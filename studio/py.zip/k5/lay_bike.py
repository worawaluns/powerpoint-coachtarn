"""20 เลย์เอาต์ชุดสวนจักรยาน ดำ+เขียวมะนาว — ลอกโครงจากเทมเพลต Bike Park (Q-Kozhino)

การ์ดมนมุมใหญ่ สลับแผ่นดำกับแผ่นเทาอ่อนบนพื้นเทากลาง หัวเรื่องตัวหนามากกลางหน้า
เส้นคดเคี้ยวเทาหนา ๆ เป็นลายพื้นหลังแบบเส้นทางปั่น วงกลมเขียวมะนาวใส่ตัวเลข
ป้ายข้อความขาวมีเงา กรอบตัวเลขขอบเขียวบนดำ
เขียวมะนาวใช้เป็นจุดเน้นเล็ก ๆ ไม่ถมเต็มหน้า (กฎสีที่ขายได้) ตัวหนังสือบนเขียวเป็นดำ
"""
import math
from pptx.util import Inches
from eng import *
import eng
import base
from lay import L, reg

txt = txt_big        # ขนาดขั้นต่ำตามชุด 366 ดู eng.roomy()
chart = chart_big

M = 0.62
DK = '161616'
GR = 'E9E9E7'
MID = 'D4D4D2'
INK = '161616'
MUTE = '555553'
SOFT = 'C2C2C0'


def LM(): return P['acc']


def _duo(): return f"duo:{mix(DK, LM(), 0.06)}:{mix('FFFFFF', LM(), 0.18)}"


def _photo(s, n, x, y, w, h, adj=0.08, focus=(0.5, 0.5), topic='bike'):
    return pic(s, ph(topic, n), x, y, w, h, geom='roundRect' if adj else None, adj=adj, focus=focus, mode=_duo())


def _squiggle(s, x, y, w, amp, c, lw=26, waves=2.5):
    """เส้นคดเคี้ยวหนา ๆ แบบเส้นทางจักรยานในต้นฉบับ (วาดเป็น freeform เปิด)"""
    E = lambda v: int(Inches(v))
    pts = [(x + w * i / 60, y + amp * math.sin(i / 60 * waves * 2 * math.pi) + amp * 0.35 * math.sin(i / 60 * 7.3))
           for i in range(61)]
    fb = s.shapes.build_freeform(E(pts[0][0]), E(pts[0][1]), scale=1.0)
    fb.add_line_segments([(E(a), E(b)) for a, b in pts[1:]], close=False)
    sh = fb.convert_to_shape(); base._nostyle(sh)
    sh.fill.background(); sh.line.color.rgb = base.rgb(c); sh.line.width = Inches(lw / 72)
    return sh


def _card(s, x, y, w, h, f, adj=0.07, shadow=False):
    return shp(s, 'round', x, y, w, h, f, adj=adj, shadow=('000000', 0.18, 12, 4) if shadow else None)


def _h(s, x, y, t, sz=40, w=8.0, c=None, al='c'):
    txt(s, x, y, w, 2.4, t, sz, c or INK, 'bd', al, sp=1.0)


def _p(s, x, y, w, t, sz=11, c=None, al='l'):
    if t: txt(s, x, y, w, 2.0, t, sz, c or MUTE, 'rg', al, sp=1.36)


def _dot(s, cx, cy, t, d=0.62, sz=15):
    shp(s, 'oval', cx - d / 2, cy - d / 2, d, d, LM(), line='FFFFFF', lw=3)
    txt(s, cx - d / 2, cy - d / 2, d, d, str(t), sz, INK, 'bd', 'c', 'm')


def _label(s, x, y, w, t, sz=10.5, h=None):
    h = h or 0.80
    shp(s, 'round', x, y, w, h, 'FFFFFF', adj=0.12, shadow=('000000', 0.14, 10, 3))
    txt(s, x + 0.15, y, w - 0.30, h, t, sz, INK, 'md', 'c', 'm', sp=1.15)


def _pill(s, x, y, t, sz=13):
    w = len(t) * 0.13 + 0.55
    shp(s, 'round', x, y, w, 0.56, LM(), adj=0.5)
    txt(s, x, y, w, 0.56, t, sz, INK, 'bd', 'c', 'm')
    return w


def _frame(s, x, y, w, h, v, lab, vs=30):
    shp(s, 'round', x, y, w, h, None, line=LM(), lw=3, adj=0.08)
    txt(s, x, y + 0.12, w, 0.80, v, vs, 'FFFFFF', 'bd', 'c')
    txt(s, x + 0.15, y + h - 0.70, w - 0.30, 0.60, lab, 10.5, SOFT, 'md', 'c', sp=1.1)


def _bg(s, dark=False):
    """พื้นเทากลาง + แผ่นการ์ดใหญ่เต็มหน้า แบบต้นฉบับที่สไลด์อยู่ในกรอบมน"""
    s2 = s
    _card(s2, 0.18, 0.18, W - 0.36, H - 0.36, DK if dark else GR, 0.05)
    _squiggle(s2, -0.5, H - 0.42, W + 1.0, 0.28, mix(DK, 'FFFFFF', 0.12) if dark else MID, 30)


# ══ เลย์เอาต์ตามรูปอ้างอิง ═════════════════════════════════════════════════

@reg
def bk_cover(prs, d):
    s = page(prs, '8C8C8A')
    _card(s, 0.18, 0.18, W - 0.36, H - 0.36, DK, 0.05)
    _squiggle(s, -0.4, 2.6, 7.8, 0.75, mix(DK, 'FFFFFF', 0.14), 34, 2.0)
    _card(s, 7.20, 1.95, 5.95, 5.37, GR, 0.10)
    _photo(s, d.get('pi', 6), 7.40, 2.15, 5.55, 4.97, 0.08, (0.6, 0.5))
    txt(s, M, 0.55, 12.0, 1.3, d['t'], 60, 'FFFFFF', 'bd')
    _pill(s, 8.20, 2.45, d.get('k', ''), 15)
    txt(s, M, 4.60, 5.6, 1.6, d['s'], 18, 'FFFFFF', 'bd', sp=1.2)
    _p(s, M, 6.15, 5.6, d.get('note', ''), 11, SOFT)


@reg
def bk_trails(prs, d):
    s = page(prs, '8C8C8A')
    _bg(s)
    _h(s, 0, 0.55, d['t'], 40, W)
    cx, cy, r = W / 2, 10.2, 6.9
    shp(s, 'donut', cx - r, cy - r, r * 2, r * 2, DK, adj=0.11)
    n = len(d['items'][:4]); cw = (W - M * 2 - 0.45) / n
    for i, (lab, body) in enumerate(d['items'][:4]):
        ang = math.radians(150 - i * 40)
        px, py = cx + (r - 0.38) * math.cos(ang), cy - (r - 0.38) * math.sin(ang)
        _dot(s, px, py, i + 1)
        x = M + i * (cw + 0.15)
        _label(s, x, 1.55, cw, f'{lab}\n{body}', 11, 1.05)
        ln(s, x + cw / 2, 2.60, px, py - 0.32, MUTE, 0.8, dash=True)


@reg
def bk_map(prs, d):
    s = page(prs, '8C8C8A')
    _card(s, 0.18, 0.18, W - 0.36, H - 0.36, GR, 0.05)
    for (x, y, w, h) in ((1.2, 2.6, 4.0, 1.6), (4.6, 1.9, 4.8, 2.0), (8.8, 2.4, 3.0, 2.6), (2.4, 4.6, 3.4, 1.2), (6.4, 4.2, 2.2, 1.1)):
        shp(s, 'cloud', x, y, w, h, MID)
    _h(s, 0, 0.55, d['t'], 40, W)
    E = lambda v: int(Inches(v))
    pts = [(1.50, 6.20), (2.80, 5.80), (4.10, 5.20), (5.00, 4.30), (5.40, 3.20), (5.70, 2.40), (6.50, 2.05), (7.40, 1.95)]
    fb = s.shapes.build_freeform(E(pts[0][0]), E(pts[0][1]), scale=1.0)
    fb.add_line_segments([(E(a), E(b)) for a, b in pts[1:]], close=False)
    sh = fb.convert_to_shape(); base._nostyle(sh); sh.fill.background()
    sh.line.color.rgb = base.rgb(DK); sh.line.width = Inches(3 / 72)
    for (x, y) in (pts[0], pts[-1]):
        shp(s, 'oval', x - 0.13, y - 0.13, 0.26, 0.26, LM(), line='FFFFFF', lw=2)
    shp(s, 'oval', 4.35, 4.05, 1.10, 1.10, LM(), line='FFFFFF', lw=4)
    txt(s, 4.35, 4.15, 1.10, 0.90, d['dist'], 15, INK, 'bd', 'c', 'm', sp=0.95)
    _label(s, pts[0][0] - 0.20, pts[0][1] + 0.25, 2.30, d['from'], 10.5, 0.55)
    _label(s, pts[-1][0] + 0.25, pts[-1][1] - 0.28, 2.30, d['to'], 10.5, 0.55)
    _card(s, 8.90, 4.70, 3.90, 2.30, DK, 0.08)
    for i, (v, lab) in enumerate(d['items'][:2]):
        txt(s, 9.20 + i * 1.85, 4.95, 1.7, 0.60, v, 22, LM(), 'bd')
        _p(s, 9.20 + i * 1.85, 5.60, 1.7, lab, 10.5, SOFT)


@reg
def bk_rating(prs, d):
    s = page(prs, '8C8C8A')
    _bg(s, True)
    _h(s, 0, 0.55, d['t'], 40, W, 'FFFFFF')
    _card(s, 1.20, 1.85, W - 2.40, 5.00, 'FFFFFF', 0.06)
    txt(s, 1.20, 2.05, W - 2.40, 0.45, d['k'], 17, INK, 'bd', 'c')
    chart(s, 'bar', 1.55, 2.60, 7.30, 4.05, d['cats'], [(d['sname'], d['vals'])], [LM()], labels=True,
          fmt='#,##0', gap=55, sz=11, c=INK)
    txt(s, 8.95, 2.95, 3.0, 1.3, d['big'], 66, INK, 'bd', 'c')
    for i in range(5):
        _star(s, 9.30 + i * 0.48, 4.40, 0.32)
    txt(s, 8.95, 4.85, 3.0, 0.32, d['biglab'], 11, INK, 'md', 'c')


def _star(s, x, y, sz):
    shp(s, 'star', x, y, sz, sz, LM())


@reg
def bk_why(prs, d):
    s = page(prs, '8C8C8A')
    _bg(s)
    _squiggle(s, -0.5, 4.2, W + 1.0, 1.2, LM(), 30, 3.0)
    _h(s, 0, 0.55, d['t'], 40, W)
    cw = (W - M * 2 - 0.40) / 3
    for i, t in enumerate(d['items'][:9]):
        x = M + (i % 3) * (cw + 0.20)
        y = 1.85 + (i // 3) * 1.70
        _card(s, x + 0.55, y + 0.20, cw - 0.55, 1.05, 'FFFFFF', 0.12, True)
        txt(s, x, y - 0.12, 0.85, 1.40, str(i + 1), 54, INK, 'bd')
        txt(s, x + 0.95, y + 0.20, cw - 1.10, 1.05, t, 13, INK, 'bd', an='m', sp=1.1)


@reg
def bk_stats_end(prs, d):
    s = page(prs, '8C8C8A')
    _bg(s, True)
    cw = 2.90
    x0 = (W - cw * 3 - 0.50) / 2
    for i, (v, lab) in enumerate(d['items'][:3]):
        _frame(s, x0 + i * (cw + 0.25), 1.50, cw, 2.05, v, lab, 34)
    _h(s, 1.0, 4.35, d['t'], 40, W - 2.0, 'FFFFFF')
    _p(s, 2.0, 6.05, W - 4.0, d.get('note', ''), 12, SOFT, 'c')


# ══ อีก 14 เลย์เอาต์ในระบบเดียวกัน ════════════════════════════════════════

@reg
def bk_agenda(prs, d):
    s = page(prs, '8C8C8A')
    _bg(s)
    _h(s, M, 0.60, d['t'], 40, 6.0, al='l')
    _photo(s, d.get('pi', 4), 7.00, 0.60, W - M - 7.00, 6.20, 0.07, (0.5, 0.4))
    for i, (h_, body) in enumerate(d['items'][:5]):
        y = 1.95 + i * 1.00
        _dot(s, M + 0.31, y + 0.35, i + 1, 0.56, 13)
        txt(s, M + 0.85, y + 0.02, 5.4, 0.40, h_, 15, INK, 'bd')
        _p(s, M + 0.85, y + 0.44, 5.4, body, 10.5)


@reg
def bk_div_dark(prs, d):
    s = page(prs, '8C8C8A')
    _bg(s, True)
    _photo(s, d.get('pi', 9), 6.90, 0.60, W - M - 6.90, 6.20, 0.07, (0.5, 0.45))
    _pill(s, M, 2.10, d.get('k', ''))
    txt(s, M, 2.85, 6.0, 2.4, d['t'], 50, 'FFFFFF', 'bd', sp=1.0)
    _p(s, M, 5.25, 5.8, d.get('note', ''), 12, SOFT)


@reg
def bk_div_light(prs, d):
    s = page(prs, '8C8C8A')
    _bg(s)
    _squiggle(s, -0.5, 1.6, W + 1.0, 0.7, LM(), 34, 2.2)
    _h(s, 0, 2.70, d['t'], 54, W)
    _p(s, 2.5, 4.60, W - 5.0, d.get('note', ''), 13, MUTE, 'c')
    _pill(s, W / 2 - 1.0, 5.55, d.get('k', ''))


@reg
def bk_visitors(prs, d):
    s = page(prs, '8C8C8A')
    _bg(s)
    _h(s, M, 0.60, d['t'], 36, 6.0, al='l')
    _p(s, M, 1.60, 5.5, d.get('note', ''), 11)
    _card(s, M, 2.40, 8.30, 4.45, 'FFFFFF', 0.05)
    n = len(d['vals'])
    chart(s, 'col', M + 0.20, 2.60, 7.90, 4.10, d['cats'], [(d['sname'], d['vals'])], [MID] * (n - 1) + [DK],
          labels=True, fmt='#,##0', gap=45, sz=11, c=INK, vary=True)
    for i, (v, lab) in enumerate(d['items'][:2]):
        y = 2.40 + i * 2.30
        _card(s, 9.15, y, W - M - 9.15, 2.15, DK if i == 0 else LM(), 0.10)
        txt(s, 9.45, y + 0.25, 3.0, 0.75, v, 32, LM() if i == 0 else INK, 'bd')
        _p(s, 9.45, y + 1.10, 3.0, lab, 10.5, SOFT if i == 0 else INK)


@reg
def bk_revenue(prs, d):
    s = page(prs, '8C8C8A')
    _bg(s, True)
    _h(s, M, 0.60, d['t'], 36, 6.0, 'FFFFFF', 'l')
    cols = [LM(), 'FFFFFF', '8C8C8A', '4A4A48']
    it = d['items'][:4]
    chart(s, 'donut', 0.70, 2.05, 4.60, 4.60, [x[0] for x in it], [('ร้อยละ', [x[1] for x in it])], cols, labels=False, hole=60)
    txt(s, 0.70, 3.95, 4.60, 0.60, d['big'], 26, 'FFFFFF', 'bd', 'c')
    txt(s, 0.70, 4.55, 4.60, 0.30, d['biglab'], 10.5, SOFT, 'rg', 'c')
    for i, (lab, v, body) in enumerate(it):
        y = 2.05 + i * 1.18
        _card(s, 5.90, y, W - M - 5.90, 1.02, mix(DK, 'FFFFFF', 0.08), 0.18)
        shp(s, 'oval', 6.15, y + 0.37, 0.28, 0.28, cols[i])
        txt(s, 6.65, y + 0.12, 3.6, 0.40, lab, 14, 'FFFFFF', 'bd')
        _p(s, 6.65, y + 0.54, 4.0, body, 10.5, SOFT)
        txt(s, 10.90, y + 0.12, 1.50, 0.80, f'{v}%', 22, LM(), 'bd', 'r', 'm')


@reg
def bk_trail_table(prs, d):
    s = page(prs, '8C8C8A')
    _bg(s)
    _h(s, M, 0.60, d['t'], 36, 9.0, al='l')
    cols = d['colw']; tw = W - M * 2; y0 = 1.75; rh = 0.82
    xs = [M]
    for f in cols[:-1]: xs.append(xs[-1] + tw * f)
    _card(s, M, y0, tw, 0.62, DK, 0.25)
    for j, hd in enumerate(d['head']):
        txt(s, xs[j] + 0.22, y0, tw * cols[j] - 0.44, 0.62, hd, 12, 'FFFFFF', 'bd', 'l' if j == 0 else 'c', 'm')
    for i, row in enumerate(d['rows']):
        y = y0 + 0.75 + i * rh
        _card(s, M, y, tw, rh - 0.12, 'FFFFFF', 0.18)
        _dot(s, M + 0.40, y + (rh - 0.12) / 2, i + 1, 0.46, 12)
        for j, cell in enumerate(row):
            txt(s, xs[j] + (0.80 if j == 0 else 0.22), y, tw * cols[j] - (1.0 if j == 0 else 0.44), rh - 0.12, cell,
                12.5 if j == 0 else 12, INK, 'bd' if j == 0 else 'md', 'l' if j == 0 else 'c', 'm')
    _p(s, M, y0 + 0.75 + len(d['rows']) * rh + 0.15, 11.5, d.get('note', ''), 10.5)


@reg
def bk_photo_trio(prs, d):
    s = page(prs, '8C8C8A')
    _bg(s, True)
    _h(s, M, 0.60, d['t'], 36, 9.0, 'FFFFFF', 'l')
    cw = (W - M * 2 - 0.40) / 3
    for i, (n, h_, body) in enumerate(d['items'][:3]):
        x = M + i * (cw + 0.20)
        _photo(s, n, x, 1.75, cw, 3.10, 0.08)
        _pill(s, x + 0.20, 1.95, h_, 12)
        _p(s, x, 5.05, cw, body, 11, SOFT)


@reg
def bk_plan(prs, d):
    s = page(prs, '8C8C8A')
    _bg(s)
    _h(s, M, 0.60, d['t'], 36, 9.0, al='l')
    cw = (W - M * 2 - 0.40) / 3
    for i, (h_, amt, body) in enumerate(d['items'][:3]):
        x = M + i * (cw + 0.20)
        hot = i == 0
        _card(s, x, 1.80, cw, 4.10, DK if hot else 'FFFFFF', 0.08, not hot)
        txt(s, x + 0.30, 2.05, cw - 0.6, 0.80, h_, 17, 'FFFFFF' if hot else INK, 'bd', sp=1.05)
        txt(s, x + 0.30, 3.05, cw - 0.6, 0.70, amt, 30, LM() if hot else INK, 'bd')
        _p(s, x + 0.30, 3.95, cw - 0.6, body, 11, SOFT if hot else MUTE)
    txt(s, M, 6.15, 11.0, 0.40, d.get('total', ''), 14, INK, 'bd')


@reg
def bk_forecast(prs, d):
    s = page(prs, '8C8C8A')
    _bg(s, True)
    _h(s, M, 0.60, d['t'], 36, 8.0, 'FFFFFF', 'l')
    _card(s, M, 1.75, 8.20, 5.05, 'FFFFFF', 0.05)
    chart(s, 'line', M + 0.20, 1.95, 7.80, 4.70, d['cats'], d['series'], [INK, '8C8C8A'], labels=True,
          fmt='#,##0', legend=True, sz=11, c=INK, lw=3)
    for i, (v, lab) in enumerate(d['items'][:3]):
        y = 1.75 + i * 1.72
        _frame(s, 9.10, y, W - M - 9.10, 1.55, v, lab, 26)


@reg
def bk_timeline(prs, d):
    s = page(prs, '8C8C8A')
    _bg(s)
    _h(s, 0, 0.60, d['t'], 36, W)
    n = len(d['items'][:4]); cw = (W - M * 2) / n
    _squiggle(s, M, 3.10, W - M * 2, 0.25, DK, 8, 1.5)
    for i, (when, h_, body) in enumerate(d['items'][:4]):
        cx = M + cw * (i + 0.5)
        _dot(s, cx, 3.10 + 0.25 * math.sin((cx - M) / (W - M * 2) * 1.5 * 2 * math.pi) +
             0.25 * 0.35 * math.sin((cx - M) / (W - M * 2) * 7.3), i + 1)
        _card(s, cx - cw / 2 + 0.12, 3.95, cw - 0.24, 2.85, 'FFFFFF', 0.08, True)
        txt(s, cx - cw / 2 + 0.35, 4.15, cw - 0.7, 0.30, when, 11, MUTE, 'md')
        txt(s, cx - cw / 2 + 0.35, 4.50, cw - 0.7, 0.70, h_, 15, INK, 'bd', sp=1.05)
        _p(s, cx - cw / 2 + 0.35, 5.30, cw - 0.7, body, 10.5)


@reg
def bk_team(prs, d):
    s = page(prs, '8C8C8A')
    _bg(s)
    _h(s, M, 0.60, d['t'], 36, 9.0, al='l')
    cw = (W - M * 2 - 0.60) / 4
    for i, (name, role, body, pi) in enumerate(d['items'][:4]):
        x = M + i * (cw + 0.20)
        _card(s, x, 1.75, cw, 5.05, 'FFFFFF', 0.07, True)
        _photo(s, pi, x + 0.18, 1.93, cw - 0.36, 2.50, 0.07)
        txt(s, x + 0.28, 4.60, cw - 0.56, 0.40, name, 15, INK, 'bd')
        w = len(role) * 0.10 + 0.40
        shp(s, 'round', x + 0.28, 5.05, w, 0.34, LM() if i == 0 else MID, adj=0.5)
        txt(s, x + 0.28, 5.05, w, 0.34, role, 10, INK, 'md', 'c', 'm')
        _p(s, x + 0.28, 5.55, cw - 0.56, body, 10.5)


@reg
def bk_quote(prs, d):
    s = page(prs, '8C8C8A')
    _bg(s, True)
    _photo(s, d.get('pi', 1), M, 0.60, 5.00, 6.20, 0.07, (0.5, 0.5))
    icon(s, 'quote', 6.50, 1.40, 0.80, LM())
    txt(s, 6.10, 2.10, 6.6, 3.0, d['t'], 22, 'FFFFFF', 'md', sp=1.3)
    for i in range(5):
        _star(s, 6.15 + i * 0.42, 5.15, 0.30)
    txt(s, 6.10, 5.65, 6.0, 0.40, d['who'], 15, 'FFFFFF', 'bd')
    _p(s, 6.10, 6.08, 6.4, d['role'], 11, SOFT)


@reg
def bk_close(prs, d):
    s = page(prs, '8C8C8A')
    _bg(s)
    _card(s, 6.80, 0.60, W - M - 6.80, 6.20, DK, 0.08)
    _photo(s, d.get('pi', 7), 6.95, 0.75, W - M - 7.10, 3.80, 0.07, (0.5, 0.45))
    for i, (lab, v) in enumerate(d['items'][:3]):
        y = 4.80 + i * 0.62
        txt(s, 7.20, y, 1.6, 0.40, lab, 11, SOFT, 'rg')
        txt(s, 8.80, y, 3.8, 0.40, v, 13, 'FFFFFF', 'bd')
    txt(s, M, 1.30, 6.0, 2.6, d['t'], 50, INK, 'bd', sp=1.0)
    _p(s, M, 3.95, 5.6, d.get('note', ''), 12.5)
    _pill(s, M, 5.15, d.get('k', ''), 14)


@reg
def bk_safety(prs, d):
    s = page(prs, '8C8C8A')
    _bg(s, True)
    _photo(s, d.get('pi', 0), 6.90, 0.60, W - M - 6.90, 6.20, 0.07, (0.5, 0.45))
    txt(s, M, 0.60, 6.0, 1.6, d['t'], 36, 'FFFFFF', 'bd', sp=1.0)
    _p(s, M, 2.10, 5.8, d.get('note', ''), 11.5, SOFT)
    for i, (v, lab) in enumerate(d['items'][:3]):
        _frame(s, M + i * 2.00, 3.70, 1.85, 2.30, v, lab, 26)
