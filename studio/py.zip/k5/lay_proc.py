"""12 เลย์เอาต์ชุด Process Infographic — ลอกโครงจากเทมเพลตอ้างอิงที่ไอซ์ส่งมา

ทุกหน้าใช้โครงเดียวกัน: โลโก้+ชื่อชุดซ้ายบน, ไอคอนขีดขวาบน, company.com ซ้ายล่าง,
เลขหน้าขวาล่าง. สีมีแค่เหลือง (acc) + ดำ (ink) + ขาว ตามต้นฉบับ
"""
from eng import *
import eng
from lay import L, reg


def _duo():
    """ย้อมรูปให้อยู่ในโทนเดียวกับพาเลตต์ของเด็ค ไม่ให้สีรูปตีกับสีธีม"""
    if P.get('dark'):
        return f"duo:{mix(P['bg'], P['acc'], 0.34)}:{mix(P['acc'], 'FFFFFF', 0.54)}"
    return f"duo:{mix(P['ink'], P['acc'], 0.42)}:{mix(P['bg'], P['acc'], 0.13)}"

M = 0.72                                   # ขอบซ้ายขวา
PALE = 'FFFFFF'                            # ปลายไล่สีของการ์ดเหลือง


# ── โครงหน้าที่ใช้ซ้ำทุกสไลด์ ────────────────────────────────────────────────
def _chrome(s, d, on_acc=False):
    ink = P['ink']
    shp(s, 'round', M, 0.40, 0.16, 0.16, ink, adj=0.22)
    txt(s, M + 0.25, 0.36, 4.2, 0.26, d.get('brand', 'Process Infographic'), 8.5, ink, 'md')
    for i in range(3):                     # ไอคอนขีดสามขีดขวาบน
        y = 0.42 + i * 0.07
        shp(s, 'rect', W - M - 0.30, y, 0.05, 0.035, ink)
        shp(s, 'rect', W - M - 0.21, y, 0.21, 0.035, ink)
    fc = mix(P['acc'], P['ink'], 0.52) if on_acc else P['mute']
    txt(s, M, H - 0.70, 4, 0.26, d.get('site', 'company.com'), 8.5, fc)
    if d.get('n'):
        txt(s, W - M - 2.4, H - 0.70, 2.4, 0.26, f"{d['n']}/{d.get('tot', 20)}", 8.5, fc, al='r')


def _soft(on_acc=False):
    """สีตัวหนังสือรอง: บนพื้นขาวใช้เทา บนพื้นเหลืองต้องเข้มกว่านั้นมากถึงจะอ่านออก"""
    return mix(P['acc'], P['ink'], 0.62) if on_acc else mix(P['bg'], P['mute'], 0.75)


def _tag(s, x, y, t, al='l', on_acc=False):
    """ป้ายเล็กขีดเส้นใต้ มุมหน้า"""
    if not t: return
    w = len(t) * 0.075 + 0.12
    x0 = x - w if al == 'r' else x
    c = mix(P['acc'], P['ink'], 0.55) if on_acc else P['mute']
    txt(s, x0, y, w, 0.24, t, 13, c, 'rg', al)
    ln(s, x0, y + 0.23, x0 + w, y + 0.23, c, 0.6)


def _ycard(s, x, y, w, h, adj=0.10):
    """การ์ดเหลืองไล่สีจางไปทางขวา แบบเดียวกับต้นฉบับ"""
    return gradband(s, x, y, w, h, 0, c1=P['acc'], c2=PALE, kind='round', adj=adj)


def _head(s, d, y=0.95, w=5.6, sz=54):
    txt(s, M, y, w, 1.9, d['t'], sz, P['ink'], 'md', sp=1.12)


def _muted(s, x, y, w, t, sz=14, on_acc=False, al='l'):
    txt(s, x, y, w, 0.5, t, sz, _soft(on_acc), 'rg', al, sp=1.35)


# ── 1. หัวเรื่อง + การ์ดตัวเลข + แถบความคืบหน้า 3 แถว ────────────────────────
@reg
def pf_title_bars(prs, d):
    s = page(prs); _chrome(s, d)
    _head(s, d, 0.92, 4.95, 40)
    cx = 5.85                                              # เส้นแบ่งกลาง
    c = d['card']
    _ycard(s, M, 3.36, 4.55, 2.58)
    shp(s, 'round', M + 0.22, 3.56, 0.40, 0.40, 'FFFFFF', adj=0.26)
    shp(s, 'rect', M + 0.35, 3.68, 0.055, 0.16, P['ink'])
    shp(s, 'rect', M + 0.43, 3.64, 0.055, 0.20, P['ink'])
    txt(s, M + 0.22, 4.12, 2.7, 0.70, c[0], 34, P['ink'], 'md')
    txt(s, M + 0.22, 4.86, 4.0, 0.62, c[1], 10.5, P['ink'], 'bd', sp=1.3)
    _muted(s, M + 0.22, 5.42, 3.9, c[2], 13, True)
    ln(s, cx, 0.92, cx, H - 0.95, mix(P['bg'], P['mute'], 0.45), 0.7)
    for i, (h_, body, pct) in enumerate(d['items'][:3]):
        y = 1.18 + i * 1.74
        shp(s, 'oval', cx - 0.21, y - 0.02, 0.42, 0.42, P['acc'])
        txt(s, cx - 0.21, y - 0.02, 0.42, 0.42, f'{i + 1:02d}', 13.5, P['ink'], 'md', 'c', 'm')
        txt(s, cx + 0.72, y - 0.04, 5.2, 0.42, h_, 16.5, P['ink'], 'md')
        _muted(s, cx + 0.72, y + 0.44, 5.1, body, 13.5)
        bx, bw = cx + 0.72, 4.45
        shp(s, 'round', bx, y + 1.00, bw, 0.20, mix(P['bg'], P['mute'], 0.28), adj=0.5)
        gradband(s, bx, y + 1.00, bw * pct / 100, 0.20, 0, c1=P['acc'], c2=P['g2'], kind='round', adj=0.5)
        txt(s, bx + bw + 0.22, y + 0.92, 0.9, 0.36, f'{pct}%', 16.5, P['ink'], 'rg', an='m')


# ── 2. แถบไล่ระดับพร้อมหมุด + 4 คอลัมน์ ─────────────────────────────────────
@reg
def pf_scale_cols(prs, d):
    s = page(prs); _chrome(s, d)
    txt(s, M, 0.92, 5.4, 1.5, d['t'], 48, P['ink'], 'md', sp=1.12)
    _muted(s, 6.9, 1.00, 5.7, d['s'], 14.5)
    y = 3.05
    gradband(s, M, y, W - M * 2, 0.54, 0, c1=P['acc'], c2=P['g2'])
    for frac, lab in d['ticks']:
        x = M + (W - M * 2) * frac
        txt(s, x - 0.6, y - 0.52, 1.2, 0.38, lab, 16.5, P['ink'], 'md', 'c')
        ln(s, x, y, x, y + 0.54, mix(P['acc'], P['ink'], 0.35), 0.8)
    cw = (W - M * 2) / 4
    for i, (h_, body) in enumerate(d['items'][:4]):
        x = M + i * cw
        txt(s, x, y + 0.92, cw - 0.40, 0.62, h_, 16, P['ink'], 'md', sp=1.25)
        _muted(s, x, y + 1.44, cw - 0.40, body, 13.5)


# ── 3. หน้าปิด พื้นเหลืองเต็ม ───────────────────────────────────────────────
@reg
def pf_close_grad(prs, d):
    s = page(prs)
    gradband(s, 0, 0, W, H, 320, c1=P['acc'], c2=P['g2'])
    _chrome(s, d, True)
    txt(s, M, 1.55, 9.4, 2.6, d['t'], 54, P['ink'], 'md', sp=1.06)
    txt(s, M, 4.65, 6.2, 0.62, d['s'], 16, P['ink'], 'bd', sp=1.3)
    _muted(s, M, 5.32, 6.0, d['note'], 14.5, True)
    bw = 1.95
    shp(s, 'round', W - M - bw, 4.68, bw, 0.56, P['ink'], adj=0.5)
    txt(s, W - M - bw, 4.68, bw, 0.56, d['cta'], 15, 'FFFFFF', 'md', 'c', 'm')


# ── 4. การ์ดเหลือง 3 ใบเรียงทแยง + เส้นทแยงมุม ──────────────────────────────
@reg
def pf_diag_cards(prs, d):
    s = page(prs); _chrome(s, d)
    _head(s, d, 0.98, 4.6, 40)
    txt(s, M, 3.30, 3.6, 0.70, d['s'], 16, P['ink'], 'md', sp=1.3)
    _muted(s, M, 4.08, 3.4, d['note'], 13.5)
    ln(s, W - 0.35, 0.18, 7.30, H - 0.18, mix(P['bg'], P['mute'], 0.6), 0.8)
    for i, (v, body, note) in enumerate(d['items'][:3]):
        cw, ch = 4.35, 1.28
        x = 5.95 - i * 0.62
        y = 1.12 + i * 1.78
        _ycard(s, x, y, cw, ch, adj=0.13)
        txt(s, x + 0.30, y + 0.24, 1.75, 0.80, v, 43, P['ink'], 'md', an='m')
        txt(s, x + 2.05, y + 0.26, 2.05, 0.54, body, 13.5, P['ink'], 'rg', sp=1.3)
        _muted(s, x + 2.05, y + 0.86, 2.0, note, 13, True)
        mx = W - 0.35 - (W - 0.35 - 7.30) * ((y + ch / 2 - 0.18) / (H - 0.36))
        shp(s, 'oval', mx - 0.19, y + ch / 2 - 0.19, 0.38, 0.38, P['acc'])
        txt(s, mx - 0.19, y + ch / 2 - 0.19, 0.38, 0.38, f'{i + 1:02d}', 13, P['ink'], 'md', 'c', 'm')


# ── 5. วงกลมฟองสามขนาด + เส้นชี้ค่า ─────────────────────────────────────────
@reg
def pf_bubbles(prs, d):
    s = page(prs); _chrome(s, d)
    txt(s, M, 4.35, 4.2, 1.6, d['t'], 51, P['ink'], 'md', sp=1.12)
    _tag(s, M, 1.02, d.get('tagl', ''))
    _tag(s, W - M, 1.02, d.get('tagr', ''), 'r')
    # (จุดกลาง, เส้นผ่านศูนย์กลาง, สี, ป้ายใน, ค่า, คำอธิบาย, ฝั่งของป้ายค่า)
    spec = [((4.95, 2.30), 1.25, P['acc'], 'l'),
            ((6.45, 3.25), 1.55, P['ink'], 'l'),
            ((8.30, 4.00), 2.15, P['acc'], 'r')]
    for i, (it, (ctr, dia, col, side)) in enumerate(zip(d['items'][:3], spec)):
        v, lb, body = it
        cx, cy = ctr
        shp(s, 'oval', cx - dia / 2, cy - dia / 2, dia, dia, col)
        txt(s, cx - dia / 2, cy - 0.18, dia, 0.36, lb, 14, 'FFFFFF' if col == P['ink'] else P['ink'], 'rg', 'c', 'm')
        if side == 'l':
            ex = cx - dia / 2 - 0.30
            ln(s, ex, cy, ex - 0.95, cy, mix(P['bg'], P['mute'], 0.7), 0.8)
            txt(s, ex - 3.45, cy - 0.34, 2.4, 0.5, v, 27, P['ink'],'md', 'r', 'm')
            _muted(s, ex - 3.45, cy + 0.04, 2.4, body, 13)
        else:
            ex = cx + dia / 2 + 0.25
            ln(s, ex, cy, ex + 0.45, cy, mix(P['bg'], P['mute'], 0.7), 0.8)
            txt(s, ex + 0.60, cy - 0.34, 2.15, 0.5, v, 27, P['ink'],'md', an='m')
            _muted(s, ex + 0.60, cy + 0.04, 2.1, body, 13)


# ── 6. รูปซ้าย + หัวเรื่องบนพื้นเหลืองขวา ───────────────────────────────────
@reg
def pf_photo_grad(prs, d):
    s = page(prs)
    gradband(s, 5.95, 0, W - 5.95, H, 320, c1=P['acc'], c2=P['g2'])
    _chrome(s, d)
    pic(s, ph(d['topic'], d.get('pi', 0)), M, 1.05, 4.75, 2.95, geom='roundRect', adj=0.05, focus=(0.5, 0.42), mode=_duo())
    txt(s, 6.35, 1.05, 6.3, 1.95, d['t'], 37, P['ink'], 'md', sp=1.22)
    _tag(s, 6.35, 3.22, d.get('tagl', ''), on_acc=True)
    _tag(s, W - M, 3.22, d.get('tagr', ''), 'r', on_acc=True)
    card(s, M + 0.35, 4.28, 2.95, 1.35, 'FFFFFF', adj=0.10, shadow=True)
    shp(s, 'round', M + 0.55, 4.46, 0.34, 0.34, P['acc'], adj=0.26)
    txt(s, M + 0.55, 4.90, 2.55, 0.62, d['card'], 13.5, P['ink'], 'md', sp=1.3)
    txt(s, 6.35, 4.28, 2.5, 0.72, d['s'], 14.5, P['ink'], 'md', sp=1.3)
    txt(s, 9.30, 4.22, 3.3, 0.80, d['big'], 43, P['ink'], 'md')
    _muted(s, 9.30, 5.05, 3.0, d['note'], 13.5, True)


# ── 7. พื้นเหลืองเต็มหน้า + ตัวเลขใหญ่ + การ์ดขาว ───────────────────────────
@reg
def pf_grad_stat(prs, d):
    s = page(prs)
    gradband(s, 0, 0, W, H, 320, c1=P['acc'], c2=P['g2'])
    _chrome(s, d, True)
    txt(s, M, 1.05, 7.0, 2.3, d['t'], 40, P['ink'], 'md', sp=1.22)
    _tag(s, M, 3.30, d.get('tagl', ''), on_acc=True)
    txt(s, M, 3.80, 4.6, 0.72, d['s'], 15, P['ink'], 'md', sp=1.3)
    txt(s, M, 4.48, 3.4, 0.82, d['big'], 45, P['ink'], 'md')
    _muted(s, M, 5.34, 3.6, d['note'], 13.5, True)
    card(s, 8.00, 3.92, 3.25, 1.46, 'FFFFFF', adj=0.10, shadow=True)
    shp(s, 'round', 8.24, 4.12, 0.34, 0.34, P['acc'], adj=0.26)
    txt(s, 8.24, 4.56, 2.78, 0.64, d['card'], 13.5, P['ink'], 'md', sp=1.3)


# ── 8. ลูกศรห้าขั้นสลับเหลืองดำ + ตัวเลขบนล่าง ──────────────────────────────
@reg
def pf_arrows(prs, d):
    s = page(prs); _chrome(s, d)
    _tag(s, M, 1.00, d.get('tagl', ''))
    _tag(s, W - M, 1.00, d.get('tagr', ''), 'r')
    n = 5
    span = W - M * 2
    aw = span / (n - 0.32 * (n - 1))                 # ลูกศรเกยกันแบบต้นฉบับ
    step = aw * 0.68
    ay, ah = 3.18, 1.22
    for i, lab in enumerate(d['steps'][:n]):
        x = M + i * step
        yellow = i % 2 == 0
        shp(s, 'chev', x, ay, aw, ah, P['acc'] if yellow else P['ink'], adj=0.46)
        txt(s, x + aw * 0.18, ay, aw * 0.64, ah, lab, 15.5, P['ink'] if yellow else 'FFFFFF', 'md', 'c', 'm')
    for v, body, note, idx in d['above']:            # ตัวเลขด้านบน วางตรงกลางลูกศรที่ระบุ
        x = M + idx * step + aw * 0.5 - 1.25
        txt(s, x, 1.42, 2.5, 0.62, v, 38, P['ink'], 'md')
        _muted(s, x, 2.08, 2.3, body, 13.5)
        _muted(s, x, 2.56, 2.3, note, 13)
    for v, body, note, idx in d['below']:
        x = M + idx * step + aw * 0.5 - 1.25
        txt(s, x, 4.70, 2.5, 0.62, v, 38, P['ink'], 'md')
        _muted(s, x, 5.36, 2.3, body, 13.5)
        _muted(s, x, 5.84, 2.3, note, 13)


# ── 9. การ์ดเหลือง 2 ใบ + วงแหวน 2 วง ───────────────────────────────────────
@reg
def pf_cards_donuts(prs, d):
    s = page(prs); _chrome(s, d)
    cx = 5.75
    ln(s, cx, 1.05, cx, H - 0.95, mix(P['bg'], P['mute'], 0.45), 0.7)
    for i, (h_, note) in enumerate(d['cards'][:2]):
        y = 1.72 + i * 2.25
        _ycard(s, M, y, 4.35, 1.42, adj=0.12)
        shp(s, 'round', M + 0.24, y + 0.20, 0.34, 0.34, 'FFFFFF', adj=0.26)
        txt(s, M + 0.70, y + 0.22, 3.12, 0.60, h_, 14.5, P['ink'], 'md', sp=1.3)
        _muted(s, M + 0.70, y + 0.88, 3.08, note, 13, True)
    for i, (pct, lb, body) in enumerate(d['rings'][:2]):
        y = 2.08 + i * 2.30
        rx = cx + 1.25
        ring(s, rx, y, 1.42, pct / 100, P['acc'], mix(P['bg'], P['mute'], 0.26), 0.13)
        txt(s, rx - 0.71, y - 0.22, 1.42, 0.44, f'{pct}%', 17, P['ink'],'md', 'c', 'm')
        txt(s, rx + 1.08, y - 0.40, 4.4, 0.40, lb, 16.5, P['ink'], 'md')
        _muted(s, rx + 1.08, y + 0.02, 4.3, body)


# ── 10. เส้นหักซิกแซก + ตัวเลขสลับฝั่ง + หัวเรื่องขวา ───────────────────────
@reg
def pf_zigzag(prs, d):
    s = page(prs); _chrome(s, d)
    _tag(s, W - M, 1.08, d.get('tagr', ''), 'r')
    _tag(s, W - M, 5.72, d.get('tagr2', ''), 'r')
    txt(s, 7.95, 2.05, 4.7, 2.7, d['t'], 51, P['ink'], 'md', sp=1.14)
    vx = [3.05, 4.22, 3.05]                           # จุดหักซ้าย-ขวา-ซ้าย
    vy = [2.00, 3.62, 5.24]
    ln(s, 3.05, 0.55, vx[0], vy[0], mix(P['bg'], P['mute'], 0.6), 0.8)
    for a_, b_ in zip(range(2), range(1, 3)):
        ln(s, vx[a_], vy[a_], vx[b_], vy[b_], mix(P['bg'], P['mute'], 0.6), 0.8)
    ln(s, vx[2], vy[2], 3.05, H - 0.42, mix(P['bg'], P['mute'], 0.6), 0.8)
    for i, (v, lb, cardt, note) in enumerate(d['items'][:3]):
        y = vy[i]
        shp(s, 'oval', vx[i] - 0.11, y - 0.11, 0.22, 0.22, P['acc'])
        if i % 2 == 0:                                # ตัวเลขซ้าย การ์ดขวา
            txt(s, M + 0.15, y - 0.52, 2.0, 0.56, v, 36, P['ink'], 'md')
            txt(s, M + 0.15, y + 0.06, 2.3, 0.32, lb, 14.5, P['ink'], 'rg')
            _ycard(s, vx[i] + 0.52, y - 0.62, 2.95, 1.12, adj=0.14)
            txt(s, vx[i] + 0.74, y - 0.44, 2.5, 0.60, cardt, 13.5, P['ink'], 'md', sp=1.3)
            _muted(s, vx[i] + 0.74, y + 0.18, 2.4, note, 13, True)
        else:                                         # การ์ดซ้าย ตัวเลขขวา
            _ycard(s, M - 0.08, y - 0.62, 2.95, 1.12, adj=0.14)
            txt(s, M + 0.14, y - 0.44, 2.5, 0.60, cardt, 13.5, P['ink'], 'md', sp=1.3)
            _muted(s, M + 0.14, y + 0.18, 2.4, note, 13, True)
            txt(s, vx[i] + 0.52, y - 0.52, 2.6, 0.56, v, 36, P['ink'], 'md')
            txt(s, vx[i] + 0.52, y + 0.06, 2.8, 0.32, lb, 14.5, P['ink'], 'rg')


# ── 11. วงแหวนสามวงซ้อนแนวตั้ง + ป้ายขวา ────────────────────────────────────
@reg
def pf_rings_stack(prs, d):
    s = page(prs); _chrome(s, d)
    _head(s, d, 0.92, 4.5, 40)
    txt(s, M, 3.72, 3.6, 0.82, d['big'], 47, P['ink'], 'md')
    txt(s, M, 4.60, 3.3, 0.64, d['s'], 15.5, P['ink'], 'bd', sp=1.3)
    _muted(s, M, 5.28, 3.2, d['note'], 13)
    cx = 6.55
    spec = [(1.72, 1.52), (3.62, 2.42), (5.52, 1.52)]   # (จุดกลางแนวตั้ง, ขนาด) วงกลางใหญ่สุด
    for i, (it, (cy, dia)) in enumerate(zip(d['items'][:3], spec)):
        pct, lb, body = it
        ring(s, cx, cy, dia, pct / 100, P['acc'], mix(P['bg'], P['mute'], 0.22), 0.15)
        txt(s, cx - dia / 2, cy - 0.20, dia, 0.40, f'{pct}%', 13 if dia < 2 else 15, P['ink'], 'rg', 'c', 'm')
        ax = cx + dia / 2 + 0.22
        ln(s, ax, cy, 9.08, cy, mix(P['bg'], P['mute'], 0.65), 0.8)
        shp(s, 'tri', 9.06, cy - 0.06, 0.12, 0.12, mix(P['bg'], P['mute'], 0.65), rot=90)
        txt(s, 9.35, cy - 0.42, 3.2, 0.38, lb, 16, P['ink'], 'md')
        _muted(s, 9.35, cy - 0.02, 3.15, body, 13)


# ── 12. วงกลมเหลืองสามวง มีลูกศรโค้งล้อม ────────────────────────────────────
@reg
def pf_circle_arrows(prs, d):
    s = page(prs); _chrome(s, d)
    _tag(s, M, 1.02, d.get('tagl', ''))
    _tag(s, M, 5.88, d.get('tagl2', ''))
    spec = [((6.30, 2.32), 1.62), ((5.05, 4.62), 1.98), ((7.95, 4.10), 1.80)]
    for i, (it, (ctr, dia)) in enumerate(zip(d['items'][:3], spec)):
        pct, lb, body, side = it
        cx, cy = ctr
        shp(s, 'oval', cx - dia / 2, cy - dia / 2, dia, dia, P['acc'])
        txt(s, cx - dia / 2, cy - 0.22, dia, 0.44, f'{pct}%', 17, P['ink'],'md', 'c', 'm')
        od = dia + 0.30                                   # วงแหวนดำบางล้อมนอก เว้นช่องให้หัวลูกศร
        shp(s, 'arc', cx - od / 2, cy - od / 2, od, od, P['ink'], adj=[300 * 0.6, 240 * 0.6, 0.055])
        shp(s, 'tri', cx - 0.17, cy - od / 2 - 0.14, 0.30, 0.28, P['ink'], rot=270)
        if side == 'r':
            txt(s, cx + dia / 2 + 0.52, cy - 0.62, 3.15, 0.40, lb, 16.5, P['ink'], 'md')
            _muted(s, cx + dia / 2 + 0.52, cy - 0.20, 3.05, body, 13)
        else:
            lx = cx - dia / 2 - 0.45 - 2.95
            txt(s, lx, cy - 0.62, 2.95, 0.40, lb, 16.5, P['ink'], 'md', 'r')
            txt(s, lx, cy - 0.20, 2.95, 0.5, body, 13, mix(P['bg'], P['mute'], 0.75), 'rg', 'r', sp=1.35)
    txt(s, M + 0.12, d['bigy'], 3.3, 0.82, d['big'], 44, P['ink'], 'md')
    _muted(s, M + 0.12, d['bigy'] + 0.86, 3.0, d['note'], 13)


# ══ อีก 7 เลย์เอาต์ เติมให้ครบ 20 หน้าเท่าชุดอื่นในคลัง ════════════════════

# ── ปก พื้นเหลืองเต็ม ───────────────────────────────────────────────────────
@reg
def pf_cover(prs, d):
    s = page(prs)
    gradband(s, 0, 0, W, H, 320, c1=P['acc'], c2=P['g2'])
    _chrome(s, d, True)
    if d.get('k'):
        shp(s, 'round', M, 1.18, len(d['k']) * 0.082 + 0.45, 0.40, P['ink'], adj=0.5)
        txt(s, M, 1.18, len(d['k']) * 0.082 + 0.45, 0.40, d['k'], 9, 'FFFFFF', 'md', 'c', 'm')
    txt(s, M, 1.90, 9.6, 2.5, d['t'], d.get('tsz', 52), P['ink'], 'md', sp=1.06)
    if d.get('s'): txt(s, M, 4.55, 7.2, 0.80, d['s'], 16, P['ink'], 'rg', sp=1.4)
    for i, (v, lb) in enumerate(d.get('stats', [])[:3]):
        x = M + i * 2.95
        ln(s, x, 5.62, x, 6.42, mix(P['acc'], P['ink'], 0.4), 1.2)
        txt(s, x + 0.22, 5.62, 2.5, 0.52, v, 30, P['ink'], 'md')
        txt(s, x + 0.22, 6.14, 2.5, 0.32, lb, 14, mix(P['acc'], P['ink'], 0.6), 'rg')


# ── สารบัญ ──────────────────────────────────────────────────────────────────
@reg
def pf_agenda(prs, d):
    s = page(prs); _chrome(s, d)
    _head(s, d, 1.00, 3.9, 36)
    _muted(s, M, 3.10, 3.6, d.get('s', ''), 14)
    x = 5.30
    for i, (h_, body) in enumerate(d['items'][:5]):
        y = 1.05 + i * 1.04
        shp(s, 'oval', x, y + 0.04, 0.42, 0.42, P['acc'])
        txt(s, x, y + 0.04, 0.42, 0.42, f'{i + 1:02d}', 13.5, P['ink'], 'md', 'c', 'm')
        txt(s, x + 0.68, y, 6.5, 0.40, h_, 16.5, P['ink'], 'md')
        _muted(s, x + 0.68, y + 0.42, 6.4, body, 13.5)
        if i < 4: ln(s, x, y + 0.90, W - M, y + 0.90, mix(P['bg'], P['mute'], 0.28), 0.6)


# ── หน้าคั่นบท ──────────────────────────────────────────────────────────────
@reg
def pf_divider(prs, d):
    s = page(prs); _chrome(s, d)
    gradband(s, 7.55, 0, W - 7.55, H, 320, c1=P['acc'], c2=P['g2'])
    txt(s, M, 2.55, 2.2, 1.5, d['num'], 54, mix(P['bg'], P['acc'], 0.75), 'md')
    txt(s, M, 4.05, 6.3, 1.0, d['t'], 48, P['ink'], 'md', sp=1.1)
    if d.get('s'): _muted(s, M, 5.15, 5.9, d['s'], 14.5)


# ── ขั้นตอนแนวตั้งมีเส้นร้อย ────────────────────────────────────────────────
@reg
def pf_steps_vert(prs, d):
    s = page(prs); _chrome(s, d)
    txt(s, M, 0.95, 4.2, 1.3, d['t'], 43, P['ink'], 'md', sp=1.12)
    _muted(s, M, 2.45, 3.9, d.get('s', ''), 14)
    x = 5.45
    n = len(d['items'][:4])
    ln(s, x + 0.21, 1.20, x + 0.21, 1.20 + (n - 1) * 1.34 + 0.42, mix(P['bg'], P['mute'], 0.35), 0.8)
    for i, (h_, body, tag) in enumerate(d['items'][:4]):
        y = 1.20 + i * 1.34
        shp(s, 'oval', x, y, 0.42, 0.42, P['acc'])
        txt(s, x, y, 0.42, 0.42, f'{i + 1}', 15, P['ink'], 'md', 'c', 'm')
        txt(s, x + 0.70, y - 0.04, 5.0, 0.40, h_, 17, P['ink'], 'md')
        _muted(s, x + 0.70, y + 0.40, 4.9, body, 13.5)
        shp(s, 'round', W - M - 1.45, y + 0.02, 1.45, 0.38, mix(P['bg'], P['acc'], 0.45), adj=0.5)
        txt(s, W - M - 1.45, y + 0.02, 1.45, 0.38, tag, 13.5, P['ink'], 'md', 'c', 'm')


# ── เทียบก่อนและหลัง สองคอลัมน์ ─────────────────────────────────────────────
@reg
def pf_compare(prs, d):
    s = page(prs); _chrome(s, d)
    txt(s, M, 0.95, 6.0, 0.9, d['t'], 43, P['ink'], 'md')
    _muted(s, M, 1.88, 6.6, d.get('s', ''), 14)
    cw, gap = 5.55, 0.65
    for c, (ttl, rows) in enumerate(zip(d['heads'], [d['before'], d['after']])):
        x = M + c * (cw + gap)
        hot = c == 1
        shp(s, 'round', x, 2.55, cw, 0.52, P['acc'] if hot else mix(P['bg'], P['mute'], 0.18), adj=0.3)
        txt(s, x, 2.55, cw, 0.52, ttl, 16, P['ink'], 'md', 'c', 'm')
        for i, (lab, v) in enumerate(rows[:4]):
            y = 3.30 + i * 0.86
            txt(s, x + 0.14, y, cw - 1.75, 0.46, lab, 15, P['ink'], 'rg', an='m')
            txt(s, x + cw - 1.60, y, 1.45, 0.46, v, 16.5, P['ink'], 'md' if hot else 'rg', 'r', 'm')
            ln(s, x, y + 0.62, x + cw, y + 0.62, mix(P['bg'], P['mute'], 0.25), 0.6)


# ── ตารางเทียบรายขั้น ───────────────────────────────────────────────────────
@reg
def pf_table(prs, d):
    s = page(prs); _chrome(s, d)
    txt(s, M, 0.95, 7.0, 0.9, d['t'], 43, P['ink'], 'md')
    _muted(s, M, 1.88, 7.0, d.get('s', ''), 14)
    cols = d['colw']; tw = W - M * 2
    y0 = 2.55
    shp(s, 'rect', M, y0, tw, 0.54, P['ink'])
    cx = M
    for j, (hd, fr) in enumerate(zip(d['head'], cols)):
        txt(s, cx + 0.18, y0, tw * fr - 0.36, 0.54, hd, 15, 'FFFFFF', 'md',
            'l' if j == 0 else 'r', 'm')
        cx += tw * fr
    for i, row in enumerate(d['rows'][:5]):
        y = y0 + 0.54 + i * 0.56
        if i % 2 == 0: shp(s, 'rect', M, y, tw, 0.56, mix(P['bg'], P['acc'], 0.14))
        cx = M
        for j, (cell, fr) in enumerate(zip(row, cols)):
            txt(s, cx + 0.18, y, tw * fr - 0.36, 0.56, cell, 15, P['ink'],
                'md' if j == len(cols) - 1 else 'rg', 'l' if j == 0 else 'r', 'm')
            cx += tw * fr
    if d.get('note'): _muted(s, M, y0 + 0.54 + len(d['rows'][:5]) * 0.56 + 0.26, 9.0, d['note'], 13.5)


# ── สิ่งที่จะทำต่อ การ์ดสามใบ ───────────────────────────────────────────────
@reg
def pf_next(prs, d):
    s = page(prs); _chrome(s, d)
    txt(s, M, 0.95, 6.5, 0.9, d['t'], 43, P['ink'], 'md')
    _muted(s, M, 1.88, 6.8, d.get('s', ''), 14)
    cw, gap = 3.78, 0.32
    for i, (h_, body, who, when) in enumerate(d['items'][:3]):
        x = M + i * (cw + gap)
        _ycard(s, x, 2.70, cw, 3.05, adj=0.08)
        txt(s, x + 0.30, 2.95, 0.5, 0.42, f'{i + 1:02d}', 18, P['ink'], 'md')
        txt(s, x + 0.30, 3.52, cw - 0.75, 0.70, h_, 16.5, P['ink'], 'md', sp=1.3)
        _muted(s, x + 0.30, 4.32, cw - 0.75, body, 13.5, True)
        ln(s, x + 0.30, 5.18, x + cw - 0.45, 5.18, mix(P['acc'], P['ink'], 0.25), 0.7)
        txt(s, x + 0.30, 5.28, cw - 0.75, 0.30, who, 14, P['ink'], 'md')
        _muted(s, x + 0.30, 5.56, cw - 0.75, when, 13, True)


# ── หน้าคั่นบท แบบที่สอง (กฎของไอซ์: ห้ามใช้โครงซ้ำในเด็คเดียว) ─────────────
@reg
def pf_divider2(prs, d):
    s = page(prs); _chrome(s, d)
    gradband(s, 0, H - 1.80, W, 0.95, 0, c1=P['acc'], c2=P['g2'])
    txt(s, M, 1.70, 3.0, 1.9, d['num'], 54, mix(P['bg'], P['acc'], 0.80), 'md')
    ln(s, M, 3.90, W - M, 3.90, mix(P['bg'], P['mute'], 0.35), 0.8)
    txt(s, M, 4.14, 8.4, 1.0, d['t'], 51, P['ink'], 'md', sp=1.1)
    if d.get('s'): _muted(s, M, 5.02, 7.2, d['s'], 14.5)
