"""20 เลย์เอาต์ชุด Creative Agency Pitch — ลอกโครงจากเทมเพลตส้ม+ครีมที่ไอซ์ส่งมา

พื้นครีม หัวเรื่องส้ม เนื้อความดำ การ์ดสลับระหว่างครีมเข้มกับส้มทึบ
ทุกหน้ามีแถบหัวบน (Presentation Template / ชื่อชุด) และแถบส้มท้ายหน้า (เว็บไซต์ / เลขหน้า)
"""
from eng import *
import eng
from lay import L, reg

M = 0.76


def _duo():
    if P.get('dark'):
        return f"duo:{mix(P['bg'], P['acc'], 0.30)}:{mix(P['acc'], 'FFFFFF', 0.52)}"
    return f"duo:{mix(P['ink'], P['acc'], 0.38)}:{mix(P['bg'], P['acc'], 0.10)}"


def _chrome(s, d, on_acc=False):
    c = P['bg'] if on_acc else P['mute']
    txt(s, M, 0.30, 3.2, 0.26, d.get('brand', 'เทมเพลตนำเสนอ'), 9, c, 'rg')
    txt(s, 4.40, 0.30, 3.6, 0.26, d.get('kind', 'เสนองานอีเวนต์'), 9, c, 'rg')
    y = H - 0.56
    shp(s, 'rect', M, y, W - M * 2, 0.40, P['acc'])
    txt(s, M + 0.24, y, 5.0, 0.40, d.get('site', 'www.agency.co.th'), 9, P['bg'], 'rg', an='m')
    if d.get('n'):
        txt(s, W - M - 1.8, y, 1.56, 0.40, f"หน้า {int(d['n'])}", 9, P['bg'], 'rg', 'r', 'm')


def _h(s, x, y, t, sz=43, w=5.4, c=None):
    txt(s, x, y, w, 2.2, t, sz, c or P['acc'], 'md', sp=1.16)


def _p(s, x, y, w, t, sz=13.5, c=None):
    txt(s, x, y, w, 1.5, t, sz, c or mix(P['bg'], P['ink'], 0.72), 'rg', sp=1.44)


def _dots(s, x, y, n=3, r=0.17):
    """จุดกลมมีเครื่องหมายบวก แบบที่ต้นฉบับวางมุมบนซ้าย"""
    for i in range(n):
        cx = x + i * (r * 2 + 0.14)
        shp(s, 'oval', cx, y, r * 2, r * 2, P['acc'])
        ln(s, cx + r * 0.5, y + r, cx + r * 1.5, y + r, P['bg'], 1.1)
        ln(s, cx + r, y + r * 0.5, cx + r, y + r * 1.5, P['bg'], 1.1)


def _card(s, x, y, w, h, hot=False, adj=0.05):
    return shp(s, 'round', x, y, w, h, P['acc'] if hot else P['panel'], adj=adj)


def _label(t, sz, w_in):
    """(ความกว้างนิ้ว, จำนวนบรรทัด) ของป้ายที่กว้างไม่เกิน w_in วัดด้วยฟอนต์จริงผ่านตัวจัด (doc2slide.lines) ไม่มีตัวจัด = ประมาณ"""
    import sys
    D = sys.modules.get('doc2slide')
    try:
        f = D.facefile(*eng.FONTS[eng.T['font']]['md'])
        return D.widest(t, w_in, sz, f), D.lines(t, w_in, sz, f)
    except Exception:
        n = len(str(t)) * 0.082 * sz / 13
        return min(n, w_in), max(1, -int(-n // w_in))


def _ink(hot):
    return P['bg'] if hot else P['ink']


# ══ เลย์เอาต์ตามรูปอ้างอิง ═════════════════════════════════════════════════

@reg
def ag_cover(prs, d):
    s = page(prs, P['acc'])
    _chrome(s, d, True)
    _dots(s, M, 0.96)
    txt(s, M, 1.86, 9.0, 2.6, d['t'], 54, P['bg'], 'md', sp=1.08)
    _p(s, 7.30, 4.76, 5.3, d['s'], 13.5, mix(P['acc'], P['bg'], 0.72))


@reg
def ag_agenda(prs, d):
    s = page(prs)
    _chrome(s, d)
    _h(s, M, 1.20, d['t'], 43, 4.4)
    x = 5.70
    ln(s, x - 0.52, 1.00, x - 0.52, 5.10, mix(P['bg'], P['ink'], 0.18), 0.7)
    for i, (h_, body) in enumerate(d['items'][:4]):
        y = 1.06 + i * 1.08
        shp(s, 'oval', x - 0.60, y + 0.08, 0.16, 0.16, P['acc'] if i == 0 else mix(P['bg'], P['ink'], 0.26))
        txt(s, x, y, 6.0, 0.30, h_, 15, P['ink'], 'md')
        _p(s, x, y + 0.36, 6.0, body, 13)
    _p(s, M, 4.20, 4.2, d.get('note', ''), 13)


@reg
def ag_photo_cards(prs, d):
    s = page(prs)
    _chrome(s, d)
    _h(s, M, 1.30, d['t'], 36, 3.4)
    pic(s, ph(d['topic'], d.get('pi', 0)), 4.60, 0.96, W - M - 4.60, 2.10, mode=_duo())
    cw = (W - M - 4.60 - 0.36) / 3
    for i, (v, h_, body) in enumerate(d['items'][:3]):
        x = 4.60 + i * (cw + 0.18)
        hot = i == 0
        _card(s, x, 3.30, cw, 1.96, hot)
        txt(s, x + 0.26, 3.52, cw - 0.52, 0.52, v, 30, _ink(hot), 'md')
        txt(s, x + 0.26, 4.12, cw - 0.52, 0.30, h_, 13.5, _ink(hot), 'md')
        _p(s, x + 0.26, 4.46, cw - 0.52, body, 12.5,
           mix(P['acc'], P['bg'], 0.72) if hot else None)


@reg
def ag_years(prs, d):
    s = page(prs)
    _chrome(s, d)
    _h(s, M, 1.00, d['t'], 43, 4.6)
    _dots(s, M, 2.86)
    _p(s, M, 3.50, 4.4, d.get('note', ''), 13)
    spec = [(7.90, 1.16, 0.96), (9.60, 2.16, 0.96), (8.10, 3.30, 0.96)]
    for i, (it, (cx, cy, dia)) in enumerate(zip(d['items'][:3], spec)):
        yr, lab = it
        hot = i == 0
        shp(s, 'oval', cx, cy, dia, dia, P['acc'] if hot else P['panel'])
        txt(s, cx, cy + dia * 0.22, dia, 0.36, yr, 16.5, _ink(hot), 'md', 'c', 'm')
        _p(s, cx + dia + 0.24, cy + 0.26, 2.6, lab, 13)
        if i:
            px, py, pd = spec[i - 1]
            ln(s, px + pd / 2, py + pd, cx + dia / 2, cy, mix(P['bg'], P['ink'], 0.20), 0.8)


@reg
def ag_grid6(prs, d):
    s = page(prs)
    _chrome(s, d)
    _h(s, M, 1.10, d['t'], 42, 4.0)
    gx = 5.00; cw, ch = 2.22, 1.56
    for i, (h_, body) in enumerate(d['items'][:6]):
        x = gx + (i % 3) * (cw + 0.16)
        y = 0.96 + (i // 3) * (ch + 0.18)
        hot = i == 5
        _card(s, x, y, cw, ch, hot)
        txt(s, x + 0.22, y + 0.20, cw - 0.44, 0.34, f'{i + 1:02d}.', 16, _ink(hot), 'md')
        _p(s, x + 0.22, y + 0.64, cw - 0.44, body, 12.5,
           mix(P['acc'], P['bg'], 0.72) if hot else None)
    pic(s, ph(d['topic'], d.get('pi', 1)), 11.90, 0.96, W - M - 11.90, 3.30, mode=_duo())
    _p(s, M, 3.60, 3.9, d.get('note', ''), 13)


@reg
def ag_collage(prs, d):
    s = page(prs)
    _chrome(s, d)
    _h(s, M, 1.00, d['t'], 43, 5.6)
    gx, gy = M, 2.30
    cw, ch = 2.70, 1.46
    for i, it in enumerate(d['items'][:6]):
        x = gx + (i % 4) * (cw + 0.14)
        y = gy + (i // 4) * (ch + 0.16)
        if isinstance(it, tuple):
            h_, body = it
            _card(s, x, y, cw, ch, i == 0)
            txt(s, x + 0.22, y + 0.22, cw - 0.44, 0.30, h_, 13.5, _ink(i == 0), 'md')
            _p(s, x + 0.22, y + 0.58, cw - 0.44, body, 12,
               mix(P['acc'], P['bg'], 0.72) if i == 0 else None)
        else:
            pic(s, ph(d['topic'], it), x, y, cw, ch, geom='roundRect', adj=0.05, mode=_duo())


@reg
def ag_blocks3(prs, d):
    s = page(prs)
    _chrome(s, d)
    for i, (v, lab) in enumerate(d['items'][:3]):
        x = M + i * 1.90
        hot = i == 0
        h = 1.70 - i * 0.26
        _card(s, x, 1.00 + i * 0.13, 1.74, h, hot)
        txt(s, x + 0.22, 1.16 + i * 0.13, 1.4, 0.52, v, 28, _ink(hot), 'md')
        _p(s, x + 0.22, 1.74 + i * 0.13, 1.35, lab, 12,
           mix(P['acc'], P['bg'], 0.72) if hot else None)
    for i in range(3):
        cx = M + i * 0.78
        shp(s, 'round', cx, 3.30, 0.58, 0.58, P['panel'], adj=0.24)
        shp(s, 'oval', cx + 0.19, 3.49, 0.20, 0.20, P['acc'])
    _h(s, M, 4.26, d['t'], 43, 5.0)
    _p(s, 7.00, 1.10, 5.4, d['note'], 13)
    _p(s, 7.00, 3.60, 5.4, d.get('note2', ''), 13)


@reg
def ag_team4(prs, d):
    s = page(prs)
    _chrome(s, d)
    _h(s, M, 1.10, d['t'], 42, 4.0)
    _p(s, M, 3.30, 4.0, d.get('note', ''), 13)
    gx = 5.10; cw, ch = 3.60, 2.00
    for i, (name, role) in enumerate(d['items'][:4]):
        x = gx + (i % 2) * (cw + 0.22)
        y = 0.96 + (i // 2) * (ch + 0.20)
        pic(s, ph(d.get('ptopic', 'office'), d.get('pi', 2) + i), x, y, cw, ch,
            geom='roundRect', adj=0.05, focus=(0.5, 0.34), mode=_duo())
        # ป้ายชื่อบนรูป: ขอบขวาเว้นเท่าขอบซ้าย (0.18) ข้อความยาวตัดหลายบรรทัดในป้าย ป้ายโตขึ้นด้านบน (เฟส D 4 พ.ย. เดิมป้ายยาวทะลุขอบสไลด์)
        z = max(13, d.get('_big') or 0); cap = cw - 0.36
        nw, nl = _label(name, z, cap - 0.40)
        w = min(cap, nw + 0.40)
        bh = min(ch - 0.36, 0.34 if nl == 1 else 0.24 + nl * z * 1.42 / 72)
        by = y + ch - 0.18 - bh
        shp(s, 'round', x + 0.18, by, w, bh, P['acc'], adj=0.5 if nl == 1 else min(0.5, 0.17 / bh))
        if nl == 1: txt(s, x + 0.18, by, w, bh, name, 13, P['bg'], 'md', 'c', 'm')
        else: txt(s, x + 0.38, by, w - 0.40, bh, name, 13, P['bg'], 'md', 'l', 'm')
        if cap - w - 0.16 >= 1.2: _p(s, x + 0.18 + w + 0.16, y + ch - 0.50, min(1.6, cap - w - 0.16), role, 12)
        elif role: _p(s, x + 0.18, by - 0.40, cap, role, 12)


# ══ อีก 12 เลย์เอาต์ ═══════════════════════════════════════════════════════

@reg
def ag_divider(prs, d):
    s = page(prs, P['acc'])
    _chrome(s, d, True)
    _dots(s, M, 1.10)
    txt(s, M, 2.00, 2.6, 1.1, d['num'], 54, mix(P['acc'], P['bg'], 0.62), 'md')
    txt(s, M, 3.20, 8.0, 1.2, d['t'], 48, P['bg'], 'md', sp=1.14)
    if d.get('s'): _p(s, M, 4.50, 7.0, d['s'], 13.5, mix(P['acc'], P['bg'], 0.72))


@reg
def ag_photo_split(prs, d):
    s = page(prs)
    _chrome(s, d)
    pic(s, ph(d['topic'], d.get('pi', 6)), 0, 0.82, 5.70, H - 1.52, mode=_duo())
    _h(s, 6.30, 1.10, d['t'], 40, 5.8)
    for i, (h_, body) in enumerate(d['items'][:3]):
        y = 2.80 + i * 0.92
        shp(s, 'oval', 6.30, y + 0.10, 0.14, 0.14, P['acc'])
        txt(s, 6.68, y, 5.6, 0.30, h_, 14.5, P['ink'], 'md')
        _p(s, 6.68, y + 0.34, 5.6, body, 13)


@reg
def ag_steps4(prs, d):
    s = page(prs)
    _chrome(s, d)
    _h(s, M, 1.10, d['t'], 43, 4.2)
    _p(s, M, 3.40, 4.0, d.get('note', ''), 13)
    x = 5.40
    n = len(d['items'][:4])
    ln(s, x + 0.21, 1.00, x + 0.21, 1.00 + (n - 1) * 1.22 + 0.42, mix(P['bg'], P['ink'], 0.18), 0.8)
    for i, (h_, body) in enumerate(d['items'][:4]):
        y = 1.00 + i * 1.22
        shp(s, 'oval', x, y, 0.42, 0.42, P['acc'] if i < 2 else P['panel'])
        txt(s, x, y, 0.42, 0.42, f'{i + 1}', 14.5, _ink(i < 2), 'md', 'c', 'm')
        txt(s, x + 0.72, y - 0.02, 6.4, 0.32, h_, 15, P['ink'], 'md')
        _p(s, x + 0.72, y + 0.36, 6.3, body, 13)


@reg
def ag_table(prs, d):
    s = page(prs)
    _chrome(s, d)
    _h(s, M, 1.00, d['t'], 40, 8.0)
    tw = W - M * 2; cols = d['colw']; y0 = 2.40
    shp(s, 'rect', M, y0, tw, 0.54, P['acc'])
    cx = M
    for j, (hd, fr) in enumerate(zip(d['head'], cols)):
        txt(s, cx + 0.22, y0, tw * fr - 0.44, 0.54, hd, 13.5, P['bg'], 'md', 'l' if j == 0 else 'r', 'm'); cx += tw * fr
    for i, row in enumerate(d['rows'][:5]):
        y = y0 + 0.54 + i * 0.56
        if i % 2 == 0: shp(s, 'rect', M, y, tw, 0.56, P['panel'])
        cx = M
        for j, (cell, fr) in enumerate(zip(row, cols)):
            txt(s, cx + 0.22, y, tw * fr - 0.44, 0.56, cell, 13.5,
                P['acc'] if j == len(cols) - 1 else P['ink'],
                'md' if j == len(cols) - 1 else 'rg', 'l' if j == 0 else 'r', 'm'); cx += tw * fr
    if d.get('note'): _p(s, M, y0 + 0.54 + len(d['rows'][:5]) * 0.56 + 0.18, 9.6, d['note'], 12.5)


@reg
def ag_compare(prs, d):
    s = page(prs)
    _chrome(s, d)
    _h(s, M, 1.00, d['t'], 40, 8.0)
    cw = (W - M * 2 - 0.44) / 2
    for c, (ttl, rows) in enumerate(zip(d['heads'], [d['before'], d['after']])):
        x = M + c * (cw + 0.44)
        hot = c == 1
        _card(s, x, 2.46, cw, 3.00, hot, adj=0.05)
        txt(s, x + 0.30, 2.70, cw - 0.60, 0.34, ttl, 15, _ink(hot), 'md')
        for i, (lab, v) in enumerate(rows[:4]):
            y = 3.22 + i * 0.54
            txt(s, x + 0.30, y, cw - 1.70, 0.40, lab, 13, _ink(hot), 'rg', an='m')
            txt(s, x + cw - 1.50, y, 1.20, 0.40, v, 15, _ink(hot), 'md', 'r', 'm')
            ln(s, x + 0.30, y + 0.44, x + cw - 0.30, y + 0.44,
               mix(P['acc'], P['bg'], 0.34) if hot else mix(P['bg'], P['ink'], 0.14), 0.6)


@reg
def ag_pricing(prs, d):
    s = page(prs)
    _chrome(s, d)
    _h(s, M, 1.00, d['t'], 40, 8.0)
    cw = (W - M * 2 - 0.44) / 3
    for i, (name, price, unit, feats) in enumerate(d['items'][:3]):
        x = M + i * (cw + 0.22)
        hot = i == 1
        _card(s, x, 2.40, cw, 3.06, hot)
        txt(s, x + 0.30, 2.64, cw - 0.60, 0.30, name, 14, _ink(hot), 'md')
        txt(s, x + 0.30, 3.02, cw - 0.60, 0.56, price, 33, _ink(hot), 'md')
        _p(s, x + 0.30, 3.66, cw - 0.60, unit, 13, mix(P['acc'], P['bg'], 0.72) if hot else None)
        ln(s, x + 0.30, 4.06, x + cw - 0.30, 4.06,
           mix(P['acc'], P['bg'], 0.34) if hot else mix(P['bg'], P['ink'], 0.16), 0.6)
        for j, f in enumerate(feats[:3]):
            txt(s, x + 0.58, 4.18 + j * 0.36, cw - 0.88, 0.30, f, 13, _ink(hot), 'rg', an='m')
            shp(s, 'oval', x + 0.30, 4.30 + j * 0.36, 0.11, 0.11, P['bg'] if hot else P['acc'])


@reg
def ag_kpi4(prs, d):
    s = page(prs)
    _chrome(s, d)
    _h(s, M, 1.00, d['t'], 40, 8.0)
    cw = (W - M * 2 - 0.54) / 4
    for i, (v, lab, body) in enumerate(d['items'][:4]):
        x = M + i * (cw + 0.18)
        hot = i == 0
        _card(s, x, 2.46, cw, 2.60, hot)
        txt(s, x + 0.26, 2.70, cw - 0.52, 0.62, v, 33, _ink(hot), 'md')
        txt(s, x + 0.26, 3.42, cw - 0.52, 0.30, lab, 13.5, _ink(hot), 'md')
        _p(s, x + 0.26, 3.78, cw - 0.52, body, 12.5,
           mix(P['acc'], P['bg'], 0.72) if hot else None)


@reg
def ag_timeline(prs, d):
    s = page(prs)
    _chrome(s, d)
    _h(s, M, 1.00, d['t'], 40, 7.4)
    n = len(d['items'][:4]); cw = (W - M * 2) / n
    ln(s, M, 3.50, W - M, 3.50, mix(P['bg'], P['ink'], 0.18), 0.8)
    for i, (per, h_, body) in enumerate(d['items'][:4]):
        x = M + i * cw
        shp(s, 'oval', x, 3.36, 0.28, 0.28, P['acc'] if i < 2 else P['panel'])
        txt(s, x, 2.90, cw - 0.4, 0.32, per, 14.5, P['acc'] if i < 2 else P['mute'], 'md')
        txt(s, x, 3.84, cw - 0.50, 0.56, h_, 15, P['ink'], 'md', sp=1.25)
        _p(s, x, 4.54, cw - 0.52, body, 13)


@reg
def ag_quote(prs, d):
    s = page(prs, P['acc'])
    _chrome(s, d, True)
    pic(s, ph(d.get('ptopic', 'office'), d.get('pi', 7)), W - 4.40, 0.82, 4.40 - M, H - 1.52,
        geom='roundRect', adj=0.05, focus=(0.5, 0.4), mode=_duo())
    txt(s, M, 1.30, 1.2, 0.9, '"', 54, mix(P['acc'], P['bg'], 0.58), 'md')
    txt(s, M, 2.20, 7.0, 2.2, d['t'], 30, P['bg'], 'md', sp=1.3)
    ln(s, M, 4.70, M + 2.8, 4.70, mix(P['acc'], P['bg'], 0.40), 0.8)
    txt(s, M, 4.86, 5.2, 0.32, d['who'], 15, P['bg'], 'md')
    _p(s, M, 5.24, 5.2, d['role'], 13, mix(P['acc'], P['bg'], 0.72))


@reg
def ag_bars(prs, d):
    s = page(prs)
    _chrome(s, d)
    _h(s, M, 1.00, d['t'], 40, 5.0)
    _p(s, M, 3.00, 4.4, d.get('note', ''), 13)
    gx, gw = 5.60, W - M - 5.60
    n = len(d['bars'][:5]); bw = gw / n * 0.56
    base, top = 5.00, 1.10
    mx = max(v for _, v in d['bars'][:5]) or 1
    for i, (lab, v) in enumerate(d['bars'][:5]):
        cx = gx + gw / n * (i + 0.5)
        h = (base - top) * (v / mx)
        shp(s, 'round', cx - bw / 2, base - h, bw, h, P['acc'] if i == n - 1 else P['panel'], adj=0.10)
        txt(s, cx - bw / 2 - 0.3, base - h - 0.40, bw + 0.6, 0.32, str(v), 11, P['ink'], 'md', 'c')
        _p(s, cx - gw / n / 2, base + 0.14, gw / n, lab, 12.5)


@reg
def ag_next(prs, d):
    s = page(prs)
    _chrome(s, d)
    _h(s, M, 1.00, d['t'], 40, 8.0)
    cw = (W - M * 2 - 0.44) / 3
    for i, (h_, body, when) in enumerate(d['items'][:3]):
        x = M + i * (cw + 0.22)
        hot = i == 0
        _card(s, x, 2.42, cw, 2.86, hot)
        txt(s, x + 0.30, 2.66, 0.8, 0.34, f'{i + 1:02d}', 16, _ink(hot), 'md')
        txt(s, x + 0.30, 3.12, cw - 0.60, 0.60, h_, 15, _ink(hot), 'md', sp=1.25)
        _p(s, x + 0.30, 3.86, cw - 0.60, body, 13, mix(P['acc'], P['bg'], 0.72) if hot else None)
        ln(s, x + 0.30, 4.66, x + cw - 0.30, 4.66,
           mix(P['acc'], P['bg'], 0.34) if hot else mix(P['bg'], P['ink'], 0.16), 0.6)
        txt(s, x + 0.30, 4.78, cw - 0.60, 0.28, when, 13, _ink(hot), 'md')


@reg
def ag_close(prs, d):
    s = page(prs, P['acc'])
    _chrome(s, d, True)
    _dots(s, M, 1.20)
    txt(s, M, 2.10, 8.6, 2.0, d['t'], 54, P['bg'], 'md', sp=1.10)
    _p(s, M, 4.26, 6.2, d.get('note', ''), 14, mix(P['acc'], P['bg'], 0.72))
    for i, (lab, v) in enumerate(d['items'][:3]):
        x = M + i * 3.90
        _p(s, x, 5.08, 3.6, lab, 12.5, mix(P['acc'], P['bg'], 0.62))
        txt(s, x, 5.38, 3.6, 0.32, v, 14, P['bg'], 'md')
