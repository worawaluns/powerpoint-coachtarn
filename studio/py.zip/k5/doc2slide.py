# python3 doc2slide.py <ไฟล์ docx/pdf/xlsx> <เลขชุดในคลัง> [--render]
# ไฟล์เดียวกันนี้รันในเบราว์เซอร์ด้วย (Pyodide) ที่ coachtarnslide.com/doc2slide — sync ด้วย d2s_web.py
# ต้นแบบ "แปลงเอกสารเป็นสไลด์" — ไม่ใช้ AI ทุกคำบนสไลด์มาจากไฟล์ลูกค้า
#   อ่าน docx → ตัดเป็นหัวข้อ → ดูรูปทรงเนื้อหา
#   → เลือกจาก layout ของ "ชุดที่ลูกค้าเลือก" เท่านั้น (ดีไซน์ สี ฟอนต์ ภาพ ของชุดนั้นทั้งหมด)
#   → วาด layout จริงลงไฟล์ทดลองแล้ววัดกรอบ ล้นก็เปลี่ยนตัว
#   → เขียนเด็คลง d2s/<ชื่อ>.py (META ของชุดนั้น + SEQ ใหม่) แล้วส่งให้ mk.py สร้าง .pptx
#
# layout ของชุดรับเนื้อหารูปทรงไหน อ่านจากตัวอย่างใน SEQ ของชุดนั้นเอง (decks/*.py)
# ponytail: ได้เฉพาะ 161 ชุดที่มีไฟล์ใน decks/ ชุดเก่าที่มีแต่ .pptx ต้องเขียนตัวเติมอีกแบบ
import sys, os, re, io, ast, glob, json, inspect, importlib, importlib.util, unicodedata, subprocess, pprint
K = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, K); os.chdir(K)
import eng, lay, base, lay_cov3
for f in sorted(glob.glob(f'{K}/lay_*.py')):           # ลงทะเบียนเลย์เอาต์เฉพาะชุดทั้งหมดเข้า lay.L เหมือน mk.py
    importlib.import_module(os.path.basename(f)[:-3])
HUB = os.path.expanduser('~/doublecraft-hub/projects/apps/powerpoint-coachtarn')
WEB = os.path.exists(f'{K}/fonts.json')                  # บนเว็บไม่มี fc-match ใช้แผนที่ฟอนต์ที่ d2s_web.py เขียนไว้
ICONS = {f.rsplit('.', 1)[0] for f in os.listdir(f'{K}/../kit/icons')}
# ชื่อหมวดรูป เช่น d.get('ptopic', 'office') ห้ามล้าง  บนเว็บโหลดรูปแค่บางหมวด เลยอ่านรายชื่อจากไฟล์
TOPICS = set(json.load(open(f'{K}/topics.json'))) if os.path.exists(f'{K}/topics.json') else set(os.listdir(eng.IMG))
SRC = {n: inspect.getsource(f) for n, f in lay.L.items()}
REQ = {n: set(re.findall(r"d\['(\w+)'\]", s)) - set(re.findall(r"d\.get\('(\w+)'", s)) for n, s in SRC.items()}
# ข้อความตั้งต้นที่ซ่อนอยู่ใน layout เช่น d.get('_l', 'ข้อเสนอบริการ ปี 2570') ของชุด 377
# ไม่ล้างทิ้ง ชื่อบริษัทสมมติของชุดจะไปโผล่บนสไลด์ลูกค้า
_MOD = {}
def _modsrc(n):
    m = sys.modules[lay.L[n].__module__]
    if m not in _MOD: _MOD[m] = inspect.getsource(m)
    return _MOD[m]
TXTDEF = {n: {k for k, v in re.findall(r"d\.get\('(\w+)',\s*'([^']*)'\)", s + _modsrc(n))
              if re.search(r'[A-Za-z\u0E00-\u0E7F]', v) and '{' not in v and v not in ICONS and v not in TOPICS} - {'topic', 'foot', 'n'}
          for n, s in SRC.items()}
ALLOW = {'สารบัญ'}                                         # คำเดียวที่ระบบเติมเอง
CAP = {n: int(m.group(1)) for n, s in SRC.items() for m in [re.search(r"d\['items'\]\[:(\d+)\]", s)] if m}
ROWCAP = {n: int(m.group(1)) for n, s in SRC.items() for m in [re.search(r"d\['rows'\]\[:(\d+)\]", s)] if m}   # ตารางที่วาดได้ไม่ครบทุกแถว

# ══ 1. อ่านไฟล์ → blocks ═══════════════════════════════════════════════════
# block = ('h', ระดับ, ข้อความ) | ('li', ข้อความ, มีเลขข้อ) | ('p', ข้อความ) | ('table', [[ช่อง...]])

def clean(t):
    """ตัดสัญลักษณ์นำหน้า (• - ✨) กับอีโมจิทิ้ง ฟอนต์ไทยในคลังไม่มีอีโมจิ ขึ้นเป็นกล่องเปล่า
    คำทุกคำยังอยู่ครบ ตัดแค่สัญลักษณ์ตกแต่ง"""
    t = ''.join(c for c in t if unicodedata.category(c) != 'So')
    return re.sub(r'^[\s•\-–*·]+', '', t).strip()

def read_docx(path):
    import docx
    from docx.table import Table
    from docx.text.paragraph import Paragraph
    d = docx.Document(path); out = []
    for el in d.element.body.iterchildren():           # เดินตามลำดับจริง ตารางแทรกกลางย่อหน้าได้
        tag = el.tag.rsplit('}', 1)[-1]
        if tag == 'tbl':
            rows = [[clean(c.text) for c in r.cells] for r in Table(el, d).rows]
            if rows: out.append(('table', rows))
            continue
        if tag != 'p': continue
        p = Paragraph(el, d); st = p.style.name.lower(); raw = p.text
        if not raw.strip(): continue
        m = re.match(r'(heading|หัวเรื่อง)\s*(\d)', st)
        if m or st == 'title':
            out.append(('h', int(m.group(2)) if m else 0, clean(raw))); continue
        numbered = 'number' in st or (p._p.pPr is not None and p._p.pPr.numPr is not None and 'bullet' not in st)
        if 'list' in st or numbered:
            out.append(('li', clean(raw), numbered)); continue
        for x in [x for x in raw.split('\n') if x.strip()]:   # ย่อหน้าที่พิมพ์ • หรือ 1. เองทีละบรรทัด
            if re.match(r'\s*[•\-–*·]\s', x): out.append(('li', clean(x), False))
            elif re.match(r'\s*\d{1,2}[.)]\s', x): out.append(('li', re.sub(r'^\s*\d{1,2}[.)]\s*', '', x).strip(), True))
            else: out.append(('p', clean(x)))
    return out

def read_pdf(path):
    """PDF ไม่มี style บอกหัวข้อ ดูจากขนาดตัวอักษร: ใหญ่กว่าเนื้อความชัด ๆ = หัวข้อ ใหญ่สุด = ชื่อเรื่อง
    ponytail: ไม่แกะตารางใน PDF ตารางจะออกมาเป็นบรรทัดข้อความ"""
    from pypdf import PdfReader
    lines_ = []                                           # (ขนาดฟอนต์, ข้อความ)
    for pg in PdfReader(path).pages:
        cur = {'sz': 0, 't': '', 'y': None}
        def vis(text, cm, tm, fd, fs):
            # ตำแหน่ง/ขนาดจริง = tm x cm  บรรทัดใหม่เมื่อ y เปลี่ยน (PDF จาก Chrome/Word ไม่ใส่ \n ให้)
            a_, b_ = tm[0] * cm[0] + tm[1] * cm[2], tm[0] * cm[1] + tm[1] * cm[3]
            y = tm[4] * cm[1] + tm[5] * cm[3] + cm[5]
            sz = round(abs(fs) * ((a_ * a_ + b_ * b_) ** 0.5 or 1), 1)
            if cur['y'] is not None and abs(y - cur['y']) > max(sz, 4) * 0.5 and cur['t'].strip():
                lines_.append((cur['sz'], cur['t'])); cur['t'] = ''; cur['sz'] = 0
            for i, part in enumerate(text.split('\n')):
                if i and cur['t'].strip(): lines_.append((cur['sz'], cur['t'])); cur['t'] = ''; cur['sz'] = 0
                if part.strip(): cur['t'] += part; cur['sz'] = max(cur['sz'], sz); cur['y'] = y
        pg.extract_text(visitor_text=vis)
        lines_.append((cur['sz'], cur['t']))
    # pypdf เติมช่องว่างหน้าสระ/วรรณยุกต์/จุดของคำย่อไทย ("ป .1" "พ . ค .") คืนให้ติดกันเหมือนต้นฉบับ
    lines_ = [(z, re.sub(r'(?<=[\u0E00-\u0E7F])\s+(?=[.\u0E31\u0E33-\u0E3A\u0E47-\u0E4E])', '', t)) for z, t in lines_]
    lines_ = [(z, re.sub(r'(?<=[\u0E01-\u0E2E]\.)\s+(?=[\u0E01-\u0E2E]\.)', '', t)) for z, t in lines_]
    lines_ = [(z, t.replace('\u0e4d\u0e32', '\u0e33').strip()) for z, t in lines_ if t.strip()]   # ํา → ำ
    if not lines_: return []
    # PDF ไทยหลายไฟล์ฝังฟอนต์แบบไม่มีตารางแปลงกลับเป็นตัวอักษร สระบน/วรรณยุกต์หายเป็นช่องว่างหรือ \x00
    # เอาขึ้นสไลด์แล้วดูพังทันที บอกลูกค้าตรง ๆ ดีกว่า
    allt = ' '.join(t for _, t in lines_)
    thai = len(re.findall(r'[\u0E01-\u0E2E]', allt))
    broken = allt.count('\x00') + len(re.findall(r'[\u0E01-\u0E2E] (?=[\u0E01-\u0E2E]{1,2}(?: |$))', allt))
    if thai and broken / thai > 0.02:
        raise ValueError('PDF นี้เก็บตัวอักษรไทยไว้ไม่ครบ (สระหรือวรรณยุกต์หาย) ใช้ไฟล์ Word (.docx) ต้นฉบับแทนจะได้ข้อความถูกต้อง')
    body = sorted(z for z, _ in lines_)[len(lines_) // 2]
    # ตัวเลขล้วน (เลขขั้นตอนตัวโต เลขหน้า) ไม่ใช่หัวข้อ ทิ้งไปเลย
    lines_ = [(z, t) for z, t in lines_ if re.search(r'[A-Za-z\u0E01-\u0E2E]', t)]
    if not lines_: return []
    big = sorted({z for z, t in lines_ if z >= body * 1.18 and len(t) <= 90}, reverse=True)
    lvl = {z: min(i + 1, 3) for i, z in enumerate(big)}
    out = []
    full = sorted(len(t) for _, t in lines_)[int(len(lines_) * 0.9)]   # ความยาวบรรทัดเต็มแถวโดยประมาณ
    prev_full = False
    for z, t in lines_:
        if z in lvl: out.append(('h', lvl[z], clean(t)))
        elif re.match(r'\s*[•\-–*·▪●○]\s*', t): out.append(('li', clean(t), False))
        elif re.match(r'\s*\d{1,2}[.)]\s', t): out.append(('li', re.sub(r'^\s*\d{1,2}[.)]\s*', '', t).strip(), True))
        elif out and out[-1][0] == 'p' and prev_full and not re.search(r'[.!?:]$', out[-1][1]):
            out[-1] = ('p', out[-1][1] + ' ' + clean(t))  # บรรทัดที่ PDF ตัดกลางย่อหน้า ต่อกลับเป็นย่อหน้าเดียว
        else: out.append(('p', clean(t)))
        prev_full = len(t) >= full * 0.85                  # บรรทัดยาวเต็มแถว = ย่อหน้ายังไม่จบ
    return out

def xl_text(v, fmt):
    """ตัวเลขตามที่เซลล์แสดง: ทศนิยมตามรูปแบบเซลล์ เปอร์เซ็นต์ยังเป็นเปอร์เซ็นต์ ไม่ปัดเองถ้าเซลล์ไม่ได้ปัด
    ponytail: อ่านแค่จำนวนทศนิยม/%/ตัวคั่นหลักพันจากรูปแบบ สัญลักษณ์เงินในรูปแบบเซลล์ไม่ใส่ให้"""
    if v is None: return ''
    if isinstance(v, bool) or not isinstance(v, (int, float)): return str(v).strip()
    f = re.sub(r'"[^"]*"|\[[^\]]*\]|\\.', '', (fmt or 'General').split(';')[0])
    m = re.search(r'\.(0+)', f); d = len(m.group(1)) if m else 0
    if '%' in f: return f'{v * 100:,.{d}f}%'
    if m or re.search(r'[0#]', f): return f'{v:,.{d}f}'
    return f'{v:.0f}' if float(v).is_integer() else format(v, '.10g')      # General: เหมือนเซลล์ ไม่มีตัวคั่นหลักพัน ทศนิยมเท่าที่พิมพ์

def read_xlsx(path):
    """แต่ละชีต = หนึ่งหัวข้อ เป็นตารางหนึ่งตาราง ชื่อชีตเป็นหัวข้อ"""
    import openpyxl
    wb = openpyxl.load_workbook(path, data_only=True, read_only=True); out = []
    for ws in wb.worksheets:
        rows = []
        for r in ws.iter_rows(max_col=8):                      # ponytail: 8 คอลัมน์ 9 แถวแรก (หัว+8) ไฟล์ 5,000 แถวไม่ต้องอ่านทั้งหมด
            if len(rows) >= 9: break
            cells = [xl_text(c.value, getattr(c, 'number_format', 'General')) for c in r]
            while cells and not cells[-1]: cells.pop()
            if any(cells): rows.append(cells)
        if not rows: continue
        w = max(len(r) for r in rows)
        out += [('h', 2, ws.title), ('table', [r + [''] * (w - len(r)) for r in rows])]
        if (ws.max_row or 0) > 9 or (ws.max_column or 0) > 8: NOTES.append(f'ชีต "{ws.title}" ใช้หัวตารางกับ 8 แถวแรก และ 8 คอลัมน์แรก ส่วนที่เหลือของชีตยังไม่ได้ทำเป็นสไลด์')
    return out

NOTES = []                                                 # สิ่งที่ระบบตัดทิ้ง ต้องบอกลูกค้าตรง ๆ
INFO = {}                                                  # สิ่งที่อ่านได้จริง (จำนวนหัวข้อที่มีชื่อ) ให้แชทพูดตรงกับที่เจอ
MAXSLIDES = 30                                             # มือถือรับไม่ไหวถ้าเกินนี้ (คำนวณ + พรีวิว)

MARK = r'\s*((วาระ(ที่)?|หัวข้อ(ที่)?|ส่วน(ที่)?|บท(ที่)?|ตอน(ที่)?|ภาค(ที่)?|เรื่อง(ที่)?|ข้อ(ที่)?)\s*\d{1,2}(\.\d+)?\b|\d{1,2}[.)](?=\s))'

LABEL_RE = re.compile(r'(เงื่อนไข|หมายเหตุ|ข้อเสนอแนะ|ข้อสังเกต|สรุป)\s+')   # คำป้ายหัวข้อสั้นที่ขึ้นต้นบรรทัดแล้วตามด้วยเนื้อ

def headsplit(l):
    """บรรทัดที่ขึ้นต้นด้วยเครื่องหมายหัวข้อ → (ชื่อหัวข้อ, ข้อที่เหลือ)  ชื่อ = เครื่องหมาย + วลีแรก (ถึงรอยต่อความ ก่อนตัวเลข)
    คำทั้งหมดเป็นของลูกค้า ไม่เติมคำ"""
    mk = re.match(MARK, l); rest = clean(l[mk.end():]).strip(); cl = clauses(rest)
    head = cl[0] if cl else ''
    ws = head.split(' ')                                   # ตัดก่อนจำนวน (350,000 บาท) แต่ไม่ตัดเลขลำดับ (ครั้งที่ 2)
    qty = lambda n: re.search(r'\d[\d,]*(\.\d+)?%?$', ws[n]) and (re.search(r'[,%]', ws[n]) or (n + 1 < len(ws) and re.match(UNIT, ws[n + 1])))
    k = next((n for n, w in enumerate(ws) if n and qty(n) and not ws[n - 1].endswith('ที่')), len(ws))   # ตัดก่อนจำนวนเงิน/จำนวนนับเท่านั้น
    head, tail = ' '.join(ws[:k]), ' '.join(ws[k:])
    if len(head) > 40:                                     # วลีแรกยาวเกินหัวข้อ: ถึงเว้นวรรคแรกหลัง 6 ตัว
        nounish = lambda x: (wordsx(x) or [''])[0] in ('ชั้น', 'ระดับ', 'จำนวน', 'ให้')   # ต้นข้อได้ (ชั้น ป.1 / ให้นำ...) ไม่ใช่คำเชื่อมท้ายหัวข้อ
        sp_ = next((m.start() for m in re.finditer(' ', head) if m.start() >= 6 and not head[:m.start()].endswith('ที่')
                    and (not cont(head[m.start() + 1:]) or nounish(head[m.start() + 1:]))
                    and (words(head[:m.start()].split(' ')[-1]) or [''])[-1] not in TAIL | {'ชั้น', 'ระดับ'}
                    and not re.search(r'\d', head[m.start() + 1:].split(' ')[0])), None)   # ไม่จบหัวข้อด้วยคำเชื่อม/ลักษณนาม ไม่แยก "ชั้น ป.1"   # ไม่ตัดเลขลำดับออกจาก "ครั้งที่" ไม่ตัดหน้าคำเชื่อม
        if sp_: tail = (head[sp_ + 1:] + ' ' + tail).strip(); head = head[:sp_]
    marker = l[:mk.end()].strip()
    rest = ' '.join(x for x in [tail] + cl[1:] if x)
    return (marker + ' ' + head).strip(), rest

def read_txt(path):
    """ข้อความที่ลูกค้าพิมพ์/วางในช่องแชท อ่านโครงแบบทั่วไป ไม่ผูกกับเอกสารตัวอย่าง:
    บรรทัดแรก = ชื่อเรื่อง (ถ้าตามด้วยบรรทัดอื่น) / หัวข้อ = บรรทัดที่ขึ้นต้นด้วย วาระที่ N, ข้อ N, N., N), เลขไทย ๑-๙
    หรือบรรทัดสั้น (≤40 ตัว) ที่ตามด้วยบรรทัดยาวกว่า / ในหัวข้อ แต่ละบรรทัดคือหนึ่งข้อ บรรทัดยาวแบ่งที่ท้ายประโยคหรือก่อนคำขึ้นเรื่อง
    รองรับ # หัวข้อ, - • * รายการ, ตาราง (คั่นด้วย tab หรือ |)"""
    L = [l.rstrip() for l in open(path, encoding='utf-8').read().replace('\r', '').split('\n')]
    bullet = lambda l: re.match(r'\s*[•\-–*·▪●○]\s+\S', l)
    numl = lambda l: re.match(r'\s*\d{1,2}[.)]\s+\S', l)
    out, i, first, prev_num = [], 0, True, False
    # ระดับหัวข้อ: ใช้เครื่องหมายระดับสูงสุดที่มีในเอกสารเป็นหัวข้อ ระดับรองลงไปเป็นข้อ (๑. เป็นหัวข้อ ข้อ 1) เป็นข้อ)
    def mkind(l):
        m = re.match(MARK, l)
        if not m: return None
        g = m.group(0).strip()
        if re.match(r'(วาระ|หัวข้อ|ส่วน|บท|ตอน|ภาค|เรื่อง)', g): return 0
        if re.match(r'[๐-๙]', g): return 1
        if re.match(r'\d{1,2}\.', g): return 2
        if g.startswith('ข้อ'): return 3
        return 4                                           # N)
    kinds = [k for k in (mkind(x.strip()) for x in L if x.strip()) if k is not None]
    top = min(kinds) if kinds else None
    explicit = top is not None
    def points_of(t):                                      # บรรทัดยาวในหัวข้อ → หลายข้อ (ท้ายประโยค/คำขึ้นเรื่อง)
        for x in points(t): out.append(('li', x, False))
    while i < len(L):
        l = L[i].strip()
        if not l: i += 1; continue
        cells = [c.strip() for c in re.split(r'\t|\s*\|\s*', l.strip('|'))] if ('\t' in l or l.count('|') >= 2) else None
        if cells and len(cells) >= 2:                 # ตาราง: เก็บแถวติดกันที่จำนวนช่องเท่ากัน
            rows = []
            while i < len(L) and L[i].strip() and ('\t' in L[i] or L[i].count('|') >= 2):
                r = [c.strip() for c in re.split(r'\t|\s*\|\s*', L[i].strip().strip('|'))]
                if not all(re.fullmatch(r':?-{2,}:?', c) for c in r if c): rows.append(r)   # ข้ามเส้นคั่นของ markdown
                i += 1
            w = max(len(r) for r in rows); out.append(('table', [r + [''] * (w - len(r)) for r in rows])); first = False; continue
        nx_ = [x.strip() for x in L[i + 1:] if x.strip()][:2] + ['', '']
        nxt, nxt2 = nx_[0], nx_[1]
        is_num = bool(numl(l))
        list_num = is_num and (prev_num or (nxt and numl(nxt) and len(l) <= 70))   # 1. 2. 3. ติดกันสั้น ๆ = รายการมีเลข ไม่ใช่หัวข้อ
        if l.startswith('#'):
            lv = min(len(l) - len(l.lstrip('#')), 3); out.append(('h', lv, clean(l.lstrip('#')))); first = False
        elif first and not bullet(l) and not re.match(MARK, l) and len(l) <= 90 and nxt:
            out.append(('h', 1, clean(l))); first = False     # บรรทัดแรก = ชื่อเรื่อง
        elif re.match(MARK, l) and not list_num and mkind(l) == top:
            head, rest = headsplit(l); out.append(('h', 2, head)); first = False
            if rest: points_of(rest)
        elif re.match(MARK, l) and mkind(l) != top:
            out.append(('li', clean(l), True)); first = False   # เครื่องหมายระดับรอง (ข้อ 1)) = ข้อในหัวข้อ
        elif bullet(l) or is_num:
            txt = re.sub(r'^\s*([•\-–*·▪●○]|\d{1,2}[.)])\s+', '', l)
            if is_num and nxt and bullet(nxt):           # "1. หัวข้อ" ตามด้วยรายการ = หัวข้อ
                out.append(('h', 2, clean(txt)))
            else: out.append(('li', clean(txt), is_num))
            first = False
        elif len(l) <= 60 and not re.search(r'[.!?]$', l) and not re.search(r'\d', l) and nxt and \
                (bullet(nxt) or (numl(nxt) and (mkind(nxt) != top or (numl(nxt2) and len(nxt) <= 70))) or ('\t' in nxt or nxt.count('|') >= 2)):
            out.append(('h', 2, clean(l.rstrip(':：')))); first = False   # บรรทัดสั้นที่ตามด้วยรายการ (รวม 1. 2. ติดกันสั้น ๆ) หรือตาราง = หัวข้อ
        elif re.fullmatch(r'.{1,60}[:：]', l):
            out.append(('h', 2, clean(l.rstrip(':：')))); first = False
        elif LABEL_RE.match(l) and len(l) > LABEL_RE.match(l).end() + 8:
            m_ = LABEL_RE.match(l); out.append(('h', 2, m_.group(1))); first = False   # "เงื่อนไข ส่งมอบ..." = หัวข้อ + เนื้อ
            points_of(clean(l[m_.end():]))
        elif not explicit and len(l) <= 40 and not re.match(r'\s*(\d|รวม|ยอดรวม|เรียน |ขอแสดงความนับถือ|ลงชื่อ)', l) and not re.search(r'(ดังนี้|บาท|[.!?%:])$', l) and nxt and len(nxt) > len(l) + 10 and not re.match(MARK, nxt) \
                and not (out and out[-1][0] in ('p', 'li') and any(b[0] == 'h' for b in out) and re.search(r'\d', l)):   # ข้อในรายการที่กำลังดำเนิน (มีตัวเลข) ไม่ขึ้นหัวข้อใหม่
            out.append(('h', 2, clean(l))); first = False    # บรรทัดสั้นที่ตามด้วยบรรทัดยาวกว่า = หัวข้อ
        elif len(l) > 140 and not (first and not nxt): points_of(clean(l)); first = False   # บรรทัดเดียวทั้งเอกสาร: ให้โหมดย่อหน้าเดียวจัด
        else: out.append(('p', clean(l))); first = False
        prev_num = is_num
        i += 1
    return out

def read_any(path):
    NOTES.clear()
    ext = path.lower().rsplit('.', 1)[-1]
    return {'docx': read_docx, 'pdf': read_pdf, 'xlsx': read_xlsx, 'txt': read_txt}[ext](path)

def source_text(path):
    """ข้อความทั้งหมดในไฟล์ลูกค้า ไว้ตรวจว่าทุกคำบนสไลด์มาจากไฟล์นี้"""
    return re.sub(r'\s+', '', ' '.join(b[2] if b[0] == 'h' else (' '.join(' '.join(r) for r in b[1]) if b[0] == 'table' else b[1])
                                     for b in read_any(path)))

# ══ 2. ตัดเป็นหัวข้อ ═══════════════════════════════════════════════════════

def sections(blocks):
    """หัวเรื่องระดับบนสุดที่มีอันเดียว = ชื่อเด็ค, ระดับถัดมา = หนึ่งหัวข้อ, ลึกกว่านั้น = กลุ่มย่อย"""
    lv = sorted({b[1] for b in blocks if b[0] == 'h'})
    title, top = None, lv[0] if lv else 9
    if len(lv) > 1 and sum(1 for b in blocks if b[0] == 'h' and b[1] == lv[0]) == 1:
        top = lv[1]
    elif len(lv) == 1 and blocks and blocks[0][0] == 'h' and sum(1 for b in blocks if b[0] == 'h') == 1:
        top = lv[0] + 1                                    # หัวเรื่องเดียวบรรทัดแรก = ชื่อเรื่อง (ไม่ใช่หัวข้อเดียวของทั้งเอกสาร)
    secs = []
    for b in blocks:
        if b[0] == 'h' and b[1] < top: title = title or b[2]; continue
        if b[0] == 'h' and b[1] == top:
            num = re.match(r'^(\d{1,2})[.)]\s+', b[2])
            secs.append(dict(t=b[2][num.end():] if num else b[2], num=num.group(1) if num else '', body=[]))
            continue
        if not secs: secs.append(dict(t='', num='', body=[]))
        secs[-1]['body'].append(b)
    return title, [s for s in secs if s['t'] or s['body']]

# ══ 3. ดูรูปทรงเนื้อหา (ยังไม่เกี่ยวกับ layout) ═══════════════════════════════
# หนึ่งแผ่น = dict(kind, t, items/...)  kind: divider statement list pairs qa stat timeline table chart compare

NUM = r'[\d][\d,\.]*\s*(?:%|฿|บาท|คน|ราย|ครั้ง|วัน|เดือน|ปี|ชั่วโมง|หน้า|ล้าน|แห่ง|โรงเรียน|ชิ้น|\+)'
DATE = (r'(พ\.ศ\.|ค\.ศ\.|\b25[5-9]\d\b|\b20[2-4]\d\b|(?:ม\.ค|ก\.พ|มี\.ค|เม\.ย|พ\.ค|มิ\.ย|ก\.ค|ส\.ค|ก\.ย|ต\.ค|พ\.ย|ธ\.ค)\.'
        r'|มกราคม|กุมภาพันธ์|มีนาคม|เมษายน|พฤษภาคม|มิถุนายน|กรกฎาคม|สิงหาคม|กันยายน|ตุลาคม|พฤศจิกายน|ธันวาคม|ไตรมาส)')

def pair(t):
    """'หัว: เนื้อ' หรือ 'Q: ...\\nA: ...' → (ชนิด, หัว, เนื้อ)  ไม่ใช่คู่ → None"""
    qa = re.match(r'\s*Q\s*[:.]\s*(.+?)\s*\n\s*A\s*[:.]\s*(.+)', t, re.S)
    if qa: return ('qa', qa.group(1).strip(), qa.group(2).strip())
    m = re.match(r'([^:：\n]{1,40}?)\s*[:：]\s+(.+)', t, re.S)
    if m and not re.match(r'https?$', m.group(1)): return ('kv', m.group(1).strip(), m.group(2).strip())
    return None

def isnum(c): return bool(re.fullmatch(r'-?[\d,]+(\.\d+)?%?', c.replace(' ', '')))
def tonum(c):
    v = float(c.replace(',', '').replace('%', '').replace(' ', ''))
    return int(v) if v.is_integer() else v               # 220 ไม่ใช่ 220.0 บนกราฟ

def xlfmt(c):
    """ตัวเลขตามที่เซลล์/ลูกค้าแสดง → รูปแบบตัวเลข Excel ของกราฟ (1,234 → #,##0 / 12.5% → 0.0"%" / 120000 → 0)"""
    c = c.replace(' ', ''); m = re.search(r'\.(\d+)', c)
    return ('#,##0' if ',' in c else '0') + ('.' + '0' * len(m.group(1)) if m else '') + ('"%"' if c.endswith('%') else '')

PERIOD = DATE + r'|\bQ[1-4]\b|\bH[12]\b|ครึ่งปี|ก่อน|หลัง|เป้า|แผน|จริง|ปีนี้|ปีที่แล้ว|ปีก่อน|เดือนนี้|เดือนก่อน|เดิม|ใหม่|รุ่น|เวอร์ชัน|\bv\d|รอบ|ครั้งที่|งวด|สัปดาห์'
def periodish(h):
    """หัวคอลัมน์ที่เป็นช่วงเวลา/รุ่น/เป้า-จริง ของค่าเดียวกัน (ปี 2568, Q1, ก่อน/หลัง) → ห้ามซ้อนแท่ง"""
    return bool(re.search(PERIOD, h, re.I))

def mixedcol(cells):
    """คอลัมน์ตัวเลขที่ทำกราฟไม่ได้: หน่วยปน (% กับเลขเปล่า) หรือค่าห่างกันเกิน 40 เท่า (ไม่นับ 0) แท่งเล็กสุดต่ำกว่า 2.5% ของแท่งใหญ่สุด แบนเป็นเส้น
    (เดิม 10 เท่า ซ่อนกราฟที่อ่านได้จริง เช่น 5,000 กับ 80,000 — slide-judge 29 ต.ค. 2569) / หลายชุดยังใช้กฎ 10 เท่าเทียบค่าสูงสุดของแต่ละชุดแยกต่างหาก"""
    if len({c.strip().endswith('%') for c in cells}) > 1: return True
    v = [abs(tonum(c)) for c in cells if tonum(c)]
    return bool(v) and max(v) / min(v) > 40

def chunk(xs, n=5):
    """เกิน n ข้อตัดเป็นหลายแผ่น แบ่งให้เท่ากัน (8 → 4+4 ไม่ใช่ 5+3)"""
    if len(xs) <= n: return [xs]
    k = -(-len(xs) // n); m = -(-len(xs) // k)
    return [xs[i:i + m] for i in range(0, len(xs), m)]

def shapes(sec):
    t, body = sec['t'], sec['body']
    lis = [b for b in body if b[0] == 'li']; ps = [b[1] for b in body if b[0] == 'p']
    tables = [b[1] for b in body if b[0] == 'table']; subs = [b for b in body if b[0] == 'h']
    note = ' '.join(ps)

    if tables and (len(note) > 80 or len(ps) > 1):      # ตารางที่มีคำอธิบายยาว: ตารางอยู่หน้าของตัวเอง คำอธิบายเป็นรายการหน้าถัดไป (ไม่ปนในการ์ดแถว)
        rest = [x for p_ in ps for x in points(p_)]
        return shapes(dict(sec, body=[b for b in body if b[0] != 'p'])) + \
            [dict(kind='list', t=t, ordered=False, note='', items=[(x,) for x in part]) for part in gchunk(rest)]
    if tables:
        head, data = tables[0][0], tables[0][1:]
        numcols = [j for j in range(1, len(head)) if data and all(len(r) > j and isnum(r[j]) for r in data)]
        if numcols and 2 <= len(data) <= 8:
            ser = [(head[j], [tonum(r[j]) for r in data]) for j in numcols]
            nf = [[xlfmt(r[j]) for r in data] for j in numcols]   # รูปแบบตัวเลขตามเซลล์ต้นทาง ลงป้ายบนกราฟและชีตฝัง
            cats = [r[0] for r in data]
            if len(numcols) == 1:
                j = numcols[0]; v = ser[0][1]
                if mixedcol([r[j] for r in data]): return [dict(kind='table', t=t, note=note, head=head, rows=data)]   # ค่าปนหน่วย/ขนาดห่างเกิน 40 เท่า (12.345 / 12.5% / 1,250,000) เทียบความสูงแท่งไม่ได้
                # สัดส่วนของทั้งก้อน: ทุกช่องเป็น % รวมได้ 100 (ปัดเศษ ±1) ไม่มีค่าติดลบ → โดนัทได้ (ชุดที่มี)
                share = len(data) <= 6 and all(r[j].strip().endswith('%') for r in data) and abs(sum(v) - 100) <= 1 and min(v) > 0
                return [dict(kind='chart', t=t, s=head[j], note=note, head=head, rows=data, cats=cats, vals=v, series=ser,
                             _nf=nf, _col=j, **({'_share': 1} if share else {}))]
            # หลายชุดข้อมูล: ทุกคอลัมน์ (นอกจากป้าย) เป็นตัวเลข หน่วยเดียวกัน (% ทั้งหมดหรือไม่มีเลย) ขนาดใกล้กัน (ไม่เกิน 10 เท่า)
            # ไม่งั้นเป็นตาราง (พนักงาน 12 คน กับยอด 540,000 บาท ในกราฟเดียวกันอ่านไม่ได้ / ห้ามทิ้งคอลัมน์ข้อความ)
            mx = [max(abs(x) for x in vs) or 1 for _, vs in ser]
            pct = {all(r[j].strip().endswith('%') for r in data) for j in numcols}
            if numcols == list(range(1, len(head))) and len(numcols) <= 3 and len(pct) == 1 and max(mx) / min(mx) <= 10 \
                    and not any(len({r[j].strip().endswith('%') for r in data}) > 1 for j in numcols):
                # แท่งซ้อนได้เฉพาะคอลัมน์ที่เป็นส่วนของก้อนเดียวกัน (ค่าเช่า + ค่าแรง = ต้นทุนรวม): หัวข้อมีคำ รวม/แยกตาม/ประกอบ
                # หัวคอลัมน์เป็นช่วงเวลา/รุ่น (ปี 2568 กับ 2569, เป้า/จริง, ก่อน/หลัง) ห้ามซ้อน ผลรวมไม่มีความหมาย / ไม่แน่ใจ = ไม่ซ้อน (แท่งคู่)
                part = re.search(r'รวม|ทั้งหมด|แยกตาม|ประกอบ', f'{t} {note} {head[0]}') and not any(periodish(head[j]) for j in numcols)
                return [dict(kind='chart', t=t, note=note, head=head, rows=data, cats=cats, series=ser, _nf=nf, **({'_stack': 1} if part else {}))]
        return [dict(kind='table', t=t, note=note, head=head, rows=data)]

    if len(subs) == 2:                                   # สองกลุ่มย่อย = เทียบกัน
        groups, cur = [], None
        for b in body:
            if b[0] == 'h': cur = [b[2], []]; groups.append(cur)
            elif cur and b[0] in ('li', 'p'): cur[1].append(b[1])
        return [dict(kind='compare', t=t, items=[(g[0], g[1]) for g in groups])]

    if lis and ps and len(note) <= 60: lis = lis + [('li', x, False) for x in ps]; note = ''   # บรรทัดปิดสั้น ๆ (เลิกประชุมเวลา...) อยู่ในเนื้อ ไม่ใช่หมายเหตุตัวจิ๋ว
    texts = [b[1] for b in lis] if lis else (ps if len(ps) > 1 else [])
    if not lis: note = ''                                  # ย่อหน้ากลายเป็นข้อไปแล้ว อย่าซ้ำเป็นหมายเหตุ
    lead = []
    while len(texts) >= 3 and (texts[0].startswith('เรียน ') or re.search(r'ดังนี้\s*:?$', texts[0])):
        lead.append(texts.pop(0))                          # คำขึ้นต้นจดหมาย / "ขอเสนอราคาดังนี้" = ข้อความนำ ไม่ใช่ข้อหรือหัวข้อ
    if lead: note = ' '.join(lead + ([note] if note else [])); sec['_lead'] = 1
    if len(texts) >= 3 and re.match(r'(รวมทั้งสิ้น|รวมเป็นเงิน|รวมทั้งหมด|ยอดรวม)\s*\d', texts[-1]):
        note = (note + ' ' + texts.pop()).strip(); sec['_lead'] = 1; sec['_leadend'] = 1   # ยอดรวมท้ายรายการ = ยอดปิด ไม่ใช่ข้อ
    if len(texts) >= 3 and re.fullmatch(r'\d[\d,.]*\s*[^\s\d]{0,12}', texts[0]) and all(re.search(r'\d', x) for x in texts[1:]):
        note = (texts[0] + ' ' + note).strip(); texts = texts[1:]; sec['_lead'] = 1   # ข้อแรกเป็นแค่ยอดรวม (85,000 บาท) ตามด้วยส่วนย่อย = ข้อความนำ ไม่ใช่ข้อระดับเดียวกัน
    if not texts:
        if ps: return [dict(kind='statement', t=ps[0], s=t)]
        return [dict(kind='divider', t=t, num=sec['num'])]

    prs = [pair(x) for x in texts]
    if all(p and p[0] == 'qa' for p in prs):
        return [dict(kind='qa', t=t, items=part) for part in chunk([(p[1], p[2]) for p in prs], 4)]

    # ตัวเลขพร้อมหน่วย หรือเลขที่มีหลักพัน/ทศนิยม (1,240 / 68.5) ไม่นับเลขปี 4 หลักเปล่า ๆ
    nums = [re.search(NUM, x) or re.search(r'(?<![\d.])\d{1,3}(?:,\d{3})+(?:\.\d+)?|(?<![\d.])\d+\.\d+', x) for x in texts]
    whole = lambda x, m: m and (m.start() == 0 or x[m.start() - 1] == ' ') and not re.search(r'\d[.:]\d{2}\s*[-–]', x)   # ค่าต้องเป็นคำเต็ม ไม่ใช่ช่วงเวลา 14.30-15.30
    nums = [m if whole(x, m) else None for x, m in zip(texts, nums)]
    onenum = lambda x: len(re.findall(r'\d[\d,.]*', x)) == 1 and not re.search(r'(ละ|ราคา|จำนวน)\s*\d', x)   # ป้าย + ตัวเลขเดียว ถึงทำการ์ดได้ (ดึงเลขออกจากประโยคแล้วเหลือ "ราคาชุดละ" ห้าม)
    if len(texts) >= 2 and all(nums) and all(map(onenum, texts)) and not all(re.search(DATE, x) for x in texts):   # ทุกข้อมีตัวเลข → การ์ดตัวเลข ทีละไม่เกิน 4 ใบ
        st = [(x, m) for x, m in zip(texts, nums)]
        return [dict(kind='stat', t=t, note=note, raw=[x for x, _ in part], **({'_lead': 1} if sec.get('_lead') else {}), **({'_leadend': 1} if sec.get('_leadend') else {}),
                     items=[(m.group(0).strip(), re.sub(r'\s{2,}', ' ', x[:m.start()] + x[m.end():]).strip(' :,-')) for x, m in part])
                for part in chunk(st, 4)]

    TR = r'^\d{1,2}[.:]\d{2}\s*[-–]\s*\d{1,2}[.:]\d{2}(?:\s*น\.)?'
    if len(texts) >= 3 and all(re.match(TR, x) for x in texts):   # กำหนดการ (เวลา + กิจกรรม) = ไทม์ไลน์ ทีละไม่เกิน 5 ช่วง
        tl = [(re.match(TR, x).group(0), x[re.match(TR, x).end():].strip()) for x in texts]
        return [dict(kind='timeline', t=t, items=part) for part in chunk(tl, 12)]   # หน้าละกี่ช่วงให้ตัวจัดแบ่งเท่า ๆ กันตามที่หน้าตารับได้
    if 3 <= len(texts) <= 5 and all(re.search(DATE, x) for x in texts):
        return [dict(kind='timeline', t=t, items=[(p[1], p[2]) if p else (re.search(DATE, x).group(0), x)
                                                  for x, p in zip(texts, prs)])]

    ordered = bool(lis) and all(b[2] for b in lis)
    kv = all(p and p[0] == 'kv' for p in prs)
    out = []
    for part in chunk(list(zip(texts, prs))):
        ld = dict({'_lead': 1} if sec.get('_lead') else {}, **({'_leadend': 1} if sec.get('_leadend') else {}))
        if kv: out.append(dict(kind='pairs', t=t, ordered=ordered, note=note, items=[(p[1], p[2]) for _, p in part], **ld))
        else: out.append(dict(kind='list', t=t, ordered=ordered, note=note, items=[(x,) for x, _ in part], **ld))
    return out

# ══ 4. layout ของชุดนี้รับรูปทรงไหน — อ่านจากตัวอย่างใน SEQ ═══════════════════

def isval(x):
    """'5 เดือน' '-35%' '140+' = ค่าตัวเลข  ใช้แยกการ์ดสถิติออกจากการ์ดหัว+เนื้อ"""
    x = str(x).strip()
    return bool(x) and len(x) <= 14 and x[0] in '-+0123456789฿' and any(c.isdigit() for c in x)

DATA = ('series', 'points', 'kpis', 'before', 'stats', 'big', 'pct', 'on', 'side')

stacked = lambda name: bool(re.search(r"\bchart\(s, '(colS|barS|areaS|colP|barP)'", SRC.get(name, '')))   # layout ที่วาดกราฟซ้อน

def kind_of(name, ex, idx, total):
    """คืน (kind, จำนวนข้อในตัวอย่าง, โครงของแต่ละข้อ)  ใช้ไม่ได้ → kind=None"""
    if idx == 0: return 'cover', 0, None
    if 'close' in name or idx == total - 1: return None, 0, None   # หน้าปิดท้ายไม่มีเนื้อหาจากเอกสาร
    # หน้ากราฟ = กราฟ PowerPoint จริง (chart() ฝังชีต Excel) เท่านั้น กราฟที่วาดด้วยรูปทรง (gradbars ของ chart_bars) ไม่ใช่หน้ากราฟ (ใบ 008)
    nat = bool(re.search(r'\bchart\(s,', SRC.get(name, '')))
    if nat and 'cats' in ex and ('vals' in ex or 'series' in ex): return 'chart', len(ex['cats']), None
    it = ex.get('items')                                   # โดนัทที่วาดค่าเป็น % ตรง ๆ (ไม่มีหน่วยตายตัวของดีไซน์ เช่น "ล.") รับสัดส่วนของลูกค้าได้
    if nat and "chart(s, 'donut'" in SRC[name] and "f'{v}%'" in SRC[name] and isinstance(it, list) and it and isinstance(it[0], (list, tuple)):
        return 'chart', len(it), tuple(type(x) for x in it[0])
    if any(k in ex for k in DATA) or 'cats' in ex: return None, 0, None   # ต้องมีตัวเลขเฉพาะทาง (การ์ดใหญ่) ที่เอกสารไม่ได้ให้ / กราฟรูปทรง
    if 'head' in ex and 'rows' in ex: return 'table', len(ex['rows']), None
    it = ex.get('items')
    if isinstance(it, list) and it:
        f = it[0]
        if isinstance(f, str): return ('agenda' if 'agenda' in name or 'toc' in name or idx == 1 else 'list'), len(it), (str,)
        if not isinstance(f, (list, tuple)) or any(isinstance(x, dict) for x in f): return None, 0, None
        slots = tuple(type(x) for x in f)
        if any(isinstance(x, (int, float)) and x not in (0, 1) for r in it for x in r):
            return None, 0, None                           # ช่องตัวเลขในข้อ = ข้อมูลกราฟ ห้ามยืมเลขตัวอย่าง
        if isinstance(f[0], str) and f[0] in ICONS: return None, 0, None   # ช่องแรกเป็นไอคอน เดาไอคอนให้เนื้อลูกค้าไม่ได้
        if list in slots: return ('compare' if len(it) == 2 else None), len(it), slots
        if 'timeline' in name or 'gantt' in name: return 'timeline', len(it), slots   # ก่อน isval: ไทม์ไลน์ขึ้นต้นด้วยปี
        if isval(f[0]): return 'stat', len(it), slots
        if 'toc' in name or 'agenda' in name or idx == 1: return 'agenda', len(it), slots
        return ('faq' if 'faq' in name else 'pairs'), len(it), slots
    if 'num' in ex or name.startswith('div') or '_div' in name or 'section' in name: return 'divider', 0, None
    return 'statement', 0, None

# เนื้อหาชนิดนี้ ลงตัวอย่างชนิดไหนได้บ้าง พร้อมโทษ (น้อย = เหมาะกว่า)
FIT = {'list': {'list': 0, 'agenda': 3, 'pairs': 4}, 'agenda': {'agenda': 0, 'list': 1, 'pairs': 4},
       'pairs': {'pairs': 0, 'faq': 2, 'agenda': 3}, 'qa': {'faq': 0, 'pairs': 1, 'agenda': 3},
       'stat': {'stat': 0}, 'timeline': {'timeline': 0, 'pairs': 3}, 'compare': {'compare': 0},
       'table': {'table': 0}, 'chart': {'chart': 0, 'table': 2},
       'statement': {'statement': 0, 'divider': 2}, 'divider': {'divider': 0, 'statement': 2}, 'cover': {'cover': 0}}
KEEP = ('pi', 'tsz', 'hi', 'nomirror', 'bsz', '_nf', '_sn', 'fsz', '_ov')                    # คีย์ดีไซน์ที่ไม่ใช่ข้อความ เก็บตามตัวอย่าง

LABEL = ('k', 'kicker', 'lab', 'label', 'tag', 'who', 'sub', 'cat', 'eyebrow')   # ช่องป้ายสั้น ๆ ที่ใส่หัวรองแทนได้

def fill(name, ex, slots, c):
    """เอาเนื้อลูกค้าใส่ตามโครงของตัวอย่าง ห้ามมีคำจากตัวอย่างหลุดมา  ใส่ไม่ได้ → None"""
    d = {k: ex[k] for k in KEEP if k in ex}
    d['t'] = c['t']
    if c['kind'] == 'cover' and 't' not in ex and 't1' in ex:   # ปกบางชุดแยกชื่อเรื่องเป็นสองบรรทัด t1/t2
        d['t1'] = c['t']; d.pop('t')
    if c.get('s') and not (c['kind'] == 'chart' and LAYKIND.get(name) == 'table'): d['s'] = c['s']   # หัวคอลัมน์ซ้ำเป็นหัวรองเฉพาะตอนเป็นกราฟ
    if c.get('_bsz'): d['bsz'] = c['_bsz']
    if c.get('note') and 'note' in ex: d['note'] = c['note']
    elif c.get('_lead') and 's' in ex and not c.get('s'): d['s'] = c['note']   # ยอดรวมนำ ลงช่องหัวรอง
    if c.get('_ins'):                                      # หน้าที่ลูกค้าแทรกเอง: ช่องหัวรอง/หมายเหตุของ layout ว่างไว้ให้พิมพ์
        for k in ('s', 'note'):
            if k in ex: d.setdefault(k, '')
    if 'num' in ex: d['num'] = c.get('num', '')
    if c['kind'] in ('table', 'chart') and 'head' in ex:
        d['head'] = c['head']; d['rows'] = [list(r) for r in c['rows']]
        tp = next((h for h in ex['head'] if isinstance(h, (list, tuple))), None)
        if tp:                                             # หัวคอลัมน์แบบ (หัว, หัวรอง) เช่น op_table ใส่หัวรองว่าง
            d['head'] = [(h,) + ('',) * (len(tp) - 1) for h in c['head']]
        if 'colw' in ex:                                   # หน่วยเดียวกับตัวอย่าง (นิ้ว หรือ สัดส่วน) แบ่งเท่ากัน
            d['colw'] = [round(sum(ex['colw']) / len(c['head']), 3)] * len(c['head'])
        if 'al' in ex: d['al'] = ['l'] + ['r' if all(isnum(r[j]) for r in c['rows']) else 'l' for j in range(1, len(c['head']))]
    elif c['kind'] == 'chart' and LAYKIND.get(name) == 'chart':
        ser = c.get('series') or [(c.get('s', ''), c['vals'])]
        if stacked(name) and not (c.get('_stack') and len(ser) > 1): return None   # แท่งซ้อน: เฉพาะส่วนของก้อนเดียวกันหลายชุด (ชุดเดียวไม่ใช่แท่งซ้อน)
        if 'cats' in ex:
            d['cats'] = list(c['cats'])
            if 'series' in ex: d['series'] = [(n, list(v)) for n, v in ser]
            elif len(ser) == 1:                            # layout กราฟชุดเดียว
                d['vals'] = list(ser[0][1])
                if 'sname' in ex: d['sname'] = ser[0][0]   # ชื่อชุดข้อมูล = หัวคอลัมน์ของลูกค้า (ขึ้นใน Edit Data)
            else: return None
        else:                                              # โดนัท: เฉพาะสัดส่วนของทั้งก้อน แถวไม่เกินที่ดีไซน์วาด
            if not c.get('_share') or len(c['cats']) > len(ex['items']): return None
            d['items'] = [tuple(a if i == 0 else v if t in (int, float) else '' for i, t in enumerate(slots)) for a, v in zip(c['cats'], c['vals'])]
        d['_nf'] = c['_nf']; d['_sn'] = [n for n, _ in ser]   # ชื่อชุดข้อมูลของลูกค้าทับชื่อตายตัวของดีไซน์ (โดนัท tb_donut ตั้ง 'ร้อยละ')
        if "d['s']" not in SRC[name] and "d.get('s'" not in SRC[name]: d.pop('s', None)   # หัวคอลัมน์อยู่ในกราฟแล้ว (ชื่อชุดข้อมูล)
        for k in ('items', 'side', 'bullets'):             # การ์ดตัวเลข/ข้อความข้างกราฟ: ว่าง ห้ามยืมเลขตัวอย่างของดีไซน์
            if isinstance(ex.get(k), list) and k not in d: d[k] = []
        if 'big' in ex:                                    # ตัวเลขใหญ่ข้างกราฟ = แถวแรกของลูกค้า ตามที่เอกสารพิมพ์ (ดีไซน์ไฮไลต์แท่งแรก) + ป้ายของแถวนั้น
            if len(ser) == 1 and '_col' in c:
                i = 0
                d['big'] = c['rows'][i][c['_col']].strip(); d['biglab'] = c['cats'][i]
            else: d['big'] = d['biglab'] = ''
    elif 'items' in ex and c.get('items'):                 # ปกบางชุดมี items ในตัวอย่าง ถ้าบังคับ REQ ด้านล่างจะตัดทิ้งเอง
        rows = []
        for it in c['items']:
            if slots == (str,):
                if len(it) > 1: return None                # หัว+เนื้อ ยัดลงช่องเดียวไม่ได้
                rows.append(it[0]); continue
            strs = [i for i, t in enumerate(slots) if t is str]
            lsts = [i for i, t in enumerate(slots) if t is list]
            vals = list(it)
            if c['kind'] == 'compare':                     # (หัว, [ข้อ...]) → ช่องสตริงแรก + ช่องลิสต์
                if not lsts: return None
                r = [''] * len(slots); r[strs[0]] = vals[0]; r[lsts[0]] = vals[1]
            else:
                if len(vals) > len(strs): return None
                r = [ex['items'][0][i] if t in (int, float, bool) else '' for i, t in enumerate(slots)]
                off = min(c.get('_slot', 0), len(strs) - len(vals))   # ลองใส่ช่องถัดไปได้ (ช่องแรกบาง layout เป็นเลขหน้า)
                for i, v in zip(strs[off:], vals): r[i] = v
            rows.append(tuple(r))
        d['items'] = rows
    for k in TXTDEF.get(name, ()):
        d.setdefault(k, '')
    if d.get('s') and "d['s']" not in SRC[name] and "d.get('s'" not in SRC[name]:   # layout ไม่วาดหัวรอง: ย้ายไปช่องป้ายที่ layout วาด
        lab = next((k for k in LABEL if k in SRC[name] and not d.get(k) and isinstance(ex.get(k, ''), str)), None)
        if lab: d[lab] = d.pop('s')
    for k in REQ.get(name, set()) - set(d) - {'topic', 'foot', 'n'}:   # คีย์บังคับที่เอกสารไม่มี
        if isinstance(ex.get(k), str): d[k] = ''
        elif c['kind'] == 'cover' and isinstance(ex.get(k), (list, tuple)): d[k] = []   # การ์ดตัวเลขบนปก mk เติมจากเนื้อเด็คเอง
        else: return None
    return d

# ══ 5. วัดกรอบจากการวาดจริง ════════════════════════════════════════════════

_FACE, _FONT = {}, {}
def facefile(name, bold):
    k = (name, bold)
    if k not in _FACE:
        q = (name or 'IBM Plex Sans Thai') + (':bold' if bold else '')
        if WEB:
            fm = json.load(open(f'{K}/fonts.json'))
            _FACE[k] = f"{K}/fonts/{fm.get(q) or fm.get(name or '') or fm['IBM Plex Sans Thai']}"
        else:
            _FACE[k] = subprocess.run(['fc-match', '-f', '%{file}', q], capture_output=True, text=True).stdout
    return _FACE[k]

def lines(t, w_in, pt, f, dpi=144):
    """ข้อความนี้ที่ขนาดนี้กินกี่บรรทัด ใช้ตัวตัดคำเพื่อวัดอย่างเดียว ไม่แทรก ZWSP ลงไฟล์
    ปล่อยให้ PowerPoint ขึ้นบรรทัดเอง"""
    from PIL import ImageFont
    if (f, pt) not in _FONT: _FONT[(f, pt)] = ImageFont.truetype(f, int(pt / 72 * dpi))
    font, lim, n = _FONT[(f, pt)], w_in * dpi, 0
    for para in str(t).split('\n'):
        n += 1; cur = 0.0
        for tok in words(para):
            wd = font.getlength(tok)
            if cur and cur + wd > lim and not tok.isspace(): n += 1; cur = 0.0
            if wd > lim and not tok.isspace():               # คำยาวไม่มีที่ตัด (URL อีเมล) กว้างกว่ากล่อง: นับบรรทัดที่ถูกหักจริง
                n += int(wd // lim); cur = wd % lim; continue
            cur += wd
    return n

def widest(t, w_in, pt, f, dpi=144):
    """ความกว้างจริงของบรรทัดที่ยาวที่สุด (นิ้ว) ตัดบรรทัดแบบเดียวกับ lines()"""
    from PIL import ImageFont
    if (f, pt) not in _FONT: _FONT[(f, pt)] = ImageFont.truetype(f, int(pt / 72 * dpi))
    font, lim, mx = _FONT[(f, pt)], w_in * dpi, 0.0
    for para in str(t).split('\n'):
        cur = 0.0
        for tok in words(para):
            wd = font.getlength(tok)
            if cur and cur + wd > lim and not tok.isspace(): mx = max(mx, cur); cur = 0.0
            cur += wd
        mx = max(mx, min(cur, lim))
    return mx / dpi

BIND = re.compile(r'(ที่|ครั้งที่|ชั้น|ข้อ|ป\.|ม\.|ปี|ฉบับที่) (\d)')   # เลขลำดับไม่หลุดไปอยู่บรรทัดเดียว ("ภาคเรียนที่ 1")

def bind_nums(slide):
    """เว้นวรรคระหว่าง "ที่"/"ชั้น" กับเลขลำดับ เป็นเว้นวรรคไม่ตัดบรรทัด (เฉพาะในไฟล์ที่วาด คำลูกค้าเหมือนเดิม)"""
    for sh in slide.shapes:
        if not sh.has_text_frame: continue
        for p in sh.text_frame.paragraphs:
            for r in p.runs:
                if BIND.search(r.text): r.text = BIND.sub('\\1\u00a0\\2', r.text)

def wordsx(t):
    """words() แต่ไม่หั่นคำอังกฤษ/ตัวเลข/ขีด เช่น O-NET 5/2568 ไว้เป็นชิ้นเดียว ใช้ตอนหาที่ตัดบรรทัด/หน้า"""
    out = []
    for w_ in words(t):
        if out and re.fullmatch(r'[A-Za-z0-9\-./%,]+', w_) and re.search(r'[A-Za-z0-9\-./]$', out[-1]): out[-1] += w_
        else: out.append(w_)
    return out

def words(t):
    """ตัดคำไทยเพื่อวัด  ในเครื่องใช้ PyThaiNLP บนเว็บใช้ Intl.Segmenter ของเบราว์เซอร์ (พจนานุกรมเหมือนกัน ไม่ใช่ AI)"""
    try:
        from pythainlp.tokenize import word_tokenize
        return word_tokenize(t, keep_whitespace=True)
    except ImportError:
        import js
        return list(js.d2sSeg(t))

def strings(v):
    if isinstance(v, str): yield v
    elif isinstance(v, (int, float)) and not isinstance(v, bool): yield str(v)   # ค่ากราฟของลูกค้า
    elif isinstance(v, (list, tuple)):
        for x in v: yield from strings(x)
    elif isinstance(v, dict):
        for k, x in v.items():
            if k not in KEEP and k != 'al': yield from strings(x)

import base64
_DOT = base64.b64decode('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==')

def overflow(name, d, M):
    """วาด layout นี้ด้วยเนื้อลูกค้า แล้วดูทุกกล่องที่มีข้อความลูกค้าว่าล้นความสูงกรอบไหม"""
    nm_ = LAYKIND.get(name, '')
    eng.setpal(M['pal'], M.get('font', 'plex'), M.get('head')); eng.setvar(0)
    prs = base.deck()
    real = base._prep
    base._prep = lambda path, mode=None: (_DOT, (4, 3))   # วัดแค่ข้อความ ไม่ต้องย่อ/ย้อมสีรูปจริง เร็วขึ้นหลายเท่า
    try: lay.L[name](prs, {'topic': M.get('topic', 'office'), 'foot': '', 'n': '01', **d})
    except Exception as ex: return [f'วาดไม่ได้ {type(ex).__name__}']
    finally: base._prep = real
    if d.get('bsz'): shrink_text(prs.slides[-1], d['bsz'])
    if d.get('fsz'): fsize(prs.slides[-1], d)
    mine = {x.strip() for x in strings(d) if len(x.strip()) > 1}
    thai_spacing(prs.slides[-1])                          # ระยะบรรทัดเดียวกับตอนวาดจริง
    scrub(prs.slides[-1], list(strings(d))); tidy(prs.slides[-1], d)   # เหมือนตอนวาดจริง: คำที่ layout เติมเอง ("หน้า 450,000 บาท") ถูกลบทั้งกล่อง
    bad = [f'ไม่ได้วาด "{x[:22]}"' for x in lost(prs.slides[-1], d)]
    bind_nums(prs.slides[-1])                             # เหมือนตอนวาดจริง (วัดบรรทัดด้วยเลขลำดับที่ไม่หลุด)   # layout ที่ไม่วาดบางช่อง = ทิ้งเนื้อลูกค้า ใช้ไม่ได้
    def solid(x):
        try: return x.fill.type == 1                       # MSO_FILL.SOLID
        except Exception: return False
    shs = [x for x in prs.slides[-1].shapes if solid(x) and not (x.has_text_frame and x.text_frame.text.strip())]
    SH = prs.slide_height / 914400
    for tbs in [x for x in prs.slides[-1].shapes if getattr(x, 'has_table', False) and x.has_table]:
        # ตารางจริง: แถวสูงขึ้นตามข้อความ (บรรทัดไทยสูงกว่าที่ประมาณ) รวมแล้วต้องไม่เลยขอบล่างสไลด์
        tb, tot = tbs.table, 0.0
        for row in tb.rows:
            hmax = row.height / 914400
            for j, cell in enumerate(row.cells):
                r_ = next((r for p_ in cell.text_frame.paragraphs for r in p_.runs if r.font.size), None)
                if not r_ or not cell.text_frame.text.strip(): continue
                pt = r_.font.size.pt; cw = tb.columns[j].width / 914400 - 0.2
                n_ = lines(cell.text_frame.text, max(cw, 0.3), pt, facefile(r_.font.name, bool(r_.font.bold)))
                hmax = max(hmax, n_ * pt * 1.5 / 72 + 0.1)
            tot += hmax
        if tbs.top / 914400 + tot > SH - 0.15: bad.append(f'ตารางยาวเลยขอบล่าง ({tot:.1f} นิ้ว)')
    for sh in prs.slides[-1].shapes:
        if not sh.has_text_frame or sh.text_frame.text.replace('\u00a0', ' ').strip() not in mine: continue
        p = sh.text_frame.paragraphs[0]
        if not p.runs or not p.runs[0].font.size: continue
        r = p.runs[0].font; pt = r.size.pt
        w, h = sh.width / 914400, sh.height / 914400
        sp = p.line_spacing if isinstance(p.line_spacing, float) else 1.0
        lh = pt * max(sp, 1.0) * 1.25 / 72                 # ความสูงหนึ่งบรรทัดของฟอนต์ไทย (สระบน-ล่าง)
        allow = max(1, int(h / lh + 0.35))
        need = lines(sh.text_frame.text, w, pt, facefile(r.name, bool(r.bold)))
        hn = LHINT.get(' '.join(sh.text_frame.text.split()))
        hn = min(hn or [], key=lambda x: abs(x[0] - pt), default=None)
        if hn and abs(hn[0] - pt) < 0.6: need = max(need, int(hn[1]))   # กล่องที่ลูกค้ากำลังพิมพ์: ใช้ค่ามากกว่าระหว่าง PIL กับที่เบราว์เซอร์ตัดจริง
        if need > allow: bad.append(f'"{sh.text_frame.text[:22]}" {need}/{allow} บรรทัด')
        elif need >= 3 and h < 1.0 and need * lh * 1.2 > h + 0.05: bad.append(f'"{sh.text_frame.text[:22]}" {need} บรรทัดแน่นเกินกล่อง')   # ไทยหลายบรรทัดสูงกว่าที่ประมาณ (ข้อความล้นลูกศร)
        if pt >= 20:                                       # หัวเรื่อง: คำติดกัน (ไม่มีเว้นวรรค) ต้องอยู่บรรทัดเดียว ไม่หักกลางคำ ("ปฏิบัติ/การ") ปก ≤30 ตัว หัวเรื่องอื่น ≤12 ตัว
            fz = facefile(r.name, bool(r.bold)); cap_ = 30 if 'tsz' in d or nm_ == 'cover' else 12
            if any(lines(ch, w, pt, fz) > 1 for ch in re.split(r'[\s\u00a0]+', sh.text_frame.text) if 4 <= len(ch) <= cap_ and not re.search(r'[A-Za-z]', ch)):
                bad.append(f'"{sh.text_frame.text[:22]}" หักกลางคำ')
        tw_ = widest(sh.text_frame.text, w, pt, facefile(r.name, bool(r.bold)))
        al_ = int(p.alignment) if p.alignment is not None else 1
        tx0 = sh.left / 914400 + ((w - tw_) / 2 if al_ == 2 else (w - tw_) if al_ == 3 else 0); tx1 = tx0 + tw_
        anc_ = sh.text_frame.vertical_anchor; th_ = need * lh
        ty0 = sh.top / 914400 + ((h - th_) / 2 if anc_ is not None and int(anc_) == 3 else (h - th_) if anc_ is not None and int(anc_) == 4 else 0)
        for ln_ in prs.slides[-1].shapes:                  # เส้นคั่นแถว/รูป เป็นขอบแข็ง ข้อความห้ามทับ
            if ln_ is sh or (ln_.has_text_frame and ln_.text_frame.text.strip()): continue
            lx, ly, lw_, lh_ = ln_.left / 914400, ln_.top / 914400, ln_.width / 914400, ln_.height / 914400
            if lw_ >= 0.5 and lh_ <= 0.04 and ty0 + lh * 0.6 < ly < ty0 + th_ - 0.04 and lx < tx1 - 0.05 and lx + lw_ > tx0 + 0.05:
                bad.append(f'"{sh.text_frame.text[:22]}" ทับเส้นคั่น'); break
            pic = getattr(ln_, 'shape_type', None) == 13
            if pic and not (lx <= sh.left / 914400 + 0.05 and ly <= sh.top / 914400 + 0.05) and lx > tx0 + 0.3 and tx1 > lx + 0.3 \
                    and ly < ty0 + th_ and ly + lh_ > ty0:
                bad.append(f'"{sh.text_frame.text[:22]}" ทับรูป'); break
        SW = prs.slide_width / 914400; x0 = sh.left / 914400; y0 = sh.top / 914400
        th = need * pt * 1.35 / 72                         # ความสูงข้อความไทยจริง
        anc = sh.text_frame.vertical_anchor
        bot = y0 + (h + th) / 2 if anc is not None and int(anc) == 3 else (y0 + h if anc is not None and int(anc) == 4 else y0 + th)   # 3 กลาง 4 ล่าง
        if h <= 0.6 and need == 1 and any(abs(x.left - sh.left) < 2e4 and abs(x.width - sh.width) < 2e4 and abs(x.top - sh.top) < 2e4
                                          for x in prs.slides[-1].shapes if x is not sh and not x.has_text_frame or (x is not sh and x.has_text_frame and not x.text_frame.text.strip())):
            if lines(sh.text_frame.text, max(w - 0.3, 0.3), pt, facefile(r.name, bool(r.bold))) > 1: bad.append(f'"{sh.text_frame.text[:22]}" ชิดขอบป้าย')
        rowbg = y0 + h > SH + 0.02 and any(abs(x.top - sh.top) < 2e4 and abs(x.height - sh.height) < 2e4 for x in shs)   # แถบแถวตารางตกขอบ
        if bot > SH - 0.02 or rowbg:                       # ตัวหนังสือจริง (ตามจุดยึดของกล่อง) หรือแถบพื้นของแถว เลยขอบล่างสไลด์
            bad.append(f'"{sh.text_frame.text[:22]}" เลยขอบล่างสไลด์')
        # กล่องข้อความวางบนแผงสี (เช่นกล่องขาวบนปก) ที่เตี้ยกว่ากล่องข้อความ: ข้อความต้องจบในแผง
        for pn in shs:
            if pn is sh: continue
            px, py, pw, ph_ = pn.left / 914400, pn.top / 914400, pn.width / 914400, pn.height / 914400
            if px <= x0 + 0.05 and py <= y0 + 0.05 < py + ph_ - 0.1 and px + pw >= x0 + min(w, 1) and py + ph_ < y0 + h - 0.15 and pw * ph_ < SW * 7.5 * 0.6:   # แผงต้องรองรับต้นข้อความจริง
                if y0 + need * lh + 0.1 > py + ph_: bad.append(f'"{sh.text_frame.text[:22]}" ล้นแผงพื้น'); break
        if x0 + w > SW + 0.05:                             # กล่องกว้างเลยขอบสไลด์ (กว้างตามข้อความ) ข้อความต้องจบในขอบสไลด์บรรทัดเดียว
            if lines(sh.text_frame.text, max(SW - x0 - 0.3, 0.5), pt, facefile(r.name, bool(r.bold))) > 1:
                bad.append(f'"{sh.text_frame.text[:22]}" ล้นขอบสไลด์')
    return bad

def slide_text(slide):
    """ข้อความทั้งหมดที่วาดจริงบนสไลด์ (กล่อง ตาราง กราฟ) ตัดช่องว่าง ตัวเล็ก ไว้เทียบว่าคำลูกค้าอยู่ครบไหม"""
    out = []
    for sh in slide.shapes:
        if getattr(sh, 'has_table', False) and sh.has_table: out += [c.text for r in sh.table.rows for c in r.cells]
        elif getattr(sh, 'has_chart', False) and sh.has_chart: out += list(sh.chart._chartSpace.itertext())
        elif sh.has_text_frame: out.append(sh.text_frame.text)
    return ''.join(''.join(out).split()).lower()

def cust(d):
    """ข้อความลูกค้าใน d (ไม่รวมคีย์ดีไซน์ ความกว้างคอลัมน์ และตัวเลขใน items ที่ fill ยกมาจากตัวอย่าง เช่นธง 0/1)"""
    strs = lambda v: [x for x in v if isinstance(x, str)] if isinstance(v, (list, tuple)) else v
    d2 = {k: ([strs(r) for r in v] if k == 'items' and isinstance(v, list) else v) for k, v in d.items() if k != 'colw'}
    return [x for x in strings(d2) if x.strip() and x.strip() not in ALLOW]   # "สารบัญ" เป็นคำของระบบ layout ไม่วาดก็ไม่ใช่เนื้อหาหาย

def lost(slide, d):
    """คำลูกค้าที่อยู่ใน d แต่ layout ไม่ได้วาดลงสไลด์ (กฎห้ามทิ้งเนื้อหา)"""
    t = slide_text(slide)
    return [x for x in cust(d) if ''.join(x.split()).lower() not in t]

SMALLNOTE = 'หน้าตานี้กล่องข้อความเล็ก บางหน้าจึงตัวเล็ก ลองหน้าตาอื่นได้'

def shrink_text(slide, f):
    """หน้าที่ข้อความยาวกว่ากล่องของชุดนี้: ย่อตัวหนังสือทั้งหน้าลง f เท่า ไม่ต่ำกว่า 10.5pt (ขั้นต่ำของมาตรฐานตัวหนังสือ) แทนการตัดกลางความ"""
    from pptx.util import Pt
    for sh in slide.shapes:
        if not sh.has_text_frame: continue
        for p in sh.text_frame.paragraphs:
            for r in p.runs:
                if r.font.size and r.font.size.pt > 10.5: r.font.size = Pt(max(10.5, round(r.font.size.pt * f * 2) / 2))

def fsize(slide, d):
    """ขนาดตัวอักษรที่ตั้งต่อกล่อง d['fsz'] = {'items.2': 0.9} เท่าของขนาดดีไซน์ ไม่ต่ำกว่า 10pt (ใบ 015: ล้นตอนจบการแก้ ย่อเองแบบ PowerPoint)"""
    from pptx.util import Pt
    for key, f in d['fsz'].items():
        try: t = ' '.join(str(_get(d, [int(x) if x.isdigit() else x for x in key.split('.')])).split())
        except (KeyError, IndexError, TypeError): continue
        for sh in slide.shapes:
            if t and sh.has_text_frame and ' '.join(sh.text_frame.text.replace('\u00a0', ' ').split()) == t:
                for p in sh.text_frame.paragraphs:
                    for r in p.runs:
                        if r.font.size and r.font.size.pt > 10: r.font.size = Pt(max(10, round(r.font.size.pt * f * 2) / 2))

def thai_spacing(slide):
    """ข้อความไทยหลายบรรทัดที่ระยะบรรทัดต่ำกว่า 1.15 วรรณยุกต์บรรทัดล่างชนบรรทัดบน (ปกตัวโต sp 0.98) ขยายเป็น 1.15"""
    for sh in slide.shapes:
        if not sh.has_text_frame or not re.search(r'[\u0E00-\u0E7F]', sh.text_frame.text): continue
        for p in sh.text_frame.paragraphs:
            if isinstance(p.line_spacing, float) and p.line_spacing < 1.15: p.line_spacing = 1.15

_DLBL = ('numFmt', 'spPr', 'txPr', 'dLblPos', 'showLegendKey', 'showVal', 'showCatName', 'showSerName', 'showPercent', 'showBubbleSize', 'separator')
def numfmt(slide, nf, sn=None):
    """รูปแบบตัวเลขตามเซลล์ต้นทาง ทับค่าที่ layout ตั้งตายตัว (เช่น 0"%" ของ by_chart_bar) ทั้งชีตฝังและป้ายบนกราฟ
    nf = [[รูปแบบต่อจุด] ต่อชุดข้อมูล]  ชุดเดียวกันรูปแบบไม่เท่ากัน (เอกสาร 10) ใส่ป้ายรายจุด
    ponytail: ชีตฝังใช้รูปแบบที่พบมากสุดของชุด ไม่ทำรายเซลล์"""
    import copy
    from lxml import etree
    from collections import Counter
    from pptx.chart.data import CategoryChartData
    from pptx.oxml.ns import qn
    from pptx.dml.color import RGBColor
    for gf in [x for x in slide.shapes if getattr(x, 'has_chart', False) and x.has_chart][:1]:
        ch = gf.chart; pl = ch.plots[0]
        top = [Counter(f).most_common(1)[0][0] for f in nf]
        cd = CategoryChartData(); cd.categories = list(pl.categories)
        for i, sr in enumerate(pl.series): cd.add_series(sn[i] if sn and i < len(sn) else sr.name, list(sr.values), number_format=top[min(i, len(top) - 1)])
        ch.replace_data(cd)
        try:                                               # แกนที่ดีไซน์ล็อกไว้ (ug_chart_pass max 100 สำหรับ %) ไม่ให้ข้อมูลลูกค้าตกขอบ
            va = ch.value_axis; vs = [v for sr in pl.series for v in sr.values if v is not None]
            if va.maximum_scale is not None and max(vs) > va.maximum_scale: va.maximum_scale = None
            if va.minimum_scale is not None and min(vs) < va.minimum_scale: va.minimum_scale = None
        except (ValueError, AttributeError): pass          # โดนัท/วงกลมไม่มีแกน
        pdl = pl._element.find(qn('c:dLbls'))
        shown = pdl is not None and pdl.find(qn('c:showVal')) is not None and pdl.find(qn('c:showVal')).get('val') == '1'
        line = pl._element.tag == qn('c:lineChart'); stk = pl._element.find(qn('c:grouping')) is not None and pl._element.find(qn('c:grouping')).get('val') in ('stacked', 'percentStacked')
        def setpos(el, v):                                 # c:dLblPos ต้องอยู่หลัง txPr ก่อน showLegendKey (ลำดับตาม schema)
            e = el.find(qn('c:dLblPos'))
            if e is None: e = etree.Element(qn('c:dLblPos')); el.find(qn('c:showLegendKey')).addprevious(e)
            e.set('val', v)
        for i, sr in enumerate(pl.series):
            f = nf[min(i, len(nf) - 1)]; ft = top[min(i, len(top) - 1)]
            sdl = sr._element.find(qn('c:dLbls'))
            if sdl is None:
                if not shown: continue
                sdl = sr._element.get_or_add_dLbls(); sdl.getparent().replace(sdl, copy.deepcopy(pdl)); sdl = sr._element.find(qn('c:dLbls'))
            nfe = sdl.find(qn('c:numFmt'))
            if nfe is None: continue
            nfe.set('formatCode', ft); nfe.set('sourceLinked', '0')
            if stk:                                        # ป้ายในแท่งซ้อน: ขาวบนแท่งเข้ม เข้มบนแท่งอ่อน (สีจางของดีไซน์อ่านไม่ออกบนส้ม)
                try:
                    h = str(sr.format.fill.fore_color.rgb); lum = (0.299 * int(h[:2], 16) + 0.587 * int(h[2:4], 16) + 0.114 * int(h[4:], 16)) / 255
                    sr.data_labels.font.color.rgb = RGBColor.from_string('FFFFFF' if lum < 0.6 else '1F1F1F')
                except (AttributeError, TypeError, ValueError): pass
            vals = list(sr.values); pos = {}
            if line and len(vals) > 1:                     # เส้น: ป้ายเหนือจุด จุดที่ต่ำกว่าเพื่อนข้าง ๆ (หุบ) ป้ายอยู่ใต้จุด ไม่ทับเส้นที่ขึ้นไป (150,250 / 149,000)
                setpos(sdl, 't')
                for j, v in enumerate(vals):
                    nb = [vals[k] for k in (j - 1, j + 1) if 0 <= k < len(vals) and vals[k] is not None]
                    if v is not None and nb and v < sum(nb) / len(nb): pos[j] = 'b'
            for j in sorted(set(pos) | {j for j, fj in enumerate(f) if fj != ft}):
                dl = etree.Element(qn('c:dLbl')); etree.SubElement(dl, qn('c:idx')).set('val', str(j))
                for k in _DLBL:
                    e = sdl.find(qn('c:' + k))
                    if e is not None: dl.append(copy.deepcopy(e))
                dl.find(qn('c:numFmt')).set('formatCode', f[j] if j < len(f) else ft)
                if j in pos: setpos(dl, pos[j])
                sdl.insert(len(sdl.findall(qn('c:dLbl'))), dl)
        if pdl is not None and pdl.find(qn('c:numFmt')) is not None: pdl.find(qn('c:numFmt')).set('formatCode', top[0])
        if len(pl.series) == 1 and pl._element.tag not in (qn('c:pieChart'), qn('c:doughnutChart')):
            ch.has_legend = False                          # ชุดเดียว: คำอธิบายสีซ้ำหัวรอง/หัวคอลัมน์ ("ยอดขาย (บาท)") ไม่ต้องมี

def drop_empty(slide, sw=13.333, sh_=7.5):
    """ป้าย/ปุ่มที่ไม่มีข้อความ (ช่องที่เอกสารไม่มี หรือข้อความตัวอย่างที่ scrub ลบ) เหลือแคปซูลสีว่าง ๆ บนสไลด์
    ลบเฉพาะคู่ "กล่องข้อความว่างที่ไม่มีพื้น" + "พื้นสีเล็ก ๆ ตำแหน่งเดียวกันพอดี" (ปุ่ม ป้าย)
    พื้นหลัง/แผงใหญ่ (สูงเกิน 1 นิ้ว หรือกว้างเกินครึ่งสไลด์) และกล่องที่มีพื้นเอง ไม่แตะ"""
    E = 914400; sh = list(slide.shapes); tol = E * 0.03
    same = lambda a, b: all(abs(int(getattr(a, k)) - int(getattr(b, k))) <= tol for k in ('left', 'top', 'width', 'height'))
    def nofill(x):
        try: return x.fill.type is None or x.fill.type == 5    # ไม่มีพื้น / พื้นโปร่ง (MSO_FILL.BACKGROUND)
        except Exception: return True
    small = lambda x: x.height <= E * 1.0 and x.width <= E * sw * 0.5
    for e in [x for x in sh if x.has_text_frame and not x.text_frame.text.strip() and nofill(x) and small(x)]:
        bg = [x for x in sh if x is not e and same(x, e) and small(x) and not (x.has_text_frame and x.text_frame.text.strip())
              and not getattr(x, 'image', None) and x.shape_type != 13]
        if len(bg) == 1:
            for x in bg + [e]:
                if x._element.getparent() is not None: x._element.getparent().remove(x._element)
    # แถบเมนู/แท็บของดีไซน์ (แถบเตี้ยที่ข้างในมีแต่กล่องข้อความว่างหลายกล่องกับเส้นคั่น) หลังลบคำตัวอย่างเหลือกรอบเปล่า: เอาออกทั้งแถบ
    sh = [x for x in slide.shapes]
    inside = lambda x, b: x.left >= b.left - 1e4 and x.top >= b.top - 1e4 and x.left + x.width <= b.left + b.width + 1e4 and x.top + x.height <= b.top + b.height + 1e4
    for b in [x for x in sh if x.height <= E * 0.8 and x.width >= E * 2 and x.shape_type == 1 and not (x.has_text_frame and x.text_frame.text.strip())]:
        kids = [x for x in sh if x is not b and inside(x, b)]
        empt = [x for x in kids if x.has_text_frame and not x.text_frame.text.strip() and x.shape_type == 17]
        if len(empt) >= 2 and all(x in empt or x.shape_type == 9 for x in kids):
            for x in [b] + kids:
                if x._element.getparent() is not None: x._element.getparent().remove(x._element)

_norm = lambda x: re.sub(r'[^\w\u0E00-\u0E7F]', '', x)   # เทียบเฉพาะตัวอักษร ลาย [ ] · ของดีไซน์ไม่นับ

def tidy(slide, d):
    """(1) ชื่อเดียวกันสองกล่อง (ป้ายเล็กหัวกระดาษ + หัวเรื่องใหญ่) เหลือกล่องใหญ่ (2) รายการข้อเดียว ไม่มีเลข 01"""
    by = {}
    for sh in slide.shapes:
        if not sh.has_text_frame or not sh.text_frame.text.strip(): continue
        r = next((r for p in sh.text_frame.paragraphs for r in p.runs if r.font.size), None)
        by.setdefault(sh.text_frame.text.strip(), []).append((r.font.size.pt if r else 0, sh))
    for t, xs in by.items():
        if len(xs) > 1 and len(t) > 3:
            big = max(z for z, _ in xs)
            for z, sh in xs:
                if z < big * 0.6:
                    for p in sh.text_frame.paragraphs:
                        for r in p.runs: r.text = ''
    its = d.get('items')
    if isinstance(its, list) and len(its) == 1:
        mine = {x.strip() for x in strings(d)}
        for sh in slide.shapes:
            if sh.has_text_frame and re.fullmatch(r'0?1\.?', sh.text_frame.text.strip()) and sh.text_frame.text.strip() not in mine:
                for p in sh.text_frame.paragraphs:
                    for r in p.runs: r.text = ''

def scrub(slide, mine):
    """ลบข้อความตัวอย่างที่ดีไซน์ฝังไว้ (ป้ายหัวกระดาษ "ข้อเสนอโครงการ 8 ต.ค. 2570", ชื่อบริษัทสมมติ)
    ลายดีไซน์ยังอยู่ครบ หายแค่คำที่ไม่ใช่ของลูกค้า  คืนรายการที่ลบ"""
    src = _norm(''.join(mine)); gone = []
    for sh in slide.shapes:
        if not sh.has_text_frame: continue
        for p in sh.text_frame.paragraphs:
            k = _norm(''.join(r.text for r in p.runs))
            if not k or k in ALLOW or k in src: continue
            if re.search(r'[A-Za-z\u0E01-\u0E2E]{2}', k) or re.search(r'\d[\d,\.]{2,}', k):
                gone.append(''.join(r.text for r in p.runs).strip())
                for r in p.runs: r.text = ''
    return gone

# ══ 6. เลือก layout ในชุด → สร้างไฟล์ ═══════════════════════════════════════

_DECKS = {}
def deck_of(slug):
    """ไฟล์ต้นฉบับของชุด (META + SEQ) จาก decks/*.py"""
    if not _DECKS:
        for p in sorted(glob.glob(f'{K}/decks/*.py')):
            ns = {}
            try: exec(open(p, encoding='utf-8').read(), ns)
            except Exception: continue
            if 'META' in ns and 'SEQ' in ns: _DECKS[ns['META']['slug']] = ns
    return _DECKS.get(slug)

def slug_of(no):
    e = next(x for x in json.load(open(f'{HUB}/library/data.json')) if str(x['no']) == str(no))
    return e['slug'], e

CONT = {'ซึ่ง', 'และ', 'หรือ', 'โดย', 'เพื่อ', 'จึง', 'แต่', 'ที่', 'ของ', 'ใน', 'กับ', 'คือ', 'เป็น', 'ให้', 'จาก', 'ถึง', 'ได้',
        'แล้ว', 'ด้วย', 'อีก', 'ทั้ง', 'ตาม', 'เมื่อ', 'จน', 'หรือไม่', 'ก็', 'จะ', 'ไป', 'มา', 'คิดเป็น', 'รวม', 'เท่ากับ',
        'ลดลง', 'เพิ่มขึ้น', 'สูงขึ้น', 'เหลือ', 'มาจาก', 'เริ่ม', 'ยัง', 'ไม่', 'ต้อง', 'อยู่', 'กว่า', 'มากกว่า', 'น้อยกว่า',
        'สูงกว่า', 'ต่ำกว่า', 'ภายใน', 'สำหรับ', 'เพราะ', 'เนื่องจาก', 'ทำให้', 'แม้', 'หาก', 'ถ้า', 'เช่น', 'ตั้งแต่',
        'เฉลี่ย', 'เพิ่ม', 'ลด', 'โดยเฉลี่ย', 'จำนวน', 'ประมาณ', 'ชั้น', 'ระดับ', 'ประจำ', 'ทั้งหมด', 'เสร็จ', 'แล้วเสร็จ'}
# ขึ้นต้นด้วยคำเหล่านี้ = ต่อจากความก่อน (เทียบต้นคำ เพราะตัวตัดคำอาจแยก "สูงกว่าค่าเฉลี่ย" เป็น "สูง")
SUBJ = ('วิชา', 'งบ', 'ขอให้', 'มอบหมาย', 'ที่ประชุม', 'ผลสอบ', 'ผลการ', 'ผู้อำนวยการ', 'ครู', 'นักเรียน', 'โรงเรียน', 'ฝ่าย', 'เริ่ม', 'เรื่อง', 'ผู้ปกครอง', 'ประธาน', 'คณะ', 'สำนักงาน', 'ทัศนศึกษา',
        'ด้าน', 'แผน', 'ระยะที่', 'ปีหน้า', 'ปีต่อไป', 'เดือนหน้า', 'ภาคเรียนหน้า', 'ครั้งหน้า', 'ครั้งต่อไป')   # ขึ้นเรื่องใหม่ (ช่วงเวลาถัดไป = เรื่องใหม่ ไม่ใช่ส่วนต่อของงบ/ผล)
CONT_PRE = ('และ', 'ซึ่ง', 'ใกล้เคียง', 'แบ่งเป็น', 'เท่ากัน', 'ส่วนที่เหลือ', 'โดย', 'เพื่อ', 'จึง', 'แต่', 'หรือ', 'สูงกว่า', 'ต่ำกว่า', 'มากกว่า', 'น้อยกว่า', 'เสร็จ', 'ลดลง',
            'เพิ่มขึ้น', 'คิดเป็น', 'เฉลี่ย', 'เนื่องจาก', 'เพราะ', 'ตั้งแต่', 'จนถึง', 'ภายใน', 'สำหรับ', 'เท่ากับ')
NOUN_PRE = ('ที่ประชุม', 'ที่ปรึกษา', 'ที่ดิน', 'ที่พัก', 'ที่อยู่', 'ที่มา', 'ที่ทำการ')   # คำนามที่ขึ้นต้นด้วย "ที่" (ตัวตัดคำของเบราว์เซอร์แยกเป็น "ที่"+...)
cont = lambda w: not w.startswith(NOUN_PRE) and ((wordsx(w) or [w])[0] in CONT or w.startswith(CONT_PRE) or w.startswith('ๆ'))   # คำต่อความ ห้ามตัดหน้าคำเหล่านี้
TAIL = {'ถึง', 'จาก', 'และ', 'หรือ', 'ของ', 'ใน', 'กับ', 'ที่', 'ซึ่ง', 'โดย', 'เพื่อ', 'แต่', 'คือ', 'เป็น', 'ตาม', 'ตั้งแต่',
        'สำหรับ', 'ภายใน', 'เช่น', 'ทั้ง', 'จน', 'เมื่อ', 'ว่า'}                                 # ห้ามจบข้อด้วยคำเหล่านี้
UNIT = (r'(?:%|฿|บาท|คน|ราย|ครั้ง|วัน|เดือน|ปี|ชั่วโมง|หน้า|ล้าน|แห่ง|โรงเรียน|ชิ้น|เล่ม|คะแนน|นาที|พ\.ศ|ค\.ศ'
        r'|มกราคม|กุมภาพันธ์|มีนาคม|เมษายน|พฤษภาคม|มิถุนายน|กรกฎาคม|สิงหาคม|กันยายน|ตุลาคม|พฤศจิกายน|ธันวาคม'
        r'|ม\.ค|ก\.พ|มี\.ค|เม\.ย|พ\.ค|มิ\.ย|ก\.ค|ส\.ค|ก\.ย|ต\.ค|พ\.ย|ธ\.ค)')   # ตัวเลขกับหน่วย/เดือนอยู่ด้วยกันเสมอ

def numunit(cur, w):
    """cur จบด้วยตัวเลข และ w ขึ้นด้วยหน่วย (หรือคำไทยสั้น ๆ ที่ไม่ใช่คำขึ้นเรื่อง ถือเป็นหน่วย เช่น เปอร์เซ็นต์ ห้อง) = ห้ามตัดตรงนี้"""
    if not re.search(r'\d\s*$', cur): return False
    w = (w.strip().split(' ') or [''])[0]                 # ทั้งคำถึงเว้นวรรค (ไม่พึ่งตัวตัดคำ ซึ่งในเบราว์เซอร์อาจแยก "เปอร์เซ็นต์")
    return bool(re.match(UNIT, w)) or (bool(re.match(r'[\u0e01-\u0e2e\u0e40-\u0e44]', w)) and len(w) <= 12 and not (w.startswith(SUBJ) and w not in SUBJ))   # "7 เรื่อง" = ลักษณนาม ไม่ใช่คำขึ้นเรื่อง

FAM = {'วิชา': 'สอบ', 'ผลสอบ': 'สอบ', 'งบ': 'งบ', 'เริ่ม': 'งบ', 'ระยะที่': 'ระยะ'}   # ข้อที่เป็นเรื่องเดียวกัน (ผลสอบหลายวิชา) ควรอยู่หน้าเดียวกัน

def groups(ps):
    """เลขกลุ่มเรื่องของแต่ละข้อ: ข้อที่ขึ้นต้นเรื่องใหม่เปลี่ยนกลุ่ม ข้อที่ไม่มีคำขึ้นเรื่องอยู่กลุ่มเดิม"""
    out, g, last = [], 0, None
    for p_ in ps:
        k = next((FAM.get(x, x) for x in SUBJ if p_.startswith(x)), None)
        if out and k is not None and k != last: g += 1
        if k is not None: last = k
        out.append(g)
    return out

def gchunk(ps, n=5):
    """แบ่งข้อเป็นหน้า ไม่แยกกลุ่มเรื่องเดียวกันข้ามหน้า (เว้นกลุ่มยาวเกินหน้า) และไม่ปนกลุ่มถ้าแยกได้"""
    gs = groups(ps); grp = []
    for p_, g in zip(ps, gs):
        if grp and grp[-1][0] == g: grp[-1][1].append(p_)
        else: grp.append((g, [p_]))
    pages, solo = [], False
    for _, xs in grp:
        if len(xs) == 1 and solo and len(pages[-1]) < 3: pages[-1].append(xs[0]); continue   # ข้อเดี่ยวหลายเรื่องรวมหน้าได้ ไม่ให้หน้าโล่งทีละข้อ
        for part in chunk(xs, n): pages.append(list(part))
        solo = len(xs) == 1
    return pages

def points(t, hi=170):
    """บรรทัด/ย่อหน้ายาว → ข้อ: ตัดที่ท้ายประโยคหรือก่อนคำขึ้นเรื่องใหม่ (วิชา งบ เรื่อง ที่ประชุม ...) เท่านั้น
    คำเทียบ/อธิบายต่อท้ายข้อเดิม หัวเรื่องสั้น ๆ ("เรื่องค่าใช้จ่าย") ไปอยู่ต้นข้อถัดไป ไม่ค้างท้ายข้อ  ข้อยาวเกิน hi แบ่งที่รอยต่อความ"""
    out, cur = [], ''
    lead = (wordsx(t.split()[0]) or [''])[0] if t.split() else ''
    rep = len(lead) >= 3 and sum(1 for w in t.split() if w.startswith(lead) or w.startswith('และ' + lead)) >= 2   # ข้อขนาน (เพื่อ... เพื่อ... และเพื่อ...)
    for w in t.split():
        newsub = ((w.startswith(SUBJ) and not cont(w)) or (rep and (w.startswith(lead) or w.startswith('และ' + lead)))) and not numunit(cur, w)
        if cur and len(cur) >= 30 and (re.search(r'[.!?]$', cur) or newsub):
            out.append(cur); cur = w
        else: cur = f'{cur} {w}' if cur else w
    if cur: out.append(cur)
    res = []
    for x in out:
        if 'แบ่งเป็น' in x and len(re.findall(r'\d[\d,]*\s*บาท', x)) >= 3 and len(x) <= 260: res.append(x); continue
        m_ = re.search(r' (ได้แก่|ดังนี้|คือ) ', x)
        if m_ and len(x) <= 260:                           # รายการที่ขึ้นด้วย ได้แก่/ดังนี้/คือ เป็นก้อนเดียว ไม่แบ่งหน้า
            e_ = re.search(r' และ\S+', x[m_.end():]); k = m_.end() + e_.end() if e_ else len(x)
            if len(x) > hi and len(x) - k >= 30: res += [x[:k]] + points(x[k + 1:], hi); continue   # ข้อยาว: ก้อนรายการจบที่ "และ<ข้อสุดท้าย>" ความที่ตามมาเป็นข้อใหม่
            res.append(x); continue
        if len(x) > hi:                                    # ประโยคยาวสองเรื่อง: ตัดที่ "แต่" ก่อน (ไม่ใช่ "แต่ละ")
            m = [k.start() for k in re.finditer(r' แต่(?!ละ)', x) if 40 <= k.start() <= len(x) - 40 and x[k.start() + 4:].startswith(SUBJ)]   # แต่ + เรื่องใหม่ (แต่วิชา...) เท่านั้น
            if m:
                k = min(m, key=lambda i: abs(i - len(x) / 2)); res += points(x[:k], hi) + points(x[k + 1:], hi); continue
        res += pieces(clauses(x), lo=40, hi=hi) if len(x) > hi else [x]
    return res

def clauses(t):
    """ตัดเฉพาะท้ายประโยค (. ! ?) หรือเว้นวรรคที่คำถัดไปขึ้นความใหม่ ไม่ตัดหน้าคำเชื่อม (ซึ่ง และ โดย ...) ไม่แยกตัวเลขกับหน่วย"""
    cl, cur = [], ''
    for w in t.split():
        tail = (words(cur.split()[-1]) or [''])[-1] if cur else ''
        brk = cur and (re.search(r'[.!?]$', cur) or (not cont(w) and not re.search(r'ที่ \d+$', cur) and tail not in TAIL and not numunit(cur, w)
                                                       and not re.search(r'\d', w) and not re.match(r'[(A-Za-z]', w) and not re.search(r'[(:]$', cur)))
        if brk: cl.append(cur); cur = w
        else: cur = f'{cur} {w}' if cur else w
    return cl + [cur] if cur else cl

def pieces(cl, lo=35, hi=130):
    """รวมความสั้นเข้ากับความก่อนหน้า (ความสั้นที่ตามมามักเป็นส่วนต่อ) ให้แต่ละข้อยาวพอ ๆ กัน ไม่แต่งคำ ไม่ทิ้งคำ"""
    out = []
    for c in cl:
        new = c.startswith(SUBJ)                           # เรื่องใหม่ (วิชาอื่น งบ มติ) ไม่รวมกับข้อก่อน ตัวเลขสองเรื่องจะไม่ปนกัน
        if out and not new and len(c) < 30 and len(out[-1]) + len(c) + 1 <= hi * 1.4: out[-1] += ' ' + c      # เศษสั้น ๆ ต่อท้ายข้อก่อน
        elif out and (not new or len(out[-1]) < 30) and len(out[-1]) < lo and len(out[-1]) + len(c) + 1 <= hi: out[-1] += ' ' + c   # หัวเรื่องสั้นค้างท้าย → ไปกับข้อถัดไป
        else: out.append(c)
    if len(out) > 1 and len(out[-1]) < lo and not out[-1].startswith(SUBJ) and len(out[-2]) + len(out[-1]) + 1 <= hi * 1.3: last = out.pop(); out[-1] += ' ' + last
    return out

def analyze(path, name=None):
    """ไฟล์ลูกค้า → ชื่อเรื่อง + รายการแผ่น (ยังไม่เลือก layout)"""
    blocks = read_any(path); INFO.clear(); INFO['sections'] = 0
    body = [b for b in blocks if b[0] != 'h']
    if len(body) == 1 and body[0][0] == 'p' and len(body[0][1]) >= 120:   # วางมาเป็นย่อหน้ายาวย่อหน้าเดียว
        pall = points(body[0][1], hi=170); hs = [b for b in blocks if b[0] == 'h']
        ttl = hs[0][2] if hs else pall.pop(0)                  # ไม่มีหัวเรื่อง = ข้อแรก (ถึงคำขึ้นเรื่องถัดไป) เป็นชื่อเรื่อง
        if not hs and len(ttl) > 60:                           # ความแรกยาวเกินปก: ชื่อเรื่อง = ความแรกเท่านั้น ที่เหลือกลับไปเป็นข้อในหน้าเนื้อหา (ไม่ใส่ก้อนยาวบนปก)
            c0 = clauses(ttl)[0]
            cut = len(c0) if 12 <= len(c0) <= 70 and len(c0) < len(ttl) else next((m.start() for m in re.finditer(' ', ttl) if 20 <= m.start() <= 60
                        and (wordsx(ttl[m.start() + 1:]) or [''])[0] not in CONT and not re.match(UNIT, ttl[m.start() + 1:])
                        and not re.search(r'\d', ttl[m.start() + 1:].split(' ')[0])), None)
            if cut: ttl, rest = ttl[:cut], ttl[cut + 1:]; pall[:0] = points(rest, hi=170)
        ps = pall                                              # ข้อละเรื่อง ตัดที่ท้ายประโยค/คำขึ้นเรื่องเท่านั้น
        if len(ps) >= 2:
            want = [dict(kind='cover', t=ttl, _sec=None)] + [dict(kind='list', t='', ordered=False, note='', items=[(x,) for x in part], _sec=0) for part in gchunk(ps)]   # เป็นรายการ ไม่ทำการ์ดตัวเลข (ป้ายจะเป็นประโยคเว้าแหว่ง)
            if len(want) > MAXSLIDES: NOTES.append(f'เอกสารยาว ทำเป็นสไลด์ได้สูงสุด {MAXSLIDES} หน้า ส่วนที่เหลือยังไม่ได้ทำเป็นสไลด์'); want = want[:MAXSLIDES]
            return ttl, want
    title, secs = sections(blocks)
    INFO['sections'] = len([x for x in secs if x['t']])
    CLOSE = ('ขอแสดงความนับถือ', 'ลงชื่อ')
    closing = []
    for x in secs:                                         # คำลงท้ายจดหมาย + บรรทัดชื่อ/ตำแหน่งสั้น ๆ ที่ตามมา = หน้าท้าย ไม่ใช่ข้อ
        keep, on = [], False
        for b in x['body']:
            t_ = b[1] if b[0] in ('p', 'li') else ''
            if t_.startswith(CLOSE) or (on and t_ and len(t_) <= 40 and not re.search(r'\d', t_)): closing.append(t_); on = True
            else: keep.append(b); on = False
        x['body'] = keep
    cov_s = ''
    b0 = secs[0]['body'] if secs and not secs[0]['t'] else []
    if b0 and b0[0][0] == 'p' and b0[0][1].startswith('เรียน '):
        # ข้อความนำบนปก = บรรทัด "เรียน ..." + บรรทัดเปิดหนึ่งบรรทัดที่จบด้วย "ดังนี้" เท่านั้น ที่เหลือเป็นเนื้อหาตามปกติ
        k = 2 if len(b0) > 1 and b0[1][0] == 'p' and len(b0[1][1]) <= 80 and re.search(r'ดังนี้\s*:?$', b0[1][1]) else 1
        cov_s = ' '.join(b[1] for b in b0[:k])
        if b0[k:]: secs[0] = dict(secs[0], body=b0[k:])
        else: secs = secs[1:]
        INFO['sections'] = len([x for x in secs if x['t']])
    for x in secs:                                         # ตารางที่ไม่มีหัวข้อ (ชีตเดียว ชื่อชีตเป็นชื่อเรื่อง): ใช้ชื่อเรื่องเป็นหัวหน้า ไม่ปล่อยหน้าไม่มีชื่อ
        if not x['t'] and title and any(b[0] == 'table' for b in x['body']): x['t'] = title
    ttl = title or os.path.splitext(name or os.path.basename(path))[0]
    # _sec = หัวข้อที่หน้านี้มาจาก (เลขลำดับในเอกสาร) สารบัญผูกกับหน้าด้วยเลขนี้ ไม่ใช่ชื่อ (หน้าที่ใช้ประโยคเป็นชื่อก็ไม่หลุด)
    want = [dict(kind='cover', t=ttl, _sec=None, **({'s': cov_s} if cov_s else {}))]
    # สารบัญปิดไว้ตั้งต้น ลูกค้ากดใส่เอง (ไอซ์ 29 ต.ค. 2569): เตรียมไว้ใน want แบบ _off (plan ข้าม) ชื่อหัวข้อตามการแก้ไปด้วย add_agenda เปิดใช้
    ix = [i for i, s in enumerate(secs) if s['t']][:6]
    if len(ix) >= 2: want.append(dict(kind='agenda', t='สารบัญ', items=[(secs[i]['t'],) for i in ix], _secs=ix, _sec=None, _off=1))
    for i, s in enumerate(secs): want += [dict(x, _sec=i) for x in shapes(s)]
    if closing: want.append(dict(kind='statement', t=' '.join(closing), _sec=None))
    cap = MAXSLIDES + (len(ix) >= 2)
    if len(want) > cap:
        NOTES.append(f'เอกสารยาว ทำเป็นสไลด์ได้สูงสุด {MAXSLIDES} หน้า ส่วนที่เหลือยังไม่ได้ทำเป็นสไลด์'); want = want[:cap]
    return ttl, want

def pool_of(slug):
    m = deck_of(slug)
    pool = [(nm, ex, *kind_of(nm, ex, i, len(m['SEQ']))) for i, (nm, ex) in enumerate(m['SEQ'])]
    LAYKIND.update({x[0]: x[2] for x in pool})
    return dict(m['META']), pool

def candidates(c, pool, used):
    cand = []
    for nm, ex, kd, n_ex, slots in pool:
        pen = FIT.get(c['kind'], {}).get(kd)
        if pen is None: continue
        n_c = len(c.get('items') or c.get('rows') or [])
        if c.get('_lead') and 'note' not in ex and 's' not in ex: continue   # ข้อความนำ (ยอดรวม) ต้องมีที่วาง
        if c['kind'] == 'list' and re.search(r'(step|process|arrow|roadmap|journey)', nm) and any('บาท' in ' '.join(x) for x in c.get('items') or []): continue   # รายการราคาไม่ใช่ขั้นตอน ไม่ใช้หน้าตาลูกศร
        if 'quote' in nm and not re.search(r'["“”«»]', ''.join(strings({k: c.get(k) for k in ('t', 's', 'items')}))): continue   # กรอบคำพูดเฉพาะคำพูดจริง (มีเครื่องหมายคำพูด)
        if len(c.get('items') or []) > CAP.get(nm, 99) or len(c.get('rows') or []) > ROWCAP.get(nm, 99): continue
        cand.append((pen * 10 + abs(n_c - n_ex) * 2 + used.get(nm, 0) * 20, nm, ex, slots))   # ใช้ซ้ำโดนโทษแรงขึ้น ให้หน้าตาหลากหลาย
    return sorted(cand, key=lambda x: x[0])

def try_one(nm, ex, slots, c, M):
    """คืน (dict, ปัญหา)  dict=None ถ้าใส่ไม่ได้"""
    d = fill(nm, ex, slots, c)
    if d is None: return None, 'โครงไม่ตรง'
    if c['kind'] == 'agenda' and slots and slots != (str,) and c.get('items') and all(len(x) == 1 for x in c['items']) and sum(t is str for t in slots) > 1 \
            and not c.get('_slot') and overflow(nm, d, M):    # ข้อเดียวต่อแถวลงช่องแรกไม่ได้ ลองช่องที่สอง
        d2, bad2 = try_one(nm, ex, slots, dict(c, _slot=1), M)
        if d2 is not None: return d2, ''
    if c['kind'] == 'cover' and 't1' in d and 't2' in d and not d.get('t2') and overflow(nm, d, M):
        # ปกที่แยกชื่อเรื่องเป็นบรรทัด t1/t2 (ตัวใหญ่ บรรทัดละกล่อง): แบ่งชื่อที่รอยต่อคำ ถ้ายังยาว ส่วนท้ายลงหัวรอง
        ws = wordsx(d['t1']); slots_ = ['t1', 't2'] + ([] if d.get('s') else ['s'])
        blank = {k: '' for k in slots_}; got = {}; i = 0
        for k in slots_:                                   # ใส่คำให้เต็มบรรทัดทีละช่อง (วัดจริงทุกครั้ง) ช่องสุดท้ายรับที่เหลือ
            if k == slots_[-1]: got[k] = ''.join(ws[i:]).strip(); break
            j = i + 1
            while j < len(ws) and not overflow(nm, {**d, **blank, **got, k: ''.join(ws[i:j + 1]).strip()}, M): j += 1
            got[k] = ''.join(ws[i:j]).strip(); i = j
        d2 = {**d, **blank, **got}
        if i >= len(ws) or got.get(slots_[-1]):
            if not overflow(nm, d2, M): d = d2
    if c['kind'] == 'cover':                               # ปกย่อขนาดหัวเรื่องได้ ลองไล่ลงก่อนเปลี่ยน layout
        for z in (None, 40, 36, 32, 28, 24):
            if z: d['tsz'] = z
            if not overflow(nm, d, M): break
        if overflow(nm, d, M) and d.get('t') and 's' in d and not d.get('s'):
            # หัวเรื่องปกยาวเกิน (layout ไม่มีย่อตัว): ส่วนท้ายของชื่อเรื่องลงหัวรองบนปก ตัดที่รอยต่อคำ คำครบ
            ws = wordsx(d['t'])
            for k in range(len(ws) - 1, 0, -1):
                a_, b_ = ''.join(ws[:k]).strip(), ''.join(ws[k:]).strip()
                if len(a_) < 12 or cont(b_) or (wordsx(a_) or [''])[-1].strip() in TAIL: continue
                d2 = dict(d, t=a_, s=b_)
                if not overflow(nm, d2, M): d = d2; break
    bad = overflow(nm, d, M)
    return (None, bad[0]) if bad else (d, '')

def one(c, xs):
    """ข้อที่แบ่งออกมา  เหลือข้อเดียว → ลองหน้าที่มีหัวเรื่องจริงก่อน (หัวข้อตัวใหญ่ รายละเอียดเป็นเนื้อ) แล้วค่อยลงหน้าข้อความเด่น"""
    if len(xs) > 1 or c['kind'] not in ('list', 'pairs', 'qa', 'timeline') or (c.get('t') and not c.get('_one')):
        return dict(c, items=xs, _one=1) if len(xs) == 1 else dict(c, items=xs)
    x = xs[0]
    if c.get('t') and c.get('_one') == 2 and c['kind'] != 'qa':   # หัวข้อตัวใหญ่ + รายละเอียดเป็นข้อความรอง (หน้าคั่น/ข้อความเด่น)
        return dict(kind='divider', t=c['t'], s=(' ' if c.get('_tbl') else ': ').join(x), num='', _hd=x, _tbl=c.get('_tbl'), _sec=c.get('_sec'))
    if c['kind'] == 'qa': return dict(kind='statement', t=x[1], s=x[0])
    return dict(kind='statement', t=(' ' if c.get('_tbl') else ': ').join(x), s=c['t'])   # คืนเครื่องหมาย : ให้ตรงต้นฉบับ (คู่จากตารางไม่มี :)

def plan(want, slug, on_step=None):
    """เลือก layout ทีละแผ่น  คืน (META, [dict(c, layout, d)], log)"""
    it = plan_iter(want, slug)
    try:
        while True:
            st = next(it)
            if on_step: on_step(*st)
    except StopIteration as e:
        return e.value

def plan_iter(want, slug):
    """เหมือน plan แต่ yield (เสร็จ, ทั้งหมด, ชื่อ layout ล่าสุด) ทุกแผ่น ให้เว็บวาดความคืบหน้าระหว่างคิด
    (Pyodide รันบนเธรดหน้าเว็บ ถ้าไม่หยุดเป็นช่วง ๆ จอจะค้างจนเสร็จ)"""
    M, pool = pool_of(slug)
    want = [c for c in want if not c.get('_off')]; out, log, used = [], [], {}   # _off = สารบัญที่ลูกค้ายังไม่ได้กดใส่
    want0, rescued, capped, rnd = list(want), False, False, 0
    last = None; steps = 0
    while want or not rescued:
        steps += 1
        if steps > 300 + 60 * len(want0):                  # กันวนไม่จบ: หยุด แล้วให้ตัวตรวจคำที่หายบอกลูกค้า
            want = []; rescued = True; break
        if not want:                                       # จบรอบ: ตรวจว่าทุกคำของลูกค้าอยู่ในสไลด์จริง ขาดตรงไหนเติมเป็นรายการ (สองรอบ)
            if capped: rescued = True; break
            want = rescue(want0, out, M, rnd); rnd += 1; rescued = rnd >= 2
            if want: log.append((dict(kind='list', t=''), None, [], f'เติมข้อความที่ยังไม่อยู่ในสไลด์ {len(want)} หน้า'))
            continue
        if len(out) >= MAXSLIDES:                          # เพดานทุกทาง (หน้าที่แบ่งเพิ่มระหว่างจัดก็นับ) หยุดจัดทันที บอกลูกค้าตรง ๆ
            if not any(n.startswith('เอกสารยาว') for n in NOTES): NOTES.append(f'เอกสารยาว ทำเป็นสไลด์ได้สูงสุด {MAXSLIDES} หน้า ส่วนที่เหลือยังไม่ได้ทำเป็นสไลด์')
            capped = True; want = []; rescued = True; break
        yield (len(out), min(len(out) + len(want), MAXSLIDES), out[-1]['layout'] if out else '')
        c = want.pop(0)
        if '_sec' not in c and last is not None: c = dict(c, _sec=last)   # หน้าที่แบ่ง/เปลี่ยนชนิดออกมา อยู่หัวข้อเดิม
        last = c.get('_sec', last)
        cand = candidates(c, pool, used)
        why, got = [], None
        for sc, nm, ex, slots in cand:
            d, bad = try_one(nm, ex, slots, c, M)
            if d is None: why.append(f'{nm} ไม่ผ่าน: {bad}'); continue
            got = (nm, d); break
        if not got and c['kind'] in ('list', 'pairs', 'statement', 'divider', 'stat', 'timeline', 'qa') and len(c.get('items') or []) <= 5:
            for z in (0.85, 0.72):                        # ตัวเต็มใส่ไม่ได้ทุกหน้าตา: ย่อตัวหนังสือก่อน (ไม่ต่ำกว่า 10.5pt) ดีกว่าตัดกลางความ
                got = next(((nm, d) for _, nm, ex, slots in cand for d, _b in [try_one(nm, ex, slots, dict(c, _bsz=z), M)] if d is not None), None)
                if got:
                    why.append(f'ย่อตัวหนังสือ {z}')
                    if SMALLNOTE not in NOTES: NOTES.append(SMALLNOTE)   # ย่อเมื่อไหร่บอกในฟองจบ   # ย่อมาก (ไม่ใช่ย่อนิดหน่อย) ถึงบอกในฟองจบ
                    break
        if not got and c['kind'] == 'cover' and cand:      # ปกต้องมีเสมอ ล้นก็ใส่แล้วฟ้องให้คนแก้ชื่อ
            d = fill(cand[0][1], cand[0][2], cand[0][3], c)
            if d is not None: got = (cand[0][1], d); why.append('ใส่ปกทั้งที่ไม่ผ่าน')
        if not got and c['kind'] == 'stat' and c.get('raw'):  # ชุดนี้ไม่มีการ์ดตัวเลขที่รับได้ → ลงเป็นรายการ ข้อความเดิม
            want.insert(0, dict(kind='list', t=c['t'], note=c.get('note', ''), items=[(x,) for x in c['raw']], **{k: 1 for k in ('_lead', '_leadend') if c.get(k)}))
            log.append((c, None, why[-3:], 'ลงเป็นรายการแทน')); continue
        if not got and c.get('_lead') and c['kind'] in ('list', 'pairs'):   # ไม่มีหน้าตาที่วางยอดรวมนำได้: กลับเป็นข้อแรกตามเดิม (ไม่ทิ้งเป็นหน้าเดี่ยว)
            base = {k: v for k, v in c.items() if k != '_lead'}
            pad = lambda x: [(x,) + ('',) * (len(c['items'][0]) - 1)]
            base.update(note='', items=(list(c['items']) + pad(c['note'])) if c.get('_leadend') else (pad(c['note']) + list(c['items'])))
            want.insert(0, base); log.append((c, None, why[-3:], 'ยอดรวมกลับเป็นข้อแรก')); continue
        n_rw = len(c.get('rows') or [])
        if not got and n_rw > 2 and c['kind'] in ('table', 'chart') and any(p[2] in ('table', 'chart') for p in pool):   # ตารางยาวเกินที่ชุดนี้วาดได้ → แบ่งครึ่ง หัวตารางซ้ำ
            def cut(a, b):
                x = {k: v for k, v in c.items() if k != '_share'}   # ครึ่งหนึ่งของสัดส่วนไม่ใช่ทั้งก้อนแล้ว
                x['rows'] = c['rows'][a:b]
                if 'cats' in c:
                    x.update(cats=c['cats'][a:b], series=[(n, v[a:b]) for n, v in c['series']], _nf=[f[a:b] for f in c['_nf']])
                    if 'vals' in c: x['vals'] = c['vals'][a:b]
                return x
            # แถวที่หน้าเดียวรับได้จริง แล้วแบ่งเท่า ๆ กัน (ไม่เหลือหน้าแถวเดียวถ้าแบ่งให้สมดุลได้)
            fitk = next((k for k in range(n_rw - 1, 1, -1) if any(try_one(nm, ex, sl, cut(0, k), M)[0] is not None for _, nm, ex, sl in candidates(cut(0, k), pool, used))), 2)
            pages_ = -(-n_rw // fitk); per = -(-n_rw // pages_)
            want[:0] = [cut(a, min(a + per, n_rw)) for a in range(0, n_rw, per)]
            log.append((c, None, why[-3:], f'แบ่งตารางเป็น {pages_} หน้า หน้าละ {per} แถว')); continue
        if not got and c['kind'] in ('chart', 'table') and len(c['head']) >= 2:   # ไม่มีตาราง/กราฟ → คู่ ช่องแรก: ที่เหลือ
            hd = c['head']                                 # หลายคอลัมน์: ใส่ชื่อคอลัมน์ของลูกค้าหน้าค่า ไม่ให้ตัวเลขติดกันอ่านไม่ออก
            head_pair = [(hd[0], ' '.join(hd[1:]))] if len(hd) <= 2 and any(hd) else []   # สองคอลัมน์: หัวตารางเป็นคู่แรก ไม่ทิ้งชื่อคอลัมน์
            rows = [(r[0], (' '.join(x for x in r[1:] if x) if len(hd) <= 2 else
                            ' '.join(f'{h} {x}' for h, x in zip(hd[1:], r[1:]) if x))) for r in c['rows']]   # เว้นวรรคอย่างเดียว ไม่เติมเครื่องหมาย
            rows = head_pair + rows
            want[:0] = [dict(kind='pairs', t=c['t'], note=c.get('note', ''), items=part, _tbl=1) for part in chunk(rows)]
            log.append((c, None, why[-3:], 'ลงเป็นคู่หัว-ค่าแทน')); continue
        n_it = len(c.get('items') or [])
        if not got and c['kind'] == 'list' and (not c.get('t') or len(c['items']) <= 2) and not c.get('_cl') and not c.get('_fb') and not c.get('_pk') \
                and any(len(x[0]) > 40 for x in c['items']):
            # ย่อหน้ายาวที่ไม่มีหัวข้อ ในชุดที่กล่องรายการเล็ก: รวมหลายข้อติดกันลงช่องข้อความยาวของหน้าข้อความเด่น
            # (ข้อความเต็มประโยค ไม่ตัดกลางความ หน้าละหลายข้อ ไม่ใช่หน้าละท่อนสั้น ๆ)
            its, i, packs, T = [x[0] for x in c['items']], 0, [], c.get('t') or ''
            m_ = []                                        # ข้อสั้น ๆ (ป.4 288) ต่อกับข้อถัดไปในบรรทัดเดียว ไม่ยืนเดี่ยวเป็นหน้า
            for x in its:
                if m_ and (len(m_[-1]) < 12 or len(x) < 12) and len(m_[-1]) + len(x) < 80: m_[-1] += '  ' + x
                else: m_.append(x)
            its = m_
            fits = lambda c_: any(try_one(nm, ex, sl, c_, M)[0] is not None for _, nm, ex, sl in candidates(c_, pool, used))
            fitsz = lambda c_: fits(c_) or fits(dict(c_, _bsz=0.85)) or fits(dict(c_, _bsz=0.72))
            # มีหัวข้อ: หัวข้อตัวใหญ่ + ข้อเป็นข้อความรอง (หน้าคั่น) ก่อน แล้วค่อยหัวข้อกับข้อรวมกันในช่องข้อความรอง (ทุกหน้ามีชื่อหัวข้อ)
            big_of = (lambda j_: dict(kind='divider', t=T, s=j_, num='', _pk=1)) if T else (lambda j_: dict(kind='statement', t=j_, _pk=1))
            small_of = (lambda j_: dict(kind='statement', t='', s=T + '\n' + j_, _pk=1)) if T else (lambda j_: dict(kind='statement', t='', s=j_, _pk=1))
            m_ = []                                        # หน้าไม่ขึ้นต้นด้วย "แต่": ข้อที่ขึ้นด้วยแต่ ต่อท้ายข้อก่อน ถ้ารวมแล้วยังลงหน้าเดียวได้
            for x in its:
                if m_ and x.startswith('แต่') and len(m_[-1]) + len(x) < 300 and fitsz(small_of(m_[-1] + ' ' + x)): m_[-1] += ' ' + x
                else: m_.append(x)
            its = m_
            k_ok = lambda kg: 2 <= kg <= 5 and fits(dict(kind='list', t=T, ordered=False, note='', items=[(x,) for x in its[i:i + kg]], _pk=1))
            while i < len(its):
                # ข้อความเด่นตัวใหญ่ (ช่อง t) ก่อน ช่องหัวรองตัวเล็ก (s) เฉพาะเมื่อตัวใหญ่ใส่ไม่ได้
                k, big = 0, True
                gs = groups(its)                           # จบหน้าที่รอยต่อเรื่องก่อน (ไม่ปนผลสอบกับมติ)
                ks = sorted(range(len(its) - i, 0, -1), key=lambda k_: (not (i + k_ == len(its) or gs[i + k_] != gs[i + k_ - 1]), -k_))
                g0 = i == 0 or gs[i] != gs[i - 1]          # หน้านี้เริ่มต้นเรื่อง
                whole = lambda k_: g0 and (i + k_ == len(its) or gs[i + k_] != gs[i + k_ - 1])
                for k_ in ks:
                    j_ = '\n'.join(its[i:i + k_])
                    if len(j_) > (300 if whole(k_) or '\n' not in j_ else 170) and not (k_ == 1 and len(j_) <= 300): continue   # หน้าละไม่เกิน ~170 ตัว อ่านได้ ยกเว้นเรื่องเดียวทั้งก้อน (ยอดรวม+ส่วนย่อย+ใช้จริง) ให้อยู่หน้าเดียวกัน
                    if fits(big_of(j_)): k, big = k_, True; break
                    if k_ > 1 and (fits(small_of(j_)) or (whole(k_) and fitsz(small_of(j_)))): k, big = k_, False; break   # ทั้งเรื่องในตัวเล็ก (ย่อได้ถึง 10.5pt) ดีกว่าแยกเรื่องเป็นตัวใหญ่สองหน้า
                if not k:
                    k = next((k_ for k_ in ks if len('\n'.join(its[i:i + k_])) <= (260 if whole(k_) else 170) and fits(small_of('\n'.join(its[i:i + k_])))), 0); big = False
                if not k and fitsz(big_of(its[i])): k, big = 1, True      # ข้อเดียวทั้งข้อ ย่อตัวหนังสือ ดีกว่าตัดกลางความ
                elif not k and fitsz(small_of(its[i])): k, big = 1, False
                if not k:                                  # ข้อนี้ยาวเกินทุกช่อง: แตกที่รอยต่อความแล้วลองต่อ
                    sub = pieces(clauses(its[i]), lo=25, hi=60)
                    if len(sub) < 2: break
                    its[i:i + 1] = sub; continue
                kg = next((k_ for k_ in range(1, len(its) - i + 1) if whole(k_)), 0)
                if g0 and k < kg and k_ok(kg):             # เรื่องเดียวทั้งก้อนใส่หน้าข้อความไม่พอ: ลงเป็นรายการหน้าเดียวทั้งก้อน ไม่แยกยอดรวมกับส่วนย่อย
                    packs.append(dict(kind='list', t=T, ordered=False, note='', items=[(x,) for x in its[i:i + kg]], _pk=1, _sec=c.get('_sec'))); i += kg; continue
                j_ = '\n'.join(its[i:i + k])   # ข้อละบรรทัด ตัวเลขสองเรื่องไม่อยู่บรรทัดเดียวกัน
                packs.append(dict(big_of(j_) if big else small_of(j_), _sec=c.get('_sec'), _j=j_, _n=k)); i += k
            q = 0
            while q < len(packs) - 1:                      # หน้าข้อเดียวต่อกับหน้าถัดไปถ้ารวมกันยังใส่ได้ (ไม่มีหน้าโล่งทีละข้อ)
                a_, b_ = packs[q], packs[q + 1]
                if '_j' in a_ and '_j' in b_ and min(a_['_n'], b_['_n']) == 1 and len(a_['_j']) + len(b_['_j']) + 1 <= 170 \
                        and fits(small_of(a_['_j'] + '\n' + b_['_j'])):
                    j2 = a_['_j'] + '\n' + b_['_j']; packs[q:q + 2] = [dict(small_of(j2), _sec=c.get('_sec'), _j=j2, _n=a_['_n'] + b_['_n'])]; continue
                q += 1
            packs = [{k_: v for k_, v in x.items() if k_ not in ('_j', '_n')} for x in packs]
            if i == len(its):
                want[:0] = packs; log.append((c, None, why[-3:], f'รวม {len(its)} ข้อเป็น {len(packs)} หน้าข้อความ')); continue
        if not got and c['kind'] == 'list' and not c.get('_cl') and any(len(x[0]) > 60 for x in c['items']):
            # ข้อยาวเกินกล่องของชุดนี้: แตกเป็นความสั้นที่รอยต่อความ (ยังเป็นรายการเดียวกัน) ก่อนจะแบ่งเป็นหลายหน้า
            its = [(p_,) for x in c['items'] for p_ in pieces(clauses(x[0]), lo=25, hi=60)]
            if len(its) == len(c['items']) == 1:           # แตกไม่ได้ (ทั้งประโยคต่อกันด้วยคำเชื่อม): ไปทางแบ่งย่อหน้ายาวตามรอยต่อคำ
                want.insert(0, dict(c, _fb=1, _cl=1))
                log.append((c, None, why[-3:], 'ข้อยาวแบ่งตามรอยต่อคำ')); continue
            want[:0] = [dict(c, items=part, _cl=1) for part in chunk(its)]
            log.append((c, None, why[-3:], f'แตกข้อยาวเป็น {len(its)} ข้อสั้น')); continue
        if not got and n_it > 1 and c['kind'] == 'agenda' and n_it > 3:   # สารบัญยาวเกินที่ชุดนี้รับ: สองหน้า "สารบัญ" (ไม่ข้ามสารบัญ)
            h = -(-n_it // 2); sc = c.get('_secs') or [None] * n_it
            want[:0] = [dict(c, items=c['items'][:h], _secs=sc[:h], _part=1), dict(c, items=c['items'][h:], _secs=sc[h:], _part=2)]
            log.append((c, None, why[-3:], f'สารบัญแบ่งเป็น {h}+{n_it - h} ข้อ')); continue
        if not got and n_it > 1 and c['kind'] == 'list' and not c.get('_jn') and \
                ((any(len(x[0]) < 12 for x in c['items']) and n_it <= 3) or (all(len(x[0]) < 20 for x in c['items']) and n_it <= 8)):
            # แบ่งครึ่งแล้วจะเหลือข้อสั้น ๆ (ป.4 288) เป็นหัวเรื่องหน้าเดี่ยว: รวมทุกข้อเป็นข้อความเดียว ข้อละบรรทัด
            want.insert(0, dict(kind='statement', t='\n'.join(x[0] for x in c['items']), s=c.get('t', ''), _sec=c.get('_sec'), _jn=1))
            log.append((c, None, why[-3:], 'รวมข้อสั้นเป็นข้อความเดียว')); continue
        if not got and n_it > 2 and c['kind'] in ('list', 'pairs', 'qa', 'timeline') and not c.get('_gf'):
            # หาจำนวนข้อที่หน้าเดียวรับได้จริง แล้วแบ่งเท่า ๆ กัน (ไม่ใช่หน้าละข้อ)
            part_ = lambda a, b: dict(c, items=c['items'][a:b], _gf=1)
            fitk = next((k for k in range(n_it - 1, 1, -1) if any(try_one(nm, ex, sl, part_(0, k), M)[0] is not None for _, nm, ex, sl in candidates(part_(0, k), pool, used))), 0)
            T_ = c.get('t') or ''; j_ = '\n'.join(' '.join(x for x in it if x) for it in c['items'])
            if c['kind'] == 'list' and n_it <= 5 and len(j_) <= 260 and len(set(groups([x[0] for x in c['items']]))) == 1:
                st_ = dict(kind='statement', t='', s=(T_ + '\n' if T_ else '') + j_ if T_ else j_, _sec=c.get('_sec'), _jn=1)
                if any(try_one(nm, ex, sl, dict(st_, _bsz=z) if z else st_, M)[0] is not None for z in (None, 0.85, 0.72) for _, nm, ex, sl in candidates(st_, pool, used)):
                    want.insert(0, st_); log.append((c, None, why[-3:], 'เรื่องเดียวทั้งก้อนลงหน้าข้อความ ไม่แยกหน้าละข้อ')); continue
            if fitk:
                pages_ = -(-n_it // fitk); per = -(-n_it // pages_)
                cuts = [0]
                for q in range(pages_): cuts.append(cuts[-1] + n_it // pages_ + (q < n_it % pages_))   # 7 ข้อ 3 หน้า = 3+2+2 ไม่ใช่ 3+3+1
                want[:0] = [part_(a, b) for a, b in zip(cuts, cuts[1:])]
                log.append((c, None, why[-3:], f'แบ่งเป็น {pages_} หน้า หน้าละ {per} ข้อ')); continue
        if not got and n_it > 1 and c['kind'] != 'agenda':  # ห้ามทิ้งเนื้อลูกค้า แบ่งครึ่งแล้วลองใหม่
            h = -(-n_it // 2)
            want[:0] = [one(c, c['items'][:h]), one(c, c['items'][h:])]
            log.append((c, None, why[-3:], f'แบ่งเป็น {h}+{n_it - h} ข้อ')); continue
        if not got and n_it == 1 and c.get('_one') == 1 and c['kind'] in ('list', 'pairs', 'qa', 'timeline'):
            want.insert(0, one(dict(c, _one=2), c['items']))   # หน้ามีหัวเรื่องรับข้อเดียวไม่ได้ → หน้าข้อความเด่น
            log.append((c, None, why[-3:], 'ข้อเดียวลงหน้าข้อความเด่น')); continue
        if not got and c.get('_hd'):                       # หัวข้อ+รายละเอียดลงหน้าไหนไม่ได้ → ข้อความเด่นแบบเดิม
            want.insert(0, dict(kind='statement', t=(' ' if c.get('_tbl') else ': ').join(c['_hd']), s=c['t'], _sec=c.get('_sec')))
            log.append((c, None, why[-3:], 'ลงหน้าข้อความเด่น')); continue
        if not got and c['kind'] == 'compare':                  # ชุดนี้ไม่มีหน้าเปรียบเทียบ → รายการกลุ่มละหน้า
            want[:0] = [dict(kind='list', t=g[0], items=[(x,) for x in g[1]]) for g in c['items'] if g[1]]
            log.append((c, None, why[-3:], 'แยกเป็นรายการกลุ่มละหน้า')); continue
        if not got and c['kind'] == 'list' and c.get('_fb') and len(c['items']) == 1:   # ย่อหน้ายาวเกินทุกกรอบ
            txt = c['items'][0][0]
            cl = clauses(txt); acc = 0; sp = []                # ตัดที่รอยต่อความก่อน (ไม่ตัดกลางความ เช่นหน้า "ซึ่ง")
            for x in cl[:-1]: acc += len(x) + 1; sp.append(acc - 1)
            if not sp:                                     # ไม่มีรอยต่อความ: เว้นวรรคที่ไม่แยกตัวเลขกับป้าย/หน่วย ไม่จบด้วยคำเชื่อม
                ok = lambda i: not re.search(r'\d', txt[i + 1:].split(' ')[0]) and not numunit(txt[:i], txt[i + 1:]) \
                    and not cont(txt[i + 1:].split(' ')[0]) \
                    and (words(txt[:i].split(' ')[-1]) or [''])[-1] not in TAIL
                allsp = [m.start() for m in re.finditer(' ', txt)]
                sp = [i for i in allsp if ok(i)]
                if not sp:                                 # ความต่อด้วย "และ/หรือ/แต่/ซึ่ง/โดย": ตัดหลังคำเชื่อม (ท่อนถัดไปไม่ขึ้นต้นด้วยคำเชื่อม)
                    for m in re.finditer(r' (และ|หรือ|แต่|ซึ่ง|โดย)(?=\S)', txt): sp.append(m.end())
                if not sp:                                 # ไม่มีเว้นวรรคที่ตัดได้: ตัดที่รอยต่อคำ แต่ไม่ตัดหน้าคำเชื่อม
                    acc = 0
                    for w_ in wordsx(txt)[:-1]:
                        acc += len(w_)
                        if txt[acc:acc + 1] != ' ' and not cont(txt[acc:].lstrip()) and w_.strip() not in TAIL \
                                and not numunit(txt[:acc], txt[acc:]) and not re.match(r'[\d' + '\u0E30-\u0E4E' + ']', txt[acc:acc + 1]): sp.append(acc)
                sp = sp or allsp
            if not sp and len(txt) > 40:                # ประโยคไทยไม่มีเว้นวรรค: ตัดที่รอยต่อคำ (ตัวตัดคำ ไม่ใช่ AI)
                acc = 0; sp = []
                for w_ in wordsx(txt)[:-1]: acc += len(w_); sp.append(acc)
            sp = [i_ for i_ in sp if 20 <= i_ <= len(txt) - 20] or [i_ for i_ in sp if 12 <= i_ <= len(txt) - 12]   # ไม่มีท่อนสั้นกว่า 12 ตัวเป็นหน้าเดี่ยว
            if sp and len(txt) > 40:                    # ตัดที่ช่องว่างใกล้กึ่งกลาง เป็นสองหน้าต่อกัน คำครบเหมือนเดิม
                cut = min(sp, key=lambda i: abs(i - len(txt) / 2))
                want[:0] = [dict(kind='statement', t=txt[:cut].strip(), s=c['t']), dict(kind='statement', t=txt[cut:].strip(), s=c['t'])]
                log.append((c, None, why[-3:], 'แบ่งย่อหน้ายาวเป็นสองหน้า')); continue
        if not got and c['kind'] == 'statement' and not c.get('_fb') and not c.get('_ts') and c.get('t'):   # ประโยคยาวเกินหน้าคำคม → ลองเป็นรายการข้อเดียว
            want.insert(0, dict(kind='list', t=c.get('s', ''), items=[(c['t'],)], _fb=1, _cl=1, _sec=c.get('_sec')))   # ไม่แตกซ้ำ (กันวน)
            log.append((c, None, why[-3:], 'ลองเป็นรายการ')); continue
        if not got and c['kind'] == 'list' and c.get('t') and len(c.get('items') or []) == 1 and not c.get('_ts'):
            # หัวข้อยาวเกินกล่องหัวเรื่องทุกแบบของชุดนี้: หัวข้อกับรายละเอียดลงช่องข้อความรองด้วยกัน หน้านี้ยังมีชื่อหัวข้อ
            want.insert(0, dict(kind='statement', t='', s=c['t'] + ' ' + c['items'][0][0], _ts=1, _sec=c.get('_sec')))
            log.append((c, None, why[-3:], 'หัวข้อกับรายละเอียดลงช่องข้อความรอง')); continue
        if not got:
            log.append((c, None, why, 'ไม่มี layout ในชุดนี้รับได้ ข้ามแผ่นนี้')); continue
        used[got[0]] = used.get(got[0], 0) + 1
        out.append(dict(c=c, layout=got[0], d=got[1])); log.append((c, got[0], why, ''))
    if not capped:
        gone = missing_words(want0, out, M)
        if gone: NOTES.append('ข้อความบางส่วนใส่ในหน้าตานี้ไม่ได้: ' + ' '.join(gone[:8]) + (' …' if len(gone) > 8 else '') + ' ลองหน้าตาอื่น')
    return M, out, log

def _toks(v):
    """คำของลูกค้า (แยกตามเว้นวรรค) จากเนื้อหาหนึ่งชิ้น ไม่รวมคีย์ภายใน/ตัวเลขกราฟ"""
    if isinstance(v, dict):                                # การ์ดตัวเลข: ใช้ข้อความเต็มของลูกค้า (raw) ไม่ใช่ค่าที่แยกแล้ว
        skip = ('kind', 'vals', 'series', 'num', 'ordered') + (('items',) if v.get('raw') else ('raw',))
        return [t for k, x in v.items() if not k.startswith('_') and k not in skip for t in _toks(x)]
    if isinstance(v, (list, tuple)): return [t for x in v for t in _toks(x)]
    if isinstance(v, str): return [w for w in v.split() if re.search(r'[A-Za-z0-9\u0E01-\u0E2E\u0E50-\u0E59]', w) and not re.fullmatch(r'[\d\u0E50-\u0E59]{1,2}[.)]', w)]   # เลขข้อ "1." ไม่นับ
    return []

def _pagetxt(x, M):
    """ข้อความที่วาดจริงของหน้าหนึ่ง (วาดด้วยตัววัดเดียวกับตอนเลือก layout จำผลไว้)"""
    if '_txt' not in x:
        eng.setpal(M['pal'], M.get('font', 'plex'), M.get('head')); eng.setvar(0)
        prs = base.deck(); real = base._prep; base._prep = lambda path, mode=None: (_DOT, (4, 3))
        try:
            lay.L[x['layout']](prs, {'topic': M.get('topic', 'office'), 'foot': '', 'n': '01', **x['d']})
            if x['d'].get('_nf'): numfmt(prs.slides[-1], x['d']['_nf'], x['d'].get('_sn'))
            scrub(prs.slides[-1], list(strings(x['d']))); x['_txt'] = slide_text(prs.slides[-1])
        except Exception: x['_txt'] = ''
        finally: base._prep = real
    return x['_txt']

def _in(w, allt):
    """คำนี้อยู่ในสไลด์ไหม (คำไทยยาวที่ไม่มีเว้นวรรคอาจถูกแบ่งข้ามหน้า: ดูทีละคำย่อยแทน)"""
    w = ''.join(w.split()).lower()
    return w in allt or all(x.strip().lower() in allt for x in wordsx(w) if len(x.strip()) > 1)

def missing_words(want0, out, M):
    """คำของลูกค้าที่ไม่อยู่ในสไลด์ที่วาดจริงเลย (ห้ามทิ้งเนื้อหา)"""
    allt = ''.join(_pagetxt(x, M) for x in out)
    return [w for c in want0 if c['kind'] != 'agenda' for w in _toks(c) if not _in(w, allt)]

def rescue(want0, out, M, rnd=0):
    """ชิ้นเนื้อหาที่มีคำหายจากสไลด์ → เติมเป็นรายการธรรมดา (หัวข้อเดิม ข้อละบรรทัด) ให้จัดอีกรอบ ไม่ปล่อยให้เนื้อหาหายเงียบ"""
    allt = ''.join(_pagetxt(x, M) for x in out)
    has = lambda x: all(_in(w, allt) for w in _toks(x))
    fix = []
    for c in want0:
        if c['kind'] == 'agenda' or has(c): continue
        keys = {k: v for k, v in c.items() if not k.startswith('_') and k not in ('kind', 'raw', 'vals', 'series', 'num', 'ordered', 't')}
        lines = [x for x in strings(keys) if x.strip() and not has(x)]
        t = c.get('t') or ''
        if t and not has(t): lines = [t] + lines; t = ''     # หัวข้อเองหาย: ใส่เป็นข้อแรก
        if rnd:                                            # รอบสอง (ยังหาย): ท่อนสั้นลงตามรอยต่อคำ ไม่มีหัวข้อ ให้กล่องเล็กที่สุดของชุดรับได้
            lines = [y for x in lines for y in _wsplit(x, 36)]; t = ''
        for part in chunk(lines):
            fix.append(dict(kind='list', t=t, ordered=False, note='', items=[(x,) for x in part], _sec=c.get('_sec'), _rescue=1))
    return fix

def _wsplit(x, n):
    """ข้อความยาว → ท่อนไม่เกิน ~n ตัว ตัดที่รอยต่อคำ ไม่ขึ้นท่อนด้วยคำเชื่อม ไม่แยกเลขกับหน่วย ท่อนสุดท้ายไม่สั้นกว่า 12 ตัว"""
    out, cur = [], ''
    ws = wordsx(x)
    for i, w in enumerate(ws):
        if cur and len(cur) + len(w) > n and not cont(w.strip()) and not numunit(cur, ''.join(ws[i:])) and w.strip():
            out.append(cur.strip()); cur = w
        else: cur += w
    if cur.strip(): out.append(cur.strip())
    if len(out) > 1 and len(out[-1]) < 12: last = out.pop(); out[-1] += ' ' + last if not out[-1].endswith(' ') else last
    return out

KIND_TH = {'cover': 'ปก', 'agenda': 'สารบัญ', 'list': 'รายการ', 'pairs': 'หัวข้อพร้อมคำอธิบาย', 'qa': 'ถาม-ตอบ',
           'stat': 'ตัวเลขสำคัญ', 'timeline': 'ไทม์ไลน์', 'table': 'ตาราง', 'chart': 'กราฟ', 'statement': 'ข้อความเด่น',
           'divider': 'หน้าคั่น', 'compare': 'เปรียบเทียบ'}

def findings(want):
    """สิ่งที่อ่านเจอในไฟล์ ไว้โชว์ลูกค้าก่อนสร้าง (ของจริงทั้งหมด ไม่ได้เดา)"""
    secs = [c for c in want if c['kind'] not in ('cover', 'agenda')]
    nums = [x[0] for c in want if c['kind'] == 'stat' for x in c['items']]
    return dict(
        sections=len({c['t'] for c in secs}),
        tables=sum(1 for c in want if c['kind'] in ('table', 'chart')),
        rows=sum(len(c.get('rows') or []) for c in want if c['kind'] in ('table', 'chart')),
        nums=nums[:6], dates=sum(len(c['items']) for c in want if c['kind'] == 'timeline'),
        qa=sum(len(c['items']) for c in want if c['kind'] == 'qa'), notes=list(NOTES),
        outline=[dict(t=c['t'] if c['kind'] != 'statement' else (c.get('s') or c['t']), kind=c['kind'],
                      th=KIND_TH.get(c['kind'], ''), n=len(c.get('items') or c.get('rows') or [])) for c in want if not c.get('_off')])

def _ptitle(c):
    t = (c.get('s') or c.get('t')) if c['kind'] == 'statement' else c.get('t')
    if t: return t
    x = (c.get('items') or c.get('rows') or [''])[0]
    x = x if isinstance(x, str) else (x[0] if x else '')
    return x[:40] + ('…' if len(x) > 40 else '')

LAYKIND = {}                                               # ชื่อ layout → ชนิดของตัวอย่าง (ตารางที่ลงหน้าตาตาราง ไม่ใช่กราฟ)

def plan_summary(out):
    """สิ่งที่ทำจริงหลังลงหน้าตา ไว้ให้ผู้ช่วยเล่า (ไม่ใช่สิ่งที่เจอในเนื้อหา ซึ่งบางอย่างหน้าตานั้นทำไม่ได้)"""
    cs = [x['c'] for x in out]
    drawn = lambda x: 'table' if x['c']['kind'] == 'chart' and LAYKIND.get(x['layout']) != 'chart' else x['c']['kind']
    n = lambda k: sum(1 for x in out if drawn(x) == k)   # ชนิดตามหน้าตาที่วาดจริง (ข้อมูลกราฟบนหน้าตาตาราง = ตาราง)
    return dict(notes=list(dict.fromkeys(NOTES)), pages=len(out), kinds={k: n(k) for k in KIND_TH if n(k)},
                stats=[dict(t=c.get('t', ''), vals=[v for v, _ in c['items']][:4]) for c in cs if c['kind'] == 'stat'][:3],
                charts=[x['c'].get('t', '') for x in out if x['c']['kind'] == 'chart' and LAYKIND.get(x['layout']) == 'chart'],
                tables=[x['c'].get('t', '') for x in out if x['c']['kind'] == 'table' or (x['c']['kind'] == 'chart' and LAYKIND.get(x['layout']) != 'chart')],
                timelines=sum(len(c['items']) for c in cs if c['kind'] == 'timeline'),
                sections=INFO.get('sections', len({c.get('_sec') for c in cs if isinstance(c.get('_sec'), int)})),
                # โครงหน้าจริงหลังจัด (ชื่อหน้า: หัวเรื่อง หรือหัวรอง หรือข้อความแรกของหน้า) ให้รายการในแชทตรงกับสไลด์
                outline=[dict(t=_ptitle(x['c']), kind=drawn(x), th=KIND_TH.get(drawn(x), ''),
                              n=len(x['c'].get('items') or x['c'].get('rows') or [])) for x in out])   # ชิปชนิดหน้าตามหน้าตาที่วาดจริง

def alternatives(c, slug):
    """layout อื่นในชุดเดียวกันที่รับแผ่นนี้ได้โดยไม่ล้น — ให้ลูกค้ากดเปลี่ยนแบบ"""
    M, pool = pool_of(slug)
    res = []
    for sc, nm, ex, slots in candidates(c, pool, {}):
        d, bad = try_one(nm, ex, slots, c, M)
        if d is not None: res.append((nm, d))
    return res

def reagenda(c, secs, slug, layout):
    """สารบัญหลังย้าย/ลบหน้า: หัวข้อเดิมที่ยังมีหน้าอยู่ เรียงตามลำดับหน้าปัจจุบัน (secs = หัวข้อของหน้าที่เหลือตามลำดับ)
    คืน (สารบัญใหม่, (layout, d) หรือ None)  None = ไม่เหลือหัวข้อหรือหน้าตานี้ใส่ไม่ได้ เว็บเอาหน้าสารบัญออก
    ponytail: ไม่เติมหัวข้อที่เกิน 6 ข้อแรกเข้ามาแทนข้อที่ลบ สารบัญจึงสั้นลงได้แต่ไม่มีข้อที่ไม่จริง"""
    base = c.get('_items0') or c['items']
    pos = {}
    for i, t in enumerate(secs): pos.setdefault(t, i)
    ids = c.get('_secs0') or c.get('_secs')
    if ids is not None and all(isinstance(t, int) for t in secs):   # ผูกด้วยเลขหัวข้อ
        pairs = sorted([(x, n) for x, n in zip(base, ids) if n in pos], key=lambda p: pos[p[1]])
        keep = [x for x, _ in pairs]
        c2 = dict(c, items=keep, _items0=base, _secs=[n for _, n in pairs], _secs0=ids)
    else:
        keep = sorted([x for x in base if x[0] in pos], key=lambda x: pos[x[0]])
        c2 = dict(c, items=keep, _items0=base)
    if not keep: return c2, None
    alts = alternatives(c2, slug)
    return c2, next((a for a in alts if a[0] == layout), alts[0] if alts else None)

# ══ 7. ตัวแก้บนเว็บ: กล่องไหนมาจากช่องไหน / แก้คำหนึ่งกล่อง ═══════════════════════
BOXES = []                                                 # render() เติม: ต่อหน้าที่วาด รายการกล่องที่แก้ได้
# ใบ 015 เฟส 0 ข้อ c: PIL นับบรรทัดขาดได้ (ฟอนต์กว้าง ข้อความเต็มกล่องพอดี) เว็บส่งจำนวนบรรทัดที่ชั้นพิมพ์ของเบราว์เซอร์ตัดจริงมาด้วย
LHINT = {}                                                 # ข้อความ (ช่องว่างยุบ) → [(pt, จำนวนบรรทัดของเบราว์เซอร์ที่ขนาดนั้น)] ใช้ระหว่าง edit_text เท่านั้น
EXTRA = {}                                                 # ผลเสริมของ edit_text ล่าสุด: lines = ยาวเกินประมาณกี่บรรทัด (0 = บอกไม่ได้)

def _leaves(v, path=()):
    """ทุกข้อความของลูกค้าใน d พร้อมที่อยู่ เช่น ('items', 2, 0)  ไม่รวมคีย์ดีไซน์ ตัวเลขกราฟ เลขหน้าคั่น"""
    if isinstance(v, str): yield path, v
    elif isinstance(v, (list, tuple)):
        for i, x in enumerate(v): yield from _leaves(x, path + (i,))
    elif isinstance(v, dict):
        for k, x in v.items():
            if k not in KEEP and k not in ('al', 'colw', 'vals', 'num'): yield from _leaves(x, path + (k,))

def boxmap(slide, d, sw, sh_):
    """กล่องข้อความบนสไลด์ที่วาดแล้ว → ช่องใน d ที่มันมา (หน่วย 960×540)
    จับคู่ด้วยข้อความตรงตัว: ทุกคำบนสไลด์มาจาก d อยู่แล้ว (scrub ลบที่เหลือ) ไม่ต้องรู้โครงของแต่ละ layout
    ponytail: ข้อความที่ layout แยกเป็นหลายกล่อง (เลข + หน่วย) หรืออยู่ในกราฟ ไม่มีกล่อง แก้บนจอไม่ได้"""
    want = {}
    for p, t in _leaves(d):
        if t.strip(): want.setdefault(t.strip(), []).append(list(p))
    used = {}
    fx, fy = 960 / sw, 540 / sh_
    def box(t, x, y, w, h, tf):
        t = t.replace('\u00a0', ' ')                      # เลขลำดับที่ผูกด้วยเว้นวรรคไม่ตัดบรรทัด = คำเดิมของลูกค้า
        ps = want.get(t)
        if not ps: return None
        k = used.get(t, 0); used[t] = k + 1
        r = next((r for p in tf.paragraphs for r in p.runs if r.font.size), None)
        pt = r.font.size.pt if r else 18
        lh = pt * 1.25 / 72 * 914400
        p_ = ps[min(k, len(ps) - 1)]; f_ = (d.get('fsz') or {}).get('.'.join(map(str, p_)))
        return dict(p=p_, **({'f': f_} if f_ else {}), x=round(x * fx, 1), y=round(y * fy, 1), w=round(w * fx, 1), h=round(h * fy, 1),
                    pt=round(pt, 1), multi=ps[0][0] not in ('t', 't1') and (h / lh >= 1.65 or '\n' in t))
    out = []
    for s in slide.shapes:
        if getattr(s, 'has_table', False) and s.has_table:
            tb, y = s.table, s.top
            for row in tb.rows:
                x = s.left
                for j, cell in enumerate(row.cells):
                    b = box(cell.text_frame.text.strip(), x, y, tb.columns[j].width, row.height, cell.text_frame)
                    if b: out.append(b)
                    x += tb.columns[j].width
                y += row.height
        elif s.has_text_frame:
            b = box(s.text_frame.text.strip(), s.left, s.top, s.width, s.height, s.text_frame)
            if b: out.append(b)
    return out

def _get(v, path):
    for k in path: v = v[k]
    return v

def _put(v, path, new):
    """คืนสำเนาที่เปลี่ยนแค่ช่องเดียว (tuple ยังเป็น tuple)"""
    if not path: return new
    k, rest = path[0], path[1:]
    if isinstance(v, dict): return {**v, k: _put(v[k], rest, new)}
    xs = list(v); xs[k] = _put(xs[k], rest, new)
    return tuple(xs) if isinstance(v, tuple) else xs

def _sub(v, old, new, hit, line=False, flat=False):
    """เปลี่ยนทุกข้อความที่ตรงกับคำเดิม (ไม่สนช่องว่าง/ขึ้นบรรทัด: หัวเรื่อง "ก\nข" กับข้อในสารบัญ "ก ข" คือคำเดียวกัน)  hit[0] นับจำนวนที่เปลี่ยน
    flat: ฝั่งสารบัญ ขึ้นบรรทัดในหัวเรื่อง = เว้นวรรค (ใบ 015 ux ข้อ H)
    raw (ข้อความเต็มของการ์ดตัวเลข ใช้ตอนลงเป็นรายการแทน) แทนเฉพาะส่วนที่ตรง"""
    if isinstance(v, str):
        if v == old or (old.strip() and v.split() == old.split()): hit[0] += 1; return new.replace('\n', ' ') if flat else new
        if line and '\n' in v and old in v.split('\n'):    # ชื่อหัวข้อเป็นบรรทัดหนึ่งในข้อความ (หัวข้อ+เนื้อในช่องเดียว) เปลี่ยนเฉพาะบรรทัดที่ตรงทั้งบรรทัด
            hit[0] += 1; return '\n'.join(new if x == old else x for x in v.split('\n'))
        return v
    if isinstance(v, (list, tuple)):
        xs = [_sub(x, old, new, hit, line, flat) for x in v]
        return tuple(xs) if isinstance(v, tuple) else xs
    if isinstance(v, dict):
        out = {}
        for k, x in v.items():
            if k in KEEP: out[k] = x
            elif k == 'raw' and len(old) > 1: out[k] = [r.replace(old, new) if old in r else r for r in x]
            else: out[k] = _sub(x, old, new, hit, line, flat)
        return out
    return v

def edit_text(items, cs, want, idx, path, new, M, dry=False, hint=None, force=False):
    """hint = [(pt, จำนวนบรรทัดที่เบราว์เซอร์ตัด)] ของกล่องที่พิมพ์ ต่อขนาดที่ลองย่อ (เว็บส่งมา) ตัดสินล้นด้วยค่ามากกว่าระหว่าง PIL กับเบราว์เซอร์
    force = ลูกค้าออกจากกล่องตอนยังล้น: ย่อตัวเองแล้ว ยังล้นก็เก็บคำครบทุกตัว (ห้ามตัด) หน้านั้นติดป้าย _ov"""
    LHINT.clear(); EXTRA.clear()
    if hint: LHINT[' '.join(str(new).split())] = [tuple(h) for h in hint] if isinstance(hint[0], (list, tuple)) else [tuple(hint)]
    try: return _edit_text(items, cs, want, idx, path, new, M, dry, force)
    finally: LHINT.clear()

def _over_n(bad):
    """ยาวเกินประมาณกี่บรรทัด จากผลของ overflow ("..." 5/4 บรรทัด) ไม่มีตัวเลข = 0"""
    return max([int(a) - int(b) for a, b in (re.findall(r'(\d+)/(\d+) บรรทัด', ' '.join(bad)))] or [0])

def _edit_text(items, cs, want, idx, path, new, M, dry=False, force=False):
    """ลูกค้าแก้คำในกล่องหนึ่งของหน้า idx  คืน (สถานะ, ตามไปหน้าตาใหม่ได้ไหม)
    สถานะ ok / shrink (ย่อตัวลงให้พอดี: หัวเรื่องปก หรือกล่องนี้ถึง 80%) / over (ล้นกล่อง ไม่ force = ไม่เปลี่ยนอะไร / force = เก็บคำครบ ติด _ov ห้ามตัดคำเงียบ)
    ไม่ dry: แก้ items[idx] ช่องนั้น + ทุกข้อความเดิมใน cs (สารบัญกับหัวข้อยังตรงกัน) + want (เปลี่ยนหน้าตาแล้วคำใหม่ตามไป)
    ponytail: คำเดิมที่ซ้ำกันหลายที่ใน want/cs เปลี่ยนทั้งหมด หน้าอื่นยังโชว์คำเดิมจนกว่าจะจัดหน้านั้นใหม่"""
    name, d = items[idx]
    path = [p for p in path]
    old = _get(d, path)
    d2 = _sub(_put(d, path, new), old, new, [0]) if old.strip() else _put(d, path, new)   # คำเดียวกันในหน้าเดียวกันเปลี่ยนด้วย (เช่นหัวตารางที่ซ้ำหัวเรื่อง)
    if path[0] == 'cats' and isinstance(d2.get('rows'), list) and len(d2['rows']) > path[1] and d2['rows'][path[1]][0] == old:
        d2 = _put(d2, ['rows', path[1], 0], new)            # ป้ายกราฟกับแถวตารางเป็นคำเดียวกัน
    key = '.'.join(map(str, path)); fz = {k: v for k, v in (d2.get('fsz') or {}).items() if k != key}
    d2 = {k: v for k, v in d2.items() if k not in ('fsz', '_ov')}
    if fz: d2['fsz'] = fz                                    # กล่องนี้เริ่มวัดที่ขนาดดีไซน์ใหม่ (สั้นลงแล้วตัวกลับใหญ่เท่าเดิม แบบ PowerPoint)
    # หน้าที่ติดป้ายล้นอยู่แล้ว (กล่องอื่นยาวเกิน): ตัดสินเฉพาะกล่องที่พิมพ์ ไม่โทษกล่องนี้เพราะกล่องอื่น
    base, nn, full = (overflow(name, d, M) if d.get('_ov') else []), ' '.join(str(new).split()), [[]]
    q_ = lambda m: ' '.join(m[1:m.index('"', 1)].replace('\u00a0', ' ').split()) if m.startswith('"') and '"' in m[1:] else ''
    def chk(dx):
        full[0] = overflow(name, dx, M)
        return [m for m in full[0] if m not in base or (q_(m) and nn.startswith(q_(m)))]
    st, bad = 'ok', chk(d2)
    if bad:
        st = 'over'
        if idx == 0 or 'tsz' in d2:                        # ปกย่อหัวเรื่องได้ ไล่ลงแบบเดียวกับตอนจัดครั้งแรก
            for z in (40, 36, 32, 28):
                if z >= d2.get('tsz', 99): continue
                if not chk({**d2, 'tsz': z}): d2 = {**d2, 'tsz': z}; st = 'shrink'; bad = []; break
    if st == 'over':                                       # ย่อตัวกล่องนี้ลงทีละขั้นถึง 80% (ไม่ต่ำกว่า 10pt) ตามกฎขนาดตัวอักษรของใบ 015
        for f in (0.8,) if dry else (0.95, 0.9, 0.85, 0.8):   # ระหว่างพิมพ์วัดแค่ขั้นเล็กสุด (ไม่หน่วงจอ) ตอนจบการแก้ไล่ทีละขั้น
            dz = {**d2, 'fsz': {**fz, key: f}}; bad = chk(dz)
            if not bad: d2, st = dz, 'shrink'; break
        else:
            if force: d2 = dz                              # ยังล้น: เก็บขนาดที่เล็กสุด คำครบ
    EXTRA['lines'] = _over_n(bad) if st == 'over' else 0
    # หัวข้อกับข้อในสารบัญเป็นคำเดียวกัน แก้ฝั่งไหนอีกฝั่งต้องตาม (ไม่งั้นไฟล์มีสองคำไม่ตรงกัน)
    if cs[idx].get('_ins'):                                # หน้าที่ลูกค้าแทรกเอง: ไม่ผูกกับสารบัญ/หัวข้อ/เนื้อหาต้นทาง (ช่องว่างเดิม = '' ห้ามแทนทั้งไฟล์)
        if not dry and (st != 'over' or force): items[idx] = (name, {**d2, '_ov': 1} if full[0] else d2)
        return st, True
    links, ag = [], cs[idx].get('kind') == 'agenda'
    sec = cs[idx].get('_sec')                                # หัวข้อที่ชื่อนี้เป็นของ (จากสารบัญ = เลขหัวข้อของข้อที่แก้)
    if ag and path[0] == 'items' and len(path) > 1 and isinstance(path[1], int) and (cs[idx].get('_secs') or []):
        sec = (cs[idx]['_secs'] + [None] * 99)[path[1]]
    same = lambda j: sec is not None and cs[j].get('_sec') == sec and cs[j].get('kind') not in ('cover', 'agenda')
    if (ag and path[0] == 'items') or not ag:                # ช่องไหนก็ได้ที่ถือชื่อหัวข้อ (หัวเรื่อง หัวรอง ป้าย)
        for j, (nm, dj) in enumerate(items):
            if j == idx: continue
            if not ag and cs[j].get('kind') == 'agenda' and 'items' in dj:
                h = [0]; it2 = _sub(dj['items'], old, new, h, flat=True)
                if h[0]: links.append((j, (nm, {**dj, 'items': it2})))
            elif not ag and cs[idx].get('_sec') is not None and cs[j].get('_sec') == cs[idx].get('_sec') and cs[j].get('kind') not in ('cover', 'agenda') \
                    and path[0] in ('t', 't1', 's', 'k', 'who', 'lab', 'label', 'tag'):
                h = [0]; dj2 = _sub(dj, old, new, h, True)  # หน้าต่อของหัวข้อเดียวกันใช้ชื่อหัวข้อเดียวกัน (รวมชื่อที่เป็นบรรทัดในเนื้อ)
                if h[0]: links.append((j, (nm, dj2)))
            elif ag and cs[j].get('kind') not in ('cover', 'agenda'):
                h = [0]; dj2 = _sub(dj, old, new, h, same(j))
                if h[0]: links.append((j, (nm, dj2)))
    links = [(j, (nm, {k: v for k, v in dj.items() if k != '_ov'})) for j, (nm, dj) in links]
    lov = {j for j, (nm, dj) in links if overflow(nm, dj, M)}
    if st != 'over' and lov: st = 'over'
    if dry or (st == 'over' and not force): return st, True
    if full[0]: d2 = {**d2, '_ov': 1}                      # ออกจากกล่องตอนยังล้น (กล่องนี้หรือกล่องอื่นในหน้า): คำครบ หน้านี้ติดป้าย "ข้อความล้นกล่อง"
    links = [(j, (nm, {**dj, '_ov': 1} if j in lov else dj)) for j, (nm, dj) in links]
    items[idx] = (name, d2)
    for j, it in links: items[j] = it
    hit = [0]
    for j in range(len(cs)): cs[j] = _sub(cs[j], old, new, [0], same(j) and (ag or path[0] in ('t', 't1', 's', 'k', 'who', 'lab', 'label', 'tag')), cs[j].get('kind') == 'agenda')
    for j in range(len(want)): want[j] = _sub(want[j], old, new, hit, flat=isinstance(want[j], dict) and want[j].get('kind') == 'agenda')
    return st, hit[0] > 0

def keys(items, order, ttl, slug):
    """ลายนิ้วมือของแต่ละหน้า (ตามลำดับบนจอ) เว็บใช้ภาพเดิมซ้ำถ้าไม่เปลี่ยน ไม่ต้องวาดใหม่ทั้งไฟล์ตอนเลิกทำ"""
    import hashlib
    return [hashlib.md5(repr((items[i], ttl, slug, k == 0)).encode()).hexdigest()[:16] for k, i in enumerate(order)]

def sync_agenda(items, cs, order, slug):
    """หลังย้าย/ลบ/ทำสำเนาหน้า: จัดสารบัญใหม่จากหน้าที่เหลือตามลำดับปัจจุบัน แก้ items/cs ในที่ คืนลำดับหน้าใหม่
    (ไม่เหลือหัวข้อ หรือหน้าตานี้ใส่ไม่ได้ = เอาหน้าสารบัญออก)"""
    k = next((p for p, i in enumerate(order) if cs[i]['kind'] == 'agenda'), -1)
    if k < 0 or sum(1 for i in order if cs[i]['kind'] == 'agenda') > 1: return list(order)   # สารบัญสองหน้า: ponytail ไม่จัดใหม่ตอนย้ายหน้า
    i = order[k]; rest = [j for j in order if cs[j]['kind'] not in ('cover', 'agenda')]
    if cs[i].get('_secs') is not None or cs[i].get('_secs0') is not None:
        secs = [cs[j]['_sec'] for j in rest if isinstance(cs[j].get('_sec'), int)]
    else:                                                  # งานเก่าที่เก็บไว้ก่อนมีเลขหัวข้อ
        secs = [t for t in ((cs[j].get('s') if cs[j]['kind'] == 'statement' else cs[j].get('t')) or '' for j in rest) if t]
    c2, pk = reagenda(cs[i], secs, slug, items[i][0])
    cs[i] = c2
    if pk: items[i] = tuple(pk); return list(order)
    if c2['items']:                                        # ไม่มีแบบหน้าเดียวที่ลงพอดีตามเกณฑ์ alternatives: ให้ตัวจัดหน้าเลือก (ย่อตัวได้) ได้หน้าเดียวก็ใช้
        new = [x for x in plan([c2], slug)[1] if x['c']['kind'] == 'agenda']
        if len(new) == 1: items[i] = (new[0]['layout'], new[0]['d']); return list(order)
    return [j for p, j in enumerate(order) if p != k]

def add_agenda(want, items, cs, order, slug, layout):
    """ลูกค้ากดใส่สารบัญ (ปิดไว้ตั้งต้น ไอซ์ 29 ต.ค. 2569): เปิดสารบัญที่เตรียมไว้ใน want วางต่อจากปก หัวข้อ = หัวข้อของหน้าที่มีอยู่ตอนนี้ ตามลำดับหน้า
    layout = แบบที่ลูกค้าเลือก ใส่ไม่ได้ = แบบอื่นของชุด / ยาวเกินหน้าเดียว = ตัวจัดหน้าแบ่งสองหน้า "สารบัญ" แบบตอนจัดทั้งไฟล์
    แก้ items/cs/want ในที่  คืน (ลำดับหน้าใหม่, หน้าแรกของสารบัญ หรือ -1 = ใส่ไม่ได้)"""
    k = next((i for i, c in enumerate(want) if c['kind'] == 'agenda'), -1)
    if k < 0: return list(order), -1
    c = {x: v for x, v in want[k].items() if x != '_off'}
    secs = [cs[j]['_sec'] for j in order if cs[j]['kind'] not in ('cover', 'agenda') and isinstance(cs[j].get('_sec'), int)]
    c2, pk = reagenda(c, secs, slug, layout)
    if not c2['items']: return list(order), -1
    new = [(tuple(pk), c2)] if pk else [((x['layout'], x['d']), x['c']) for x in plan([c2], slug)[1] if x['c']['kind'] == 'agenda']
    if not new: return list(order), -1
    at = next((p + 1 for p, i in enumerate(order) if cs[i]['kind'] == 'cover'), 0); ids = []
    for it, cc in new: items.append(it); cs.append(dict(cc)); ids.append(len(items) - 1)
    want[k] = c
    return list(order[:at]) + ids + list(order[at:]), at

# ══ 8. แทรกหน้าใหม่ (ใบงาน 003 เฟส 2): layout ของชุดนี้ ช่องว่างให้ลูกค้าพิมพ์เอง ═══════════
INSK = ('cover', 'agenda', 'list', 'pairs', 'faq', 'stat', 'timeline', 'compare', 'statement', 'divider')   # ไม่มีตาราง/กราฟ: หน้าเปล่ายังไม่มีที่กรอกข้อมูล
_INSP = {}
# แบบที่ผ่าน ins_ok ต่อชุด คิดไว้ตอนรวม bundle (d2s_web.py) บนเว็บไม่ต้องวาดทดสอบทุกแบบตอนเปิดแผง (มือถือค้างหลายวินาที)
INSOK = json.load(open(f'{K}/ins_ok.json')) if os.path.exists(f'{K}/ins_ok.json') else {}
def ins_ok(nm, d, kd, M):
    """แบบหน้าว่างที่แทรกได้: วาดได้ และคำใบ้ลงกล่องพอดีไม่ทับรูป/เส้น (ช่องที่ layout ไม่วาดไม่นับ)"""
    return not [b for b in overflow(nm, hinted(d, kd)[0], M) if not b.startswith('ไม่ได้วาด')]

def ins_pool(slug):
    """แบบหน้าที่แทรกได้ของชุดนี้ (ไม่ซ้ำชื่อ layout) ทุกช่องข้อความว่าง ไม่มีคำตัวอย่างของดีไซน์  คืน [(layout, d, c, ชนิดตัวอย่าง)]"""
    if slug not in _INSP:
        M, pool = pool_of(slug); seen, out = set(), []
        for nm, ex, kd, n_ex, slots in pool:
            if kd not in INSK or nm in seen: continue
            c = dict(kind={'faq': 'qa', 'agenda': 'list' if slots in (None, (str,)) else 'pairs'}.get(kd, kd), t='', _ins=1)
            it = ex.get('items')
            if isinstance(it, list) and it and slots:
                c['items'] = ([('', [''] * len(next((x for x in r if isinstance(x, list)), []))) for r in it] if kd == 'compare'
                              else [('',) * sum(t is str for t in slots)] * len(it))
            d = fill(nm, ex, slots, c)
            if d is None: continue
            seen.add(nm); out.append((nm, d, c, kd))
        out.sort(key=lambda x: INSK.index(x[3]))
        ok = INSOK.get(slug)
        _INSP[slug] = [e for e in out if (e[0] in ok if ok is not None else ins_ok(e[0], e[1], e[2]['kind'], M))]
    return _INSP[slug]

def blank_page(d):
    """หน้าที่แทรกแล้วยังไม่ได้พิมพ์อะไรเลย (ถามก่อนบันทึก)"""
    return not any(v.strip() for _, v in _leaves(d))

HINTW = {'stat': ('เลข', 'คำอธิบาย', 'ข้อความ'), 'timeline': ('เวลา', 'หัวข้อ', 'รายละเอียด')}
def hinted(d, kind=''):
    """ช่องว่างของหน้าที่แทรก → คำใบ้สั้น ๆ บนจอ (ไม่ลงไฟล์) คำไม่ซ้ำกัน กล่องบนจอจึงผูกกลับช่องได้ถูก  คืน (d ที่มีคำใบ้, ชุดคำใบ้)"""
    out, used = d, set()
    for p, v in list(_leaves(d)):
        if v.strip() or p[0] not in ('t', 't1', 't2', 's', 'note', 'items'): continue   # ป้ายของดีไซน์ (แบรนด์ ชื่อเอกสาร) ว่างเหมือนหน้าที่ระบบจัด
        if p[0] == 'items' and len(p) == 2: h = f'ข้อ {p[1] + 1}'
        elif p[0] == 'items' and len(p) == 3:
            r = sum(isinstance(x, str) for x in d['items'][p[1]][:p[2]])
            h = f"{HINTW.get(kind, ('หัวข้อ', 'รายละเอียด', 'ข้อความ'))[min(r, 2)]} {p[1] + 1}"
        elif p[0] == 'items': h = f'ข้อ {p[1] + 1}.{p[-1] + 1}'
        else: h = {'t': 'พิมพ์หัวเรื่อง', 't1': 'พิมพ์หัวเรื่อง', 't2': 'หัวเรื่องต่อ', 's': 'พิมพ์หัวรอง', 'note': 'หมายเหตุ'}[p[0]]
        h0, n = h, 2
        while h in used: h = f'{h0} ({n})'; n += 1
        used.add(h); out = _put(out, list(p), h)
    return out, used

def unblank(d):
    """ตอนบันทึก: ข้อที่ปล่อยว่างในหน้าที่แทรกไม่ลงไฟล์ (เหลืออย่างน้อยข้อเดียว)"""
    its = d.get('items')
    if isinstance(its, list):
        keep = [r for r in its if any(v.strip() for _, v in _leaves(r))]
        if keep and len(keep) < len(its): return {**d, 'items': keep}
    return d

_rtrim = lambda r: r[:max(1, max((k + 1 for k, x in enumerate(r) if x.strip()), default=0))]   # ช่องว่างท้ายข้อ (แบบเดิมมีสามช่อง) ไม่นับ แบบใหม่ช่องน้อยกว่าก็ลงได้
def content_of(d, c):
    """คำที่ลูกค้าพิมพ์ในหน้าที่แทรก → เนื้อหา (หัวเรื่อง หัวรอง ข้อ) ไว้ลงแบบอื่นหรือหน้าตาอื่น
    ponytail: ช่องป้ายเล็กของ layout (นอกจากหัวเรื่อง หัวรอง หมายเหตุ ข้อ) ไม่ตามไป"""
    t = d['t'] if 't' in d else ' '.join(x for x in (d.get('t1', ''), d.get('t2', '')) if str(x).strip())
    c2 = dict(kind=c['kind'], _ins=1, t=t, s=d.get('s', ''))
    if d.get('note'): c2['note'] = d['note']
    its = d.get('items')
    if isinstance(its, list) and its:
        c2['items'] = ([(next((x for x in r if isinstance(x, str)), ''), next((x for x in r if isinstance(x, list)), [])) for r in its] if c['kind'] == 'compare'
                       else [(r,) if isinstance(r, str) else tuple(x for x in r if isinstance(x, str)) for r in its])
        typed = [r for r in c2['items'] if any(v.strip() for _, v in _leaves(r))]
        if typed: c2['items'] = typed if c['kind'] == 'compare' else [_rtrim(r) for r in typed]                      # ข้อที่ยังว่างไม่ต้องตามไป (แบบใหม่อาจรับจำนวนข้อไม่เท่าเดิม)
    return c2

def carry_ins(old_items, old_cs, old_order, items, cs, slug):
    """เปลี่ยนหน้าตาแล้ว หน้าที่ลูกค้าแทรกเองตามไปด้วย: คำเดิม แบบที่ใส่ได้ในหน้าตาใหม่ วางต่อจากหัวข้อเดิม แก้ items/cs ในที่
    คืน (ลำดับหน้าใหม่, จำนวนหน้าที่ตามไปไม่ได้)"""
    order, at, gone = list(range(len(items))), 0, 0
    for i in old_order:
        c = old_cs[i]
        if not c.get('_ins'):
            if c['kind'] == 'cover': at = 0
            elif c.get('_sec') is not None:
                ps = [p for p, j in enumerate(order) if cs[j].get('_sec') == c['_sec'] and not cs[j].get('_ins')]
                if ps: at = ps[-1]
            continue
        c2 = content_of(old_items[i][1], c); its = c2.get('items') or []
        typed = any(v.strip() for _, v in _leaves(its))
        tries = [c2] + ([dict(c2, items=its[:3]), dict(c2, items=its[:1])] if its and not typed else [])   # ยังไม่ได้พิมพ์ข้อ: จำนวนข้อว่างน้อยลงได้
        if its and c2['kind'] not in ('list', 'pairs', 'compare'):   # หน้าตาใหม่ไม่มีแบบชนิดนี้ (การ์ดตัวเลข ไทม์ไลน์): ลงเป็นรายการ/หัวข้อพร้อมคำอธิบาย คำครบ
            tries += [dict(x, kind='list' if all(len(r) == 1 for r in its) else 'pairs') for x in list(tries)]
        if not typed: tries.append({k: v for k, v in c2.items() if k != 'items'} | {'kind': 'statement'})
        alts, x = [], c2
        for x in tries:
            if len(order) >= MAXSLIDES: break
            alts = alternatives(x, slug)
            if alts: break
        if not alts: gone += 1; continue
        items.append(tuple(alts[0])); cs.append(dict(c, kind=x['kind'])); at += 1; order.insert(at, len(items) - 1)
    return order, gone

_covfill = None
def render(items, M, ttl, only=None, ins=(), hint=False):
    """[(layout, dict)] → ไบต์ .pptx  ลำดับขั้นเดียวกับ mk.py (เติมปก, สลับรายละเอียดตาม slug, พลิกปก, ฟอนต์ธีม)
    only = ตำแหน่งหน้าที่จะวาด (ปก/เลขหน้ายังคิดจากทั้งเด็ค) ใช้วาดใหม่เฉพาะหน้าที่แก้
    ins = ตำแหน่งหน้าที่ลูกค้าแทรก: hint (จอ) ช่องว่างโชว์คำใบ้สีเทา / ไม่ hint (ไฟล์) ข้อว่างไม่ลงไฟล์"""
    global _covfill
    if _covfill is None:                                   # ยืม _covfill จาก mk.py ตรง ๆ ไม่ก๊อปโค้ด (mk.py รันทันทีที่ import)
        tree = ast.parse(open(f'{K}/mk.py', encoding='utf-8').read())
        fn = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == '_covfill')
        ns = {'re': re}; exec(compile(ast.Module(body=[fn], type_ignores=[]), 'mk.py', 'exec'), ns)
        _covfill = ns['_covfill']
    M = dict(M, cat='', foot=ttl, th=ttl)
    eng.setpal(M['pal'], M.get('font', 'plex'), M.get('head'))
    prs = base.deck()
    seq = list(items)
    BOXES.clear()
    for i, (name, d) in enumerate(seq, 1):
        if only is not None and i - 1 not in only: continue
        d0, hs = d, ()
        if i - 1 in ins:
            if hint: d, hs = hinted(d, ins[i - 1] if isinstance(ins, dict) else '')
            else: d = unblank(d)
        dd = dict(topic=M.get('topic', 'office'), foot=ttl, n=f'{i:02d}')
        dd.update(d)
        if i == 1 and name in [n for n, _ in deck_of(M['slug'])['SEQ'][:1]]:
            dd0 = dict(dd); _covfill(dd, seq, M)
            if ''.join(str(dd.get('k', '')).split()) and ''.join(str(dd.get('k', '')).split()) in ''.join(ttl.split()):
                dd['k'] = ''                               # ป้ายบนปกไม่ซ้ำชื่อเรื่อง (ป้ายว่างถูกลบทั้งแคปซูล)
            strip_ = lambda x: {k: v for k, v in x.items() if k not in ('topic', 'foot', 'n')}
            if dd != dd0 and overflow(name, strip_(dd), M) and not overflow(name, strip_(dd0), M):
                dd = dd0                                   # ตัวเลขบนปกที่ยกจากหน้าอื่นทำให้ปกล้น/ชนกัน: ไม่ใส่ (ยังอยู่ในหน้าเดิมครบ)
            eng.setvar(sum(ord(c) * (k + 3) for k, c in enumerate(M['slug'])))
        else:
            eng.setvar(0)
        lay_cov3.TTL2.clear(); lay.L[name](prs, dd)
        if dd.get('_nf'): numfmt(prs.slides[-1], dd['_nf'], dd.get('_sn'))
        if dd.get('bsz'): shrink_text(prs.slides[-1], dd['bsz'])
        if dd.get('fsz'): fsize(prs.slides[-1], dd)
        scrub(prs.slides[-1], list(strings(dd)) + [ttl]); tidy(prs.slides[-1], d); drop_empty(prs.slides[-1]); thai_spacing(prs.slides[-1]); bind_nums(prs.slides[-1])
        if i == 1 and eng.vch(0, 2) and not M.get('nomirror'): eng.mirror(prs.slides[-1])
        bx = boxmap(prs.slides[-1], d, prs.slide_width, prs.slide_height)
        if lay_cov3.TTL2:                                  # ปกที่แยกหัวเรื่องเป็นกล่องละบรรทัด (ttl2): ขึ้นบรรทัดใหม่แล้วกล่องหัวเรื่องหายจากจอ แก้ต่อไม่ได้ → เว็บปิด Enter (ใบ 015 เฟส 0 P3)
            for b_ in bx:
                if b_['p'][0] in ('t', 't1', 't2'): b_['nobr'] = 1
        if hs:                                             # คำใบ้: สีเทา + บอกเว็บว่าช่องนี้ยังว่าง (เปิดแก้แล้วช่องพิมพ์ว่าง)
            from pptx.dml.color import RGBColor
            for sh in prs.slides[-1].shapes:
                if sh.has_text_frame and sh.text_frame.text.replace(' ', ' ').strip() in hs:
                    for p in sh.text_frame.paragraphs:
                        for r in p.runs: r.font.color.rgb = RGBColor(0x9A, 0xA3, 0xAF)
            for b in bx:
                if not str(_get(d0, b['p'])).strip(): b['ph'] = _get(d, b['p'])
        BOXES.append(bx)
    base.theme_font(prs, M.get('font', 'plex'))
    b = io.BytesIO(); prs.save(b)
    return b.getvalue()

FONT_HOWTO = """วิธีติดตั้งฟอนต์ (ทำครั้งเดียวต่อเครื่อง)

Windows: เลือกไฟล์ .ttf ทั้งหมด คลิกขวา แล้วเลือก "ติดตั้งสำหรับผู้ใช้ทั้งหมด" (Install for all users)
Mac: ดับเบิลคลิกไฟล์ .ttf แล้วกด "ติดตั้งฟอนต์" ทีละไฟล์
เสร็จแล้วปิด PowerPoint แล้วเปิดไฟล์สไลด์ใหม่อีกครั้ง

ถ้าเปิดในเครื่องที่ไม่ได้ติดตั้งฟอนต์ ข้อความยังอยู่ครบและแก้ได้ แต่ตัวอักษรจะเปลี่ยนเป็นฟอนต์อื่น
ฟอนต์ทั้งหมดใช้สัญญาอนุญาต SIL Open Font License (ดูไฟล์ OFL.txt) ใช้งานและแจกต่อได้ฟรี
"""

def fonts_zip(files):
    """ฟอนต์ของชุด + สัญญาอนุญาต + วิธีติดตั้ง เป็นไฟล์ zip ให้ลูกค้าโหลดคู่กับ .pptx"""
    import zipfile
    b = io.BytesIO()
    with zipfile.ZipFile(b, 'w', zipfile.ZIP_DEFLATED) as z:
        for f in files: z.write(f'{K}/fonts/{f}', f'ฟอนต์/{f}')
        if os.path.exists(f'{K}/fonts/OFL.txt'): z.write(f'{K}/fonts/OFL.txt', 'ฟอนต์/OFL.txt')
        z.writestr('วิธีติดตั้งฟอนต์.txt', FONT_HOWTO)
    return b.getvalue()

def words_missing(items, src):
    """ข้อความบนสไลด์ที่ไม่มีในไฟล์ต้นฉบับ  คำเดียวที่ระบบเติมเองคือ 'สารบัญ'"""
    return [v for _, d in items for v in strings({k: x for k, x in d.items() if k != 'num'})
            if v.strip() and v != 'สารบัญ' and not re.fullmatch(r'[\d.]+', v) and re.sub(r'\s+', '', v) not in src
            and not all(w in src for w in v.split())]   # ป้ายการ์ดตัวเลขตัดตัวเลขออก วลีเลยไม่ติดกัน แต่ทุกคำยังมาจากต้นฉบับ

if __name__ == '__main__':
    a = [x for x in sys.argv[1:] if not x.startswith('--')]
    path = os.path.abspath(a[0]); slug, e = slug_of(a[1])
    if not deck_of(slug): sys.exit(f'ชุด {a[1]} {e["th"]} ยังไม่มีไฟล์ต้นฉบับใน decks/ (มีแต่ .pptx)')
    ttl, want = analyze(path)
    M, out, log = plan(want, slug)
    print(f'ชุด {e["no"]} {e["th"]} ({e["theme"]})')
    for i, (c, nm, why, err) in enumerate(log, 1):
        n = len(c.get('items') or c.get('rows') or [])
        print(f'{i:2d}. {c["t"][:26]:<26} | {c["kind"]:<9} {n or "":>2} → {nm or "-"}  {err}')
        for w in why[:4]: print(f'        ข้าม {w}')
    items = [(x['layout'], x['d']) for x in out]
    print('ข้อความที่ไม่มีในต้นฉบับ:', [w for w in words_missing(items, source_text(path)) if w != ttl] or 'ไม่มี (ชื่อเรื่องจากชื่อไฟล์ไม่นับ)')
    os.makedirs(f'{K}/out', exist_ok=True)
    stem = re.sub(r'[^a-z0-9]+', '', os.path.splitext(os.path.basename(path))[0].lower())[:10] or 'doc'
    dst = f'{K}/out/d2s{a[1]}_{stem}.pptx'
    open(dst, 'wb').write(render(items, M, ttl)); print('→', dst)
    if '--render' in sys.argv:
        subprocess.run([f'{K}/../kit/render.sh', dst, dst[:-5] + '.pdf'], check=True)
