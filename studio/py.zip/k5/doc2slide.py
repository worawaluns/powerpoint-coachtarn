# python3 doc2slide.py <ไฟล์ docx/pdf/xlsx> <เลขชุดในคลัง> [--render]
# ไฟล์เดียวกันนี้รันในเบราว์เซอร์ด้วย (Pyodide) ที่ coachtarnslide.com/doc2slide — sync ด้วย d2s_web.py
# ต้นแบบ "แปลงเอกสารเป็นสไลด์" — ไม่ใช้ AI ทุกคำบนสไลด์มาจากไฟล์ลูกค้า
#   อ่าน docx → ตัดเป็นหัวข้อ → ดูรูปทรงเนื้อหา
#   → เลือกจาก layout ของ "ชุดที่ลูกค้าเลือก" เท่านั้น (ดีไซน์ สี ฟอนต์ ภาพ ของชุดนั้นทั้งหมด)
#   → วาด layout จริงลงไฟล์ทดลองแล้ววัดกรอบ ล้นก็เปลี่ยนตัว
#   → เขียนเด็คลง d2s/<ชื่อ>.py (META ของชุดนั้น + SEQ ใหม่) แล้วส่งให้ mk.py สร้าง .pptx
#
# layout ของชุดรับเนื้อหารูปทรงไหน อ่านจากตัวอย่างใน SEQ ของชุดนั้นเอง (decks/*.py)
# ponytail: ได้เฉพาะ 161 ชุดที่มีไฟล์ใน decks/ ชุดเก่าที่มีแต่ .pptx ต้องเขียนตัวเติมอีกแบบ
import sys, os, re, io, ast, glob, json, collections, inspect, importlib, importlib.util, unicodedata, subprocess, pprint
K = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, K); os.chdir(K)
import eng, lay, base, lay_cov3
import d2s_el as EL                                       # ใบ 027 คลังองค์ประกอบ: SVG → custGeom / ภาพบนจอจากรูปทรงชุดเดียวกัน
for f in sorted(glob.glob(f'{K}/lay_*.py')):           # ลงทะเบียนเลย์เอาต์เฉพาะชุดทั้งหมดเข้า lay.L เหมือน mk.py
    importlib.import_module(os.path.basename(f)[:-3])
HUB = os.path.expanduser('~/doublecraft-hub/projects/apps/powerpoint-coachtarn')
WEB = os.path.exists(f'{K}/fonts.json')                  # บนเว็บไม่มี fc-match ใช้แผนที่ฟอนต์ที่ d2s_web.py เขียนไว้
ICONS = {f.rsplit('.', 1)[0] for f in os.listdir(f'{K}/../kit/icons')}
# ชื่อหมวดรูป เช่น d.get('ptopic', 'office') ห้ามล้าง  บนเว็บโหลดรูปแค่บางหมวด เลยอ่านรายชื่อจากไฟล์
TOPICS = set(json.load(open(f'{K}/topics.json'))) if os.path.exists(f'{K}/topics.json') else set(os.listdir(eng.IMG))
SRC = {n: inspect.getsource(f) for n, f in lay.L.items()}
REQ = {n: set(re.findall(r"d\['(\w+)'\]", s)) - set(re.findall(r"d\.get\('(\w+)'", s)) for n, s in SRC.items()}
# ข้อความตั้งต้นที่ซ่อนอยู่ใน layout เช่น d.get('_l', 'ข้อเสนอบริการ ปี 2570') ของชุด 377
# ไม่ล้างทิ้ง ชื่อบริษัทสมมติของชุดจะไปโผล่บนสไลด์ลูกค้า
_MOD = {}
def _modsrc(n):
    m = sys.modules[lay.L[n].__module__]
    if m not in _MOD: _MOD[m] = inspect.getsource(m)
    return _MOD[m]
TXTDEF = {n: {k for k, v in re.findall(r"d\.get\('(\w+)',\s*'([^']*)'\)", s + _modsrc(n))
              if re.search(r'[A-Za-z\u0E00-\u0E7F]', v) and '{' not in v and v not in ICONS and v not in TOPICS} - {'topic', 'foot', 'n'}
          for n, s in SRC.items()}
ALLOW = {'สารบัญ'}                                         # คำเดียวที่ระบบเติมเอง
CAP = {n: int(m.group(1)) for n, s in SRC.items() for m in [re.search(r"d\['items'\]\[:(\d+)\]", s)] if m}
ROWCAP = {n: int(m.group(1)) for n, s in SRC.items() for m in [re.search(r"d\['rows'\]\[:(\d+)\]", s)] if m}   # ตารางที่วาดได้ไม่ครบทุกแถว

# ══ 1. อ่านไฟล์ → blocks ═══════════════════════════════════════════════════
# block = ('h', ระดับ, ข้อความ) | ('li', ข้อความ, มีเลขข้อ) | ('p', ข้อความ) | ('table', [[ช่อง...]])

def clean(t):
    """ตัดสัญลักษณ์นำหน้า (• - ✨) กับอีโมจิทิ้ง ฟอนต์ไทยในคลังไม่มีอีโมจิ ขึ้นเป็นกล่องเปล่า
    คำทุกคำยังอยู่ครบ ตัดแค่สัญลักษณ์ตกแต่ง"""
    t = ''.join(c for c in t if unicodedata.category(c) != 'So')
    return re.sub(r'^[\s•\-–*·]+', '', t).strip()

def read_docx(path):
    import docx
    from docx.table import Table
    from docx.text.paragraph import Paragraph
    d = docx.Document(path); out = []
    for el in d.element.body.iterchildren():           # เดินตามลำดับจริง ตารางแทรกกลางย่อหน้าได้
        tag = el.tag.rsplit('}', 1)[-1]
        if tag == 'tbl':
            rows = [[clean(c.text) for c in r.cells] for r in Table(el, d).rows]
            if rows: out.append(('table', rows))
            continue
        if tag != 'p': continue
        p = Paragraph(el, d); st = p.style.name.lower(); raw = p.text
        if not raw.strip(): continue
        m = re.match(r'(heading|หัวเรื่อง)\s*(\d)', st)
        if m or st == 'title':
            out.append(('h', int(m.group(2)) if m else 0, clean(raw))); continue
        numbered = 'number' in st or (p._p.pPr is not None and p._p.pPr.numPr is not None and 'bullet' not in st)
        if 'list' in st or numbered:
            out.append(('li', clean(raw), numbered)); continue
        for x in [x for x in raw.split('\n') if x.strip()]:   # ย่อหน้าที่พิมพ์ • หรือ 1. เองทีละบรรทัด
            if re.match(r'\s*[•\-–*·]\s', x): out.append(('li', clean(x), False))
            elif re.match(r'\s*\d{1,2}[.)]\s', x): out.append(('li', re.sub(r'^\s*\d{1,2}[.)]\s*', '', x).strip(), True))
            else: out.append(('p', clean(x)))
    return out

def read_pdf(path):
    """PDF ไม่มี style บอกหัวข้อ ดูจากขนาดตัวอักษร: ใหญ่กว่าเนื้อความชัด ๆ = หัวข้อ ใหญ่สุด = ชื่อเรื่อง
    ponytail: ไม่แกะตารางใน PDF ตารางจะออกมาเป็นบรรทัดข้อความ"""
    from pypdf import PdfReader
    lines_ = []                                           # (ขนาดฟอนต์, ข้อความ)
    for pg in PdfReader(path).pages:
        cur = {'sz': 0, 't': '', 'y': None}
        def vis(text, cm, tm, fd, fs):
            # ตำแหน่ง/ขนาดจริง = tm x cm  บรรทัดใหม่เมื่อ y เปลี่ยน (PDF จาก Chrome/Word ไม่ใส่ \n ให้)
            a_, b_ = tm[0] * cm[0] + tm[1] * cm[2], tm[0] * cm[1] + tm[1] * cm[3]
            y = tm[4] * cm[1] + tm[5] * cm[3] + cm[5]
            sz = round(abs(fs) * ((a_ * a_ + b_ * b_) ** 0.5 or 1), 1)
            if cur['y'] is not None and abs(y - cur['y']) > max(sz, 4) * 0.5 and cur['t'].strip():
                lines_.append((cur['sz'], cur['t'])); cur['t'] = ''; cur['sz'] = 0
            for i, part in enumerate(text.split('\n')):
                if i and cur['t'].strip(): lines_.append((cur['sz'], cur['t'])); cur['t'] = ''; cur['sz'] = 0
                if part.strip(): cur['t'] += part; cur['sz'] = max(cur['sz'], sz); cur['y'] = y
        pg.extract_text(visitor_text=vis)
        lines_.append((cur['sz'], cur['t']))
    # pypdf เติมช่องว่างหน้าสระ/วรรณยุกต์/จุดของคำย่อไทย ("ป .1" "พ . ค .") คืนให้ติดกันเหมือนต้นฉบับ
    lines_ = [(z, re.sub(r'(?<=[\u0E00-\u0E7F])\s+(?=[.\u0E31\u0E33-\u0E3A\u0E47-\u0E4E])', '', t)) for z, t in lines_]
    lines_ = [(z, re.sub(r'(?<=[\u0E01-\u0E2E]\.)\s+(?=[\u0E01-\u0E2E]\.)', '', t)) for z, t in lines_]
    lines_ = [(z, t.replace('\u0e4d\u0e32', '\u0e33').strip()) for z, t in lines_ if t.strip()]   # ํา → ำ
    if not lines_: return []
    # PDF ไทยหลายไฟล์ฝังฟอนต์แบบไม่มีตารางแปลงกลับเป็นตัวอักษร สระบน/วรรณยุกต์หายเป็นช่องว่างหรือ \x00
    # เอาขึ้นสไลด์แล้วดูพังทันที บอกลูกค้าตรง ๆ ดีกว่า
    allt = ' '.join(t for _, t in lines_)
    thai = len(re.findall(r'[\u0E01-\u0E2E]', allt))
    broken = allt.count('\x00') + len(re.findall(r'[\u0E01-\u0E2E] (?=[\u0E01-\u0E2E]{1,2}(?: |$))', allt))
    if thai and broken / thai > 0.02:
        raise ValueError('PDF นี้เก็บตัวอักษรไทยไว้ไม่ครบ (สระหรือวรรณยุกต์หาย) ใช้ไฟล์ Word (.docx) ต้นฉบับแทนจะได้ข้อความถูกต้อง')
    body = sorted(z for z, _ in lines_)[len(lines_) // 2]
    # ตัวเลขล้วน (เลขขั้นตอนตัวโต เลขหน้า) ไม่ใช่หัวข้อ ทิ้งไปเลย
    lines_ = [(z, t) for z, t in lines_ if re.search(r'[A-Za-z\u0E01-\u0E2E]', t)]
    if not lines_: return []
    big = sorted({z for z, t in lines_ if z >= body * 1.18 and len(t) <= 90}, reverse=True)
    lvl = {z: min(i + 1, 3) for i, z in enumerate(big)}
    out = []
    full = sorted(len(t) for _, t in lines_)[int(len(lines_) * 0.9)]   # ความยาวบรรทัดเต็มแถวโดยประมาณ
    prev_full = False
    for z, t in lines_:
        if z in lvl: out.append(('h', lvl[z], clean(t)))
        elif re.match(r'\s*[•\-–*·▪●○]\s*', t): out.append(('li', clean(t), False))
        elif re.match(r'\s*\d{1,2}[.)]\s', t): out.append(('li', re.sub(r'^\s*\d{1,2}[.)]\s*', '', t).strip(), True))
        elif out and out[-1][0] == 'p' and prev_full and not re.search(r'[.!?:]$', out[-1][1]):
            out[-1] = ('p', out[-1][1] + ' ' + clean(t))  # บรรทัดที่ PDF ตัดกลางย่อหน้า ต่อกลับเป็นย่อหน้าเดียว
        else: out.append(('p', clean(t)))
        prev_full = len(t) >= full * 0.85                  # บรรทัดยาวเต็มแถว = ย่อหน้ายังไม่จบ
    return out

def xl_text(v, fmt):
    """ตัวเลขตามที่เซลล์แสดง: ทศนิยมตามรูปแบบเซลล์ เปอร์เซ็นต์ยังเป็นเปอร์เซ็นต์ ไม่ปัดเองถ้าเซลล์ไม่ได้ปัด
    ponytail: อ่านแค่จำนวนทศนิยม/%/ตัวคั่นหลักพันจากรูปแบบ สัญลักษณ์เงินในรูปแบบเซลล์ไม่ใส่ให้"""
    if v is None: return ''
    if isinstance(v, bool) or not isinstance(v, (int, float)): return str(v).strip()
    f = re.sub(r'"[^"]*"|\[[^\]]*\]|\\.', '', (fmt or 'General').split(';')[0])
    m = re.search(r'\.(0+)', f); d = len(m.group(1)) if m else 0
    if '%' in f: return f'{v * 100:,.{d}f}%'
    if m or re.search(r'[0#]', f): return f'{v:,.{d}f}'
    return f'{v:.0f}' if float(v).is_integer() else format(v, '.10g')      # General: เหมือนเซลล์ ไม่มีตัวคั่นหลักพัน ทศนิยมเท่าที่พิมพ์

def read_xlsx(path):
    """แต่ละชีต = หนึ่งหัวข้อ เป็นตารางหนึ่งตาราง ชื่อชีตเป็นหัวข้อ"""
    import openpyxl
    wb = openpyxl.load_workbook(path, data_only=True, read_only=True); out = []
    for ws in wb.worksheets:
        rows = []
        for r in ws.iter_rows(max_col=8):                      # ponytail: 8 คอลัมน์ 9 แถวแรก (หัว+8) ไฟล์ 5,000 แถวไม่ต้องอ่านทั้งหมด
            if len(rows) >= 9: break
            cells = [xl_text(c.value, getattr(c, 'number_format', 'General')) for c in r]
            while cells and not cells[-1]: cells.pop()
            if any(cells): rows.append(cells)
        if not rows: continue
        w = max(len(r) for r in rows)
        out += [('h', 2, ws.title), ('table', [r + [''] * (w - len(r)) for r in rows])]
        if (ws.max_row or 0) > 9 or (ws.max_column or 0) > 8: NOTES.append(f'ชีต "{ws.title}" ใช้หัวตารางกับ 8 แถวแรก และ 8 คอลัมน์แรก ส่วนที่เหลือของชีตยังไม่ได้ทำเป็นสไลด์')
    return out

NOTES = []                                                 # สิ่งที่ระบบตัดทิ้ง ต้องบอกลูกค้าตรง ๆ
INFO = {}                                                  # สิ่งที่อ่านได้จริง (จำนวนหัวข้อที่มีชื่อ) ให้แชทพูดตรงกับที่เจอ
MAXSLIDES = 30                                             # มือถือรับไม่ไหวถ้าเกินนี้ (คำนวณ + พรีวิว)

MARK = r'\s*((วาระ(ที่)?|หัวข้อ(ที่)?|ส่วน(ที่)?|บท(ที่)?|ตอน(ที่)?|ภาค(ที่)?|เรื่อง(ที่)?|ข้อ(ที่)?)\s*\d{1,2}(\.\d+)?\b|\d{1,2}[.)](?=\s))'

LABEL_RE = re.compile(r'(เงื่อนไข|หมายเหตุ|ข้อเสนอแนะ|ข้อสังเกต|สรุป)\s+')   # คำป้ายหัวข้อสั้นที่ขึ้นต้นบรรทัดแล้วตามด้วยเนื้อ

def headsplit(l):
    """บรรทัดที่ขึ้นต้นด้วยเครื่องหมายหัวข้อ → (ชื่อหัวข้อ, ข้อที่เหลือ)  ชื่อ = เครื่องหมาย + วลีแรก (ถึงรอยต่อความ ก่อนตัวเลข)
    คำทั้งหมดเป็นของลูกค้า ไม่เติมคำ"""
    mk = re.match(MARK, l); rest = clean(l[mk.end():]).strip(); cl = clauses(rest)
    head = cl[0] if cl else ''
    ws = head.split(' ')                                   # ตัดก่อนจำนวน (350,000 บาท) แต่ไม่ตัดเลขลำดับ (ครั้งที่ 2)
    qty = lambda n: re.search(r'\d[\d,]*(\.\d+)?%?$', ws[n]) and (re.search(r'[,%]', ws[n]) or (n + 1 < len(ws) and re.match(UNIT, ws[n + 1])))
    k = next((n for n, w in enumerate(ws) if n and qty(n) and not ws[n - 1].endswith('ที่')), len(ws))   # ตัดก่อนจำนวนเงิน/จำนวนนับเท่านั้น
    head, tail = ' '.join(ws[:k]), ' '.join(ws[k:])
    if len(head) > 40:                                     # วลีแรกยาวเกินหัวข้อ: ถึงเว้นวรรคแรกหลัง 6 ตัว
        nounish = lambda x: (wordsx(x) or [''])[0] in ('ชั้น', 'ระดับ', 'จำนวน', 'ให้')   # ต้นข้อได้ (ชั้น ป.1 / ให้นำ...) ไม่ใช่คำเชื่อมท้ายหัวข้อ
        sp_ = next((m.start() for m in re.finditer(' ', head) if m.start() >= 6 and not head[:m.start()].endswith('ที่')
                    and (not cont(head[m.start() + 1:]) or nounish(head[m.start() + 1:]))
                    and (words(head[:m.start()].split(' ')[-1]) or [''])[-1] not in TAIL | {'ชั้น', 'ระดับ'}
                    and not re.search(r'\d', head[m.start() + 1:].split(' ')[0])), None)   # ไม่จบหัวข้อด้วยคำเชื่อม/ลักษณนาม ไม่แยก "ชั้น ป.1"   # ไม่ตัดเลขลำดับออกจาก "ครั้งที่" ไม่ตัดหน้าคำเชื่อม
        if sp_: tail = (head[sp_ + 1:] + ' ' + tail).strip(); head = head[:sp_]
    marker = l[:mk.end()].strip()
    rest = ' '.join(x for x in [tail] + cl[1:] if x)
    return (marker + ' ' + head).strip(), rest

def read_txt(path):
    """ข้อความที่ลูกค้าพิมพ์/วางในช่องแชท อ่านโครงแบบทั่วไป ไม่ผูกกับเอกสารตัวอย่าง:
    บรรทัดแรก = ชื่อเรื่อง (ถ้าตามด้วยบรรทัดอื่น) / หัวข้อ = บรรทัดที่ขึ้นต้นด้วย วาระที่ N, ข้อ N, N., N), เลขไทย ๑-๙
    หรือบรรทัดสั้น (≤40 ตัว) ที่ตามด้วยบรรทัดยาวกว่า / ในหัวข้อ แต่ละบรรทัดคือหนึ่งข้อ บรรทัดยาวแบ่งที่ท้ายประโยคหรือก่อนคำขึ้นเรื่อง
    รองรับ # หัวข้อ, - • * รายการ, ตาราง (คั่นด้วย tab หรือ |)"""
    L = [l.rstrip() for l in open(path, encoding='utf-8').read().replace('\r', '').split('\n')]
    bullet = lambda l: re.match(r'\s*[•\-–*·▪●○]\s+\S', l)
    numl = lambda l: re.match(r'\s*\d{1,2}[.)]\s+\S', l)
    out, i, first, prev_num = [], 0, True, False
    # ระดับหัวข้อ: ใช้เครื่องหมายระดับสูงสุดที่มีในเอกสารเป็นหัวข้อ ระดับรองลงไปเป็นข้อ (๑. เป็นหัวข้อ ข้อ 1) เป็นข้อ)
    def mkind(l):
        m = re.match(MARK, l)
        if not m: return None
        g = m.group(0).strip()
        if re.match(r'(วาระ|หัวข้อ|ส่วน|บท|ตอน|ภาค|เรื่อง)', g): return 0
        if re.match(r'[๐-๙]', g): return 1
        if re.match(r'\d{1,2}\.', g): return 2
        if g.startswith('ข้อ'): return 3
        return 4                                           # N)
    kinds = [k for k in (mkind(x.strip()) for x in L if x.strip()) if k is not None]
    top = min(kinds) if kinds else None
    explicit = top is not None
    def points_of(t):                                      # บรรทัดยาวในหัวข้อ → หลายข้อ (ท้ายประโยค/คำขึ้นเรื่อง)
        for x in points(t): out.append(('li', x, False))
    while i < len(L):
        l = L[i].strip()
        if not l: i += 1; continue
        cells = [c.strip() for c in re.split(r'\t|\s*\|\s*', l.strip('|'))] if ('\t' in l or l.count('|') >= 2) else None
        if cells and len(cells) >= 2:                 # ตาราง: เก็บแถวติดกันที่จำนวนช่องเท่ากัน
            rows = []
            while i < len(L) and L[i].strip() and ('\t' in L[i] or L[i].count('|') >= 2):
                r = [c.strip() for c in re.split(r'\t|\s*\|\s*', L[i].strip().strip('|'))]
                if not all(re.fullmatch(r':?-{2,}:?', c) for c in r if c): rows.append(r)   # ข้ามเส้นคั่นของ markdown
                i += 1
            w = max(len(r) for r in rows); out.append(('table', [r + [''] * (w - len(r)) for r in rows])); first = False; continue
        nx_ = [x.strip() for x in L[i + 1:] if x.strip()][:2] + ['', '']
        nxt, nxt2 = nx_[0], nx_[1]
        is_num = bool(numl(l))
        sib = is_num and nxt and numl(nxt) and mkind(nxt) == mkind(l) and int(re.match(r'\s*(\d+)', nxt).group(1)) == int(re.match(r'\s*(\d+)', l).group(1)) + 1
        list_num = is_num and (prev_num or (nxt and numl(nxt) and (len(l) <= 70 or sib)))   # 1. 2. 3. ติดกันสั้น ๆ = รายการมีเลข ไม่ใช่หัวข้อ / ใบ 045: ๑. ๒. ต่อเลขกันโดยไม่มีเนื้อคั่น = ข้อพี่น้อง แม้ข้อยาว (บันทึกข้อความ ๑. เป็นหัวข้อ ๒-๕ เป็นข้อ)
        if l.startswith('#'):
            lv = min(len(l) - len(l.lstrip('#')), 3); out.append(('h', lv, clean(l.lstrip('#')))); first = False
        elif first and not bullet(l) and not re.match(MARK, l) and len(l) <= 90 and nxt:
            out.append(('h', 1, clean(l))); first = False     # บรรทัดแรก = ชื่อเรื่อง
        elif re.match(MARK, l) and not list_num and mkind(l) == top:
            head, rest = headsplit(l); out.append(('h', 2, head)); first = False
            if rest: points_of(rest)
        elif re.match(MARK, l) and mkind(l) != top:
            out.append(('li', clean(l), True)); first = False   # เครื่องหมายระดับรอง (ข้อ 1)) = ข้อในหัวข้อ
        elif bullet(l) or is_num:
            txt = re.sub(r'^\s*([•\-–*·▪●○]|\d{1,2}[.)])\s+', '', l)
            if is_num and nxt and bullet(nxt):           # "1. หัวข้อ" ตามด้วยรายการ = หัวข้อ
                out.append(('h', 2, clean(txt)))
            else: out.append(('li', clean(txt), is_num))
            first = False
        elif len(l) <= 60 and not re.search(r'[.!?]$', l) and not re.search(r'\d', l) and nxt and \
                (bullet(nxt) or (numl(nxt) and (mkind(nxt) != top or (numl(nxt2) and len(nxt) <= 70))) or ('\t' in nxt or nxt.count('|') >= 2)):
            out.append(('h', 2, clean(l.rstrip(':：')))); first = False   # บรรทัดสั้นที่ตามด้วยรายการ (รวม 1. 2. ติดกันสั้น ๆ) หรือตาราง = หัวข้อ
        elif re.fullmatch(r'.{1,60}[:：]', l):
            out.append(('h', 2, clean(l.rstrip(':：')))); first = False
        elif LABEL_RE.match(l) and len(l) > LABEL_RE.match(l).end() + 8:
            m_ = LABEL_RE.match(l); out.append(('h', 2, m_.group(1))); first = False   # "เงื่อนไข ส่งมอบ..." = หัวข้อ + เนื้อ
            points_of(clean(l[m_.end():]))
        elif not explicit and len(l) <= 40 and not re.match(r'\s*(\d|รวม|ยอดรวม|เรียน |ขอแสดงความนับถือ|ลงชื่อ)', l) and not re.search(r'(ดังนี้|บาท|[.!?%:])$', l) and nxt and len(nxt) > len(l) + 10 and not re.match(MARK, nxt) \
                and not (out and out[-1][0] in ('p', 'li') and any(b[0] == 'h' for b in out) and re.search(r'\d', l)):   # ข้อในรายการที่กำลังดำเนิน (มีตัวเลข) ไม่ขึ้นหัวข้อใหม่
            out.append(('h', 2, clean(l))); first = False    # บรรทัดสั้นที่ตามด้วยบรรทัดยาวกว่า = หัวข้อ
        elif len(l) > 140 and not (first and not nxt): points_of(clean(l)); first = False   # บรรทัดเดียวทั้งเอกสาร: ให้โหมดย่อหน้าเดียวจัด
        else: out.append(('p', clean(l))); first = False
        prev_num = is_num
        i += 1
    return out

def read_any(path):
    NOTES.clear()
    ext = path.lower().rsplit('.', 1)[-1]
    return {'docx': read_docx, 'pdf': read_pdf, 'xlsx': read_xlsx, 'txt': read_txt}[ext](path)

def source_text(path):
    """ข้อความทั้งหมดในไฟล์ลูกค้า ไว้ตรวจว่าทุกคำบนสไลด์มาจากไฟล์นี้"""
    return re.sub(r'\s+', '', ' '.join(b[2] if b[0] == 'h' else (' '.join(' '.join(r) for r in b[1]) if b[0] == 'table' else b[1])
                                     for b in read_any(path)))

# ══ 2. ตัดเป็นหัวข้อ ═══════════════════════════════════════════════════════

def sections(blocks):
    """หัวเรื่องระดับบนสุดที่มีอันเดียว = ชื่อเด็ค, ระดับถัดมา = หนึ่งหัวข้อ, ลึกกว่านั้น = กลุ่มย่อย"""
    lv = sorted({b[1] for b in blocks if b[0] == 'h'})
    title, top = None, lv[0] if lv else 9
    if len(lv) > 1 and sum(1 for b in blocks if b[0] == 'h' and b[1] == lv[0]) == 1:
        top = lv[1]
    elif len(lv) == 1 and blocks and blocks[0][0] == 'h' and sum(1 for b in blocks if b[0] == 'h') == 1:
        top = lv[0] + 1                                    # หัวเรื่องเดียวบรรทัดแรก = ชื่อเรื่อง (ไม่ใช่หัวข้อเดียวของทั้งเอกสาร)
    secs = []
    for b in blocks:
        if b[0] == 'h' and b[1] < top: title = title or b[2]; continue
        if b[0] == 'h' and b[1] == top:
            num = re.match(r'^(\d{1,2})[.)]\s+', b[2])
            secs.append(dict(t=b[2][num.end():] if num else b[2], num=num.group(1) if num else '', body=[]))
            continue
        if not secs: secs.append(dict(t='', num='', body=[]))
        secs[-1]['body'].append(b)
    return title, [s for s in secs if s['t'] or s['body']]

# ══ 3. ดูรูปทรงเนื้อหา (ยังไม่เกี่ยวกับ layout) ═══════════════════════════════
# หนึ่งแผ่น = dict(kind, t, items/...)  kind: divider statement list pairs qa stat timeline table chart compare

NUM = r'[\d][\d,\.]*\s*(?:%|฿|บาท|คน|ราย|ครั้ง|วัน|เดือน|ปี|ชั่วโมง|หน้า|ล้าน|แห่ง|โรงเรียน|ชิ้น|\+)'
DATE = (r'(พ\.ศ\.|ค\.ศ\.|\b25[5-9]\d\b|\b20[2-4]\d\b|(?:ม\.ค|ก\.พ|มี\.ค|เม\.ย|พ\.ค|มิ\.ย|ก\.ค|ส\.ค|ก\.ย|ต\.ค|พ\.ย|ธ\.ค)\.'
        r'|มกราคม|กุมภาพันธ์|มีนาคม|เมษายน|พฤษภาคม|มิถุนายน|กรกฎาคม|สิงหาคม|กันยายน|ตุลาคม|พฤศจิกายน|ธันวาคม|ไตรมาส)')

def pair(t):
    """'หัว: เนื้อ' หรือ 'Q: ...\\nA: ...' → (ชนิด, หัว, เนื้อ)  ไม่ใช่คู่ → None"""
    qa = re.match(r'\s*Q\s*[:.]\s*(.+?)\s*\n\s*A\s*[:.]\s*(.+)', t, re.S)
    if qa: return ('qa', qa.group(1).strip(), qa.group(2).strip())
    m = re.match(r'([^:：\n]{1,40}?)\s*[:：]\s+(.+)', t, re.S)
    if m and not re.match(r'https?$', m.group(1)): return ('kv', m.group(1).strip(), m.group(2).strip())
    return None

def isnum(c): return bool(re.fullmatch(r'-?[\d,]+(\.\d+)?%?', c.replace(' ', '')))
def tonum(c):
    v = float(c.replace(',', '').replace('%', '').replace(' ', ''))
    return int(v) if v.is_integer() else v               # 220 ไม่ใช่ 220.0 บนกราฟ

def _commas(f):
    """รูปแบบตัวเลขของกราฟ: มีตัวคั่นหลักพันเสมอ (0 → #,##0 / 0.0"%" → #,##0.0"%") General คงเดิม"""
    f = str(f or 'General')
    return '#,##0' + f[1:] if f.startswith('0') else f

def chart_commas(slide):
    """ไอซ์ 1 พ.ย. 2569 ตัวคั่นหลักพันเป็นค่าเริ่ม: ทุกกราฟจริงในหน้า ป้ายค่า (ชุด/ทั้งกราฟ) + แกนค่า เขียนรูปแบบเองชัด ๆ (sourceLinked=0)
    รูปแบบ = ของชุดข้อมูล (numCache) ที่มีจุลภาค ทศนิยม/% คงเดิม  ป้ายรายจุด (c:dLbl) ที่มีรูปแบบของตัวเองก็ใส่จุลภาค"""
    from lxml import etree
    from pptx.oxml.ns import qn
    for gf in [x for x in slide.shapes if getattr(x, 'has_chart', False) and x.has_chart]:
        cs = gf.chart._chartSpace; top = None
        for pl in gf.chart.plots:
            pdl = pl._element.find(qn('c:dLbls'))
            for i, sr in enumerate(pl.series):
                code = _commas((sr._element.xpath('./c:val//c:formatCode/text()') or ['#,##0'])[0])
                if code == 'General': code = '#,##0'
                top = top or code
                for dl in [sr._element.find(qn('c:dLbls'))] + ([pdl] if i == 0 else []):
                    if dl is None or dl.find(qn('c:delete')) is not None: continue
                    for q in dl.findall(qn('c:dLbl')):
                        e = q.find(qn('c:numFmt'))
                        if e is not None: e.set('formatCode', _commas(e.get('formatCode'))); e.set('sourceLinked', '0')
                    e = dl.find(qn('c:numFmt'))
                    if e is None:
                        e = etree.Element(qn('c:numFmt')); last = dl.findall(qn('c:dLbl')); (last[-1].addnext(e) if last else dl.insert(0, e)); e.set('formatCode', code)
                    else: e.set('formatCode', _commas(e.get('formatCode')))
                    e.set('sourceLinked', '0')
        for ax in cs.iter(qn('c:valAx')):
            e = ax.find(qn('c:numFmt'))
            if e is not None and (e.get('sourceLinked') == '1' or str(e.get('formatCode', '')).startswith('0')): e.set('formatCode', _commas(e.get('formatCode')) if e.get('sourceLinked') != '1' else (top or '#,##0')); e.set('sourceLinked', '0')

def xlfmt(c):
    """ตัวเลขตามที่เซลล์/ลูกค้าแสดง → รูปแบบตัวเลข Excel ของกราฟ (1,234 → #,##0 / 12.5% → 0.0"%" / 120000 → 0)"""
    c = c.replace(' ', ''); m = re.search(r'\.(\d+)', c)
    return ('#,##0' if ',' in c else '0') + ('.' + '0' * len(m.group(1)) if m else '') + ('"%"' if c.endswith('%') else '')

PERIOD = DATE + r'|\bQ[1-4]\b|\bH[12]\b|ครึ่งปี|ก่อน|หลัง|เป้า|แผน|จริง|ปีนี้|ปีที่แล้ว|ปีก่อน|เดือนนี้|เดือนก่อน|เดิม|ใหม่|รุ่น|เวอร์ชัน|\bv\d|รอบ|ครั้งที่|งวด|สัปดาห์'
def periodish(h):
    """หัวคอลัมน์ที่เป็นช่วงเวลา/รุ่น/เป้า-จริง ของค่าเดียวกัน (ปี 2568, Q1, ก่อน/หลัง) → ห้ามซ้อนแท่ง"""
    return bool(re.search(PERIOD, h, re.I))

def mixedcol(cells):
    """คอลัมน์ตัวเลขที่ทำกราฟไม่ได้: หน่วยปน (% กับเลขเปล่า) หรือค่าห่างกันเกิน 40 เท่า (ไม่นับ 0) แท่งเล็กสุดต่ำกว่า 2.5% ของแท่งใหญ่สุด แบนเป็นเส้น
    (เดิม 10 เท่า ซ่อนกราฟที่อ่านได้จริง เช่น 5,000 กับ 80,000 — slide-judge 29 ต.ค. 2569) / หลายชุดยังใช้กฎ 10 เท่าเทียบค่าสูงสุดของแต่ละชุดแยกต่างหาก"""
    if len({c.strip().endswith('%') for c in cells}) > 1: return True
    v = [abs(tonum(c)) for c in cells if tonum(c)]
    return bool(v) and max(v) / min(v) > 40

def chunk(xs, n=5):
    """เกิน n ข้อตัดเป็นหลายแผ่น แบ่งให้เท่ากัน (8 → 4+4 ไม่ใช่ 5+3)"""
    if len(xs) <= n: return [xs]
    k = -(-len(xs) // n); m = -(-len(xs) // k)
    return [xs[i:i + m] for i in range(0, len(xs), m)]

def shapes(sec):
    t, body = sec['t'], sec['body']
    lis = [b for b in body if b[0] == 'li']; ps = [b[1] for b in body if b[0] == 'p']
    tables = [b[1] for b in body if b[0] == 'table']; subs = [b for b in body if b[0] == 'h']
    note = ' '.join(ps)

    if tables and (len(note) > 80 or len(ps) > 1):      # ตารางที่มีคำอธิบายยาว: ตารางอยู่หน้าของตัวเอง คำอธิบายเป็นรายการหน้าถัดไป (ไม่ปนในการ์ดแถว)
        rest = [x for p_ in ps for x in points(p_)]
        return shapes(dict(sec, body=[b for b in body if b[0] != 'p'])) + \
            [dict(kind='list', t=t, ordered=False, note='', items=[(x,) for x in part]) for part in gchunk(rest)]
    if tables:
        head, data = tables[0][0], tables[0][1:]
        numcols = [j for j in range(1, len(head)) if data and all(len(r) > j and isnum(r[j]) for r in data)]
        if numcols and 2 <= len(data) <= 8:
            ser = [(head[j], [tonum(r[j]) for r in data]) for j in numcols]
            nf = [[xlfmt(r[j]) for r in data] for j in numcols]   # รูปแบบตัวเลขตามเซลล์ต้นทาง ลงป้ายบนกราฟและชีตฝัง
            cats = [r[0] for r in data]
            if len(numcols) == 1:
                j = numcols[0]; v = ser[0][1]
                if mixedcol([r[j] for r in data]): return [dict(kind='table', t=t, note=note, head=head, rows=data)]   # ค่าปนหน่วย/ขนาดห่างเกิน 40 เท่า (12.345 / 12.5% / 1,250,000) เทียบความสูงแท่งไม่ได้
                # สัดส่วนของทั้งก้อน: ทุกช่องเป็น % รวมได้ 100 (ปัดเศษ ±1) ไม่มีค่าติดลบ → โดนัทได้ (ชุดที่มี)
                share = len(data) <= 6 and all(r[j].strip().endswith('%') for r in data) and abs(sum(v) - 100) <= 1 and min(v) > 0
                return [dict(kind='chart', t=t, s=head[j], note=note, head=head, rows=data, cats=cats, vals=v, series=ser,
                             _nf=nf, _col=j, **({'_share': 1} if share else {}))]
            # หลายชุดข้อมูล: ทุกคอลัมน์ (นอกจากป้าย) เป็นตัวเลข หน่วยเดียวกัน (% ทั้งหมดหรือไม่มีเลย) ขนาดใกล้กัน (ไม่เกิน 10 เท่า)
            # ไม่งั้นเป็นตาราง (พนักงาน 12 คน กับยอด 540,000 บาท ในกราฟเดียวกันอ่านไม่ได้ / ห้ามทิ้งคอลัมน์ข้อความ)
            mx = [max(abs(x) for x in vs) or 1 for _, vs in ser]
            pct = {all(r[j].strip().endswith('%') for r in data) for j in numcols}
            if numcols == list(range(1, len(head))) and len(numcols) <= 3 and len(pct) == 1 and max(mx) / min(mx) <= 10 \
                    and not any(len({r[j].strip().endswith('%') for r in data}) > 1 for j in numcols):
                # แท่งซ้อนได้เฉพาะคอลัมน์ที่เป็นส่วนของก้อนเดียวกัน (ค่าเช่า + ค่าแรง = ต้นทุนรวม): หัวข้อมีคำ รวม/แยกตาม/ประกอบ
                # หัวคอลัมน์เป็นช่วงเวลา/รุ่น (ปี 2568 กับ 2569, เป้า/จริง, ก่อน/หลัง) ห้ามซ้อน ผลรวมไม่มีความหมาย / ไม่แน่ใจ = ไม่ซ้อน (แท่งคู่)
                part = re.search(r'รวม|ทั้งหมด|แยกตาม|ประกอบ', f'{t} {note} {head[0]}') and not any(periodish(head[j]) for j in numcols)
                return [dict(kind='chart', t=t, note=note, head=head, rows=data, cats=cats, series=ser, _nf=nf, **({'_stack': 1} if part else {}))]
        return [dict(kind='table', t=t, note=note, head=head, rows=data)]

    if len(subs) == 2:                                   # สองกลุ่มย่อย = เทียบกัน
        groups, cur = [], None
        for b in body:
            if b[0] == 'h': cur = [b[2], []]; groups.append(cur)
            elif cur and b[0] in ('li', 'p'): cur[1].append(b[1])
        return [dict(kind='compare', t=t, items=[(g[0], g[1]) for g in groups])]

    if lis and ps and len(note) <= 60: lis = lis + [('li', x, False) for x in ps]; note = ''   # บรรทัดปิดสั้น ๆ (เลิกประชุมเวลา...) อยู่ในเนื้อ ไม่ใช่หมายเหตุตัวจิ๋ว
    texts = [b[1] for b in lis] if lis else (ps if len(ps) > 1 else [])
    if not lis: note = ''                                  # ย่อหน้ากลายเป็นข้อไปแล้ว อย่าซ้ำเป็นหมายเหตุ
    lead = []
    while len(texts) >= 3 and (texts[0].startswith('เรียน ') or re.search(r'ดังนี้\s*:?$', texts[0])):
        lead.append(texts.pop(0))                          # คำขึ้นต้นจดหมาย / "ขอเสนอราคาดังนี้" = ข้อความนำ ไม่ใช่ข้อหรือหัวข้อ
    if lead: note = ' '.join(lead + ([note] if note else [])); sec['_lead'] = 1
    if len(texts) >= 3 and re.match(r'(รวมทั้งสิ้น|รวมเป็นเงิน|รวมทั้งหมด|ยอดรวม)\s*\d', texts[-1]):
        note = (note + ' ' + texts.pop()).strip(); sec['_lead'] = 1; sec['_leadend'] = 1   # ยอดรวมท้ายรายการ = ยอดปิด ไม่ใช่ข้อ
    if len(texts) >= 3 and re.fullmatch(r'\d[\d,.]*\s*[^\s\d]{0,12}', texts[0]) and all(re.search(r'\d', x) for x in texts[1:]):
        note = (texts[0] + ' ' + note).strip(); texts = texts[1:]; sec['_lead'] = 1   # ข้อแรกเป็นแค่ยอดรวม (85,000 บาท) ตามด้วยส่วนย่อย = ข้อความนำ ไม่ใช่ข้อระดับเดียวกัน
    if not texts:
        if ps: return [dict(kind='statement', t=ps[0], s=t)]
        return [dict(kind='divider', t=t, num=sec['num'])]

    prs = [pair(x) for x in texts]
    if all(p and p[0] == 'qa' for p in prs):
        return [dict(kind='qa', t=t, items=part) for part in chunk([(p[1], p[2]) for p in prs], 4)]

    # ตัวเลขพร้อมหน่วย หรือเลขที่มีหลักพัน/ทศนิยม (1,240 / 68.5) ไม่นับเลขปี 4 หลักเปล่า ๆ
    nums = [re.search(NUM, x) or re.search(r'(?<![\d.])\d{1,3}(?:,\d{3})+(?:\.\d+)?|(?<![\d.])\d+\.\d+', x) for x in texts]
    whole = lambda x, m: m and (m.start() == 0 or x[m.start() - 1] == ' ') and not re.search(r'\d[.:]\d{2}\s*[-–]', x)   # ค่าต้องเป็นคำเต็ม ไม่ใช่ช่วงเวลา 14.30-15.30
    nums = [m if whole(x, m) else None for x, m in zip(texts, nums)]
    onenum = lambda x: len(re.findall(r'\d[\d,.]*', x)) == 1 and not re.search(r'(ละ|ราคา|จำนวน)\s*\d', x)   # ป้าย + ตัวเลขเดียว ถึงทำการ์ดได้ (ดึงเลขออกจากประโยคแล้วเหลือ "ราคาชุดละ" ห้าม)
    if len(texts) >= 2 and all(nums) and all(map(onenum, texts)) and not all(re.search(DATE, x) for x in texts):   # ทุกข้อมีตัวเลข → การ์ดตัวเลข ทีละไม่เกิน 4 ใบ
        st = [(x, m) for x, m in zip(texts, nums)]
        return [dict(kind='stat', t=t, note=note, raw=[x for x, _ in part], **({'_lead': 1} if sec.get('_lead') else {}), **({'_leadend': 1} if sec.get('_leadend') else {}),
                     items=[(m.group(0).strip(), re.sub(r'\s{2,}', ' ', x[:m.start()] + x[m.end():]).strip(' :,-')) for x, m in part])
                for part in chunk(st, 4)]

    TR = r'^\d{1,2}[.:]\d{2}\s*[-–]\s*\d{1,2}[.:]\d{2}(?:\s*น\.)?'
    if len(texts) >= 3 and all(re.match(TR, x) for x in texts):   # กำหนดการ (เวลา + กิจกรรม) = ไทม์ไลน์ ทีละไม่เกิน 5 ช่วง
        tl = [(re.match(TR, x).group(0), x[re.match(TR, x).end():].strip()) for x in texts]
        return [dict(kind='timeline', t=t, items=part) for part in chunk(tl, 12)]   # หน้าละกี่ช่วงให้ตัวจัดแบ่งเท่า ๆ กันตามที่หน้าตารับได้
    if 3 <= len(texts) <= 5 and all(re.search(DATE, x) for x in texts):
        return [dict(kind='timeline', t=t, items=[(p[1], p[2]) if p else (re.search(DATE, x).group(0), x)
                                                  for x, p in zip(texts, prs)])]

    ordered = bool(lis) and all(b[2] for b in lis)
    kv = all(p and p[0] == 'kv' for p in prs)
    out = []
    for part in chunk(list(zip(texts, prs))):
        ld = dict({'_lead': 1} if sec.get('_lead') else {}, **({'_leadend': 1} if sec.get('_leadend') else {}))
        if kv: out.append(dict(kind='pairs', t=t, ordered=ordered, note=note, items=[(p[1], p[2]) for _, p in part], **ld))
        else: out.append(dict(kind='list', t=t, ordered=ordered, note=note, items=[(x,) for x, _ in part], **ld))
    return out

# ══ 4. layout ของชุดนี้รับรูปทรงไหน — อ่านจากตัวอย่างใน SEQ ═══════════════════

def isval(x):
    """'5 เดือน' '-35%' '140+' = ค่าตัวเลข  ใช้แยกการ์ดสถิติออกจากการ์ดหัว+เนื้อ"""
    x = str(x).strip()
    return bool(x) and len(x) <= 14 and x[0] in '-+0123456789฿' and any(c.isdigit() for c in x)

DATA = ('series', 'points', 'kpis', 'before', 'stats', 'big', 'pct', 'on', 'side')

stacked = lambda name: bool(re.search(r"\bchart\(s, '(colS|barS|areaS|colP|barP)'", SRC.get(name, '')))   # layout ที่วาดกราฟซ้อน

def kind_of(name, ex, idx, total):
    """คืน (kind, จำนวนข้อในตัวอย่าง, โครงของแต่ละข้อ)  ใช้ไม่ได้ → kind=None"""
    if idx == 0: return 'cover', 0, None
    if 'close' in name or idx == total - 1: return None, 0, None   # หน้าปิดท้ายไม่มีเนื้อหาจากเอกสาร
    # หน้ากราฟ = กราฟ PowerPoint จริง (chart() ฝังชีต Excel) เท่านั้น กราฟที่วาดด้วยรูปทรง (gradbars ของ chart_bars) ไม่ใช่หน้ากราฟ (ใบ 008)
    nat = bool(re.search(r'\bchart\(s,', SRC.get(name, '')))
    if nat and 'cats' in ex and ('vals' in ex or 'series' in ex): return 'chart', len(ex['cats']), None
    it = ex.get('items')                                   # โดนัทที่วาดค่าเป็น % ตรง ๆ (ไม่มีหน่วยตายตัวของดีไซน์ เช่น "ล.") รับสัดส่วนของลูกค้าได้
    if nat and "chart(s, 'donut'" in SRC[name] and "f'{v}%'" in SRC[name] and isinstance(it, list) and it and isinstance(it[0], (list, tuple)):
        return 'chart', len(it), tuple(type(x) for x in it[0])
    if any(k in ex for k in DATA) or 'cats' in ex: return None, 0, None   # ต้องมีตัวเลขเฉพาะทาง (การ์ดใหญ่) ที่เอกสารไม่ได้ให้ / กราฟรูปทรง
    if 'head' in ex and 'rows' in ex: return 'table', len(ex['rows']), None
    it = ex.get('items')
    if isinstance(it, list) and it:
        f = it[0]
        if isinstance(f, str): return ('agenda' if 'agenda' in name or 'toc' in name or idx == 1 else 'list'), len(it), (str,)
        if not isinstance(f, (list, tuple)) or any(isinstance(x, dict) for x in f): return None, 0, None
        if any(not isinstance(r, (list, tuple)) for r in it): return None, 0, None   # ข้อปนชนิด (บางข้อเป็นเลขเดี่ยว) ไม่รู้โครง
        slots = tuple(type(x) for x in f)
        if any(isinstance(x, (int, float)) and x not in (0, 1) for r in it for x in r):
            return None, 0, None                           # ช่องตัวเลขในข้อ = ข้อมูลกราฟ ห้ามยืมเลขตัวอย่าง
        if isinstance(f[0], str) and f[0] in ICONS: return None, 0, None   # ช่องแรกเป็นไอคอน เดาไอคอนให้เนื้อลูกค้าไม่ได้
        if list in slots: return ('compare' if len(it) == 2 else None), len(it), slots
        if 'timeline' in name or 'gantt' in name: return 'timeline', len(it), slots   # ก่อน isval: ไทม์ไลน์ขึ้นต้นด้วยปี
        if isval(f[0]): return 'stat', len(it), slots
        if 'toc' in name or 'agenda' in name or idx == 1: return 'agenda', len(it), slots
        return ('faq' if 'faq' in name else 'pairs'), len(it), slots
    if 'num' in ex or name.startswith('div') or '_div' in name or 'section' in name: return 'divider', 0, None
    return 'statement', 0, None

# เนื้อหาชนิดนี้ ลงตัวอย่างชนิดไหนได้บ้าง พร้อมโทษ (น้อย = เหมาะกว่า)
FIT = {'list': {'list': 0, 'agenda': 3, 'pairs': 4}, 'agenda': {'agenda': 0, 'list': 1, 'pairs': 4},
       'pairs': {'pairs': 0, 'faq': 2, 'agenda': 3}, 'qa': {'faq': 0, 'pairs': 1, 'agenda': 3},
       'stat': {'stat': 0}, 'timeline': {'timeline': 0, 'pairs': 3}, 'compare': {'compare': 0},
       'table': {'table': 0}, 'chart': {'chart': 0, 'table': 2},
       'statement': {'statement': 0, 'divider': 2}, 'divider': {'divider': 0, 'statement': 2}, 'cover': {'cover': 0}}
KEEP = ('_note', '_name', '_big', 'pi', 'tsz', 'hi', 'nomirror', 'bsz', '_nf', '_sn', 'fsz', '_ov', 'mv', '_tz', 'usz', 'ffam', '_lg', '_pn', '_tr', 'tfm', 'z', 'lock', 'rot', 'chart', 'dpic', 'shc', 'el', 'ns', '_tst')   # el ns = องค์ประกอบใบ 027 (svg สี ชนิดรูปทรง) ไม่ใช่คำลูกค้า   # chart = ชนิด/แบบ/สี/ป้ายของกราฟที่ลูกค้าเลือก (ใบ 023)   # lock rot = ล็อกกล่อง / หมุน (ใบ 019b ตำแหน่ง)   # tfm = รูปแบบข้อความต่อกล่อง (ใบ 019) z = ลำดับชั้นที่ลูกค้าสั่ง (ยกขึ้น/ส่งลง)   # _lg _pn _tr = โลโก้/เลขหน้า/ทรานซิชันรายหน้า (ใบ 007)   # usz/ffam = ขนาด/ฟอนต์ที่ลูกค้าตั้งต่อกล่อง (ใบ 015 เฟส 2-3)   # mv = ตำแหน่ง/ขนาดกล่องที่ลูกค้าลากบนเว็บ (ใบ 017)                    # คีย์ดีไซน์ที่ไม่ใช่ข้อความ เก็บตามตัวอย่าง

LABEL = ('k', 'kicker', 'lab', 'label', 'tag', 'who', 'sub', 'cat', 'eyebrow')   # ช่องป้ายสั้น ๆ ที่ใส่หัวรองแทนได้

def fill(name, ex, slots, c):
    """เอาเนื้อลูกค้าใส่ตามโครงของตัวอย่าง ห้ามมีคำจากตัวอย่างหลุดมา  ใส่ไม่ได้ → None"""
    d = {k: ex[k] for k in KEEP if k in ex}
    d['t'] = c['t']
    if 't' not in ex and 't1' in ex:                       # ปก/หน้าเนื้อหาบางชุดแยกหัวเรื่องเป็นสองบรรทัด t1/t2 (เฟส C expandproposal: เดิมเฉพาะปก หน้าอื่นหัวเรื่องหาย)
        d['t1'] = c['t']; d.pop('t')
    if c.get('s') and not (c['kind'] == 'chart' and LAYKIND.get(name) == 'table'): d['s'] = c['s']   # หัวคอลัมน์ซ้ำเป็นหัวรองเฉพาะตอนเป็นกราฟ
    big = (c.get('_big') or PLANBIG) and c['kind'] != 'cover' and not c.get('_nobig')
    if c.get('_bsz') and not big: d['bsz'] = c['_bsz']    # โหมดประกอบการพูด (_big) ไม่ย่อตัวอักษร ล้นให้แบ่งหน้า (ไอซ์ 2 พ.ย.)
    if c.get('_note'): d['_note'] = c['_note']                # ใบ 037 โหมดประกอบการพูด: ข้อความเต็มไปโน้ตผู้บรรยาย
    if big: d['_big'] = c.get('_big') or PLANBIG
    if c.get('note') and 'note' in ex: d['note'] = c['note']
    elif c.get('_lead') and 's' in ex and not c.get('s'): d['s'] = c['note']   # ยอดรวมนำ ลงช่องหัวรอง
    if c.get('_ins'):                                      # หน้าที่ลูกค้าแทรกเอง: ช่องหัวรอง/หมายเหตุของ layout ว่างไว้ให้พิมพ์
        for k in ('s', 'note'):
            if k in ex: d.setdefault(k, '')
    if 'num' in ex: d['num'] = c.get('num', '')
    if c['kind'] in ('table', 'chart') and 'head' in ex:
        d['head'] = c['head']; d['rows'] = [list(r) for r in c['rows']]
        tp = next((h for h in ex['head'] if isinstance(h, (list, tuple))), None)
        if tp:                                             # หัวคอลัมน์แบบ (หัว, หัวรอง) เช่น op_table ใส่หัวรองว่าง
            d['head'] = [(h,) + ('',) * (len(tp) - 1) for h in c['head']]
        if 'colw' in ex:                                   # หน่วยเดียวกับตัวอย่าง (นิ้ว หรือ สัดส่วน) แบ่งเท่ากัน
            d['colw'] = [round(sum(ex['colw']) / len(c['head']), 3)] * len(c['head'])
        if 'al' in ex: d['al'] = ['l'] + ['r' if all(isnum(r[j]) for r in c['rows']) else 'l' for j in range(1, len(c['head']))]
    elif c['kind'] == 'chart' and LAYKIND.get(name) == 'chart':
        ser = c.get('series') or [(c.get('s', ''), c['vals'])]
        if stacked(name) and not (c.get('_stack') and len(ser) > 1): return None   # แท่งซ้อน: เฉพาะส่วนของก้อนเดียวกันหลายชุด (ชุดเดียวไม่ใช่แท่งซ้อน)
        if 'cats' in ex and re.search(r"\bchart\(s, '(donut|pie)'", SRC[name]) and (not c.get('_share') or len(c['cats']) > len(ex['cats'])):
            return None                                    # โดนัท/พายแบบ cats/vals (chart_donut_split ของ pricing): เฉพาะสัดส่วนของทั้งก้อน ไม่เกินแถวที่ดีไซน์วาด (ใบ 021: 220 เล่มขึ้นเป็น 220%)
        if 'cats' in ex:
            d['cats'] = list(c['cats'])
            if 'series' in ex: d['series'] = [(n, list(v)) for n, v in ser]
            elif len(ser) == 1:                            # layout กราฟชุดเดียว
                d['vals'] = list(ser[0][1])
                if 'sname' in ex: d['sname'] = ser[0][0]   # ชื่อชุดข้อมูล = หัวคอลัมน์ของลูกค้า (ขึ้นใน Edit Data)
            else: return None
        else:                                              # โดนัท: เฉพาะสัดส่วนของทั้งก้อน แถวไม่เกินที่ดีไซน์วาด
            if not c.get('_share') or len(c['cats']) > len(ex['items']): return None
            d['items'] = [tuple(a if i == 0 else v if t in (int, float) else '' for i, t in enumerate(slots)) for a, v in zip(c['cats'], c['vals'])]
        if c.get('head') and str(c['head'][0]).strip(): d['head'] = [c['head'][0]]   # ใบ 034 หัวคอลัมน์แรก → A1 ของชีตฝัง (head_a1) ไม่ใช่หน้าคำตกค้าง
        d['_nf'] = c['_nf']; d['_sn'] = [n for n, _ in ser]   # ชื่อชุดข้อมูลของลูกค้าทับชื่อตายตัวของดีไซน์ (โดนัท tb_donut ตั้ง 'ร้อยละ')
        if "d['s']" not in SRC[name] and "d.get('s'" not in SRC[name]: d.pop('s', None)   # หัวคอลัมน์อยู่ในกราฟแล้ว (ชื่อชุดข้อมูล)
        for k in ('items', 'side', 'bullets'):             # การ์ดตัวเลข/ข้อความข้างกราฟ: ว่าง ห้ามยืมเลขตัวอย่างของดีไซน์
            if isinstance(ex.get(k), list) and k not in d: d[k] = []
        if 'big' in ex:                                    # ตัวเลขใหญ่ข้างกราฟ = แถวแรกของลูกค้า ตามที่เอกสารพิมพ์ (ดีไซน์ไฮไลต์แท่งแรก) + ป้ายของแถวนั้น
            if len(ser) == 1 and '_col' in c:
                i = 0
                d['big'] = c['rows'][i][c['_col']].strip(); d['biglab'] = c['cats'][i]
            else: d['big'] = d['biglab'] = ''
    elif 'items' in ex and c.get('items'):                 # ปกบางชุดมี items ในตัวอย่าง ถ้าบังคับ REQ ด้านล่างจะตัดทิ้งเอง
        rows = []
        for it in c['items']:
            if slots == (str,):
                if len(it) > 1: return None                # หัว+เนื้อ ยัดลงช่องเดียวไม่ได้
                rows.append(it[0]); continue
            strs = [i for i, t in enumerate(slots) if t is str]
            lsts = [i for i, t in enumerate(slots) if t is list]
            vals = list(it)
            if c['kind'] == 'compare':                     # (หัว, [ข้อ...]) → ช่องสตริงแรก + ช่องลิสต์
                if not lsts: return None
                r = [''] * len(slots); r[strs[0]] = vals[0]; r[lsts[0]] = vals[1]
            else:
                if len(vals) > len(strs): return None
                if c['kind'] == 'stat' and len(vals) < len(strs):   # เฟส C: ช่องหน่วยสั้นของดีไซน์ ('+' '%' ต่อท้ายเลข) ไม่รับคำอธิบาย (เดิม "18 คนอ่านไม่" ติดเลข)
                    un_ = {i for i in strs[1:] if all(isinstance(e, (list, tuple)) and len(e) > i and isinstance(e[i], str) and len(e[i].strip()) <= 8 for e in ex['items']) and i != strs[-1]}
                    if len(strs) - len(un_) >= len(vals): strs = [i for i in strs if i not in un_]
                r = [ex['items'][0][i] if t in (int, float, bool) else '' for i, t in enumerate(slots)]
                off = min(c.get('_slot', 0), len(strs) - len(vals))   # ลองใส่ช่องถัดไปได้ (ช่องแรกบาง layout เป็นเลขหน้า)
                for i, v in zip(strs[off:], vals): r[i] = v
            rows.append(tuple(r))
        d['items'] = rows
    for k in TXTDEF.get(name, ()):
        d.setdefault(k, '')
    if d.get('s') and "d['s']" not in SRC[name] and "d.get('s'" not in SRC[name]:   # layout ไม่วาดหัวรอง: ย้ายไปช่องป้ายที่ layout วาด
        lab = next((k for k in LABEL if k in SRC[name] and not d.get(k) and isinstance(ex.get(k, ''), str)), None)
        if lab: d[lab] = d.pop('s')
    for k in REQ.get(name, set()) - set(d) - {'topic', 'foot', 'n'}:   # คีย์บังคับที่เอกสารไม่มี
        if isinstance(ex.get(k), str): d[k] = ''
        elif c['kind'] == 'cover' and isinstance(ex.get(k), (list, tuple)): d[k] = []   # การ์ดตัวเลขบนปก mk เติมจากเนื้อเด็คเอง
        else: return None
    if name.startswith(('chb_', 'chc_')) and 'chart' not in d:   # ใบ 028 ไอซ์ 1 พ.ย. "ตั้งต้นหน้ากราฟใหม่ = B" / มีคำอธิบายของลูกค้า = B + คำอธิบายขวา (C) ไม่ทิ้งคำ
        d['chart'] = {'lay': dict(lay_charts.LAYP['C' if d.get('note') else 'B'])}
    return d

# ══ 5. วัดกรอบจากการวาดจริง ════════════════════════════════════════════════

_FACE, _FONT = {}, {}
FONTX, LOCALF = {}, set()                                   # ฟอนต์ที่ลูกค้าเลือกบนเว็บ (โหลดตอนกดใช้): ชื่อ -> {ตัวปกติ, ตัวหนา} / LOCALF = ฟอนต์ในเครื่องลูกค้า (วัดได้ แต่ไม่ฝัง ไม่ใส่ zip)
def add_font(fam, reg, bold=None, local=False):
    FONTX[fam] = {False: reg, True: bold or reg}; _FACE.clear()
    if local: LOCALF.add(fam)

def facefile(name, bold):
    if name in FONTX: return FONTX[name][bool(bold)]
    k = (name, bold)
    if k not in _FACE:
        q = (name or 'IBM Plex Sans Thai') + (':bold' if bold else '')
        if WEB:
            fm = json.load(open(f'{K}/fonts.json'))
            f_ = [f"{K}/fonts/{x}" for x in (fm.get(q), fm.get(name or ''), fm['IBM Plex Sans Thai:bold' if bold else 'IBM Plex Sans Thai']) if x]
            _FACE[k] = next((x for x in f_ if os.path.exists(x)), f_[-1])   # ฟอนต์ที่ชุดนี้ยังไม่ได้โหลด: วัดด้วยตัวสำรองแทนพัง
        else:
            _FACE[k] = subprocess.run(['fc-match', '-f', '%{file}', q], capture_output=True, text=True).stdout
    return _FACE[k]

def lines(t, w_in, pt, f, dpi=144):
    """ข้อความนี้ที่ขนาดนี้กินกี่บรรทัด ใช้ตัวตัดคำเพื่อวัดอย่างเดียว ไม่แทรก ZWSP ลงไฟล์
    ปล่อยให้ PowerPoint ขึ้นบรรทัดเอง"""
    from PIL import ImageFont
    if (f, pt) not in _FONT: _FONT[(f, pt)] = ImageFont.truetype(f, int(pt / 72 * dpi))
    font, lim, n = _FONT[(f, pt)], w_in * dpi, 0
    for para in str(t).split('\n'):
        n += 1; cur = 0.0
        for tok in words(para):
            wd = font.getlength(tok)
            if cur and cur + wd > lim and not tok.isspace(): n += 1; cur = 0.0
            if wd > lim and not tok.isspace():               # คำยาวไม่มีที่ตัด (URL อีเมล) กว้างกว่ากล่อง: นับบรรทัดที่ถูกหักจริง
                n += int(wd // lim); cur = wd % lim; continue
            cur += wd
    return n

def widest(t, w_in, pt, f, dpi=144):
    """ความกว้างจริงของบรรทัดที่ยาวที่สุด (นิ้ว) ตัดบรรทัดแบบเดียวกับ lines()"""
    from PIL import ImageFont
    if (f, pt) not in _FONT: _FONT[(f, pt)] = ImageFont.truetype(f, int(pt / 72 * dpi))
    font, lim, mx = _FONT[(f, pt)], w_in * dpi, 0.0
    for para in str(t).split('\n'):
        cur = 0.0
        for tok in words(para):
            wd = font.getlength(tok)
            if cur and cur + wd > lim and not tok.isspace(): mx = max(mx, cur); cur = 0.0
            cur += wd
        mx = max(mx, min(cur, lim))
    return mx / dpi

BIND = re.compile(r'(ที่|ครั้งที่|ชั้น|ข้อ|ป\.|ม\.|ปี|พ\.ศ\.|ค\.ศ\.|ฉบับที่) (\d)')   # QA 30n: "พ.ศ. 2569" "ค.ศ. 2026" แบบเดียวกับ "ปี 2569"   # เลขลำดับไม่หลุดไปอยู่บรรทัดเดียว ("ภาคเรียนที่ 1")

def bind_nums(slide):
    """เว้นวรรคระหว่าง "ที่"/"ชั้น" กับเลขลำดับ เป็นเว้นวรรคไม่ตัดบรรทัด (เฉพาะในไฟล์ที่วาด คำลูกค้าเหมือนเดิม)"""
    for sh in slide.shapes:
        if not sh.has_text_frame: continue
        for p in sh.text_frame.paragraphs:
            for r in p.runs:
                if BIND.search(r.text): r.text = BIND.sub('\\1\u00a0\\2', r.text)

def wordsx(t):
    """words() แต่ไม่หั่นคำอังกฤษ/ตัวเลข/ขีด เช่น O-NET 5/2568 ไว้เป็นชิ้นเดียว ใช้ตอนหาที่ตัดบรรทัด/หน้า"""
    out = []
    for w_ in words(t):
        if out and re.fullmatch(r'[A-Za-z0-9\-./%,]+', w_) and re.search(r'[A-Za-z0-9\-./]$', out[-1]): out[-1] += w_
        else: out.append(w_)
    return out

def words(t):
    """ตัดคำไทยเพื่อวัด  ในเครื่องใช้ PyThaiNLP บนเว็บใช้ Intl.Segmenter ของเบราว์เซอร์ (พจนานุกรมเหมือนกัน ไม่ใช่ AI)"""
    try:
        from pythainlp.tokenize import word_tokenize
        return word_tokenize(t, keep_whitespace=True)
    except ImportError:
        import js
        return list(js.d2sSeg(t))

def strings(v):
    if isinstance(v, str): yield v
    elif isinstance(v, (int, float)) and not isinstance(v, bool): yield str(v)   # ค่ากราฟของลูกค้า
    elif isinstance(v, (list, tuple)):
        for x in v: yield from strings(x)
    elif isinstance(v, dict):
        for k, x in v.items():
            if k == 'two' and isinstance(x, dict): yield from strings(x.get('d'))   # ใบ 028 ตารางที่สอง: เฉพาะเนื้อหน้าเดิม (ไม่นับชื่อ layout/ตำแหน่ง)
            elif k not in KEEP and k != 'al': yield from strings(x)

import base64
_DOT = base64.b64decode('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==')

def _panels(slide, moved=()):
    """[(คีย์ตำแหน่ง, [ข้อความในแผง])] แผง/การ์ดสีทึบที่มีกล่องข้อความอยู่ข้างใน  คีย์ = x กว้าง สูง (ไม่ใช้ y: จำนวนข้อเปลี่ยน แถวเลื่อน)"""
    def solid(x):
        try: return x.fill.type == 1
        except Exception: return False
    E = 914400; sw, sh = slide.part.package.presentation_part.presentation.slide_width / E, slide.part.package.presentation_part.presentation.slide_height / E
    tb = [x for x in slide.shapes if x.has_text_frame and x.shape_id not in moved and not solid(x)]
    out = []
    for pn in slide.shapes:
        if not solid(pn) or (pn.has_text_frame and pn.text_frame.text.strip()) or pn.shape_id in moved: continue
        px, py, pw, ph = pn.left / E, pn.top / E, pn.width / E, pn.height / E
        if pw * ph < 0.5 or ph < 0.6 or pw * ph > sw * sh * 0.6 or px < -0.05 or py < -0.05 or px + pw > sw + 0.05 or py + ph > sh + 0.05: continue   # แสงเรือง/ลายที่ล้นขอบ ไม่ใช่การ์ด
        ins = [x.text_frame.text.strip() for x in tb if px - 0.02 <= x.left / E and (x.left + x.width) / E <= px + pw + 0.02
               and py - 0.02 <= x.top / E and (x.top + x.height) / E <= py + ph + 0.02]
        if ins: out.append(((round(px, 1), round(pw, 1), round(ph, 1)), ins))
    return out

_EXP = {}
def _expanels(name, M):
    """คีย์แผงที่ตัวอย่างของดีไซน์มีคำ (วาดตัวอย่างครั้งเดียวต่อ layout)"""
    if name not in _EXP:
        _EXP[name] = set()
        ex = next((e for n_, e, *_ in pool_of(M['slug'])[1] if n_ == name), None) if M.get('slug') else None
        if ex is not None:
            prs = base.deck(); real = base._prep; base._prep = lambda path, mode=None: (_DOT, (4, 3))
            try:
                lay.L[name](prs, {'topic': M.get('topic', 'office'), 'foot': '', 'n': '01', **ex})
                slot = {' '.join(str(x).split()) for x in strings(ex) if str(x).strip()}   # คำในแผงต้องมาจากช่องเนื้อหา (ไม่ใช่ป้ายเมนู/คำตกแต่งที่ layout เขียนเอง)
                _EXP[name] = {k for k, t in _panels(prs.slides[-1]) if any(' '.join(x.split()) in slot for x in t)}
            except Exception: pass
            finally: base._prep = real; lay_cov3.TTL2.clear()
    return _EXP[name]

def overflow(name, d, M, card=False):
    """วาด layout นี้ด้วยเนื้อลูกค้า แล้วดูทุกกล่องที่มีข้อความลูกค้าว่าล้นความสูงกรอบไหม"""
    d = {k: v for k, v in d.items() if k != 'add'}       # ข้อความ/รูปที่ลูกค้าเพิ่ม (ใบ 022) ไม่ได้วาดตรงนี้ และกล่องสูงตามตัวหนังสือเอง: ไม่นับ ไม่งั้นทุกการแก้คำในหน้านั้นเป็น "ล้น" (บั๊กไอซ์ 1 พ.ย.: ข้อความที่แก้หาย/ป้ายล้นกรอบ)
    nm_ = LAYKIND.get(name, '')
    eng.setpal(M['pal'], M.get('font', 'plex'), M.get('head')); eng.setvar(0)
    prs = base.deck()
    real = base._prep
    base._prep = lambda path, mode=None: (_DOT, (4, 3))   # วัดแค่ข้อความ ไม่ต้องย่อ/ย้อมสีรูปจริง เร็วขึ้นหลายเท่า
    try: lay.L[name](prs, {'topic': M.get('topic', 'office'), 'foot': '', 'n': '01', **d})
    except Exception as ex: return [f'วาดไม่ได้ {type(ex).__name__}']
    finally: base._prep = real
    head_a1(prs.slides[-1], d)
    if d.get('bsz'): shrink_text(prs.slides[-1], d['bsz'])
    if d.get('_big'): bigtext(prs.slides[-1], d['_big'])
    if d.get('usz') or d.get('ffam'): styles(prs.slides[-1], d)
    if d.get('fsz'): fsize(prs.slides[-1], d)
    if d.get('_tz'): tsize(prs.slides[-1], d)
    moved = apply_moves(prs.slides[-1], d, prs.slide_width, prs.slide_height)   # กล่องที่ลูกค้าย้ายเอง: ข้ามกฎชน (เส้นคั่น รูป แผง) เหลือจำนวนบรรทัดกับขอบสไลด์
    mine = {x.strip() for x in strings(d) if len(x.strip()) > 1}
    thai_spacing(prs.slides[-1])                          # ระยะบรรทัดเดียวกับตอนวาดจริง
    scrub(prs.slides[-1], list(strings(d))); tidy(prs.slides[-1], d)   # เหมือนตอนวาดจริง: คำที่ layout เติมเอง ("หน้า 450,000 บาท") ถูกลบทั้งกล่อง
    bad = [f'ไม่ได้วาด "{x[:22]}"' for x in lost(prs.slides[-1], d)]
    bind_nums(prs.slides[-1])                             # เหมือนตอนวาดจริง (วัดบรรทัดด้วยเลขลำดับที่ไม่หลุด)   # layout ที่ไม่วาดบางช่อง = ทิ้งเนื้อลูกค้า ใช้ไม่ได้
    if d.get('tfm'): fmts(prs.slides[-1], d)             # ตัวหนา ระยะบรรทัด จุดนำหน้า ฯลฯ กินที่: วัดหลังใส่ (ใบ 019)
    def solid(x):
        try: return x.fill.type == 1                       # MSO_FILL.SOLID
        except Exception: return False
    shs = [x for x in prs.slides[-1].shapes if solid(x) and not (x.has_text_frame and x.text_frame.text.strip())]
    SH = prs.slide_height / 914400
    for tbs in [x for x in prs.slides[-1].shapes if getattr(x, 'has_table', False) and x.has_table]:
        # ตารางจริง: แถวสูงขึ้นตามข้อความ (บรรทัดไทยสูงกว่าที่ประมาณ) รวมแล้วต้องไม่เลยขอบล่างสไลด์
        tb, tot = tbs.table, 0.0
        for row in tb.rows:
            hmax = row.height / 914400
            for j, cell in enumerate(row.cells):
                r_ = next((r for p_ in cell.text_frame.paragraphs for r in p_.runs if r.font.size), None)
                if not r_ or not cell.text_frame.text.strip(): continue
                pt = r_.font.size.pt; cw = tb.columns[j].width / 914400 - 0.2
                n_ = lines(cell.text_frame.text, max(cw, 0.3), pt, facefile(r_.font.name, bool(r_.font.bold)))
                hmax = max(hmax, n_ * pt * 1.5 / 72 + 0.1)
            tot += hmax
        if tbs.top / 914400 + tot > SH - 0.15: bad.append(f'ตารางยาวเลยขอบล่าง ({tot:.1f} นิ้ว)')
    hl_ = collections.defaultdict(list)                    # เฟส C: ตารางกริดพื้นหลัง (sc_ ของ parentmeet เส้นบางสิบกว่าเส้นเท่ากันหมด) เป็นลาย ไม่ใช่เส้นคั่น
    for x in prs.slides[-1].shapes:
        if not x.has_text_frame or not x.text_frame.text.strip():
            if x.width >= 0.5 * 914400 and x.height <= 0.04 * 914400: hl_[(round(x.left / 914400, 2), round(x.width / 914400, 2))].append(x.shape_id)
    grid_ = {i for v in hl_.values() if len(v) >= 10 for i in v}
    for sh in prs.slides[-1].shapes:
        if not sh.has_text_frame: continue
        t_ = sh.text_frame.text.replace('\u00a0', ' ').strip()
        if t_ not in mine and t_.strip('[]"\u201c\u201d ') not in mine: continue   # เฟส C: [คำลูกค้า] / "คำลูกค้า" ที่ดีไซน์ครอบ (csred tech perf) ต้องวัดล้นด้วย เดิมข้ามจนตัวหนังสือเลยขอบล่าง
        p = sh.text_frame.paragraphs[0]
        if not p.runs or not p.runs[0].font.size: continue
        r = p.runs[0].font; pt = r.size.pt
        w, h = sh.width / 914400, sh.height / 914400
        if p._p.pPr is not None and p._p.pPr.get('marL'): w = max(0.3, w - int(p._p.pPr.get('marL')) / 914400)   # จุดนำหน้า/เลขรายการ (ใบ 019) กินความกว้าง
        sp = p.line_spacing if isinstance(p.line_spacing, float) else 1.0
        lh = pt * max(sp, 1.0) * 1.25 / 72                 # ความสูงหนึ่งบรรทัดของฟอนต์ไทย (สระบน-ล่าง)
        allow = max(1, int(h / lh + 0.35))
        need = lines(sh.text_frame.text, w, pt, facefile(r.name, bool(r.bold)))
        hn = LHINT.get(' '.join(sh.text_frame.text.split()))
        hn = min(hn or [], key=lambda x: abs(x[0] - pt), default=None)
        if hn and abs(hn[0] - pt) < 0.6: need = max(need, int(hn[1]))   # กล่องที่ลูกค้ากำลังพิมพ์: ใช้ค่ามากกว่าระหว่าง PIL กับที่เบราว์เซอร์ตัดจริง
        if need > allow: bad.append(f'"{sh.text_frame.text[:22]}" {need}/{allow} บรรทัด')
        elif need >= 3 and h < 1.0 and need * lh * 1.2 > h + 0.05: bad.append(f'"{sh.text_frame.text[:22]}" {need} บรรทัดแน่นเกินกล่อง')   # ไทยหลายบรรทัดสูงกว่าที่ประมาณ (ข้อความล้นลูกศร)
        if pt >= 20:                                       # หัวเรื่อง: คำติดกัน (ไม่มีเว้นวรรค) ต้องอยู่บรรทัดเดียว ไม่หักกลางคำ ("ปฏิบัติ/การ") ปก ≤30 ตัว หัวเรื่องอื่น ≤12 ตัว
            fz = facefile(r.name, bool(r.bold)); cap_ = 30 if 'tsz' in d or nm_ == 'cover' else 12
            if any(lines(ch, w, pt, fz) > 1 for ch in re.split(r'[\s\u00a0]+', sh.text_frame.text) if 4 <= len(ch) <= cap_ and not re.search(r'[A-Za-z]', ch)):
                bad.append(f'"{sh.text_frame.text[:22]}" หักกลางคำ')
        tw_ = widest(sh.text_frame.text, w, pt, facefile(r.name, bool(r.bold)))
        al_ = int(p.alignment) if p.alignment is not None else 1
        tx0 = sh.left / 914400 + ((w - tw_) / 2 if al_ == 2 else (w - tw_) if al_ == 3 else 0); tx1 = tx0 + tw_
        anc_ = sh.text_frame.vertical_anchor; th_ = need * lh
        ty0 = sh.top / 914400 + ((h - th_) / 2 if anc_ is not None and int(anc_) == 3 else (h - th_) if anc_ is not None and int(anc_) == 4 else 0)
        mvd = sh.shape_id in moved
        for ln_ in [] if mvd else prs.slides[-1].shapes:   # เส้นคั่นแถว/รูป เป็นขอบแข็ง ข้อความห้ามทับ
            if ln_ is sh or ln_.shape_id in moved or (ln_.has_text_frame and ln_.text_frame.text.strip()) or ln_.shape_id in grid_: continue
            lx, ly, lw_, lh_ = ln_.left / 914400, ln_.top / 914400, ln_.width / 914400, ln_.height / 914400
            if lw_ >= 0.5 and lh_ <= 0.04 and ty0 + lh * 0.6 < ly < ty0 + th_ - 0.04 and lx < tx1 - 0.05 and lx + lw_ > tx0 + 0.05:
                bad.append(f'"{sh.text_frame.text[:22]}" ทับเส้นคั่น'); break
            pic = getattr(ln_, 'shape_type', None) == 13
            if pic and not (lx <= sh.left / 914400 + 0.05 and ly <= sh.top / 914400 + 0.05) and lx > tx0 + 0.3 and tx1 > lx + 0.3 \
                    and ly < ty0 + th_ and ly + lh_ > ty0:
                bad.append(f'"{sh.text_frame.text[:22]}" ทับรูป'); break
            if pic and lx < tx1 - 0.3 and lx + lw_ > tx0 + 0.3 and ty0 + lh * 0.5 < ly < ty0 + th_ - 0.05:   # เฟส C: รูปใต้ข้อความ (edtechpitch หัวเรื่อง 4 บรรทัดวิ่งเข้าใต้รูป) เดิมดูแค่รูปทางขวา
                bad.append(f'"{sh.text_frame.text[:22]}" ทับรูป'); break
        SW = prs.slide_width / 914400; x0 = sh.left / 914400; y0 = sh.top / 914400
        th = need * pt * 1.35 / 72                         # ความสูงข้อความไทยจริง
        anc = sh.text_frame.vertical_anchor
        bot = y0 + (h + th) / 2 if anc is not None and int(anc) == 3 else (y0 + h if anc is not None and int(anc) == 4 else y0 + th)   # 3 กลาง 4 ล่าง
        if not mvd and h <= 0.6 and need == 1 and any(abs(x.left - sh.left) < 2e4 and abs(x.width - sh.width) < 2e4 and abs(x.top - sh.top) < 2e4
                                          for x in prs.slides[-1].shapes if x is not sh and not x.has_text_frame or (x is not sh and x.has_text_frame and not x.text_frame.text.strip())):
            if lines(sh.text_frame.text, max(w - 0.3, 0.3), pt, facefile(r.name, bool(r.bold))) > 1: bad.append(f'"{sh.text_frame.text[:22]}" ชิดขอบป้าย')
        rowbg = not mvd and y0 + h > SH + 0.02 and any(abs(x.top - sh.top) < 2e4 and abs(x.height - sh.height) < 2e4 for x in shs)   # แถบแถวตารางตกขอบ
        if bot > SH - 0.02 or rowbg:                       # ตัวหนังสือจริง (ตามจุดยึดของกล่อง) หรือแถบพื้นของแถว เลยขอบล่างสไลด์
            bad.append(f'"{sh.text_frame.text[:22]}" เลยขอบล่างสไลด์')
        # กล่องข้อความวางบนแผงสี (เช่นกล่องขาวบนปก) ที่เตี้ยกว่ากล่องข้อความ: ข้อความต้องจบในแผง
        for pn in [] if mvd else shs:
            if pn is sh or pn.shape_id in moved: continue
            px, py, pw, ph_ = pn.left / 914400, pn.top / 914400, pn.width / 914400, pn.height / 914400
            if px <= x0 + 0.05 and py <= y0 + 0.05 < py + ph_ - 0.1 and px + pw >= x0 + min(w, 1) and py + ph_ < y0 + h - 0.15 and pw * ph_ < SW * 7.5 * 0.6:   # แผงต้องรองรับต้นข้อความจริง
                if y0 + need * lh + 0.1 > py + ph_: bad.append(f'"{sh.text_frame.text[:22]}" ล้นแผงพื้น'); break
        if x0 + w > SW + 0.05:                             # กล่องกว้างเลยขอบสไลด์ (กว้างตามข้อความ) ข้อความต้องจบในขอบสไลด์บรรทัดเดียว
            if lines(sh.text_frame.text, max(SW - x0 - 0.3, 0.5), pt, facefile(r.name, bool(r.bold))) > 1:
                bad.append(f'"{sh.text_frame.text[:22]}" ล้นขอบสไลด์')
    # ใบ 045 การ์ดว่าง: การ์ด/แผงที่ตัวอย่างของดีไซน์มีคำ แต่เนื้อลูกค้าทำให้ว่าง (รายการข้อเดียวลงหน้าคู่ "ปัญหา | วิธีแก้" การ์ดขวาเหลือแค่ไอคอน)
    # หรือเหลือแค่ชื่อชุดข้อมูล (แผงส้มใหญ่มีแค่ "งบ (บาท)") = เลือกหน้าอื่น  แผงตกแต่งที่ตัวอย่างก็ว่างอยู่แล้ว ไม่นับ
    lab_ = {str(x).strip() for x in [d.get('sname')] + list(d.get('_sn') or []) if x and str(x).strip()}
    full_ = _expanels(name, M) if card and nm_ != 'cover' else set()   # ปก: การ์ดตัวเลขเติมตอนวาด (_covfill) ว่างได้ / ตรวจเฉพาะตอนจัดหน้าจากเนื้อลูกค้า (try_one) หน้าที่ลูกค้าแทรก/แก้เองว่างได้
    for key, texts in _panels(prs.slides[-1], moved):
        if key in full_ and all(not t or t in lab_ for t in texts): bad.append('การ์ดว่าง ไม่มีคำ'); break
    return bad

def _xlsx_a1(ch, put=None):
    """ใบ 034 ช่อง A1 ของชีตฝังในกราฟ (หัวคอลัมน์แรกของตารางลูกค้า เช่น "รายการ") อ่าน / เขียน (put) ตรงในไฟล์ zip
    ponytail: แก้ sheet1.xml ด้วย regex (ชีตที่ python-pptx/xlsxwriter เขียน แถว 1 มีเสมอ) ไม่ใช้ openpyxl เพราะเซฟใหม่แล้วค่าสูตรที่คิดไว้หาย"""
    import zipfile
    from xml.sax.saxutils import escape, unescape
    wb = ch.part.chart_workbook; xp = wb.xlsx_part
    if xp is None: return ''
    zi = zipfile.ZipFile(io.BytesIO(xp.blob)); sh = zi.read('xl/worksheets/sheet1.xml').decode('utf-8')
    if put is None:
        m = re.search(r'<c r="A1"[^>]*?(?:/>|>(.*?)</c>)', sh)
        if not m or not m.group(1): return ''
        if 't="s"' in m.group(0):
            ss = re.findall(r'<si>(.*?)</si>', zi.read('xl/sharedStrings.xml').decode('utf-8'), re.S)
            k = int(re.search(r'<v>(\d+)</v>', m.group(1)).group(1))
            return unescape(''.join(re.findall(r'<t[^>]*>(.*?)</t>', ss[k], re.S))) if k < len(ss) else ''
        return unescape(''.join(re.findall(r'<t[^>]*>(.*?)</t>', m.group(1), re.S)))
    sh = re.sub(r'<c r="A1"[^>]*?(?:/>|>.*?</c>)', '', sh, count=1)
    cell = f'<c r="A1" t="inlineStr"><is><t xml:space="preserve">{escape(put)}</t></is></c>' if put.strip() else ''
    if re.search(r'<row r="1"[ >]', sh): sh = re.sub(r'(<row r="1"[^>]*?)(/?)>', lambda m: m.group(1) + '>' + cell + ('</row>' if m.group(2) else ''), sh, count=1)
    else: sh = sh.replace('<sheetData>', f'<sheetData><row r="1">{cell}</row>', 1).replace('<sheetData/>', f'<sheetData><row r="1">{cell}</row></sheetData>', 1)
    b = io.BytesIO()
    with zipfile.ZipFile(b, 'w', zipfile.ZIP_DEFLATED) as zo:
        for it in zi.infolist(): zo.writestr(it, sh.encode('utf-8') if it.filename == 'xl/worksheets/sheet1.xml' else zi.read(it))
    xp.blob = b.getvalue()

def head_a1(slide, d):
    """ใบ 034 หน้ากราฟ: หัวคอลัมน์แรกของลูกค้า (d['head'][0]) ลง A1 ของชีตฝังในกราฟแรกของหน้า (หลังตัววาด/numfmt เขียนชีตเสร็จ)
    ไม่ต้องทำหน้าเก็บคำตกค้างเพราะคำนี้อยู่ในไฟล์แล้ว (slide_text อ่าน A1 ด้วย)"""
    h = d.get('head')
    h0 = h[0] if isinstance(h, list) and h else ''
    h0 = h0 if isinstance(h0, str) else (h0[0] if h0 else '')
    if not h0.strip(): return
    for gf in [x for x in slide.shapes if getattr(x, 'has_chart', False) and x.has_chart][:1]: _xlsx_a1(gf.chart, h0)

def _chart_shown(ch):
    """ใบ 037: ค่าในกราฟตามรูปแบบที่โชว์ (1,200,000 / 52%) ไม่ใช่ค่าดิบในไฟล์ (1200000 / 0.52)
    เดิมตัวตรวจคำเห็นว่าค่ากราฟหาย แล้วเติมหน้ารายการซ้ำ (03-marketing-plan หน้างบประมาณซ้ำ)"""
    from pptx.oxml.ns import qn as _q
    out = []
    for nc in ch._chartSpace.iter(_q('c:numCache')):
        fc = nc.find(_q('c:formatCode')); code = fc.text if fc is not None else 'General'
        for pt in nc.iter(_q('c:pt')):
            v = pt.find(_q('c:v'))
            try: out.append(_fmtv(float(v.text), pt.get('formatCode') or code))
            except (TypeError, ValueError, AttributeError): pass
    return out

def slide_text(slide):
    """ข้อความทั้งหมดที่วาดจริงบนสไลด์ (กล่อง ตาราง กราฟ + A1 ของชีตฝัง) ตัดช่องว่าง ตัวเล็ก ไว้เทียบว่าคำลูกค้าอยู่ครบไหม"""
    out = []
    for sh in slide.shapes:
        if getattr(sh, 'has_table', False) and sh.has_table: out += [c.text for r in sh.table.rows for c in r.cells]
        elif getattr(sh, 'has_chart', False) and sh.has_chart: out += list(sh.chart._chartSpace.itertext()) + [_xlsx_a1(sh.chart)] + _chart_shown(sh.chart)
        elif sh.has_text_frame: out.append(sh.text_frame.text)
    return ''.join(''.join(out).split()).lower()

def cust(d):
    """ข้อความลูกค้าใน d (ไม่รวมคีย์ดีไซน์ ความกว้างคอลัมน์ และตัวเลขใน items ที่ fill ยกมาจากตัวอย่าง เช่นธง 0/1)"""
    strs = lambda v: [x for x in v if isinstance(x, str)] if isinstance(v, (list, tuple)) else v
    d2 = {k: ([strs(r) for r in v] if k == 'items' and isinstance(v, list) else v) for k, v in d.items() if k != 'colw'}
    return [x for x in strings(d2) if x.strip() and x.strip() not in ALLOW]   # "สารบัญ" เป็นคำของระบบ layout ไม่วาดก็ไม่ใช่เนื้อหาหาย

def lost(slide, d):
    """คำลูกค้าที่อยู่ใน d แต่ layout ไม่ได้วาดลงสไลด์ (กฎห้ามทิ้งเนื้อหา)"""
    t = slide_text(slide); t2 = t.replace(',', '')          # ตัวเลขในอินโฟกราฟิกมีตัวคั่นหลักพัน (ไอซ์ 1 พ.ย.) ค่าในตารางไม่มี
    return [x for x in cust(d) if ''.join(x.split()).lower() not in t and ''.join(x.split()).lower().replace(',', '') not in t2]

SMALLNOTE = 'หน้าตานี้กล่องข้อความเล็ก บางหน้าจึงตัวเล็ก ลองหน้าตาอื่นได้'

def shrink_text(slide, f):
    """หน้าที่ข้อความยาวกว่ากล่องของชุดนี้: ย่อตัวหนังสือทั้งหน้าลง f เท่า ไม่ต่ำกว่า 10.5pt (ขั้นต่ำของมาตรฐานตัวหนังสือ) แทนการตัดกลางความ"""
    from pptx.util import Pt
    for sh in slide.shapes:
        if not sh.has_text_frame: continue
        for p in sh.text_frame.paragraphs:
            for r in p.runs:
                if r.font.size and r.font.size.pt > 10.5: r.font.size = Pt(max(10.5, round(r.font.size.pt * f * 2) / 2))

def bigtext(slide, pt=18):
    """ใบ 037 โหมดประกอบการพูด: ตัวหนังสือเนื้อหาไม่ต่ำกว่า pt (ไอซ์ 2 พ.ย. "ตัวหนังสือในสไลด์หน้าอื่นๆมันเล็กๆไปหน่อยอ่านไม่ค่อยออก")
    ขยายก่อนวัดกรอบ (overflow) หน้าไหนล้นที่ขนาดนี้ ตัวจัดเลือกแบบอื่นหรือแบ่งหน้า ไม่ย่อกลับ  เลขหน้า/ตัวเลขสั้น ๆ ไม่ขยาย  ตาราง กราฟ ไม่แตะ"""
    from pptx.util import Pt
    for sh in slide.shapes:
        if not sh.has_text_frame: continue
        for p in sh.text_frame.paragraphs:
            for r in p.runs:
                if r.font.size and r.font.size.pt < pt and not re.fullmatch(r'[\d\s/.\-]{0,4}', r.text): r.font.size = Pt(pt)

def fsize(slide, d):
    """ขนาดตัวอักษรที่ตั้งต่อกล่อง d['fsz'] = {'items.2': 0.9} เท่าของขนาดดีไซน์ ไม่ต่ำกว่า 10pt (ใบ 015: ล้นตอนจบการแก้ ย่อเองแบบ PowerPoint)"""
    from pptx.util import Pt
    for key, f in d['fsz'].items():
        try: t = ' '.join(str(_get(d, [int(x) if x.isdigit() else x for x in key.split('.')])).split())
        except (KeyError, IndexError, TypeError): continue
        for sh in slide.shapes:
            if t and sh.has_text_frame and ' '.join(sh.text_frame.text.replace('\u00a0', ' ').split()) == t:
                for p in sh.text_frame.paragraphs:
                    for r in p.runs:
                        if r.font.size and r.font.size.pt > 10: r.font.size = Pt(max(10, round(r.font.size.pt * f * 2) / 2))

def tsize(slide, d):
    """d['tsz'] = ขนาดหัวเรื่องปกที่ตัวจัดเลือก ใช้กับทุก layout (บาง layout เขียนขนาดตายตัว ไม่อ่าน tsz → ย่อไม่ได้ แล้วชื่อเรื่องถูกแบ่งไปกล่องอื่น)"""
    from pptx.util import Pt
    ts = {' '.join(str(d.get(k, '')).split()) for k in ('t', 't1', 't2') if k not in (d.get('usz') or {})} - {''}   # ขนาดที่ลูกค้าตั้งเอง (ใบ 019) ไม่ถูกหนีบ
    for sh in slide.shapes:
        if sh.has_text_frame and ' '.join(sh.text_frame.text.replace('\u00a0', ' ').split()) in ts:
            for p in sh.text_frame.paragraphs:
                for r in p.runs:
                    if r.font.size and r.font.size.pt > d['tsz']: r.font.size = Pt(d['tsz'])

def _face(r, fam):
    """ฟอนต์ของ run ครบ latin ea cs (ภาษาไทยใน PowerPoint ใช้ cs)"""
    from pptx.oxml.ns import qn
    r.font.name = fam
    rPr = r._r.get_or_add_rPr(); at = rPr.find(qn('a:latin'))
    for tag in ('a:ea', 'a:cs'):
        el = rPr.find(qn(tag))
        if el is None: el = rPr.makeelement(qn(tag), {}); at.addnext(el); at = el
        el.set('typeface', fam)

def styles(slide, d):
    """ขนาด (usz = เท่าของขนาดดีไซน์ 0.8-1.3 ไม่ต่ำกว่า 10pt) และฟอนต์ (ffam) ที่ลูกค้าตั้งต่อกล่อง ก่อนย่ออัตโนมัติ (fsize)"""
    from pptx.util import Pt
    us, ff = d.get('usz') or {}, d.get('ffam') or {}
    for s_, p, *_r in list(_match(slide, d)):
        key = '.'.join(map(str, p)); f, fam = us.get(key), ff.get(key)
        if not f and not fam: continue
        for para in _r[4].paragraphs:
            for r in para.runs:
                if f and r.font.size: r.font.size = Pt(min(96, max(10, round(r.font.size.pt * f * 2) / 2)))   # ใบ 019: 10pt ถึง 2 เท่า ไม่เกิน 96
                if fam: _face(r, fam)

def set_style(items, idx, path, M, size=None, font=None, dry=False, fmt=None, reset=False, lo=None, step=None):
    """ลูกค้าตั้งขนาด (size = เท่าของดีไซน์, 1 = คืนค่าเดิม) / ฟอนต์ (font, '' = ฟอนต์ของดีไซน์) / รูปแบบ (fmt = {b i u s al ls va li col}, ค่า None = กลับของดีไซน์) ของกล่องหนึ่ง
    reset = คืนรูปแบบเดิมทั้งกล่อง (ขนาด ฟอนต์ รูปแบบ) / lo + step: ขนาดหรือระยะบรรทัดล้น = ถอยไปค่าใหญ่สุดที่พอดี (ระหว่าง lo กับที่ขอ) คืน 'fit' ค่าที่ได้อยู่ EXTRA['fit']
    ล้น: ฟอนต์ใหม่ลองย่อตัว 0.95-0.8 แบบตอนแก้คำ ยังล้น = ไม่เปลี่ยน / ขนาด ตัวหนา จุดนำหน้า ล้น = ไม่เปลี่ยน  คืนสถานะ ok/shrink/fit/over"""
    name, d = items[idx]; key = '.'.join(map(str, path))
    us, ff, tf = dict(d.get('usz') or {}), dict(d.get('ffam') or {}), {k: dict(v) for k, v in (d.get('tfm') or {}).items()}
    if reset: us.pop(key, None); ff.pop(key, None); tf.pop(key, None)
    if font is not None:
        if font: ff[key] = font
        else: ff.pop(key, None)
    keep = size is None and font is None and not reset and fmt and set(fmt) <= {'al', 'va', 'col', 'u', 's'}   # ใบ 030 ข้อ 2: ชิดซ้าย/สี ไม่เปลี่ยนการตัดบรรทัด คงขนาดที่ระบบย่อไว้ (เดิมกล่องที่ล้นอยู่ เลือกชิดซ้ายแล้วขึ้นว่าล้น ไม่เปลี่ยน)
    fz = {k: v for k, v in (d.get('fsz') or {}).items() if k != key or keep}
    def mk(sz, ls):
        u2, t2 = dict(us), {k: dict(v) for k, v in tf.items()}
        if sz is not None:
            if abs(sz - 1) < 1e-3: u2.pop(key, None)
            else: u2[key] = round(min(2.0, max(0.05, float(sz))), 3)
        if fmt:
            f = {**t2.get(key, {}), **fmt}
            if ls is not None: f['ls'] = round(float(ls), 2)
            f = {k: v for k, v in f.items() if v is not None}
            if f: t2[key] = f
            else: t2.pop(key, None)
        d2 = {k: v for k, v in d.items() if k not in ('usz', 'ffam', 'fsz', 'tfm') + (() if keep else ('_ov',))}
        if u2: d2['usz'] = u2
        if ff: d2['ffam'] = ff
        if fz: d2['fsz'] = fz
        if t2: d2['tfm'] = t2
        return d2
    want = fmt.get('ls') if fmt else None
    d2 = mk(size, want)
    base = overflow(name, d, M) if d.get('_ov') else []
    chk = lambda dx: [m for m in overflow(name, dx, M) if m not in base]
    st = 'ok' if not chk(d2) else 'over'
    if st == 'over' and lo is not None and step and (size is not None or want is not None):
        top = size if size is not None else want; grid = []
        v = top - step
        while v > lo + 1e-6: grid.append(round(v, 4)); v -= step
        grid.append(lo)                                   # lo = ค่าตอนนี้ (พอดีอยู่แล้ว)
        a, b_, hit = 0, len(grid) - 1, None               # ค่าใหญ่ลงเล็ก: หาค่าแรก (ใหญ่สุด) ที่พอดี
        while a <= b_:
            m = (a + b_) // 2; dz = mk(grid[m], None) if size is not None else mk(None, grid[m])
            if not chk(dz): hit, b_ = (m, dz), m - 1
            else: a = m + 1
        if hit: d2, st = hit[1], 'fit'; EXTRA['fit'] = grid[hit[0]]
    if st == 'over' and font:
        for f in (0.95, 0.9, 0.85, 0.8):
            dz = {**d2, 'fsz': {**fz, key: f}}
            if not chk(dz): d2, st = dz, 'shrink'; break
    if st != 'over' and not dry:
        if base: d2['_ov'] = 1
        items[idx] = (name, d2)
    return st

def _rgb(c):
    """สีที่ลูกค้าเลือก: 'P:acc' = ช่องสีของชุด (เปลี่ยนหน้าตาแล้วตามชุดใหม่) / '#RRGGBB' = สีที่เลือกเอง"""
    c = str(c)
    if c.startswith('P:'): c = eng.P.get(c[2:], '000000')
    return c.lstrip('#').upper()[:6]

DCOL = ('ink', 'acc', 'acc2', 'g1', 'mute')
def design_colors(M):
    """สีของดีไซน์นี้ (ช่องสีของชุด) + ขาว ดำ ไม่ซ้ำกัน ให้แผงสีบนเว็บ [[ค่า, รหัสสี]]"""
    eng.setpal(M['pal'], M.get('font', 'plex'), M.get('head'))
    out, seen = [], set()
    for k in DCOL:
        h = str(eng.P.get(k, '')).upper()
        if h and h not in seen: seen.add(h); out.append(['P:' + k, '#' + h])
    for h in ('FFFFFF', '000000'):
        if h not in seen: seen.add(h); out.append(['#' + h, '#' + h])
    return out

def _bullet(para, kind, pt):
    """จุดนำหน้า (bul) / เลขรายการ (num) / ไม่มี: bullet จริงของ PowerPoint (a:buChar / a:buAutoNum) + ระยะเยื้อง"""
    from pptx.oxml.ns import qn
    from pptx.util import Pt
    pPr = para._p.get_or_add_pPr()
    for t in ('a:buFont', 'a:buNone', 'a:buChar', 'a:buAutoNum', 'a:buBlip'):
        for e in pPr.findall(qn(t)): pPr.remove(e)
    if kind in ('bul', 'num'):
        ind = int(Pt(max(12, pt * (1.1 if kind == 'bul' else 1.6))))
        pPr.set('marL', str(ind)); pPr.set('indent', str(-ind))
        els = [pPr.makeelement(qn('a:buFont'), {'typeface': 'Arial'}), pPr.makeelement(qn('a:buChar'), {'char': '•'})] if kind == 'bul' \
            else [pPr.makeelement(qn('a:buAutoNum'), {'type': 'arabicPeriod'})]
    else:
        for a in ('marL', 'indent'): pPr.attrib.pop(a, None)
        els = [pPr.makeelement(qn('a:buNone'), {})]
    nxt = next((e for e in pPr if e.tag in (qn('a:tabLst'), qn('a:defRPr'), qn('a:extLst'))), None)
    for e in els:
        if nxt is not None: nxt.addprevious(e)
        else: pPr.append(e)

def fmts(slide, d):
    """d['tfm'] = {'items.2': {'b': 1, 'i': 0, 'u': 1, 's': 1, 'al': 'l|c|r', 'ls': 1.4, 'va': 't|m|b', 'li': 'bul|num|', 'col': 'P:acc'|'#RRGGBB'}}
    เขียนเป็นคุณสมบัติจริงของ PowerPoint ทั้งกล่อง (run/paragraph/bodyPr) แก้ต่อในแอปได้ (กฎไอซ์ 30 ต.ค.)"""
    from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
    from pptx.dml.color import RGBColor
    tf = d.get('tfm') or {}
    for s_, p, *_r in list(_match(slide, d)):
        f = tf.get('.'.join(map(str, p)))
        if not f: continue
        fr = _r[4]
        if f.get('va') in ('t', 'm', 'b') and not _r[5]: fr.vertical_anchor = {'t': MSO_ANCHOR.TOP, 'm': MSO_ANCHOR.MIDDLE, 'b': MSO_ANCHOR.BOTTOM}[f['va']]
        for para in fr.paragraphs:
            if f.get('al') in ('l', 'c', 'r'): para.alignment = {'l': PP_ALIGN.LEFT, 'c': PP_ALIGN.CENTER, 'r': PP_ALIGN.RIGHT}[f['al']]
            if f.get('ls'): para.line_spacing = float(f['ls'])
            if 'li' in f and para.runs: _bullet(para, f['li'], next((r.font.size.pt for r in para.runs if r.font.size), 18))
            for r in para.runs:
                if 'b' in f: r.font.bold = bool(f['b'])
                if 'i' in f: r.font.italic = bool(f['i'])
                if 'u' in f: r.font.underline = bool(f['u'])
                if 's' in f: r._r.get_or_add_rPr().set('strike', 'sngStrike' if f['s'] else 'noStrike')
                if f.get('col'): r.font.color.rgb = RGBColor.from_string(_rgb(f['col']))

def _fmt_now(tf, cell):
    """ค่ารูปแบบที่วาดจริงของกล่อง (ให้แถบบนเว็บแสดงสถานะ) จาก paragraph/run แรกที่มีคำ"""
    from pptx.oxml.ns import qn
    p = next((x for x in tf.paragraphs if x.runs), tf.paragraphs[0]); r = next((x for x in p.runs if x.text.strip()), p.runs[0] if p.runs else None)
    al = {1: 'l', 2: 'c', 3: 'r'}.get(int(p.alignment) if p.alignment is not None else 1, 'l')
    va = tf.vertical_anchor; va = {3: 'm', 4: 'b'}.get(int(va) if va is not None else 1, 't')
    pPr = p._p.pPr; li = ''
    if pPr is not None: li = 'bul' if pPr.find(qn('a:buChar')) is not None else 'num' if pPr.find(qn('a:buAutoNum')) is not None else ''
    o = dict(al=al, va=va, ls=round(p.line_spacing, 2) if isinstance(p.line_spacing, float) else 1.0, li=li)
    if r is not None:
        o.update(b=int(bool(r.font.bold)), i=int(bool(r.font.italic)), u=int(bool(r.font.underline)), s=int(r._r.rPr is not None and r._r.rPr.get('strike') == 'sngStrike'))
        try: o['col'] = '#' + str(r.font.color.rgb) if r.font.color and r.font.color.type is not None and r.font.color.rgb is not None else ''
        except Exception: o['col'] = ''
    return o

ZOBJ = True                                               # ใบ 019b รอบ 2: เว็บเปิดลาก/ล็อกรูป รูปทรง กราฟ ในแผงเลเยอร์ (ช่อง '#shape_id')
# ── ลำดับชั้น (ใบ 019+020 เลเยอร์): d['z'] = [[ช่อง, front|fwd|bwd|back], ...] เล่นซ้ำตามลำดับหลัง apply_moves ──
def _dpshape(slide, n):
    return next((x for x in slide.shapes if getattr(slide.part, '_d2s_dp', {}).get(x.shape_id, (None,))[0] == n), None)

def _zunit(slide, d, key):
    """shape ของช่องนี้ (กล่องบนการ์ด = การ์ด + ทุกอย่างในการ์ด ไปด้วยกันเหมือนตอนลาก) / '#id' = shape_id ในหน้าที่วาด (รูป รูปทรง กราฟ เลขหน้า ใบ 019b รอบ 2)"""
    if key.startswith('dpic.'):                          # ใบ 026 รูปในดีไซน์ที่ N
        s = _dpshape(slide, int(key.split('.')[1])); return s, ([s] if s is not None else [])
    if key.startswith('#') or key.startswith('add.'):
        s = next((x for x in slide.shapes if (str(x.shape_id) == key[1:] if key[0] == '#' else x.name == 'add.' + key.split('.')[1])), None)
        return s, ([s] if s is not None else [])
    sw, sh_ = slide.part.package.presentation_part.presentation.slide_width, slide.part.package.presentation_part.presentation.slide_height
    for s, p, *_r in _match(slide, d):
        if '.'.join(map(str, p)) != key or _r[5]: continue
        c = _card(_cards(slide, sw, sh_), s, p)
        return s, ([c] + [o for o in slide.shapes if o.shape_id != c.shape_id and _inside(o, c)]) if c is not None else [s]
    return None, []

def _ov(a, b):
    return a.left < b.left + b.width and b.left < a.left + a.width and a.top < b.top + b.height and b.top < a.top + a.height

def _zop(slide, d, key, op):
    s, unit = _zunit(slide, d, key)
    if not unit: return
    tree = slide.shapes._spTree; ids = {u.shape_id for u in unit}
    shs = [x for x in slide.shapes]; els = [x._element for x in shs if x.shape_id in ids]
    kids = [x for x in shs if x.shape_id not in ids]
    pos = [shs.index(x) for x in shs if x.shape_id in ids]
    if op == 'front':
        anchor = tree.find('{http://schemas.openxmlformats.org/presentationml/2006/main}extLst')
        for e in els: (anchor.addprevious(e) if anchor is not None else tree.append(e))
    elif op == 'back':
        first = shs[0]._element if shs else None
        for e in els:
            if first is not None and first is not e: first.addprevious(e)
    elif op == 'fwd':
        nxt = next((x for x in shs[max(pos) + 1:] if x.shape_id not in ids and any(_ov(x, u) for u in unit)), None)
        if nxt is not None:
            at = nxt._element
            for e in els: at.addnext(e); at = e
    elif op == 'bwd':
        prv = next((x for x in reversed(shs[:min(pos)]) if x.shape_id not in ids and any(_ov(x, u) for u in unit)), None)
        if prv is not None:
            for e in els: prv._element.addprevious(e)

def zorder(slide, d):
    for key, op in d.get('z') or []: _zop(slide, d, key, op)

def _hidden(slide, d, key, tol=9144):
    """กล่องข้อความถูกรูปทรงทึบ/รูปที่อยู่ชั้นบนบังทั้งกล่อง"""
    s, unit = _zunit(slide, d, key)
    if s is None: return False
    shs = list(slide.shapes); ids = {u.shape_id for u in unit}; i = shs.index(s)
    for o in shs[i + 1:]:
        if o.shape_id in ids or not (_solid(o) or getattr(o, 'shape_type', None) == 13): continue
        if o.left - tol <= s.left and o.top - tol <= s.top and s.left + s.width <= o.left + o.width + tol and s.top + s.height <= o.top + o.height + tol: return True
    return False

LASTPRS = []
def box_props(slide, d):
    """d['rot'] = {'t': 15} องศาตามเข็ม / d['lock'] = {'t': 1}  เขียนลง shape จริง: rotation + <a:spLocks noMove noResize noRot> ที่ PowerPoint เคารพ"""
    from pptx.oxml.ns import qn
    rot, lk = d.get('rot') or {}, d.get('lock') or {}
    for k in set(rot) | set(lk):
        s, unit = _zunit(slide, d, k)
        if s is None: continue
        if k in rot and len(unit) == 1: s.rotation = float(rot[k]) % 360          # กล่องบนการ์ดไม่หมุน (หมุนทั้งกลุ่มเป็นงานถัดไป)
        if k in lk:
            for u in unit:                                # รูปทรง รูป เส้น กราฟ/ตาราง กลุ่ม: แท็กล็อกของชนิดนั้น (graphicFrameLocks ไม่มี noRot ตามสคีมา)
                c = next((n[1] for n in (u._element.find(qn(t)) for t in ('p:nvSpPr', 'p:nvPicPr', 'p:nvCxnSpPr', 'p:nvGraphicFramePr', 'p:nvGrpSpPr')) if n is not None and len(n) > 1), None)
                tag = None if c is None else {qn('p:cNvSpPr'): 'a:spLocks', qn('p:cNvPicPr'): 'a:picLocks', qn('p:cNvCxnSpPr'): 'a:cxnSpLocks', qn('p:cNvGraphicFramePr'): 'a:graphicFrameLocks', qn('p:cNvGrpSpPr'): 'a:grpSpLocks'}.get(c.tag)
                if tag is None: continue
                L = c.find(qn(tag))
                if L is None: L = c.makeelement(qn(tag), {}); c.insert(0, L)
                for a in ('noMove', 'noResize') + (() if tag == 'a:graphicFrameLocks' else ('noRot',)): L.set(a, '1')

def set_box(items, idx, path, rot=None, lock=None):
    """หมุน (rot องศา, 0 = ตรง) / ล็อก (lock True/False) กล่องหนึ่ง ไม่กระทบการตัดบรรทัด (กรอบไม่หมุนเชิงวัด)"""
    name, d = items[idx]; key = '.'.join(map(str, path)); d2 = dict(d)
    for f, v in (('rot', None if rot is None else (round(float(rot), 1) % 360)), ('lock', None if lock is None else bool(lock))):
        if v is None: continue
        m = dict(d.get(f) or {})
        if v: m[key] = v if f == 'rot' else 1
        else: m.pop(key, None)
        if m: d2[f] = m
        else: d2.pop(f, None)
    items[idx] = (name, d2); return 'ok'

def scale_box(items, idx, path, rect, f, M):
    """มุมกรอบ (แบบ Canva): กรอบและตัวอักษรขยายเท่ากัน f = กว้างใหม่/กว้างเดิม  1 ขั้นเลิกทำ  ล้น = ย่อเองถึง 80% แบบ move_box"""
    name, d = items[idx]; key = '.'.join(map(str, path))
    us = dict(d.get('usz') or {}); u = round(min(2.0, max(0.05, us.get(key, 1) * float(f))), 3)
    if abs(u - 1) < 1e-3: us.pop(key, None)
    else: us[key] = u
    d2 = {k: v for k, v in d.items() if k != 'usz'}
    if us: d2['usz'] = us
    items[idx] = (name, d2)
    return move_box(items, idx, path, rect, M, resize=True)[0]

def z_box(items, order, k, path, op, M, ttl, ins=None):
    """ยกขึ้นบนสุด/ขึ้นหนึ่งชั้น/ลงหนึ่งชั้น/ส่งไปล่างสุด กล่องหนึ่ง (k = ตำแหน่งบนจอ) คืน ok / same (ลำดับไม่เปลี่ยน) / hidden (ข้อความจะถูกบังทั้งหมด ไม่เปลี่ยน)"""
    idx = order[k]; name, d = items[idx]; key = '.'.join(map(str, path))
    ops = [x for x in (d.get('z') or []) if not (op in ('front', 'back') and x[0] == key)] + [[key, op]]
    d2 = {**d, 'z': ops}
    def ids(dx):
        it = list(items); it[idx] = (name, dx)
        render([it[i] for i in order], M, ttl, only={k}, ins=ins or {}, hint=True)
        sl = LASTPRS[0].slides[0]
        return [x.shape_id for x in sl.shapes], sl
    a, s0 = ids(d); b, sl = ids(d2)
    if a == b: return 'same'
    if key.startswith('#'):                               # ชิ้นที่ไม่ใช่ข้อความ: ห้ามทำให้กล่องข้อความไหนถูกบังเพิ่ม
        hid = lambda s_, dx: {q for q in ('.'.join(map(str, p)) for _s, p, *_r in _match(s_, dx) if not _r[5]) if _hidden(s_, dx, q)}
        if hid(sl, d2) - hid(s0, d): return 'hidden'
    elif _hidden(sl, d2, key): return 'hidden'
    items[idx] = (name, d2); return 'ok'

def set_font_page(items, idx, fam, M, only_unset=False):
    """ฟอนต์ทั้งหน้า: ทุกกล่องของหน้า (only_unset = ทั้งไฟล์: เฉพาะกล่องที่ลูกค้ายังไม่ได้ตั้งเอง) ไม่พอดี = หน้านี้ใช้ฟอนต์เดิม คืน True/False"""
    name, d = items[idx]
    ff = dict(d.get('ffam') or {})
    for p, t in _leaves(d):
        k = '.'.join(map(str, p))
        if t.strip() and not (only_unset and k in ff): ff[k] = fam
    d2 = {**{k: v for k, v in d.items() if k not in ('ffam', '_ov')}, 'ffam': ff}
    if overflow(name, d2, M): return False
    items[idx] = (name, d2); return True

def fonts_used(items):
    return sorted({f for _, d in items for f in (d.get('ffam') or {}).values()})

def eot(ttf):
    """EOT 2.1 ไม่บีบอัด ไม่ XOR = ส่วนหัว + TTF เดิม (ใบ 015 เฟส 0 ข้อ e: PowerPoint Mac ใช้ได้เมื่อมี embedTrueTypeFonts="1")"""
    import struct
    from fontTools.ttLib import TTFont
    t = TTFont(io.BytesIO(ttf)); o = t['OS/2']; nm = t['name']
    s_ = lambda i: (nm.getDebugName(i) or '').encode('utf-16-le')
    pn = o.panose
    body = struct.pack('<10sBBLHH', bytes([pn.bFamilyType, pn.bSerifStyle, pn.bWeight, pn.bProportion, pn.bContrast, pn.bStrokeVariation, pn.bArmStyle, pn.bLetterForm, pn.bMidline, pn.bXHeight]),
                       1, 1 if o.fsSelection & 1 else 0, o.usWeightClass, o.fsType, 0x504C)
    body += struct.pack('<4L', o.ulUnicodeRange1, o.ulUnicodeRange2, o.ulUnicodeRange3, o.ulUnicodeRange4)
    body += struct.pack('<2L', o.ulCodePageRange1, o.ulCodePageRange2) + struct.pack('<L', t['head'].checkSumAdjustment) + b'\0' * 16
    for x in (s_(1), s_(2), s_(5), s_(4)): body += struct.pack('<HH', 0, len(x)) + x
    body += struct.pack('<HH', 0, 0)
    return struct.pack('<LLLL', 16 + len(body) + len(ttf), len(ttf), 0x00020001, 0) + body + ttf

def embed_fonts(buf, fams):
    """ฝังฟอนต์ฟรี (OFL) ที่ใช้ในงานลง .pptx: ppt/fonts/*.fntdata + rel + embeddedFontLst + embedTrueTypeFonts="1" (ตัวปกติ + ตัวหนา)"""
    import zipfile
    fams = [f for f in fams if f in FONTX and f not in LOCALF]
    if not fams: return buf
    zin, out = zipfile.ZipFile(io.BytesIO(buf)), io.BytesIO(); zout = zipfile.ZipFile(out, 'w', zipfile.ZIP_DEFLATED)
    parts, rels, lst, n = {}, '', '', 0
    for fam in fams:
        ids = {}
        for bold in (False, True):
            path = FONTX[fam][bold]
            if bold and path == FONTX[fam][False]: continue
            n += 1; parts[f'ppt/fonts/font{n}.fntdata'] = eot(open(path, 'rb').read())
            rels += f'<Relationship Id="rIdF{n}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/font" Target="fonts/font{n}.fntdata"/>'
            ids['bold' if bold else 'regular'] = f'rIdF{n}'
        lst += f'<p:embeddedFont><p:font typeface="{fam}" pitchFamily="2" charset="0"/>' + ''.join(f'<p:{k} r:id="{v}"/>' for k, v in ids.items()) + '</p:embeddedFont>'
    for it in zin.infolist():
        x = zin.read(it.filename)
        if it.filename == '[Content_Types].xml' and b'Extension="fntdata"' not in x:
            x = x.replace(b'<Default Extension="xml"', b'<Default Extension="fntdata" ContentType="application/x-fontdata"/><Default Extension="xml"')
        elif it.filename == 'ppt/_rels/presentation.xml.rels':
            x = x.replace(b'</Relationships>', rels.encode() + b'</Relationships>')
        elif it.filename == 'ppt/presentation.xml':
            t = x.decode(); i = t.index('/>', t.index('<p:notesSz')) + 2
            t = t[:i] + f'<p:embeddedFontLst>{lst}</p:embeddedFontLst>' + t[i:]
            t = t.replace('<p:presentation ', '<p:presentation embedTrueTypeFonts="1" ', 1)
            x = t.encode()
        zout.writestr(it, x)
    for k, v in parts.items(): zout.writestr(k, v)
    zout.close(); return out.getvalue()

def thai_spacing(slide):
    """ข้อความไทยหลายบรรทัดที่ระยะบรรทัดต่ำกว่า 1.15 วรรณยุกต์บรรทัดล่างชนบรรทัดบน (ปกตัวโต sp 0.98) ขยายเป็น 1.15"""
    for sh in slide.shapes:
        if not sh.has_text_frame or not re.search(r'[\u0E00-\u0E7F]', sh.text_frame.text): continue
        for p in sh.text_frame.paragraphs:
            if isinstance(p.line_spacing, float) and p.line_spacing < 1.15: p.line_spacing = 1.15

_DLBL = ('numFmt', 'spPr', 'txPr', 'dLblPos', 'showLegendKey', 'showVal', 'showCatName', 'showSerName', 'showPercent', 'showBubbleSize', 'separator')
def numfmt(slide, nf, sn=None):
    """รูปแบบตัวเลขตามเซลล์ต้นทาง ทับค่าที่ layout ตั้งตายตัว (เช่น 0"%" ของ by_chart_bar) ทั้งชีตฝังและป้ายบนกราฟ
    nf = [[รูปแบบต่อจุด] ต่อชุดข้อมูล]  ชุดเดียวกันรูปแบบไม่เท่ากัน (เอกสาร 10) ใส่ป้ายรายจุด
    ponytail: ชีตฝังใช้รูปแบบที่พบมากสุดของชุด ไม่ทำรายเซลล์"""
    import copy
    from lxml import etree
    from collections import Counter
    from pptx.chart.data import CategoryChartData
    from pptx.oxml.ns import qn
    from pptx.dml.color import RGBColor
    for gf in [x for x in slide.shapes if getattr(x, 'has_chart', False) and x.has_chart][:1]:
        ch = gf.chart; pl = ch.plots[0]
        top = [Counter(f).most_common(1)[0][0] for f in nf]
        cd = CategoryChartData(); cd.categories = list(pl.categories)
        for i, sr in enumerate(pl.series): cd.add_series(sn[i] if sn and i < len(sn) else sr.name, list(sr.values), number_format=top[min(i, len(top) - 1)])
        ch.replace_data(cd)
        try:                                               # แกนที่ดีไซน์ล็อกไว้ (ug_chart_pass max 100 สำหรับ %) ไม่ให้ข้อมูลลูกค้าตกขอบ
            va = ch.value_axis; vs = [v for sr in pl.series for v in sr.values if v is not None]
            if va.maximum_scale is not None and max(vs) > va.maximum_scale: va.maximum_scale = None
            if va.minimum_scale is not None and min(vs) < va.minimum_scale: va.minimum_scale = None
        except (ValueError, AttributeError): pass          # โดนัท/วงกลมไม่มีแกน
        pdl = pl._element.find(qn('c:dLbls'))
        shown = pdl is not None and pdl.find(qn('c:showVal')) is not None and pdl.find(qn('c:showVal')).get('val') == '1'
        line = pl._element.tag == qn('c:lineChart'); stk = pl._element.find(qn('c:grouping')) is not None and pl._element.find(qn('c:grouping')).get('val') in ('stacked', 'percentStacked')
        def setpos(el, v):                                 # c:dLblPos ต้องอยู่หลัง txPr ก่อน showLegendKey (ลำดับตาม schema)
            e = el.find(qn('c:dLblPos'))
            if e is None: e = etree.Element(qn('c:dLblPos')); el.find(qn('c:showLegendKey')).addprevious(e)
            e.set('val', v)
        for i, sr in enumerate(pl.series):
            f = nf[min(i, len(nf) - 1)]; ft = top[min(i, len(top) - 1)]
            sdl = sr._element.find(qn('c:dLbls'))
            if sdl is None:
                if not shown: continue
                sdl = sr._element.get_or_add_dLbls(); sdl.getparent().replace(sdl, copy.deepcopy(pdl)); sdl = sr._element.find(qn('c:dLbls'))
            nfe = sdl.find(qn('c:numFmt'))
            if nfe is None: continue
            nfe.set('formatCode', ft); nfe.set('sourceLinked', '0')
            if stk:                                        # ป้ายในแท่งซ้อน: ขาวบนแท่งเข้ม เข้มบนแท่งอ่อน (สีจางของดีไซน์อ่านไม่ออกบนส้ม)
                try:
                    h = str(sr.format.fill.fore_color.rgb); lum = (0.299 * int(h[:2], 16) + 0.587 * int(h[2:4], 16) + 0.114 * int(h[4:], 16)) / 255
                    sr.data_labels.font.color.rgb = RGBColor.from_string('FFFFFF' if lum < 0.6 else '1F1F1F')
                except (AttributeError, TypeError, ValueError): pass
            vals = list(sr.values); pos = {}
            if line and len(vals) > 1:                     # เส้น: ป้ายเหนือจุด จุดที่ต่ำกว่าเพื่อนข้าง ๆ (หุบ) ป้ายอยู่ใต้จุด ไม่ทับเส้นที่ขึ้นไป (150,250 / 149,000)
                setpos(sdl, 't')
                for j, v in enumerate(vals):
                    nb = [vals[k] for k in (j - 1, j + 1) if 0 <= k < len(vals) and vals[k] is not None]
                    if v is not None and nb and v < sum(nb) / len(nb): pos[j] = 'b'
            for j in sorted(set(pos) | {j for j, fj in enumerate(f) if fj != ft}):
                dl = etree.Element(qn('c:dLbl')); etree.SubElement(dl, qn('c:idx')).set('val', str(j))
                for k in _DLBL:
                    e = sdl.find(qn('c:' + k))
                    if e is not None: dl.append(copy.deepcopy(e))
                dl.find(qn('c:numFmt')).set('formatCode', f[j] if j < len(f) else ft)
                if j in pos: setpos(dl, pos[j])
                sdl.insert(len(sdl.findall(qn('c:dLbl'))), dl)
        if pdl is not None and pdl.find(qn('c:numFmt')) is not None: pdl.find(qn('c:numFmt')).set('formatCode', top[0])
        if len(pl.series) == 1 and pl._element.tag not in (qn('c:pieChart'), qn('c:doughnutChart')):
            ch.has_legend = False                          # ชุดเดียว: คำอธิบายสีซ้ำหัวรอง/หัวคอลัมน์ ("ยอดขาย (บาท)") ไม่ต้องมี

def drop_empty(slide, sw=13.333, sh_=7.5):
    """ป้าย/ปุ่มที่ไม่มีข้อความ (ช่องที่เอกสารไม่มี หรือข้อความตัวอย่างที่ scrub ลบ) เหลือแคปซูลสีว่าง ๆ บนสไลด์
    ลบเฉพาะคู่ "กล่องข้อความว่างที่ไม่มีพื้น" + "พื้นสีเล็ก ๆ ตำแหน่งเดียวกันพอดี" (ปุ่ม ป้าย)
    พื้นหลัง/แผงใหญ่ (สูงเกิน 1 นิ้ว หรือกว้างเกินครึ่งสไลด์) และกล่องที่มีพื้นเอง ไม่แตะ"""
    E = 914400; sh = list(slide.shapes); tol = E * 0.03
    same = lambda a, b: all(abs(int(getattr(a, k)) - int(getattr(b, k))) <= tol for k in ('left', 'top', 'width', 'height'))
    def nofill(x):
        try: return x.fill.type is None or x.fill.type == 5    # ไม่มีพื้น / พื้นโปร่ง (MSO_FILL.BACKGROUND)
        except Exception: return True
    small = lambda x: x.height <= E * 1.0 and x.width <= E * sw * 0.5
    for e in [x for x in sh if x.has_text_frame and not x.text_frame.text.strip() and nofill(x) and small(x)]:
        bg = [x for x in sh if x is not e and same(x, e) and small(x) and not (x.has_text_frame and x.text_frame.text.strip())
              and not getattr(x, 'image', None) and x.shape_type != 13]
        if len(bg) == 1:
            for x in bg + [e]:
                if x._element.getparent() is not None: x._element.getparent().remove(x._element)
    # แถบเมนู/แท็บของดีไซน์ (แถบเตี้ยที่ข้างในมีแต่กล่องข้อความว่างหลายกล่องกับเส้นคั่น) หลังลบคำตัวอย่างเหลือกรอบเปล่า: เอาออกทั้งแถบ
    sh = [x for x in slide.shapes]
    inside = lambda x, b: x.left >= b.left - 1e4 and x.top >= b.top - 1e4 and x.left + x.width <= b.left + b.width + 1e4 and x.top + x.height <= b.top + b.height + 1e4
    for b in [x for x in sh if x.height <= E * 0.8 and x.width >= E * 2 and x.shape_type == 1 and not (x.has_text_frame and x.text_frame.text.strip())]:
        kids = [x for x in sh if x is not b and inside(x, b)]
        empt = [x for x in kids if x.has_text_frame and not x.text_frame.text.strip() and x.shape_type == 17]
        if len(empt) >= 2 and all(x in empt or x.shape_type == 9 for x in kids):
            for x in [b] + kids:
                if x._element.getparent() is not None: x._element.getparent().remove(x._element)

_norm = lambda x: re.sub(r'[^\w\u0E00-\u0E7F]', '', x)   # เทียบเฉพาะตัวอักษร ลาย [ ] · ของดีไซน์ไม่นับ

def tidy(slide, d):
    """(1) ชื่อเดียวกันสองกล่อง (ป้ายเล็กหัวกระดาษ + หัวเรื่องใหญ่) เหลือกล่องใหญ่ (2) รายการข้อเดียว ไม่มีเลข 01"""
    by = {}
    for sh in slide.shapes:
        if not sh.has_text_frame or not sh.text_frame.text.strip() or sh.name.startswith(('ch:', 'ch2:')): continue   # ป้ายในกราฟซ้ำกับตัวเลขใหญ่ได้ (ใบ 028 D)
        r = next((r for p in sh.text_frame.paragraphs for r in p.runs if r.font.size), None)
        by.setdefault(' '.join(sh.text_frame.text.split()), []).append((r.font.size.pt if r else 0, sh))   # ชื่อปกที่แบ่งบรรทัดแล้วยังเป็นชื่อเดียวกับท้ายกระดาษ
    for t, xs in by.items():
        if len(xs) > 1 and len(t) > 3:
            big = max(z for z, _ in xs)
            for z, sh in xs:
                if z < big * 0.6:
                    for p in sh.text_frame.paragraphs:
                        for r in p.runs: r.text = ''
    its = d.get('items')
    if isinstance(its, list) and len(its) == 1:
        mine = {x.strip() for x in strings(d)}
        for sh in slide.shapes:
            if sh.has_text_frame and re.fullmatch(r'0?1\.?', sh.text_frame.text.strip()) and sh.text_frame.text.strip() not in mine:
                for p in sh.text_frame.paragraphs:
                    for r in p.runs: r.text = ''

def scrub(slide, mine):
    """ลบข้อความตัวอย่างที่ดีไซน์ฝังไว้ (ป้ายหัวกระดาษ "ข้อเสนอโครงการ 8 ต.ค. 2570", ชื่อบริษัทสมมติ)
    ลายดีไซน์ยังอยู่ครบ หายแค่คำที่ไม่ใช่ของลูกค้า  คืนรายการที่ลบ"""
    src = _norm(''.join(mine)); gone = []
    for sh in slide.shapes:
        if not sh.has_text_frame: continue
        for p in sh.text_frame.paragraphs:
            k = _norm(''.join(r.text for r in p.runs))
            if not k or k in ALLOW or k in src: continue
            if len(re.findall(r'[A-Za-z\u0E01-\u0E30\u0E32\u0E33\u0E40-\u0E44]', k)) >= 2 or re.search(r'\d[\d,\.]{2,}', k):   # นับตัวอักษร (พยัญชนะ+สระที่เป็นตัว) ไม่ต้องติดกัน: เดิมหลุด "(ขั้น 1)" "(เป้า 1)" ที่ layout เขียนตายตัว
                gone.append(''.join(r.text for r in p.runs).strip())
                for r in p.runs: r.text = ''
    return gone

# ══ 6. เลือก layout ในชุด → สร้างไฟล์ ═══════════════════════════════════════

_DECKS = {}
def deck_of(slug):
    """ไฟล์ต้นฉบับของชุด (META + SEQ) จาก decks/*.py"""
    if not _DECKS:
        for p in sorted(glob.glob(f'{K}/decks/*.py')):
            ns = {}
            try: exec(open(p, encoding='utf-8').read(), ns)
            except Exception: continue
            if 'META' in ns and 'SEQ' in ns: _DECKS[ns['META']['slug']] = ns
    return _DECKS.get(slug)

def slug_of(no):
    e = next(x for x in json.load(open(f'{HUB}/library/data.json')) if str(x['no']) == str(no))
    return e['slug'], e

CONT = {'ซึ่ง', 'และ', 'หรือ', 'โดย', 'เพื่อ', 'จึง', 'แต่', 'ที่', 'ของ', 'ใน', 'กับ', 'คือ', 'เป็น', 'ให้', 'จาก', 'ถึง', 'ได้',
        'แล้ว', 'ด้วย', 'อีก', 'ทั้ง', 'ตาม', 'เมื่อ', 'จน', 'หรือไม่', 'ก็', 'จะ', 'ไป', 'มา', 'คิดเป็น', 'รวม', 'เท่ากับ',
        'ลดลง', 'เพิ่มขึ้น', 'สูงขึ้น', 'เหลือ', 'มาจาก', 'เริ่ม', 'ยัง', 'ไม่', 'ต้อง', 'อยู่', 'กว่า', 'มากกว่า', 'น้อยกว่า',
        'สูงกว่า', 'ต่ำกว่า', 'ภายใน', 'สำหรับ', 'เพราะ', 'เนื่องจาก', 'ทำให้', 'แม้', 'หาก', 'ถ้า', 'เช่น', 'ตั้งแต่',
        'เฉลี่ย', 'เพิ่ม', 'ลด', 'โดยเฉลี่ย', 'จำนวน', 'ประมาณ', 'ชั้น', 'ระดับ', 'ประจำ', 'ทั้งหมด', 'เสร็จ', 'แล้วเสร็จ'}
# ขึ้นต้นด้วยคำเหล่านี้ = ต่อจากความก่อน (เทียบต้นคำ เพราะตัวตัดคำอาจแยก "สูงกว่าค่าเฉลี่ย" เป็น "สูง")
SUBJ = ('วิชา', 'งบ', 'ขอให้', 'มอบหมาย', 'ที่ประชุม', 'ผลสอบ', 'ผลการ', 'ผู้อำนวยการ', 'ครู', 'นักเรียน', 'โรงเรียน', 'ฝ่าย', 'เริ่ม', 'เรื่อง', 'ผู้ปกครอง', 'ประธาน', 'คณะ', 'สำนักงาน', 'ทัศนศึกษา',
        'ด้าน', 'แผน', 'ระยะที่', 'ปีหน้า', 'ปีต่อไป', 'เดือนหน้า', 'ภาคเรียนหน้า', 'ครั้งหน้า', 'ครั้งต่อไป')   # ขึ้นเรื่องใหม่ (ช่วงเวลาถัดไป = เรื่องใหม่ ไม่ใช่ส่วนต่อของงบ/ผล)
CONT_PRE = ('และ', 'ซึ่ง', 'ใกล้เคียง', 'แบ่งเป็น', 'เท่ากัน', 'ส่วนที่เหลือ', 'โดย', 'เพื่อ', 'จึง', 'แต่', 'หรือ', 'สูงกว่า', 'ต่ำกว่า', 'มากกว่า', 'น้อยกว่า', 'เสร็จ', 'ลดลง',
            'เพิ่มขึ้น', 'คิดเป็น', 'เฉลี่ย', 'เนื่องจาก', 'เพราะ', 'ตั้งแต่', 'จนถึง', 'ภายใน', 'สำหรับ', 'เท่ากับ')
NOUN_PRE = ('ที่ประชุม', 'ที่ปรึกษา', 'ที่ดิน', 'ที่พัก', 'ที่อยู่', 'ที่มา', 'ที่ทำการ')   # คำนามที่ขึ้นต้นด้วย "ที่" (ตัวตัดคำของเบราว์เซอร์แยกเป็น "ที่"+...)
cont = lambda w: not w.startswith(NOUN_PRE) and ((wordsx(w) or [w])[0] in CONT or w.startswith(CONT_PRE) or w.startswith('ๆ'))   # คำต่อความ ห้ามตัดหน้าคำเหล่านี้
TAIL = {'ถึง', 'จาก', 'และ', 'หรือ', 'ของ', 'ใน', 'กับ', 'ที่', 'ซึ่ง', 'โดย', 'เพื่อ', 'แต่', 'คือ', 'เป็น', 'ตาม', 'ตั้งแต่',
        'สำหรับ', 'ภายใน', 'เช่น', 'ทั้ง', 'จน', 'เมื่อ', 'ว่า'}                                 # ห้ามจบข้อด้วยคำเหล่านี้
UNIT = (r'(?:%|฿|บาท|คน|ราย|ครั้ง|วัน|เดือน|ปี|ชั่วโมง|หน้า|ล้าน|แห่ง|โรงเรียน|ชิ้น|เล่ม|คะแนน|นาที|เปอร์เซ็นต์|พ\.ศ|ค\.ศ'
        r'|มกราคม|กุมภาพันธ์|มีนาคม|เมษายน|พฤษภาคม|มิถุนายน|กรกฎาคม|สิงหาคม|กันยายน|ตุลาคม|พฤศจิกายน|ธันวาคม'
        r'|ม\.ค|ก\.พ|มี\.ค|เม\.ย|พ\.ค|มิ\.ย|ก\.ค|ส\.ค|ก\.ย|ต\.ค|พ\.ย|ธ\.ค)')   # ตัวเลขกับหน่วย/เดือนอยู่ด้วยกันเสมอ

def numunit(cur, w):
    """cur จบด้วยตัวเลข และ w ขึ้นด้วยหน่วย (หรือคำไทยสั้น ๆ ที่ไม่ใช่คำขึ้นเรื่อง ถือเป็นหน่วย เช่น เปอร์เซ็นต์ ห้อง) = ห้ามตัดตรงนี้"""
    if not re.search(r'\d\s*$', cur): return False
    w = (w.strip().split(' ') or [''])[0]                 # ทั้งคำถึงเว้นวรรค (ไม่พึ่งตัวตัดคำ ซึ่งในเบราว์เซอร์อาจแยก "เปอร์เซ็นต์")
    return bool(re.match(UNIT, w)) or (bool(re.match(r'[\u0e01-\u0e2e\u0e40-\u0e44]', w)) and len(w) <= 12 and not (w.startswith(SUBJ) and w not in SUBJ))   # "7 เรื่อง" = ลักษณนาม ไม่ใช่คำขึ้นเรื่อง

FAM = {'วิชา': 'สอบ', 'ผลสอบ': 'สอบ', 'งบ': 'งบ', 'เริ่ม': 'งบ', 'ระยะที่': 'ระยะ'}   # ข้อที่เป็นเรื่องเดียวกัน (ผลสอบหลายวิชา) ควรอยู่หน้าเดียวกัน

# ใบ 037: คำเปิดเรื่องที่ผู้พูดบอกเอง (เรื่องที่สอง ... เรื่องสุดท้าย) ชัดกว่าคำขึ้นเรื่องทั่วไป (ขอให้ งบ ...)
TOPIC = re.compile(r'(เรื่อง(ที่\s*(\d+|หนึ่ง|สอง|สาม|สี่|ห้า|หก|เจ็ด|แปด|เก้า|สิบ)|สุดท้าย|แรก|ต่อไป|ถัดไป)|ประเด็น(ที่\s*\S|สุดท้าย)|สุดท้ายคือ)')

def groups(ps):
    """เลขกลุ่มเรื่องของแต่ละข้อ: ข้อที่ขึ้นต้นเรื่องใหม่เปลี่ยนกลุ่ม ข้อที่ไม่มีคำขึ้นเรื่องอยู่กลุ่มเดิม
    มีคำเปิดเรื่องตั้งแต่ 2 ครั้ง (02-meeting-wall: CRM กับลาพักร้อนเคยปนหน้าเดียว) = ตัดกลุ่มที่คำเปิดเรื่องเท่านั้น"""
    tops = [bool(TOPIC.match(p_)) for p_ in ps]
    if sum(tops) >= 2:
        g = 0; out = []
        for i, t_ in enumerate(tops):
            if t_ and i: g += 1
            out.append(g)
        return out
    out, g, last = [], 0, None
    for p_ in ps:
        k = next((FAM.get(x, x) for x in SUBJ if p_.startswith(x)), None)
        if out and k is not None and k != last: g += 1
        if k is not None: last = k
        out.append(g)
    return out

def gchunk(ps, n=5):
    """แบ่งข้อเป็นหน้า ไม่แยกกลุ่มเรื่องเดียวกันข้ามหน้า (เว้นกลุ่มยาวเกินหน้า) และไม่ปนกลุ่มถ้าแยกได้"""
    gs = groups(ps); grp = []
    for p_, g in zip(ps, gs):
        if grp and grp[-1][0] == g: grp[-1][1].append(p_)
        else: grp.append((g, [p_]))
    pages, solo = [], False
    for _, xs in grp:
        if len(xs) == 1 and solo and len(pages[-1]) < 3: pages[-1].append(xs[0]); continue   # ข้อเดี่ยวหลายเรื่องรวมหน้าได้ ไม่ให้หน้าโล่งทีละข้อ
        for part in chunk(xs, n): pages.append(list(part))
        solo = len(xs) == 1
    return pages

def points(t, hi=170):
    """บรรทัด/ย่อหน้ายาว → ข้อ: ตัดที่ท้ายประโยคหรือก่อนคำขึ้นเรื่องใหม่ (วิชา งบ เรื่อง ที่ประชุม ...) เท่านั้น
    คำเทียบ/อธิบายต่อท้ายข้อเดิม หัวเรื่องสั้น ๆ ("เรื่องค่าใช้จ่าย") ไปอยู่ต้นข้อถัดไป ไม่ค้างท้ายข้อ  ข้อยาวเกิน hi แบ่งที่รอยต่อความ"""
    out, cur = [], ''
    lead = (wordsx(t.split()[0]) or [''])[0] if t.split() else ''
    rep = len(lead) >= 3 and sum(1 for w in t.split() if w.startswith(lead) or w.startswith('และ' + lead)) >= 2   # ข้อขนาน (เพื่อ... เพื่อ... และเพื่อ...)
    for w in t.split():
        newsub = ((w.startswith(SUBJ) and not cont(w)) or (rep and (w.startswith(lead) or w.startswith('และ' + lead)))) and not numunit(cur, w)
        if cur and len(cur) >= 30 and (re.search(r'[.!?]$', cur) or newsub):
            out.append(cur); cur = w
        else: cur = f'{cur} {w}' if cur else w
    if cur: out.append(cur)
    res = []
    for x in out:
        if 'แบ่งเป็น' in x and len(re.findall(r'\d[\d,]*\s*บาท', x)) >= 3 and len(x) <= 260: res.append(x); continue
        m_ = re.search(r' (ได้แก่|ดังนี้|คือ) ', x)
        if m_ and len(x) <= 260:                           # รายการที่ขึ้นด้วย ได้แก่/ดังนี้/คือ เป็นก้อนเดียว ไม่แบ่งหน้า
            e_ = re.search(r' และ\S+', x[m_.end():]); k = m_.end() + e_.end() if e_ else len(x)
            if len(x) > hi and len(x) - k >= 30: res += [x[:k]] + points(x[k + 1:], hi); continue   # ข้อยาว: ก้อนรายการจบที่ "และ<ข้อสุดท้าย>" ความที่ตามมาเป็นข้อใหม่
            res.append(x); continue
        if len(x) > hi:                                    # ประโยคยาวสองเรื่อง: ตัดที่ "แต่" ก่อน (ไม่ใช่ "แต่ละ")
            m = [k.start() for k in re.finditer(r' แต่(?!ละ)', x) if 40 <= k.start() <= len(x) - 40 and x[k.start() + 4:].startswith(SUBJ)]   # แต่ + เรื่องใหม่ (แต่วิชา...) เท่านั้น
            if m:
                k = min(m, key=lambda i: abs(i - len(x) / 2)); res += points(x[:k], hi) + points(x[k + 1:], hi); continue
        res += pieces(clauses(x), lo=40, hi=hi) if len(x) > hi else [x]
    return res

def clauses(t):
    """ตัดเฉพาะท้ายประโยค (. ! ?) หรือเว้นวรรคที่คำถัดไปขึ้นความใหม่ ไม่ตัดหน้าคำเชื่อม (ซึ่ง และ โดย ...) ไม่แยกตัวเลขกับหน่วย"""
    cl, cur = [], ''
    for w in t.split():
        tail = (words(cur.split()[-1]) or [''])[-1] if cur else ''
        brk = cur and (re.search(r'[.!?]$', cur) or (not cont(w) and not re.search(r'ที่ \d+$', cur) and tail not in TAIL and not numunit(cur, w)
                                                       and not re.search(r'\d', w) and not re.match(r'[(A-Za-z]', w) and not re.search(r'[(:]$', cur)))
        if brk: cl.append(cur); cur = w
        else: cur = f'{cur} {w}' if cur else w
    return cl + [cur] if cur else cl

def pieces(cl, lo=35, hi=130):
    """รวมความสั้นเข้ากับความก่อนหน้า (ความสั้นที่ตามมามักเป็นส่วนต่อ) ให้แต่ละข้อยาวพอ ๆ กัน ไม่แต่งคำ ไม่ทิ้งคำ"""
    out = []
    for c in cl:
        new = c.startswith(SUBJ)                           # เรื่องใหม่ (วิชาอื่น งบ มติ) ไม่รวมกับข้อก่อน ตัวเลขสองเรื่องจะไม่ปนกัน
        if out and not new and len(c) < 30 and len(out[-1]) + len(c) + 1 <= hi * 1.4: out[-1] += ' ' + c      # เศษสั้น ๆ ต่อท้ายข้อก่อน
        elif out and (not new or len(out[-1]) < 30) and len(out[-1]) < lo and len(out[-1]) + len(c) + 1 <= hi: out[-1] += ' ' + c   # หัวเรื่องสั้นค้างท้าย → ไปกับข้อถัดไป
        else: out.append(c)
    if len(out) > 1 and len(out[-1]) < lo and not out[-1].startswith(SUBJ) and len(out[-2]) + len(out[-1]) + 1 <= hi * 1.3: last = out.pop(); out[-1] += ' ' + last
    return out

LASTBLOCKS = []
PLANBIG = 0                                                # ใบ 037: ขนาดเนื้อหาขั้นต่ำระหว่าง plan_iter (โหมดประกอบการพูด) 0 = ปิด
HEADF = re.compile(r'(ส่วนราชการ|ที่|วันที่|เรื่อง|เรียน|อ้างถึง|สิ่งที่ส่งมาด้วย)\s+\S')   # ช่องหัวหนังสือราชการ (ระเบียบงานสารบรรณ)
FORMS = {'บันทึกข้อความ', 'บันทึก', 'หนังสือ', 'หนังสือภายใน', 'หนังสือภายนอก', 'คำสั่ง', 'ประกาศ', 'ระเบียบ'}   # ชื่อแบบฟอร์มล้วน ไม่บอกว่าเรื่องอะไร

def analyze(path, name=None):
    """ไฟล์ลูกค้า → ชื่อเรื่อง + รายการแผ่น (ยังไม่เลือก layout)"""
    blocks = read_any(path); INFO.clear(); INFO['sections'] = 0; LASTBLOCKS[:] = blocks   # ใบ 037 โครงหน้าอ้างกลับเอกสาร
    body = [b for b in blocks if b[0] != 'h']
    if len(body) == 1 and body[0][0] == 'p' and len(body[0][1]) >= 120:   # วางมาเป็นย่อหน้ายาวย่อหน้าเดียว
        pall = points(body[0][1], hi=170); hs = [b for b in blocks if b[0] == 'h']
        ttl = hs[0][2] if hs else pall.pop(0)                  # ไม่มีหัวเรื่อง = ข้อแรก (ถึงคำขึ้นเรื่องถัดไป) เป็นชื่อเรื่อง
        if not hs and len(ttl) > 60:                           # ความแรกยาวเกินปก: ชื่อเรื่อง = ความแรกเท่านั้น ที่เหลือกลับไปเป็นข้อในหน้าเนื้อหา (ไม่ใส่ก้อนยาวบนปก)
            c0 = clauses(ttl)[0]
            cut = len(c0) if 12 <= len(c0) <= 70 and len(c0) < len(ttl) else next((m.start() for m in re.finditer(' ', ttl) if 20 <= m.start() <= 60
                        and (wordsx(ttl[m.start() + 1:]) or [''])[0] not in CONT and not re.match(UNIT, ttl[m.start() + 1:])
                        and not re.search(r'\d', ttl[m.start() + 1:].split(' ')[0])), None)
            if cut: ttl, rest = ttl[:cut], ttl[cut + 1:]; pall[:0] = points(rest, hi=170)
        ps = pall                                              # ข้อละเรื่อง ตัดที่ท้ายประโยค/คำขึ้นเรื่องเท่านั้น
        if len(ps) >= 2:
            want = [dict(kind='cover', t=ttl, _sec=None)] + [dict(kind='list', t='', ordered=False, note='', items=[(x,) for x in part], _sec=0) for part in gchunk(ps)]   # เป็นรายการ ไม่ทำการ์ดตัวเลข (ป้ายจะเป็นประโยคเว้าแหว่ง)
            for w_ in want[1:]:                                # ใบ 037: กลุ่มที่ขึ้นด้วยคำเปิดเรื่อง ("เรื่องที่สามคือระบบ CRM ...") = หัวข้อของหน้า ตัดที่ความแรก คำครบ
                x0 = w_['items'][0][0]
                if not TOPIC.match(x0): continue
                c0 = (clauses(x0) or [x0])[0]
                if len(x0) <= 60 and len(w_['items']) > 1: w_.update(t=x0, items=w_['items'][1:])   # ความแรกทั้งข้อสั้นพอเป็นหัวข้อ (ไม่ตัดกลางชื่อ "ระบบ CRM ใหม่")
                elif 12 <= len(c0) <= 60 and len(c0) < len(x0) and x0[len(c0):len(c0) + 1] == ' ': w_.update(t=c0, items=[(x0[len(c0) + 1:],)] + w_['items'][1:])
            if len(want) > MAXSLIDES: NOTES.append(f'เอกสารยาว ทำเป็นสไลด์ได้สูงสุด {MAXSLIDES} หน้า ส่วนที่เหลือยังไม่ได้ทำเป็นสไลด์'); want = want[:MAXSLIDES]
            return ttl, want
    title, secs = sections(blocks)
    INFO['sections'] = len([x for x in secs if x['t']])
    CLOSE = ('ขอแสดงความนับถือ', 'ลงชื่อ', 'จึงเรียนมาเพื่อ')     # ใบ 045: "จึงเรียนมาเพื่อโปรด..." = ประโยคปิดหนังสือราชการ อยู่หน้าท้ายกับคำลงท้าย
    closing = []
    for x in secs:                                         # คำลงท้ายจดหมาย + บรรทัดชื่อ/ตำแหน่งสั้น ๆ ที่ตามมา = หน้าท้าย ไม่ใช่ข้อ
        keep, on = [], False
        for b in x['body']:
            t_ = b[1] if b[0] in ('p', 'li') else ''
            if t_.startswith(CLOSE) or (on and t_ and len(t_) <= 40 and not re.search(r'\d', t_)): closing.append(t_); on = True
            else: keep.append(b); on = False
        x['body'] = keep
    cov_s = ''
    b0 = secs[0]['body'] if secs and not secs[0]['t'] else []
    n0 = 0                                                 # หัวหนังสือ (บันทึกข้อความ/หนังสือราชการ): ส่วนราชการ ที่ วันที่ เรื่อง เรียน อ้างถึง ... บรรทัดติดกันใต้ชื่อเรื่อง
    while n0 < len(b0) and b0[n0][0] == 'p' and len(b0[n0][1]) <= 100 and HEADF.match(b0[n0][1]): n0 += 1
    lead = [b[1] for b in b0[:n0]]
    if lead and any(x.startswith(('ส่วนราชการ', 'เรื่อง ', 'เรียน ')) for x in lead):
        # ข้อความนำบนปก = หัวหนังสือ + บรรทัดเปิดหนึ่งบรรทัดที่จบด้วย "ดังนี้" เท่านั้น ที่เหลือเป็นเนื้อหาตามปกติ (ไม่เป็นหัวข้อ/ข้อซ้ำทุกหน้า)
        subj = next((x for x in lead if x.startswith('เรื่อง ')), None)
        if subj and (title or '').strip() in FORMS:        # ใบ 045: ชื่อเรื่องเป็นแค่ชื่อแบบฟอร์ม ("บันทึกข้อความ") → ปก = "เรื่อง ..." ชื่อแบบฟอร์มไปข้อความนำ
            lead = [title] + [x for x in lead if x is not subj]; title = subj
        k = n0 + (1 if len(b0) > n0 and b0[n0][0] == 'p' and len(b0[n0][1]) <= 80 and re.search(r'ดังนี้\s*:?$', b0[n0][1]) else 0)
        lead += [b0[n0][1]] if k > n0 else []
        while len(' '.join(lead)) > 120 and len(lead) > 1:   # ข้อความนำยาวเกินปก: ท้าย ๆ กลับไปเป็นเนื้อหา
            lead.pop(); k -= 1
        cov_s = ' '.join(lead)
        if b0[k:]: secs[0] = dict(secs[0], body=b0[k:])
        else: secs = secs[1:]
        INFO['sections'] = len([x for x in secs if x['t']])
    for x in secs:                                         # ตารางที่ไม่มีหัวข้อ (ชีตเดียว ชื่อชีตเป็นชื่อเรื่อง): ใช้ชื่อเรื่องเป็นหัวหน้า ไม่ปล่อยหน้าไม่มีชื่อ
        if not x['t'] and title and any(b[0] == 'table' for b in x['body']): x['t'] = title
    ttl = title or os.path.splitext(name or os.path.basename(path))[0]
    # _sec = หัวข้อที่หน้านี้มาจาก (เลขลำดับในเอกสาร) สารบัญผูกกับหน้าด้วยเลขนี้ ไม่ใช่ชื่อ (หน้าที่ใช้ประโยคเป็นชื่อก็ไม่หลุด)
    want = [dict(kind='cover', t=ttl, _sec=None, **({'s': cov_s} if cov_s else {}))]
    # สารบัญปิดไว้ตั้งต้น ลูกค้ากดใส่เอง (ไอซ์ 29 ต.ค. 2569): เตรียมไว้ใน want แบบ _off (plan ข้าม) ชื่อหัวข้อตามการแก้ไปด้วย add_agenda เปิดใช้
    ix = [i for i, s in enumerate(secs) if s['t']][:6]
    if len(ix) >= 2: want.append(dict(kind='agenda', t='สารบัญ', items=[(secs[i]['t'],) for i in ix], _secs=ix, _sec=None, _off=1))
    for i, s in enumerate(secs): want += [dict(x, _sec=i) for x in shapes(s)]
    if closing: want.append(dict(kind='statement', t=' '.join(closing), _sec=None))
    cap = MAXSLIDES + (len(ix) >= 2)
    if len(want) > cap:
        NOTES.append(f'เอกสารยาว ทำเป็นสไลด์ได้สูงสุด {MAXSLIDES} หน้า ส่วนที่เหลือยังไม่ได้ทำเป็นสไลด์'); want = want[:cap]
    return ttl, want

def pool_of(slug):
    m = deck_of(slug)
    pool = [(nm, ex, *kind_of(nm, ex, i, len(m['SEQ']))) for i, (nm, ex) in enumerate(m['SEQ'])]
    pool += [(nm, ex, kd, -1, sl) for nm, ex in importlib.import_module('lay_charts').SEQ if 'radar' not in nm for kd, _, sl in [kind_of(nm, ex, 1, 99)]]   # ponytail: เรดาร์ซ่อนไว้ก่อน พรีวิวบนเว็บ (pptx-preview) วาดเรดาร์ไม่ได้ = หน้าว่าง (QA 30 ต.ค.) โค้ดยังอยู่ใน lay_charts   # หน้ากราฟกลาง B/C (ใบ 016 ไอซ์ "ชอบ B กับ C ครับ") n_ex=-1: แพ้หน้ากราฟของชุด ชนะหน้าตาราง / C ไม่มีรูปในหมวด = วาดไม่ได้ ไม่ถูกเลือก
    LAYKIND.update({x[0]: x[2] for x in pool})
    return dict(m['META']), pool

def candidates(c, pool, used):
    cand = []
    for nm, ex, kd, n_ex, slots in pool:
        pen = FIT.get(c['kind'], {}).get(kd)
        if pen is None: continue
        n_c = len(c.get('items') or c.get('rows') or [])
        if c.get('_lead') and 'note' not in ex and 's' not in ex: continue   # ข้อความนำ (ยอดรวม) ต้องมีที่วาง
        if c['kind'] == 'list' and re.search(r'(step|process|arrow|roadmap|journey)', nm) and any('บาท' in ' '.join(x) for x in c.get('items') or []): continue   # รายการราคาไม่ใช่ขั้นตอน ไม่ใช้หน้าตาลูกศร
        if c['kind'] == 'chart' and re.search(r"chart\(s, '(line|area)'", SRC.get(nm, '')) and not all(periodish(str(x)) for x in c.get('cats') or ['x']): continue   # ใบ 045: เส้น = แนวโน้มตามเวลา หมวดที่ไม่ใช่ช่วงเวลา (รายการงบ) ใช้แท่ง ไม่งั้นอ่านเป็นขึ้นลงผิด
        if 'quote' in nm and not re.search(r'["“”«»]', ''.join(strings({k: c.get(k) for k in ('t', 's', 'items')}))): continue   # กรอบคำพูดเฉพาะคำพูดจริง (มีเครื่องหมายคำพูด)
        if len(c.get('items') or []) > CAP.get(nm, 99) or len(c.get('rows') or []) > ROWCAP.get(nm, 99): continue
        cand.append((pen * 10 + abs(n_c - n_ex) * 2 + used.get(nm, 0) * 20, nm, ex, slots))   # ใช้ซ้ำโดนโทษแรงขึ้น ให้หน้าตาหลากหลาย
    return sorted(cand, key=lambda x: x[0])

COVER_MIN = 40                                              # slide-judge 30 ต.ค.: ชื่อปก <= 60 ตัว ห้ามต่ำกว่า 40pt / ยาวกว่านั้นลงได้ถึง 32 / 28-24 ทางสุดท้ายหลังลองทุกปก
PRE = ('การ', 'ความ')                                      # คำนำหน้าที่ติดคำถัดไปเป็นคำผสม (แผนการตลาด ความรู้): ไม่แบ่งบรรทัดติดคำนี้
COMP = ('ศูนย์กีฬาชุมชน', 'กีฬาชุมชน', 'ศูนย์กีฬา', 'ศูนย์การเรียนรู้', 'ศูนย์การค้า', 'ศูนย์บริการ', 'ศูนย์ข้อมูล', 'อบรมเชิงปฏิบัติการ', 'ประชุมเชิงปฏิบัติการ', 'สัมมนาเชิงปฏิบัติการ', 'เชิงปฏิบัติการ',
        'ปฏิบัติการ', 'โครงการ', 'การเรียนรู้', 'การเรียนการสอน', 'ประชาสัมพันธ์', 'มหาวิทยาลัย', 'สถานศึกษา', 'กระทรวงศึกษาธิการ', 'ผู้บริหาร', 'นักเรียน', 'นักศึกษา',
        'งบประมาณ', 'ประจำปี', 'ปีการศึกษา', 'ภาคเรียน', 'วิสาหกิจชุมชน', 'สหกรณ์', 'ห้างหุ้นส่วน', 'บริษัทจำกัด')   # ponytail: รายการคำผสมที่เจอจริง เจอคำใหม่ค่อยเติม (ตัวตัดคำบนเว็บ = Intl.Segmenter ไม่มีพจนานุกรมคำผสม)
BOUND = ('ศูนย์', 'เชิง', 'สถาน', 'หน่วย')                     # คำที่ต้องมีคำต่อท้ายเสมอ ห้ามจบบรรทัด
def _okcut(ws, k):
    """จุดแบ่งบรรทัดชื่อเรื่องที่ใช้ได้: ไม่อยู่ในวงเล็บ ไม่ทิ้งขีดท้ายบรรทัด ไม่ติด การ/ความ (QA 30 ต.ค.: "แผนการ / ตลาด" "(ฉบับ / ปรับปรุง)" "- ท้ายบรรทัด")"""
    left = ''.join(ws[:k]); last = left.rstrip()[-1:] if left.strip() else ''
    if left.count('(') > left.count(')') or left.count('[') > left.count(']') or left.count('"') % 2: return False
    if last in ('-', '–', '—', '(', '['): return False
    if ws[k].lstrip()[:1] in ('-', '–', '—', ')', ']', ',', '.', ':'): return False   # QA 30g: บรรทัดห้ามขึ้นต้นด้วยขีด/วงเล็บปิด/จุด
    full, pos = ''.join(ws), len(left)
    for c_ in COMP:                                           # คำผสมที่ตัวตัดคำแยกออก (ศูนย์|กีฬา อบรม|เชิงปฏิบัติการ โครง|การ) ห้ามแบ่งกลาง
        i = full.find(c_)
        while i >= 0:
            if i < pos < i + len(c_): return False
            i = full.find(c_, i + 1)
    if numunit(left, ''.join(ws[k:])): return False           # เฟส D: ไม่แยกเลขจากหน่วย/เดือนที่ตามมา (studiopitch ปก "วันที่ 14 | พฤศจิกายน")
    if ws[k - 1].strip().endswith(BOUND): return False
    pv = next((w.strip() for w in reversed(ws[:k]) if w.strip()), '')
    if pv in TAIL or pv in ('ที่', 'ครั้งที่', 'รุ่นที่', 'ฉบับที่', 'ปีที่', 'ปี', 'พ.ศ.', 'ค.ศ.', 'ปีการศึกษา'): return False   # "รุ่นที่ | 2"
    nx = ws[k].strip()
    if re.match(r'[\d๐-๙]', nx) and (re.search(r'(ปี|พ\.ศ\.|ค\.ศ\.|ที่)$', pv) or re.search(r'[\d๐-๙,.]$', pv)): return False   # QA 30m: "ประจำปี | 2569" / เลขห้ามหักกลาง
    return ws[k - 1].strip() not in PRE and ws[k].strip() not in PRE

def _breaks(ws, n, keep=2, sp=False):
    """จุดแบ่งชื่อเรื่องเป็น n บรรทัดที่รอยต่อคำ บาลานซ์ความยาว ไม่ตัดหน้าคำต่อความ ไม่ทิ้งคำเชื่อมท้ายบรรทัด  sp = แบ่งเฉพาะที่เว้นวรรค
    คืนรายการบรรทัด keep แบบที่ดีที่สุด"""
    import itertools
    ok = [k for k in range(1, len(ws)) if ws[k].strip() and not cont(''.join(ws[k:]).strip()) and ws[k - 1].strip() not in TAIL and _okcut(ws, k)
          and (not sp or not ws[k - 1].strip() or ws[k - 1].endswith(' '))]
    out = []
    for cut in itertools.combinations(ok, n - 1):
        parts = [''.join(ws[a:b]).strip() for a, b in zip((0,) + cut, cut + (len(ws),))]
        if not all(parts): continue
        glue = sum(1 for k in cut if ws[k - 1].strip() and len(ws[k - 1].strip()) <= 4 and len(ws[k].strip()) <= 4)   # คำสั้นสองคำติดกัน = มักเป็นคำผสม ("รัก|การ" "การ|อ่าน") ไม่แบ่งตรงนั้นถ้ามีทางอื่น
        nat = sum(1 for k in cut if re.match(r'(ปี|พ\.ศ\.|ค\.ศ\.)?\s*[\d๐-๙]{4}', ''.join(ws[k:]).strip()))   # QA 30j: แบ่งก่อน "ปี 2569" ดีกว่าแบ่งกลางชื่อ
        out.append((glue, -nat, max(map(len, parts)), parts))
    return [x[-1] for x in sorted(out, key=lambda x: x[:3])[:keep]]

# ไอซ์ 2 พ.ย. 2569: "พวกนี้มันควรจะเด่นสุดด้วยซ้ำเพราะเหมือนเป็นการบอกครั้งที่เท่าไหร่มันสำคัญ" รุ่น/ครั้ง/ปี อยู่ในชื่อเรื่องหลักเสมอ ห้ามย้ายไปหัวรองตัวเล็ก
ORDINAL = re.compile(r'(รุ่นที่|ครั้งที่|ประจำปี|ปีการศึกษา|ปี\s*[\d๐-๙]|พ\.ศ\.|ค\.ศ\.|(?<![\d,.])(25|20)\d\d(?![\d,]))')
NATURAL = ('ปีการศึกษา', 'ประจำ', 'ครั้งที่', 'วันที่', 'ระหว่าง', 'ณ ', 'เดือน', 'สำหรับ', 'โรงเรียน')
def _nat(ws, k):
    """จุดแบ่งท้ายชื่อเรื่องลงหัวรองที่เป็นธรรมชาติ: หลังเว้นวรรค / ก่อนตัวเลข ปี วันที่ / ก่อนคำขึ้นต้นท่อนท้าย (ปีการศึกษา ประจำ ...) ไม่ตัดกลางคำ"""
    if k <= 0 or k >= len(ws) or not ws[k].strip() or not _okcut(ws, k): return False
    p, n = ws[k - 1], ws[k]
    return not p.strip() or bool(re.match(r'[\d๐-๙]', n)) or n.startswith(NATURAL)

_NEAR = {}
def _sub_near(nm, d, M):
    """หัวรองอยู่ในพื้นที่เดียวกับชื่อเรื่อง (ใต้ชื่อ ชิดซ้ายแนวเดียวกัน ห่างไม่เกิน 1.2 นิ้ว เช่น nichebrand st_cover) ไม่ใช่กล่องคนละที่ (แถบรูปของ cafeloyalty)"""
    if nm in _NEAR: return _NEAR[nm]
    _NEAR[nm] = False
    if 's' not in d: return False
    two = 't1' in d and 't2' in d
    eng.setpal(M['pal'], M.get('font', 'plex'), M.get('head')); eng.setvar(0)
    prs = base.deck(); real = base._prep; base._prep = lambda path, mode=None: (_DOT, (4, 3))
    mk_ = {**d, **({'t1': 'QQTA', 't2': 'QQTB'} if two else {'t': 'QQTA'}), 's': 'QQSU'}
    try: lay_cov3.TTL2.clear(); lay.L[nm](prs, {'topic': M.get('topic', 'office'), 'foot': '', 'n': '01', **mk_})
    except Exception: return False
    finally: base._prep = real; lay_cov3.TTL2.clear()
    box = {sh.text_frame.text.strip(): sh for sh in prs.slides[-1].shapes if sh.has_text_frame and sh.text_frame.text.strip().startswith('QQ')}
    t = box.get('QQTB') or box.get('QQTA'); su = box.get('QQSU')
    if t is not None and su is not None:
        gap = (su.top - (t.top + t.height)) / 914400; dl = abs(su.left - (box.get('QQTA') or t).left) / 914400
        _NEAR[nm] = -0.1 <= gap <= 1.2 and dl <= 0.5
    return _NEAR[nm]

def _cover_fit(nm, d, c, M):
    """ปก: บันไดขนาด (ขนาดดีไซน์, 52, 48, 44, 40 / ชื่อยาวกว่า 60 ตัว ต่อ 36, 32) ลองชื่อบรรทัดเดียว แล้วแบ่ง 2-3 บรรทัด (layout ที่แยกกล่อง t1/t2 = บรรทัดละกล่อง) ก่อนย่อขั้นถัดไป
    แต่ละขนาดลองแบ่งที่เว้นวรรคก่อนรอยต่อคำ ไม่หักคำผสม (_breaks) ไม่พอดี = None ให้ตัวจัดลองปกแบบอื่น  c['_small'] = รอบสอง 36-24"""
    two = 't1' in d and 't2' in d
    full = ' '.join(str(d.get(k, '')).strip() for k in ('t1', 't2') if str(d.get(k, '')).strip()) if two else str(d.get('t', ''))
    if not full.strip(): return None
    ws = wordsx(full.replace('\n', ' '))
    sizes = [36, 32, 28, 24] if c.get('_small') else [None, 52, 48, 44, 40] + ([36, 32] if len(full) > 60 else [])   # _small = รอบสองหลังลองทุกปกแล้ว
    def variants():                                            # ทุกขนาด: บรรทัดเดียว > 2 บรรทัด (แบ่งที่เว้นวรรคก่อน แล้วรอยต่อคำ) > 3 บรรทัด
        if two:
            yield {'t1': full, 't2': ''}
            for sp in (True, False):
                for p in _breaks(ws, 2, 2, sp): yield {'t1': p[0], 't2': p[1]}
        else:
            yield {'t': full}
            if own[0]: return                                  # layout ตัดบรรทัดชื่อเองเป็นกล่องละบรรทัด (ttl2): ไม่แทรกขึ้นบรรทัด สไตล์บรรทัดจะเพี้ยน
            for n in (2, 3):
                for sp in (True, False):
                    for p in _breaks(ws, n, 2 if n == 2 else 1, sp): yield {'t': '\n'.join(p)}
    lay_cov3.TTL2.clear(); overflow(nm, d, M); own = [bool(lay_cov3.TTL2)]; lay_cov3.TTL2.clear()
    if not c.get('_small') and not str(d.get('s', '')).strip() and _sub_near(nm, d, M):
        # ไอซ์ 30 ต.ค. "ชอบแบบเก่ามากกว่าครับ": หัวรองอยู่ในกรอบเดียวกับชื่อ = คงขนาดดีไซน์ (ถึง 48pt) แบบสองบรรทัดหนา/บาง ท้ายชื่อลงหัวรองได้ที่จุดแบ่งธรรมชาติเท่านั้น
        cuts = [k for k in range(len(ws) - 1, 0, -1) if _nat(ws, k) and len(''.join(ws[:k]).strip()) >= 8 and not ORDINAL.search(''.join(ws[k:]))]
        for z in (None, 52, 48):
            sz = {'tsz': z, '_tz': 1} if z else {}
            base_ = {k: x for k, x in d.items() if k != '_tz' and not (z and k == 'tsz')}
            heads = [(full, '')] + [(''.join(ws[:k]).strip(), ''.join(ws[k:]).strip()) for k in cuts]
            for head, tail in heads:
                hw = wordsx(head)
                vs = ([{'t1': p[0], 't2': p[1]} for sp in (True, False) for p in _breaks(hw, 2, 2, sp)] + [{'t1': head, 't2': ''}]) if two else [{'t': head}]
                for v in vs:
                    d2 = {**base_, **v, 's': tail, **sz}
                    if not overflow(nm, d2, M): return d2
    for z in sizes:
        sz = {'tsz': z, '_tz': 1} if z else {}
        for v in variants():
            d2 = {**{k: x for k, x in d.items() if k != '_tz' and not (z and k == 'tsz')}, **v, **sz}
            if not overflow(nm, d2, M): return d2
    return None

def try_one(nm, ex, slots, c, M):
    """คืน (dict, ปัญหา)  dict=None ถ้าใส่ไม่ได้"""
    d = fill(nm, ex, slots, c)
    if d is None: return None, 'โครงไม่ตรง'
    if c['kind'] == 'agenda' and slots and slots != (str,) and c.get('items') and all(len(x) == 1 for x in c['items']) and sum(t is str for t in slots) > 1 \
            and not c.get('_slot') and overflow(nm, d, M, card=True):    # ข้อเดียวต่อแถวลงช่องแรกไม่ได้ ลองช่องที่สอง
        d2, bad2 = try_one(nm, ex, slots, dict(c, _slot=1), M)
        if d2 is not None: return d2, ''
    if c['kind'] == 'cover':
        d = _cover_fit(nm, d, c, M) or d
    if c['kind'] == 'cover' and c.get('_spill') and overflow(nm, d, M, card=True) and d.get('t') and 's' in d and not d.get('s'):
        # หัวเรื่องปกยาวเกิน (layout ไม่มีย่อตัว): ส่วนท้ายของชื่อเรื่องลงหัวรองบนปก ตัดที่รอยต่อคำ คำครบ
        ws = wordsx(d['t'])
        for k in range(len(ws) - 1, 0, -1):
            a_, b_ = ''.join(ws[:k]).strip(), ''.join(ws[k:]).strip()
            if len(a_) < 12 or cont(b_) or (wordsx(a_) or [''])[-1].strip() in TAIL or ORDINAL.search(b_): continue   # รุ่น/ครั้ง/ปี ไม่ลงหัวรอง
            d2 = dict(d, t=a_, s=b_)
            if not overflow(nm, d2, M, card=True): d = d2; break
    bad = overflow(nm, d, M, card=True)
    return (None, bad[0]) if bad else (d, '')

def one(c, xs):
    """ข้อที่แบ่งออกมา  เหลือข้อเดียว → ลองหน้าที่มีหัวเรื่องจริงก่อน (หัวข้อตัวใหญ่ รายละเอียดเป็นเนื้อ) แล้วค่อยลงหน้าข้อความเด่น"""
    if len(xs) > 1 or c['kind'] not in ('list', 'pairs', 'qa', 'timeline') or (c.get('t') and not c.get('_one')):
        return dict(c, items=xs, _one=1) if len(xs) == 1 else dict(c, items=xs)
    x = xs[0]
    if c.get('t') and c.get('_one') == 2 and c['kind'] != 'qa':   # หัวข้อตัวใหญ่ + รายละเอียดเป็นข้อความรอง (หน้าคั่น/ข้อความเด่น)
        return dict(kind='divider', t=c['t'], s=(' ' if c.get('_tbl') else ': ').join(x), num='', _hd=x, _tbl=c.get('_tbl'), _sec=c.get('_sec'))
    if c['kind'] == 'qa': return dict(kind='statement', t=x[1], s=x[0])
    return dict(kind='statement', t=(' ' if c.get('_tbl') else ': ').join(x), s=c['t'])   # คืนเครื่องหมาย : ให้ตรงต้นฉบับ (คู่จากตารางไม่มี :)

def plan(want, slug, on_step=None):
    """เลือก layout ทีละแผ่น  คืน (META, [dict(c, layout, d)], log)"""
    it = plan_iter(want, slug)
    try:
        while True:
            st = next(it)
            if on_step: on_step(*st)
    except StopIteration as e:
        return e.value

def plan_iter(want, slug):
    """เหมือน plan แต่ yield (เสร็จ, ทั้งหมด, ชื่อ layout ล่าสุด) ทุกแผ่น ให้เว็บวาดความคืบหน้าระหว่างคิด
    (Pyodide รันบนเธรดหน้าเว็บ ถ้าไม่หยุดเป็นช่วง ๆ จอจะค้างจนเสร็จ)"""
    global PLANBIG
    want_in = list(want)
    M, pool = pool_of(slug)
    PLANBIG = max([c.get('_big') or 0 for c in want] + [0])   # ใบ 037 ทั้งเด็คประกอบการพูด: ทุกการลองระหว่างจัด (แผ่นลูกที่ยังไม่มีคีย์) วัดที่ขนาดเดียวกัน
    want = [c for c in want if not c.get('_off')]; out, log, used = [], [], {}   # _off = สารบัญที่ลูกค้ายังไม่ได้กดใส่
    want0, rescued, capped, rnd = list(want), False, False, 0
    last = None; steps = 0
    _pn = None; _pb = None; _pnb = None; _n0 = 0; orphan = []; r0 = None; bef = set()                       # ใบ 037: โน้ตของแผ่นที่ตัวจัดแตก/เปลี่ยนชนิด ไปอยู่กับแผ่นลูกแผ่นแรก (ไม่ซ้ำทุกแผ่น ไม่หาย)
    while want or not rescued:
        steps += 1
        if _pn is not None or _pb or _pnb:                 # _big (ตัวหนังสือ >= 18pt) / _nobig ตามไปทุกแผ่นลูก
            k_ = len(want) - _n0
            for j_ in range(max(k_, 0)):
                x_ = {kk: v for kk, v in want[j_].items() if kk != '_note' or _pn is None}
                if _pn is not None and j_ == 0: x_['_note'] = _pn
                if _pb: x_['_big'] = _pb
                if _pnb: x_['_nobig'] = 1
                want[j_] = x_
            if k_ <= 0 and _pn is not None: orphan.append(_pn)
            _pn = None; _pb = None; _pnb = None
        if (steps > 300 + 60 * len(want0) or len(out) >= MAXSLIDES) and PLANBIG and len(want_in) <= MAXSLIDES // 2 and not all(c.get('_nobig') for c in want_in if c.get('kind') != 'cover'):
            # เฟส C: ประกอบการพูด (18pt) แบ่งหน้าจนชนเพดานหน้า/รอบ = คำจะหาย → จัดใหม่ทั้งเด็คที่ขนาดของดีไซน์ (ข้อยาวไปโน้ตยังอยู่) คำครบสำคัญกว่าขนาด
            # ponytail: เอกสารสั้น (ไม่เกินครึ่งเพดาน) เท่านั้น เอกสารยาวจริง (40 หัวข้อ) ชนเพดานทุกโหมด คงตัวใหญ่ไว้
            return (yield from plan_iter([dict(c, _nobig=1) for c in want_in], slug))
        if steps > 300 + 60 * len(want0):                  # กันวนไม่จบ: หยุด แล้วให้ตัวตรวจคำที่หายบอกลูกค้า
            want = []; rescued = True; break
        if not want:                                       # จบรอบ: ตรวจว่าทุกคำของลูกค้าอยู่ในสไลด์จริง ขาดตรงไหนเติมเป็นรายการ (สองรอบ)
            if capped: rescued = True; break
            want = rescue(want0, out, M, rnd); rnd += 1; rescued = rnd >= 2
            if want and r0 is None: r0 = len(out)          # หน้าที่ต่อจากนี้ = หน้าเติมคำกลับ (ตัวจัดอาจแตกเป็นชนิดอื่น ธงในแผ่นไม่ตามไป)
            bef |= {x.get('_sec') for x in want if x.get('_before')}
            if want: log.append((dict(kind='list', t=''), None, [], f'เติมข้อความที่ยังไม่อยู่ในสไลด์ {len(want)} หน้า'))
            continue
        if len(out) >= MAXSLIDES:                          # เพดานทุกทาง (หน้าที่แบ่งเพิ่มระหว่างจัดก็นับ) หยุดจัดทันที บอกลูกค้าตรง ๆ
            if not any(n.startswith('เอกสารยาว') for n in NOTES): NOTES.append(f'เอกสารยาว ทำเป็นสไลด์ได้สูงสุด {MAXSLIDES} หน้า ส่วนที่เหลือยังไม่ได้ทำเป็นสไลด์')
            capped = True; want = []; rescued = True; break
        yield (len(out), min(len(out) + len(want), MAXSLIDES), out[-1]['layout'] if out else '')
        c = want.pop(0); _n0 = len(want); _pn = c.get('_note'); _pb = c.get('_big'); _pnb = c.get('_nobig')
        if '_sec' not in c and last is not None: c = dict(c, _sec=last)   # หน้าที่แบ่ง/เปลี่ยนชนิดออกมา อยู่หัวข้อเดิม
        last = c.get('_sec', last)
        cand = candidates(c, pool, used)
        why, got = [], None
        for sc, nm, ex, slots in cand:
            d, bad = try_one(nm, ex, slots, c, M)
            if d is None: why.append(f'{nm} ไม่ผ่าน: {bad}'); continue
            got = (nm, d); break
        if not got and c['kind'] in ('list', 'pairs', 'statement', 'divider', 'stat', 'timeline', 'qa') and len(c.get('items') or []) <= 5:
            for z in (0.85, 0.72):                        # ตัวเต็มใส่ไม่ได้ทุกหน้าตา: ย่อตัวหนังสือก่อน (ไม่ต่ำกว่า 10.5pt) ดีกว่าตัดกลางความ
                got = next(((nm, d) for _, nm, ex, slots in cand for d, _b in [try_one(nm, ex, slots, dict(c, _bsz=z), M)] if d is not None), None)
                if got:
                    why.append(f'ย่อตัวหนังสือ {z}')
                    if SMALLNOTE not in NOTES: NOTES.append(SMALLNOTE)   # ย่อเมื่อไหร่บอกในฟองจบ   # ย่อมาก (ไม่ใช่ย่อนิดหน่อย) ถึงบอกในฟองจบ
                    break
        if got and got[1].get('bsz') and SMALLNOTE not in NOTES: NOTES.append(SMALLNOTE)   # หน้าที่ย่อมาแล้วตั้งแต่ตอนแพ็ก (_bsz) ก็ต้องบอกในฟองจบ (ใบ 021)
        if not got and c['kind'] == 'cover':               # ทุกปกไม่พอดีที่ 40pt (ชื่อยาว 32pt): ปกกล่องชื่อเล็กจริงย่อถึง 28-24 ก่อนแบ่งชื่อไปหัวรอง
            got = next(((nm, d) for _, nm, ex, slots in cand for d, _b in [try_one(nm, ex, slots, dict(c, _small=1), M)] if d is not None), None)
            if got: why.append('ชื่อเรื่องปกย่อต่ำกว่า 32pt')
        if not got and c['kind'] == 'cover':               # ชื่อเรื่องแยกไปกล่องหัวรอง (คนละที่บนปก อ่านแล้วขาดกลางประโยค) = ทางสุดท้าย หลังลองทุกแบบปกที่ใส่ชื่อครบในกล่องเดียวแล้ว
            got = next(((nm, d) for _, nm, ex, slots in cand for d, _b in [try_one(nm, ex, slots, dict(c, _spill=1), M)] if d is not None), None)
            if got: why.append('ชื่อเรื่องยาว ส่วนท้ายลงหัวรอง')
        if not got and c['kind'] == 'cover' and cand:      # ปกต้องมีเสมอ ล้นก็ใส่แล้วฟ้องให้คนแก้ชื่อ
            d = fill(cand[0][1], cand[0][2], cand[0][3], c)
            if d is not None: got = (cand[0][1], d); why.append('ใส่ปกทั้งที่ไม่ผ่าน')
        if not got and c['kind'] == 'stat' and c.get('raw'):  # ชุดนี้ไม่มีการ์ดตัวเลขที่รับได้ → ลงเป็นรายการ ข้อความเดิม
            want.insert(0, dict(kind='list', t=c['t'], note=c.get('note', ''), items=[(x,) for x in c['raw']], **{k: 1 for k in ('_lead', '_leadend') if c.get(k)}))
            log.append((c, None, why[-3:], 'ลงเป็นรายการแทน')); continue
        if not got and c.get('_lead') and c['kind'] in ('list', 'pairs'):   # ไม่มีหน้าตาที่วางยอดรวมนำได้: กลับเป็นข้อแรกตามเดิม (ไม่ทิ้งเป็นหน้าเดี่ยว)
            base = {k: v for k, v in c.items() if k != '_lead'}
            pad = lambda x: [(x,) + ('',) * (len(c['items'][0]) - 1)]
            base.update(note='', items=(list(c['items']) + pad(c['note'])) if c.get('_leadend') else (pad(c['note']) + list(c['items'])))
            want.insert(0, base); log.append((c, None, why[-3:], 'ยอดรวมกลับเป็นข้อแรก')); continue
        n_rw = len(c.get('rows') or [])
        if not got and n_rw > 2 and c['kind'] in ('table', 'chart') and any(p[2] in ('table', 'chart') for p in pool):   # ตารางยาวเกินที่ชุดนี้วาดได้ → แบ่งครึ่ง หัวตารางซ้ำ
            def cut(a, b):
                x = {k: v for k, v in c.items() if k != '_share'}   # ครึ่งหนึ่งของสัดส่วนไม่ใช่ทั้งก้อนแล้ว
                x['rows'] = c['rows'][a:b]
                if 'cats' in c:
                    x.update(cats=c['cats'][a:b], series=[(n, v[a:b]) for n, v in c['series']], _nf=[f[a:b] for f in c['_nf']])
                    if 'vals' in c: x['vals'] = c['vals'][a:b]
                return x
            # แถวที่หน้าเดียวรับได้จริง แล้วแบ่งเท่า ๆ กัน (ไม่เหลือหน้าแถวเดียวถ้าแบ่งให้สมดุลได้)
            fitk = next((k for k in range(n_rw - 1, 1, -1) if any(try_one(nm, ex, sl, cut(0, k), M)[0] is not None for _, nm, ex, sl in candidates(cut(0, k), pool, used))), 2)
            pages_ = -(-n_rw // fitk); per = -(-n_rw // pages_)
            want[:0] = [cut(a, min(a + per, n_rw)) for a in range(0, n_rw, per)]
            log.append((c, None, why[-3:], f'แบ่งตารางเป็น {pages_} หน้า หน้าละ {per} แถว')); continue
        if not got and c['kind'] in ('chart', 'table') and len(c['head']) >= 2:   # ไม่มีตาราง/กราฟ → คู่ ช่องแรก: ที่เหลือ
            hd = c['head']                                 # หลายคอลัมน์: ใส่ชื่อคอลัมน์ของลูกค้าหน้าค่า ไม่ให้ตัวเลขติดกันอ่านไม่ออก
            head_pair = [(hd[0], ' '.join(hd[1:]))] if len(hd) <= 2 and any(hd) else []   # สองคอลัมน์: หัวตารางเป็นคู่แรก ไม่ทิ้งชื่อคอลัมน์
            rows = [(r[0], (' '.join(x for x in r[1:] if x) if len(hd) <= 2 else
                            ' '.join(f'{h} {x}' for h, x in zip(hd[1:], r[1:]) if x))) for r in c['rows']]   # เว้นวรรคอย่างเดียว ไม่เติมเครื่องหมาย
            rows = head_pair + rows
            want[:0] = [dict(kind='pairs', t=c['t'], note=c.get('note', ''), items=part, _tbl=1) for part in chunk(rows)]
            log.append((c, None, why[-3:], 'ลงเป็นคู่หัว-ค่าแทน')); continue
        n_it = len(c.get('items') or [])
        if not got and c['kind'] == 'list' and (not c.get('t') or len(c['items']) <= 2) and not c.get('_cl') and not c.get('_fb') and not c.get('_pk') \
                and any(len(x[0]) > 40 for x in c['items']):
            # ย่อหน้ายาวที่ไม่มีหัวข้อ ในชุดที่กล่องรายการเล็ก: รวมหลายข้อติดกันลงช่องข้อความยาวของหน้าข้อความเด่น
            # (ข้อความเต็มประโยค ไม่ตัดกลางความ หน้าละหลายข้อ ไม่ใช่หน้าละท่อนสั้น ๆ)
            its, i, packs, T = [x[0] for x in c['items']], 0, [], c.get('t') or ''
            m_ = []                                        # ข้อสั้น ๆ (ป.4 288) ต่อกับข้อถัดไปในบรรทัดเดียว ไม่ยืนเดี่ยวเป็นหน้า
            for x in its:
                if m_ and (len(m_[-1]) < 12 or len(x) < 12) and len(m_[-1]) + len(x) < 80: m_[-1] += '  ' + x
                else: m_.append(x)
            its = m_
            fits = lambda c_: any(try_one(nm, ex, sl, c_, M)[0] is not None for _, nm, ex, sl in candidates(c_, pool, used))
            fitsz = lambda c_: fits(c_) or fits(dict(c_, _bsz=0.85)) or fits(dict(c_, _bsz=0.72))
            # มีหัวข้อ: หัวข้อตัวใหญ่ + ข้อเป็นข้อความรอง (หน้าคั่น) ก่อน แล้วค่อยหัวข้อกับข้อรวมกันในช่องข้อความรอง (ทุกหน้ามีชื่อหัวข้อ)
            big_of = (lambda j_: dict(kind='divider', t=T, s=j_, num='', _pk=1)) if T else (lambda j_: dict(kind='statement', t=j_, _pk=1))
            small_of = (lambda j_: dict(kind='statement', t='', s=T + '\n' + j_, _pk=1)) if T else (lambda j_: dict(kind='statement', t='', s=j_, _pk=1))
            m_ = []                                        # หน้าไม่ขึ้นต้นด้วย "แต่": ข้อที่ขึ้นด้วยแต่ ต่อท้ายข้อก่อน ถ้ารวมแล้วยังลงหน้าเดียวได้
            for x in its:
                if m_ and x.startswith('แต่') and len(m_[-1]) + len(x) < 300 and fitsz(small_of(m_[-1] + ' ' + x)): m_[-1] += ' ' + x
                else: m_.append(x)
            its = m_
            k_ok = lambda kg: 2 <= kg <= 5 and fits(dict(kind='list', t=T, ordered=False, note='', items=[(x,) for x in its[i:i + kg]], _pk=1))
            while i < len(its):
                # ข้อความเด่นตัวใหญ่ (ช่อง t) ก่อน ช่องหัวรองตัวเล็ก (s) เฉพาะเมื่อตัวใหญ่ใส่ไม่ได้
                k, big = 0, True
                gs = groups(its)                           # จบหน้าที่รอยต่อเรื่องก่อน (ไม่ปนผลสอบกับมติ)
                ks = sorted(range(len(its) - i, 0, -1), key=lambda k_: (not (i + k_ == len(its) or gs[i + k_] != gs[i + k_ - 1]), -k_))
                g0 = i == 0 or gs[i] != gs[i - 1]          # หน้านี้เริ่มต้นเรื่อง
                whole = lambda k_: g0 and (i + k_ == len(its) or gs[i + k_] != gs[i + k_ - 1])
                for k_ in ks:
                    j_ = '\n'.join(its[i:i + k_])
                    if len(j_) > (300 if whole(k_) or '\n' not in j_ else 170) and not (k_ == 1 and len(j_) <= 300): continue   # หน้าละไม่เกิน ~170 ตัว อ่านได้ ยกเว้นเรื่องเดียวทั้งก้อน (ยอดรวม+ส่วนย่อย+ใช้จริง) ให้อยู่หน้าเดียวกัน
                    if fits(big_of(j_)): k, big = k_, True; break
                    if k_ > 1 and (fits(small_of(j_)) or (whole(k_) and fitsz(small_of(j_)))): k, big = k_, False; break   # ทั้งเรื่องในตัวเล็ก (ย่อได้ถึง 10.5pt) ดีกว่าแยกเรื่องเป็นตัวใหญ่สองหน้า
                if not k:
                    k = next((k_ for k_ in ks if len('\n'.join(its[i:i + k_])) <= (260 if whole(k_) else 170) and fits(small_of('\n'.join(its[i:i + k_])))), 0); big = False
                if not k and fitsz(big_of(its[i])): k, big = 1, True      # ข้อเดียวทั้งข้อ ย่อตัวหนังสือ ดีกว่าตัดกลางความ
                elif not k and fitsz(small_of(its[i])): k, big = 1, False
                if not k and len(its[i]) <= 300 and (re.search(r' (ได้แก่|ดังนี้|คือ) ', its[i]) or ('แบ่งเป็น' in its[i] and len(re.findall(r'\d[\d,]*\s*บาท', its[i])) >= 3)):
                    # ก้อนที่ points() ตั้งใจไม่แบ่ง (รายการ ได้แก่... / ยอดรวม+ส่วนย่อย) ห้ามแยกหน้า: ชุดที่ไม่มีช่องข้อความยาวพอ (ใบ 021 creativeclass/startupseed)
                    # ลงเป็นรายการหน้าเดียว ข้อละท่อนความ (ข้อยาวน้อยข้อก่อน แล้วค่อยข้อสั้นหลายข้อ) ย่อตัวได้ถึง 72%
                    lst = next((x_ for sub in (pieces(clauses(its[i]), lo=25, hi=60), clauses(its[i])) if len(sub) >= 2 for bz in (None, 0.85, 0.72)
                                for x_ in [dict(kind='list', t=T, ordered=False, note='', items=[(x,) for x in sub], _pk=1, **({'_bsz': bz} if bz else {}))] if fits(x_)), None)
                    if lst: lst['_sec'] = c.get('_sec')
                    if lst: packs.append(lst); i += 1; continue
                if not k:                                  # ข้อนี้ยาวเกินทุกช่อง: แตกที่รอยต่อความแล้วลองต่อ
                    sub = pieces(clauses(its[i]), lo=25, hi=60)
                    if len(sub) < 2: break
                    its[i:i + 1] = sub; continue
                kg = next((k_ for k_ in range(1, len(its) - i + 1) if whole(k_)), 0)
                if g0 and k < kg and k_ok(kg):             # เรื่องเดียวทั้งก้อนใส่หน้าข้อความไม่พอ: ลงเป็นรายการหน้าเดียวทั้งก้อน ไม่แยกยอดรวมกับส่วนย่อย
                    packs.append(dict(kind='list', t=T, ordered=False, note='', items=[(x,) for x in its[i:i + kg]], _pk=1, _sec=c.get('_sec'))); i += kg; continue
                j_ = '\n'.join(its[i:i + k])   # ข้อละบรรทัด ตัวเลขสองเรื่องไม่อยู่บรรทัดเดียวกัน
                packs.append(dict(big_of(j_) if big else small_of(j_), _sec=c.get('_sec'), _j=j_, _n=k)); i += k
            q = 0
            while q < len(packs) - 1:                      # หน้าข้อเดียวต่อกับหน้าถัดไปถ้ารวมกันยังใส่ได้ (ไม่มีหน้าโล่งทีละข้อ)
                a_, b_ = packs[q], packs[q + 1]
                if '_j' in a_ and '_j' in b_ and min(a_['_n'], b_['_n']) == 1 and len(a_['_j']) + len(b_['_j']) + 1 <= 170 \
                        and fits(small_of(a_['_j'] + '\n' + b_['_j'])):
                    j2 = a_['_j'] + '\n' + b_['_j']; packs[q:q + 2] = [dict(small_of(j2), _sec=c.get('_sec'), _j=j2, _n=a_['_n'] + b_['_n'])]; continue
                q += 1
            packs = [{k_: v for k_, v in x.items() if k_ not in ('_j', '_n')} for x in packs]
            if i == len(its):
                want[:0] = packs; log.append((c, None, why[-3:], f'รวม {len(its)} ข้อเป็น {len(packs)} หน้าข้อความ')); continue
        if not got and c['kind'] == 'list' and not c.get('_cl') and any(len(x[0]) > 60 for x in c['items']):
            # ข้อยาวเกินกล่องของชุดนี้: แตกเป็นความสั้นที่รอยต่อความ (ยังเป็นรายการเดียวกัน) ก่อนจะแบ่งเป็นหลายหน้า
            its = [(p_,) for x in c['items'] for p_ in pieces(clauses(x[0]), lo=25, hi=60)]
            if len(its) == len(c['items']) == 1:           # แตกไม่ได้ (ทั้งประโยคต่อกันด้วยคำเชื่อม): ไปทางแบ่งย่อหน้ายาวตามรอยต่อคำ
                want.insert(0, dict(c, _fb=1, _cl=1))
                log.append((c, None, why[-3:], 'ข้อยาวแบ่งตามรอยต่อคำ')); continue
            want[:0] = [dict(c, items=part, _cl=1) for part in chunk(its)]
            log.append((c, None, why[-3:], f'แตกข้อยาวเป็น {len(its)} ข้อสั้น')); continue
        if not got and n_it > 1 and c['kind'] == 'agenda' and n_it > 3:   # สารบัญยาวเกินที่ชุดนี้รับ: สองหน้า "สารบัญ" (ไม่ข้ามสารบัญ)
            h = -(-n_it // 2); sc = c.get('_secs') or [None] * n_it
            want[:0] = [dict(c, items=c['items'][:h], _secs=sc[:h], _part=1), dict(c, items=c['items'][h:], _secs=sc[h:], _part=2)]
            log.append((c, None, why[-3:], f'สารบัญแบ่งเป็น {h}+{n_it - h} ข้อ')); continue
        if not got and n_it > 1 and c['kind'] == 'list' and not c.get('_jn') and \
                ((any(len(x[0]) < 12 for x in c['items']) and n_it <= 3) or (all(len(x[0]) < 20 for x in c['items']) and n_it <= 8)):
            # แบ่งครึ่งแล้วจะเหลือข้อสั้น ๆ (ป.4 288) เป็นหัวเรื่องหน้าเดี่ยว: รวมทุกข้อเป็นข้อความเดียว ข้อละบรรทัด
            want.insert(0, dict(kind='statement', t='\n'.join(x[0] for x in c['items']), s=c.get('t', ''), _sec=c.get('_sec'), _jn=1))
            log.append((c, None, why[-3:], 'รวมข้อสั้นเป็นข้อความเดียว')); continue
        if not got and n_it > 2 and c['kind'] in ('list', 'pairs', 'qa', 'timeline') and not c.get('_gf'):
            # หาจำนวนข้อที่หน้าเดียวรับได้จริง แล้วแบ่งเท่า ๆ กัน (ไม่ใช่หน้าละข้อ)
            part_ = lambda a, b: dict(c, items=c['items'][a:b], _gf=1)
            fitk = next((k for k in range(n_it - 1, 1, -1) if any(try_one(nm, ex, sl, part_(0, k), M)[0] is not None for _, nm, ex, sl in candidates(part_(0, k), pool, used))), 0)
            T_ = c.get('t') or ''; j_ = '\n'.join(' '.join(x for x in it if x) for it in c['items'])
            if c['kind'] == 'list' and n_it <= 5 and len(j_) <= 260 and len(set(groups([x[0] for x in c['items']]))) == 1:
                st_ = dict(kind='statement', t='', s=(T_ + '\n' if T_ else '') + j_ if T_ else j_, _sec=c.get('_sec'), _jn=1)
                if any(try_one(nm, ex, sl, dict(st_, _bsz=z) if z else st_, M)[0] is not None for z in (None, 0.85, 0.72) for _, nm, ex, sl in candidates(st_, pool, used)):
                    want.insert(0, st_); log.append((c, None, why[-3:], 'เรื่องเดียวทั้งก้อนลงหน้าข้อความ ไม่แยกหน้าละข้อ')); continue
            if fitk:
                pages_ = -(-n_it // fitk); per = -(-n_it // pages_)
                cuts = [0]
                for q in range(pages_): cuts.append(cuts[-1] + n_it // pages_ + (q < n_it % pages_))   # 7 ข้อ 3 หน้า = 3+2+2 ไม่ใช่ 3+3+1
                want[:0] = [part_(a, b) for a, b in zip(cuts, cuts[1:])]
                log.append((c, None, why[-3:], f'แบ่งเป็น {pages_} หน้า หน้าละ {per} ข้อ')); continue
        if not got and n_it > 1 and c['kind'] != 'agenda':  # ห้ามทิ้งเนื้อลูกค้า แบ่งครึ่งแล้วลองใหม่
            h = -(-n_it // 2)
            want[:0] = [one(c, c['items'][:h]), one(c, c['items'][h:])]
            log.append((c, None, why[-3:], f'แบ่งเป็น {h}+{n_it - h} ข้อ')); continue
        if not got and n_it == 1 and c.get('_one') == 1 and c['kind'] in ('list', 'pairs', 'qa', 'timeline'):
            want.insert(0, one(dict(c, _one=2), c['items']))   # หน้ามีหัวเรื่องรับข้อเดียวไม่ได้ → หน้าข้อความเด่น
            log.append((c, None, why[-3:], 'ข้อเดียวลงหน้าข้อความเด่น')); continue
        if not got and c.get('_hd'):                       # หัวข้อ+รายละเอียดลงหน้าไหนไม่ได้ → ข้อความเด่นแบบเดิม
            want.insert(0, dict(kind='statement', t=(' ' if c.get('_tbl') else ': ').join(c['_hd']), s=c['t'], _sec=c.get('_sec')))
            log.append((c, None, why[-3:], 'ลงหน้าข้อความเด่น')); continue
        if not got and c['kind'] == 'compare':                  # ชุดนี้ไม่มีหน้าเปรียบเทียบ → รายการกลุ่มละหน้า
            want[:0] = [dict(kind='list', t=g[0], items=[(x,) for x in g[1]]) for g in c['items'] if g[1]]
            log.append((c, None, why[-3:], 'แยกเป็นรายการกลุ่มละหน้า')); continue
        if not got and c['kind'] == 'list' and c.get('_fb') and len(c['items']) == 1:   # ย่อหน้ายาวเกินทุกกรอบ
            txt = c['items'][0][0]
            cl = clauses(txt); acc = 0; sp = []                # ตัดที่รอยต่อความก่อน (ไม่ตัดกลางความ เช่นหน้า "ซึ่ง")
            for x in cl[:-1]: acc += len(x) + 1; sp.append(acc - 1)
            sp = [i for i in sp if not numunit(txt[:i], txt[i + 1:])]   # เฟส C: รอยต่อความระหว่างเลขกับหน่วย ("68.4 | เปอร์เซ็นต์") ไม่ใช่ที่ตัด
            if not sp:                                     # ไม่มีรอยต่อความ: เว้นวรรคที่ไม่แยกตัวเลขกับป้าย/หน่วย ไม่จบด้วยคำเชื่อม
                ok = lambda i: not re.search(r'\d', txt[i + 1:].split(' ')[0]) and not numunit(txt[:i], txt[i + 1:]) \
                    and not cont(txt[i + 1:].split(' ')[0]) \
                    and (words(txt[:i].split(' ')[-1]) or [''])[-1] not in TAIL
                allsp = [m.start() for m in re.finditer(' ', txt)]
                sp = [i for i in allsp if ok(i)]
                if not sp:                                 # ความต่อด้วย "และ/หรือ/แต่/ซึ่ง/โดย": ตัดหลังคำเชื่อม (ท่อนถัดไปไม่ขึ้นต้นด้วยคำเชื่อม)
                    for m in re.finditer(r' (และ|หรือ|แต่|ซึ่ง|โดย)(?=\S)', txt): sp.append(m.end())
                if not sp:                                 # ไม่มีเว้นวรรคที่ตัดได้: ตัดที่รอยต่อคำ แต่ไม่ตัดหน้าคำเชื่อม
                    acc = 0
                    for w_ in wordsx(txt)[:-1]:
                        acc += len(w_)
                        if txt[acc:acc + 1] != ' ' and not cont(txt[acc:].lstrip()) and w_.strip() not in TAIL \
                                and not numunit(txt[:acc], txt[acc:]) and not re.match(r'[\d' + '\u0E30-\u0E4E' + ']', txt[acc:acc + 1]): sp.append(acc)
                sp = sp or [i for i in allsp if not numunit(txt[:i], txt[i + 1:])]   # เฟส C: ทางสุดท้ายก็ไม่แยกเลขกับหน่วย
            if not sp and len(txt) > 40:                # ประโยคไทยไม่มีเว้นวรรค: ตัดที่รอยต่อคำ (ตัวตัดคำ ไม่ใช่ AI)
                acc = 0; sp = []
                for w_ in wordsx(txt)[:-1]: acc += len(w_); sp.append(acc)
            sp = [i_ for i_ in sp if 20 <= i_ <= len(txt) - 20] or [i_ for i_ in sp if 12 <= i_ <= len(txt) - 12]   # ไม่มีท่อนสั้นกว่า 12 ตัวเป็นหน้าเดี่ยว
            if sp and len(txt) > 40:                    # ตัดที่ช่องว่างใกล้กึ่งกลาง เป็นสองหน้าต่อกัน คำครบเหมือนเดิม
                cut = min(sp, key=lambda i: abs(i - len(txt) / 2))
                want[:0] = [dict(kind='statement', t=txt[:cut].strip(), s=c['t']), dict(kind='statement', t=txt[cut:].strip(), s=c['t'])]
                log.append((c, None, why[-3:], 'แบ่งย่อหน้ายาวเป็นสองหน้า')); continue
        if not got and c['kind'] == 'statement' and not c.get('_fb') and not c.get('_ts') and c.get('t'):   # ประโยคยาวเกินหน้าคำคม → ลองเป็นรายการข้อเดียว
            want.insert(0, dict(kind='list', t=c.get('s', ''), items=[(c['t'],)], _fb=1, _cl=1, _sec=c.get('_sec')))   # ไม่แตกซ้ำ (กันวน)
            log.append((c, None, why[-3:], 'ลองเป็นรายการ')); continue
        if not got and c['kind'] == 'list' and c.get('t') and len(c.get('items') or []) == 1 and not c.get('_ts'):
            # หัวข้อยาวเกินกล่องหัวเรื่องทุกแบบของชุดนี้: หัวข้อกับรายละเอียดลงช่องข้อความรองด้วยกัน หน้านี้ยังมีชื่อหัวข้อ
            want.insert(0, dict(kind='statement', t='', s=c['t'] + ' ' + c['items'][0][0], _ts=1, _sec=c.get('_sec')))
            log.append((c, None, why[-3:], 'หัวข้อกับรายละเอียดลงช่องข้อความรอง')); continue
        if not got:
            log.append((c, None, why, 'ไม่มี layout ในชุดนี้รับได้ ข้ามแผ่นนี้')); continue
        used[got[0]] = used.get(got[0], 0) + 1; _pn = None; _pb = None; _pnb = None
        out.append(dict(c=c, layout=got[0], d=got[1])); log.append((c, got[0], why, ''))
    PLANBIG = 0
    resc = out[r0:] if r0 is not None else []
    last_ = {}
    for n_, x in enumerate(resc):                          # ใบ 045: หน้าที่เติมคำกลับ อยู่ในหัวข้อเดิม ไม่ใช่ท้ายเด็ค (หลังคำลงท้าย "ขอแสดงความนับถือ")
        sec = x['c'].get('_sec'); del out[next(i for i, y in enumerate(out) if y is x)]   # ตามตัวตน (remove เทียบค่า หน้าที่เหมือนกันทุกอย่างหลุดผิดหน้า)
        if sec in last_ and any(y is last_[sec] for y in out):                                   # เฟส C: หน้าเติมคำถัดไปของหัวข้อเดียวกัน ต่อจากหน้าเติมคำก่อนหน้า (เดิมนับหน้าที่ยังรอวางท้ายเด็คเป็นหัวข้อเดียวกัน ไปต่อท้ายคำลงท้าย)
            k_ = next(i for i, y in enumerate(out) if y is last_[sec]); out.insert(k_ + 1, x); last_[sec] = x; continue
        pend = resc[n_ + 1:]
        same = [i for i, y in enumerate(out) if y['c'].get('_sec') == sec and y['c'].get('kind') != 'cover' and not any(y is z for z in pend)]
        if not same: out.append(x); continue
        own = [i for i in same if not any(out[i] is z for z in resc)] or same
        out.insert(own[0] if sec in bef else same[-1] + 1, x); last_[sec] = x
        bef.discard(sec)                                   # ponytail: หน้าเติมคำหลายหน้าของหัวข้อเดียว: หน้าแรกขึ้นหน้า ที่เหลือต่อกัน
    if _pn is not None: orphan.append(_pn)
    if orphan and out:                                     # แผ่นที่ข้ามไป: โน้ตต่อท้ายหน้าสุดท้าย คำไม่หาย
        d_ = out[-1]['d']; d_['_note'] = '\n'.join(([d_['_note']] if d_.get('_note') else []) + orphan)
    if not capped:
        gone = missing_words(want0, out, M)
        if gone: NOTES.append('ข้อความบางส่วนใส่ในหน้าตานี้ไม่ได้: ' + ' '.join(gone[:8]) + (' …' if len(gone) > 8 else '') + ' ลองหน้าตาอื่น')
    return M, out, log

def _toks(v):
    """คำของลูกค้า (แยกตามเว้นวรรค) จากเนื้อหาหนึ่งชิ้น ไม่รวมคีย์ภายใน/ตัวเลขกราฟ"""
    if isinstance(v, dict):                                # การ์ดตัวเลข: ใช้ข้อความเต็มของลูกค้า (raw) ไม่ใช่ค่าที่แยกแล้ว
        skip = ('kind', 'vals', 'series', 'num', 'ordered') + (('items',) if v.get('raw') else ('raw',))
        return [t for k, x in v.items() if not k.startswith('_') and k not in skip for t in _toks(x)]
    if isinstance(v, (list, tuple)): return [t for x in v for t in _toks(x)]
    if isinstance(v, str): return [w for w in v.split() if re.search(r'[A-Za-z0-9\u0E01-\u0E2E\u0E50-\u0E59]', w) and not re.fullmatch(r'[\d\u0E50-\u0E59]{1,2}[.)]', w)]   # เลขข้อ "1." ไม่นับ
    return []

def _pagetxt(x, M):
    """ข้อความที่วาดจริงของหน้าหนึ่ง (วาดด้วยตัววัดเดียวกับตอนเลือก layout จำผลไว้)"""
    if '_txt' not in x:
        eng.setpal(M['pal'], M.get('font', 'plex'), M.get('head')); eng.setvar(0)
        prs = base.deck(); real = base._prep; base._prep = lambda path, mode=None: (_DOT, (4, 3))
        try:
            lay.L[x['layout']](prs, {'topic': M.get('topic', 'office'), 'foot': '', 'n': '01', **x['d']})
            if x['d'].get('_nf'): numfmt(prs.slides[-1], x['d']['_nf'], x['d'].get('_sn'))
            head_a1(prs.slides[-1], x['d'])
            scrub(prs.slides[-1], list(strings(x['d']))); x['_txt'] = slide_text(prs.slides[-1])
        except Exception: x['_txt'] = ''
        finally: base._prep = real
    return x['_txt']

def _in(w, allt):
    """คำนี้อยู่ในสไลด์ไหม (คำไทยยาวที่ไม่มีเว้นวรรคอาจถูกแบ่งข้ามหน้า: ดูทีละคำย่อยแทน)"""
    w = ''.join(w.split()).lower()
    return w in allt or all(x.strip().lower() in allt for x in wordsx(w) if len(x.strip()) > 1)

def missing_words(want0, out, M):
    """คำของลูกค้าที่ไม่อยู่ในสไลด์ที่วาดจริงเลย (ห้ามทิ้งเนื้อหา)"""
    allt = ''.join(_pagetxt(x, M) + _nosp(x['d'].get('_note') or '').lower() for x in out)   # เฟส C: คำที่ไปอยู่โน้ตผู้บรรยาย (โหมดประกอบการพูด) ไม่หาย ไม่ต้องเติมกลับ
    return [w for c in want0 if c['kind'] != 'agenda' for w in _toks(c) if not _in(w, allt)]

def rescue(want0, out, M, rnd=0):
    """ชิ้นเนื้อหาที่มีคำหายจากสไลด์ → เติมเป็นรายการธรรมดา (หัวข้อเดิม ข้อละบรรทัด) ให้จัดอีกรอบ ไม่ปล่อยให้เนื้อหาหายเงียบ"""
    allt = ''.join(_pagetxt(x, M) + _nosp(x['d'].get('_note') or '').lower() for x in out)   # เฟส C: คำที่ไปอยู่โน้ตผู้บรรยาย (โหมดประกอบการพูด) ไม่หาย ไม่ต้องเติมกลับ
    has = lambda x: all(_in(w, allt) for w in _toks(x))
    fix = []
    for c in want0:
        if c['kind'] == 'agenda' or has(c): continue
        keys = {k: v for k, v in c.items() if not k.startswith('_') and k not in ('kind', 'raw', 'vals', 'series', 'num', 'ordered', 't')}
        lines = [x for x in strings(keys) if x.strip() and not has(x)]
        t = c.get('t') or ''
        if t and not has(t): lines = [t] + lines; t = ''     # หัวข้อเองหาย: ใส่เป็นข้อแรก
        if rnd:                                            # รอบสอง (ยังหาย): ท่อนสั้นลงตามรอยต่อคำ ไม่มีหัวข้อ ให้กล่องเล็กที่สุดของชุดรับได้
            lines = [y for x in lines for y in _wsplit(x, 36)]; t = ''
        lead = bool(c.get('note')) and not c.get('_leadend') and all(x in c['note'] for x in lines)   # ข้อความนำของรายการ (…ดังนี้) ที่หาย: กลับไปอยู่หน้ารายการ
        for part in chunk(lines):
            fix.append(dict(kind='list', t=t, ordered=False, note='', items=[(x,) for x in part], _sec=c.get('_sec'), _rescue=1, **({'_before': 1} if lead else {}),
                            **({'_nobig': 1} if rnd else {})))   # รอบสุดท้ายคำครบสำคัญกว่าขนาด 18pt
    return fix

def _wsplit(x, n):
    """ข้อความยาว → ท่อนไม่เกิน ~n ตัว ตัดที่รอยต่อคำ ไม่ขึ้นท่อนด้วยคำเชื่อม ไม่แยกเลขกับหน่วย ท่อนสุดท้ายไม่สั้นกว่า 12 ตัว"""
    out, cur = [], ''
    ws = wordsx(x)
    for i, w in enumerate(ws):
        if cur and len(cur) + len(w) > n and not cont(w.strip()) and not numunit(cur, ''.join(ws[i:])) and w.strip():
            out.append(cur.strip()); cur = w
        else: cur += w
    if cur.strip(): out.append(cur.strip())
    if len(out) > 1 and len(out[-1]) < 12: last = out.pop(); out[-1] += ' ' + last if not out[-1].endswith(' ') else last
    return out

KIND_TH = {'cover': 'ปก', 'agenda': 'สารบัญ', 'list': 'รายการ', 'pairs': 'หัวข้อพร้อมคำอธิบาย', 'qa': 'ถาม-ตอบ',
           'stat': 'ตัวเลขสำคัญ', 'timeline': 'ไทม์ไลน์', 'table': 'ตาราง', 'chart': 'กราฟ', 'statement': 'ข้อความเด่น',
           'divider': 'หน้าคั่น', 'compare': 'เปรียบเทียบ'}

def findings(want):
    """สิ่งที่อ่านเจอในไฟล์ ไว้โชว์ลูกค้าก่อนสร้าง (ของจริงทั้งหมด ไม่ได้เดา)"""
    secs = [c for c in want if c['kind'] not in ('cover', 'agenda')]
    nums = [x[0] for c in want if c['kind'] == 'stat' for x in c['items']]
    return dict(
        sections=len({c['t'] for c in secs}),
        tables=sum(1 for c in want if c['kind'] in ('table', 'chart')),
        rows=sum(len(c.get('rows') or []) for c in want if c['kind'] in ('table', 'chart')),
        nums=nums[:6], dates=sum(len(c['items']) for c in want if c['kind'] == 'timeline'),
        qa=sum(len(c['items']) for c in want if c['kind'] == 'qa'), notes=list(NOTES),
        outline=[dict(t=c['t'] if c['kind'] != 'statement' else (c.get('s') or c['t']), kind=c['kind'],
                      th=KIND_TH.get(c['kind'], ''), n=len(c.get('items') or c.get('rows') or [])) for c in want if not c.get('_off')])

def _ptitle(c):
    t = (c.get('s') or c.get('t')) if c['kind'] == 'statement' else c.get('t')
    if t: return t
    x = (c.get('items') or c.get('rows') or [''])[0]
    x = x if isinstance(x, str) else (x[0] if x else '')
    return x[:40] + ('…' if len(x) > 40 else '')

LAYKIND = {}                                               # ชื่อ layout → ชนิดของตัวอย่าง (ตารางที่ลงหน้าตาตาราง ไม่ใช่กราฟ)

def plan_summary(out):
    """สิ่งที่ทำจริงหลังลงหน้าตา ไว้ให้ผู้ช่วยเล่า (ไม่ใช่สิ่งที่เจอในเนื้อหา ซึ่งบางอย่างหน้าตานั้นทำไม่ได้)"""
    cs = [x['c'] for x in out]
    drawn = lambda x: 'table' if x['c']['kind'] == 'chart' and LAYKIND.get(x['layout']) != 'chart' else x['c']['kind']
    n = lambda k: sum(1 for x in out if drawn(x) == k)   # ชนิดตามหน้าตาที่วาดจริง (ข้อมูลกราฟบนหน้าตาตาราง = ตาราง)
    return dict(notes=list(dict.fromkeys(NOTES)), pages=len(out), kinds={k: n(k) for k in KIND_TH if n(k)},
                stats=[dict(t=c.get('t', ''), vals=[v for v, _ in c['items']][:4]) for c in cs if c['kind'] == 'stat'][:3],
                charts=[x['c'].get('t', '') for x in out if x['c']['kind'] == 'chart' and LAYKIND.get(x['layout']) == 'chart'],
                tables=[x['c'].get('t', '') for x in out if x['c']['kind'] == 'table' or (x['c']['kind'] == 'chart' and LAYKIND.get(x['layout']) != 'chart')],
                timelines=sum(len(c['items']) for c in cs if c['kind'] == 'timeline'),
                sections=INFO.get('sections', len({c.get('_sec') for c in cs if isinstance(c.get('_sec'), int)})),
                # โครงหน้าจริงหลังจัด (ชื่อหน้า: หัวเรื่อง หรือหัวรอง หรือข้อความแรกของหน้า) ให้รายการในแชทตรงกับสไลด์
                outline=[dict(t=_ptitle(x['c']), kind=drawn(x), th=KIND_TH.get(drawn(x), ''),
                              n=len(x['c'].get('items') or x['c'].get('rows') or [])) for x in out])   # ชิปชนิดหน้าตามหน้าตาที่วาดจริง

def alternatives(c, slug):
    """layout อื่นในชุดเดียวกันที่รับแผ่นนี้ได้โดยไม่ล้น — ให้ลูกค้ากดเปลี่ยนแบบ"""
    M, pool = pool_of(slug)
    res = []
    for sc, nm, ex, slots in candidates(c, pool, {}):
        d, bad = try_one(nm, ex, slots, c, M)
        if d is not None: res.append((nm, d))
    return res

def reagenda(c, secs, slug, layout):
    """สารบัญหลังย้าย/ลบหน้า: หัวข้อเดิมที่ยังมีหน้าอยู่ เรียงตามลำดับหน้าปัจจุบัน (secs = หัวข้อของหน้าที่เหลือตามลำดับ)
    คืน (สารบัญใหม่, (layout, d) หรือ None)  None = ไม่เหลือหัวข้อหรือหน้าตานี้ใส่ไม่ได้ เว็บเอาหน้าสารบัญออก
    ponytail: ไม่เติมหัวข้อที่เกิน 6 ข้อแรกเข้ามาแทนข้อที่ลบ สารบัญจึงสั้นลงได้แต่ไม่มีข้อที่ไม่จริง"""
    base = c.get('_items0') or c['items']
    pos = {}
    for i, t in enumerate(secs): pos.setdefault(t, i)
    ids = c.get('_secs0') or c.get('_secs')
    if ids is not None and all(isinstance(t, int) for t in secs):   # ผูกด้วยเลขหัวข้อ
        pairs = sorted([(x, n) for x, n in zip(base, ids) if n in pos], key=lambda p: pos[p[1]])
        keep = [x for x, _ in pairs]
        c2 = dict(c, items=keep, _items0=base, _secs=[n for _, n in pairs], _secs0=ids)
    else:
        keep = sorted([x for x in base if x[0] in pos], key=lambda x: pos[x[0]])
        c2 = dict(c, items=keep, _items0=base)
    if not keep: return c2, None
    alts = alternatives(c2, slug)
    return c2, next((a for a in alts if a[0] == layout), alts[0] if alts else None)

# ══ 7. ตัวแก้บนเว็บ: กล่องไหนมาจากช่องไหน / แก้คำหนึ่งกล่อง ═══════════════════════
BOXES = []                                                 # render() เติม: ต่อหน้าที่วาด รายการกล่องที่แก้ได้
DPFX = []                                                  # ใบ 026 render() เติม: ต่อหน้า [ลำดับใน spTree, ขาวดำ] ของรูปที่มี a:grayscl
PICROT = []                                                # render() เติม: ต่อหน้า [ลำดับใน spTree, องศา, กลับซ้ายขวา, กลับบนล่าง] ของรูปที่หมุน/กลับ (pptx-preview ไม่วาด rot ของ p:pic เว็บหมุนเอง QA 30n)

def pic_rot(slide):
    from pptx.oxml.ns import qn
    out = []
    for i, sh in enumerate(slide.shapes):                    # ลำดับเดียวกับ b['zi'] = ลูกของแผ่นที่ pptx-preview วาด
        el = sh._element; xf = el.find(qn('p:spPr') + '/' + qn('a:xfrm')) if el.tag == qn('p:pic') else None
        if xf is not None and (int(xf.get('rot', 0)) or xf.get('flipH') in ('1', 'true') or xf.get('flipV') in ('1', 'true')):
            out.append([i, int(xf.get('rot', 0)) / 60000, xf.get('flipH') in ('1', 'true'), xf.get('flipV') in ('1', 'true')])
    return out

CHARTC = []                                                # render() เติม: ต่อหน้าที่วาด สีตัวอักษรของแต่ละกราฟ (จากไฟล์) ให้พรีวิวบนเว็บใช้แทนสีที่ pptx-preview บังคับ

def chart_colors(slide):
    """สีตัวอักษรของกราฟแต่ละตัวในหน้า ตามลำดับ shape: txPr ระดับ chartSpace ก่อน ไม่มีค่อยใช้ป้าย/แกนตัวแรกที่มีสี"""
    out = []
    for sh in slide.shapes:
        if not (getattr(sh, 'has_chart', False) and sh.has_chart): continue
        cs = sh.chart._chartSpace
        v = cs.xpath('./c:txPr//a:solidFill/a:srgbClr/@val') or cs.xpath('.//c:txPr//a:solidFill/a:srgbClr/@val')
        out.append(v[0] if v else None)
    return out
CHARTL = []                                                # ป้ายค่าของกราฟต่อหน้า (pptx-preview ไม่อ่าน c:dLbls เลย เว็บวาดป้ายเองจากนี่ ให้จอตรงไฟล์)
def _fmtv(v, code):
    """ค่าตามรูปแบบตัวเลขของป้าย (#,##0 / 0.0 / 0%  "หน่วย") พอสำหรับรูปแบบที่ตัวจัดเขียน"""
    if v is None: return ''
    code = (code or 'General').split(';')[0]
    if code == 'General': return (f'{v:,.2f}'.rstrip('0').rstrip('.') if isinstance(v, float) and v != int(v) else f'{int(round(v)):,}') if abs(v) >= 1000 else (str(round(v, 2)).rstrip('0').rstrip('.') if isinstance(v, float) else str(v))
    pct = '%' in code.replace('"%"', '') and '"%"' not in code
    num = re.sub(r'"[^"]*"', '', code); dec = len(num.split('.')[1].rstrip('#%')) if '.' in num else 0
    x = v * 100 if pct else v
    t = f'{x:,.{dec}f}' if ',' in num else f'{x:.{dec}f}'
    if '.' in num and num.split('.')[1].startswith('#'): t = t.rstrip('0').rstrip('.') if '.' in t else t
    lit = re.findall(r'"([^"]*)"', code)
    return t + ('%' if pct else '') + ''.join(lit)

def chart_labels(slide):
    """ต่อกราฟ: {k: col|bar|pie|line|area, s: [{c: สีชุด, l: [ป้ายต่อจุด '' = ไม่มี], lc: สีป้าย, pc: [สีต่อชิ้น]}]} ตามที่ไฟล์จะแสดงจริง"""
    from pptx.oxml.ns import qn
    out = []
    for sh in slide.shapes:
        if not (getattr(sh, 'has_chart', False) and sh.has_chart): continue
        pl = sh.chart.plots[0]; x = pl._element; tag = x.tag.split('}')[1]
        k = {'pieChart': 'pie', 'doughnutChart': 'donut', 'lineChart': 'line', 'areaChart': 'area', 'radarChart': 'radar'}.get(tag)
        if tag == 'barChart': k = 'bar' if (x.find(qn('c:barDir')) is not None and x.find(qn('c:barDir')).get('val') == 'bar') else 'col'
        if not k or k == 'radar': out.append(None); continue
        pdl = x.find(qn('c:dLbls')); sers = []
        on = lambda dl, t: dl is not None and dl.find(qn(t)) is not None and dl.find(qn(t)).get('val') in ('1', 'true')
        for sr in pl.series:
            e = sr._element; dl = e.find(qn('c:dLbls')); dl = dl if dl is not None else pdl
            vals = list(sr.values); n = len(vals)
            nf = (dl.find(qn('c:numFmt')).get('formatCode') if dl is not None and dl.find(qn('c:numFmt')) is not None else None) or (e.xpath('./c:val//c:formatCode/text()') or ['General'])[0]
            rng = [v.text for v in e.iter('{http://schemas.openxmlformats.org/drawingml/2006/chart}v') if v.getparent().getparent().tag.endswith('dlblRangeCache')]
            show_v, show_p = on(dl, 'c:showVal'), on(dl, 'c:showPercent')
            tot = sum(v for v in vals if v) or 1
            lab = []
            for j, v in enumerate(vals):
                pd = next((q for q in (dl.findall(qn('c:dLbl')) if dl is not None else []) if q.find(qn('c:idx')).get('val') == str(j)), None)
                sv, spc = (on(pd, 'c:showVal'), on(pd, 'c:showPercent')) if pd is not None and pd.find(qn('c:showVal')) is not None else (show_v, show_p)
                if pd is not None and on(pd, 'c:delete'): sv = spc = False
                t = []
                if rng and j < len(rng) and (sv or spc): t.append(rng[j])
                if sv: t.append(_fmtv(v, nf))
                if spc and not sv: t.append(f'{round(v / tot * 100)}%')
                lab.append('\n'.join(t))
            col = (e.xpath('./c:spPr/a:solidFill/a:srgbClr/@val') or e.xpath('./c:spPr/a:ln/a:solidFill/a:srgbClr/@val') or [''])[0]
            lc = (dl.xpath('.//a:defRPr/a:solidFill/a:srgbClr/@val') if dl is not None else []) or ['']
            pc = [(q.xpath('./c:spPr/a:solidFill/a:srgbClr/@val') or [''])[0] for q in sorted(e.findall(qn('c:dPt')), key=lambda q: int(q.find(qn('c:idx')).get('val')))]
            plc = [((q.xpath('.//a:defRPr/a:solidFill/a:srgbClr/@val') or [''])[0], q.find(qn('c:idx')).get('val')) for q in (dl.findall(qn('c:dLbl')) if dl is not None else [])]
            sz = (dl.xpath('.//a:defRPr/@sz') if dl is not None else []) or ['1400']
            pl_ = [next((c_ for c_, i_ in plc if i_ == str(j) and c_), lc[0]) for j in range(n)]
            ln_ = (e.xpath('./c:spPr/a:ln/a:solidFill/a:srgbClr/@val') or [''])[0]
            sers.append(dict(c=col, ln=ln_, l=lab, lc=lc[0], pl=pl_, pc=pc, z=int(sz[0]) / 100, n=(e.xpath('./c:tx//c:v/text()') or [''])[0], p=(dl.xpath('./c:dLblPos/@val') if dl is not None else []) and dl.xpath('./c:dLblPos/@val')[0] or ''))   # p = ตำแหน่งป้าย (ctr inEnd outEnd) ใบ 034 กรวยกลาง/น้ำตกป้ายอยู่ในแท่ง   # n = ชื่อชุด (ใบ 034 ป้ายแตะแก้ผูกกับหัวคอลัมน์ในตาราง)
        out.append(dict(k=k, s=sers, cats=[str(c_) for c_ in pl.categories]))   # cats = ชื่อหมวดตามลำดับในไฟล์ (พาเรโตเรียงใหม่ น้ำตก/กรวยมีชุดฐานซ่อน) ป้ายผูกกับแถวด้วยชื่อ
    return out
# ใบ 015 เฟส 0 ข้อ c: PIL นับบรรทัดขาดได้ (ฟอนต์กว้าง ข้อความเต็มกล่องพอดี) เว็บส่งจำนวนบรรทัดที่ชั้นพิมพ์ของเบราว์เซอร์ตัดจริงมาด้วย
LHINT = {}                                                 # ข้อความ (ช่องว่างยุบ) → [(pt, จำนวนบรรทัดของเบราว์เซอร์ที่ขนาดนั้น)] ใช้ระหว่าง edit_text เท่านั้น
EXTRA = {}                                                 # ผลเสริมของ edit_text ล่าสุด: lines = ยาวเกินประมาณกี่บรรทัด (0 = บอกไม่ได้)

def _leaves(v, path=()):
    """ทุกข้อความของลูกค้าใน d พร้อมที่อยู่ เช่น ('items', 2, 0)  ไม่รวมคีย์ดีไซน์ ตัวเลขกราฟ เลขหน้าคั่น"""
    if isinstance(v, str): yield path, v
    elif isinstance(v, (list, tuple)):
        for i, x in enumerate(v): yield from _leaves(x, path + (i,))
    elif isinstance(v, dict):
        for k, x in v.items():
            if k not in KEEP and k not in ('al', 'colw', 'vals', 'num'): yield from _leaves(x, path + (k,))

ADDV = ((40, 'bd', 'acc'), (28, 'bd', 'ink'), (18, 'rg', 'ink'))   # ใบ 022 ตัวอย่าง 3 แบบ: หัวเรื่อง หัวข้อรอง เนื้อความ (ขนาด น้ำหนัก สีของชุด)
ADDPH = ('พิมพ์หัวเรื่อง', 'พิมพ์หัวข้อรอง', 'พิมพ์ข้อความ')    # คำนำบนจอเท่านั้น (hint) กล่องว่างไม่ลงไฟล์
USERIMG = '/k5/user'                                           # รูปของลูกค้า: เว็บเขียนไฟล์ลง Pyodide FS ชื่อ = แฮช (hex)
TFIT = ('mv', 'usz', 'ffam', 'tfm', 'fsz')                  # คีย์ที่บอกว่าลูกค้าแตะกล่องนั้นแล้ว (ย้าย/ย่อขยาย ขนาด ฟอนต์ รูปแบบ)
def textfit(slide, d):
    """กฎไอซ์ "กรอบกล่องข้อความสูงพอดีตัวหนังสือ": กล่องที่ลูกค้าเพิ่ม (add) หรือแตะแล้ว (TFIT) ความสูง = ตัวหนังสือจริง (textfit_height)
    ช่องตาราง/กล่องที่ลูกค้าไม่ได้แตะ ไม่เปลี่ยน (ดีไซน์เดิม)"""
    keys = {k for f in TFIT for k in (d.get(f) or {})}
    if not (keys or d.get('add')): return
    import textfit_height
    for s, p_, *_r in list(_match(slide, d)):
        if _r[5] or not (p_[0] == 'add' or '.'.join(map(str, p_)) in keys): continue
        if p_[0] == 'add' and (d['add'][p_[1]] or {}).get('ns'): continue   # ใบ 027 รูปทรงมีข้อความ: กรอบ = รูปทรง ไม่หดตามคำ
        textfit_height.fit(s, lines, facefile)

def draw_adds(slide, d, hint=False):
    """ใบ 022: วาดของที่ลูกค้าเพิ่ม ตามลำดับ (ต่อท้าย spTree = บนสุด) ตำแหน่ง = mv ถ้าลากแล้ว ไม่งั้น r / ข้อความสูงตามบรรทัดจริง + PowerPoint ขยายเองได้"""
    from pptx.util import Emu
    from pptx.enum.text import MSO_AUTO_SIZE
    mv = d.get('mv') or {}
    for i, o in enumerate(d.get('add') or []):
        key = 'add.%d' % i
        if 't' in o and o.get('ns'):
            sh = _draw_ns(slide, o, mv.get(key + '.t') or o['r'], hint)
        elif 't' in o:
            r = mv.get(key + '.t') or o['r']; v = int(o.get('v', 2)) % 3; sz, wt, col = ADDV[v]; t = str(o['t'])
            ph = not t.strip()
            if ph and not hint: continue
            show = ADDPH[v] if ph else t
            need = lines(show, r[2] / 72 - 0.2, sz, facefile(None, wt == 'bd')) * sz * 1.25 + 10
            sh = base.txt(slide, r[0] / 72, r[1] / 72, r[2] / 72, max(r[3], need) / 72, show, sz, '9AA3AF' if ph else eng.P[col], wt)
            sh.text_frame.word_wrap = True; sh.text_frame.auto_size = MSO_AUTO_SIZE.SHAPE_TO_FIT_TEXT
        elif (o.get('el') or {}).get('k') in ('ico', 'map', 'pat'):
            sh = _draw_el(slide, key, o, mv.get(key) or o['r'], hint)
            if sh is None: continue
        elif o.get('img') is not None:
            r = mv.get(key) or o['r']; p = '%s/%x' % (USERIMG, int(o['img']))
            if not os.path.exists(p): continue                # รูปยังไม่ถูกเขียนลงเครื่องนี้: ข้าม ไม่พังทั้งหน้า
            sh = slide.shapes.add_picture(p, Emu(int(r[0] * 12700)), Emu(int(r[1] * 12700)), Emu(int(r[2] * 12700)), Emu(int(r[3] * 12700)))
            if (o.get('el') or {}).get('svg') and not hint: _svgblip(slide, sh, o['el']['svg'])   # ใบ 027 ไอคอน/ธงที่เป็นรูป: SVG คมทุกขนาด + PNG สำรอง
        else: continue
        sh.name = key

# ══ ใบ 027 คลังองค์ประกอบ: ไอคอน แผนที่ไทย ลายพื้น (d2s_el) + รูปทรงของเราที่มีข้อความ ═══════════════════════════
# ไฟล์: ไอคอน/แผนที่ = กลุ่มรูปทรง custGeom (เปลี่ยนสีใน PowerPoint ได้ แผนที่ = จังหวัดละรูปทรง ชื่อไทย) / ลายพื้น = สี่เหลี่ยมปูกระเบื้องรูป
# จอ: pptx-preview วาด custGeom หลายเส้นไม่ได้ → ไฟล์พรีวิววาดกรอบใส (ชื่อ add.N) แล้วเว็บใส่ SVG ที่สร้างจากรูปทรงชุดเดียวกัน (ELFX) = จอตรงไฟล์
ELFX = []                                                  # render(hint) เติม: ต่อหน้า [[ลำดับใน spTree, html]]
_ELC = {}
def _elof(d, name):
    try: o = d['add'][int(name.split('.')[1])]
    except Exception: return None
    return o.get('el') if isinstance(o, dict) and o.get('el') and 't' not in o else None
def _colx(c):
    c = str(c)
    if c.startswith('T:') and c[2:] in SCHEME: return 'schemeClr', SCHEME[c[2:]]   # สีของไฟล์: เปลี่ยนชุดสีใน PowerPoint แล้วตาม
    return 'srgbClr', _colhex(c)
def _elshapes(o):
    el = o['el']; k = (el.get('k'), el.get('svg') if el.get('k') == 'ico' else '', json.dumps(el.get('c')), json.dumps(el.get('pc'), sort_keys=True))
    if k not in _ELC:
        if len(_ELC) > 80: _ELC.clear()
        _ELC[k] = EL.map_shapes(el.get('pc')) if el['k'] == 'map' else EL.shapes(el['svg'], el.get('c') or ('T:primary', None))
    return _ELC[k]
def _emu(r): return [int(round(v * 12700)) for v in r]
def _bgfirst(slide):
    """จุดแทรกลายพื้น: ถัดจากพื้นหลังเต็มหน้าชิ้นแรก ๆ (ลายอยู่บนพื้น ใต้ทุกอย่าง)"""
    sw, sh_ = slide.part.package.presentation_part.presentation.slide_width, slide.part.package.presentation_part.presentation.slide_height
    at = None
    for x in slide.shapes:
        if x.width * x.height >= sw * sh_ * 0.95 and x.left <= 12700 and x.top <= 12700: at = x
        else: break
    return at
def _draw_el(slide, key, o, r, hint):
    from pptx.util import Emu
    from pptx.enum.shapes import MSO_SHAPE
    el = o['el']; X, Y, W, H = _emu(r)
    if el['k'] == 'pat' or hint:                           # จอ: กรอบใส ให้เว็บใส่ภาพ / ลายพื้น: สี่เหลี่ยมปูรูปในไฟล์
        if el['k'] == 'pat' and not hint and o.get('img') is None: return None
        sh = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, Emu(X), Emu(Y), Emu(W), Emu(H)); base._nostyle(sh); sh.line.fill.background()
        if el['k'] == 'pat' and not hint:
            p = '%s/%x' % (USERIMG, int(o['img']))
            if not os.path.exists(p): sh._element.getparent().remove(sh._element); return None
            _, rid = slide.part.get_or_add_image_part(p)
            from pptx.oxml import parse_xml
            spPr = sh._element.spPr
            for x in list(spPr):
                if x.tag.split('}')[1] in ('solidFill', 'noFill', 'gradFill', 'blipFill', 'pattFill'): spPr.remove(x)
            bf = parse_xml('<a:blipFill xmlns:a="%s" xmlns:r="%s" dpi="0" rotWithShape="1"><a:blip r:embed="%s"/><a:srcRect/><a:tile tx="0" ty="0" sx="25000" sy="25000" flip="none" algn="tl"/></a:blipFill>' % (EL.A_NS, EL.R_NS, rid))
            spPr.find('{%s}prstGeom' % EL.A_NS).addnext(bf)   # PNG กระเบื้อง 4 เท่าของ SVG ที่ 96 dpi: 25% = กว้าง 0.75 ของหน่วย SVG (pt) เท่าจอ
        else: sh.fill.background()
        if el['k'] == 'pat':
            at = _bgfirst(slide)
            if at is not None and at._element is not sh._element: at._element.addnext(sh._element)
            elif at is None: slide.shapes._spTree.insert_element_before(sh._element, 'p:sp', 'p:grpSp', 'p:pic', 'p:graphicFrame', 'p:cxnSp')
        return sh
    try: vb, shs = _elshapes(o)
    except Exception: return None                          # svg พัง: ข้าม ไม่พังทั้งหน้า
    g = EL.add_group(slide, key, vb, shs, (X, Y, W, H), _colx)
    return next(x for x in slide.shapes if x._element is g)
def _svgblip(slide, pic, svg):
    """p:pic PNG + a:extLst asvg:svgBlip (PowerPoint 2016+ วาด SVG คมทุกขนาด รุ่นเก่า/แอปอื่นใช้ PNG)"""
    from pptx.opc.package import Part
    from pptx.opc.packuri import PackURI
    from pptx.opc.constants import RELATIONSHIP_TYPE as RT
    from pptx.oxml import parse_xml
    pkg = slide.part.package; n = 1
    names = {str(p.partname) for p in pkg.iter_parts()}
    while '/ppt/media/el%d.svg' % n in names: n += 1
    part = Part(PackURI('/ppt/media/el%d.svg' % n), 'image/svg+xml', pkg, svg.encode('utf-8'))
    rid = slide.part.relate_to(part, RT.IMAGE)
    blip = pic._element.find('.//{%s}blip' % EL.A_NS)
    ext = parse_xml('<a:extLst xmlns:a="%s"><a:ext uri="{96DAC541-7B7A-43D3-8B79-37D633B846F1}"><asvg:svgBlip xmlns:asvg="http://schemas.microsoft.com/office/drawing/2016/SVG/main" xmlns:r="%s" r:embed="%s"/></a:ext></a:extLst>' % (EL.A_NS, EL.R_NS, rid))
    blip.append(ext)
def _draw_ns(slide, o, r, hint):
    """ใบ 027 รูปทรงของเรา: รูปทรง PowerPoint จริง (prstGeom) สี/เส้นของดีไซน์ + ข้อความที่พิมพ์ได้ (ว่าง = คำใบ้บนจอเท่านั้น)"""
    from pptx.util import Emu, Pt
    from pptx.enum.shapes import MSO_SHAPE
    from pptx.enum.text import MSO_ANCHOR, PP_ALIGN
    from pptx.oxml import parse_xml
    ns = o['ns']; X, Y, W, H = _emu(r)
    sh = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, Emu(X), Emu(Y), Emu(W), Emu(H)); base._nostyle(sh)
    pg = sh._element.spPr.find('{%s}prstGeom' % EL.A_NS); pg.set('prst', ns.get('p', 'rect'))
    av = pg.find('{%s}avLst' % EL.A_NS)
    for k_, v_ in (ns.get('adj') or {}).items(): av.append(parse_xml('<a:gd xmlns:a="%s" name="%s" fmla="val %d"/>' % (EL.A_NS, k_, int(v_))))
    spPr = sh._element.spPr
    def put(tag, xml):
        for x in list(spPr):
            if x.tag.split('}')[1] in tag: spPr.remove(x)
        if xml: spPr.append(parse_xml(xml))
    A = 'xmlns:a="%s"' % EL.A_NS
    put(('solidFill', 'noFill'), '<a:solidFill %s>%s</a:solidFill>' % (A, EL._clr(ns['f'], 1, _colx).replace('<a:', '<a:', 1)) if ns.get('f') else '<a:noFill %s/>' % A)
    if ns.get('l'):
        lw = int(float(ns.get('lw', 2)) * 12700)
        put(('ln',), '<a:ln %s w="%d" cap="rnd"><a:solidFill>%s</a:solidFill>%s<a:round/>%s%s</a:ln>' % (A, lw, EL._clr(ns['l'], 1, _colx), '<a:prstDash val="%s"/>' % ns['dash'] if ns.get('dash') else '',
            '<a:headEnd type="%s"/>' % ns['he'] if ns.get('he') else '', '<a:tailEnd type="%s"/>' % ns['te'] if ns.get('te') else ''))
    else: put(('ln',), '<a:ln %s><a:noFill/></a:ln>' % A)
    t = str(o.get('t') or ''); show = t if t.strip() else ((ns.get('hint') or ADDPH[2]) if hint and ns.get('ph', 1) else '')
    tf = sh.text_frame; tf.word_wrap = True; tf.vertical_anchor = MSO_ANCHOR.MIDDLE
    for m_ in ('margin_left', 'margin_right'): setattr(tf, m_, Emu(int(min(W, H) * 0.08)))
    tf.margin_top = tf.margin_bottom = Emu(0)
    for i_, ln_ in enumerate(show.split('\n')):
        p = tf.paragraphs[0] if i_ == 0 else tf.add_paragraph(); p.alignment = PP_ALIGN.CENTER
        if not ln_: continue
        r_ = p.add_run(); r_.text = ln_; r_.font.size = Pt(float(ns.get('sz', 16)))
        r_.font.color.rgb = base.rgb('9AA3AF' if not t.strip() else _colhex(ns.get('tc') or 'P:ink'))
        base._font(r_._r.get_or_add_rPr(), 'bd' if ns.get('b', 1) else 'rg')
    return sh
def el_fx(slide, d):
    """ภาพบนจอของทุกองค์ประกอบในหน้านี้ [[ลำดับใน spTree, html]]  html = SVG (ไอคอน แผนที่) / พื้นปูกระเบื้อง (ลายพื้น)"""
    out = []
    for i, x in enumerate(slide.shapes):
        if not x.name.startswith('add.'): continue
        el = _elof(d, x.name)
        if not el: continue
        o = d['add'][int(x.name.split('.')[1])]
        try:
            if el['k'] == 'pat':
                tw = float(el.get('tw') or 60); th = tw * float(el.get('ar') or 1)
                svg = str(el.get('svg') or '')
                h = '<div style="width:100%%;height:100%%;background-image:url(&quot;data:image/svg+xml,%s&quot;);background-size:%.2fpx %.2fpx"></div>' % (
                    __import__('urllib.parse').parse.quote(svg, safe=''), tw, th)
            elif el['k'] in ('ico', 'map'):
                vb, shs = _elshapes(o); h = EL.svg_of(vb, shs, _colhex, ids=el['k'] == 'map')
            else: continue
        except Exception: continue
        out.append([i, h])
    return out
def _note_cc(d):
    """โน้ตผู้บรรยาย + เครดิตชุด CC BY ที่อยู่บนหน้านี้ (ไอซ์ 1 พ.ย. ข้อ 3 "ตอนส่งออกใส่บรรทัดเครดิตในโน้ตของหน้านั้นอัตโนมัติ")"""
    t = str(d.get('_note') or '').rstrip(); cc = EL.credits(d)
    return (t + ('\n\n' if t else '') + '\n'.join(cc)) if cc else t

# ── กราฟ (ใบ 023): ชนิด 18 แบบ 40 สีไล่ ป้ายของลูกค้า ตารางข้อมูล ─────────────────────────
lay_charts = importlib.import_module('lay_charts')
def chart_types(items, idx):
    """เมนูชนิด: [{type th en ok why styles: [{id th xl ok why}]}] ชนิดที่ข้อมูลไม่พอ ok=False พร้อมเหตุผลภาษาไทย"""
    return lay_charts.chart_types(items[idx][1])

def set_chart(items, idx, **kw):
    """type style colors pc lab (None = ลบค่านั้น) คืน ok หรือเหตุผลที่ข้อมูลไม่พอ (ไม่เปลี่ยน)  หน้ากราฟของชุดเองย้ายเป็นหน้ากราฟกลาง (chb_col) ก่อน
    colors = {'pri': [[0, '#9A86FF'], [1, '#4F46E5']], 'acc': [...]} จุดสีกี่จุดก็ได้ / pc = {'i.j': hex|จุดสี} / lab = {'big'|'e.j'|'e.js'|'q.0'..: ข้อความ}"""
    name, d = items[idx]; cfg = dict(d.get('chart') or {})
    for k, v in kw.items():
        if v is None: cfg.pop(k, None)
        else: cfg[k] = v
    d2 = {k: v for k, v in d.items() if k != 'chart'}
    if cfg: d2['chart'] = cfg
    if cfg.get('type'):
        why = lay_charts._why(d2, cfg['type'], cfg.get('style'))
        if why: return why
    if cfg and not name.startswith(('chb_', 'chc_')):
        cats, ser = lay_charts._raw(d2); name = 'chb_col'; d2.update(cats=cats, series=ser)
    items[idx] = (name, d2); return 'ok'

def set_chart_all(items, colors):
    """คู่สีทั้งไฟล์ (ค่าเริ่ม): BR['chartc'] หน้าที่ตั้งสีเฉพาะกราฟยังใช้สีของตัวเอง  None = กลับเป็นสีตามชุด"""
    if colors: BR['chartc'] = colors
    else: BR.pop('chartc', None)
    return 'ok'

# ── ใบ 028 เลย์เอาต์หน้ากราฟ A-F + ปรับเอง ─────────────────────────────────────
NOTEPH = 'แตะเพื่อเพิ่มคำอธิบาย'                            # คำใบ้บนจอ (ไอซ์ 1 พ.ย. รอบ 2) ไม่ใช่คำบนสไลด์ ไม่ออกในไฟล์
def _chpage(items, i):
    """หน้ากราฟที่เปลี่ยนเลย์เอาต์ได้: หน้ากราฟกลาง หรือหน้ากราฟของชุด (มีตาราง) ที่ย้ายเป็นหน้ากราฟกลางได้"""
    if not isinstance(i, int) or not 0 <= i < len(items): return False   # เว็บส่ง null (JsNull) ได้ (คอนโซล 3 พ.ย.)
    nm, d = items[i]
    if nm.startswith(('chb_', 'chc_')): return True
    return LAYKIND.get(nm) == 'chart' and bool(lay_charts._raw(d)[0])

def _two_ok(items, idx, nxt):
    """ตารางที่สอง (F): หน้าถัดไปเป็นหน้ากราฟ ยังไม่รวมกับหน้าอื่น วาดได้สักแบบ / หน้าที่รวมแล้ว = ได้"""
    if items[idx][1].get('two'): return None
    if not isinstance(nxt, int): nxt = None               # JsNull จากเว็บ = ไม่มีหน้าถัดไป
    if nxt is None or nxt == idx or not _chpage(items, nxt): return 'ต้องมี 2 ตาราง: หน้าถัดไปต้องเป็นหน้ากราฟ'
    if items[nxt][1].get('two'): return 'หน้าถัดไปรวมสองกราฟอยู่แล้ว'
    if not any(y['ok'] for x in lay_charts.chart_types(items[nxt][1]) for y in x['styles']): return 'ตารางหน้าถัดไปทำกราฟไม่ได้'
    return None

def lay_now(items, idx):
    """ชุดค่าที่หน้านี้ใช้อยู่ / None = แบบของชุด (หน้ากราฟของชุด หรือแบบเวทีเข้มเดิม)"""
    nm, d = items[idx]; lay = (d.get('chart') or {}).get('lay')
    if lay: return lay_charts.lay_norm(lay)
    return dict(lay_charts.LAYP['A']) if nm.startswith('chb_') else None

def chart_layouts(items, idx, nxt=None):
    """แผงเลย์เอาต์: {cur ชุดค่า|None, pre แบบสำเร็จที่ตรง (A-F / X ปรับเอง / None), tables, presets: [{id ok why}], ctl: {คีย์: {ค่า: เหตุผล|None}}}
    nxt = ตำแหน่งใน ITEMS ของหน้าถัดไป (เว็บส่ง order[k+1]) ใช้ตัดสินว่ารวมสองกราฟได้ไหม"""
    L = lay_charts; cur = lay_now(items, idx); why2 = _two_ok(items, idx, nxt); tb = 1 if why2 else 2
    c = cur or dict(L.LAYP['B']); bad = L.lay_bad(c, tb, why2 or '')
    pre = next((k for k, v in L.LAYP.items() if v == cur), 'X' if cur else None)
    presets = []
    for k, v in L.LAYP.items():
        w = next((r for (a, b), r in L.lay_bad(v, tb, why2 or '').items() if v[a] == b), None)
        presets.append(dict(id=k, ok=w is None, why=w))
    ctl = {key: {str(v): (None if c[key] == v else bad.get((key, v))) for v in vals} for key, vals in L.LAYV.items()}   # = mockup: กดไม่ได้เฉพาะที่ชุดค่าปัจจุบันขวาง ค่าอื่นที่ชนกันปรับให้เอง (set_chart_layout keep=)
    return json.dumps(dict(cur=cur, pre=pre, tables=tb, presets=presets, ctl=ctl, note=bool(str(items[idx][1].get('note') or '').strip())), ensure_ascii=False)

def dpic_lists(items, M):
    """แผงเปลี่ยนรูป (เว็บ paintDpic): [รูปที่ลูกค้าใส่ในงานนี้ (hex), รูปของหมวดดีไซน์, โฟลเดอร์รูป]
    เดิมเขียนเป็นนิพจน์ยาวใน runPython ของหน้าเว็บ คอนโซล 3 พ.ย. ฟ้อง NameError 'os' ย้ายมาไว้ในโมดูลที่ import os แล้ว"""
    mine = sorted({'%x' % int(v) for _, d in items for v in [o.get('img') for o in (d.get('add') or []) if isinstance(o, dict)]
                   + [o.get('img') for o in (d.get('dpic') or {}).values() if isinstance(o, dict)] if v is not None})
    tp = M.get('topic', 'office'); tp = eng.PHMAP.get(tp) or tp; fd = os.path.join(eng.IMG, tp)   # ใบ 055 ชุดคนเอเชียที่ใช้แทน (กรอบว่าง = หมวดเดิมของดีไซน์)
    pool = sorted(f'{tp}/{f}' for f in (os.listdir(fd) if os.path.isdir(fd) else []) if f.lower().endswith(('.jpg', '.jpeg', '.png', '.webp')))
    return json.dumps([mine, pool, eng.IMG])

def set_chart_layout(items, idx, lay, pages=None, nxt=None, keep=None):
    """ตั้งเลย์เอาต์หน้านี้ (lay = ชุดค่า หรือชื่อแบบ 'A'-'F') pages = ตำแหน่งใน ITEMS ของทุกหน้ากราฟ (สวิตช์ "ทุกหน้ากราฟ")
    k=2: รวมหน้ากราฟถัดไป (nxt) เข้ามา / k=1 จากหน้าที่รวมไว้: แยกหน้าเดิมกลับ
    คืน JSON [สถานะ, {merge: ตำแหน่งที่ถูกรวม | split: ตำแหน่งที่แยกกลับ, n: จำนวนหน้าที่เปลี่ยน}]"""
    L = lay_charts; nxt = nxt if isinstance(nxt, int) else None   # JsNull จากเว็บ
    c = L.lay_norm(L.LAYP[lay] if isinstance(lay, str) else lay)
    why2 = _two_ok(items, idx, nxt); tb = 1 if why2 else 2
    if keep:                                               # ปรับเอง: ตัวที่เพิ่งกดชนะ ตัวอื่นที่ชนกันถอยเป็นค่าแรก (ไม่มี/บน/1/พอดี)
        for _ in range(6):
            hit = [(a, b) for (a, b) in L.lay_bad(c, tb) if c[a] == b and a != keep]
            if not hit: break
            a, _b = hit[0]; c[a] = L.LAYV[a][0]
    if not L.lay_ok(c, tb):
        return json.dumps([next(r for (a, b), r in L.lay_bad(c, tb, why2 or '').items() if c[a] == b), None], ensure_ascii=False)
    out = {'n': 0}
    def put(i, cc, two=None, drop_two=False):
        nm, d = items[i]; cfg = dict(d.get('chart') or {}); cfg['lay'] = cc
        d2 = {k: v for k, v in d.items() if k not in ('chart', 'two')}; d2['chart'] = cfg; d2.setdefault('note', '')   # ช่องคำอธิบายให้แตะพิมพ์ได้
        if two is not None: d2['two'] = two
        elif d.get('two') and not drop_two: d2['two'] = d['two']
        if not nm.startswith(('chb_', 'chc_')):          # หน้ากราฟของชุด: ย้ายเป็นหน้ากราฟกลางก่อน (เหมือน set_chart)
            cats, ser = lay_charts._raw(d2); nm = 'chb_col'; d2.update(cats=cats, series=ser)
        if not cfg.get('type'):                            # ลูกค้าเลือกเลย์เอาต์เอง: ล็อกแบบกราฟที่เห็นอยู่ (เพดานของตัวจัดอัตโนมัติไม่ขวางกรอบที่แคบลง)
            t_, s_ = lay_charts._tsid(d, nm[4:])
            if lay_charts._why(d2, t_, s_): t_, s_ = next(((x['type'], y['id']) for x in lay_charts.chart_types(d2) for y in x['styles'] if y['ok']), (t_, s_))
            cfg['type'], cfg['style'] = t_, s_
        items[i] = (nm, d2); out['n'] += 1
    d = items[idx][1]
    if c['k'] == 2 and not d.get('two'):
        nm2, dd2 = items[nxt]
        put(idx, c, two={'i': nxt, 'nm': nm2, 'd': dd2}); out['merge'] = nxt
    elif c['k'] == 1 and d.get('two'):
        two = d['two']; items[two['i']] = (two['nm'], two['d'])   # หน้าเดิมกลับมาทั้งหน้า (ชื่อ/ตารางที่แก้ระหว่างรวมอยู่ใน two['d'])
        put(idx, c, drop_two=True); out['split'] = two['i']
    else: put(idx, c)
    for i in pages or ():
        if i == idx or i == out.get('merge') or not _chpage(items, i): continue
        has2 = bool(items[i][1].get('two')); cc = dict(c, k=2 if has2 else 1)
        if not L.lay_ok(cc, 2 if has2 else 1): continue      # หน้าที่ชุดค่านี้ใช้ไม่ได้ (เช่น สองกราฟ) คงเดิม
        put(i, cc)
    return json.dumps(['ok', out], ensure_ascii=False)

def after_look(items, order, cs):
    """หลังเปลี่ยนหน้าตา (carry_page แล้ว): หน้าที่ได้ two มา -> ลบหน้ากราฟที่จัดใหม่ซ้ำกับตารางที่สอง / หน้ากราฟของชุดที่มีเลย์เอาต์ -> หน้ากราฟกลาง
    คืน order ใหม่"""
    out = list(order); gone = set()
    for p, i in enumerate(order):
        if i in gone: continue
        nm, d = items[i]
        if (d.get('chart') or {}).get('lay') and not nm.startswith(('chb_', 'chc_')) and _chpage(items, i):
            cats, ser = lay_charts._raw(d); items[i] = ('chb_col', {**d, 'cats': cats, 'series': ser}); d = items[i][1]
        two = d.get('two')
        if not two: continue
        nx = order[p + 1] if p + 1 < len(order) else None   # หน้าถัดไปที่จัดใหม่จากเนื้อหาเดียวกับตารางที่สอง (หัวข้อหรือชื่อแถวตรงกัน)
        if nx is not None and _chpage(items, nx) and (cs[nx].get('t') == two['d'].get('t') or list(cs[nx].get('cats') or []) == list(lay_charts._raw(two['d'])[0])):
            gone.add(nx); j = nx
        else:                                              # ไม่เจอหน้าคู่: เก็บหน้าเดิมไว้ท้าย ITEMS (นอกลำดับ) แยกกลับได้
            items.append((two['nm'], two['d'])); cs.append(dict(kind='chart', t=two['d'].get('t', ''))); j = len(items) - 1
        items[i] = (nm, {**d, 'two': {**two, 'i': j}})          # ITEMS ชุดใหม่: ตำแหน่งหน้าเดิมเปลี่ยน
    return [i for i in out if i not in gone]

def unmerge_lost(items, idx):
    """เปลี่ยนแบบหน้าเป็นหน้ากราฟของชุด (วาดตารางที่สองไม่ได้): แยกหน้าเดิมกลับ คืนตำแหน่งใน ITEMS ที่ต้องใส่กลับในลำดับ / None"""
    nm, d = items[idx]; two = d.get('two')
    if not two or nm.startswith(('chb_', 'chc_')): return None
    items[two['i']] = (two['nm'], two['d']); cfg = dict(d.get('chart') or {})
    if cfg.get('lay'): cfg['lay'] = dict(cfg['lay'], k=1)
    items[idx] = (nm, {**{k: v for k, v in d.items() if k != 'two'}, 'chart': cfg}); return two['i']

def chart_table(items, idx):
    return lay_charts.table_of(items[idx][1])

def set_chart_table(items, idx, table):
    """แผงตาราง: [หัว, แถว...] (ตัวเลขเป็นข้อความตามที่ลูกค้าพิมพ์ 1,250 / 12.5%) เขียนกลับทุกรูปแบบที่หน้านั้นใช้ (series / vals / items)
    คืน ok หรือข้อความไทยบอกเซลล์ที่ไม่ใช่ตัวเลข"""
    head, rows = list(table[0]), [list(r) for r in table[1:] if any(str(c).strip() for c in r)]
    nc = head.index(lay_charts.NOTE) if lay_charts.NOTE in head[1:] else None   # คอลัมน์หมายเหตุ = ป้ายเหตุการณ์ของแถว (ข้อความ ไม่ใช่ตัวเลข)
    notes = [str(r[nc]).strip() if nc < len(r) else '' for r in rows] if nc else None
    if nc: head = head[:nc] + head[nc + 1:]; rows = [r[:nc] + r[nc + 1:] for r in rows]
    if len(head) < 2 or not rows: return 'ต้องมีอย่างน้อย 1 คอลัมน์ตัวเลขและ 1 แถว'
    for r, row in enumerate(rows):
        for c in range(1, len(head)):
            if c >= len(row) or not isnum(str(row[c])): return f'แถว {r + 1} คอลัมน์ "{head[c]}" ไม่ใช่ตัวเลข'
    name, d = items[idx]; cats = [str(r[0]) for r in rows]
    ser = [(head[c], [tonum(str(r[c])) for r in rows]) for c in range(1, len(head))]
    d2 = dict(d, cats=cats, series=ser, _nf=[[xlfmt(str(r[c])) for r in rows] for c in range(1, len(head))], _sn=[n for n, _ in ser])
    d2.pop('_samp', None)                                  # ใบ 031: ลูกค้าแก้ตารางแล้ว ไม่ใช่ข้อมูลตัวอย่างอีก
    if isinstance(d.get('head'), list): d2['head'] = [head[0]] + list(d['head'][1:])
    elif str(head[0]).strip(): d2['head'] = [head[0]]          # ใบ 034 หัวคอลัมน์แรกที่ลูกค้าพิมพ์ในแผงข้อมูล → A1 ของชีตฝัง
    if 'vals' in d: d2['vals'] = list(ser[0][1]); d2['sname'] = ser[0][0]
    if 'items' in d and 'cats' not in d: d2['items'] = [(c, v) for c, v in zip(cats, ser[0][1])]
    if notes is not None:
        cfg = dict(d.get('chart') or {}); lab = {k: v for k, v in (cfg.get('lab') or {}).items() if not re.fullmatch(r'e\.\d+s?', k)}
        lab.update({f'e.{j}': t for j, t in enumerate(notes) if t}); cfg['lab'] = lab; d2['chart'] = cfg
    items[idx] = (name, d2); return 'ok'

def new_chart(t, sid, table, lay='B', samp=False):
    """ใบ 031 หน้ากราฟจากแผ่นเพิ่มหน้า: (layout, d, c) = หน้ากราฟกลางแบบเดียวกับที่ตัวจัดทำ (chb_col + เลย์เอาต์) / ข้อความไทยเมื่อข้อมูลวาดแบบนี้ไม่ได้
    หัวเรื่อง หัวรอง ว่าง (บนจอเป็นคำใบ้ ไม่ลงไฟล์ เหมือนหน้าที่แทรกอื่น)  samp = ยังเป็นข้อมูลตัวอย่าง (เตือนตอนบันทึก)"""
    its = [('chb_col', {'t': '', 's': '', 'cats': [], 'series': []})]
    r = set_chart_table(its, 0, table)
    if r != 'ok': return r
    d = its[0][1]; why = lay_charts._why(d, t, sid)
    if why: return why
    d = dict(d, chart={**(d.get('chart') or {}), 'type': t, 'style': sid, 'lay': dict(lay_charts.LAYP[lay])})
    if samp: d['_samp'] = 1
    return ('chb_col', d, dict(kind='chart', t='', _ins=1))

def chart_sample(t, sid, lay='B'):
    """ตารางตัวอย่างของแบบนี้ ในรูปที่แผงข้อมูลแสดง (คอลัมน์ตามชนิด เช่น หมายเหตุของเส้นพร้อมป้าย) คืน JSON"""
    x = new_chart(t, sid, lay_charts.sample(t, sid), lay, True)
    return json.dumps(lay_charts.table_of(x[1]) if isinstance(x, tuple) else lay_charts.sample(t, sid), ensure_ascii=False)

# ══ ใบ 034 หน้าตารางจากแผ่นเพิ่มหน้า ═══════════════════════════════════════════════════════════
# หน้าตารางของชุด (kind table) ที่วาดตารางนี้ได้ครบ ถ้าชุดไม่มี/วาดไม่ครบ (expandarea photo_collage, cafeloyalty ฯลฯ) ใช้ table_plain = หน้าตารางกลาง สี/ฟอนต์ของชุด (แบบเดียวกับหน้ากราฟกลางของ lay_charts)
TABLE_SAMPLE = [['รายการ', 'แพ็กเริ่มต้น', 'แพ็กมาตรฐาน'], ['ราคาต่อเดือน', '990 บาท', '1,890 บาท'], ['จำนวนผู้ใช้', '1 คน', '5 คน'], ['พื้นที่เก็บไฟล์', '5 GB', '50 GB']]

def _tbl_ex(slug, nm):
    """ตัวอย่าง (ex, slots) ของ layout ตาราง: จากชุดนี้ก่อน ไม่มีก็จากชุดที่ใช้ table_plain"""
    M, pool = pool_of(slug)
    x = next(((ex, sl) for n_, ex, kd, _, sl in pool if n_ == nm), None)
    if x: return x
    deck_of(slug)
    ex = next(dict(e) for m in _DECKS.values() for n_, e in m['SEQ'] if n_ == nm)
    LAYKIND.setdefault(nm, 'table'); return ex, None

_RTB = {}
def _realtbl(nm, d, M):
    """layout นี้วาดเป็นตารางจริงของ PowerPoint (graphicFrame tbl) ไหม  ชุดที่วาดแถวเป็นกล่องข้อความ ลูกค้าเพิ่ม/ลบคอลัมน์ใน PowerPoint ไม่ได้ จึงใช้หน้าตารางกลาง"""
    if nm not in _RTB:
        eng.setpal(M['pal'], M.get('font', 'plex'), M.get('head')); eng.setvar(0)
        prs = base.deck(); real = base._prep; base._prep = lambda path, mode=None: (_DOT, (4, 3))
        try: lay.L[nm](prs, {'topic': M.get('topic', 'office'), 'foot': '', 'n': '01', **d}); _RTB[nm] = any(getattr(x, 'has_table', False) and x.has_table for x in prs.slides[-1].shapes)
        except Exception: _RTB[nm] = False
        finally: base._prep = real
    return _RTB[nm]

def _tbl_c(table, t=''):
    head = [str(x) for x in table[0]]; w = len(head)
    rows = [[str(r[j]) if j < len(r) else '' for j in range(w)] for r in table[1:] if any(str(x).strip() for x in r)]
    return dict(kind='table', t=t, head=head, rows=rows, _ins=1)

# ใบ 036 (ไอซ์ 2 พ.ย. 2569 เลือก ข): รูปแบบตาราง 2 แบบ  'set' = หน้าตารางของชุด (กล่องข้อความ สวยตามดีไซน์)  'ppt' = ตาราง PowerPoint จริง (หน้าตารางของชุดที่เป็นตารางจริง หรือ table_plain)
#   d['_tst'] = รูปแบบที่เลือก ตามไปตอนเปลี่ยนหน้าตา (retable) ชุดใหม่ไม่มีแบบนั้นใช้ตาราง PowerPoint แต่จำที่เลือกไว้
def table_style(nm, d, slug):
    return 'ppt' if _realtbl(nm, d, pool_of(slug)[0]) else 'set'

def _tbl_pick(slug, c, style):
    """(layout, d) ของรูปแบบ style ที่วาดตาราง c ได้ครบ / ข้อความไทยบอกเหตุ (ไม่เปลี่ยนอะไร)"""
    M, pool = pool_of(slug)
    own = [n_ for n_, ex, kd, _, sl in pool if kd == 'table' and n_ != 'table_plain']
    seen = False
    for nm in own + ['table_plain'] if style == 'ppt' else own:
        ex, sl = _tbl_ex(slug, nm); d = fill(nm, ex, sl, c)
        if d is None or _realtbl(nm, d, M) != (style == 'ppt'): continue
        seen = True
        if overflow(nm, d, M): continue
        return nm, {**d, '_tst': style}
    n = f'{len(c["head"])} คอลัมน์ {len(c["rows"])} แถว'
    if style == 'set': return f'แบบของชุดรับตาราง {n} นี้ไม่ได้ ใช้ตาราง PowerPoint หรือลดแถว/คอลัมน์' if seen else 'หน้าตานี้ไม่มีหน้าตารางของดีไซน์ ใช้ตาราง PowerPoint แทน'
    return f'ตาราง {n} ยาวเกินหนึ่งหน้า ลองลดแถวหรือคอลัมน์'

def new_table(slug, table, samp=False, style=None):
    """(layout, d, c) ของหน้าตารางใหม่ / ข้อความไทยเมื่อวาดไม่ได้ครบ  style None = แบบของชุดก่อน ไม่มี/ไม่พอก็ตาราง PowerPoint (จำว่าตั้งต้นแบบของชุด)"""
    if len(table) < 2 or len(table[0]) < 2: return 'ตารางต้องมีอย่างน้อย 2 คอลัมน์และ 1 แถว'
    c = _tbl_c(table)
    if not c['rows']: return 'ตารางต้องมีอย่างน้อย 2 คอลัมน์และ 1 แถว'
    x = _tbl_pick(slug, c, style or 'set')
    if isinstance(x, str) and style is None:
        x = _tbl_pick(slug, c, 'ppt')
        if not isinstance(x, str): x[1]['_tst'] = 'set'
    if isinstance(x, str): return x
    if samp: x[1]['_samp'] = 1
    return (x[0], x[1], c)

def table_sample():
    return json.dumps(TABLE_SAMPLE, ensure_ascii=False)

def page_table(items, idx):
    """ตารางของหน้าตาราง [หัว, แถว...] ให้แผงข้อมูล (หัวแบบ (หัว, หัวรอง) ใช้หัวหลัก)"""
    d = items[idx][1]
    return json.dumps([[h if isinstance(h, str) else h[0] for h in d.get('head') or []]] + [[str(x) for x in r] for r in d.get('rows') or []], ensure_ascii=False)

def _tbl_move(items, idx, c2, style, slug):
    """หน้าตารางไปอีก layout: คำ (หัวเรื่อง หัวรอง หมายเหตุ ตาราง) + ของที่ลูกค้าเพิ่ม/ตั้งไว้ตามไป (carry_page) คืน ok / เหตุผล"""
    x = _tbl_pick(slug, c2, style)
    if isinstance(x, str): return x
    items[idx] = (x[0], carry_page(items[idx][1], x[1])); items[idx][1]['_tst'] = style; return 'ok'

def set_table(items, idx, table, slug, style=None):
    """แผงข้อมูลหน้าตาราง: เขียนหัว/แถวใหม่ (ช่องว่างได้) ด้วย layout เดิม วาดไม่ครบ = ลองหน้าตารางอื่น คืน ok หรือเหตุผล (ไม่เปลี่ยน)
    style ('set'/'ppt') ต่างจากรูปแบบตอนนี้ = เปลี่ยนรูปแบบด้วย (ใบ 036)"""
    nm, d = items[idx]
    x = new_table(slug, table)
    if isinstance(x, str): return x
    c = x[2]
    if style and style != table_style(nm, d, slug):
        c2 = content_of(d, {'kind': 'table'}); c2.update(head=c['head'], rows=c['rows'])
        return _tbl_move(items, idx, c2, style, slug)
    ex, sl = _tbl_ex(slug, nm); d2 = fill(nm, ex, sl, c); M, _ = pool_of(slug)
    if d2 is None or overflow(nm, d2, M):
        st = style or d.get('_tst') or table_style(nm, d, slug); y = _tbl_pick(slug, c, st)
        if isinstance(y, str) and st == 'set': y = _tbl_pick(slug, c, 'ppt')   # แถวเกินแบบของชุด: ตาราง PowerPoint คำครบ (จำที่เลือกไว้)
        if isinstance(y, str): return y
        nm, d2 = y
    keep = {k: v for k, v in d.items() if k not in ('head', 'rows', 'colw', 'al', '_samp')}
    items[idx] = (nm, {**d2, **keep, **{k: d2[k] for k in ('head', 'rows', 'colw', 'al') if k in d2}}); return 'ok'

def set_table_style(items, idx, style, slug):
    """แผ่นเปลี่ยนแบบ: สลับ แบบของชุด <-> ตาราง PowerPoint ข้อมูลเดิมครบ คืน ok / เหตุผล"""
    nm, d = items[idx]
    if style == table_style(nm, d, slug): items[idx] = (nm, {**d, '_tst': style}); return 'ok'
    return _tbl_move(items, idx, content_of(d, {'kind': 'table'}), style, slug)

def retable(items, order, cs, slug):
    """หลังเปลี่ยนหน้าตา: หน้าตารางที่มีรูปแบบที่เลือก (_tst) ใช้รูปแบบนั้นในหน้าตาใหม่ ไม่มีก็ตาราง PowerPoint (ยังจำที่เลือกไว้)
    หน้าตารางที่ยกมาทั้งหน้า (layout ของชุดเก่า) ลง layout ของชุดใหม่"""
    _, pool = pool_of(slug); mine = {n_ for n_, ex, kd, _, sl in pool if kd == 'table'} | {'table_plain'}
    for i in order:
        nm, d = items[i]
        if cs[i].get('kind') != 'table' or not d.get('rows') or not d.get('_tst'): continue
        if nm in mine and table_style(nm, d, slug) == d['_tst']: continue
        st = d['_tst']; c2 = content_of(d, {'kind': 'table'})
        if _tbl_move(items, i, c2, st, slug) != 'ok' and _tbl_move(items, i, c2, 'ppt', slug) == 'ok': items[i][1]['_tst'] = st

def add_obj(items, idx, o):
    """เพิ่มข้อความ/รูปหนึ่งชิ้นท้าย d['add'] คืนตำแหน่ง N (path ข้อความ = ['add', N, 't'] รูป = ['add', N])"""
    name, d = items[idx]; a = list(d.get('add') or []); a.append(dict(o)); items[idx] = (name, {**d, 'add': a}); return len(a) - 1

def del_obj(items, idx, n):
    """ลบชิ้นที่ N (ช่องว่างคงไว้เป็น {} ให้ path ของชิ้นอื่นไม่เลื่อน) + ค่าที่ผูกกับมัน (mv rot lock z รูปแบบ)"""
    name, d = items[idx]; a = list(d.get('add') or [])
    if not 0 <= n < len(a): return 'none'
    a[n] = {}; pre = ('add.%d' % n, 'add.%d.' % n); d2 = {**d, 'add': a}
    for f in ('mv', 'rot', 'lock', 'usz', 'ffam', 'tfm', 'fsz'):
        if isinstance(d2.get(f), dict):
            m = {k: v for k, v in d2[f].items() if not (k == pre[0] or k.startswith(pre[1]))}
            if m: d2[f] = m
            else: d2.pop(f)
    if d2.get('z'): d2['z'] = [x for x in d2['z'] if not (x[0] == pre[0] or x[0].startswith(pre[1]))] or None
    if not d2.get('z'): d2.pop('z', None)
    items[idx] = (name, d2); return 'ok'

def set_obj(items, idx, n, **kw):
    """เปลี่ยนค่าชิ้นที่ N (เปลี่ยนรูป: img + r ใหม่ คงที่เดิม)"""
    name, d = items[idx]; a = list(d.get('add') or []); a[n] = {**a[n], **kw}; items[idx] = (name, {**d, 'add': a}); return 'ok'

# ══ ใบ 026: รูปในดีไซน์ (เปลี่ยน/ปรับจุดที่เห็น/ลบ) + สีชิ้นในสไลด์ + สีของไฟล์ (ธีมสี) ═══════════════════════════
# รูปในดีไซน์ = p:pic ที่ layout วาดจากคลังรูป (eng.IMG) ไม่ใช่ไอคอน/พื้นผิว/โลโก้/รูปที่ลูกค้าเพิ่ม  เรียกด้วยลำดับ 'dpic.N' (รูปที่ N ของหน้าตามลำดับที่วาด)
# d['dpic'] = {'N': {img: แฮช | src: 'learn/03.jpg', crop: [l, t, r, b], gray: 0|1, del: 1}}  เขียนลง p:pic ตัวเดิม (a:blip r:embed + a:srcRect + a:grayscl)
# d['shc'] = {'acc#2': 'T:primary' | '#RRGGBB'}  ชิ้นที่ 3 ที่เป็นสีหลักของหน้า (ช่องสีของชุด + ลำดับ) เปลี่ยนหน้าตาแล้วไปหาชิ้นสีเดียวกันลำดับเดียวกัน
# BR['theme'] = {name, primary, secondary, accent, bg, text}  สีของไฟล์: ทับช่องสีของชุด (eng.P) ก่อนวาด + theme1.xml clrScheme + สีตรงที่ตรงธีมเป็น schemeClr
import hashlib as _hl
PREPSRC = {}                                               # แฮชของไบต์รูปที่ _prep ทำ → (ไฟล์ต้นทาง, โหมด bw/duo/dim)
_prep0 = base._prep
def _blankimg(mode):
    """ใบ 055 กรอบรูปว่างให้ลูกค้าใส่รูปเอง: พื้นเทาอ่อน + ไอคอนรูปภาพกลางกรอบ (กรอบเป็น p:pic เดิม แตะ "เปลี่ยนรูป" ได้)
    dim:f (ปกตัวขาวบนรูป) ทำให้เข้มตามเดิม ไม่ใช้ autocontrast ของ bw (พื้นเรียบจะกลายเป็นขาวดำจัด)"""
    from PIL import Image, ImageDraw
    W, H = 1600, 1000; f = float(mode[4:]) if str(mode or '').startswith('dim:') else 1
    bg, ic = tuple(int(v * f) for v in (226, 226, 222)), tuple(int(v * f) for v in (196, 196, 192))
    im = Image.new('RGB', (W, H), bg); d = ImageDraw.Draw(im); u = 30; x0, y0 = W / 2 - 4 * u, H / 2 - 3 * u
    d.rounded_rectangle((x0, y0, x0 + 8 * u, y0 + 6 * u), radius=u * .6, outline=ic, width=int(u * .45))
    d.polygon([(x0 + 1.2 * u, y0 + 4.8 * u), (x0 + 3.4 * u, y0 + 2.4 * u), (x0 + 5 * u, y0 + 4 * u), (x0 + 5.8 * u, y0 + 3.2 * u), (x0 + 6.8 * u, y0 + 4.8 * u)], fill=ic)
    d.ellipse((x0 + 5.2 * u, y0 + 1.1 * u, x0 + 6.4 * u, y0 + 2.3 * u), fill=ic)
    b = io.BytesIO(); im.save(b, 'JPEG', quality=80); return b.getvalue(), (W, H)
def _prep_spy(path, mode):
    if path == eng.BLANK:
        if (path, mode) not in base._imgc:
            base._imgc[(path, mode)] = r = _blankimg(mode); PREPSRC[_hl.sha1(r[0]).hexdigest()] = (path, mode)
        return base._imgc[(path, mode)]
    hit = (path, mode) in base._imgc; r = _prep0(path, mode)
    if not hit: PREPSRC[_hl.sha1(r[0]).hexdigest()] = (path, mode)
    return r
base._prep = _prep_spy
PALETTES = [{"id": "orange-navy", "name": "ส้มกรมท่า", "primary": "CC4F10", "secondary": "1A1F4B", "accent": "F5C4AB", "bg": "F8F8F8", "text": "1A1F4B"}, {"id": "navy-gold", "name": "กรมท่าทอง", "primary": "5063C7", "secondary": "1A1F4B", "accent": "E0B038", "bg": "F8F8F8", "text": "1A1F4B"}, {"id": "green-lime", "name": "เขียวมะนาว", "primary": "0D7553", "secondary": "0E3B2C", "accent": "DCDD2A", "bg": "F2F1EC", "text": "0E3B2C"}, {"id": "red-black", "name": "แดงดำ", "primary": "E0193A", "secondary": "4A0F1C", "accent": "D9D9D9", "bg": "FFFFFF", "text": "0E0B0D"}, {"id": "charcoal-orange", "name": "เทาถ่านส้ม", "primary": "1C1C1C", "secondary": "444444", "accent": "F85A1E", "bg": "E9E9E6", "text": "1C1C1C"}, {"id": "violet", "name": "ม่วงสด", "primary": "6B4EF5", "secondary": "563EC4", "accent": "CFC4FF", "bg": "F8F6FF", "text": "14161A"}, {"id": "sea-blue", "name": "ฟ้าน้ำทะเล", "primary": "0077B6", "secondary": "0F2A38", "accent": "00C9A7", "bg": "EAF8F8", "text": "0F2A38"}]
ROLES = ('primary', 'secondary', 'accent', 'bg', 'text')
SLOT = {'primary': 'accent1', 'secondary': 'dk2', 'accent': 'accent2', 'bg': 'lt2', 'text': 'dk1'}       # ช่องใน theme1.xml
SCHEME = {'primary': 'accent1', 'secondary': 'tx2', 'accent': 'accent2', 'bg': 'bg2', 'text': 'tx1'}     # ชื่อที่ shape อ้าง (ผ่าน clrMap ของ master)
PK = ('acc', 'g1', 'g2', 'acc2', 'bg', 'ink', 'mute', 'panel')
ROLE0 = {}                                                 # สีเดิมของดีไซน์ (5 บทบาท) ของชุดที่ setpal ล่าสุด
ROLEK = {}                                                 # บทบาท → ช่อง eng.P ที่เป็นสีนั้น
def _hx(c): return str(c or '').lstrip('#').upper()[:6]
def _roles(P):
    """5 บทบาทจากพาเลตต์ของชุด (theme1.xml ของทุกชุดเป็นธีม Office ตั้งต้น 4F81BD ไม่ใช่สีของดีไซน์ จึงอ่านจาก eng.P)
    ชุดพื้นอ่อน: หลัก=acc รอง=g1 (ถ้าเท่าหลักใช้ g2 ไม่งั้น ink) เสริม=acc2 พื้น=bg ตัวอักษร=ink
    ชุดพื้นเข้ม (creativeclass brandkit): รอง=bg (หน้าเข้ม) พื้น=สีอ่อนของชุด (acc2/panel) ตัวอักษร=สีเข้มบนหน้าอ่อน (g1) เสริม=mute ถ้า acc2 เป็นพื้น"""
    g = lambda k: _hx(P.get(k)); pri = g('acc')
    if not P.get('dark'):
        sec = next((g(k) for k in ('g1', 'g2') if g(k) and g(k) != pri), g('ink'))
        return dict(primary=pri, secondary=sec, accent=g('acc2'), bg=g('bg'), text=g('ink'))
    lt = next((g(k) for k in ('acc2', 'panel') if g(k) and eng._lm(g(k)) > 0.5), 'FFFFFF')
    return dict(primary=pri, secondary=g('bg'), accent=g('mute') if lt == g('acc2') else g('acc2'), bg=lt, text=g('g1') if g('g1') not in (pri, '') else g('bg'))
def _rolek(P, R):
    out = {r: [] for r in ROLES}
    for k in PK:
        r = next((r for r in ROLES if R[r] == _hx(P.get(k))), None)
        if r: out[r].append(k)
    return out
_mixc = lambda a, b, t: base.mix(_hx(a), _hx(b), t)
def _theme_apply(th):
    """ทับช่องสีของชุดด้วยสีของไฟล์ที่ลูกค้าเลือก ช่องที่ไม่ใช่ 5 บทบาท (mute panel g2) คิดใหม่จากสีที่เปลี่ยน"""
    P = eng.P; P0 = dict(P); new = {r: _hx(th.get(r)) or ROLE0[r] for r in ROLES}; ch = {r for r in ROLES if new[r] != ROLE0[r]}
    if not ch: return
    for r in ROLES:
        for k in ROLEK[r]: P[k] = new[r]
    used = {k for r in ROLES for k in ROLEK[r]}
    if not P0.get('dark'):
        if 'mute' not in used and ch & {'text', 'bg'}: P['mute'] = _mixc(new['text'], new['bg'], 0.45)
        if 'panel' not in used and ch & {'text', 'bg'}: P['panel'] = _mixc(new['bg'], new['text'], 0.05)
        if 'g2' not in used and 'primary' in ch: P['g2'] = new['primary']
    else:
        if 'panel' not in used and 'secondary' in ch: P['panel'] = _mixc(new['secondary'], 'FFFFFF', 0.06)
        if 'ink' not in used and 'secondary' in ch: P['ink'] = max(('FFFFFF', new['text']), key=lambda c: eng.cratio(c, new['secondary']))
        if 'g2' not in used and 'primary' in ch: P['g2'] = new['primary']
    P['dark'] = int(eng._lm(_hx(P['bg'])) < 0.18)
    base.T.update(ink=P['ink'], mute=P['mute'], bg=P['bg'], acc=P['acc'])
_setpal0 = eng.setpal
def _setpal(name, font='plex', head=None):
    _setpal0(name, font, head)
    ROLE0.clear(); ROLE0.update(_roles(eng.P)); ROLEK.clear(); ROLEK.update(_rolek(eng.P, ROLE0))
    if BR.get('theme'): _theme_apply(BR['theme'])
eng.setpal = _setpal
def roles_now():
    """5 บทบาทที่ใช้อยู่ (หลังสีของไฟล์)"""
    th = BR.get('theme') or {}
    return {r: _hx(th.get(r)) or ROLE0.get(r, '000000') for r in ROLES}
def theme_info(M):
    """แผงสีของไฟล์: สีเดิมของดีไซน์ สีที่ใช้อยู่ ชื่อชุด ชุดสีพร้อมใช้ 7 ชุด"""
    eng.setpal(M['pal'], M.get('font', 'plex'), M.get('head'))
    return dict(orig=dict(ROLE0), cur=roles_now(), name=(BR.get('theme') or {}).get('name', ''), pal=PALETTES, keys={r: list(v) for r, v in ROLEK.items()})
def set_theme(th):
    """None = กลับเป็นสีเดิมของดีไซน์ (ชิ้นที่ลูกค้าตั้งสีเองยังอยู่ใน d['shc'])"""
    if th: BR['theme'] = {**{r: _hx(th[r]) for r in ROLES if th.get(r)}, 'name': th.get('name', '')}
    else: BR.pop('theme', None)
    return 'ok'
def _colhex(c):
    c = str(c)
    if c.startswith('T:'): return roles_now().get(c[2:], '000000')
    return _rgb(c)
def _recolour(slide, old2new):
    """สีตรงของดีไซน์ที่ layout เขียนเป็นตัวเลขตายตัว (ไม่ผ่าน eng.P) แต่ตรงสีเดิมของบทบาท → สีใหม่"""
    if not old2new: return
    for e in slide.shapes._spTree.iter('{http://schemas.openxmlformats.org/drawingml/2006/main}srgbClr'):
        v = old2new.get((e.get('val') or '').upper())
        if v: e.set('val', v)

_mono = lambda mode: str(mode or '').startswith(('bw', 'duo:'))   # ดีไซน์ภาพขาวดำ/สองสี: รูปลูกค้าตั้งต้นขาวดำ (a:grayscl) สวิตช์สีจริงได้ (ไอซ์ข้อ 2)
def _blip(s):
    return s._element.find('.//{http://schemas.openxmlformats.org/drawingml/2006/main}blip')
def _dpics(slide):
    """รูปในดีไซน์ของหน้า [(shape, (ไฟล์, โหมด))] ตามลำดับที่วาด"""
    out = []
    for s in slide.shapes:
        if getattr(s, 'shape_type', None) != 13 or s.name.startswith('add.') or s.name == 'Logo': continue
        b = _blip(s)
        if b is None or b.find('.//{http://schemas.microsoft.com/office/drawing/2016/SVG/main}svgBlip') is not None: continue   # ไอคอน
        try: src = PREPSRC.get(_hl.sha1(s.image.blob).hexdigest())
        except Exception: src = None
        if src and os.path.abspath(src[0]).startswith(os.path.abspath(eng.IMG) + os.sep): out.append((s, src))
    return out
_ASP = {}
def _aspect(s):
    from PIL import Image
    b = s.image.blob; h = _hl.sha1(b).hexdigest()
    if h not in _ASP: w_, h_ = Image.open(io.BytesIO(b)).size; _ASP[h] = round(w_ / h_, 4)
    return _ASP[h]
def _ovr(a, b):
    w = min(a.left + a.width, b.left + b.width) - max(a.left, b.left); h = min(a.top + a.height, b.top + b.height) - max(a.top, b.top)
    return max(0, w) * max(0, h)
def _decor(slide, p):
    """พื้นตกแต่งที่ผูกกับรูป (กรอบหลังรูป แผ่นย้อมสีทับรูป ครึ่งวงกลมที่ซ้อนรูป): ไม่มีคำ ไม่ใช่รูป วาดติดกับรูป (ห่างไม่เกิน 3 ชั้น)
    และซ้อนรูปอย่างน้อย 25% ของตัวเอง หรือเป็นกรอบที่ครอบรูปพอดี (ใหญ่กว่ารูปไม่เกิน 1.6 เท่า)  ponytail: เดาจากรูปทรง ถ้าลบผิดชุดไหนค่อยติดป้ายใน layout"""
    shs = list(slide.shapes); i = shs.index(p); pa = p.width * p.height; out = []
    sw, sh_ = slide.part.package.presentation_part.presentation.slide_width, slide.part.package.presentation_part.presentation.slide_height
    for j in range(max(0, i - 3), min(len(shs), i + 4)):
        o = shs[j]
        if o is p or getattr(o, 'shape_type', None) in (13, 3) or (o.has_text_frame and o.text_frame.text.strip()) or o.name.startswith('add.') or o.name in ('Logo', 'PageNo'): continue
        oa = o.width * o.height
        if not oa or oa >= sw * sh_ * 0.6: continue
        if any(t is not o and t.has_text_frame and t.text_frame.text.strip() and _inside(t, o) for t in shs): continue   # การ์ดที่มีคำ = ของอื่น
        if _ovr(o, p) >= 0.25 * oa or (_inside(p, o) and oa <= pa * 1.6): out.append(o)
    return out
def _cover(fw, fh, iw, ih, c=None):
    """srcRect แบบเต็มกรอบไม่ยืด (cover) จุดกลาง c = (x, y) 0..1 ของรูป  คืน [l, t, r, b] สัดส่วน"""
    fa, ia = fw / fh, iw / ih
    vw, vh = (fa / ia, 1.0) if ia > fa else (1.0, ia / fa)
    cx, cy = c or (0.5, 0.5)
    l = min(max(cx - vw / 2, 0), 1 - vw); t = min(max(cy - vh / 2, 0), 1 - vh)
    return [round(l, 5), round(t, 5), round(1 - vw - l, 5), round(1 - vh - t, 5)]
def _setcrop(s, crop):
    l, t, r, b = crop; s.crop_left, s.crop_top, s.crop_right, s.crop_bottom = l, t, r, b
def _getcrop(s):
    return [round(float(x), 5) for x in (s.crop_left, s.crop_top, s.crop_right, s.crop_bottom)]
def _imgbytes(o):
    if o.get('img') is not None:
        p = '%s/%x' % (USERIMG, int(o['img']))
        return open(p, 'rb').read() if os.path.exists(p) else None
    if o.get('src'):
        p = os.path.join(eng.IMG, o['src'])
        return base._prep(p, None)[0] if os.path.exists(p) else None
    return None
def apply_dpics(slide, d, dps):
    """d['dpic'] → p:pic ตัวเดิม: เปลี่ยนแค่ a:blip r:embed + a:srcRect (+ a:grayscl) / ลบ = รูป + พื้นตกแต่งที่ผูกกับรูป"""
    from PIL import Image
    A = '{http://schemas.openxmlformats.org/drawingml/2006/main}'
    gone = []
    for n, (s, (path, mode)) in enumerate(dps):
        o = (d.get('dpic') or {}).get(str(n))
        if not o: continue
        if o.get('del'): gone.append(s); continue
        data = _imgbytes(o)
        if data is not None:
            iw, ih = Image.open(io.BytesIO(data)).size
            b = _blip(s); old = b.get('{http://schemas.openxmlformats.org/officeDocument/2006/relationships}embed')
            _ip, rid = slide.part.get_or_add_image_part(io.BytesIO(data)); b.set('{http://schemas.openxmlformats.org/officeDocument/2006/relationships}embed', rid)
            if old and old != rid: slide.part.drop_rel(old)
            _setcrop(s, o.get('crop') or _cover(s.width, s.height, iw, ih))
        elif o.get('crop'): _setcrop(s, o['crop'])
        b = _blip(s)
        for g in b.findall(A + 'grayscl'): b.remove(g)
        if data is not None and int(o.get('gray', 1 if _mono(mode) else 0)):
            g = b.makeelement(A + 'grayscl', {}); ext = b.find(A + 'extLst')
            (ext.addprevious(g) if ext is not None else b.append(g))
    for s in gone:
        for o in _decor(slide, s) + [s]:
            if o._element.getparent() is not None: o._element.getparent().remove(o._element)
def _fillclr(s):
    """srgbClr ของพื้นทึบ (ไม่มี = None) และความทึบ"""
    A = '{http://schemas.openxmlformats.org/drawingml/2006/main}'
    sp = s._element.find('{http://schemas.openxmlformats.org/presentationml/2006/main}spPr')
    sf = sp.find(A + 'solidFill') if sp is not None else None
    c = sf.find(A + 'srgbClr') if sf is not None else None
    if c is None: return None, 1
    al = c.find(A + 'alpha'); return c.get('val').upper(), (int(al.get('val')) / 1e5 if al is not None else 1)
def _colshapes(slide):
    """รูปทรงที่มีสีพื้นที่ลูกค้าเปลี่ยนสีได้ → [(shape, คีย์ 'acc#2', สี)]  ข้ามพื้นหลังเต็มหน้า ชิ้นจาง (< 50%) ชิ้นเล็กกว่า 12px"""
    sw, sh_ = slide.part.package.presentation_part.presentation.slide_width, slide.part.package.presentation_part.presentation.slide_height
    hx2k = {}
    for k in PK:
        v = _hx(eng.P.get(k))
        if v: hx2k.setdefault(v, k)
    out, rank = [], {}
    for s in slide.shapes:
        if getattr(s, 'shape_type', None) in (13, 3, 6, 19) or s.name.startswith('add.') or s.name in ('Logo', 'PageNo') or getattr(s, 'has_chart', False): continue
        if s._element.tag != '{http://schemas.openxmlformats.org/presentationml/2006/main}sp': continue
        c, al = _fillclr(s)
        if not c or al < 0.5 or s.width * s.height >= sw * sh_ * 0.9 or min(s.width / sw * 960, s.height / sh_ * 540) < 12: continue
        role = hx2k.get(c, 'x' + c); r = rank.get(role, 0); rank[role] = r + 1
        out.append((s, '%s#%d' % (role, r), c))
    return out
def _paint(s, col):
    """สีพื้นของรูปทรง: 'T:primary' = a:schemeClr ตามธีม / '#hex' = a:srgbClr (คงความทึบเดิม)"""
    A = '{http://schemas.openxmlformats.org/drawingml/2006/main}'
    sp = s._element.find('{http://schemas.openxmlformats.org/presentationml/2006/main}spPr'); sf = sp.find(A + 'solidFill'); old = list(sf)[0]
    kids = list(old); new = sf.makeelement(A + ('schemeClr' if str(col).startswith('T:') else 'srgbClr'), {'val': SCHEME[col[2:]] if str(col).startswith('T:') else _rgb(col)})
    for x in kids: new.append(x)
    sf.replace(old, new)
def _flip_text(slide, s, fill):
    """ตัวอักษรบนชิ้นที่เปลี่ยนสี: ต่างสีต่ำกว่า 4.5:1 → ขาว/ดำ (ค่าที่ลงไฟล์จริง)"""
    from pptx.dml.color import RGBColor
    ink = max(('FFFFFF', '15151A'), key=lambda c: eng.cratio(c, fill))
    for t in [x for x in slide.shapes if x.has_text_frame and x.text_frame.text.strip() and (x is s or _inside(x, s))]:
        for p in t.text_frame.paragraphs:
            for r in p.runs:
                try: cur = str(r.font.color.rgb) if r.font.color and r.font.color.type is not None else _hx(eng.P['ink'])
                except Exception: cur = _hx(eng.P['ink'])
                if eng.cratio(cur, fill) < 4.5: r.font.color.rgb = RGBColor.from_string(ink)
def apply_shc(slide, d, cols):
    shc = d.get('shc') or {}
    for s, key, c in cols:
        col = shc.get(key)
        if not col: continue
        _paint(s, col); _flip_text(slide, s, _colhex(col))
def set_dpic(items, idx, n, **kw):
    """รูปในดีไซน์ที่ N: img/src (เปลี่ยนรูป ล้าง crop) crop gray del  None = ลบค่านั้น  reset=True = กลับรูปเดิมของดีไซน์"""
    name, d = items[idx]; m = dict(d.get('dpic') or {}); o = {} if kw.pop('reset', False) else dict(m.get(str(n)) or {})
    if 'img' in kw or 'src' in kw: o.pop('img', None); o.pop('src', None); o.pop('crop', None)
    for k, v in kw.items():
        if v is None: o.pop(k, None)
        else: o[k] = v
    if o: m[str(n)] = o
    else: m.pop(str(n), None)
    d2 = {k: v for k, v in d.items() if k != 'dpic'}
    if m: d2['dpic'] = m
    items[idx] = (name, d2); return 'ok'
def set_shc(pairs, items, col):
    """สีชิ้น: pairs = [[idx, คีย์], ...] (ชิ้นนี้ = 1 คู่ / ทุกชิ้นสีเดียวกัน = ทุกคู่ในไฟล์) col None = กลับสีดีไซน์"""
    for idx, key in pairs:
        name, d = items[idx]; m = dict(d.get('shc') or {})
        if col: m[key] = col
        else: m.pop(key, None)
        d2 = {k: v for k, v in d.items() if k != 'shc'}
        if m: d2['shc'] = m
        items[idx] = (name, d2)
    return 'ok'
def _scheme_fills(slide, keep=()):
    """สีตรงของรูปทรงที่ตรงสีของไฟล์ → a:schemeClr (เปลี่ยนชุดสีใน PowerPoint แล้วตาม) ยกเว้นชิ้นที่ลูกค้าตั้งรหัสสีเอง (keep = shape_id)"""
    R = roles_now(); h2s = {}
    for r in ROLES: h2s.setdefault(R[r], SCHEME[r])
    A = '{http://schemas.openxmlformats.org/drawingml/2006/main}'
    for s in slide.shapes:
        if s.shape_id in keep or s._element.tag != '{http://schemas.openxmlformats.org/presentationml/2006/main}sp': continue
        sp = s._element.find('{http://schemas.openxmlformats.org/presentationml/2006/main}spPr')
        sf = sp.find(A + 'solidFill') if sp is not None else None
        c = sf.find(A + 'srgbClr') if sf is not None else None
        if c is None or (c.get('val') or '').upper() not in h2s: continue
        new = sf.makeelement(A + 'schemeClr', {'val': h2s[c.get('val').upper()]})
        for x in list(c): new.append(x)
        sf.replace(c, new)
def fill_hex(sh):
    """สีพื้นของรูปทรงในไฟล์ที่วาดแล้ว (srgbClr หรือ schemeClr ตามสีของไฟล์) เป็นรหัสสี ให้เทสต์/ตัวตรวจอ่าน"""
    A = '{http://schemas.openxmlformats.org/drawingml/2006/main}'
    sf = sh._element.find('.//' + A + 'solidFill')
    if sf is None or not len(sf): return None
    c = sf[0]
    if c.tag == A + 'srgbClr': return c.get('val').upper()
    inv = {v: k for k, v in SCHEME.items()}
    return roles_now().get(inv.get(c.get('val'), ''), None)
def write_theme(prs):
    """theme1.xml a:clrScheme = 5 บทบาทที่ใช้อยู่ (Design > Variants > Colors / รูปทรงใหม่ได้สีหลัก)"""
    R = roles_now(); nm = (BR.get('theme') or {}).get('name') or 'Slide Studio'
    for part in prs.part.package.iter_parts():
        if not str(part.partname).startswith('/ppt/theme/theme'): continue
        x = part.blob.decode('utf8')
        x = re.sub(r'<a:clrScheme name="[^"]*"', '<a:clrScheme name="%s"' % esc_xml(nm), x, count=1)
        for r in ROLES: x = re.sub(r'(<a:%s>).*?(</a:%s>)' % (SLOT[r], SLOT[r]), lambda m: m.group(1) + '<a:srgbClr val="%s"/>' % R[r] + m.group(2), x, count=1, flags=re.S)
        part._blob = x.encode('utf8')
def esc_xml(t): return str(t).replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;').replace('"', '&quot;')

def _match(slide, d):
    """กล่องข้อความ/ช่องตารางบนสไลด์ ↔ ช่องใน d จับคู่ด้วยข้อความตรงตัว ตามลำดับ shape  ตัวเดียวที่ boxmap และ apply_moves ใช้ (ห้ามมีตัวจับคู่สองชุด)
    ทุกคำบนสไลด์มาจาก d อยู่แล้ว (scrub ลบที่เหลือ) ไม่ต้องรู้โครงของแต่ละ layout
    yield (shape, path, x, y, w, h, text_frame, cell, path แรกของคำนี้)  หน่วย EMU"""
    want = {}
    for p, t in _leaves(d):
        if t.strip() and p[0] != 'add': want.setdefault(t.strip(), []).append(list(p))
    used = {}
    def hit(t):
        t = t.replace('\u00a0', ' ')                     # เลขลำดับที่ผูกด้วยเว้นวรรคไม่ตัดบรรทัด = คำเดิมของลูกค้า
        ps = want.get(t)
        if not ps: return None
        k = used.get(t, 0); used[t] = k + 1
        return ps[min(k, len(ps) - 1)], ps[0]
    for s in slide.shapes:
        if s.name.startswith('add.') and s.has_text_frame:   # ใบ 022 ข้อความที่ลูกค้าเพิ่ม: จับด้วยชื่อ
            if _elof(d, s.name): continue                 # ใบ 027 องค์ประกอบ (ไอคอน แผนที่ ลายพื้น) ไม่มีคำ
            pa = ['add', int(s.name[4:]), 't']; yield s, pa, s.left, s.top, s.width, s.height, s.text_frame, False, pa; continue
        if getattr(s, 'has_table', False) and s.has_table:
            tb, y = s.table, s.top
            for row in tb.rows:
                x = s.left
                for j, cell in enumerate(row.cells):
                    h = hit(cell.text_frame.text.strip())
                    if h: yield s, h[0], x, y, tb.columns[j].width, row.height, cell.text_frame, True, h[1]
                    x += tb.columns[j].width
                y += row.height
        elif s.has_text_frame:
            h = hit(s.text_frame.text.strip())
            if h: yield s, h[0], s.left, s.top, s.width, s.height, s.text_frame, False, h[1]

def _solid(x):
    try: return x.fill.type == 1
    except Exception: return False

def _cards(slide, sw, sh_, tol=18288, panels=False):
    """การ์ด = shape พื้นทึบ ไม่มีข้อความ เล็กกว่า 25% ของสไลด์ ไม่มีรูปข้างใน ไม่ชิดขอบสไลด์ -> ลากแล้วการ์ดไปพร้อมของข้างใน
    panels=True: แผงฉากหลัง (ใหญ่กว่า 25% หรือมีรูปข้างใน) -> กล่องบนแผงย้ายเดี่ยว แผงอยู่ที่เดิม / บนปกล็อก (slide-judge 30 ต.ค.)
    ponytail: เดาจากรูปทรง ไม่ติดป้ายต่อ layout ถ้าจับผิดชุดไหนค่อยติดป้ายเฉพาะชุดนั้น"""
    pics = [x for x in slide.shapes if getattr(x, 'shape_type', None) == 13]
    out = []
    for x in slide.shapes:
        if not _solid(x) or (x.has_text_frame and x.text_frame.text.strip()) or x.name.startswith('add.'): continue   # ใบ 027 รูปทรงที่ลูกค้าเพิ่มไม่ใช่การ์ดของดีไซน์
        if not (x.left > tol and x.top > tol and x.left + x.width < sw - tol and x.top + x.height < sh_ - tol) or x.width * x.height >= sw * sh_ * 0.6: continue
        big = x.width * x.height >= sw * sh_ * 0.25 or any(_inside(p, x) for p in pics)
        if big == panels: out.append(x)
    return out

def _inside(o, c, tol=18288):
    return c.left - tol <= o.left and c.top - tol <= o.top and o.left + o.width <= c.left + c.width + tol and o.top + o.height <= c.top + c.height + tol

NOCARD = ('add', 't', 't1', 't2')                       # ใบ 042 หัวเรื่องย้าย/ย่อขยาย/หมุนเดี่ยวแบบ Canva ไม่พาการ์ดไป (ปก coop-b3 หัวเรื่องบนแผงขาว 23% ของสไลด์)

def _card(cards, s, p=None):
    if p and p[0] in NOCARD: return None
    c = [x for x in cards if x.shape_id != s.shape_id and _inside(s, x)]
    return min(c, key=lambda x: x.width * x.height) if c else None

LOCKP = ('rows', 'head', 'cats')                          # ช่องข้อมูลตาราง/กราฟ: พิมพ์ได้ ย้ายไม่ได้ (ใบ 017 รอบ 1)

def apply_moves(slide, d, sw, sh_):
    """d['mv'] = {'items.2': [x, y, w, h]} หน่วย 960×540 (ลูกค้าลาก/ย่อขยายบนเว็บ) → ย้าย shape จริง หนีบไว้ในสไลด์
    กล่องบนการ์ด: การ์ด + ทุกอย่างในการ์ดเลื่อนเท่ากัน ขนาดไม่เปลี่ยน  คืน shape_id ที่ย้าย (overflow ข้ามกฎชนของกล่องพวกนี้)"""
    mv, moved = d.get('mv'), set()
    if not mv: return moved
    from pptx.util import Emu
    fx, fy = sw / 960, sh_ / 540
    cards = _cards(slide, sw, sh_)
    for s, p, *_r in list(_match(slide, d)):
        r = mv.get('.'.join(map(str, p)))
        if not r or _r[5] or p[0] in LOCKP: continue     # ตาราง (ทั้งตารางจริงและแถวที่วาดเป็นกล่อง) ย้ายไม่ได้
        X, Y, W, H = r[0] * fx, r[1] * fy, r[2] * fx, r[3] * fy
        c = _card(cards, s, p)
        if c is not None:
            grp = [c] + [o for o in slide.shapes if o.shape_id != c.shape_id and _inside(o, c)]
            dx = int(round(max(-c.left, min(X - s.left, sw - c.left - c.width))))
            dy = int(round(max(-c.top, min(Y - s.top, sh_ - c.top - c.height))))
            for o in grp: o.left, o.top = Emu(o.left + dx), Emu(o.top + dy); moved.add(o.shape_id)
        else:
            W, H = min(max(W, fx), sw), min(max(H, fy), sh_)
            s.left, s.top = Emu(int(round(min(max(X, 0), sw - W)))), Emu(int(round(min(max(Y, 0), sh_ - H))))
            s.width, s.height = Emu(int(round(W))), Emu(int(round(H)))
            moved.add(s.shape_id)
    for key, r in mv.items():                             # ใบ 026 รูปในดีไซน์ (กรอบเดิม ย้าย/ย่อขยายคงสัดส่วน)
        s = _dpshape(slide, int(key.split('.')[1])) if key.startswith('dpic.') else None
        if s is None: continue
        W, H = min(max(r[2] * fx, fx), sw), min(max(r[3] * fy, fy), sh_)
        s.left, s.top = Emu(int(round(min(max(r[0] * fx, 0), sw - W)))), Emu(int(round(min(max(r[1] * fy, 0), sh_ - H))))
        s.width, s.height = Emu(int(round(W))), Emu(int(round(H))); moved.add(s.shape_id)
    return moved

def boxmap(slide, d, sw, sh_):
    """กล่องข้อความบนสไลด์ที่วาดแล้ว → ช่องใน d ที่มันมา (หน่วย 960×540)
    can = ย้ายได้ (ทุกกล่องยกเว้นช่องตาราง/กราฟ ใบ 030) / g, gi = กรอบการ์ดที่ย้ายไปด้วยกัน / m = ลูกค้าย้ายแล้ว (มีปุ่มคืนตำแหน่งเดิม)
    ponytail: ข้อความที่ layout แยกเป็นหลายกล่อง (เลข + หน่วย) หรืออยู่ในกราฟ ไม่มีกล่อง แก้บนจอไม่ได้"""
    fx, fy = 960 / sw, 540 / sh_
    cards, mvd, out = _cards(slide, sw, sh_), d.get('mv') or {}, []
    for s, p_, x, y, w, h, tf, cell, p0 in _match(slide, d):
        r = next((r for p in tf.paragraphs for r in p.runs if r.font.size), None)
        pt = r.font.size.pt if r else 18
        lh = pt * 1.25 / 72 * 914400
        key = '.'.join(map(str, p_)); f_ = (d.get('fsz') or {}).get(key); u_ = (d.get('usz') or {}).get(key); ff_ = (d.get('ffam') or {}).get(key)
        b = dict(p=p_, **({'f': f_} if f_ else {}), **({'u': u_} if u_ else {}), **({'ff': ff_} if ff_ else {}), x=round(x * fx, 1), y=round(y * fy, 1), w=round(w * fx, 1), h=round(h * fy, 1),
                 pt=round(pt, 1), multi=p0[0] not in ('t', 't1') and (h / lh >= 1.65 or '\n' in tf.text))
        b['fm'] = _fmt_now(tf, cell)
        if not cell: b['zi'] = list(slide.shapes).index(s)    # ลำดับชั้น (0 = ล่างสุด) ให้แผงเลเยอร์
        if key in (d.get('rot') or {}): b['rot'] = d['rot'][key]
        # ใบ 019: fm = ค่าที่วาดจริง (แถบแต่งข้อความแสดงสถานะ)
        if key in (d.get('tfm') or {}): b['tf'] = 1
        if not cell and p_[0] not in LOCKP:
            c = _card(cards, s, p_)
            if c is not None: b.update(g=[round(c.left * fx, 1), round(c.top * fy, 1), round(c.width * fx, 1), round(c.height * fy, 1)], gi=c.shape_id)
            b['can'] = 1                                   # ใบ 030 ไอซ์ "text เดิมของสไลด์กดแล้วปรับไม่ได้ทำให้ได้เหมือนกัน": ทุกกล่องของดีไซน์ (ยกเว้นตาราง/กราฟ)
            if p_[0] == 'add': b['add'] = 1
            if p_[0] == 'add' and (_get(d, p_[:2]) or {}).get('ns'):
                b['ns'] = 1                                # ใบ 027 รูปทรงมีข้อความ: กรอบไม่กอดคำ
                if 'ph' in b and _get(d, p_[:2])['ns'].get('hint'): b['ph'] = _get(d, p_[:2])['ns']['hint']
            if p_[0] == 'add' and not str(_get(d, p_)).strip(): b['ph'] = ADDPH[int(_get(d, p_[:2]).get('v', 2)) % 3]
            if key in mvd: b['m'] = 1
        if key in (d.get('lock') or {}): b['lk'] = 1; b.pop('can', None)   # ล็อก (ใบ 019b): ย้าย ย่อขยาย หมุน ชั้น แก้คำ ไม่ได้จนกว่าจะปลด
        out.append(b)
    shs = list(slide.shapes)
    for s in shs:                                              # ใบ 022 รูปที่ลูกค้าเพิ่ม: กล่องไม่มีคำ (pic) ย้าย ย่อขยายคงสัดส่วน หมุน ล็อก ชั้น
        el = _elof(d, s.name) if s.name.startswith('add.') else None   # ใบ 027 องค์ประกอบ = แบบเดียวกับรูปที่เพิ่ม
        if not (s.name.startswith('add.') and (getattr(s, 'shape_type', None) == 13 or el)): continue
        key = s.name; b = dict(p=['add', int(key[4:])], pic=1, add=1, x=round(s.left * fx, 1), y=round(s.top * fy, 1), w=round(s.width * fx, 1), h=round(s.height * fy, 1), pt=18, multi=False, fm={}, zi=shs.index(s), can=1)
        if el: b['el'] = el.get('k'); b.update({'bg': 1} if el.get('k') == 'pat' else {})
        if key in (d.get('rot') or {}): b['rot'] = d['rot'][key]
        if key in mvd: b['m'] = 1
        if key in (d.get('lock') or {}): b['lk'] = 1; b.pop('can', None)
        out.append(b)
    dm = getattr(slide.part, '_d2s_dp', {})                # ใบ 026 รูปในดีไซน์: แถบเดียวกับรูปที่เพิ่ม + ปรับจุดที่เห็น
    for s in shs:
        if s.shape_id not in dm or s._element.getparent() is None: continue
        n, mode, ar, rel = dm[s.shape_id]; key = 'dpic.%d' % n; o = (d.get('dpic') or {}).get(str(n)) or {}
        b = dict(p=['dpic', n], pic=1, dp=1, x=round(s.left * fx, 1), y=round(s.top * fy, 1), w=round(s.width * fx, 1), h=round(s.height * fy, 1), pt=18, multi=False, fm={}, zi=shs.index(s), can=1,
                 crop=_getcrop(s), ar=ar, bw=int(_mono(mode)), rep=int('img' in o or 'src' in o), gray=int(bool(_blip(s).findall('{http://schemas.openxmlformats.org/drawingml/2006/main}grayscl'))))
        if o.get('src'): b['src'] = o['src']
        if o.get('img') is not None: b['img'] = '%x' % int(o['img'])
        b['orig'] = rel                                   # รูปเดิมของดีไซน์ (ติ๊ก ใช้อยู่ ในตัวเลือก)
        if key in (d.get('rot') or {}): b['rot'] = d['rot'][key]
        if key in mvd: b['m'] = 1
        if key in (d.get('lock') or {}): b['lk'] = 1; b.pop('can', None)
        out.append(b)
    cm = getattr(slide.part, '_d2s_col', {})
    objs = [b for b in out if b.get('dp')]               # ใบ 026 รูปทรงที่มีสีพื้น: แตะแล้วเปลี่ยนสี (ล่างสุดก่อน = กล่องบนสุดอยู่ท้าย)
    for s in shs:
        if s.shape_id not in cm or s._element.getparent() is None: continue
        key, c = cm[s.shape_id]
        out.append(dict(p=['shc', key], shp=1, x=round(s.left * fx, 1), y=round(s.top * fy, 1), w=round(s.width * fx, 1), h=round(s.height * fy, 1), pt=18, multi=False, fm={}, zi=shs.index(s), col='#' + c,
                        **({'own': (d.get('shc') or {})[key]} if key in (d.get('shc') or {}) else {})))
    objs += [b for b in out if b.get('shp')]
    return [b for b in out if b.get('bg')] + [b for b in out if not (b.get('dp') or b.get('shp') or b.get('bg'))] + sorted(objs, key=lambda b: b['zi'])   # ใบ 027 ลายพื้นเต็มหน้า: ล่างสุดของชั้นแตะ (ไม่บังกล่องอื่น)   # ชิ้นของดีไซน์ไว้ท้าย เรียงตามชั้น (ชั้นบนแตะโดนก่อน)

def move_box(items, idx, path, rect, M, resize=False, drop=()):
    """ลูกค้าลากกล่องบนเว็บ (ใบ 017): rect = [x, y, w, h] หน่วย 960×540 / None = คืนตำแหน่งเดิม  drop = กล่องอื่นบนการ์ดเดียวกัน (ตำแหน่งเก่าของการ์ดทิ้ง)
    ย้ายเฉย ๆ ไม่วัดใหม่ (บรรทัดเท่าเดิม) / ปรับขนาดหรือคืนตำแหน่ง: วัดใหม่ที่ขนาดดีไซน์ ย่อเองถึง 80% แบบ edit_text ยังล้น = คำครบ ติด _ov
    คืน (สถานะ ok/shrink/over, จำนวนกล่องที่ย้ายในหน้า)"""
    name, d = items[idx]
    key = '.'.join(map(str, path)); mv = {k: v for k, v in (d.get('mv') or {}).items() if k != key and k not in drop}
    if rect is not None: mv[key] = [round(float(v), 1) for v in rect]
    d2 = {k: v for k, v in d.items() if k != 'mv'}
    if mv: d2['mv'] = mv
    st = 'ok'
    if resize or rect is None:
        fz = {k: v for k, v in (d2.get('fsz') or {}).items() if k != key}
        d2 = {k: v for k, v in d2.items() if k not in ('fsz', '_ov')}
        if fz: d2['fsz'] = fz
        bad = overflow(name, d2, M)
        if bad:
            st = 'over'
            for f in (0.95, 0.9, 0.85, 0.8):
                dz = {**d2, 'fsz': {**fz, key: f}}; bad = overflow(name, dz, M)
                if not bad: d2, st = dz, 'shrink'; break
            else: d2 = {**dz, '_ov': 1}                     # ยังล้นที่ 80%: เก็บกรอบตามที่ปรับ คำครบทุกตัว ป้ายล้น
    items[idx] = (name, d2)
    return st, len(mv)

def _get(v, path):
    for k in path: v = v[k]
    return v

def _put(v, path, new):
    """คืนสำเนาที่เปลี่ยนแค่ช่องเดียว (tuple ยังเป็น tuple)"""
    if not path: return new
    k, rest = path[0], path[1:]
    if isinstance(v, dict): return {**v, k: _put(v[k], rest, new)}
    xs = list(v); xs[k] = _put(xs[k], rest, new)
    return tuple(xs) if isinstance(v, tuple) else xs

def _sub(v, old, new, hit, line=False, flat=False):
    """เปลี่ยนทุกข้อความที่ตรงกับคำเดิม (ไม่สนช่องว่าง/ขึ้นบรรทัด: หัวเรื่อง "ก\nข" กับข้อในสารบัญ "ก ข" คือคำเดียวกัน)  hit[0] นับจำนวนที่เปลี่ยน
    flat: ฝั่งสารบัญ ขึ้นบรรทัดในหัวเรื่อง = เว้นวรรค (ใบ 015 ux ข้อ H)
    raw (ข้อความเต็มของการ์ดตัวเลข ใช้ตอนลงเป็นรายการแทน) แทนเฉพาะส่วนที่ตรง"""
    if isinstance(v, str):
        if v == old or (old.strip() and v.split() == old.split()): hit[0] += 1; return new.replace('\n', ' ') if flat else new
        if line and '\n' in v and old in v.split('\n'):    # ชื่อหัวข้อเป็นบรรทัดหนึ่งในข้อความ (หัวข้อ+เนื้อในช่องเดียว) เปลี่ยนเฉพาะบรรทัดที่ตรงทั้งบรรทัด
            hit[0] += 1; return '\n'.join(new if x == old else x for x in v.split('\n'))
        return v
    if isinstance(v, (list, tuple)):
        xs = [_sub(x, old, new, hit, line, flat) for x in v]
        return tuple(xs) if isinstance(v, tuple) else xs
    if isinstance(v, dict):
        out = {}
        for k, x in v.items():
            if k in KEEP: out[k] = x
            elif k == 'raw' and len(old) > 1: out[k] = [r.replace(old, new) if old in r else r for r in x]
            else: out[k] = _sub(x, old, new, hit, line, flat)
        return out
    return v

def edit_text(items, cs, want, idx, path, new, M, dry=False, hint=None, force=False):
    """hint = [(pt, จำนวนบรรทัดที่เบราว์เซอร์ตัด)] ของกล่องที่พิมพ์ ต่อขนาดที่ลองย่อ (เว็บส่งมา) ตัดสินล้นด้วยค่ามากกว่าระหว่าง PIL กับเบราว์เซอร์
    force = ลูกค้าออกจากกล่องตอนยังล้น: ย่อตัวเองแล้ว ยังล้นก็เก็บคำครบทุกตัว (ห้ามตัด) หน้านั้นติดป้าย _ov"""
    LHINT.clear(); EXTRA.clear()
    if hint: LHINT[' '.join(str(new).split())] = [tuple(h) for h in hint] if isinstance(hint[0], (list, tuple)) else [tuple(hint)]
    try:
        r = _edit_text(items, cs, want, idx, path, new, M, dry, force)
        if not dry and isinstance(r, tuple) and r[0] == 'ok' and path and path[0] in ('rows', 'head') and items[idx][1].get('_samp'):   # ใบ 034 แก้ช่องตารางบนสไลด์แล้ว ไม่ใช่ข้อมูลตัวอย่างอีก (ไม่เตือนตอนบันทึก)
            items[idx] = (items[idx][0], {k: v for k, v in items[idx][1].items() if k != '_samp'})
        return r
    finally: LHINT.clear()

def _over_n(bad):
    """ยาวเกินประมาณกี่บรรทัด จากผลของ overflow ("..." 5/4 บรรทัด) ไม่มีตัวเลข = 0"""
    return max([int(a) - int(b) for a, b in (re.findall(r'(\d+)/(\d+) บรรทัด', ' '.join(bad)))] or [0])

def _edit_text(items, cs, want, idx, path, new, M, dry=False, force=False):
    """ลูกค้าแก้คำในกล่องหนึ่งของหน้า idx  คืน (สถานะ, ตามไปหน้าตาใหม่ได้ไหม)
    สถานะ ok / shrink (ย่อตัวลงให้พอดี: หัวเรื่องปก หรือกล่องนี้ถึง 80%) / over (ล้นกล่อง ไม่ force = ไม่เปลี่ยนอะไร / force = เก็บคำครบ ติด _ov ห้ามตัดคำเงียบ)
    ไม่ dry: แก้ items[idx] ช่องนั้น + ทุกข้อความเดิมใน cs (สารบัญกับหัวข้อยังตรงกัน) + want (เปลี่ยนหน้าตาแล้วคำใหม่ตามไป)
    ponytail: คำเดิมที่ซ้ำกันหลายที่ใน want/cs เปลี่ยนทั้งหมด หน้าอื่นยังโชว์คำเดิมจนกว่าจะจัดหน้านั้นใหม่"""
    name, d = items[idx]
    path = [p for p in path]
    if path[0] == 'add':                                     # ใบ 022 ข้อความที่ลูกค้าเพิ่ม: เปลี่ยนเฉพาะกล่องนี้ (กล่องโตตามบรรทัด ไม่มีล้น)
        if not dry: items[idx] = (name, _put(d, path, new))
        EXTRA['lines'] = 0; return 'ok', True
    old = _get(d, path)
    d2 = _sub(_put(d, path, new), old, new, [0]) if old.strip() else _put(d, path, new)   # คำเดียวกันในหน้าเดียวกันเปลี่ยนด้วย (เช่นหัวตารางที่ซ้ำหัวเรื่อง)
    if path[0] == 'cats' and isinstance(d2.get('rows'), list) and len(d2['rows']) > path[1] and d2['rows'][path[1]][0] == old:
        d2 = _put(d2, ['rows', path[1], 0], new)            # ป้ายกราฟกับแถวตารางเป็นคำเดียวกัน
    key = '.'.join(map(str, path)); fz = {k: v for k, v in (d2.get('fsz') or {}).items() if k != key}
    d2 = {k: v for k, v in d2.items() if k not in ('fsz', '_ov')}
    if fz: d2['fsz'] = fz                                    # กล่องนี้เริ่มวัดที่ขนาดดีไซน์ใหม่ (สั้นลงแล้วตัวกลับใหญ่เท่าเดิม แบบ PowerPoint)
    # หน้าที่ติดป้ายล้นอยู่แล้ว (กล่องอื่นยาวเกิน): ตัดสินเฉพาะกล่องที่พิมพ์ ไม่โทษกล่องนี้เพราะกล่องอื่น
    base, nn, full = (overflow(name, d, M) if d.get('_ov') else []), ' '.join(str(new).split()), [[]]
    q_ = lambda m: ' '.join(m[1:m.index('"', 1)].replace('\u00a0', ' ').split()) if m.startswith('"') and '"' in m[1:] else ''
    def chk(dx):
        full[0] = overflow(name, dx, M)
        return [m for m in full[0] if m not in base or (q_(m) and nn.startswith(q_(m)))]
    st, bad = 'ok', chk(d2)
    if bad:
        st = 'over'
        if idx == 0 or 'tsz' in d2:                        # ปกย่อหัวเรื่องได้ ไล่ลงแบบเดียวกับตอนจัดครั้งแรก
            for z in (40, 36, 32, 28):
                if z >= d2.get('tsz', 99): continue
                if not chk({**d2, 'tsz': z, '_tz': 1}): d2 = {**d2, 'tsz': z, '_tz': 1}; st = 'shrink'; bad = []; break
    if st == 'over':                                       # ย่อตัวกล่องนี้ลงทีละขั้นถึง 80% (ไม่ต่ำกว่า 10pt) ตามกฎขนาดตัวอักษรของใบ 015
        for f in (0.8,) if dry else (0.95, 0.9, 0.85, 0.8):   # ระหว่างพิมพ์วัดแค่ขั้นเล็กสุด (ไม่หน่วงจอ) ตอนจบการแก้ไล่ทีละขั้น
            dz = {**d2, 'fsz': {**fz, key: f}}; bad = chk(dz)
            if not bad: d2, st = dz, 'shrink'; break
        else:
            if force: d2 = dz                              # ยังล้น: เก็บขนาดที่เล็กสุด คำครบ
    EXTRA['lines'] = _over_n(bad) if st == 'over' else 0
    # หัวข้อกับข้อในสารบัญเป็นคำเดียวกัน แก้ฝั่งไหนอีกฝั่งต้องตาม (ไม่งั้นไฟล์มีสองคำไม่ตรงกัน)
    if cs[idx].get('_ins'):                                # หน้าที่ลูกค้าแทรกเอง: ไม่ผูกกับสารบัญ/หัวข้อ/เนื้อหาต้นทาง (ช่องว่างเดิม = '' ห้ามแทนทั้งไฟล์)
        if not dry and (st != 'over' or force): items[idx] = (name, {**d2, '_ov': 1} if full[0] else d2)
        return st, True
    links, ag = [], cs[idx].get('kind') == 'agenda'
    sec = cs[idx].get('_sec')                                # หัวข้อที่ชื่อนี้เป็นของ (จากสารบัญ = เลขหัวข้อของข้อที่แก้)
    if ag and path[0] == 'items' and len(path) > 1 and isinstance(path[1], int) and (cs[idx].get('_secs') or []):
        sec = (cs[idx]['_secs'] + [None] * 99)[path[1]]
    same = lambda j: sec is not None and cs[j].get('_sec') == sec and cs[j].get('kind') not in ('cover', 'agenda')
    if (ag and path[0] == 'items') or not ag:                # ช่องไหนก็ได้ที่ถือชื่อหัวข้อ (หัวเรื่อง หัวรอง ป้าย)
        for j, (nm, dj) in enumerate(items):
            if j == idx: continue
            if not ag and cs[j].get('kind') == 'agenda' and 'items' in dj:
                h = [0]; it2 = _sub(dj['items'], old, new, h, flat=True)
                if h[0]: links.append((j, (nm, {**dj, 'items': it2})))
            elif not ag and cs[idx].get('_sec') is not None and cs[j].get('_sec') == cs[idx].get('_sec') and cs[j].get('kind') not in ('cover', 'agenda') \
                    and path[0] in ('t', 't1', 's', 'k', 'who', 'lab', 'label', 'tag'):
                h = [0]; dj2 = _sub(dj, old, new, h, True)  # หน้าต่อของหัวข้อเดียวกันใช้ชื่อหัวข้อเดียวกัน (รวมชื่อที่เป็นบรรทัดในเนื้อ)
                if h[0]: links.append((j, (nm, dj2)))
            elif ag and cs[j].get('kind') not in ('cover', 'agenda'):
                h = [0]; dj2 = _sub(dj, old, new, h, same(j))
                if h[0]: links.append((j, (nm, dj2)))
    links = [(j, (nm, {k: v for k, v in dj.items() if k != '_ov'})) for j, (nm, dj) in links]
    lov = {j for j, (nm, dj) in links if overflow(nm, dj, M)}
    if st != 'over' and lov: st = 'over'
    if dry or (st == 'over' and not force): return st, True
    if full[0]: d2 = {**d2, '_ov': 1}                      # ออกจากกล่องตอนยังล้น (กล่องนี้หรือกล่องอื่นในหน้า): คำครบ หน้านี้ติดป้าย "ข้อความล้นกล่อง"
    links = [(j, (nm, {**dj, '_ov': 1} if j in lov else dj)) for j, (nm, dj) in links]
    items[idx] = (name, d2)
    for j, it in links: items[j] = it
    hit = [0]
    for j in range(len(cs)): cs[j] = _sub(cs[j], old, new, [0], same(j) and (ag or path[0] in ('t', 't1', 's', 'k', 'who', 'lab', 'label', 'tag')), cs[j].get('kind') == 'agenda')
    for j in range(len(want)): want[j] = _sub(want[j], old, new, hit, flat=isinstance(want[j], dict) and want[j].get('kind') == 'agenda')
    sq = lambda x: ''.join(str(x).split())
    if not hit[0] and sq(old):                             # ปกตัดบรรทัดเอง ("รายงานผลโครงการ\nรักการอ่าน") แต่ cs/want เก็บบรรทัดเดียว: เทียบแบบไม่นับช่องว่าง/ขึ้นบรรทัด ไม่งั้นชื่อเรื่องที่แก้ไม่ตามไปหน้าตาใหม่ (บั๊กไอซ์ 1 พ.ย.)
        n2 = ' '.join(str(new).split())
        for arr, h in ((cs, [0]), (want, hit)):
            for j, w in enumerate(arr):
                if isinstance(w, dict):
                    for kk, vv in list(w.items()):
                        if isinstance(vv, str) and sq(vv) == sq(old): arr[j] = {**arr[j], kk: n2}; h[0] += 1
    return st, hit[0] > 0

def keys(items, order, ttl, slug):
    """ลายนิ้วมือของแต่ละหน้า (ตามลำดับบนจอ) เว็บใช้ภาพเดิมซ้ำถ้าไม่เปลี่ยน ไม่ต้องวาดใหม่ทั้งไฟล์ตอนเลิกทำ  รวมค่าแบรนด์/เลขหน้า (BR) และตำแหน่งหน้า (เลขหน้า โลโก้เฉพาะปก)"""
    import hashlib
    br = repr(sorted(BR.items()))
    return [hashlib.md5(repr((items[i], ttl, slug, k == 0, br, k if BR.get('num', True) else 0)).encode()).hexdigest()[:16] for k, i in enumerate(order)]

# ══ ใบ 007: แบรนด์ (โลโก้ + ชื่อบริษัท) เลขหน้า ทรานซิชัน ═════════════════════════════════════════
# BR ทั้งไฟล์ (อยู่ใน snapshot ของเว็บ ไม่อยู่ใน items ข้ามการเปลี่ยนหน้าตาได้) / รายหน้า d['_lg'] d['_pn'] d['_tr']
BR = {}   # logo, logow (ไฟล์รูปในเครื่อง), lr (กว้าง/สูง), company, scope all|nocover|cover, pos tr|tl|br|bl, size s|m, num, start, numcover, tr none|fade|push|wipe, spd slow|med|fast

def _dark(slide, sw, sh_):
    """พื้นหน้าเข้มไหม: shape พื้นทึบที่คลุมสไลด์ (ตัวแรกที่กว้าง ≥ 80%) ไม่มี = พื้นสว่าง"""
    for x in slide.shapes:
        try:
            if x.fill.type == 1 and x.width * x.height >= sw * sh_ * 0.8:
                c = x.fill.fore_color.rgb; return (0.299 * c[0] + 0.587 * c[1] + 0.114 * c[2]) / 255 < 0.5
        except Exception: continue
    return False

def _dark_at(slide, x, y, bg=None):
    """พื้นตรงจุด (x, y) เข้มไหม: shape พื้นทึบ/รูปบนสุดที่คลุมจุดนั้น ไม่มี = สีพื้นของชุด"""
    for o in reversed(list(slide.shapes)):
        if o.name == 'PageNo' or not (o.left <= x <= o.left + o.width and o.top <= y <= o.top + o.height): continue
        if getattr(o, 'shape_type', None) == 13: return True        # รูป (ภาพถ่ายย้อมสีของชุด) ส่วนใหญ่เข้ม
        try:
            if o.fill.type == 1: c = o.fill.fore_color.rgb; return (0.299 * c[0] + 0.587 * c[1] + 0.114 * c[2]) / 255 < 0.5
        except Exception: continue
    c = str(bg or 'FFFFFF').lstrip('#')
    return (0.299 * int(c[0:2], 16) + 0.587 * int(c[2:4], 16) + 0.114 * int(c[4:6], 16)) / 255 < 0.5

def _num_ink(slide, box):
    """สีเลขหน้าจากทุก shape ที่อยู่ใต้กล่อง (บนสุดลงล่าง ถึงตัวที่คลุมทั้งกล่อง) + พื้นชุด  รูป/ไล่สี = ไม่รู้ -> ใส่แคปซูลพื้นชุด ตัวสีหลักของชุด"""
    from pptx.dml.color import RGBColor
    from pptx.util import Emu
    from pptx.oxml.ns import qn
    under, unknown = [], False
    shs = list(slide.shapes); i0 = shs.index(box)
    if any(_ov(o, box) for o in shs[i0 + 1:]):                 # QA 30k followup90 หน้า 5: รูปครึ่งหน้าวาดทีหลังช่องเลขของดีไซน์ = เลขอยู่ใต้รูป -> ยกเลขขึ้นบนสุดก่อนแล้วค่อยดูของข้างใต้
        tree = slide.shapes._spTree; ext = tree.find(qn('p:extLst'))
        ext.addprevious(box._element) if ext is not None else tree.append(box._element)
        shs = list(slide.shapes); i0 = shs.index(box)
    def leaves(o):                                              # กลุ่ม: ดูทุกชิ้นข้างใน (รูปในกลุ่มก็ต้องเห็น)
        if getattr(o, 'shape_type', None) == 6: return [x for c in o.shapes for x in leaves(c)]
        return [o]
    def fill(x):                                                # (สี, ความทึบ 0-1) / None = ไม่มีพื้น / 'U' = ไม่รู้ (รูป ไล่สี ลาย สีธีม)
        if getattr(x, 'shape_type', None) == 13: return 'U'
        sp = x._element.find(qn('p:spPr'))
        if sp is None: return None
        f_ = next((c for c in sp if c.tag in (qn('a:solidFill'), qn('a:noFill'), qn('a:gradFill'), qn('a:blipFill'), qn('a:pattFill'), qn('a:grpFill'))), None)
        if f_ is None or f_.tag == qn('a:noFill'): return None
        if f_.tag != qn('a:solidFill'): return 'U'
        c = f_.find(qn('a:srgbClr'))
        if c is None or len([k for k in c if k.tag != qn('a:alpha')]): return 'U'
        a = c.find(qn('a:alpha'))
        return c.get('val').upper(), (int(a.get('val')) / 100000 if a is not None else 1.0)
    def covers(o): return o.left <= box.left and o.top <= box.top and o.left + o.width >= box.left + box.width and o.top + o.height >= box.top + box.height
    def bgfill():                                               # พื้นสไลด์ (สไลด์ -> layout -> master) QA 30n startupseed: พื้นไล่สี/รูปของสไลด์ = ไม่รู้
        for part in (slide, slide.slide_layout, slide.slide_layout.slide_master):
            bp = part._element.find('.//' + qn('p:bgPr'))
            if bp is not None:
                fx = next((c for c in bp if c.tag.startswith('{http://schemas.openxmlformats.org/drawingml/2006/main}') and c.tag.endswith('Fill')), None)
                if fx is None or fx.tag == qn('a:noFill'): continue
                c = fx.find(qn('a:srgbClr')) if fx.tag == qn('a:solidFill') else None
                return c.get('val').upper() if c is not None and not len(c) else 'U'
            if part._element.find('.//' + qn('p:bgRef')) is not None: return 'U'
        return str(eng.P.get('bg', 'FFFFFF')).lstrip('#')[:6]
    stack = []                                                  # (สี, ทึบ, คลุมทั้งกล่อง) บนลงล่าง ถึงชิ้นทึบที่คลุมทั้งกล่อง
    for o in reversed(shs[:i0]):
        if not (o.left < box.left + box.width and box.left < o.left + o.width and o.top < box.top + box.height and box.top < o.top + o.height): continue
        fs = [fill(x) for x in leaves(o)]
        if 'U' in fs: unknown = True; break
        fs = [x for x in fs if x]
        cov = getattr(o, 'shape_type', None) != 6 and covers(o)
        stack += [(c, a, cov) for c, a in fs]
        if cov and fs and fs[-1][1] >= 0.999: break
    else:
        b_ = bgfill()
        if b_ == 'U': unknown = True
        else: stack.append((b_, 1.0, True))
    if not unknown:                                             # QA 30n startupseed: วงกลมโปร่ง 2% สีน้ำเงินไม่ใช่พื้นน้ำเงิน -> ผสมสีตามความทึบจากล่างขึ้นบน
        mix = lambda c, u, a: ''.join('%02X' % round(int(c[k:k + 2], 16) * a + int(u[k:k + 2], 16) * (1 - a)) for k in (0, 2, 4))
        for c, a, cov in reversed(stack):
            got = {c} if a >= 0.999 else {mix(c, u, a) for u in under}
            under = list(got if cov else set(under) | got)
    ink = str(eng.P.get('ink', '15151A')).lstrip('#')[:6]
    pick = None if unknown else next((c for c in (ink, 'FFFFFF', '15151A') if all(eng.cratio(c, u) >= 4.5 for u in under)), None)
    runs = [r for p in box.text_frame.paragraphs for r in p.runs]
    if pick is None:                                               # แคปซูล: พื้นชุด + สีที่อ่านออกบนพื้นนั้น
        bg = str(eng.P.get('bg', 'FFFFFF')).lstrip('#')[:6]
        pick = next((c for c in (ink, '15151A', 'FFFFFF') if eng.cratio(c, bg) >= 4.5), '15151A')
        if eng.cratio(pick, bg) < 4.5: bg = 'FFFFFF'; pick = '15151A'
        box.fill.solid(); box.fill.fore_color.rgb = RGBColor.from_string(bg)
        tf = box.text_frame; tf.margin_left = tf.margin_right = Emu(45720); tf.margin_top = tf.margin_bottom = Emu(18288)
        for p in tf.paragraphs: p.alignment = 2
        if box.width > Emu(914400 * 0.5): box.left = box.left + box.width - Emu(914400 * 0.42); box.width = Emu(914400 * 0.42)
        from pptx.enum.text import MSO_AUTO_SIZE, MSO_ANCHOR    # pncheck 30o: spAutoFit = pptx-preview ย่อกรอบเอง ตัวเลขโผล่พ้นขอบแคปซูล (followup90 nichebrand) -> กรอบตายตัว ตัวเลขกลางแคปซูล
        tf.auto_size = MSO_AUTO_SIZE.NONE; tf.vertical_anchor = MSO_ANCHOR.MIDDLE
    for r in runs: r.font.color.rgb = RGBColor.from_string(pick)

def page_extras(prs, slide, d, dd, i, cover, field=True):
    """หลังวาดหน้า: เลขหน้าเป็นช่องอัตโนมัติของ PowerPoint (slidenum) / โลโก้ที่มุม / ทรานซิชัน  ค่าตั้งจาก BR + รายหน้าใน d"""
    from pptx.util import Emu, Pt
    from pptx.oxml.ns import qn
    from lxml import etree
    sw, sh_ = prs.slide_width, prs.slide_height
    # เลขหน้า: ช่องเลขหน้าของ layout (ข้อความ = เลขหน้านี้ ไม่ใช่คำลูกค้า) -> field / ปิด = ลบเลข / layout ไม่มีช่อง = มุมล่างขวา
    numset = 'num' in BR                                       # ลูกค้ายังไม่ตั้ง = ตามดีไซน์ (ช่องเลขหน้าเดิมเป็น field ไม่เพิ่ม ไม่ลบ)
    num = BR.get('num', True) and (BR.get('numcover', False) or not cover)   # ปก: ไม่มีเลขจนกว่าลูกค้าเปิด "แสดงบนปก" (บั๊ก iPhone 30k: ช่องเลขของดีไซน์บนปกได้แคปซูล "1")
    if '_pn' in d: num = bool(d['_pn'])
    mine = {' '.join(t.split()) for _, t in _leaves(d)}
    nn = {str(dd.get('n', '')), str(int(dd['n'])) if str(dd.get('n', '')).isdigit() else ''} - {''}
    edge = lambda sh: sh.top + sh.height / 2 < 914400 * 0.9 or sh.top + sh.height / 2 > sh_ - 914400 * 0.9   # ช่องเลขหน้าอยู่ขอบบน/ล่าง (เลขลำดับรายการ "03" กลางหน้าไม่ใช่เลขหน้า)
    hit = next((sh for sh in slide.shapes if sh.has_text_frame and sh.text_frame.text.strip() in nn and sh.text_frame.text.strip() not in mine and edge(sh)), None)
    add = bool(d['_pn']) if '_pn' in d else num and (BR.get('numcover', False) or not cover)   # QA 007: สวิตช์เปิดอยู่ = มีเลขจริง ดีไซน์ไม่มีช่อง -> มุมล่างขวา (ปกไม่ใส่ตั้งต้น)
    if hit is None and add:
        hit = slide.shapes.add_textbox(sw - Emu(914400 * 1.25), sh_ - Emu(914400 * 0.6), Emu(914400 * 0.9), Emu(914400 * 0.3)); hit.name = 'PageNo'
        p = hit.text_frame.paragraphs[0]; p.alignment = 3; r = p.add_run(); r.text = str(i); r.font.size = Pt(10)
    if hit is not None and num: _num_ink(slide, hit)                 # QA 30j: เลขหน้าอ่านออก ≥ 4.5:1 กับของที่อยู่ใต้กล่องจริง (ทุก shape ที่ทับ) ไม่รู้ = แคปซูลพื้นชุด
    if hit is not None:
        runs = [r for p in hit.text_frame.paragraphs for r in p.runs]
        if not num:
            for r in runs: r.text = ''
        elif runs and not field: runs[0].text = str(i); [setattr(r, 'text', '') for r in runs[1:]]   # จอเว็บ: pptx-preview ไม่วาดช่อง field ใช้ตัวเลขเดียวกันแทน (ไฟล์ = field)
        elif runs:
            r0 = runs[0]._r; fld = etree.SubElement(r0.getparent(), qn('a:fld')); fld.set('id', '{B6F15528-21DE-4FAA-801E-634DDDAF4B2B}'); fld.set('type', 'slidenum')
            rpr = r0.find(qn('a:rPr'))
            if rpr is not None: fld.append(__import__('copy').deepcopy(rpr))
            t = etree.SubElement(fld, qn('a:t')); t.text = str(i)
            r0.addprevious(fld); [r._r.getparent().remove(r._r) for r in runs]
    # โลโก้ลูกค้า: มุมที่เลือก ขนาดเล็ก/กลาง สัดส่วนเดิม / พื้นเข้มใช้โลโก้สีขาวถ้ามี
    lg = BR.get('logo') and {'all': True, 'nocover': not cover, 'cover': cover}[BR.get('scope', 'nocover')]
    if '_lg' in d: lg = bool(d['_lg']) and bool(BR.get('logo'))
    if lg:
        path = BR['logo']
        if BR.get('logow') and _dark(slide, sw, sh_): path = BR['logow']
        if os.path.exists(path):
            h = Emu(int(914400 * (0.62 if BR.get('size') == 'm' else 0.42))); w = Emu(int(min(h * float(BR.get('lr', 1) or 1), 914400 * 2.4)))
            if w < h * float(BR.get('lr', 1) or 1): h = Emu(int(w / float(BR.get('lr', 1))))
            m = Emu(int(914400 * 0.35)); pos = BR.get('pos', 'tr')
            x = sw - m - w if pos[1] == 'r' else m; y = m if pos[0] == 't' else sh_ - m - h
            slide.shapes.add_picture(path, x, y, w, h).name = 'Logo'
    # ทรานซิชัน (schema พื้นฐาน เปิดได้ตั้งแต่ PowerPoint 2007)
    tr = d['_tr'] if d.get('_tr') else BR.get('tr', 'none')
    if tr and tr != 'none':
        el = slide._element; old = el.find(qn('p:transition'))
        if old is not None: el.remove(old)
        x = etree.SubElement(el, qn('p:transition')); x.set('spd', {'slow': 'slow', 'fast': 'fast'}.get(BR.get('spd'), 'med'))
        k = etree.SubElement(x, qn({'fade': 'p:fade', 'push': 'p:push', 'wipe': 'p:wipe'}[tr]))
        if tr == 'push': k.set('dir', 'l')
        if tr == 'wipe': k.set('dir', 'r')
        anchor = el.find(qn('p:clrMapOvr'))
        if anchor is None: anchor = el.find(qn('p:cSld'))
        anchor.addnext(x)

def sync_agenda(items, cs, order, slug):
    """หลังย้าย/ลบ/ทำสำเนาหน้า: จัดสารบัญใหม่จากหน้าที่เหลือตามลำดับปัจจุบัน แก้ items/cs ในที่ คืนลำดับหน้าใหม่
    (ไม่เหลือหัวข้อ หรือหน้าตานี้ใส่ไม่ได้ = เอาหน้าสารบัญออก)"""
    k = next((p for p, i in enumerate(order) if cs[i]['kind'] == 'agenda'), -1)
    if k < 0 or sum(1 for i in order if cs[i]['kind'] == 'agenda') > 1: return list(order)   # สารบัญสองหน้า: ponytail ไม่จัดใหม่ตอนย้ายหน้า
    i = order[k]; rest = [j for j in order if cs[j]['kind'] not in ('cover', 'agenda')]
    if cs[i].get('_secs') is not None or cs[i].get('_secs0') is not None:
        secs = [cs[j]['_sec'] for j in rest if isinstance(cs[j].get('_sec'), int)]
    else:                                                  # งานเก่าที่เก็บไว้ก่อนมีเลขหัวข้อ
        secs = [t for t in ((cs[j].get('s') if cs[j]['kind'] == 'statement' else cs[j].get('t')) or '' for j in rest) if t]
    c2, pk = reagenda(cs[i], secs, slug, items[i][0])
    cs[i] = c2; mv0 = items[i][1].get('mv')
    if pk: items[i] = (pk[0], {**pk[1], 'mv': mv0}) if mv0 and pk[0] == items[i][0] else tuple(pk); return list(order)   # แบบเดิม: กล่องที่ลูกค้าย้ายอยู่ที่เดิม
    if c2['items']:                                        # ไม่มีแบบหน้าเดียวที่ลงพอดีตามเกณฑ์ alternatives: ให้ตัวจัดหน้าเลือก (ย่อตัวได้) ได้หน้าเดียวก็ใช้
        new = [x for x in plan([c2], slug)[1] if x['c']['kind'] == 'agenda']
        if len(new) == 1: items[i] = (new[0]['layout'], new[0]['d']); return list(order)
    return [j for p, j in enumerate(order) if p != k]

def add_agenda(want, items, cs, order, slug, layout):
    """ลูกค้ากดใส่สารบัญ (ปิดไว้ตั้งต้น ไอซ์ 29 ต.ค. 2569): เปิดสารบัญที่เตรียมไว้ใน want วางต่อจากปก หัวข้อ = หัวข้อของหน้าที่มีอยู่ตอนนี้ ตามลำดับหน้า
    layout = แบบที่ลูกค้าเลือก ใส่ไม่ได้ = แบบอื่นของชุด / ยาวเกินหน้าเดียว = ตัวจัดหน้าแบ่งสองหน้า "สารบัญ" แบบตอนจัดทั้งไฟล์
    แก้ items/cs/want ในที่  คืน (ลำดับหน้าใหม่, หน้าแรกของสารบัญ หรือ -1 = ใส่ไม่ได้)"""
    k = next((i for i, c in enumerate(want) if c['kind'] == 'agenda'), -1)
    if k < 0: return list(order), -1
    c = {x: v for x, v in want[k].items() if x != '_off'}
    secs = [cs[j]['_sec'] for j in order if cs[j]['kind'] not in ('cover', 'agenda') and isinstance(cs[j].get('_sec'), int)]
    c2, pk = reagenda(c, secs, slug, layout)
    if not c2['items']: return list(order), -1
    new = [(tuple(pk), c2)] if pk else [((x['layout'], x['d']), x['c']) for x in plan([c2], slug)[1] if x['c']['kind'] == 'agenda']
    if not new: return list(order), -1
    at = next((p + 1 for p, i in enumerate(order) if cs[i]['kind'] == 'cover'), 0); ids = []
    for it, cc in new: items.append(it); cs.append(dict(cc)); ids.append(len(items) - 1)
    want[k] = c
    return list(order[:at]) + ids + list(order[at:]), at

# ══ 8. แทรกหน้าใหม่ (ใบงาน 003 เฟส 2): layout ของชุดนี้ ช่องว่างให้ลูกค้าพิมพ์เอง ═══════════
INSK = ('cover', 'agenda', 'list', 'pairs', 'faq', 'stat', 'timeline', 'compare', 'statement', 'divider')   # ไม่มีตาราง/กราฟ: หน้าเปล่ายังไม่มีที่กรอกข้อมูล
_INSP = {}
# แบบที่ผ่าน ins_ok ต่อชุด คิดไว้ตอนรวม bundle (d2s_web.py) บนเว็บไม่ต้องวาดทดสอบทุกแบบตอนเปิดแผง (มือถือค้างหลายวินาที)
INSOK = json.load(open(f'{K}/ins_ok.json')) if os.path.exists(f'{K}/ins_ok.json') else {}
def ins_ok(nm, d, kd, M):
    """แบบหน้าว่างที่แทรกได้: วาดได้ และคำใบ้ลงกล่องพอดีไม่ทับรูป/เส้น (ช่องที่ layout ไม่วาดไม่นับ)"""
    return not [b for b in overflow(nm, hinted(d, kd)[0], M) if not b.startswith('ไม่ได้วาด')]

def ins_pool(slug):
    """แบบหน้าที่แทรกได้ของชุดนี้ (ไม่ซ้ำชื่อ layout) ทุกช่องข้อความว่าง ไม่มีคำตัวอย่างของดีไซน์  คืน [(layout, d, c, ชนิดตัวอย่าง)]"""
    if slug not in _INSP:
        M, pool = pool_of(slug); seen, out = set(), []
        for nm, ex, kd, n_ex, slots in pool:
            if kd not in INSK or nm in seen: continue
            c = dict(kind={'faq': 'qa', 'agenda': 'list' if slots in (None, (str,)) else 'pairs'}.get(kd, kd), t='', _ins=1)
            it = ex.get('items')
            if isinstance(it, list) and it and slots:
                c['items'] = ([('', [''] * len(next((x for x in r if isinstance(x, list)), []))) for r in it] if kd == 'compare'
                              else [('',) * sum(t is str for t in slots)] * len(it))
            d = fill(nm, ex, slots, c)
            if d is None: continue
            seen.add(nm); out.append((nm, d, c, kd))
        out.sort(key=lambda x: INSK.index(x[3]))
        ok = INSOK.get(slug)
        _INSP[slug] = [e for e in out if (e[0] in ok if ok is not None else ins_ok(e[0], e[1], e[2]['kind'], M))]
    return _INSP[slug]

def blank_page(d):
    """หน้าที่แทรกแล้วยังไม่ได้พิมพ์อะไรเลย (ถามก่อนบันทึก)"""
    return not any(v.strip() for _, v in _leaves(d))

HINTW = {'stat': ('เลข', 'คำอธิบาย', 'ข้อความ'), 'timeline': ('เวลา', 'หัวข้อ', 'รายละเอียด')}
def hinted(d, kind='', name=None):
    """ช่องว่างของหน้าที่แทรก → คำใบ้สั้น ๆ บนจอ (ไม่ลงไฟล์) คำไม่ซ้ำกัน กล่องบนจอจึงผูกกลับช่องได้ถูก  คืน (d ที่มีคำใบ้, ชุดคำใบ้)"""
    out, used, first = d, set(), None
    for p, v in list(_leaves(d)):
        if name and p[0] in ('t', 't1', 't2', 's', 'note') and f"d['{p[0]}']" not in SRC.get(name, '') and f"d.get('{p[0]}'" not in SRC.get(name, ''): continue   # เฟส C: ช่องที่ layout ไม่วาด (m_toc ไม่มีหัวเรื่อง) ไม่ใช่คำใบ้
        if v.strip() or p[0] not in ('t', 't1', 't2', 's', 'note', 'items'): continue   # ป้ายของดีไซน์ (แบรนด์ ชื่อเอกสาร) ว่างเหมือนหน้าที่ระบบจัด
        if p[0] == 'items' and len(p) == 2: h = f'ข้อ {p[1] + 1}'
        elif p[0] == 'items' and len(p) == 3:
            r = sum(isinstance(x, str) for x in d['items'][p[1]][:p[2]])
            h = f"{HINTW.get(kind, ('หัวข้อ', 'รายละเอียด', 'ข้อความ'))[min(r, 2)]} {p[1] + 1}"
        elif p[0] == 'items': h = f'ข้อ {p[1] + 1}.{p[-1] + 1}'
        else: h = {'t': 'พิมพ์หัวเรื่อง', 't1': 'พิมพ์หัวเรื่อง', 't2': 'หัวเรื่องต่อ', 's': 'พิมพ์หัวรอง', 'note': 'หมายเหตุ'}[p[0]]
        h0, n = h, 2
        while h in used: h = f'{h0} ({n})'; n += 1
        used.add(h); out = _put(out, list(p), h); first = first or (p, h)
    if first and not any(h.startswith('พิมพ์') for h in used):   # เฟส C: หน้าที่ไม่มีช่องหัวเรื่อง (สารบัญ m_toc หัวตายตัว) ช่องแรกบอกให้พิมพ์
        used.discard(first[1]); h = 'พิมพ์' + first[1]; used.add(h); out = _put(out, list(first[0]), h)
    return out, used

def unblank(d):
    """ตอนบันทึก: ข้อที่ปล่อยว่างในหน้าที่แทรกไม่ลงไฟล์ (เหลืออย่างน้อยข้อเดียว)"""
    its = d.get('items')
    if isinstance(its, list):
        keep = [r for r in its if any(v.strip() for _, v in _leaves(r))]
        if keep and len(keep) < len(its): return {**d, 'items': keep}
    return d

_rtrim = lambda r: r[:max(1, max((k + 1 for k, x in enumerate(r) if x.strip()), default=0))]   # ช่องว่างท้ายข้อ (แบบเดิมมีสามช่อง) ไม่นับ แบบใหม่ช่องน้อยกว่าก็ลงได้
def content_of(d, c):
    """คำที่ลูกค้าพิมพ์ในหน้าที่แทรก → เนื้อหา (หัวเรื่อง หัวรอง ข้อ) ไว้ลงแบบอื่นหรือหน้าตาอื่น
    ponytail: ช่องป้ายเล็กของ layout (นอกจากหัวเรื่อง หัวรอง หมายเหตุ ข้อ) ไม่ตามไป"""
    t = d['t'] if 't' in d else ' '.join(x for x in (d.get('t1', ''), d.get('t2', '')) if str(x).strip())
    c2 = dict(kind=c['kind'], _ins=1, t=t, s=d.get('s', ''))
    if d.get('note'): c2['note'] = d['note']
    if c['kind'] == 'chart':                               # ใบ 031 หน้ากราฟที่เพิ่มเอง: ตารางไปด้วย (เปลี่ยนแบบหน้าเป็นหน้ากราฟของชุดได้)
        cats, ser = lay_charts._raw(d)
        h0 = (d.get('head') or [''])[0]; h0 = h0 if isinstance(h0, str) else (h0[0] if h0 else '')
        c2.update(head=[h0] + [n for n, _ in ser], rows=[[x] + [str(v[j]) for _, v in ser] for j, x in enumerate(cats)], cats=cats, series=ser, vals=list(ser[0][1]) if ser else [])
        if d.get('_nf'): c2['_nf'] = d['_nf']
        return c2
    if c['kind'] == 'table' and d.get('rows'):              # ใบ 034 หน้าตารางที่เพิ่มเอง: หัว/แถวไปด้วย (เปลี่ยนแบบ/หน้าตา)
        c2.update(head=[h if isinstance(h, str) else h[0] for h in d.get('head') or []], rows=[[str(x) for x in r] for r in d['rows']]); return c2
    its = d.get('items')
    if isinstance(its, list) and its:
        c2['items'] = ([(next((x for x in r if isinstance(x, str)), ''), next((x for x in r if isinstance(x, list)), [])) for r in its] if c['kind'] == 'compare'
                       else [(r,) if isinstance(r, str) else tuple(x for x in r if isinstance(x, str)) for r in its])
        typed = [r for r in c2['items'] if any(v.strip() for _, v in _leaves(r))]
        if typed: c2['items'] = typed if c['kind'] == 'compare' else [_rtrim(r) for r in typed]                      # ข้อที่ยังว่างไม่ต้องตามไป (แบบใหม่อาจรับจำนวนข้อไม่เท่าเดิม)
    return c2

def carry_ins(old_items, old_cs, old_order, items, cs, slug):
    """เปลี่ยนหน้าตาแล้ว หน้าที่ลูกค้าแทรกเองตามไปด้วย: คำเดิม แบบที่ใส่ได้ในหน้าตาใหม่ วางต่อจากหัวข้อเดิม แก้ items/cs ในที่
    คืน (ลำดับหน้าใหม่, จำนวนหน้าที่ตามไปไม่ได้)"""
    order, at, gone = list(range(len(items))), 0, 0
    for i in old_order:
        c = old_cs[i]
        if not c.get('_ins'):
            if c['kind'] == 'cover': at = 0
            elif c.get('_sec') is not None:
                ps = [p for p, j in enumerate(order) if cs[j].get('_sec') == c['_sec'] and not cs[j].get('_ins')]
                if ps: at = ps[-1]
            continue
        if (c['kind'] == 'chart' and old_items[i][0].startswith('chb_')) or (c['kind'] == 'table' and old_items[i][1].get('rows')):   # ใบ 036 หน้าตารางที่เพิ่มเองยกไปทั้งหน้า แล้ว retable ลงหน้าตารางของชุดใหม่ตามรูปแบบที่เลือก   # ใบ 034 หน้าตารางกลาง (สีตามชุด) ตามไปทั้งหน้าเหมือนกัน   # ใบ 031 หน้ากราฟที่เพิ่มเอง: หน้ากราฟกลางใช้ได้ทุกหน้าตา ตามไปทั้งหน้า (ชนิด แบบ สี ตาราง เลย์เอาต์)
            if len(order) >= MAXSLIDES: gone += 1; continue
            items.append(old_items[i]); cs.append(dict(c)); at += 1; order.insert(at, len(items) - 1); continue
        c2 = content_of(old_items[i][1], c); its = c2.get('items') or []
        typed = any(v.strip() for _, v in _leaves(its))
        tries = [c2] + ([dict(c2, items=its[:3]), dict(c2, items=its[:1])] if its and not typed else [])   # ยังไม่ได้พิมพ์ข้อ: จำนวนข้อว่างน้อยลงได้
        if its and c2['kind'] not in ('list', 'pairs', 'compare'):   # หน้าตาใหม่ไม่มีแบบชนิดนี้ (การ์ดตัวเลข ไทม์ไลน์): ลงเป็นรายการ/หัวข้อพร้อมคำอธิบาย คำครบ
            tries += [dict(x, kind='list' if all(len(r) == 1 for r in its) else 'pairs') for x in list(tries)]
        if not typed: tries += [{k: v for k, v in c2.items() if k != 'items'} | {'kind': k_} for k_ in ('statement', 'divider')] + [{k: v for k, v in c2.items() if k != 'items'} | {'kind': 'list', 'items': [('',)]}]   # เฟส C: มีแต่หัวเรื่อง ชุดที่ข้อความเด่นต้องมีเนื้อความ ลงหน้าคั่นได้ / ชุดที่ไม่มีทั้งสองแบบ (edtechpitch) = รายการว่างให้พิมพ์ต่อ
        alts, x = [], c2
        for x in tries:
            if len(order) >= MAXSLIDES: break
            alts = alternatives(x, slug)
            if alts: break
        if not alts: gone += 1; continue
        items.append(tuple(alts[0])); cs.append(dict(c, kind=x['kind'])); at += 1; order.insert(at, len(items) - 1)
    return order, gone

CARRY = ('add', '_note', '_name', '_chlk', 'dpic', 'shc', '_samp', '_tst')   # ใบ 036 _tst รูปแบบตารางที่เลือก   # ใบ 026 รูปในดีไซน์ที่เปลี่ยน (รูปที่ N ไปรูปที่ N) สีชิ้น (ช่องสีของชุด + ลำดับ)                  # ของที่ลูกค้าเพิ่ม/ตั้งต่อหน้า ตามไปทุกแบบ
CARRYK = ('ffam', 'usz', 'tfm', 'rot', 'lock')              # รูปแบบต่อกล่อง ตามไปถ้าช่องนั้นยังมีในแบบใหม่
CHARTD = ('cats', 'series', 'vals', 'sname', '_nf', '_sn')  # ตารางกราฟที่ลูกค้าแก้ (อยู่ใน items ไม่อยู่ใน want)
def carry_page(old, new, chart=False):
    """เปลี่ยนหน้าตา / เปลี่ยนแบบหน้า: ของที่ลูกค้าเพิ่มหรือแก้ตามไปหน้าใหม่ (ไอซ์ 1 พ.ย. 2569 "เปลี่ยนหน้าตาห้ามทิ้งของที่ลูกค้าเพิ่มหรือแก้")
    add (ข้อความ/รูปที่เพิ่ม ตำแหน่ง ขนาด หมุน ล็อก ชั้น บนแผ่น 960x540 เดิม 1:1) โน้ต ชื่อหน้า รูปแบบต่อกล่อง (ฟอนต์ ขนาด ตัวหนา สี จุดนำ) หมุน ล็อก ชั้น
    กราฟ: ชนิด/แบบ/สี/ป้าย + ตารางที่แก้ (chart=True เมื่อเป็นหน้ากราฟ)  คำที่แก้ตามไปทาง want/cs อยู่แล้ว
    ตำแหน่งกล่องของดีไซน์ที่ลากไว้ (mv) ตามไปถ้าช่องนั้นยังมี (ใบ 030)  ไม่ตาม: ขนาดที่ระบบย่อเอง (fsz _ov)"""
    d = dict(new)
    for k in CARRY:
        if old.get(k): d[k] = old[k]
    def ok(key):
        if key == 'add' or key.startswith(('add.', 'dpic.')): return True
        try: return isinstance(_get(d, [int(x) if x.isdigit() else x for x in key.split('.')]), str)
        except Exception: return False
    tk = lambda k: k if ok(k) else {'t': 't1', 't1': 't'}.get(k, k)   # เฟส C: หัวเรื่องช่องเดียว <-> สองบรรทัด (t1/t2) ฟอนต์/รูปแบบที่ตั้งไว้ตามไป
    for f in CARRYK:
        m = {tk(k): v for k, v in (old.get(f) or {}).items() if ok(tk(k))}
        if m: d[f] = {**(d.get(f) or {}), **m}
    mv = {k: v for k, v in (old.get('mv') or {}).items() if ok(k)}   # ใบ 030: ตำแหน่งกล่องของดีไซน์ที่ลากไว้ตามไปด้วย ถ้าช่องนั้นยังมีในแบบใหม่ (พิกัดบนจอ 960x540)
    if mv: d['mv'] = {**(d.get('mv') or {}), **mv}
    z = [x for x in (old.get('z') or []) if ok(x[0])]
    if z: d['z'] = z
    if chart:
        if old.get('chart'): d['chart'] = old['chart']
        if old.get('two'): d['two'] = old['two']             # ใบ 028 F: ตารางที่รวมมาจากหน้าถัดไปตามไปด้วย (after_look ลบหน้าซ้ำที่จัดใหม่)
        ks = [k for k in ('cats', 'series', 'vals') if k in old]
        if ks and all(k in d for k in ks): d.update({k: old[k] for k in CHARTD if k in old})   # ตารางรูปแบบเดียวกันเท่านั้น (กันจำนวนแถวไม่ตรงกัน)
    return d

# ── ใบ 055 รูปของดีไซน์ต้องไม่ผิดเรื่อง (qa 10 พ.ย. 2569: เนื้อหาร้านกาแฟ ปกเป็นคนในโกดัง shots/051/e-375-editor.png) ──
# หมวดรูปที่เป็นฉากเฉพาะ ใช้ได้เมื่อเนื้อหาลูกค้ามีคำของเรื่องนั้น ไม่งั้นเป็นกรอบว่าง (eng.BLANK) ให้ลูกค้าใส่รูปเอง ไม่เติมรูปสุ่ม
# หมวดกลาง (office training mono3d tech studio aboutme tex) ใช้กับทุกเรื่อง
# รูปคน: หมวดที่มีชุดคนเอเชีย (asia_*) ใช้ชุดนั้นแทนเมื่อมีไฟล์ในเครื่อง (SKILL ข้อ 117) บนเว็บต้องมี zip บน R2 ก่อน (d2s_web.py ใส่ให้เมื่อมี)
# ponytail: จับคำตรง ๆ ไม่ตัดคำ ถ้าคำสั้นชนคำอื่นบ่อยค่อยเปลี่ยนเป็นตัดคำ
SUBJW = {
    'wh': 'คลังสินค้า โกดัง ขนส่ง โลจิสติกส์ สต็อก สต๊อก จัดส่ง ซัพพลาย ห้องเย็น รถบรรทุก warehouse logistics',
    'school': 'โรงเรียน นักเรียน ครู ห้องเรียน การสอน ผู้ปกครอง หลักสูตร นักศึกษา มหาวิทยาลัย อาจารย์ ชั้นเรียน school student teacher',
    'food': 'อาหาร กาแฟ คาเฟ่ เครื่องดื่ม เบเกอรี่ เมนู เชฟ ขนม coffee cafe restaurant',
    'fashion': 'เสื้อผ้า แฟชั่น ไลฟ์สด fashion',
    'retail': 'ร้านค้า ขายปลีก ค้าปลีก หน้าร้าน ร้าน สาขา retail',
    'factory': 'โรงงาน การผลิต สายการผลิต เครื่องจักร factory manufacturing',
    'construction': 'ก่อสร้าง ผู้รับเหมา อาคาร construction',
    'health': 'สุขภาพ โรงพยาบาล ผู้ป่วย คนไข้ พยาบาล แพทย์ คลินิก hospital clinic',
    'beauty': 'ความงาม สกินแคร์ เครื่องสำอาง สปา beauty',
    'bike': 'จักรยาน bike',
    'waste': 'ขยะ รีไซเคิล สิ่งแวดล้อม recycle',
}
SUBJT = {'logistics': 'wh', 'asia_wh': 'wh', 'school': 'school', 'teach': 'school', 'kidclass': 'school', 'learn': 'school', 'eng': 'school', 'asia_school': 'school',
         'food': 'food', 'asia_cafe': 'food', 'fashion': 'fashion', 'asia_fashion': 'fashion', 'retail': 'retail', 'factory': 'factory',
         'construction': 'construction', 'health': 'health', 'beauty': 'beauty', 'bike': 'bike', 'waste': 'waste'}
ASIA = {'office': 'asia_office', 'logistics': 'asia_wh', 'school': 'asia_school', 'teach': 'asia_school', 'kidclass': 'asia_school', 'fashion': 'asia_fashion', 'food': 'asia_cafe'}
def _hasimg(t):
    d = os.path.join(eng.IMG, t)
    return os.path.isdir(d) and any(f.lower().endswith(('.jpg', '.jpeg', '.png', '.webp')) for f in os.listdir(d))
def subjects(items, ttl=''):
    """เรื่องของเนื้อหาลูกค้า (คีย์ของ SUBJW): นับคำในทุกหน้า คำในชื่อเรื่องนับ 3
    เรื่องที่พูดถึงผ่าน ๆ ไม่นับ (ต้อง >= 2 และ >= 1/3 ของเรื่องหลัก) เช่น "ค่าขนส่ง" ในใบเสนอราคาโรงเรียน ไม่ใช่เรื่องคลังสินค้า"""
    t = ' '.join(x for _, d in items for x in strings(d)).lower(); tt = str(ttl).lower()
    sc = {k: sum(t.count(w) + 3 * tt.count(w) for w in ws.split()) for k, ws in SUBJW.items()}
    top = max(sc.values())
    return {k for k, v in sc.items() if v >= 2 and v * 3 >= top}
def phmap(items, ttl=''):
    """หมวด -> หมวดที่ใช้จริง ('' = กรอบว่าง) สำหรับ eng.PHMAP"""
    sub = subjects(items, ttl); out = {}
    for t in TOPICS | set(ASIA):
        s_ = SUBJT.get(t)
        if s_ and s_ not in sub: out[t] = ''
        elif ASIA.get(t) and _hasimg(ASIA[t]): out[t] = ASIA[t]
    return out

_covfill = None
# ── รูปไม่ซ้ำในไฟล์ (ใบ 045 ไอซ์ 2 พ.ย. 2569: "ไฟล์หนึ่งไม่ใช้รูปซ้ำจนกว่ารูปในหมวดจะหมด แล้วค่อยวน") ──
# layout ขอรูปเป็นเลขลำดับในหมวด (eng.ph) หน้าแบบเดียวกันซ้ำ = เลขเดียวกัน = รูปเดียวกัน
# แก้ที่จุดเดียว: ตอนวาด ไล่หน้าตามลำดับ รูปที่ขอถ้าหน้าก่อนหน้าใช้แล้ว เลื่อนไปรูปถัดไปที่ใช้น้อยที่สุดในหมวด (ครบหมวดแล้วค่อยวน)
# วาดบางหน้า (only) ต้องได้รูปเดียวกับวาดทั้งไฟล์: หน้าก่อนหน้าที่ไม่ได้วาด ใช้รายการรูปที่หน้านั้นขอ (จำไว้ตอนวาด หรือวาดลองแบบไม่โหลดรูป)
_PHREQ = {}
def _phkey(name, d, M, first):
    try: return (name, M.get('topic', 'office'), first, json.dumps(d, sort_keys=True, ensure_ascii=False, default=str), json.dumps(eng.PHMAP, sort_keys=True))
    except Exception: return None
_phid = lambda f: f.split('_', 1)[-1]                       # คลังรูปมีไฟล์ซ้ำต่างเลขนำ (eng/05_3776969.jpg = eng/07_3776969.jpg) นับเป็นรูปเดียว
def _phtake(used, topic, n, fs):
    k = min(range(len(fs)), key=lambda j: used.get((topic, _phid(fs[(n + j) % len(fs)])), 0))   # ตัวแรกที่ใช้น้อยสุด เริ่มจากรูปเดิมของดีไซน์
    f = fs[(n + k) % len(fs)]; used[(topic, _phid(f))] = used.get((topic, _phid(f)), 0) + 1
    return os.path.join(eng.IMG, topic, f)
def _phreq(name, d, M, first, ttl):
    """[(topic, n)] ที่หน้านี้ขอ โดยไม่วาดจริง (ไม่โหลดรูป)"""
    k = _phkey(name, d, M, first)
    if k in _PHREQ: return _PHREQ[k]
    rec = []; real = base._prep; base._prep = lambda path, mode=None: (_DOT, (4, 3))
    eng.PHPICK = lambda t, n, fs: (rec.append((t, n)), os.path.join(eng.IMG, t, fs[n % len(fs)]))[1]
    try: lay.L[name](base.deck(), dict(topic=M.get('topic', 'office'), foot=ttl, n='01', **d))
    except Exception: pass
    finally: base._prep = real; eng.PHPICK = None; lay_cov3.TTL2.clear()
    if k is not None:
        if len(_PHREQ) > 400: _PHREQ.clear()             # ponytail: ล้างทั้งก้อนเมื่อโต ไม่ทำ LRU
        _PHREQ[k] = rec
    return rec

def render(items, M, ttl, only=None, ins=(), hint=False):
    """[(layout, dict)] → ไบต์ .pptx  ลำดับขั้นเดียวกับ mk.py (เติมปก, สลับรายละเอียดตาม slug, พลิกปก, ฟอนต์ธีม)
    only = ตำแหน่งหน้าที่จะวาด (ปก/เลขหน้ายังคิดจากทั้งเด็ค) ใช้วาดใหม่เฉพาะหน้าที่แก้
    ins = ตำแหน่งหน้าที่ลูกค้าแทรก: hint (จอ) ช่องว่างโชว์คำใบ้สีเทา / ไม่ hint (ไฟล์) ข้อว่างไม่ลงไฟล์"""
    global _covfill
    if _covfill is None:                                   # ยืม _covfill จาก mk.py ตรง ๆ ไม่ก๊อปโค้ด (mk.py รันทันทีที่ import)
        tree = ast.parse(open(f'{K}/mk.py', encoding='utf-8').read())
        fn = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == '_covfill')
        ns = {'re': re}; exec(compile(ast.Module(body=[fn], type_ignores=[]), 'mk.py', 'exec'), ns)
        _covfill = ns['_covfill']
    M = dict(M, cat='', foot=ttl, th=ttl)
    eng.setpal(M['pal'], M.get('font', 'plex'), M.get('head'))
    prs = base.deck()
    seq = list(items)
    eng.PHMAP = phmap(seq, ttl)                            # ใบ 055 รูปผิดเรื่อง -> กรอบว่าง / ชุดคนเอเชีย
    BOXES.clear(); CHARTC.clear(); CHARTL.clear(); _drawn = []
    used = {}                                              # (หมวด, ไฟล์) → ครั้งที่ใช้แล้วในไฟล์นี้ (ใบ 045)
    for i, (name, d) in enumerate(seq, 1):
        if only is not None and i - 1 not in only:
            if only and i - 1 < max(only):                 # หน้าหลังหน้าสุดท้ายที่วาดไม่มีผลกับรูป ไม่ต้องคิด
                for t_, n_ in _phreq(name, d, M, i == 1, ttl): _phtake(used, t_, n_, sorted(os.listdir(os.path.join(eng.IMG, t_))))
            continue
        _d_ph = d
        _drawn.append(d)
        d0, hs = d, ()
        if i - 1 in ins:
            if hint: d, hs = hinted(d, ins[i - 1] if isinstance(ins, dict) else '', name)
            else: d = unblank(d)
        lay_ = (d.get('chart') or {}).get('lay') if name.startswith(('chb_', 'chc_')) else None
        if hint and lay_ and lay_charts.lay_norm(lay_)['n'] != 'none' and lay_charts.lay_norm(lay_)['k'] == 1 and not str(d.get('note') or '').strip():
            d0 = {**d0, 'note': ''}; d = {**d, 'note': NOTEPH, '_nph': 1}; hs = set(hs) | {NOTEPH}   # ใบ 028 ไอซ์ "ช่องจาง แตะเพื่อเพิ่มคำอธิบาย" บนจอเท่านั้น ไม่ออกในไฟล์
        dd = dict(topic=M.get('topic', 'office'), foot=ttl, n=f'{i:02d}')
        dd.update(d)
        if BR.get('company') and 'brand' in dd: dd['brand'] = BR['company']
        if dd.get('_nf'): dd['_nf'] = [[_commas(f) for f in s_] for s_ in dd['_nf']]   # ไอซ์ 1 พ.ย. "พวกกราฟต่างๆอยากให้ตัวเลขมี , ด้วยแบบ default" (ค่าที่เก็บไม่เปลี่ยน)
        if BR.get('chartc'): dd['_pal'] = BR['chartc']           # คู่สีกราฟทั้งไฟล์ (ใบ 023) หน้าที่ตั้งสีเฉพาะกราฟ (d['chart']['colors']) ชนะ   # ชื่อบริษัทที่ลูกค้าพิมพ์ แทนช่องแบรนด์ของดีไซน์ (ใบ 007)
        if i == 1 and name in [n for n, _ in deck_of(M['slug'])['SEQ'][:1]]:
            dd0 = dict(dd); _covfill(dd, seq, M)
            if ''.join(str(dd.get('k', '')).split()) and ''.join(str(dd.get('k', '')).split()) in ''.join(ttl.split()):
                dd['k'] = ''                               # ป้ายบนปกไม่ซ้ำชื่อเรื่อง (ป้ายว่างถูกลบทั้งแคปซูล)
            strip_ = lambda x: {k: v for k, v in x.items() if k not in ('topic', 'foot', 'n')}
            if dd != dd0 and overflow(name, strip_(dd), M) and not overflow(name, strip_(dd0), M):
                dd = dd0                                   # ตัวเลขบนปกที่ยกจากหน้าอื่นทำให้ปกล้น/ชนกัน: ไม่ใส่ (ยังอยู่ในหน้าเดิมครบ)
            eng.setvar(sum(ord(c) * (k + 3) for k, c in enumerate(M['slug'])))
        else:
            eng.setvar(0)
        rec_ = []; eng.PHPICK = lambda t_, n_, fs_: (rec_.append((t_, n_)), _phtake(used, t_, n_, fs_))[1]
        lay_cov3.TTL2.clear()
        try: lay.L[name](prs, dd)
        finally: eng.PHPICK = None
        k_ = _phkey(name, _d_ph, M, i == 1)
        if k_ is not None: _PHREQ[k_] = rec_
        sl_ = prs.slides[-1]                                 # ใบ 026: สีตรงตายตัวของ layout ตามสีของไฟล์ / รูปในดีไซน์ / สีชิ้น
        if BR.get('theme'): _recolour(sl_, {ROLE0[r]: v for r, v in roles_now().items() if v != ROLE0[r]})
        dps = _dpics(sl_)
        if d.get('dpic'): apply_dpics(sl_, d, dps)
        sl_.part._d2s_dp = {s.shape_id: (n, src[1], _aspect(s), os.path.relpath(src[0], eng.IMG)) for n, (s, src) in enumerate(dps) if s._element.getparent() is not None}   # (N, โหมด bw, กว้าง/สูงของรูปจริง)
        cols = _colshapes(sl_); apply_shc(sl_, d, cols); shc_ = d.get('shc') or {}
        sl_.part._d2s_col = {s.shape_id: (k, _colhex(shc_[k]) if k in shc_ else c) for s, k, c in cols}
        sl_.part._d2s_own = {s.shape_id for s, k, c in cols if str(shc_.get(k, '')).startswith('#')}
        if d.get('add'): draw_adds(prs.slides[-1], d, hint)  # ใบ 022 ข้อความ/รูปที่ลูกค้าเพิ่ม (ก่อนขนาด/ฟอนต์/รูปแบบ เพื่อให้แต่งได้เหมือนกล่องเดิม)
        if dd.get('_nf'): numfmt(prs.slides[-1], dd['_nf'], dd.get('_sn'))
        chart_commas(prs.slides[-1])                       # ไอซ์ 1 พ.ย. ตัวเลขในกราฟมีตัวคั่นหลักพันเสมอ
        head_a1(prs.slides[-1], dd)                        # ใบ 034 หัวคอลัมน์แรก (รายการ) ลง A1 ของชีตฝัง
        if dd.get('bsz'): shrink_text(prs.slides[-1], dd['bsz'])
        if dd.get('_big'): bigtext(prs.slides[-1], dd['_big'])
        if d.get('usz') or d.get('ffam'): styles(prs.slides[-1], d)
        if dd.get('fsz'): fsize(prs.slides[-1], dd)
        if dd.get('_tz'): tsize(prs.slides[-1], dd)
        scrub(prs.slides[-1], list(strings(dd)) + [ttl]); tidy(prs.slides[-1], d); drop_empty(prs.slides[-1]); thai_spacing(prs.slides[-1]); bind_nums(prs.slides[-1])
        if i == 1 and eng.vch(0, 2) and not M.get('nomirror'): eng.mirror(prs.slides[-1])
        if d.get('tfm'): fmts(prs.slides[-1], d)            # ใบ 030 ข้อ 2: หลังพลิกปก ไม่งั้นชิดซ้ายที่ลูกค้าเลือกถูกพลิกเป็นชิดขวา (ไอซ์ "เลือกปรับเป็นชิดซ้ายไม่ได้")
        apply_moves(prs.slides[-1], d, prs.slide_width, prs.slide_height)   # ตำแหน่งที่ลูกค้าลากเป็นตำแหน่งบนจอ (หลังพลิกปก)
        if d.get('z'): zorder(prs.slides[-1], d)            # ลำดับชั้นจริงของ PowerPoint = ลำดับใน spTree (ใบ 019 เลเยอร์)
        if d.get('rot') or d.get('lock'): box_props(prs.slides[-1], d)   # หมุน (a:xfrm rot) / ล็อก (a:spLocks) ค่าจริงของ PowerPoint
        textfit(prs.slides[-1], d)                         # กล่องที่ลูกค้าเพิ่ม/ย้าย/แต่ง: กรอบสูงพอดีตัวหนังสือ (ก่อน boxmap = เว็บได้ความสูงเดียวกัน)
        page_extras(prs, prs.slides[-1], d, dd, i - 1 + int(BR.get('start', 1) or 1), i == 1, field=not hint)
        bx = boxmap(prs.slides[-1], d, prs.slide_width, prs.slide_height)
        if lay_cov3.TTL2:                                  # ปกที่แยกหัวเรื่องเป็นกล่องละบรรทัด (ttl2): ขึ้นบรรทัดใหม่แล้วกล่องหัวเรื่องหายจากจอ แก้ต่อไม่ได้ → เว็บปิด Enter (ใบ 015 เฟส 0 P3)
            for b_ in bx:
                if b_['p'][0] in ('t', 't1', 't2'): b_['nobr'] = 1   # ใบ 030: แต่ละบรรทัดย้ายได้เป็นกล่องแยก
        if hs:                                             # คำใบ้: สีเทา + บอกเว็บว่าช่องนี้ยังว่าง (เปิดแก้แล้วช่องพิมพ์ว่าง)
            from pptx.dml.color import RGBColor
            for sh in prs.slides[-1].shapes:
                if sh.has_text_frame and sh.text_frame.text.replace(' ', ' ').strip() in hs:
                    for p in sh.text_frame.paragraphs:
                        for r in p.runs: r.font.color.rgb = RGBColor(0x9A, 0xA3, 0xAF)
            for b in bx:
                try: emp = not str(_get(d0, b['p'])).strip()
                except (KeyError, IndexError, TypeError): emp = False
                if emp: b['ph'] = _get(d, b['p'])
        BOXES.append(bx); CHARTC.append(chart_colors(prs.slides[-1])); CHARTL.append(chart_labels(prs.slides[-1]))
    base.theme_font(prs, M.get('font', 'plex')); LASTPRS[:] = [prs]; PICROT[:] = [pic_rot(x) for x in prs.slides]
    ELFX[:] = [el_fx(x, d_) for x, d_ in zip(prs.slides, _drawn)] if hint else []   # ใบ 027 ภาพองค์ประกอบบนจอ (pptx-preview วาด custGeom ไม่ครบ)
    DPFX[:] = [[[i, 1] for i, x in enumerate(sl.shapes) if getattr(x, 'shape_type', None) == 13 and _blip(x) is not None and _blip(x).find('{http://schemas.openxmlformats.org/drawingml/2006/main}grayscl') is not None] for sl in prs.slides]   # ใบ 026 pptx-preview ไม่วาด a:grayscl เว็บใส่ filter
    write_theme(prs)                                       # ใบ 026 สีของไฟล์ลง theme1.xml + สีตรงที่ตรงธีมเป็น schemeClr (ชิ้นที่ลูกค้าตั้งรหัสสีเองคงเป็นสีตรง)
    for sl in prs.slides: _scheme_fills(sl, getattr(sl.part, '_d2s_own', set()))
    if int(BR.get('start', 1) or 1) != 1: prs.part._element.set('firstSlideNum', str(int(BR['start'])))   # เลขหน้าเริ่มที่ (ใบ 007)
    if not hint and only is None: __import__('notes_out').write(prs, [(n_, {**d_, '_note': _note_cc(d_)}) for n_, d_ in seq])   # ใบ 027 ชุด CC BY บนหน้า = บรรทัดเครดิตต่อท้ายโน้ต   # ใบ 025 โน้ตผู้บรรยาย d['_note'] → Notes ของ PowerPoint
    b = io.BytesIO(); prs.save(b)
    return b.getvalue()

FONT_HOWTO = """วิธีติดตั้งฟอนต์ (ทำครั้งเดียวต่อเครื่อง)

Windows: เลือกไฟล์ .ttf ทั้งหมด คลิกขวา แล้วเลือก "ติดตั้งสำหรับผู้ใช้ทั้งหมด" (Install for all users)
Mac: ดับเบิลคลิกไฟล์ .ttf แล้วกด "ติดตั้งฟอนต์" ทีละไฟล์
เสร็จแล้วปิด PowerPoint แล้วเปิดไฟล์สไลด์ใหม่อีกครั้ง

ถ้าเปิดในเครื่องที่ไม่ได้ติดตั้งฟอนต์ ข้อความยังอยู่ครบและแก้ได้ แต่ตัวอักษรจะเปลี่ยนเป็นฟอนต์อื่น
ฟอนต์ทั้งหมดใช้สัญญาอนุญาต SIL Open Font License (ดูไฟล์ OFL.txt) ใช้งานและแจกต่อได้ฟรี
"""

def fonts_zip(files):
    """ฟอนต์ของชุด + สัญญาอนุญาต + วิธีติดตั้ง เป็นไฟล์ zip ให้ลูกค้าโหลดคู่กับ .pptx"""
    import zipfile
    b = io.BytesIO()
    with zipfile.ZipFile(b, 'w', zipfile.ZIP_DEFLATED) as z:
        for f in files: z.write(f'{K}/fonts/{f}', f'ฟอนต์/{f}')
        for fam, fx in [(f, x) for f, x in FONTX.items() if f not in LOCALF]:   # ฟอนต์ฟรีที่ลูกค้าเลือกใช้ (ไม่รวมฟอนต์ในเครื่องลูกค้า)
            for p in {fx[False], fx[True]}:
                if os.path.exists(p): z.write(p, f'ฟอนต์/{os.path.basename(p)}')
        if os.path.exists(f'{K}/fonts/OFL.txt'): z.write(f'{K}/fonts/OFL.txt', 'ฟอนต์/OFL.txt')
        z.writestr('วิธีติดตั้งฟอนต์.txt', FONT_HOWTO)
    return b.getvalue()

def words_missing(items, src):
    """ข้อความบนสไลด์ที่ไม่มีในไฟล์ต้นฉบับ  คำเดียวที่ระบบเติมเองคือ 'สารบัญ'"""
    return [v for _, d in items for v in strings({k: x for k, x in d.items() if k != 'num'})
            if v.strip() and v != 'สารบัญ' and not re.fullmatch(r'[\d.]+', v) and re.sub(r'\s+', '', v) not in src
            and not all(w in src for w in v.split())]   # ป้ายการ์ดตัวเลขตัดตัวเลขออก วลีเลยไม่ติดกัน แต่ทุกคำยังมาจากต้นฉบับ

# ══ ใบ 037 โครงหน้า (outline JSON v1): ข้อมูลกลางระหว่างตัววิเคราะห์ หน้าจอ ตัวสร้าง (และผู้ช่วยในอนาคต) ════════
# หนึ่งหน้า = {id, type, by, title{text,src,ref}, items[{text,src,to,ref}], hints, layout, edited, w}
#   w = แผ่นของตัววิเคราะห์ (dict เดียวกับ want) ตัวสร้างใช้ตัวนี้ ข้อความใน title/items มีไว้ให้จอโชว์และอ้างกลับเอกสาร
#   src: doc = คำลูกค้าตรงตัว / user = ลูกค้าพิมพ์ในโครงหน้า / assistant = ผู้ช่วย (ยังไม่มี ต้องมี accepted ก่อนถึงสไลด์)
#   to: slide | notes (โหมดประกอบการพูด ข้อความเต็มไปโน้ตผู้บรรยาย คำไม่หาย)
# ไม่มี AI: ทุกการแยก รวม เปลี่ยนชนิด ใช้ฟังก์ชันตัวจัดเดิม (shapes points clauses chunk) คำครบเสมอ
OLTYPE = {'cover': 'cover', 'list': 'list', 'pairs': 'list', 'qa': 'list', 'stat': 'numbers', 'chart': 'chart', 'table': 'table',
          'statement': 'quote', 'timeline': 'timeline', 'compare': 'compare', 'divider': 'section'}
OLKIND = {'cover': 'cover', 'list': 'list', 'numbers': 'stat', 'chart': 'chart', 'table': 'table', 'quote': 'statement',
          'timeline': 'timeline', 'compare': 'compare', 'section': 'divider'}
TALK_MAX = 90                                              # ข้อยาวกว่านี้ (ตัวอักษร) ในโหมดประกอบการพูด: บนสไลด์เหลือความแรก ข้อความเต็มไปโน้ต

def _nosp(t): return ''.join(str(t).split())

def _flat(w):
    """แผ่น → (หัวข้อ, [บรรทัด]) คำของลูกค้าครบ ไว้รวม/เปลี่ยนชนิด/โชว์บนจอ"""
    k = w.get('kind'); t = w.get('t') or ''; L = []
    if k == 'statement': t, L = (w.get('s') or ''), [x for x in str(w.get('t') or '').split('\n') if x.strip()]
    elif k in ('cover', 'divider'): L = [w['s']] if w.get('s') else []
    elif k in ('table', 'chart'): L = [' '.join(str(c) for c in r) for r in [w.get('head') or []] + list(w.get('rows') or []) if any(str(c).strip() for c in r)]
    elif k == 'compare': L = [y for g in w.get('items') or [] for y in [g[0]] + list(g[1])]
    elif k == 'stat' and w.get('raw'): L = list(w['raw'])
    else: L = [(': ' if k == 'pairs' and len(x) > 1 and x[1] else ' ').join(str(y) for y in x if str(y).strip()) if isinstance(x, (list, tuple)) else str(x) for x in w.get('items') or []]
    if w.get('note') and k not in ('statement',): L.append(w['note'])
    return t, [x for x in L if str(x).strip()]

def _tup(w):
    """JSON (list) → แผ่นที่ตัวจัดใช้ (tuple ในข้อ/ชุดข้อมูล)"""
    w = dict(w)
    if w.get('items') is not None:
        w['items'] = [(x[0], list(x[1])) if w.get('kind') == 'compare' else tuple(x) if isinstance(x, (list, tuple)) else (x,) for x in w['items']]
    if w.get('series') is not None: w['series'] = [(n, list(v)) for n, v in w['series']]
    return w

def _ref(text, blocks):
    """ข้อความนี้มาจากบล็อกไหนของเอกสาร (เทียบแบบไม่สนช่องว่าง) span = ตำแหน่งตัวอักษรในบล็อก"""
    n = _nosp(text)
    if not n: return []
    for i, b in enumerate(blocks):
        bt = b['text']; k = bt.find(text)
        if k >= 0: return [{'b': b['id'], 'span': [k, k + len(text)]}]
        if n in _nosp(bt): return [{'b': b['id']}]
    return [{'b': b['id']} for b in blocks if _nosp(b['text']) and _nosp(b['text']) in n][:6]   # ข้อที่รวมหลายบรรทัด (หัวข้อ+เนื้อ)

def _blocks():
    out = []
    for b in LASTBLOCKS:
        if b[0] == 'table':
            for r in b[1]: out.append(dict(kind='row', text=' '.join(str(c) for c in r)))
        elif b[0] == 'h': out.append(dict(kind='heading', text=b[2]))
        else: out.append(dict(kind='bullet' if b[0] == 'li' else 'para', text=b[1]))
    for i, b in enumerate(out): b.update(id=f'b{i}', loc={'i': i})   # ponytail: loc = ลำดับบล็อกทุกชนิดไฟล์ (line/para/page/sheet แยกตามชนิดเมื่อมีจอที่ต้องใช้)
    return out

def talk(w, lim=TALK_MAX):
    """โหมดประกอบการพูด: ข้อยาวเหลือความแรกบนสไลด์ ข้อความเต็มไป _note (โน้ตผู้บรรยาย ในไฟล์ PowerPoint) คำไม่หาย
    lim = ความยาวที่เริ่มย่อ (ตัวจัดใช้ lim ต่ำเมื่อชุดนี้ใส่ข้อเดียวที่ 18pt ไม่ได้)"""
    k = w.get('kind'); notes = []; w = dict(w)
    def short(x):
        if len(x) <= lim: return None
        c0 = (clauses(x) or [x])[0]
        return c0 if 12 <= len(c0) < len(x) - 8 else None
    if k == 'list' and w.get('items'):
        its = []
        for it in w['items']:
            s_ = short(it[0]) if len(it) == 1 else None
            if s_: notes.append(it[0]); its.append((s_,))
            else: its.append(tuple(it))
        w['items'] = its
    elif (k == 'pairs' or (k == 'qa' and lim < TALK_MAX)) and w.get('items'):
        its = []
        for it in w['items']:
            s_ = short(it[1]) if len(it) > 1 else None
            if s_: notes.append(f'{it[0]}: {it[1]}'); its.append((it[0], s_))
            else: its.append(tuple(it))
        w['items'] = its
    elif k == 'statement' and len(str(w.get('t') or '')) > lim * 1.5:
        ls = [x for x in str(w['t']).split('\n') if x.strip()]
        keep = [short(x) or x for x in ls]
        if keep != ls: notes += ls; w['t'] = '\n'.join(keep)
    if notes: w['_note'] = '\n'.join(([w['_note']] if w.get('_note') else []) + notes)
    return w

def _page(w, blocks, i, by='analyzer'):
    t, L = _flat(w); tw = talk(w) if w.get('kind') in ('list', 'pairs', 'statement') else w
    _, Lt = _flat(tw); moved = [x for x in L if x not in Lt]
    src = 'user' if w.get('_user') else 'doc'
    return dict(id=f'p{i}', type=OLTYPE.get(w.get('kind'), 'list'), by=by, conf=1,
                title=dict(text=t, src=src, ref=_ref(t, blocks)),
                items=[dict(text=x, src=src, to='notes' if x in moved else 'slide', ref=_ref(x, blocks)) for x in L],
                hints=[], layout=None, edited=by == 'user', w=w)

def outline_of(want, ttl, name='', kind='text'):
    """ผลตัววิเคราะห์ → โครงหน้า (เรียกต่อจาก analyze)"""
    blocks = _blocks()
    on = [c for c in want if not c.get('_off')]
    ol = dict(v=1, doc=dict(id=__import__('hashlib').sha1(''.join(b['text'] for b in blocks).encode()).hexdigest()[:16], name=name, kind=kind, blocks=blocks),
              title=ttl, brief=dict(use='talk', pages='auto', audience=None), target=dict(n=len(on)),
              design=dict(set=None, by=None), pages=[_page(c, blocks, i) for i, c in enumerate(on)],
              off=[c for c in want if c.get('_off')], dropped=[], seq=len(on))
    return ol_refresh(ol)

def ol_want(ol):
    """โครงหน้า → แผ่นที่ตัวสร้างใช้ (โหมดประกอบการพูด = ข้อยาวไปโน้ต) สารบัญที่ปิดไว้ยังเปิดได้ในตัวแก้"""
    sp = (ol.get('brief') or {}).get('use') == 'talk'
    ws = [_tup(p['w']) for p in ol['pages']]
    ws = [dict(talk(w), _big=18) if sp and w.get('kind') != 'cover' else w for w in ws]   # ประกอบการพูด: เนื้อหา >= 18pt (ไอซ์ 2 พ.ย.)
    if ws and ws[0].get('kind') == 'cover': return ws[:1] + [_tup(w) for w in ol.get('off') or []] + ws[1:]
    return [_tup(w) for w in ol.get('off') or []] + ws

def _new(ol, w, by='user'):
    ol['seq'] = ol.get('seq', len(ol['pages'])) + 1
    p = _page(w, ol['doc']['blocks'], ol['seq'], by); return p

def _cut(w, a, b):
    """ส่วนหนึ่งของแผ่น (ข้อ/แถว a:b) คงคีย์อื่นไว้ ตารางกราฟตัดชุดข้อมูลตามแถว"""
    x = {k: v for k, v in w.items() if k not in ('_share', '_lead', '_leadend')}
    if w.get('rows'):
        x['rows'] = w['rows'][a:b]
        if 'cats' in w: x['cats'] = w['cats'][a:b]
        if 'vals' in w: x['vals'] = w['vals'][a:b]
        if 'series' in w: x['series'] = [(n, list(v)[a:b]) for n, v in w['series']]
        if '_nf' in w: x['_nf'] = [f[a:b] for f in w['_nf']]
    else:
        x['items'] = list(w['items'])[a:b]
        if w.get('raw'): x['raw'] = list(w['raw'])[a:b]
        if a and w.get('note'): x['note'] = ''              # ข้อความนำอยู่กับส่วนแรก ไม่ซ้ำ
    return x

def _halves(w, at=None):
    """แยกแผ่นเป็นสองแผ่น คำครบ  แยกไม่ได้ → None"""
    k = w.get('kind'); n = len(w.get('rows') or w.get('items') or [])
    if k in ('cover', 'divider'): return None
    if k == 'compare' and n >= 2:                         # กลุ่มละหน้า หัวข้อเดิมของหน้าเทียบอยู่ทุกหน้า ชื่อกลุ่มเป็นข้อแรก
        T = w.get('t') or ''
        return [dict(kind='list', t=T or g[0], ordered=False, note='', items=([(g[0],)] if T else []) + [(y,) for y in g[1]], _sec=w.get('_sec')) for g in w['items']]
    if n >= 2:
        h = at if at and 0 < at < n else -(-n // 2)
        return [_cut(w, 0, h), _cut(w, h, n)]
    t, L = _flat(w)
    txt = L[0] if len(L) == 1 else ''
    if k == 'statement' and len(L) >= 2:
        h = -(-len(L) // 2); return [dict(w, t='\n'.join(L[:h])), dict(w, t='\n'.join(L[h:]))]
    if txt and len(txt) > 40:                              # ข้อเดียวยาว: ตัดที่รอยต่อความใกล้กึ่งกลาง
        cl = clauses(txt)
        if len(cl) < 2: cl = _wsplit(txt, max(24, len(txt) // 2))
        if len(cl) >= 2:
            h = min(range(1, len(cl)), key=lambda j: abs(len(' '.join(cl[:j])) - len(txt) / 2))
            a_, b_ = ' '.join(cl[:h]), ' '.join(cl[h:])
            if k == 'statement': return [dict(w, t=a_), dict(w, t=b_)]
            base = {kk: v for kk, v in w.items() if kk not in ('items', 'raw')}
            return [dict(base, kind='list', items=[(a_,)]), dict(base, kind='list', items=[(b_,)], note='')]
    return None

def _merge(a, b):
    """รวมสองแผ่น คำครบ: ตารางหัวเดียวกัน = ต่อแถว / อื่น ๆ = รายการเดียว (หัวข้อของแผ่นหลังเป็นข้อ)"""
    if a.get('kind') in ('table', 'chart') and b.get('kind') in ('table', 'chart') and list(a.get('head') or []) == list(b.get('head') or []):
        rows = [list(r) for r in list(a['rows']) + list(b['rows'])]
        x = shapes(dict(t=a.get('t') or b.get('t') or '', num='', body=[('table', [list(a['head'])] + rows)]))[0]
        x['note'] = ' '.join(y for y in (a.get('note'), b.get('note')) if y); x['_sec'] = a.get('_sec'); return x
    ta, la = _flat(a); tb, lb = _flat(b); t = ta or tb
    L = la + ([tb] if tb and tb != t else []) + lb
    return dict(kind='list', t=t, ordered=False, note='', items=[(x,) for x in L], _sec=a.get('_sec'))

def _retype(w, typ):
    """เปลี่ยนชนิดหน้า ใช้ตัววิเคราะห์เดิม (shapes) กับคำของหน้านี้ ได้ชนิดนั้นไม่ได้ = None"""
    kind = OLKIND.get(typ); t, L = _flat(w)
    if not kind or kind == w.get('kind'): return None
    if kind == 'list': return dict(kind='list', t=t, ordered=False, note='', items=[(x,) for x in L], _sec=w.get('_sec'))
    if kind == 'statement': return dict(kind='statement', t='\n'.join(L) or t, s=t if L else '', _sec=w.get('_sec'))
    if kind == 'divider': return dict(kind='divider', t=t or (L[0] if L else ''), s=' '.join(L if t else L[1:]), num='', _sec=w.get('_sec'))
    if kind == 'cover': return dict(kind='cover', t=t or (L[0] if L else ''), **({'s': ' '.join(L if t else L[1:])} if (L if t else L[1:]) else {}), _sec=None)
    if kind == 'table' and w.get('rows'): return dict(kind='table', t=t, note=w.get('note', ''), head=list(w['head']), rows=[list(r) for r in w['rows']], _sec=w.get('_sec'))
    body = [('table', [list(w['head'])] + [list(r) for r in w['rows']])] if w.get('rows') else [('li', x, False) for x in L]
    got = [x for x in shapes(dict(t=t, num='', body=body)) if x['kind'] == kind]
    if len(got) == 1: return dict(got[0], _sec=w.get('_sec'))
    return None

def ol_types(ol, i):
    """ชนิดที่หน้านี้เปลี่ยนได้ [(ชนิด, แนะนำ)] แนะนำ = ตัววิเคราะห์อ่านเนื้อหานี้ได้ชนิดนั้น"""
    w = ol['pages'][i]['w']; cur = OLTYPE.get(w.get('kind'))
    t, L = _flat(w)
    body = [('table', [list(w['head'])] + [list(r) for r in w['rows']])] if w.get('rows') else [('li', x, False) for x in L]
    rec = {OLTYPE.get(x['kind']) for x in shapes(dict(t=t, num='', body=body))} if L else set()
    out = []
    for typ in ('chart', 'table', 'numbers', 'list', 'compare', 'timeline', 'quote', 'section', 'cover'):
        if typ == cur: out.append((typ, typ in rec, True)); continue
        if typ == 'cover' and i: continue
        if _retype(w, typ) is not None: out.append((typ, typ in rec and typ not in ('list', 'quote', 'section'), False))
    return out

def ol_refresh(ol):
    """เลขหน้า ป้ายเตือน (ทีละเรื่อง จอโชว์อันแรก) และจำนวนหน้าเทียบเป้า หลังทุกการแก้"""
    for k, p in enumerate(ol['pages']):
        w = p['w']; t, L = _flat(w); hs = []
        if len(L) >= 2 and len(set(groups(L))) > 1 and sum(1 for x in L if TOPIC.match(x)) >= 1 and w.get('kind') in ('list', 'statement'):
            hs.append('two_topics')
        if k > 1 and not t and L and cont((L[0].split() or [''])[0]): hs.append('continues_prev')
        p['hints'] = hs
    n = len(ol['pages']); pg = (ol.get('brief') or {}).get('pages', 'auto')
    ol['target'] = dict(n=n if pg == 'auto' else int(pg), have=n, fit=pg == 'auto' or int(pg) == n)
    return ol

def ol_split(ol, i, by='user'):
    p = ol['pages'][i]; w = p['w']; at = None
    if 'two_topics' in p['hints']:
        t, L = _flat(w); gs = groups(L); at = next((j for j in range(1, len(gs)) if gs[j] != gs[j - 1]), None)
        if w.get('kind') == 'statement' and at:
            ol['pages'][i:i + 1] = [_new(ol, dict(w, t='\n'.join(L[:at])), by), _new(ol, dict(w, t='\n'.join(L[at:])), by)]; return ol_refresh(ol)
    hv = _halves(w, at)
    if not hv: return None
    ol['pages'][i:i + 1] = [_new(ol, x, by) for x in hv]
    return ol_refresh(ol)

def ol_merge(ol, i, by='user'):
    """รวมหน้า i กับหน้าถัดไป"""
    if i + 1 >= len(ol['pages']) or ol['pages'][i]['w'].get('kind') == 'cover': return None
    ol['pages'][i:i + 2] = [_new(ol, _merge(ol['pages'][i]['w'], ol['pages'][i + 1]['w']), by)]
    return ol_refresh(ol)

def ol_retype(ol, i, typ, by='user'):
    w2 = _retype(ol['pages'][i]['w'], typ)
    if w2 is None: return None
    ol['pages'][i] = _new(ol, w2, by); return ol_refresh(ol)

def ol_add(ol, text):
    """ลูกค้าพิมพ์หัวข้อหน้าใหม่ในโครงหน้า = หน้าคั่นบท (src user) ต่อท้าย"""
    t = ' '.join(str(text or '').split())[:120]
    if not t: return None
    ol['pages'].append(_new(ol, dict(kind='divider', t=t, s='', num='', _user=1), 'user')); return ol_refresh(ol)

def ol_open(ol, i):
    """ข้อมูลเมนูของหน้า i: แยกได้ไหม (ไม่โชว์ปุ่มที่กดไม่ได้)"""
    return dict(split=_halves(ol['pages'][i]['w']) is not None or 'two_topics' in ol['pages'][i]['hints'])

def ol_fit(ol, n):
    """ทำจำนวนหน้าให้ใกล้เป้า n: รวมคู่ที่สั้นที่สุด (หัวข้อเดียวกันก่อน) หรือแยกหน้าที่ยาวที่สุด คำครบ ไม่เติมเนื้อหาเอง"""
    ol['brief']['pages'] = n
    size = lambda w: len(''.join(_flat(w)[1])) + len(_flat(w)[0])
    while len(ol['pages']) > n:
        ps = ol['pages']
        cand = [(ps[j]['w'].get('_sec') != ps[j + 1]['w'].get('_sec'), size(ps[j]['w']) + size(ps[j + 1]['w']), j) for j in range(len(ps) - 1)
                if ps[j]['w'].get('kind') != 'cover' and ps[j + 1]['w'].get('kind') != 'cover'
                and (not ({ps[j]['w'].get('kind'), ps[j + 1]['w'].get('kind')} & {'chart', 'table', 'stat', 'timeline'})   # ไม่รวมกราฟ/ตาราง/การ์ดตัวเลขเป็นรายการ (เสียหน้าตาข้อมูล)
                     or (ps[j]['w'].get('kind') in ('chart', 'table') and list(ps[j]['w'].get('head') or []) == list(ps[j + 1]['w'].get('head') or ['-'])))]
        if not cand: break
        ol_merge(ol, min(cand)[2], by='analyzer')
    tried = set()
    while len(ol['pages']) < n:
        ps = ol['pages']; order_ = sorted(range(len(ps)), key=lambda j: -size(ps[j]['w']))
        j = next((j for j in order_ if ps[j]['id'] not in tried and _halves(ps[j]['w'])), None)
        if j is None: break
        tried.add(ps[j]['id']); ol_split(ol, j, by='analyzer')
    return ol_refresh(ol)


if __name__ == '__main__':
    a = [x for x in sys.argv[1:] if not x.startswith('--')]
    path = os.path.abspath(a[0]); slug, e = slug_of(a[1])
    if not deck_of(slug): sys.exit(f'ชุด {a[1]} {e["th"]} ยังไม่มีไฟล์ต้นฉบับใน decks/ (มีแต่ .pptx)')
    ttl, want = analyze(path)
    M, out, log = plan(want, slug)
    print(f'ชุด {e["no"]} {e["th"]} ({e["theme"]})')
    for i, (c, nm, why, err) in enumerate(log, 1):
        n = len(c.get('items') or c.get('rows') or [])
        print(f'{i:2d}. {c["t"][:26]:<26} | {c["kind"]:<9} {n or "":>2} → {nm or "-"}  {err}')
        for w in why[:4]: print(f'        ข้าม {w}')
    items = [(x['layout'], x['d']) for x in out]
    print('ข้อความที่ไม่มีในต้นฉบับ:', [w for w in words_missing(items, source_text(path)) if w != ttl] or 'ไม่มี (ชื่อเรื่องจากชื่อไฟล์ไม่นับ)')
    os.makedirs(f'{K}/out', exist_ok=True)
    stem = re.sub(r'[^a-z0-9]+', '', os.path.splitext(os.path.basename(path))[0].lower())[:10] or 'doc'
    dst = f'{K}/out/d2s{a[1]}_{stem}.pptx'
    open(dst, 'wb').write(render(items, M, ttl)); print('→', dst)
    if '--render' in sys.argv:
        subprocess.run([f'{K}/../kit/render.sh', dst, dst[:-5] + '.pdf'], check=True)
