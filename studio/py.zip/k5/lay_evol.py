"""20 เลย์เอาต์ชุด Business Evolution Roadmap — ลอกโครงจากเทมเพลตดำ+เขียวมะนาว

พื้นดำ การ์ดเทาเข้มมุมมน ตัวเน้นเป็นไล่เฉดไลม์ไปเขียว ป้ายเม็ดยาเล็ก ๆ กำกับเฟส
หัวเรื่องขาวน้ำหนักกลาง ตัวเลขใหญ่เป็นไลม์หรือขาว
"""
from eng import *
import eng
from lay import L, reg

M = 0.68
R = 0.085          # ความมนของการ์ด


def _duo():
    if P.get('dark'):
        return f"duo:{mix(P['bg'], P['acc'], 0.26)}:{mix(P['acc'], 'FFFFFF', 0.40)}"
    return f"duo:{mix(P['ink'], P['acc'], 0.42)}:{mix(P['bg'], P['acc'], 0.13)}"


def _card(s, x, y, w, h, fill=None, adj=R):
    return shp(s, 'round', x, y, w, h, fill or P['panel'], adj=adj)


def _grad(s, x, y, w, h, ang=300, adj=R, kind='round'):
    return gradband(s, x, y, w, h, ang, c1=P['acc'], c2=P['acc2'], kind=kind, adj=adj)


def _pill(s, x, y, t, lime=False, sz=13):
    if not t: return 0
    w = len(t) * 0.062 + 0.40
    shp(s, 'round', x, y, w, 0.30, P['acc'] if lime else mix(P['bg'], P['ink'], 0.16), adj=0.5)
    txt(s, x, y, w, 0.30, t, sz, P['bg'] if lime else P['ink'], 'md', 'c', 'm')
    return w


def _h(s, x, y, t, sz=40, w=7.0, c=None):
    txt(s, x, y, w, 2.0, t, sz, c or P['ink'], 'md', sp=1.16)


def _p(s, x, y, w, t, sz=13, c=None):
    txt(s, x, y, w, 1.4, t, sz, c or mix(P['bg'], P['ink'], 0.58), 'rg', sp=1.46)


def _n(s, d, c=None):
    if d.get('n'):
        txt(s, W - M - 0.8, H - 0.48, 0.8, 0.24, f"{int(d['n']):02d}", 7, c or mix(P['bg'], P['ink'], 0.40), 'rg', 'r')


def _plus(s, cx, cy, r=0.26, dark=True):
    shp(s, 'oval', cx - r, cy - r, r * 2, r * 2, P['bg'] if dark else 'FFFFFF')
    c = 'FFFFFF' if dark else P['bg']
    ln(s, cx - r * 0.42, cy, cx + r * 0.42, cy, c, 1.3)
    ln(s, cx, cy - r * 0.42, cx, cy + r * 0.42, c, 1.3)


# ══ เลย์เอาต์ตามรูปอ้างอิง ═════════════════════════════════════════════════

@reg
def ev_cover(prs, d):
    s = page(prs)
    _grad(s, 0, 0, W, H, 300, adj=None, kind='rect')
    for i in range(7):                       # เส้นโค้งซ้อนเป็นพื้นหลัง แบบต้นฉบับ
        shp(s, 'oval', -3.4 + i * 0.42, -2.6 + i * 0.34, 11.0 - i * 0.9, 11.0 - i * 0.9,
            None, line=mix(P['acc'], P['bg'], 0.10 + i * 0.11), lw=22)
    _p(s, M, 0.74, 5.4, d.get('k', ''), 14.5, mix(P['bg'], P['acc'], 0.30))
    txt(s, M, 1.26, 9.0, 2.3, d['t'], 54, P['bg'], 'md', sp=1.12)
    _pill(s, M, 4.42, d.get('tag', ''), True, 8)
    for i, (v, lab) in enumerate(d['items'][:2]):
        x = 8.00 + i * 2.30
        txt(s, x, 3.46, 2.1, 0.56, v, 34, P['bg'], 'md')
        _p(s, x, 4.10, 2.1, lab, 13.5, mix(P['bg'], P['acc'], 0.26))
    _n(s, d)


@reg
def ev_photo_head(prs, d):
    s = page(prs)
    pic(s, ph(d['topic'], d.get('pi', 0)), M, 0.62, W - M * 2, 2.70, geom='roundRect', adj=0.05, mode=_duo())
    _p(s, M, 3.66, 5.0, d.get('k', ''), 13)
    _h(s, M, 3.98, d['t'], 40, 6.4)
    x = W - M
    for t in d.get('tags', [])[:2][::-1]:
        w = _pill(s, x - (len(t) * 0.062 + 0.40), 4.22, t, t == d['tags'][0])
        x -= w + 0.16
    _p(s, M, 5.48, 7.4, d.get('note', ''), 13)
    _n(s, d)


@reg
def ev_three_cards(prs, d):
    s = page(prs)
    _h(s, M, 0.72, d['t'], 37, 7.0)
    _p(s, M, 1.70, 5.4, d.get('k', ''), 13)
    cw = (W - M * 2 - 0.46) / 3
    for i, (v, body) in enumerate(d['items'][:3]):
        x = M + i * (cw + 0.23)
        hot = i == 1
        (_grad if hot else _card)(s, x, 2.54, cw, 2.58)
        c = P['bg'] if hot else P['ink']
        txt(s, x + 0.34, 2.86, cw - 0.68, 0.60, v, 36, c, 'md')
        _p(s, x + 0.34, 3.60, cw - 0.74, body, 13, mix(P['acc'], P['bg'], 0.74) if hot else None)
        _plus(s, x + cw - 0.52, 2.90, 0.20, not hot)
    _n(s, d)


@reg
def ev_bignum_ghost(prs, d):
    s = page(prs)
    txt(s, M, 1.00, 4.4, 1.3, d['big'], 54, 'FFFFFF', 'md')
    _p(s, 5.40, 1.14, 1.9, d.get('k', ''), 13.5, P['ink'])
    _p(s, 7.70, 1.14, 4.6, d['note'], 13)
    _p(s, M, 3.80, 3.4, d.get('k2', ''), 13)
    txt(s, M, 4.12, 10.0, 1.2, d['ghost'], 51, mix(P['bg'], P['ink'], 0.16), 'md')
    _pill(s, 8.20, 4.46, d.get('tag', ''), True)
    _n(s, d)


@reg
def ev_circle_big(prs, d):
    s = page(prs)
    _grad(s, 0, 0, W, H, 300, adj=None, kind='rect')
    shp(s, 'oval', 6.40, -1.60, 8.6, 8.6, mix(P['acc'], 'FFFFFF', 0.30))
    _p(s, M, 0.72, 6.2, d.get('note', ''), 13.5, mix(P['bg'], P['acc'], 0.26))
    _pill(s, M, 3.26, d.get('tag', ''), False)
    txt(s, M, 3.80, 6.0, 1.6, d['t'], 45, P['bg'], 'md', sp=1.14)
    _plus(s, 9.90, 2.34, 0.30, True)
    _n(s, d, mix(P['acc'], P['bg'], 0.74))


@reg
def ev_strategy(prs, d):
    s = page(prs)
    for i in range(5):
        shp(s, 'oval', 7.20 + i * 0.30, -1.20 + i * 0.26, 7.4 - i * 0.6, 7.4 - i * 0.6,
            None, line=mix(P['bg'], P['acc'], 0.08 + i * 0.07), lw=18)
    _h(s, M, 0.86, d['t'], 38, 5.4)
    _grad(s, M, 2.90, 1.90, 1.10)
    txt(s, M + 0.22, 3.06, 1.5, 0.46, d['big'], 27, P['bg'], 'md')
    _p(s, M + 0.22, 3.56, 1.5, d['biglab'], 12.5, mix(P['acc'], P['bg'], 0.74))
    for i, (h_, body) in enumerate(d['items'][:2]):
        x = 2.80 + i * 2.16
        _card(s, x, 2.90, 2.04, 1.10)
        txt(s, x + 0.22, 3.06, 1.7, 0.30, h_, 13, P['ink'], 'md')
        _p(s, x + 0.22, 3.40, 1.66, body, 12.5)
    _p(s, M, 4.50, 5.6, d.get('note', ''), 13)
    _n(s, d)


@reg
def ev_donut(prs, d):
    s = page(prs)
    _h(s, M, 0.80, d['t'], 33, 3.4)
    _p(s, M, 1.84, 3.3, d.get('note', ''), 13)
    for i, (v, lab) in enumerate(d['items'][:2]):
        y = 3.10 + i * 1.26
        txt(s, M, y, 2.6, 0.54, v, 31, P['acc'] if i == 0 else 'FFFFFF', 'md')
        _p(s, M, y + 0.58, 2.6, lab, 13)
        ln(s, M, y + 1.02, M + 2.40, y + 1.02, mix(P['bg'], P['ink'], 0.18), 0.6)
    cx, cy, dia = 6.60, 3.26, 3.70
    a = d['ring']
    ring(s, cx, cy, dia, a[0] / 100, P['acc'], mix(P['bg'], P['ink'], 0.14), 0.30)
    # มุมต้องวนกลับเข้าช่วง 0-360 ก่อน ไม่งั้น blockArc เพี้ยนเป็นวงเต็ม
    st = (270 + 3.6 * a[0]) % 360
    en = (270 + 3.6 * (a[0] + a[1])) % 360
    shp(s, 'arc', cx - dia / 2, cy - dia / 2, dia, dia, 'FFFFFF', adj=[st * 0.6, en * 0.6, 0.30])
    # ทุกป้ายอยู่บนไลม์หรือขาว ใช้สีเข้มทั้งหมดถึงจะอ่านออก
    txt(s, cx - 1.74, cy - 0.26, 1.0, 0.32, f'{a[0]}%', 15, P['bg'], 'md', 'c', 'm')
    txt(s, cx + 0.46, cy - 1.30, 1.0, 0.32, f'{a[1]}%', 15, P['bg'], 'md', 'c', 'm')
    txt(s, cx - 0.50, cy + 1.34, 1.0, 0.32, f'{a[2]}%', 15, P['bg'], 'md', 'c', 'm')
    _n(s, d)


@reg
def ev_progress(prs, d):
    s = page(prs)
    _h(s, M, 0.80, d['t'], 40, 7.6)
    _pill(s, 7.95, 1.02, d.get('tag', ''), True)
    for i, (v, lab) in enumerate(d['items'][:3]):
        x = M + i * 2.62
        txt(s, x, 2.56, 2.2, 0.50, v, 28, 'FFFFFF', 'md')
        _p(s, x, 3.10, 2.3, lab, 13)
    bx, bw, by = M, W - M * 2 - 0.70, 3.84
    shp(s, 'round', bx, by, bw, 0.72, P['panel'], adj=0.30)
    _grad(s, bx, by, bw * d.get('pct', 0.46), 0.72, 0, adj=0.30)
    for f in d.get('ticks', [0.46, 0.70]):
        ln(s, bx + bw * f, by, bx + bw * f, by + 0.72, mix(P['bg'], P['ink'], 0.30), 0.8)
    _plus(s, W - M - 0.34, by + 0.36, 0.26, False)
    _n(s, d)


@reg
def ev_hbars(prs, d):
    s = page(prs)
    _h(s, M, 0.80, d['t'], 37, 7.0)
    gx, gw = 3.10, W - M - 3.10 - 0.80
    mx = max(v for _, v in d['items'][:3]) or 1
    for i, (lab, v) in enumerate(d['items'][:3]):
        y = 2.40 + i * 1.02
        _p(s, M, y + 0.14, 2.2, lab, 13)
        shp(s, 'round', gx, y, gw, 0.62, P['panel'], adj=0.26)
        bw = max(gw * (v / mx) * 0.86, 0.6)
        if i == 0: _grad(s, gx, y, bw, 0.62, 0, adj=0.26)
        else: shp(s, 'round', gx, y, bw, 0.62, mix(P['bg'], P['ink'], 0.22), adj=0.26)
        txt(s, W - M - 0.70, y, 0.70, 0.62, str(v), 9, mix(P['bg'], P['ink'], 0.55), 'rg', 'r', 'm')
    _p(s, M, 5.30, 8.0, d.get('note', ''), 13)
    _n(s, d)


@reg
def ev_tiles_pct(prs, d):
    s = page(prs)
    _p(s, M, 0.76, 4.6, d.get('note', ''), 13)
    for i, (v, lab) in enumerate(d['items'][:3]):
        y = 0.76 + i * 1.46
        txt(s, 8.60, y, 2.6, 0.56, v, 33, 'FFFFFF', 'md', 'r')
        _p(s, 8.60, y + 0.60, 2.6, lab, 13, None)
    spec = [(M, 2.30, 1.70, 1.44, True), (M + 1.86, 3.10, 1.30, 1.06, False), (M + 3.32, 3.10, 1.30, 1.06, False)]
    for i, (it, (x, y, w, h, hot)) in enumerate(zip(d['tiles'][:3], spec)):
        v, lab = it
        (_grad if hot else _card)(s, x, y, w, h)
        txt(s, x + 0.20, y + 0.22, w - 0.40, 0.44, v, 16 if hot else 13,
            P['bg'] if hot else P['ink'], 'md')
        _p(s, x + 0.20, y + 0.72, w - 0.40, lab, 12.5, mix(P['acc'], P['bg'], 0.74) if hot else None)
    _n(s, d)


# ══ อีก 10 เลย์เอาต์ ═══════════════════════════════════════════════════════

@reg
def ev_roadmap(prs, d):
    s = page(prs)
    _h(s, M, 0.80, d['t'], 37, 6.4)
    n = len(d['items'][:4]); cw = (W - M * 2) / n
    ln(s, M, 3.44, W - M, 3.44, mix(P['bg'], P['ink'], 0.16), 0.8)
    for i, (per, h_, v) in enumerate(d['items'][:4]):
        x = M + i * cw
        shp(s, 'oval', x, 3.30, 0.28, 0.28, P['acc'] if i < 2 else mix(P['bg'], P['ink'], 0.24))
        _p(s, x, 2.84, cw - 0.4, per, 13, P['acc'] if i < 2 else None)
        txt(s, x, 3.78, cw - 0.50, 0.56, h_, 15, 'FFFFFF', 'md', sp=1.25)
        w = _pill(s, x, 4.52, v, i < 2)
    _p(s, M, 5.40, 8.4, d.get('note', ''), 13)
    _n(s, d)


@reg
def ev_stack3(prs, d):
    s = page(prs)
    txt(s, M, 0.80, 3.4, 0.58, d['big'], 34, P['acc'], 'md')
    _p(s, M, 1.42, 3.2, d['biglab'], 13)
    _p(s, M, 3.70, 3.0, d.get('k', ''), 13, P['ink'])
    _p(s, M, 4.06, 3.4, d.get('note', ''), 13)
    for i, (v, lab) in enumerate(d['items'][:3]):
        y = 0.80 + i * 1.46
        w = 4.90 - i * 0.70
        hot = i == 0
        (_grad if hot else _card)(s, 4.60, y, w, 1.14)
        txt(s, 4.84, y + 0.22, w - 0.48, 0.48, v, 18, P['bg'] if hot else P['ink'], 'md')
        _p(s, 4.84, y + 0.72, w - 0.48, lab, 12.5, mix(P['acc'], P['bg'], 0.74) if hot else None)
    _n(s, d)


@reg
def ev_grid_tiles(prs, d):
    s = page(prs)
    for i, (v, lab) in enumerate(d['side'][:2]):
        y = 0.86 + i * 1.34
        txt(s, M, y, 2.6, 0.56, v, 31, P['acc'] if i == 0 else 'FFFFFF', 'md')
        _p(s, M, y + 0.60, 2.6, lab, 13)
    spec = [(4.10, 0.86, 2.30, 1.52, 0), (6.56, 0.86, 2.30, 1.52, 1),
            (4.10, 2.54, 2.30, 1.52, 1), (6.56, 2.54, 2.30, 1.52, 0)]
    for (v, lab), (x, y, w, h, hot) in zip(d['items'][:4], spec):
        (_grad if hot else _card)(s, x, y, w, h)
        _p(s, x + 0.24, y + 0.22, w - 0.48, lab, 12.5, mix(P['acc'], P['bg'], 0.74) if hot else None)
        txt(s, x + 0.24, y + 0.62, w - 0.48, 0.56, v, 28, P['bg'] if hot else P['ink'], 'md')
    _p(s, 9.30, 0.90, 3.3, d.get('note', ''), 13)
    _n(s, d)


@reg
def ev_expert(prs, d):
    s = page(prs, 'F4F4F2')
    _h(s, M, 0.88, d['t'], 37, 5.0, '101010')
    _p(s, M, 2.00, 4.6, d.get('note', ''), 13, '4A4A48')
    _p(s, M, 5.10, 3.0, d.get('k', ''), 13, '6E6E6C')
    cw = 2.80
    for i, (name, role, yr) in enumerate(d['items'][:2]):
        x = 6.60 + i * (cw + 0.26)
        shp(s, 'round', x, 1.26, cw, 3.80, 'FFFFFF', adj=0.07)
        pic(s, ph(d.get('ptopic', 'office'), d.get('pi', 3) + i), x + 0.20, 1.46, cw - 0.40, 2.46,
            geom='roundRect', adj=0.07, focus=(0.5, 0.34), mode=_duo())
        txt(s, x + 0.20, 4.10, cw - 0.40, 0.30, name, 15, '101010', 'md')
        _p(s, x + 0.20, 4.44, cw - 0.40, role, 13, '6E6E6C')
        _pill(s, x + cw - 0.82, 1.58, yr, True, 6.5)
    _n(s, d, '8E8E8C')


@reg
def ev_hero_num(prs, d):
    s = page(prs, 'F4F4F2')
    txt(s, M, 1.30, 10.6, 1.9, d['big'], 54, '101010', 'md')
    _p(s, M, 3.42, 6.0, d['biglab'], 13.5, '4A4A48')
    for i, (v, yr) in enumerate(d['items'][:3]):
        x = M + i * 2.10
        hot = i == 2
        if hot: _grad(s, x, 4.30, 1.86, 0.72, 300, adj=0.26)
        else: shp(s, 'round', x, 4.30, 1.86, 0.72, 'E6E6E2', adj=0.26)
        txt(s, x + 0.24, 4.30, 1.2, 0.72, v, 16.5, '101010', 'md', an='m')
        txt(s, x + 1.26, 4.38, 0.54, 0.26, yr, 12.5, '6E6E6C', 'rg')
    _n(s, d, '8E8E8C')


@reg
def ev_phase_cards(prs, d):
    s = page(prs)
    for i, (v, lab) in enumerate(d['side'][:3]):
        y = 0.86 + i * 1.46
        txt(s, M, y, 2.8, 0.56, v, 31, P['acc'] if i == 0 else 'FFFFFF', 'md')
        _p(s, M, y + 0.60, 2.8, lab, 13)
    spec = [(4.40, 0.86, 2.90, 1.26, True), (7.20, 1.92, 2.90, 1.26, False),
            (5.60, 3.18, 2.90, 1.26, False)]
    for (h_, body, yr), (x, y, w, hh, hot) in zip(d['items'][:3], spec):
        (_grad if hot else _card)(s, x, y, w, hh)
        txt(s, x + 0.24, y + 0.20, w - 0.90, 0.28, h_, 13.5, P['bg'] if hot else P['ink'], 'md')
        _p(s, x + 0.24, y + 0.54, w - 0.48, body, 12.5, mix(P['acc'], P['bg'], 0.74) if hot else None)
        txt(s, x + w - 0.62, y + 0.20, 0.44, 0.24, yr, 12.5,
            mix(P['acc'], P['bg'], 0.50) if hot else mix(P['bg'], P['ink'], 0.40), 'rg')
    _n(s, d)


@reg
def ev_journey_bars(prs, d):
    s = page(prs)
    _h(s, M, 0.80, d['t'], 34, 4.6)
    for i, (lab, v) in enumerate(d['items'][:3]):
        y = 2.30 + i * 0.86
        _p(s, M, y - 0.02, 1.4, lab, 13)
        gx, gw = 2.30, W - M - 2.30
        shp(s, 'round', gx, y, gw, 0.46, P['panel'], adj=0.30)
        if i == 0: _grad(s, gx, y, gw * v / 100, 0.46, 0, adj=0.30)
        else: shp(s, 'round', gx, y, gw * v / 100, 0.46, mix(P['bg'], P['ink'], 0.20), adj=0.30)
    _p(s, M, 5.08, 3.4, d.get('k', ''), 13, P['ink'])
    _p(s, M, 5.42, 6.6, d.get('note', ''), 13)
    _n(s, d)


@reg
def ev_exec(prs, d):
    s = page(prs)
    _h(s, M, 0.80, d['t'], 34, 3.4)
    _pill(s, M, 2.26, d.get('tag', ''), True)
    pic(s, ph(d['topic'], d.get('pi', 6)), 4.30, 0.70, 3.30, 2.46, geom='roundRect', adj=0.06, mode=_duo())
    _plus(s, 7.26, 1.02, 0.22, True)
    for i, (v, lab) in enumerate(d['items'][:3]):
        x = M + i * 2.46
        txt(s, x, 3.96, 2.2, 0.52, v, 28, P['acc'] if i < 2 else 'FFFFFF', 'md')
        _p(s, x, 4.52, 2.3, lab, 13)
    _p(s, 8.10, 0.78, 4.5, d.get('note', ''), 13)
    _n(s, d)


@reg
def ev_table(prs, d):
    s = page(prs)
    _h(s, M, 0.80, d['t'], 37, 8.0)
    tw = W - M * 2; cols = d['colw']; y0 = 2.30
    _grad(s, M, y0, tw, 0.52, 0, adj=0.14)
    cx = M
    for j, (hd, fr) in enumerate(zip(d['head'], cols)):
        txt(s, cx + 0.22, y0, tw * fr - 0.44, 0.52, hd, 13.5, P['bg'], 'md', 'l' if j == 0 else 'r', 'm'); cx += tw * fr
    for i, row in enumerate(d['rows'][:5]):
        y = y0 + 0.56 + i * 0.56
        if i % 2 == 0: shp(s, 'round', M, y, tw, 0.52, P['panel'], adj=0.14)
        cx = M
        for j, (cell, fr) in enumerate(zip(row, cols)):
            txt(s, cx + 0.22, y, tw * fr - 0.44, 0.52, cell, 14,
                P['acc'] if j == len(cols) - 1 else mix(P['bg'], P['ink'], 0.80),
                'md' if j == len(cols) - 1 else 'rg', 'l' if j == 0 else 'r', 'm'); cx += tw * fr
    if d.get('note'): _p(s, M, y0 + 0.56 + len(d['rows'][:5]) * 0.56 + 0.16, 9.6, d['note'], 13)
    _n(s, d)


@reg
def ev_close(prs, d):
    s = page(prs)
    _grad(s, 0, 0, W, H, 300, adj=None, kind='rect')
    for i in range(6):
        shp(s, 'oval', 5.0 + i * 0.36, -2.0 + i * 0.30, 9.0 - i * 0.8, 9.0 - i * 0.8,
            None, line=mix(P['acc'], P['bg'], 0.08 + i * 0.09), lw=20)
    txt(s, M, 2.10, 7.4, 1.9, d['t'], 54, P['bg'], 'md', sp=1.12)
    _p(s, M, 4.22, 5.6, d.get('note', ''), 14, mix(P['bg'], P['acc'], 0.30))
    for i, (lab, v) in enumerate(d['items'][:3]):
        x = M + i * 3.70
        _p(s, x, 5.30, 3.4, lab, 13, mix(P['bg'], P['acc'], 0.42))
        txt(s, x, 5.56, 3.4, 0.30, v, 14, P['bg'], 'md')
    _n(s, d, mix(P['bg'], P['acc'], 0.40))
