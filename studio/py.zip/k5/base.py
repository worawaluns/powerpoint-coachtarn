# k3 engine: one module, per-deck theme T. Every deck composes its own slides from these primitives
# so no two decks share a skeleton (Ice: no repeated 01/02 dividers, no stock thank-you layout).
import io, os
from lxml import etree
from PIL import Image, ImageOps
from pptx import Presentation
from pptx.util import Inches, Pt, Emu
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from pptx.enum.shapes import MSO_SHAPE, MSO_CONNECTOR
from pptx.chart.data import CategoryChartData
from pptx.enum.chart import XL_CHART_TYPE, XL_LEGEND_POSITION, XL_LABEL_POSITION
from pptx.oxml.ns import qn
from pptx.opc.package import Part
from pptx.opc.constants import RELATIONSHIP_TYPE as RT

HERE = os.path.dirname(os.path.abspath(__file__))
ICONS = os.path.join(HERE, '..', 'kit', 'icons')
W, H = 13.333, 7.5
I = Inches

FONTS = {  # weight -> (family, bold flag). Families = legacy nameID 1 so PowerPoint picks the right face
    'plex':   {'lt': ('IBM Plex Sans Thai Light', 0), 'rg': ('IBM Plex Sans Thai', 0), 'md': ('IBM Plex Sans Thai SemiBold', 0), 'bd': ('IBM Plex Sans Thai', 1)},
    'kanit':  {'lt': ('Kanit Light', 0), 'rg': ('Kanit', 0), 'md': ('Kanit Medium', 0), 'bd': ('Kanit SemiBold', 0)},
    'anuphan': {'lt': ('Anuphan Light', 0), 'rg': ('Anuphan', 0), 'md': ('Anuphan Medium', 0), 'bd': ('Anuphan', 1)},
    'athiti': {'lt': ('Athiti Light', 0), 'rg': ('Athiti', 0), 'md': ('Athiti SemiBold', 0), 'bd': ('Athiti', 1)},
    'seed':   {'lt': ('LINE Seed Sans TH', 0), 'rg': ('LINE Seed Sans TH', 0), 'md': ('LINE Seed Sans TH', 1), 'bd': ('LINE Seed Sans TH ExtraBold', 0)},
    'mitr':   {'lt': ('Mitr Light', 0), 'rg': ('Mitr Light', 0), 'md': ('Mitr', 0), 'bd': ('Mitr Medium', 0)},
    'pridi':  {'lt': ('Pridi Light', 0), 'rg': ('Pridi Light', 0), 'md': ('Pridi', 0), 'bd': ('Pridi Medium', 0)},
    'mali':   {'lt': ('Mali', 0), 'rg': ('Mali', 0), 'md': ('Mali SemiBold', 0), 'bd': ('Mali', 1)},
    'noto':   {'lt': ('Noto Sans Thai Light', 0), 'rg': ('Noto Sans Thai', 0), 'md': ('Noto Sans Thai SemBd', 0), 'bd': ('Noto Sans Thai', 1)},
    'looped': {'lt': ('Noto Sans Thai Looped Light', 0), 'rg': ('Noto Sans Thai Looped', 0), 'md': ('Noto Sans Thai Looped SemiBold', 0), 'bd': ('Noto Sans Thai Looped', 1)},
}
T = {'font': 'plex', 'head': None, 'ink': '111827', 'mute': '6B7280', 'bg': 'FFFFFF', 'acc': '2563EB'}  # deck sets this

def rgb(h): return RGBColor.from_string(h)

def _font(rPr, wt, fam=None):
    face, bold = FONTS[fam or T['font']][wt]
    rPr.set('lang', 'th-TH'); rPr.set('altLang', 'en-US'); rPr.set('b', str(bold)); rPr.set('i', '0')
    for tag in ('a:latin', 'a:ea', 'a:cs'):
        el = rPr.find(qn(tag))
        if el is None: el = etree.SubElement(rPr, qn(tag))
        el.set('typeface', face)

def _nostyle(shape):
    st = shape._element.find(qn('p:style'))
    if st is not None: shape._element.remove(st)

def deck():
    p = Presentation(); p.slide_width = I(W); p.slide_height = I(H); return p

def new(prs, bg=None, img=None, **kw):
    s = prs.slides.add_slide(prs.slide_layouts[6])
    if bg: shp(s, 'rect', 0, 0, W, H, bg)
    if img: pic(s, img, 0, 0, W, H, **kw)
    return s

def notes(s, t): s.notes_slide.notes_text_frame.text = t

def txt(s, x, y, w, h, t, sz=14, c=None, wt='rg', al='l', an='t', sp=1.0, track=0, fam=None, runs=None, caps=False):
    """t: str ('\\n' = paragraph). runs: [[(text, {sz,c,wt,fam}), ...], ...] for mixed styling. track: letter spacing pt."""
    tb = s.shapes.add_textbox(I(x), I(y), I(w), I(h)); tf = tb.text_frame; tf.word_wrap = True
    tf.margin_left = tf.margin_right = tf.margin_top = tf.margin_bottom = 0
    tf.vertical_anchor = {'t': MSO_ANCHOR.TOP, 'm': MSO_ANCHOR.MIDDLE, 'b': MSO_ANCHOR.BOTTOM}[an]
    if fam is None and T.get('head') and wt in ('bd', 'md') and sz >= 20: fam = T['head']
    base = dict(sz=sz, c=c or T['ink'], wt=wt, fam=fam)
    paras = runs or [[(ln_.upper() if caps else ln_, {})] for ln_ in t.split('\n')]
    for i, pr in enumerate(paras):
        p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
        p.alignment = {'l': PP_ALIGN.LEFT, 'c': PP_ALIGN.CENTER, 'r': PP_ALIGN.RIGHT}[al]; p.line_spacing = sp
        for (tx, o) in pr:
            st = {**base, **o}; r = p.add_run(); r.text = tx
            r.font.size = Pt(st['sz']); r.font.color.rgb = rgb(st['c'])
            rPr = r._r.get_or_add_rPr(); _font(rPr, st['wt'], st['fam'])
            if track: rPr.set('spc', str(int(track * 100)))
    return tb

KIND = {'rect': MSO_SHAPE.RECTANGLE, 'round': MSO_SHAPE.ROUNDED_RECTANGLE, 'oval': MSO_SHAPE.OVAL,
        'snip1': MSO_SHAPE.SNIP_1_RECTANGLE, 'snip2': MSO_SHAPE.SNIP_2_SAME_RECTANGLE, 'snipd': MSO_SHAPE.SNIP_2_DIAG_RECTANGLE,
        'round1': MSO_SHAPE.ROUND_1_RECTANGLE, 'round2': MSO_SHAPE.ROUND_2_SAME_RECTANGLE, 'roundd': MSO_SHAPE.ROUND_2_DIAG_RECTANGLE,
        'tri': MSO_SHAPE.ISOSCELES_TRIANGLE, 'rtri': MSO_SHAPE.RIGHT_TRIANGLE, 'chev': MSO_SHAPE.CHEVRON, 'pent': MSO_SHAPE.PENTAGON,
        'para': MSO_SHAPE.PARALLELOGRAM, 'arc': MSO_SHAPE.BLOCK_ARC, 'donut': MSO_SHAPE.DONUT, 'star': MSO_SHAPE.STAR_5_POINT,
        'hex': MSO_SHAPE.HEXAGON, 'tear': MSO_SHAPE.TEAR, 'wave': MSO_SHAPE.WAVE, 'plus': MSO_SHAPE.CROSS, 'heart': MSO_SHAPE.HEART,
        'moon': MSO_SHAPE.MOON, 'pie': MSO_SHAPE.PIE, 'frame': MSO_SHAPE.FRAME, 'arrow': MSO_SHAPE.RIGHT_ARROW, 'cloud': MSO_SHAPE.CLOUD,
        'flow_doc': MSO_SHAPE.FLOWCHART_DOCUMENT, 'diamond': MSO_SHAPE.DIAMOND, 'oct': MSO_SHAPE.OCTAGON, 'callout': MSO_SHAPE.ROUNDED_RECTANGULAR_CALLOUT}

def shp(s, kind, x, y, w, h, fill=None, line=None, lw=1, adj=None, a=None, grad=None, rot=0, shadow=None, dash=False):
    """grad=(c1, c2, angle_deg[, a1, a2]). shadow=(color, alpha, blur_pt, dist_pt)."""
    sh = s.shapes.add_shape(KIND[kind], I(x), I(y), I(w), I(h)); _nostyle(sh)
    if adj is not None:
        for i, v in enumerate(adj if isinstance(adj, (list, tuple)) else [adj]): sh.adjustments[i] = v
    spPr = sh._element.spPr
    if grad:
        c1, c2, ang = grad[:3]; a1 = grad[3] if len(grad) > 3 else 1; a2 = grad[4] if len(grad) > 4 else 1
        g = etree.SubElement(spPr, qn('a:gradFill')); g.set('rotWithShape', '1'); gl = etree.SubElement(g, qn('a:gsLst'))
        for pos, c, al in ((0, c1, a1), (100000, c2, a2)):
            gs = etree.SubElement(gl, qn('a:gs')); gs.set('pos', str(pos)); cl = etree.SubElement(gs, qn('a:srgbClr')); cl.set('val', c)
            if al < 1: etree.SubElement(cl, qn('a:alpha')).set('val', str(int(al * 100000)))
        etree.SubElement(g, qn('a:lin')).set('ang', str(int(ang * 60000)))
        _order(spPr)
    elif fill:
        sh.fill.solid(); sh.fill.fore_color.rgb = rgb(fill)
        if a is not None: etree.SubElement(spPr.find(qn('a:solidFill')).find(qn('a:srgbClr')), qn('a:alpha')).set('val', str(int(a * 100000)))
    else: sh.fill.background()
    if line:
        sh.line.color.rgb = rgb(line); sh.line.width = Pt(lw)
        if dash:
            from pptx.enum.dml import MSO_LINE_DASH_STYLE
            sh.line.dash_style = MSO_LINE_DASH_STYLE.DASH
    else: sh.line.fill.background()
    if rot: sh.rotation = rot
    if shadow: _shadow(spPr, *shadow)
    tf = sh.text_frame; tf.margin_left = tf.margin_right = tf.margin_top = tf.margin_bottom = 0
    return sh

def _order(spPr):
    """gradFill must sit right after prstGeom (before ln) for schema order"""
    g = spPr.find(qn('a:gradFill')); geom = spPr.find(qn('a:prstGeom'))
    if g is not None and geom is not None: spPr.remove(g); geom.addnext(g)

def _shadow(spPr, color='000000', al=0.18, blur=18, dist=6):
    ef = spPr.find(qn('a:effectLst'))
    if ef is None: ef = etree.SubElement(spPr, qn('a:effectLst'))
    sd = etree.SubElement(ef, qn('a:outerShdw')); sd.set('blurRad', str(int(blur * 12700))); sd.set('dist', str(int(dist * 12700)))
    sd.set('dir', '5400000'); sd.set('algn', 't'); sd.set('rotWithShape', '0')
    c = etree.SubElement(sd, qn('a:srgbClr')); c.set('val', color); etree.SubElement(c, qn('a:alpha')).set('val', str(int(al * 100000)))

def ln(s, x1, y1, x2, y2, c=None, w=1, dash=False):
    cn = s.shapes.add_connector(MSO_CONNECTOR.STRAIGHT, I(x1), I(y1), I(x2), I(y2)); _nostyle(cn)
    cn.line.color.rgb = rgb(c or T['ink']); cn.line.width = Pt(w)
    if dash:
        from pptx.enum.dml import MSO_LINE_DASH_STYLE
        cn.line.dash_style = MSO_LINE_DASH_STYLE.DASH
    return cn

_imgc = {}
def _prep(path, mode):
    key = (path, mode)
    if key in _imgc: return _imgc[key]
    im = Image.open(path).convert('RGB')
    if mode == 'bw': im = ImageOps.grayscale(im).convert('RGB'); im = ImageOps.autocontrast(im, cutoff=1)
    elif mode and mode.startswith('duo:'):  # duo:DARKHEX:LIGHTHEX
        _, d, l = mode.split(':'); im = ImageOps.colorize(ImageOps.grayscale(im), '#' + d, '#' + l)
    elif mode and mode.startswith('dim:'):
        f = float(mode[4:]); im = Image.eval(im, lambda v: int(v * f))
    im.thumbnail((1600, 1600)); buf = io.BytesIO(); im.save(buf, 'JPEG', quality=78); _imgc[key] = (buf.getvalue(), im.size); return _imgc[key]

def pic(s, path, x, y, w, h, geom=None, adj=None, mode=None, focus=(0.5, 0.5), line=None, lw=1, shadow=None, a=None):
    """photo cropped to fill the box (focus = which part to keep), optional preset geometry (roundRect, ellipse,
    round2SameRect, snip1Rect ...). Users can right-click > Change Picture and keep this frame."""
    data, (iw, ih) = _prep(path, mode)
    p = s.shapes.add_picture(io.BytesIO(data), I(x), I(y), I(w), I(h))
    box_r, im_r = w / h, iw / ih
    if im_r > box_r:
        keep = box_r / im_r; off = (1 - keep) * focus[0]; p.crop_left, p.crop_right = off, 1 - keep - off
    else:
        keep = im_r / box_r; off = (1 - keep) * focus[1]; p.crop_top, p.crop_bottom = off, 1 - keep - off
    spPr = p._element.spPr
    if geom:
        pg = spPr.find(qn('a:prstGeom')); pg.set('prst', geom)
        if adj is not None:
            av = pg.find(qn('a:avLst'))
            if av is None: av = etree.SubElement(pg, qn('a:avLst'))
            for i, v in enumerate(adj if isinstance(adj, (list, tuple)) else [adj]):
                gd = etree.SubElement(av, qn('a:gd')); gd.set('name', 'adj' if i == 0 and len(adj if isinstance(adj, (list, tuple)) else [adj]) == 1 else f'adj{i + 1}'); gd.set('fmla', f'val {int(v * 100000)}')
    if line: p.line.color.rgb = rgb(line); p.line.width = Pt(lw)
    if shadow: _shadow(spPr, *shadow)
    if a is not None:
        blip = p._element.find('.//' + qn('a:blip')); etree.SubElement(blip, qn('a:alphaModFix')).set('amt', str(int(a * 100000)))
    return p

_png = {}
def icon(s, name, cx, cy, sz, c=None):
    c = c or T['ink']; key = (name, c)
    if key not in _png:
        im = Image.open(f'{ICONS}/{name}.png').convert('RGBA'); solid = Image.new('RGBA', im.size, '#' + c); solid.putalpha(im.getchannel('A'))
        b = io.BytesIO(); solid.save(b, 'PNG'); _png[key] = b.getvalue()
    p = s.shapes.add_picture(io.BytesIO(_png[key]), I(cx - sz / 2), I(cy - sz / 2), I(sz), I(sz))
    svg = open(f'{ICONS}/{name}.svg', 'rb').read().replace(b'#FFFFFF', b'#' + c.encode())
    pkg = s.part.package; part = Part(pkg.next_partname('/ppt/media/image%d.svg'), 'image/svg+xml', pkg, svg)
    rid = s.part.relate_to(part, RT.IMAGE); blip = p._element.find('.//' + qn('a:blip'))
    ext = etree.SubElement(etree.SubElement(blip, qn('a:extLst')), qn('a:ext')); ext.set('uri', '{96DAC541-7B7A-43D3-8B79-37D633B846F1}')
    etree.SubElement(ext, '{http://schemas.microsoft.com/office/drawing/2016/SVG/main}svgBlip').set(qn('r:embed'), rid)
    return p

# ---------- native charts (editable in PowerPoint; data lives in the embedded sheet) ----------
CT = {'col': XL_CHART_TYPE.COLUMN_CLUSTERED, 'colS': XL_CHART_TYPE.COLUMN_STACKED, 'colP': XL_CHART_TYPE.COLUMN_STACKED_100,
      'bar': XL_CHART_TYPE.BAR_CLUSTERED, 'barS': XL_CHART_TYPE.BAR_STACKED, 'barP': XL_CHART_TYPE.BAR_STACKED_100,
      'line': XL_CHART_TYPE.LINE_MARKERS, 'lineP': XL_CHART_TYPE.LINE, 'area': XL_CHART_TYPE.AREA, 'areaS': XL_CHART_TYPE.AREA_STACKED,
      'donut': XL_CHART_TYPE.DOUGHNUT, 'pie': XL_CHART_TYPE.PIE, 'radar': XL_CHART_TYPE.RADAR_FILLED, 'radarL': XL_CHART_TYPE.RADAR_MARKERS}

def chart(s, kind, x, y, w, h, cats, series, colors, labels=True, fmt='#,##0', legend=False, gap=70, overlap=None, sz=11,
          c=None, axis=True, grid=False, hole=62, lblc=None, smooth=False, vary=False, lw=2.5, maxv=None, lblpos=None, minv=None, only=None):
    cd = CategoryChartData(); cd.categories = cats
    for nm, vals in series: cd.add_series(nm, vals)
    gf = s.shapes.add_chart(CT[kind], I(x), I(y), I(w), I(h), cd); ch = gf.chart
    c = c or T['mute']; ch.font.size = Pt(sz); ch.font.color.rgb = rgb(c); ch.has_title = False
    ch.has_legend = legend
    if legend: ch.legend.position = XL_LEGEND_POSITION.TOP; ch.legend.include_in_layout = False; ch.legend.font.size = Pt(sz)
    pl = ch.plots[0]
    if kind in ('donut', 'pie'):
        pts = pl.series[0].points
        for i, col in enumerate(colors[:len(cats)]):
            pts[i].format.fill.solid(); pts[i].format.fill.fore_color.rgb = rgb(col); pts[i].format.line.fill.background()
        if kind == 'donut':
            dn = ch._chartSpace.find('.//' + qn('c:doughnutChart')); hs = dn.find(qn('c:holeSize'))
            if hs is None: hs = etree.SubElement(dn, qn('c:holeSize'))
            hs.set('val', str(hole))
        pl.has_data_labels = labels
        if labels:
            dl = pl.data_labels; dl.number_format = fmt; dl.number_format_is_linked = False; dl.font.size = Pt(sz); dl.font.color.rgb = rgb(lblc or 'FFFFFF')
    else:
        if hasattr(pl, 'gap_width'): pl.gap_width = gap
        if overlap is not None and hasattr(pl, 'overlap'): pl.overlap = overlap
        if vary and len(series) == 1: pl.vary_by_categories = True
        for i, sr in enumerate(pl.series):
            col = colors[i % len(colors)]
            if kind.startswith('line') or kind.startswith('radar'):
                sr.format.line.color.rgb = rgb(col); sr.format.line.width = Pt(lw); sr.smooth = smooth
                if kind in ('line', 'radarL'):
                    from pptx.enum.chart import XL_MARKER_STYLE
                    sr.marker.style = XL_MARKER_STYLE.CIRCLE; sr.marker.size = 7
                    sr.marker.format.fill.solid(); sr.marker.format.fill.fore_color.rgb = rgb(col); sr.marker.format.line.color.rgb = rgb('FFFFFF')
                if kind == 'radar': sr.format.fill.solid(); sr.format.fill.fore_color.rgb = rgb(col)
            else:
                sr.format.fill.solid(); sr.format.fill.fore_color.rgb = rgb(col); sr.format.line.fill.background()
                if hasattr(sr, 'invert_if_negative'): sr.invert_if_negative = False
                if vary and len(series) == 1:
                    for j, pt in enumerate(sr.points):
                        pt.format.fill.solid(); pt.format.fill.fore_color.rgb = rgb(colors[j % len(colors)])
                    for dpt in sr._element.findall(qn('c:dPt')):
                        if dpt.find(qn('c:invertIfNegative')) is None:
                            iv = etree.Element(qn('c:invertIfNegative')); iv.set('val', '0'); dpt.find(qn('c:idx')).addnext(iv)
        pl.has_data_labels = labels and only is None
        if labels and only is None:
            dl = pl.data_labels; dl.number_format = fmt; dl.number_format_is_linked = False; dl.font.size = Pt(sz); dl.font.color.rgb = rgb(lblc or c)
            if lblpos: dl.position = lblpos
        if only is not None:  # labels on one series only (e.g. actual, not target)
            dl = pl.series[only].data_labels; dl.show_value = True; dl.number_format = fmt; dl.number_format_is_linked = False; dl.font.size = Pt(sz); dl.font.color.rgb = rgb(lblc or c)
            if lblpos: dl.position = lblpos
        try:
            va = ch.value_axis; va.visible = axis and not labels; va.has_major_gridlines = grid
            if grid: va.major_gridlines.format.line.color.rgb = rgb('E5E7EB')
            va.format.line.fill.background(); va.tick_labels.font.size = Pt(sz)
            if maxv: va.maximum_scale = maxv
            if minv is not None: va.minimum_scale = minv
            ca = ch.category_axis; ca.format.line.color.rgb = rgb('D1D5DB'); ca.tick_labels.font.size = Pt(sz); ca.has_major_gridlines = False
            from pptx.enum.chart import XL_TICK_MARK
            ca.major_tick_mark = XL_TICK_MARK.NONE; va.major_tick_mark = XL_TICK_MARK.NONE
            if any(v < 0 for _, vals in series for v in vals):
                from pptx.enum.chart import XL_TICK_LABEL_POSITION
                ca.tick_label_position = XL_TICK_LABEL_POSITION.LOW
        except Exception: pass
    cs = ch._chartSpace
    for el in cs.iter(qn('a:defRPr'), qn('a:rPr')): _font(el, 'rg')
    return ch

def table(s, x, y, w, h, head, rows, colw=None, hf=None, hc='FFFFFF', bf=None, alt=None, sz=12, hsz=None, line=None, al=None, bold_first=False, rowc=None):
    tb = s.shapes.add_table(len(rows) + 1, len(head), I(x), I(y), I(w), I(h)).table
    tbl = tb._tbl; tp = tbl.find(qn('a:tblPr'))
    for k in ('firstRow', 'bandRow'): tp.set(k, '0')
    sid = tp.find(qn('a:tableStyleId'))
    if sid is not None: sid.text = '{5940675A-B579-460E-94D1-54222C63F5DA}'  # "No Style, Table Grid" then we paint
    if colw:
        tot = sum(colw)
        for i, cw in enumerate(colw): tb.columns[i].width = I(w * cw / tot)
    rh = h / (len(rows) + 1)
    for r in range(len(rows) + 1): tb.rows[r].height = I(rh)
    for r, row in enumerate([head] + rows):
        for ci, val in enumerate(row):
            cell = tb.cell(r, ci); cell.margin_left = cell.margin_right = I(0.12); cell.margin_top = cell.margin_bottom = I(0.04)
            cell.vertical_anchor = MSO_ANCHOR.MIDDLE
            f = hf if r == 0 else (rowc(r - 1, ci) if rowc else (alt if (alt and r % 2 == 0) else bf))
            if f: cell.fill.solid(); cell.fill.fore_color.rgb = rgb(f)
            else: cell.fill.background()
            tf = cell.text_frame; tf.text = ''; p = tf.paragraphs[0]
            p.alignment = {'l': PP_ALIGN.LEFT, 'c': PP_ALIGN.CENTER, 'r': PP_ALIGN.RIGHT}[(al or ['l'] + ['c'] * 20)[ci]]
            rr = p.add_run(); rr.text = str(val); rr.font.size = Pt(hsz or sz) if r == 0 else Pt(sz)
            rr.font.color.rgb = rgb(hc if r == 0 else T['ink']); _font(rr._r.get_or_add_rPr(), 'md' if r == 0 or (bold_first and ci == 0) else 'rg')
            tcPr = cell._tc.get_or_add_tcPr()
            for side in ('a:lnL', 'a:lnR', 'a:lnT', 'a:lnB'):
                l_ = etree.SubElement(tcPr, qn(side)); l_.set('w', '0' if (side != 'a:lnB' or not line) else '9525')
                if side == 'a:lnB' and line:
                    sf = etree.SubElement(l_, qn('a:solidFill')); etree.SubElement(sf, qn('a:srgbClr')).set('val', line)
                else: etree.SubElement(l_, qn('a:noFill'))
    return tb

def mix(a, b, t):
    """blend hex a->b by t (0..1)"""
    pa = [int(a[i:i + 2], 16) for i in (0, 2, 4)]; pb = [int(b[i:i + 2], 16) for i in (0, 2, 4)]
    return ''.join(f'{round(x + (y - x) * t):02X}' for x, y in zip(pa, pb))

def img(deck_id, n): return os.path.join(HERE, 'img', deck_id, f'{n:02d}.jpg')

def theme_font(prs, fam=None):
    """theme + master defaults -> deck font (so text the buyer adds later uses an allowed font, not Arial/Calibri)"""
    face = FONTS[fam or T['font']]['rg'][0]; head = FONTS[fam or T['font']]['bd'][0]
    import re as _re
    m = prs.slide_master; parts = [m.part] + [p for p in prs.part.package.iter_parts() if p.partname.startswith('/ppt/theme/')]
    for p in parts:
        el = p._element if hasattr(p, '_element') else None
        if el is not None:
            for node in el.iter():
                if node.get('typeface') in ('Arial', 'Calibri', 'Calibri Light') or node.get('script') == 'Thai':
                    node.set('typeface', face)
        else:
            x = p.blob.decode('utf8')
            x = _re.sub(r'(<a:majorFont>.*?<a:latin typeface=")[^"]*', lambda k: k.group(1) + head, x, flags=_re.S)
            x = _re.sub(r'(<a:minorFont>.*?<a:latin typeface=")[^"]*', lambda k: k.group(1) + face, x, flags=_re.S)
            x = x.replace('typeface="Arial"', f'typeface="{face}"').replace('typeface="Calibri"', f'typeface="{face}"')
            x = _re.sub(r'(<a:font script="Thai" typeface=")[^"]*', lambda k: k.group(1) + face, x)   # Thai script default (Angsana/Cordia) -> deck font
            p._blob = x.encode('utf8')

def save(prs, path):
    theme_font(prs); prs.save(path); return len(prs.slides._sldIdLst)

def ring(s, cx, cy, d, pct, c, track=None, th=0.1):
    """progress ring from 12 o'clock clockwise; blockArc angles are 60000ths of a degree (python-pptx scales by 1e5)"""
    if track: shp(s, 'donut', cx - d / 2, cy - d / 2, d, d, track, adj=th)
    if pct <= 0: return
    if pct >= 0.999: return shp(s, 'donut', cx - d / 2, cy - d / 2, d, d, c, adj=th)
    st = 270; en = (270 + 360 * pct) % 360
    return shp(s, 'arc', cx - d / 2, cy - d / 2, d, d, c, adj=[st * 0.6, en * 0.6, th])

def reorder(prs, order):
    """order = 1-based slide numbers in the wanted sequence (every slide exactly once)"""
    lst = prs.slides._sldIdLst; ids = list(lst)
    assert sorted(order) == list(range(1, len(ids) + 1)), (sorted(order), len(ids))
    for el in ids: lst.remove(el)
    for k in order: lst.append(ids[k - 1])

def mixt(s, x, y, w, h, a, b, sz, c=None, c2=None, al='l', an='t', sp=1.05, wa='lt', wb='bd', nl=False, sz2=None):
    """two-weight title: light part + bold part (nl=True puts bold part on its own line, sz2 for its size)"""
    runs = [[(a, {'wt': wa})], [(b, {'wt': wb, 'c': c2 or c or T['ink'], 'sz': sz2 or sz})]] if nl else [[(a + ' ', {'wt': wa}), (b, {'wt': wb, 'c': c2 or c or T['ink']})]]
    return txt(s, x, y, w, h, '', sz, c, 'rg', al, an, sp=sp, runs=runs)

def renum(prs, x, tol=0.05, fmt='{:02d}'):
    """after reorder: rewrite page-number text boxes sitting at left=x inches (only pure digits)"""
    for k, sl in enumerate(prs.slides, 1):
        for sh in sl.shapes:
            if sh.has_text_frame and abs(sh.left / 914400 - x) < tol and sh.text_frame.text.strip().isdigit():
                sh.text_frame.paragraphs[0].runs[0].text = fmt.format(k)
