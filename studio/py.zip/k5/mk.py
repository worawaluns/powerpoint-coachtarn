# python3 mk.py decks/e01_xxx.py ...  -> out/<id>.pptx (+ pdf + contact sheet png)
import sys, os, re, importlib.util, subprocess, collections
K = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, K); os.chdir(K)
import eng, lay, base
import lay_cov2, lay_cov3, lay_cov4   # ลงทะเบียนเลย์เอาต์ปกชุดใหม่เข้า lay.L
import lay_proc                      # ชุดแผนผังกระบวนการ (เลย์เอาต์ pf_*)
import lay_aip                       # ชุด AI pitch deck (เลย์เอาต์ ap_*)
import lay_town                      # ชุด Town Hall (เลย์เอาต์ tw_*)
import lay_strat                     # ชุด Strategic Planning (เลย์เอาต์ st_*)
import lay_tech                      # ชุด Modern Technology (เลย์เอาต์ m_*)
import lay_perf                      # ชุด Corporate Performance (เลย์เอาต์ pr_*)
import lay_evol                      # ชุด Business Evolution (เลย์เอาต์ ev_*)
import lay_startup                   # ชุด Startup Business Pitch (เลย์เอาต์ sb_*)
import lay_gproj                     # ชุด Project Summary เขียว+ส้ม (เลย์เอาต์ gp_*)
import lay_zw                        # ชุด Zero-Waste collage เขียว+เหลือง (เลย์เอาต์ zw_*)
import lay_openpay                   # ชุดแอปการเงิน ส้ม+น้ำตาล (เลย์เอาต์ op_*)
import lay_trade                     # ชุดโปรไฟล์บริษัท ดำ+แดง (เลย์เอาต์ tb_*)
import lay_engblue                   # ชุดโปรไฟล์บริษัทวิศวกรรม น้ำเงิน (เลย์เอาต์ eg_*)
import lay_bizyel                    # ชุด Business Proposal ขาว+เหลือง (เลย์เอาต์ by_*)
import lay_bike                      # ชุดสวนจักรยาน ดำ+เขียวมะนาว (เลย์เอาต์ bk_*)
import lay_brand                     # ชุดคู่มือแบรนด์ แดง+ดำ (เลย์เอาต์ br_*)
import lay_create                    # ชุดเวิร์กช็อปสร้างสรรค์ ดำ+เหลือง (เลย์เอาต์ cr_*)
import lay_gloss                     # ชุดรายงานแคมเปญ ฟ้า+ครีม (เลย์เอาต์ gl_*)
import lay_aboutme                   # ชุดแนะนำตัว ชมพู+เบอร์กันดี (เลย์เอาต์ am_*)
import lay_ugc                       # ชุดแฟ้มผลงานครู ฟ้าพาสเทล (เลย์เอาต์ ug_*)
import lay_scrap                     # ชุดสมุดภาพ น้ำตาล+ครีม (เลย์เอาต์ sc_*)
import lay_csred                     # ชุดครีเอทีฟสตูดิโอ แดงส้ม+ครีม (เลย์เอาต์ cs_*)
import lay_ember                     # ชุด Process Infographic ส้ม (เลย์เอาต์ em_*)
import lay_agency                    # ชุด Creative Agency (เลย์เอาต์ ag_*)
import lay_edtech                    # ชุด Pitch Deck EdTech (เลย์เอาต์ ed_*)
import lay_propo                     # ชุด Business Proposal (เลย์เอาต์ pp_*)
import lay_mkt                       # ชุด Marketing Strategy (เลย์เอาต์ mk_*)
import lay_sust                      # ชุด Sustainability (เลย์เอาต์ su_*)
import lay_tesla                     # ชุดรายงานผลงานแบบ Tesla Impact Report (เลย์เอาต์ ti_*)
import lay_core                      # เด็คตัวอย่าง Slide Studio สร้างด้วย AI (เลย์เอาต์ ks_*)


def _covfill(dd, SEQ, M):
    """เติม kicker กับตัวเลขให้ปก จากเนื้อในเด็คเอง

    71 จาก 133 ชุด ปกไม่มีคีย์ stats เลย เลย์เอาต์ปกใหม่ทุกตัวมีการ์ดตัวเลข
    ถ้าไม่เติม การ์ดจะว่างโบ๋ ห้ามแต่งเลขขึ้นเอง เลยกวาดจากสไลด์ถัดไปในเด็คเดียวกัน
    """
    CAP = 24

    def isval(x):
        """ตัวเลขที่เอาขึ้นปกได้ ต้องมีหน่วยด้วย เลขเปล่าอย่าง 0 หรือ 12 ไม่สื่ออะไร"""
        x = str(x).strip()
        if not x or len(x) > 14 or not any(c.isdigit() for c in x): return False
        if not any(c.isalpha() or c in '%฿' for c in x) or x.startswith('0'): return False
        # ชื่อไอคอน/ไฟล์ เช่น trash-2 bar-chart-3 หลุดมาเป็น "ตัวเลข" บนปกขายงาน
        if re.fullmatch(r'[a-z][a-z0-9-]*', x) or 'หน้า ' in x: return False
        return True

    if not dd.get('k'):
        dd['k'] = M.get('cat', '') or M['th']

    def innum(v):
        """ตัวเลขนี้มีอยู่จริงในสไลด์อื่นของเด็คนี้ไหม"""
        tok = re.findall(r'[\d,\.]+', str(v))
        if not tok: return False
        body = ' '.join(str(d) for _, d in SEQ[1:])
        return all(t.strip('.,') in body for t in tok if len(t.strip('.,')) > 1)

    # stats ที่คนเขียนเด็คใส่ไว้เอง บางตัวไม่มีอยู่ในเนื้อเด็คเลย เช่น "412 คน" ที่โผล่
    # ข้ามเด็คไปหลายชุด พอเอาขึ้นปกกลายเป็นตัวเลขที่ลูกค้าเปิดเข้าไปแล้วไม่เจอ
    if dd.get('stats'):
        keep = [s for s in dd['stats'] if innum(s[0])]
        if len(keep) == len(dd['stats']):
            return dd
        dd['stats'] = keep                      # เหลือเท่าไหร่เก็บไว้ แล้วไปเติมจากเนื้อเด็คต่อ

    got = list(dd.get('stats') or [])
    seen = {str(v).strip() for v, _ in got}

    def put(a, b):
        """คู่ (ค่า, ป้าย) สลับด้านกันตามเลย์เอาต์ เลยดูเองว่าฝั่งไหนคือตัวเลข"""
        a, b = str(a).strip(), str(b).strip()
        v, lb = (a, b) if isval(a) else (b, a)
        if not isval(v) or v in seen: return
        lb = lb.split('·')[0].split('(')[0].strip()
        if not lb or len(lb) > CAP: return   # ไทยไม่มีช่องว่าง ตัดแล้วขาดกลางคำ ทิ้งดีกว่า
        seen.add(v); got.append((v, lb))

    for nm, d in SEQ[1:]:
        # หน้าสารบัญให้เวลาเป็นนาทีต่อหัวข้อ ขึ้นปกแล้วอ่านไม่รู้เรื่อง
        if nm.startswith(('agenda', 'div_', 'close_', 'quote')): continue
        if d.get('big'): put(d['big'], d.get('biglab', ''))
        for r in d.get('rows', []):
            if isinstance(r, dict): put(r.get('val', ''), r.get('lab', ''))
        for it in d.get('items', []):
            if isinstance(it, (list, tuple)) and len(it) >= 2: put(it[0], it[1])
        if len(got) >= 3: break
    if got: dd['stats'] = got[:3]
    return dd


USED = collections.Counter()
RENDER = '--render' in sys.argv
for path in [a for a in sys.argv[1:] if not a.startswith('--')]:
    sp = importlib.util.spec_from_file_location('dk', path); m = importlib.util.module_from_spec(sp); sp.loader.exec_module(m)
    M = m.META
    eng.setpal(M['pal'], M.get('font', 'plex'), M.get('head'))
    prs = base.deck()
    seen = []
    for i, (name, d) in enumerate(m.SEQ, 1):
        dd = dict(topic=M.get('topic', 'office'), foot=M.get('foot', M['th']), n=f'{i:02d}')
        dd.update(d)
        if i == 1:
            _covfill(dd, m.SEQ, M)
            # เลขประจำชุด ใช้สลับรายละเอียดของโครงเดียวกันให้ไม่ซ้ำกับชุดอื่น
            eng.setvar(sum(ord(c) * (k + 3) for k, c in enumerate(M['slug'])))
        else:
            eng.setvar(0)
        lay.L[name](prs, dd)
        if i == 1 and eng.vch(0, 2) and not M.get('nomirror'):   # ครึ่งหนึ่งพลิกซ้าย-ขวา ได้โครงเพิ่มเท่าตัว
            # nomirror: เด็คที่โครงหน้าทุกหน้าตรึงด้านไว้ (โลโก้ซ้าย เลขหน้าขวา) พลิกแล้วปกไม่เข้าชุด
            eng.mirror(prs.slides[-1])
        seen.append(name); USED[name] += 1
    base.theme_font(prs, M.get('font', 'plex'))
    out = f"out/{M['id']}_{M['slug']}"
    os.makedirs('out', exist_ok=True)
    n = base.save(prs, out + '.pptx')
    dup = [k for k, v in collections.Counter(seen).items() if v > 1]
    print(f"{M['id']} {M['slug']}: {n} slides, {len(set(seen))} unique layouts" + (f"  DUP:{dup}" if dup else ''))
    if RENDER:
        subprocess.run([f'{K}/../kit/render.sh', out + '.pptx', out + '.pdf'], check=True)
        subprocess.run([f'{K}/../tools/pdfsheet', out + '.pdf', out + '.png', '5', '520'], check=True, capture_output=True)
print('layout usage:', dict(USED))
