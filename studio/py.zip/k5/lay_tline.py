"""20 เลย์เอาต์ชุดไทม์ไลน์ & Milestone พื้นขาว ไล่สีส้ม-แดง-เหลือง-ชมพูเข้ม — ลอกโครงจากชุด 238 timelineset (ใบงาน 021)

ต้นฉบับ: .pptx ใน Downloads/02 Coach Tarn/By Coach Tarn/อัปขึ้น Drive 06 สีใหม่/238 ... (ไม่มีโค้ดเดิม k6 หาย)
หัวเรื่องกึ่งกลาง ใต้หัวมีขีดสั้นไล่สี บล็อก/หมุด/ริบบิ้นไล่สีสี่เฉด ไม่มีรูปถ่าย
สี: ส้มต้นฉบับ EB5A0E กับตัวขาว = 3.5 ไม่ผ่าน → บล็อกที่มีตัวขาวใช้ส้มเข้ม C2410C (5.2) / แดง DF3231 (4.5) / ชมพูเข้ม CE365A (4.9)
     เหลือง F9A825 ใช้ตัวน้ำตาลเข้ม 2A1410 เสมอ
ทุกข้อความมาจาก d ไม่มีค่าตั้งต้นที่เป็นคำ ไม่มีเลข 01/02 ตกแต่ง (การ์ดลำดับในต้นฉบับใช้จุดสีแทน)
"""
from eng import *
import eng
from lay import L, reg

txt = txt_big
chart = chart_big

eng.PAL.setdefault('tline_sunset', dict(bg='FFFFFF', ink='2A1410', mute='7A5A52', acc='DF3231', acc2='F9A825',
                                        g1='C2410C', g2='CE365A', dark=0, panel='FBF3EF'))

M = 0.70
INK = '2A1410'
MU = '7A5A52'
WH = 'FFFFFF'
PAN = 'FBF3EF'
LINE = 'EADFDA'
OR, RD, YL, RS = 'C2410C', 'DF3231', 'F9A825', 'CE365A'
SEQC = [OR, RD, YL, RS, 'B4531A']                          # สีประจำลำดับ วนซ้ำ
GRAD = {OR: ('F27F34', OR), RD: ('E75655', RD), YL: ('FDC24A', YL), RS: ('D54563', RS), 'B4531A': ('C96A2C', 'B4531A')}


def _c(i): return SEQC[i % len(SEQC)]
def _on(c): return INK if c == YL else WH                 # ตัวหนังสือบนบล็อกสี
def _g(c, ang=90): a, b = GRAD[c]; return (a, b, ang)


def _hd(s, d, y=0.55):
    txt(s, M, y, W - M * 2, 0.70, d['t'], 30, INK, 'md', 'c')
    if d.get('s'): txt(s, 2.0, y + 0.72, W - 4.0, 0.50, d['s'], 13, MU, 'rg', 'c')
    shp(s, 'rect', W / 2 - 0.40, y + 1.30, 0.80, 0.05, grad=(OR, YL, 0))


def _p(s, x, y, w, t, sz=12.5, c=MU, h=1.0, al='l'):
    if t: txt(s, x, y, w, h, t, sz, c, 'rg', al, sp=1.25)


# ══ ปก / สารบัญ / คั่น / ข้อความ / ปิด ═══════════════════════════════════

@reg
def tl_cover(prs, d):
    s = page(prs, WH)
    shp(s, 'rect', 0, 0, 0.22, H, grad=(OR, RS, 90))
    for i, c in enumerate([OR, RD, YL, RS]):              # บันไดไล่สีมุมขวาล่าง (ของตกแต่ง ไม่มีคำ)
        h = 1.2 + i * 0.95
        shp(s, 'round', 8.40 + i * 1.12, H - 0.70 - h, 0.96, h, grad=_g(c), adj=0.10)
    txt(s, 1.00, 1.30, 7.6, 2.9, d['t'], d.get('tsz', 44), INK, 'md', sp=1.08)
    shp(s, 'rect', 1.00, 4.45, 1.40, 0.07, grad=(OR, YL, 0))
    _p(s, 1.00, 4.75, 6.6, d.get('s', ''), 16, MU, h=1.6)


@reg
def tl_agenda(prs, d):
    s = page(prs, WH)
    txt(s, M, 0.90, 4.2, 2.0, d['t'], 36, INK, 'md', sp=1.08)
    shp(s, 'rect', M, 2.55, 1.10, 0.06, grad=(OR, YL, 0))
    it = d['items'][:6]
    rh = min(0.92, 5.8 / max(len(it), 1))
    for i, t in enumerate(it):
        y = 0.85 + i * rh; c = _c(i)
        shp(s, 'pent', 5.20, y, 0.70, rh - 0.18, grad=_g(c, 0))
        txt(s, 6.10, y, W - M - 6.10, rh - 0.18, t, 17, INK, 'md', an='m')
        ln(s, 6.10, y + rh - 0.09, W - M, y + rh - 0.09, LINE, 0.7)


@reg
def tl_div_grad(prs, d):
    s = page(prs, WH)
    shp(s, 'rect', 0, 0, W, H, grad=(OR, RS, 45))
    shp(s, 'oval', 8.6, -1.6, 6.0, 6.0, WH, a=0.10)
    shp(s, 'oval', 10.2, 3.9, 4.2, 4.2, WH, a=0.08)
    txt(s, 1.00, 2.40, 9.0, 2.0, d['t'], 46, WH, 'md', sp=1.08)
    _p(s, 1.00, 4.55, 8.0, d.get('s', ''), 16, WH, h=1.4)


@reg
def tl_statement(prs, d):
    s = page(prs, PAN)
    shp(s, 'rect', M, 1.60, 0.10, 3.60, grad=(OR, RS, 90))
    txt(s, M + 0.45, 1.50, 10.6, 2.80, d['t'], 34, INK, 'md', sp=1.12)
    _p(s, M + 0.45, 4.45, 10.0, d.get('s', ''), 15, MU, h=1.6)


@reg
def tl_close(prs, d):
    s = page(prs, WH)
    shp(s, 'rect', 0, H - 1.10, W, 1.10, grad=(OR, RS, 0))
    txt(s, M, 2.20, W - M * 2, 1.40, d['t'], 44, INK, 'md', 'c')
    _p(s, 2.0, 3.70, W - 4.0, d.get('s', ''), 15, MU, h=1.4, al='c')


# ══ ไทม์ไลน์ (ชื่อมี timeline = doc2slide อ่านเป็นลำดับเวลา) ═══════════════

@reg
def tl_timeline_pins(prs, d):
    s = page(prs, WH)
    _hd(s, d)
    it = d['items'][:5]; n = max(len(it), 1)
    y0 = 4.10; cw = (W - M * 2) / n
    ln(s, M, y0, W - M, y0, LINE, 1.6)
    for i, (per, h_, body) in enumerate(it):
        cx = M + cw * (i + 0.5); c = _c(i); up = i % 2 == 0
        shp(s, 'oval', cx - 0.09, y0 - 0.09, 0.18, 0.18, c)
        py = y0 - 0.82 if up else y0 + 0.22
        shp(s, 'tear', cx - 0.30, py, 0.60, 0.60, grad=_g(c), rot=135 if up else 315)
        ty = 1.98 if up else 5.00
        txt(s, cx - cw / 2 + 0.08, ty, cw - 0.16, 0.32, per, 15, c if c != YL else 'B4531A', 'md', 'c')
        txt(s, cx - cw / 2 + 0.08, ty + 0.34, cw - 0.16, 0.36, h_, 14, INK, 'md', 'c')
        _p(s, cx - cw / 2 + 0.08, ty + 0.70, cw - 0.16, body, 12, h=0.56, al='c')


@reg
def tl_timeline_stairs(prs, d):
    s = page(prs, WH)
    _hd(s, d)
    it = d['items'][:4]; n = max(len(it), 1)
    gap = 0.22; cw = (W - M * 2 - gap * (n - 1)) / n
    for i, (per, h_, body) in enumerate(it):
        x = M + i * (cw + gap); c = _c(i); h = 1.70 + i * 0.85; y = H - 0.55 - h
        shp(s, 'round', x, y, cw, h, grad=_g(c), adj=0.06)
        txt(s, x + 0.25, y + 0.18, cw - 0.5, 0.32, per, 13, _on(c), 'md')
        txt(s, x + 0.25, y + 0.52, cw - 0.5, 0.80, h_, 15, _on(c), 'md', sp=1.1)
        _p(s, x + 0.25, y + 1.30 if h > 2.0 else y + 1.10, cw - 0.5, body, 12, _on(c), h=max(h - 1.40, 0.4))


@reg
def tl_timeline_arrow(prs, d):
    s = page(prs, WH)
    _hd(s, d)
    it = d['items'][:4]; n = max(len(it), 1)
    y0 = 4.05
    shp(s, 'arrow', M, y0 - 0.30, W - M * 2, 0.60, grad=(OR, RD, 0), adj=[0.5, 0.6])
    cw = (W - M * 2 - 0.6) / n
    for i, (per, h_, body) in enumerate(it):
        cx = M + 0.3 + cw * (i + 0.5); up = i % 2 == 0
        shp(s, 'oval', cx - 0.13, y0 - 0.13, 0.26, 0.26, WH)
        ty = 2.30 if up else 4.65
        txt(s, cx - cw / 2, ty, cw, 0.34, per, 15, OR, 'md', 'c')
        txt(s, cx - cw / 2 + 0.1, ty + 0.38, cw - 0.2, 0.40, h_, 13.5, INK, 'md', 'c')
        _p(s, cx - cw / 2 + 0.1, ty + 0.78, cw - 0.2, body, 12, h=0.7, al='c')


@reg
def tl_timeline_bubbles(prs, d):
    s = page(prs, WH)
    _hd(s, d)
    it = d['items'][:4]; n = max(len(it), 1)
    cw = (W - M * 2) / n
    for i, (per, h_, body) in enumerate(it):
        c = _c(i); x = M + i * cw; y = 2.40 if i % 2 == 0 else 3.70
        shp(s, 'callout', x + 0.10, y, cw - 0.45, 1.25, grad=_g(c), adj=[-0.30, 0.80, 0.16])
        txt(s, x + 0.30, y + 0.12, cw - 0.85, 0.34, per, 13, _on(c), 'md')
        txt(s, x + 0.30, y + 0.48, cw - 0.85, 0.66, h_, 14.5, _on(c), 'md', sp=1.1)
        _p(s, x + 0.10, y + 1.70, cw - 0.45, body, 12, h=1.2)


# ══ หัวข้อคู่คำอธิบาย ═════════════════════════════════════════════════════

@reg
def tl_ribbon(prs, d):
    s = page(prs, WH)
    _hd(s, d)
    it = d['items'][:4]; n = max(len(it), 1)
    rw = 5.6; dx = (W - M * 2 - rw) / max(n - 1, 1)
    for i, (h_, body) in enumerate(it):
        c = _c(i); x = M + i * dx; y = H - 1.35 - i * ((H - 3.10) / n)
        shp(s, 'pent', x, y, rw, 0.95, grad=_g(c, 0), adj=0.35)
        txt(s, x + 0.25, y + 0.06, rw - 0.9, 0.38, h_, 14.5, _on(c), 'md')
        txt(s, x + 0.25, y + 0.44, rw - 0.9, 0.48, body, 11.5, _on(c), 'rg', sp=1.1)


@reg
def tl_cards(prs, d):
    s = page(prs, WH)
    _hd(s, d)
    it = d['items'][:4]; n = max(len(it), 1)
    gap = 0.26; cw = (W - M * 2 - gap * (n - 1)) / n
    for i, (h_, body) in enumerate(it):
        x = M + i * (cw + gap); c = _c(i)
        shp(s, 'round', x, 2.40, cw, 4.30, WH, line=LINE, adj=0.05)
        shp(s, 'oval', x + 0.30, 2.15, 0.52, 0.52, grad=_g(c))
        txt(s, x + 0.30, 2.95, cw - 0.6, 0.80, h_, 16, INK, 'md', sp=1.1)
        _p(s, x + 0.30, 3.85, cw - 0.6, body, 12.5, h=2.6)


@reg
def tl_cycle(prs, d):
    s = page(prs, WH)
    _hd(s, d)
    cx, cy, r = W / 2, 4.45, 1.70
    shp(s, 'oval', cx - r, cy - r, r * 2, r * 2, None, line=LINE, lw=2)
    shp(s, 'oval', cx - 0.95, cy - 0.95, 1.90, 1.90, PAN)
    txt(s, cx - 0.85, cy - 0.45, 1.70, 0.90, d.get('k', ''), 14, OR, 'md', 'c', 'm')
    it = d['items'][:4]
    pos = [(cx, cy - r, 'c'), (cx + r, cy, 'l'), (cx, cy + r, 'c'), (cx - r, cy, 'r')]
    for i, (h_, body) in enumerate(it):
        x, y, al = pos[i]; c = _c(i)
        shp(s, 'oval', x - 0.30, y - 0.30, 0.60, 0.60, grad=_g(c))
        if al == 'c':                                      # บน/ล่าง: ข้อความข้างขวาของจุด ไม่ชนหัวรอง
            txt(s, x + 0.45, y - 0.30, 3.6, 0.36, h_, 14.5, INK, 'md')
            _p(s, x + 0.45, y + 0.08, 3.6, body, 12, h=0.6)
        else:
            bx = x + 0.45 if al == 'l' else x - 0.45 - 3.4
            txt(s, bx, y - 0.40, 3.4, 0.36, h_, 14.5, INK, 'md', al)
            _p(s, bx, y - 0.02, 3.4, body, 12, h=0.8, al=al)


@reg
def tl_matrix(prs, d):
    s = page(prs, WH)
    _hd(s, d)
    it = d['items'][:4]
    cw, ch = (W - M * 2 - 0.20) / 2, 2.05
    for i, (h_, body) in enumerate(it):
        c = _c(i); x = M + (i % 2) * (cw + 0.20); y = 2.25 + (i // 2) * (ch + 0.20)
        shp(s, 'round', x, y, cw, ch, PAN, adj=0.06)
        shp(s, 'rect', x, y + 0.25, 0.08, ch - 0.5, c)
        txt(s, x + 0.40, y + 0.25, cw - 0.7, 0.40, h_, 16, INK, 'md')
        _p(s, x + 0.40, y + 0.75, cw - 0.7, body, 12.5, h=1.2)


@reg
def tl_hex(prs, d):
    s = page(prs, WH)
    _hd(s, d)
    it = d['items'][:6]
    pos = [(2.6, 2.55), (5.7, 2.25), (8.8, 2.55), (2.6, 4.75), (5.7, 4.45), (8.8, 4.75)]
    for i, t in enumerate(it):
        x, y = pos[i]; c = _c(i)
        shp(s, 'hex', x, y, 1.90, 1.65, grad=_g(c))
        txt(s, x + 0.15, y + 0.20, 1.60, 1.25, t, 13, _on(c), 'md', 'c', 'm', sp=1.1)


# ══ ตัวเลข / ตาราง / กราฟจริง ═════════════════════════════════════════════

@reg
def tl_numbers(prs, d):
    s = page(prs, WH)
    _hd(s, d)
    it = d['items'][:4]; n = max(len(it), 1)
    gap = 0.24; cw = (W - M * 2 - gap * (n - 1)) / n
    for i, (v, lab) in enumerate(it):
        x = M + i * (cw + gap); c = _c(i)
        shp(s, 'round', x, 2.45, cw, 3.80, grad=_g(c, 45), adj=0.08)
        txt(s, x + 0.30, 3.05, cw - 0.6, 0.90, v, 34, _on(c), 'md')
        _p(s, x + 0.30, 4.10, cw - 0.6, lab, 13, _on(c), h=1.9)


@reg
def tl_stat_rings(prs, d):
    s = page(prs, WH)
    _hd(s, d)
    it = d['items'][:3]; n = max(len(it), 1)
    cw = (W - M * 2) / n
    for i, (v, lab) in enumerate(it):
        cx = M + cw * (i + 0.5); c = _c(i)
        shp(s, 'donut', cx - 1.05, 2.35, 2.10, 2.10, grad=_g(c), adj=0.10)   # วงแหวนเต็ม (ของตกแต่ง ไม่ใช่เกจที่บอกค่า)
        txt(s, cx - 0.95, 3.00, 1.90, 0.80, v, 26, INK, 'md', 'c', 'm')
        _p(s, cx - cw / 2 + 0.2, 4.75, cw - 0.4, lab, 13, h=1.5, al='c')


@reg
def tl_table(prs, d):
    s = page(prs, WH)
    _hd(s, d)
    head, rows = d['head'], d['rows'][:6]
    nc = len(head); tw = W - M * 2
    cols = d.get('colw') or [1] * nc; tot = sum(cols); cols = [c / tot for c in cols]
    al = d.get('al') or ['l'] * nc
    y0, hh = 2.20, 0.54
    rh = min(0.60, 4.4 / max(len(rows), 1))
    shp(s, 'rect', M, y0, tw, hh, grad=(OR, RD, 0))
    cx = M
    for j, (hd, fr) in enumerate(zip(head, cols)):
        txt(s, cx + 0.18, y0, tw * fr - 0.36, hh, hd, 13.5, WH, 'md', al[j] if j < len(al) else 'l', 'm'); cx += tw * fr
    for i, row in enumerate(rows):
        y = y0 + hh + i * rh
        shp(s, 'rect', M, y, tw, rh, PAN if i % 2 else WH)
        cx = M
        for j, (cell, fr) in enumerate(zip(row, cols)):
            txt(s, cx + 0.18, y, tw * fr - 0.36, rh, cell, 13, INK, 'md' if j == 0 else 'rg', al[j] if j < len(al) else 'l', 'm'); cx += tw * fr
    if d.get('note'): _p(s, M, y0 + hh + len(rows) * rh + 0.18, 10, d['note'], 12, h=0.6)


@reg
def tl_chart_area(prs, d):
    s = page(prs, WH)
    _hd(s, d)
    chart(s, 'area', M, 2.15, W - M * 2, 4.75, d['cats'], [(d.get('sname', ''), d['vals'])], [OR],
          labels=False, fmt='#,##0', sz=12, c=MU, grid=True)


@reg
def tl_chart_col(prs, d):
    s = page(prs, WH)
    _hd(s, d)
    n = len(d['vals'])
    chart(s, 'col', M, 2.15, 8.2, 4.75, d['cats'], [(d.get('sname', ''), d['vals'])], [_c(i) for i in range(n)],
          labels=True, fmt='#,##0.##', gap=60, sz=12, c=INK, vary=True)
    if d.get('note'):
        shp(s, 'round', 9.30, 2.40, W - M - 9.30, 3.20, PAN, adj=0.06)
        _p(s, 9.60, 2.70, W - M - 9.90, d['note'], 13, INK, h=2.6)


@reg
def tl_chart_bar(prs, d):
    s = page(prs, WH)
    _hd(s, d)
    n = len(d['vals'])
    chart(s, 'bar', M, 2.15, W - M * 2, 4.75, d['cats'], [(d.get('sname', ''), d['vals'])], [RD] * n,
          labels=True, fmt='#,##0.##', gap=55, sz=12, c=INK)
