"""หน้ากราฟกลาง (ใบ 016 เฟส 1) 9 ชนิด × 2 แบบหน้า = 18 layout ต่อท้าย pool ของทุกชุด สี/ฟอนต์/รูปของชุดที่ลูกค้าเลือก
ไอซ์เลือกแบบจาก mockup (29 ต.ค. 2569 "ชอบ B กับ C ครับ") ต้นแบบ: powerpoint-coachtarn/docs/doc2slide/mockups/016-design/ (src/gen.py)
  B แผงสีครึ่งหน้า (chb_*): แผงสีหลักของชุดเต็มความสูงซ้าย หัวเรื่องตัวหนา ป้ายแคปซูล คำอธิบายของลูกค้าท้ายแผง วงแหวนตกแต่ง
     ขวาเป็นกราฟใหญ่บนพื้นเรียบ / คู่สี: สีเข้มหนึ่งสีบอกเรื่องหลัก ที่เหลือเป็นเทาของชุด
  C เวทีสีเข้มเต็มหน้า + ภาพของชุด (chc_*): พื้นโทนเข้มของชุดเต็มหน้า หัวเรื่องบางตัวใหญ่สีสว่าง แผงภาพจากหมวดรูปของชุดด้านขวา
     คำอธิบายเป็นการ์ดสีสว่างใต้ภาพ / คู่สี: สีสว่างสุดของชุดเด่นชุดเดียว ที่เหลือขาว (สีสว่างของชุด) ไล่ความจาง
     ชุดที่ไม่มีรูปในหมวดของชุด: แบบ C วาดไม่ได้ (โยน error) ตัวจัดไม่เลือก ใช้แบบ B แทน
กฎเดิมครบ: กราฟ PowerPoint จริงมีชีตฝัง ตัวเลขทุกตัวเป็นป้าย/แกนของกราฟ (ไม่มีตัวเลขในกล่องข้อความ) คำอธิบายสีเป็นของกราฟ
  คำทั้งหมดจากเอกสาร สีจาก P ของชุด (+ mix / eng.ink_on ดันให้อ่านออก) ห้ามสีหรือฟอนต์ตายตัวในไฟล์นี้
  เส้น/ตัวหนังสือ ≥ 3:1 กับพื้นที่อยู่ / แท่ง ชิ้น พื้นที่ ≥ 1.15 / แท่งซ้อน 100% = คอลัมน์สูตรในชีต / เรดาร์อ่านค่าจากแกนรัศมี
  ไฮไลต์ (แท่ง/ชิ้นค่าสูงสุด) ตั้งตอนสร้างไฟล์ แก้ชีตทีหลังสีไม่ย้ายตาม (แจ้งไอซ์แล้ว)
doc2slide อ่านซอร์สของ layout (kind_of: chart(s, / stacked(): chart(s, 'colS' / REQ: d['..']) ทุก layout จึงเรียก chart(s, ... ในตัวเอง
เพดาน (วัดจากภาพเรนเดอร์): CAP = จำนวนหมวดสูงสุดต่อชนิด เกิน = วาดไม่ได้ ตัวจัดไม่เลือก (ไม่ตัดข้อมูลเงียบ)
  ชุดข้อมูลสูงสุด 3 ตาม doc2slide.shapes / วงกลม-โดนัทสูงสุด 6 ชิ้น (ตัวอย่าง items 6 ข้อ = เพดานใน fill) / แบบแท่ง: ป้ายต้องไม่กว้างกว่าแท่ง (_fits)"""
import io, os, copy, math, types, colorsys
from eng import *
import eng
from lay import reg
from lxml import etree
from pptx.oxml.ns import qn
from pptx.enum.chart import XL_LEGEND_POSITION as LG, XL_LABEL_POSITION as LP, XL_MARKER_STYLE

CAP = {'area': 8, 'col': 8, 'col_note': 6, 'colS': 6, 'colP': 6, 'donut': 6, 'pie': 6, 'line': 8, 'radar': 8}
FMT = '#,##0.##'                                           # numfmt() ทับด้วยรูปแบบเซลล์ต้นทางตอนวาดจริง
C15 = 'http://schemas.microsoft.com/office/drawing/2012/chart'
PX = 1 / 120                                               # mockup 1600×900 px -> สไลด์ 13.333×7.5 นิ้ว


# ── สี ──────────────────────────────────────────────────────────────────────
def _best(c, *opts):
    """ตัวเลือกที่ต่างจาก c มากสุด (ตัวหนังสือบนพื้น c)"""
    return max(opts, key=lambda o: cratio(o, c))


def _style(st):
    """คู่สีของแบบหน้า B / C จาก P ของชุด (ตาม gen.py dirB / dirC)"""
    lt, dk = max(P['bg'], P['ink'], key=eng._lm), min(P['bg'], P['ink'], key=eng._lm)
    if st == 'B':
        surf = P['bg']; hi = P['acc'] if cratio(P['acc'], surf) >= 3 else _best(surf, P['ink'], P['g1'])
        return dict(st='B', surf=surf, hi=hi, grey=[mix(P['mute'], surf, t) for t in (0.35, 0.6, 0.8, 0.5, 0.7)], bar=mix(P['mute'], surf, 0.62),
                    panel=P['acc'], on=_best(P['acc'], P['ink'], P['bg']),
                    lines=[hi, ink_on(mix(P['mute'], P['ink'], 0.3), surf, 3), ink_on(P['mute'], surf, 3)],
                    text=P['ink'], soft=ink_on(P['mute'], surf, 4.5), axis=P['ink'], grid=mix(P['mute'], surf, 0.82), lt=lt, dk=dk)
    stage = next((c for c in (P['acc'], P['g1'], P['acc2'], P['g2'], dk) if cratio(lt, c) >= 4.5 and eng._lm(c) < 0.25), dk)
    cand = [c for c in (P['acc'], P['acc2'], P['g1'], P['g2']) if c != stage and cratio(c, stage) >= 3]
    hi = max(cand, key=eng._lm) if cand else lt
    rest = [lt] if hi != lt else []
    return dict(st='C', surf=stage, hi=hi, grey=rest + [mix(stage, lt, t) for t in (0.6, 0.3, 0.45, 0.75)], bar=mix(stage, lt, 0.3),
                lines=[hi] + [ink_on(c, stage, 3) for c in rest + [mix(stage, lt, 0.62), mix(stage, lt, 0.45)]][:2],
                text=lt, soft=ink_on(mix(stage, lt, 0.62), stage, 4.5), axis=mix(stage, lt, 0.4), grid=mix(stage, lt, 0.3), lt=lt, dk=dk)


def _tw(t, sz, wt):
    """ความกว้างข้อความ (นิ้ว) วัดจากฟอนต์จริง ไม่มีฟอนต์ (บนเว็บ) ใช้ค่าประมาณ 0.5em"""
    try:
        from PIL import ImageFont
        return ImageFont.truetype(eng._facefile(None, wt), int(sz / 72 * 200)).getlength(t) / 200
    except Exception:
        return len(t) * sz * 0.5 / 72


def _tsz(t, w, base, lo, wt):
    """หัวเรื่องบรรทัดเดียวถ้าย่อได้ไม่ต่ำกว่า lo (ตัวตัดคำไม่หักกลางวลี เช่น "แต่ละ/กลุ่ม") ไม่งั้นใช้ base ให้ตัดบรรทัดตามคำ (eng.fit_w ตัวเดิม)"""
    z = fit_w(t, w, base, lo=lo, wt=wt)
    return z if _tw(t, z, wt) <= w else base


# ── โครงหน้า B / C ───────────────────────────────────────────────────────────
def _frame(prs, d, st, sub, need_note=False):
    """พื้น หัวเรื่อง หัวรอง คำอธิบาย (และภาพของแบบ C) คืน (สไลด์, สี, กรอบกราฟ x y w h)"""
    if need_note and not d.get('note'): raise ValueError('แบบนี้ต้องมีคำอธิบายจากเอกสาร')
    S = _style(st); note = d.get('note'); nz = 20 if need_note else 18
    if st == 'B':
        s = page(prs)
        shp(s, 'rect', 0, 0, 600 * PX, H, S['panel'])
        shp(s, 'donut', (40 - 228) * PX, (900 - 228) * PX, 456 * PX, 456 * PX, mix(S['panel'], S['on'], 0.14), adj=56 / 456)   # วงแหวนมุมล่าง
        shp(s, 'round', 80 * PX, 96 * PX, 64 * PX, 8 * PX, P['acc2'] if cratio(P['acc2'], S['panel']) >= 3 else S['on'], adj=0.5)
        z = _tsz(d['t'], 470 * PX, 36, 28, 'bd'); nl = min(3, max(1, math.ceil(_tw(d['t'], z, 'bd') / (470 * PX * 0.92))))
        txt(s, 80 * PX, 140 * PX, 470 * PX, 1.95, d['t'], z, S['on'], 'bd', sp=1.12)
        py = 140 * PX + nl * z * 1.12 * 1.3 / 72 + 0.3          # ป้ายแคปซูลต่อใต้หัวเรื่อง (ประมาณจำนวนบรรทัดจากความกว้างจริง)
        if sub:
            pf = P['acc2'] if cratio(P['acc2'], S['panel']) >= 3 else S['on']; w_ = min(470 * PX, _tw(sub, 13, 'md') + 0.5)
            shp(s, 'round', 80 * PX, py, w_, 0.4, pf, adj=0.5)
            txt(s, 80 * PX, py, w_, 0.4, sub, 13, _best(pf, P['ink'], P['bg'], P['acc']), 'md', 'c', 'm')
        if note:
            ln(s, 80 * PX, 560 * PX, 520 * PX, 560 * PX, mix(S['panel'], S['on'], 0.45), 1.2)
            txt(s, 80 * PX, 584 * PX, 440 * PX, 2.1, note, nz, S['on'], 'rg', sp=1.45)
        return s, S, (5.75, 1.0, 6.85, 5.75)
    tp = os.path.join(eng.IMG, d.get('topic') or '')
    if not (d.get('topic') and os.path.isdir(tp) and os.listdir(tp)): raise ValueError('ชุดนี้ไม่มีรูปในหมวดของชุด แบบ C ใช้ไม่ได้')   # ตัวจัดใช้แบบ B แทน
    s = page(prs, S['surf'])
    txt(s, 96 * PX, 0.35, 8.0, 1.25, d['t'], _tsz(d['t'], 8.0, 48, 34, 'lt'), S['lt'], 'lt', an='b', sp=1.05)
    if sub: txt(s, 98 * PX, 1.68, 8.0, 0.4, sub, 17, S['hi'], 'md')
    sat = colorsys.rgb_to_hsv(*[int(S['surf'][i:i + 2], 16) / 255 for i in (0, 2, 4)])[1]
    mode = f"duo:{mix(S['surf'], S['dk'], 0.55)}:{mix(S['surf'], S['lt'], 0.55)}" if sat > 0.3 else 'bw'   # พื้นมีสี: ย้อมโทนชุด / พื้นเทาดำ: ขาวดำ
    pic(s, eng.ph(d['topic'], d.get('pi', 3)), 1124 * PX, 96 * PX, 380 * PX, (400 if note else 708) * PX, geom='roundRect', adj=28 / 380, mode=mode)
    if note:
        shp(s, 'round', 1124 * PX, 520 * PX, 380 * PX, 284 * PX, S['hi'], adj=28 / 284)
        txt(s, 1160 * PX, 556 * PX, 308 * PX, 214 * PX, note, nz, _best(S['hi'], P['ink'], P['bg']), 'rg', sp=1.45)
    return s, S, (0.8, 2.35, 8.0, 4.45)


# ── ตัวช่วยกราฟ ──────────────────────────────────────────────────────────────
def _cap(kind, d, lo=2):
    n = len(d['cats']) if 'cats' in d else len(d['items'])
    if not lo <= n <= CAP[kind]: raise ValueError(f'{kind} รับ {lo}-{CAP[kind]} หมวด ได้ {n}')


def _fits(d, ser, w, sz, stacked=False):
    """ป้ายตัวเลขของแท่งที่แคบที่สุดต้องไม่กว้างเกินแท่ง (วัดจากภาพ: ตัวเลข ~0.55 ของขนาดตัว)"""
    n = len(d['cats']); k = 1 if stacked else len(ser)
    slot = (w - 0.9) / n / (k + 0.5)
    mx = max(len(f'{abs(v):,.2f}'.rstrip('0').rstrip('.')) + 1 for _, vs in ser for v in vs)
    if mx * sz * 0.55 / 72 > slot * 1.15: raise ValueError(f'ป้าย {mx} ตัวกว้างกว่าแท่ง {slot:.2f} นิ้ว')
    if not stacked and len(ser) == 1 and mx * 26 * 0.55 / 72 > (w - 0.9) / n * 1.1:   # ป้ายเด่น 26pt ของแท่งสูงสุดต้องไม่เกินช่องหมวด
        raise ValueError(f'ป้ายเด่น {mx} ตัวกว้างกว่าช่องหมวด')


def _grid(ax, c):
    ax.has_major_gridlines = True; ax.major_gridlines.format.line.color.rgb = rgb(c)


def _manual(ch, x, y, w, h):
    pa = ch._chartSpace.find('.//' + qn('c:plotArea')); lay_ = pa.find(qn('c:layout'))
    if lay_ is None:
        lay_ = etree.Element(qn('c:layout')); pa.insert(0, lay_)
    for e in list(lay_): lay_.remove(e)
    m = etree.SubElement(lay_, qn('c:manualLayout')); etree.SubElement(m, qn('c:layoutTarget')).set('val', 'inner')
    for k, v in (('xMode', 'edge'), ('yMode', 'edge'), ('x', x), ('y', y), ('w', w), ('h', h)):
        etree.SubElement(m, qn('c:' + k)).set('val', str(v))


def _legend(ch, S, pos, sz=13):
    ch.has_legend = True; lg = ch.legend; lg.position = pos; lg.include_in_layout = False
    lg.font.size = Pt(sz); lg.font.color.rgb = rgb(S['text'])


def _axes(ch, S):
    """แกนหมวด: เส้นฐานสีแบบหน้า ชื่อหมวด / ซ่อนแกนตัวเลข"""
    ca = ch.category_axis; ca.format.line.color.rgb = rgb(S['axis']); ca.format.line.width = Pt(1.2)
    ca.tick_labels.font.size = Pt(14); ca.tick_labels.font.color.rgb = rgb(S['text'] if S['st'] == 'B' else S['soft'])
    ch.value_axis.visible = False


def _lab(sr, c, sz, bold=False, pos=None):
    """ป้ายระดับชุด ไม่มี numFmt = รูปแบบเซลล์ในชีต (numfmt ของ doc2slide เขียนรูปแบบลงชีตแล้วข้ามชุดนี้ ไม่ทับสี/ตำแหน่ง)"""
    dl = sr.data_labels; dl.show_value = True; dl.font.size = Pt(sz); dl.font.bold = bold; dl.font.color.rgb = rgb(c)
    if pos is not None: dl.position = pos


def _plab(sr, j, c, sz, bold=False, pos=None):
    pd = sr.points[j].data_label; pd.font.size = Pt(sz); pd.font.bold = bold; pd.font.color.rgb = rgb(c)
    if pos is not None: pd.position = pos


def _pfill(sr, j, c):
    pt = sr.points[j]; pt.format.fill.solid(); pt.format.fill.fore_color.rgb = rgb(c); pt.format.line.fill.background()
    for e in sr._element.findall(qn('c:dPt')):            # ค่าติดลบไม่กลับสี (เหมือน base.chart vary)
        if e.find(qn('c:invertIfNegative')) is None:
            iv = etree.Element(qn('c:invertIfNegative')); iv.set('val', '0'); e.find(qn('c:idx')).addnext(iv)


def _hilite(ch, S, d):
    """ชุดเดียว: แท่งสูงสุดสีเด่น ป้ายใหญ่ตัวหนา ที่เหลือแท่งเทา ป้ายสีรอง / หลายชุด: ชุดแรกสีเด่น ป้ายตามสีชุด"""
    pl = ch.plots[0]; hc = ink_on(S['hi'], S['surf'], 3)
    if len(d['series']) == 1:
        sr = pl.series[0]; v = d['series'][0][1]; m = v.index(max(v))
        _lab(sr, S['soft'], 16, pos=LP.OUTSIDE_END); _pfill(sr, m, S['hi']); _plab(sr, m, hc, 26, True, LP.OUTSIDE_END)
    else:
        for i, sr in enumerate(pl.series): _lab(sr, hc if i == 0 else S['soft'], 15 if i == 0 else 13, i == 0, LP.OUTSIDE_END)


def _bar_cols(S, k):
    return [S['bar']] if k == 1 else [S['hi']] + S['grey'][:k - 1]


def _ring(ch, S, cols, kind):
    """โดนัท/วงกลม: ป้ายบนชิ้นสีที่อ่านออก ชิ้นเด่นตัวหนา / B คำอธิบายสีล่าง C คำอธิบายสีขวา (ของกราฟเอง)"""
    for i, c in enumerate(cols):
        pt = ch.plots[0].series[0].points[i]
        if kind == 'pie': pt.format.line.color.rgb = rgb(S['surf']); pt.format.line.width = Pt(2)
        dl = pt.data_label; dl.font.size = Pt(16 if c == S['hi'] else 14); dl.font.bold = c == S['hi']; dl.font.color.rgb = rgb(_best(c, P['ink'], P['bg']))
    if S['st'] == 'B': _legend(ch, S, LG.BOTTOM, 14); _manual(ch, 0.2, 0.02, 0.6, 0.82)
    else: _legend(ch, S, LG.RIGHT, 16); _manual(ch, 0.02, 0.02, 0.5, 0.96)


def _slices(S, d):
    """ชิ้นใหญ่สุดสีเด่น ที่เหลือเทา/ขาวไล่ตามขนาด"""
    cats = [a for a, *_ in d['items']]; vals = [v for _, v, *_ in d['items']]
    order = sorted(range(len(vals)), key=lambda j: -vals[j]); cols = [None] * len(vals)
    for r, j in enumerate(order): cols[j] = S['hi'] if r == 0 else S['grey'][(r - 1) % len(S['grey'])]
    return cats, vals, cols


def _xf(v, f):
    """ข้อความตัวเลขตามรูปแบบเซลล์ต้นทาง (#,##0 / 0.0"%") ที่ doc2slide.xlfmt สร้าง"""
    dec = len(f.split('.')[1].split('"')[0].rstrip('#')) if '.' in f else 0
    s = f'{v:,.{dec}f}' if ',' in f else f'{v:.{dec}f}'
    return s + ('%' if '%' in f else '')


def _two(kind):
    """ลงทะเบียนฟังก์ชันเดียวเป็นสองแบบหน้า chb_<kind> (st='B') / chc_<kind> (st='C')
    โค้ดชุดเดียวกัน ซอร์สที่ doc2slide อ่าน (kind_of / stacked / REQ) จึงตรงกับที่วาดจริงทั้งสองชื่อ"""
    def deco(fn):
        for st in 'BC':
            g = types.FunctionType(fn.__code__, fn.__globals__, f'ch{st.lower()}_{kind}', (st,), fn.__closure__)
            g.__module__ = fn.__module__; reg(g)
        return fn
    return deco


# ── 9 ชนิด ───────────────────────────────────────────────────────────────────
@_two('area')
def _area(prs, d, st='B'):
    _cap('area', d); s, S, (x, y, w, h) = _frame(prs, d, st, d.get('s'))
    # พื้นที่ไล่จากสีเด่นเข้าหาพื้นจนป้ายสีตัวหนังสือ ≥ 4.5:1 ทั้งบนพื้นที่และพื้นหน้า (ป้ายหมวดแรก/สุดท้ายคร่อมขอบ)
    fillc = next(m for t in (0.55, 0.65, 0.75, 0.85, 1) for m in [mix(S['hi'], S['surf'], t)] if cratio(S['text'], m) >= 4.5)
    ch = chart(s, 'area', x, y, w, h, d['cats'], [(d.get('sname', ''), d['vals'])], [fillc], labels=False, fmt=FMT, sz=14)
    sr = ch.plots[0].series[0]; sr.format.line.color.rgb = rgb(ink_on(S['hi'], S['surf'], 3)); sr.format.line.width = Pt(3)
    _axes(ch, S); _lab(sr, S['text'], 14); _plab(sr, d['vals'].index(max(d['vals'])), S['text'], 22, True)
    cb = ch._chartSpace.find('.//' + qn('c:valAx') + '/' + qn('c:crossBetween'))
    if cb is not None: cb.set('val', 'between')            # จุดแรก/สุดท้ายกลางช่องหมวด ไม่ชิดขอบ


@_two('col')
def _col(prs, d, st='B'):
    _cap('col', d); s, S, (x, y, w, h) = _frame(prs, d, st, d.get('s')); _fits(d, d['series'], w, 16 if len(d['series']) == 1 else 14)
    k = len(d['series'])
    ch = chart(s, 'col', x, y, w, h, d['cats'], d['series'], _bar_cols(S, k), labels=False, fmt=FMT, sz=14, gap=47, overlap=-6)
    _axes(ch, S); _hilite(ch, S, d)
    if k > 1: _legend(ch, S, LG.TOP)


@_two('col_note')
def _col_note(prs, d, st='B'):  # แท่งพร้อมคำอธิบายจากเอกสารตัวใหญ่ (ต้องมีคำอธิบาย) แท่งแคบลง เว้นที่ให้ป้ายเด่น
    _cap('col_note', d); s, S, (x, y, w, h) = _frame(prs, d, st, d.get('s'), need_note=True); _fits(d, d['series'], w, 16 if len(d['series']) == 1 else 14)
    k = len(d['series'])
    ch = chart(s, 'col', x, y, w, h, d['cats'], d['series'], _bar_cols(S, k), labels=False, fmt=FMT, sz=14, gap=90, overlap=-6)
    _axes(ch, S); _hilite(ch, S, d)
    if k > 1: _legend(ch, S, LG.TOP)


@_two('colS')
def _colS(prs, d, st='B'):  # แท่งซ้อน: stacked() ใน doc2slide อ่าน chart(s, 'colS' จากซอร์สนี้ = ต้องมี _stack
    _cap('colS', d); s, S, (x, y, w, h) = _frame(prs, d, st, d.get('s')); _fits(d, d['series'], w, 14, True)
    cols = [S['hi']] + S['grey'][:len(d['series']) - 1]
    ch = chart(s, 'colS', x, y, w, h, d['cats'], d['series'], cols, labels=False, legend=True, fmt=FMT, sz=14, gap=60)
    _axes(ch, S); _legend(ch, S, LG.TOP)
    for i, sr in enumerate(ch.plots[0].series): _lab(sr, _best(cols[i], P['ink'], P['bg']), 14, i == 0, LP.CENTER)


# แท่งซ้อน 100%: ชีตเก็บค่าจริง + คอลัมน์สูตร =ค่า/ผลรวมแถว กราฟวาดคอลัมน์สูตร ป้าย/แกนเป็น %
# ป้ายแสดงค่าจริงจากเซลล์ด้วย (Value From Cells ของ Office 2013+): PowerPoint "180 ขึ้นบรรทัด 47%" / LibreOffice ขึ้นแค่ %
@_two('colP')
def _colP(prs, d, st='B'):
    _cap('colP', d); s, S, (x, y, w, h) = _frame(prs, d, st, d.get('s'))
    ser, cats = d['series'], d['cats']; k, n = len(ser), len(cats)
    nf = d.pop('_nf', None) or [[FMT] * n] * k            # ponytail: จัดรูปแบบเอง (pop จาก dd ของ render) ไม่ให้ numfmt เขียนชีตทับคอลัมน์สูตร
    names = d.get('_sn') or [nm for nm, _ in ser]
    tot = [sum(v[j] for _, v in ser) or 1 for j in range(n)]
    share = [(names[i], [v[j] / tot[j] for j in range(n)]) for i, (_, v) in enumerate(ser)]
    cols = [S['hi']] + S['grey'][:k - 1]
    ch = chart(s, 'colP', x, y, w, h, cats, share, cols, legend=True, fmt='0%', sz=14, gap=60)
    _axes(ch, S); _legend(ch, S, LG.TOP)
    import xlsxwriter
    b = io.BytesIO(); wb = xlsxwriter.Workbook(b, {'in_memory': True}); ws = wb.add_worksheet('Sheet1')
    L = lambda c: chr(65 + c); pct = wb.add_format({'num_format': '0%'})
    for j, c in enumerate(cats): ws.write(j + 1, 0, c)
    for i in range(k):
        fi = nf[min(i, len(nf) - 1)]; f = wb.add_format({'num_format': max(set(fi), key=fi.count)})
        ws.write(0, 1 + i, names[i]); ws.write(0, 1 + k + i, f'{names[i]} %')
        for j in range(n):
            r = j + 2; rng = f'$B{r}:${L(k)}{r}'
            ws.write(j + 1, 1 + i, ser[i][1][j], f)
            ws.write_formula(j + 1, 1 + k + i, f'=IF(SUM({rng})=0,0,{L(1 + i)}{r}/SUM({rng}))', pct, share[i][1][j])
    ws.set_column(0, 2 * k, 14); wb.close()
    ch.part.chart_workbook.update_from_xlsx_blob(b.getvalue())
    pdl = ch.plots[0]._element.find(qn('c:dLbls'))
    for i, sr in enumerate(ch.plots[0].series):
        e = sr._element; fi = nf[min(i, len(nf) - 1)]; col = L(1 + k + i); raw = L(1 + i)
        e.find(f"{qn('c:val')}/{qn('c:numRef')}/{qn('c:f')}").text = f'Sheet1!${col}$2:${col}${n + 1}'
        dl = copy.deepcopy(pdl); e.find(qn('c:cat')).addprevious(dl)
        dl.find(f".//{qn('a:defRPr')}/{qn('a:solidFill')}/{qn('a:srgbClr')}").set('val', _best(cols[i], P['ink'], P['bg']))
        sep = etree.Element(qn('c:separator')); sep.text = '\n'; dl.find(qn('c:showBubbleSize')).addnext(sep)
        x_ = etree.SubElement(etree.SubElement(dl, qn('c:extLst')), qn('c:ext'), uri='{CE6537A1-D6FC-4f65-9D91-7224C49458BB}', nsmap={'c15': C15})
        etree.SubElement(x_, f'{{{C15}}}showDataLabelsRange').set('val', '1')
        x_ = etree.SubElement(etree.SubElement(e, qn('c:extLst')), qn('c:ext'), uri='{02D57815-91ED-43cb-92C2-25804820EDAC}', nsmap={'c15': C15})
        rg = etree.SubElement(x_, f'{{{C15}}}datalabelsRange'); etree.SubElement(rg, f'{{{C15}}}f').text = f'Sheet1!${raw}$2:${raw}${n + 1}'
        cache = etree.SubElement(rg, f'{{{C15}}}dlblRangeCache'); etree.SubElement(cache, qn('c:ptCount')).set('val', str(n))
        for j in range(n):
            pt = etree.SubElement(cache, qn('c:pt'), idx=str(j)); etree.SubElement(pt, qn('c:v')).text = _xf(ser[i][1][j], fi[j])


# โดนัท / วงกลม: kind_of (doc2slide) รับเป็นหน้ากราฟสัดส่วนเมื่อเห็น chart(s, 'donut' กับ f'{v}%' ในซอร์ส layout
# -> fill ใช้ได้เฉพาะ _share (รวม 100%) ไม่เกิน 6 ชิ้น / ponytail: วงกลมเขียนสัญญาเดียวกันไว้ในคอมเมนต์ในตัวฟังก์ชัน
@_two('donut')
def _donut(prs, d, st='B'):  # สัญญา kind_of: f'{v}%' = สัดส่วน
    _cap('donut', d); s, S, (x, y, w, h) = _frame(prs, d, st, d.get('s')); cats, vals, cols = _slices(S, d)
    ch = chart(s, 'donut', x, y, w, h, cats, [((d.get('_sn') or [''])[0], vals)], cols, fmt=FMT, sz=14, hole=62 if st == 'B' else 50)
    _ring(ch, S, cols, 'donut')


@_two('pie')
def _pie(prs, d, st='B'):  # สัญญาเดียวกับโดนัท: chart(s, 'donut' / f'{v}%'
    _cap('pie', d); s, S, (x, y, w, h) = _frame(prs, d, st, d.get('s')); cats, vals, cols = _slices(S, d)
    ch = chart(s, 'pie', x, y, w, h, cats, [((d.get('_sn') or [''])[0], vals)], cols, fmt=FMT, sz=14)
    _ring(ch, S, cols, 'pie')


# เส้น: ชุดแรก = เรื่องหลัก เส้นหนา มีจุด ป้ายทุกจุด (ใต้จุดเมื่อต่ำกว่าเส้นอื่น) / ชุดอื่นเส้นบาง ไม่มีจุด ป้ายเฉพาะจุดสุดท้ายด้านขวา
@_two('line')
def _line(prs, d, st='B'):
    _cap('line', d); s, S, (x, y, w, h) = _frame(prs, d, st, d.get('s'))
    ser = d['series']; n = len(d['cats']); cols = (S['lines'] * 3)[:len(ser)]
    ch = chart(s, 'line', x, y, w, h, d['cats'], ser, cols, labels=False, legend=len(ser) > 1, fmt=FMT, sz=14, lw=2.4)
    _axes(ch, S)
    if len(ser) > 1: _legend(ch, S, LG.TOP)
    if st == 'B':
        va = ch.value_axis; va.visible = True; _grid(va, S['grid']); va.tick_labels.font.size = Pt(12); va.tick_labels.font.color.rgb = rgb(S['soft'])
        va.tick_labels.number_format = FMT; va.tick_labels.number_format_is_linked = False; va.format.line.fill.background()
    for i, sr in enumerate(ch.plots[0].series):
        if i == 0:
            sr.format.line.width = Pt(5.4); sr.marker.size = 11
            sr.marker.format.fill.fore_color.rgb = rgb(cols[0] if st == 'B' else S['surf']); sr.marker.format.line.color.rgb = rgb(cols[0])
            _lab(sr, cols[0], 18, True, LP.ABOVE)
            for j in range(n):
                vs = [v[j] for _, v in ser]
                if len(ser) > 1: below = vs[0] < max(vs[1:])     # ใต้เส้นอื่น: ป้ายใต้จุด ไม่ทับเส้นที่อยู่เหนือ
                else:
                    nb = [ser[0][1][q] for q in (j - 1, j + 1) if 0 <= q < n]
                    below = bool(nb) and vs[0] < sum(nb) / len(nb)
                _plab(sr, j, cols[0], 18, True, LP.BELOW if below else LP.ABOVE)
        else:
            sr.marker.style = XL_MARKER_STYLE.NONE; sr.data_labels.show_value = False
            _plab(sr, n - 1, cols[i], 13, False, LP.RIGHT)


# เรดาร์ (3 หมวดขึ้นไป): ไม่มีป้ายรายจุด (เรดาร์ตั้งตำแหน่งป้ายไม่ได้ ทับเส้น) อ่านค่าจากแกนรัศมี + วงตาราง ราว 10 วง
@_two('radar')
def _radar(prs, d, st='B'):
    _cap('radar', d, lo=3); s, S, (x, y, w, h) = _frame(prs, d, st, d.get('s'))
    ser = d['series']; cols = (S['lines'] * 3)[:len(ser)]
    ch = chart(s, 'radarL', x, y, w, h, d['cats'], ser, cols, labels=False, legend=False, fmt=FMT, sz=14, lw=2.4)
    ch.plots[0].series[0].format.line.width = Pt(4.5)
    va = ch.value_axis; _grid(va, S['grid']); va.visible = True; va.format.line.fill.background()
    va.tick_labels.font.size = Pt(12); va.tick_labels.font.color.rgb = rgb(S['soft'])
    va.tick_labels.number_format = FMT; va.tick_labels.number_format_is_linked = False
    top = max(v for _, vs in ser for v in vs) or 1; e_ = 10 ** math.floor(math.log10(top / 10))
    va.major_unit = next(m * e_ for m in (1, 2, 2.5, 5, 10) if m * e_ >= top / 10); va.minimum_scale = 0
    ca = ch.category_axis; _grid(ca, S['grid']); ca.tick_labels.font.size = Pt(14); ca.tick_labels.font.color.rgb = rgb(S['text'])
    if len(ser) > 1: _legend(ch, S, LG.BOTTOM, 14)
    wf = h * 0.8 / w; _manual(ch, round(0.5 - wf / 2, 3), 0.05, round(wf, 3), 0.8)


# ตัวอย่างโครงของแต่ละแบบ (pool_of อ่านแบบเดียวกับ SEQ ของชุด) ตัวเลขในนี้ไม่ขึ้นสไลด์: fill ใส่ข้อมูลลูกค้าทับทุกช่อง
# ponytail: เก็บในไฟล์นี้แทน decks/_charts.py เพราะ d2s_web.py รวม lay_*.py ลง py.zip เอง แต่ decks/ รวมเฉพาะชุดในคลัง
_c4 = ['ก', 'ข', 'ค', 'ง']; _s2 = [('', [1, 2, 3, 4]), ('', [2, 3, 4, 5])]
_EX = {'donut': dict(items=[('', 1)] * 6), 'colS': dict(cats=_c4, series=_s2), 'col': dict(cats=_c4, series=_s2), 'line': dict(cats=_c4, series=_s2),
       'col_note': dict(cats=_c4, series=_s2[:1]), 'area': dict(cats=_c4, vals=[1, 2, 3, 4], sname=''), 'pie': dict(items=[('', 1)] * 6),
       'colP': dict(cats=_c4, series=_s2), 'radar': dict(cats=_c4 + ['จ'], series=[('', [1, 2, 3, 4, 5]), ('', [2, 3, 4, 5, 1])])}
# ลำดับ = ลำดับเลือกเมื่อคะแนนเท่ากัน: แบบเฉพาะทาง (สัดส่วน แท่งซ้อน) ก่อน / ต่อชนิด B ก่อน C (C ใช้ไม่ได้ในชุดไม่มีรูป)
SEQ = [(f'ch{st}_{k}', dict(t='', s='', note='', **_EX[k])) for k in _EX for st in 'bc']
