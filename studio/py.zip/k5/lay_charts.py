"""หน้ากราฟกลาง (ใบ 016 เฟส 1) 9 ชนิด × 2 แบบหน้า = 18 layout ต่อท้าย pool ของทุกชุด สี/ฟอนต์/รูปของชุดที่ลูกค้าเลือก
ไอซ์เลือกแบบจาก mockup (29 ต.ค. 2569 "ชอบ B กับ C ครับ") ต้นแบบ: powerpoint-coachtarn/docs/doc2slide/mockups/016-design/ (src/gen.py)
  B แผงสีครึ่งหน้า (chb_*): แผงสีหลักของชุดเต็มความสูงซ้าย หัวเรื่องตัวหนา ป้ายแคปซูล คำอธิบายของลูกค้าท้ายแผง วงแหวนตกแต่ง
     ขวาเป็นกราฟใหญ่บนพื้นเรียบ / คู่สี: สีเข้มหนึ่งสีบอกเรื่องหลัก ที่เหลือเป็นเทาของชุด
  C เวทีสีเข้มเต็มหน้า + ภาพของชุด (chc_*): พื้นโทนเข้มของชุดเต็มหน้า หัวเรื่องบางตัวใหญ่สีสว่าง แผงภาพจากหมวดรูปของชุดด้านขวา
     คำอธิบายเป็นการ์ดสีสว่างใต้ภาพ / คู่สี: สีสว่างสุดของชุดเด่นชุดเดียว ที่เหลือขาว (สีสว่างของชุด) ไล่ความจาง
     ชุดที่ไม่มีรูปในหมวดของชุด: แบบ C วาดไม่ได้ (โยน error) ตัวจัดไม่เลือก ใช้แบบ B แทน
กฎเดิมครบ: กราฟ PowerPoint จริงมีชีตฝัง ตัวเลขทุกตัวเป็นป้าย/แกนของกราฟ (ไม่มีตัวเลขในกล่องข้อความ) คำอธิบายสีเป็นของกราฟ
  คำทั้งหมดจากเอกสาร สีจาก P ของชุด (+ mix / eng.ink_on ดันให้อ่านออก) ห้ามสีหรือฟอนต์ตายตัวในไฟล์นี้
  เส้น/ตัวหนังสือ ≥ 3:1 กับพื้นที่อยู่ / แท่ง ชิ้น พื้นที่ ≥ 1.15 / แท่งซ้อน 100% = คอลัมน์สูตรในชีต / เรดาร์อ่านค่าจากแกนรัศมี
  ไฮไลต์ (แท่ง/ชิ้นค่าสูงสุด) ตั้งตอนสร้างไฟล์ แก้ชีตทีหลังสีไม่ย้ายตาม (แจ้งไอซ์แล้ว)
doc2slide อ่านซอร์สของ layout (kind_of: chart(s, / stacked(): chart(s, 'colS' / REQ: d['..']) ทุก layout จึงเรียก chart(s, ... ในตัวเอง
เพดาน (วัดจากภาพเรนเดอร์): CAP = จำนวนหมวดสูงสุดต่อชนิด เกิน = วาดไม่ได้ ตัวจัดไม่เลือก (ไม่ตัดข้อมูลเงียบ)
  ชุดข้อมูลสูงสุด 3 ตาม doc2slide.shapes / วงกลม-โดนัทสูงสุด 6 ชิ้น (ตัวอย่าง items 6 ข้อ = เพดานใน fill) / แบบแท่ง: ป้ายต้องไม่กว้างกว่าแท่ง (_fits)"""
import io, os, copy, math, types, colorsys, functools
from eng import *
import eng
from lay import reg
from lxml import etree
from pptx.oxml.ns import qn
from pptx.enum.chart import XL_LEGEND_POSITION as LG, XL_LABEL_POSITION as LP, XL_MARKER_STYLE

CAP = {'area': 8, 'col': 8, 'col_note': 6, 'colS': 6, 'colP': 6, 'donut': 6, 'pie': 6, 'line': 8, 'radar': 8}
FMT = '#,##0.##'                                           # numfmt() ทับด้วยรูปแบบเซลล์ต้นทางตอนวาดจริง
C15 = 'http://schemas.microsoft.com/office/drawing/2012/chart'
PX = 1 / 120                                               # mockup 1600×900 px -> สไลด์ 13.333×7.5 นิ้ว


# ตัวอักษรตั้งต้นของกราฟ (txPr ระดับกราฟ) = สีอ่อนของแบบหน้า ≥ 4.5 บนพื้น (QA 30g: เดิมเป็นสีเทาของชุด บนพื้นเข้มแบบ C อ่านไม่ออก และเว็บใช้สีนี้ทาตัวอักษรในกราฟ)
_CS = []
_chart0 = chart
def chart(s, kind, *a, **k):
    if _CS and k.get('c') is None: k['c'] = _CS[0]['soft']
    return _chart0(s, kind, *a, **k)


# ── สี ──────────────────────────────────────────────────────────────────────
def _best(c, *opts):
    """ตัวเลือกที่ต่างจาก c มากสุด (ตัวหนังสือบนพื้น c)"""
    return max(opts, key=lambda o: cratio(o, c))


def _style(st):
    """คู่สีของแบบหน้า B / C จาก P ของชุด (ตาม gen.py dirB / dirC)"""
    lt, dk = max(P['bg'], P['ink'], key=eng._lm), min(P['bg'], P['ink'], key=eng._lm)
    if st == 'B':
        surf = P['bg']; hi = P['acc'] if cratio(P['acc'], surf) >= 3 else _best(surf, P['ink'], P['g1'])
        return dict(st='B', surf=surf, hi=hi, grey=[mix(P['mute'], surf, t) for t in (0.35, 0.6, 0.8, 0.5, 0.7)], bar=mix(P['mute'], surf, 0.62),
                    panel=P['acc'], on=_best(P['acc'], P['ink'], P['bg']),
                    lines=[hi, ink_on(mix(P['mute'], P['ink'], 0.3), surf, 3), ink_on(P['mute'], surf, 3)],
                    text=P['ink'], soft=ink_on(P['mute'], surf, 4.5), axis=P['ink'], grid=mix(P['mute'], surf, 0.82), lt=lt, dk=dk)
    stage = next((c for c in (P['acc'], P['g1'], P['acc2'], P['g2'], dk) if cratio(lt, c) >= 4.5 and eng._lm(c) < 0.25), dk)
    cand = [c for c in (P['acc'], P['acc2'], P['g1'], P['g2']) if c != stage and cratio(c, stage) >= 4.5]   # QA 30g: สีเด่น (ป้ายสีเดียวกัน) ≥ 4.5 บนพื้น
    hi = max(cand, key=eng._lm) if cand else lt
    rest = [lt] if hi != lt and cratio(lt, hi) >= 1.6 else []   # ขาวกับสีเด่นที่เกือบขาว (E8EEFF/FFFFFF) ห้ามเป็นสองชุดคู่กัน
    mx = [mix(stage, lt, t) for t in (0.55, 0.62, 0.7, 0.78, 0.86, 0.48)] + [mix(stage, dk, t) for t in (0.7, 0.82, 0.95)]   # พื้นแดง/ส้มกลาง ๆ: ชุดสองเป็นโทนเข้มแทน (ขาวกับชมพูอ่อนแยกไม่ออก)
    two = next((c for c in mx if cratio(c, stage) >= 3 and cratio(c, hi) >= 1.6), None) or max((c for c in mx if cratio(c, stage) >= 3), key=lambda c: cratio(c, hi), default=lt)   # เส้น/แท่งชุดสอง ≥ 3:1 บนพื้น ห่างจากสีเด่นที่สุดเท่าที่ได้
    return dict(st='C', surf=stage, hi=hi, grey=rest + [two] + [mix(stage, lt, t) for t in (0.3, 0.45, 0.75)], bar=mix(stage, lt, 0.3),
                lines=[hi] + [c if cratio(c, stage) >= 3 else ink_on(c, stage, 3) for c in (rest + [two, mix(stage, lt, 0.45)])[:2]],
                text=lt, soft=ink_on(mix(stage, lt, 0.62), stage, 4.5), axis=mix(stage, lt, 0.4), grid=mix(stage, lt, 0.3), lt=lt, dk=dk)


def _tw(t, sz, wt):
    """ความกว้างข้อความ (นิ้ว) วัดจากฟอนต์จริง ไม่มีฟอนต์ (บนเว็บ) ใช้ค่าประมาณ 0.5em"""
    try:
        from PIL import ImageFont
        return ImageFont.truetype(eng._facefile(None, wt), int(sz / 72 * 200)).getlength(t) / 200
    except Exception:
        return len(t) * sz * 0.5 / 72


def _tsz(t, w, base, lo, wt):
    """หัวเรื่องบรรทัดเดียวถ้าย่อได้ไม่ต่ำกว่า lo (ตัวตัดคำไม่หักกลางวลี เช่น "แต่ละ/กลุ่ม") ไม่งั้นใช้ base ให้ตัดบรรทัดตามคำ (eng.fit_w ตัวเดิม)"""
    z = fit_w(t, w, base, lo=lo, wt=wt)
    return z if _tw(t, z, wt) <= w else base


# ── โครงหน้า B / C ───────────────────────────────────────────────────────────
def _frame(prs, d, st, sub, need_note=False):
    """พื้น หัวเรื่อง หัวรอง คำอธิบาย (และภาพของแบบ C) คืน (สไลด์, สี, กรอบกราฟ x y w h)"""
    if need_note and not d.get('note'): raise ValueError('แบบนี้ต้องมีคำอธิบายจากเอกสาร')
    S = _style(st); _CS[:] = [S]; note = d.get('note'); nz = 20 if need_note else 18
    if st == 'B':
        s = page(prs)
        shp(s, 'rect', 0, 0, 600 * PX, H, S['panel'])
        shp(s, 'donut', (40 - 228) * PX, (900 - 228) * PX, 456 * PX, 456 * PX, mix(S['panel'], S['on'], 0.14), adj=56 / 456)   # วงแหวนมุมล่าง
        shp(s, 'round', 80 * PX, 96 * PX, 64 * PX, 8 * PX, P['acc2'] if cratio(P['acc2'], S['panel']) >= 3 else S['on'], adj=0.5)
        z = _tsz(d['t'], 470 * PX, 36, 28, 'bd'); nl = min(3, max(1, math.ceil(_tw(d['t'], z, 'bd') / (470 * PX * 0.92))))
        txt(s, 80 * PX, 140 * PX, 470 * PX, 1.95, d['t'], z, S['on'], 'bd', sp=1.12)
        py = 140 * PX + nl * z * 1.12 * 1.3 / 72 + 0.3          # ป้ายแคปซูลต่อใต้หัวเรื่อง (ประมาณจำนวนบรรทัดจากความกว้างจริง)
        if sub:
            pf = P['acc2'] if cratio(P['acc2'], S['panel']) >= 3 else S['on']; w_ = min(470 * PX, _tw(sub, 13, 'md') + 0.5)
            shp(s, 'round', 80 * PX, py, w_, 0.4, pf, adj=0.5)
            txt(s, 80 * PX, py, w_, 0.4, sub, 13, _best(pf, P['ink'], P['bg'], P['acc']), 'md', 'c', 'm')
        if note:
            ln(s, 80 * PX, 560 * PX, 520 * PX, 560 * PX, mix(S['panel'], S['on'], 0.45), 1.2)
            txt(s, 80 * PX, 584 * PX, 440 * PX, 2.1, note, nz, S['on'], 'rg', sp=1.45)
        return s, S, (5.75, 1.0, 6.85, 5.75)
    tp = os.path.join(eng.IMG, d.get('topic') or '')
    if not (d.get('topic') and os.path.isdir(tp) and os.listdir(tp)): raise ValueError('ชุดนี้ไม่มีรูปในหมวดของชุด แบบ C ใช้ไม่ได้')   # ตัวจัดใช้แบบ B แทน
    s = page(prs, S['surf'])
    txt(s, 96 * PX, 0.35, 8.0, 1.25, d['t'], _tsz(d['t'], 8.0, 48, 34, 'lt'), S['lt'], 'lt', an='b', sp=1.05)
    if sub: txt(s, 98 * PX, 1.68, 8.0, 0.4, sub, 17, S['hi'], 'md')
    sat = colorsys.rgb_to_hsv(*[int(S['surf'][i:i + 2], 16) / 255 for i in (0, 2, 4)])[1]
    mode = f"duo:{mix(S['surf'], S['dk'], 0.55)}:{mix(S['surf'], S['lt'], 0.55)}" if sat > 0.3 else 'bw'   # พื้นมีสี: ย้อมโทนชุด / พื้นเทาดำ: ขาวดำ
    pic(s, eng.ph(d['topic'], d.get('pi', 3)), 1124 * PX, 96 * PX, 380 * PX, (400 if note else 708) * PX, geom='roundRect', adj=28 / 380, mode=mode)
    if note:
        shp(s, 'round', 1124 * PX, 520 * PX, 380 * PX, 284 * PX, S['hi'], adj=28 / 284)
        txt(s, 1160 * PX, 556 * PX, 308 * PX, 214 * PX, note, nz, _best(S['hi'], P['ink'], P['bg']), 'rg', sp=1.45)
    return s, S, (0.8, 2.35, 8.0, 4.45)


# ── ตัวช่วยกราฟ ──────────────────────────────────────────────────────────────
def _cap(kind, d, lo=2):
    n = len(d['cats']) if 'cats' in d else len(d['items'])
    if not lo <= n <= CAP[kind]: raise ValueError(f'{kind} รับ {lo}-{CAP[kind]} หมวด ได้ {n}')


def _fits(d, ser, w, sz, stacked=False):
    """ป้ายตัวเลขของแท่งที่แคบที่สุดต้องไม่กว้างเกินแท่ง (วัดจากภาพ: ตัวเลข ~0.55 ของขนาดตัว)"""
    n = len(d['cats']); k = 1 if stacked else len(ser)
    slot = (w - 0.9) / n / (k + 0.5)
    mx = max(len(f'{abs(v):,.2f}'.rstrip('0').rstrip('.')) + 1 for _, vs in ser for v in vs)
    if mx * sz * 0.55 / 72 > slot * 1.15: raise ValueError(f'ป้าย {mx} ตัวกว้างกว่าแท่ง {slot:.2f} นิ้ว')
    if not stacked and len(ser) == 1 and mx * 26 * 0.55 / 72 > (w - 0.9) / n * 1.1:   # ป้ายเด่น 26pt ของแท่งสูงสุดต้องไม่เกินช่องหมวด
        raise ValueError(f'ป้ายเด่น {mx} ตัวกว้างกว่าช่องหมวด')


def _grid(ax, c):
    ax.has_major_gridlines = True; ax.major_gridlines.format.line.color.rgb = rgb(c)


def _manual(ch, x, y, w, h):
    pa = ch._chartSpace.find('.//' + qn('c:plotArea')); lay_ = pa.find(qn('c:layout'))
    if lay_ is None:
        lay_ = etree.Element(qn('c:layout')); pa.insert(0, lay_)
    for e in list(lay_): lay_.remove(e)
    m = etree.SubElement(lay_, qn('c:manualLayout')); etree.SubElement(m, qn('c:layoutTarget')).set('val', 'inner')
    for k, v in (('xMode', 'edge'), ('yMode', 'edge'), ('x', x), ('y', y), ('w', w), ('h', h)):
        etree.SubElement(m, qn('c:' + k)).set('val', str(v))


def _legend(ch, S, pos, sz=13):
    ch.has_legend = True; lg = ch.legend; lg.position = pos; lg.include_in_layout = False
    lg.font.size = Pt(sz); lg.font.color.rgb = rgb(S['text'])


def _axes(ch, S):
    """แกนหมวด: เส้นฐานสีแบบหน้า ชื่อหมวด / ซ่อนแกนตัวเลข"""
    ca = ch.category_axis; ca.format.line.color.rgb = rgb(S['axis']); ca.format.line.width = Pt(1.2)
    ca.tick_labels.font.size = Pt(14); ca.tick_labels.font.color.rgb = rgb(S['text'] if S['st'] == 'B' else S['soft'])
    ch.value_axis.visible = False


def _lab(sr, c, sz, bold=False, pos=None):
    """ป้ายระดับชุด ไม่มี numFmt = รูปแบบเซลล์ในชีต (numfmt ของ doc2slide เขียนรูปแบบลงชีตแล้วข้ามชุดนี้ ไม่ทับสี/ตำแหน่ง)"""
    dl = sr.data_labels if hasattr(sr, 'data_labels') else DataLabels(sr._element.get_or_add_dLbls())   # ชุดของกราฟกระจาย/ฟองไม่มี .data_labels
    dl.show_value = True; dl.font.size = Pt(sz); dl.font.bold = bold; dl.font.color.rgb = rgb(c)
    if pos is not None: dl.position = pos


def _plab(sr, j, c, sz, bold=False, pos=None):
    pd = sr.points[j].data_label; pd.font.size = Pt(sz); pd.font.bold = bold; pd.font.color.rgb = rgb(c)
    if pos is not None: pd.position = pos


def _pfill(sr, j, c):
    pt = sr.points[j]; pt.format.fill.solid(); pt.format.fill.fore_color.rgb = rgb(c); pt.format.line.fill.background(); _noinv(sr)


def _noinv(sr):
    for e in sr._element.findall(qn('c:dPt')):            # ค่าติดลบไม่กลับสี (เหมือน base.chart vary)
        if e.find(qn('c:invertIfNegative')) is None:
            iv = etree.Element(qn('c:invertIfNegative')); iv.set('val', '0'); e.find(qn('c:idx')).addnext(iv)


def _hilite(ch, S, d):
    """ชุดเดียว: แท่งสูงสุดสีเด่น ป้ายใหญ่ตัวหนา ที่เหลือแท่งเทา ป้ายสีรอง / หลายชุด: ชุดแรกสีเด่น ป้ายตามสีชุด"""
    pl = ch.plots[0]; hc = ink_on(S['hi'], S['surf'], 3)
    if len(d['series']) == 1:
        sr = pl.series[0]; v = d['series'][0][1]; m = v.index(max(v))
        _lab(sr, S['soft'], 16, pos=LP.OUTSIDE_END); _pfill(sr, m, S['hi']); _plab(sr, m, hc, 26, True, LP.OUTSIDE_END)
    else:
        for i, sr in enumerate(pl.series): _lab(sr, hc if i == 0 else S['soft'], 15 if i == 0 else 13, i == 0, LP.OUTSIDE_END)


def _bar_cols(S, k):
    return [S['bar']] if k == 1 else [S['hi']] + S['grey'][:k - 1]


def _ring(ch, S, cols, kind):
    """โดนัท/วงกลม: ป้ายบนชิ้นสีที่อ่านออก ชิ้นเด่นตัวหนา / B คำอธิบายสีล่าง C คำอธิบายสีขวา (ของกราฟเอง)"""
    for i, c in enumerate(cols):
        pt = ch.plots[0].series[0].points[i]
        if kind == 'pie': pt.format.line.color.rgb = rgb(S['surf']); pt.format.line.width = Pt(2)
        dl = pt.data_label; dl.font.size = Pt(16 if c == S['hi'] else 14); dl.font.bold = c == S['hi']; dl.font.color.rgb = rgb(_best(c, P['ink'], P['bg']))
    if S['st'] == 'B': _legend(ch, S, LG.BOTTOM, 14); _manual(ch, 0.2, 0.02, 0.6, 0.82)
    else: _legend(ch, S, LG.RIGHT, 16); _manual(ch, 0.02, 0.02, 0.5, 0.96)


def _slices(S, d):
    """ชิ้นใหญ่สุดสีเด่น ที่เหลือเทา/ขาวไล่ตามขนาด"""
    cats = [a for a, *_ in d['items']]; vals = [v for _, v, *_ in d['items']]
    order = sorted(range(len(vals)), key=lambda j: -vals[j]); cols = [None] * len(vals)
    for r, j in enumerate(order): cols[j] = S['hi'] if r == 0 else S['grey'][(r - 1) % len(S['grey'])]
    return cats, vals, cols


def _xf(v, f):
    """ข้อความตัวเลขตามรูปแบบเซลล์ต้นทาง (#,##0 / 0.0"%") ที่ doc2slide.xlfmt สร้าง"""
    dec = len(f.split('.')[1].split('"')[0].rstrip('#')) if '.' in f else 0
    s = f'{v:,.{dec}f}'                                   # ไอซ์ 1 พ.ย.: ตัวคั่นหลักพันเสมอ
    return s + ('%' if '%' in f else '')


def _two(kind):
    """ลงทะเบียนฟังก์ชันเดียวเป็นสองแบบหน้า chb_<kind> (st='B') / chc_<kind> (st='C')
    โค้ดชุดเดียวกัน ซอร์สที่ doc2slide อ่าน (kind_of / stacked / REQ) จึงตรงกับที่วาดจริงทั้งสองชื่อ"""
    def deco(fn):
        for st in 'BC':
            g = types.FunctionType(fn.__code__, fn.__globals__, f'ch{st.lower()}_{kind}', (st,), fn.__closure__)
            g.__module__ = fn.__module__
            # ใบ 023: หน้าที่ลูกค้าเลือกชนิด/แบบ/สี (d['chart']) หรือตั้งคู่สีทั้งไฟล์ (_pal จาก BR['chartc']) วาดด้วยแบบในแกลเลอรี
            # __wrapped__ = g: inspect.getsource ยังอ่านซอร์สของ fn (kind_of / stacked / REQ ของ doc2slide ไม่เปลี่ยน)
            def w(prs, d, _g=g, _st=st):
                return _styled(prs, d, _st, kind) if (d.get('chart') or d.get('_pal')) else _g(prs, d)
            functools.update_wrapper(w, g); reg(w)
        return fn
    return deco


# ── 9 ชนิด ───────────────────────────────────────────────────────────────────
@_two('area')
def _area(prs, d, st='B'):
    _cap('area', d); s, S, (x, y, w, h) = _frame(prs, d, st, d.get('s'))
    # พื้นที่ไล่จากสีเด่นเข้าหาพื้นจนป้ายสีตัวหนังสือ ≥ 4.5:1 ทั้งบนพื้นที่และพื้นหน้า (ป้ายหมวดแรก/สุดท้ายคร่อมขอบ)
    fillc = next(m for t in (0.55, 0.65, 0.75, 0.85, 1) for m in [mix(S['hi'], S['surf'], t)] if cratio(S['text'], m) >= 4.5)
    ch = chart(s, 'area', x, y, w, h, d['cats'], [(d.get('sname', ''), d['vals'])], [fillc], labels=False, fmt=FMT, sz=14)
    sr = ch.plots[0].series[0]; sr.format.line.color.rgb = rgb(ink_on(S['hi'], S['surf'], 3)); sr.format.line.width = Pt(3)
    _axes(ch, S); _lab(sr, S['text'], 14); _plab(sr, d['vals'].index(max(d['vals'])), S['text'], 22, True)
    cb = ch._chartSpace.find('.//' + qn('c:valAx') + '/' + qn('c:crossBetween'))
    if cb is not None: cb.set('val', 'between')            # จุดแรก/สุดท้ายกลางช่องหมวด ไม่ชิดขอบ


@_two('col')
def _col(prs, d, st='B'):
    _cap('col', d); s, S, (x, y, w, h) = _frame(prs, d, st, d.get('s')); _fits(d, d['series'], w, 16 if len(d['series']) == 1 else 14)
    k = len(d['series'])
    ch = chart(s, 'col', x, y, w, h, d['cats'], d['series'], _bar_cols(S, k), labels=False, fmt=FMT, sz=14, gap=47, overlap=-6)
    _axes(ch, S); _hilite(ch, S, d)
    if k > 1: _legend(ch, S, LG.TOP)


@_two('col_note')
def _col_note(prs, d, st='B'):  # แท่งพร้อมคำอธิบายจากเอกสารตัวใหญ่ (ต้องมีคำอธิบาย) แท่งแคบลง เว้นที่ให้ป้ายเด่น
    _cap('col_note', d); s, S, (x, y, w, h) = _frame(prs, d, st, d.get('s'), need_note=True); _fits(d, d['series'], w, 16 if len(d['series']) == 1 else 14)
    k = len(d['series'])
    ch = chart(s, 'col', x, y, w, h, d['cats'], d['series'], _bar_cols(S, k), labels=False, fmt=FMT, sz=14, gap=90, overlap=-6)
    _axes(ch, S); _hilite(ch, S, d)
    if k > 1: _legend(ch, S, LG.TOP)


@_two('colS')
def _colS(prs, d, st='B'):  # แท่งซ้อน: stacked() ใน doc2slide อ่าน chart(s, 'colS' จากซอร์สนี้ = ต้องมี _stack
    _cap('colS', d); s, S, (x, y, w, h) = _frame(prs, d, st, d.get('s')); _fits(d, d['series'], w, 14, True)
    cols = [S['hi']] + S['grey'][:len(d['series']) - 1]
    ch = chart(s, 'colS', x, y, w, h, d['cats'], d['series'], cols, labels=False, legend=True, fmt=FMT, sz=14, gap=60)
    _axes(ch, S); _legend(ch, S, LG.TOP)
    for i, sr in enumerate(ch.plots[0].series): _lab(sr, _best(cols[i], P['ink'], P['bg']), 14, i == 0, LP.CENTER)


# แท่งซ้อน 100%: ชีตเก็บค่าจริง + คอลัมน์สูตร =ค่า/ผลรวมแถว กราฟวาดคอลัมน์สูตร ป้าย/แกนเป็น %
# ป้ายแสดงค่าจริงจากเซลล์ด้วย (Value From Cells ของ Office 2013+): PowerPoint "180 ขึ้นบรรทัด 47%" / LibreOffice ขึ้นแค่ %
@_two('colP')
def _colP(prs, d, st='B'):
    _cap('colP', d); s, S, (x, y, w, h) = _frame(prs, d, st, d.get('s'))
    ser, cats = d['series'], d['cats']; k, n = len(ser), len(cats)
    nf = d.pop('_nf', None) or [[FMT] * n] * k            # ponytail: จัดรูปแบบเอง (pop จาก dd ของ render) ไม่ให้ numfmt เขียนชีตทับคอลัมน์สูตร
    names = d.get('_sn') or [nm for nm, _ in ser]
    tot = [sum(v[j] for _, v in ser) or 1 for j in range(n)]
    share = [(names[i], [v[j] / tot[j] for j in range(n)]) for i, (_, v) in enumerate(ser)]
    cols = [S['hi']] + S['grey'][:k - 1]
    ch = chart(s, 'colP', x, y, w, h, cats, share, cols, legend=True, fmt='0%', sz=14, gap=60)
    _axes(ch, S); _legend(ch, S, LG.TOP)
    import xlsxwriter
    b = io.BytesIO(); wb = xlsxwriter.Workbook(b, {'in_memory': True}); ws = wb.add_worksheet('Sheet1')
    L = lambda c: chr(65 + c); pct = wb.add_format({'num_format': '0%'})
    for j, c in enumerate(cats): ws.write(j + 1, 0, c)
    for i in range(k):
        fi = nf[min(i, len(nf) - 1)]; f = wb.add_format({'num_format': max(set(fi), key=fi.count)})
        ws.write(0, 1 + i, names[i]); ws.write(0, 1 + k + i, f'{names[i]} %')
        for j in range(n):
            r = j + 2; rng = f'$B{r}:${L(k)}{r}'
            ws.write(j + 1, 1 + i, ser[i][1][j], f)
            ws.write_formula(j + 1, 1 + k + i, f'=IF(SUM({rng})=0,0,{L(1 + i)}{r}/SUM({rng}))', pct, share[i][1][j])
    ws.set_column(0, 2 * k, 14); wb.close()
    ch.part.chart_workbook.update_from_xlsx_blob(b.getvalue())
    pdl = ch.plots[0]._element.find(qn('c:dLbls'))
    for i, sr in enumerate(ch.plots[0].series):
        e = sr._element; fi = nf[min(i, len(nf) - 1)]; col = L(1 + k + i); raw = L(1 + i)
        e.find(f"{qn('c:val')}/{qn('c:numRef')}/{qn('c:f')}").text = f'Sheet1!${col}$2:${col}${n + 1}'
        dl = copy.deepcopy(pdl); e.find(qn('c:cat')).addprevious(dl)
        dl.find(f".//{qn('a:defRPr')}/{qn('a:solidFill')}/{qn('a:srgbClr')}").set('val', _best(cols[i], P['ink'], P['bg']))
        sep = etree.Element(qn('c:separator')); sep.text = '\n'; dl.find(qn('c:showBubbleSize')).addnext(sep)
        x_ = etree.SubElement(etree.SubElement(dl, qn('c:extLst')), qn('c:ext'), uri='{CE6537A1-D6FC-4f65-9D91-7224C49458BB}', nsmap={'c15': C15})
        etree.SubElement(x_, f'{{{C15}}}showDataLabelsRange').set('val', '1')
        x_ = etree.SubElement(etree.SubElement(e, qn('c:extLst')), qn('c:ext'), uri='{02D57815-91ED-43cb-92C2-25804820EDAC}', nsmap={'c15': C15})
        rg = etree.SubElement(x_, f'{{{C15}}}datalabelsRange'); etree.SubElement(rg, f'{{{C15}}}f').text = f'Sheet1!${raw}$2:${raw}${n + 1}'
        cache = etree.SubElement(rg, f'{{{C15}}}dlblRangeCache'); etree.SubElement(cache, qn('c:ptCount')).set('val', str(n))
        for j in range(n):
            pt = etree.SubElement(cache, qn('c:pt'), idx=str(j)); etree.SubElement(pt, qn('c:v')).text = _xf(ser[i][1][j], fi[j])


# โดนัท / วงกลม: kind_of (doc2slide) รับเป็นหน้ากราฟสัดส่วนเมื่อเห็น chart(s, 'donut' กับ f'{v}%' ในซอร์ส layout
# -> fill ใช้ได้เฉพาะ _share (รวม 100%) ไม่เกิน 6 ชิ้น / ponytail: วงกลมเขียนสัญญาเดียวกันไว้ในคอมเมนต์ในตัวฟังก์ชัน
@_two('donut')
def _donut(prs, d, st='B'):  # สัญญา kind_of: f'{v}%' = สัดส่วน
    _cap('donut', d); s, S, (x, y, w, h) = _frame(prs, d, st, d.get('s')); cats, vals, cols = _slices(S, d)
    ch = chart(s, 'donut', x, y, w, h, cats, [((d.get('_sn') or [''])[0], vals)], cols, fmt=FMT, sz=14, hole=62 if st == 'B' else 50)
    _ring(ch, S, cols, 'donut')


@_two('pie')
def _pie(prs, d, st='B'):  # สัญญาเดียวกับโดนัท: chart(s, 'donut' / f'{v}%'
    _cap('pie', d); s, S, (x, y, w, h) = _frame(prs, d, st, d.get('s')); cats, vals, cols = _slices(S, d)
    ch = chart(s, 'pie', x, y, w, h, cats, [((d.get('_sn') or [''])[0], vals)], cols, fmt=FMT, sz=14)
    _ring(ch, S, cols, 'pie')


# เส้น: ชุดแรก = เรื่องหลัก เส้นหนา มีจุด ป้ายทุกจุด (ใต้จุดเมื่อต่ำกว่าเส้นอื่น) / ชุดอื่นเส้นบาง ไม่มีจุด ป้ายเฉพาะจุดสุดท้ายด้านขวา
@_two('line')
def _line(prs, d, st='B'):
    _cap('line', d); s, S, (x, y, w, h) = _frame(prs, d, st, d.get('s'))
    ser = d['series']; n = len(d['cats']); cols = (S['lines'] * 3)[:len(ser)]
    ch = chart(s, 'line', x, y, w, h, d['cats'], ser, cols, labels=False, legend=len(ser) > 1, fmt=FMT, sz=14, lw=2.4)
    _axes(ch, S)
    if len(ser) > 1: _legend(ch, S, LG.TOP)
    if st == 'B':
        va = ch.value_axis; va.visible = True; _grid(va, S['grid']); va.tick_labels.font.size = Pt(12); va.tick_labels.font.color.rgb = rgb(S['soft'])
        va.tick_labels.number_format = FMT; va.tick_labels.number_format_is_linked = False; va.format.line.fill.background()
    for i, sr in enumerate(ch.plots[0].series):
        if i == 0:
            sr.format.line.width = Pt(5.4); sr.marker.size = 11
            sr.marker.format.fill.fore_color.rgb = rgb(cols[0] if st == 'B' else S['surf']); sr.marker.format.line.color.rgb = rgb(cols[0])
            _lab(sr, cols[0], 18, True, LP.ABOVE)
            for j in range(n):
                vs = [v[j] for _, v in ser]
                if len(ser) > 1: below = vs[0] < max(vs[1:])     # ใต้เส้นอื่น: ป้ายใต้จุด ไม่ทับเส้นที่อยู่เหนือ
                else:
                    nb = [ser[0][1][q] for q in (j - 1, j + 1) if 0 <= q < n]
                    below = bool(nb) and vs[0] < sum(nb) / len(nb)
                _plab(sr, j, cols[0], 18, True, LP.BELOW if below else LP.ABOVE)
        else:
            sr.marker.style = XL_MARKER_STYLE.NONE; sr.data_labels.show_value = False
            _plab(sr, n - 1, cols[i] if cratio(cols[i], S['surf']) >= 4.5 else S['text'], 13, False, LP.RIGHT)


# เรดาร์ (3 หมวดขึ้นไป): ไม่มีป้ายรายจุด (เรดาร์ตั้งตำแหน่งป้ายไม่ได้ ทับเส้น) อ่านค่าจากแกนรัศมี + วงตาราง ราว 10 วง
@_two('radar')
def _radar(prs, d, st='B'):
    _cap('radar', d, lo=3); s, S, (x, y, w, h) = _frame(prs, d, st, d.get('s'))
    ser = d['series']; cols = (S['lines'] * 3)[:len(ser)]
    ch = chart(s, 'radarL', x, y, w, h, d['cats'], ser, cols, labels=False, legend=False, fmt=FMT, sz=14, lw=2.4)
    ch.plots[0].series[0].format.line.width = Pt(4.5)
    va = ch.value_axis; _grid(va, S['grid']); va.visible = True; va.format.line.fill.background()
    va.tick_labels.font.size = Pt(12); va.tick_labels.font.color.rgb = rgb(S['soft'])
    va.tick_labels.number_format = FMT; va.tick_labels.number_format_is_linked = False
    top = max(v for _, vs in ser for v in vs) or 1; e_ = 10 ** math.floor(math.log10(top / 10))
    va.major_unit = next(m * e_ for m in (1, 2, 2.5, 5, 10) if m * e_ >= top / 10); va.minimum_scale = 0
    ca = ch.category_axis; _grid(ca, S['grid']); ca.tick_labels.font.size = Pt(14); ca.tick_labels.font.color.rgb = rgb(S['text'])
    if len(ser) > 1: _legend(ch, S, LG.BOTTOM, 14)
    wf = h * 0.8 / w; _manual(ch, round(0.5 - wf / 2, 3), 0.05, round(wf, 3), 0.8)


# ตัวอย่างโครงของแต่ละแบบ (pool_of อ่านแบบเดียวกับ SEQ ของชุด) ตัวเลขในนี้ไม่ขึ้นสไลด์: fill ใส่ข้อมูลลูกค้าทับทุกช่อง
# ponytail: เก็บในไฟล์นี้แทน decks/_charts.py เพราะ d2s_web.py รวม lay_*.py ลง py.zip เอง แต่ decks/ รวมเฉพาะชุดในคลัง
_c4 = ['ก', 'ข', 'ค', 'ง']; _s2 = [('', [1, 2, 3, 4]), ('', [2, 3, 4, 5])]
_EX = {'donut': dict(items=[('', 1)] * 6), 'colS': dict(cats=_c4, series=_s2), 'col': dict(cats=_c4, series=_s2), 'line': dict(cats=_c4, series=_s2),
       'col_note': dict(cats=_c4, series=_s2[:1]), 'area': dict(cats=_c4, vals=[1, 2, 3, 4], sname=''), 'pie': dict(items=[('', 1)] * 6),
       'colP': dict(cats=_c4, series=_s2), 'radar': dict(cats=_c4 + ['จ'], series=[('', [1, 2, 3, 4, 5]), ('', [2, 3, 4, 5, 1])])}
# ลำดับ = ลำดับเลือกเมื่อคะแนนเท่ากัน: แบบเฉพาะทาง (สัดส่วน แท่งซ้อน) ก่อน / ต่อชนิด B ก่อน C (C ใช้ไม่ได้ในชุดไม่มีรูป)
SEQ = [(f'ch{st}_{k}', dict(t='', s='', note='', **_EX[k])) for k in _EX for st in 'bc']


# ══ ใบ 023: 18 ชนิด 40 แบบ ตามแกลเลอรีที่ไอซ์อนุมัติ (docs/doc2slide/mockups/023/a + b) ═══════════════════════
# ไอซ์ 1 พ.ย. 2569: "ผ่านทั้งหมดนะครับแต่ต้องมีฟีเจอร์ให้เลือกคู่สีเองด้วยนะ" / "เพิ่มฟีเจอร์ปรับคู่สีที่ไล่สีเองได้ด้วยนะ เผื่อเค้าใส่สี CI ของตัวเอง"
# ข้อมูลที่เก็บ (อยู่ใน KEEP ของ doc2slide: เลิกทำ / IndexedDB เก็บครบ):
#   d['chart'] = {type, style, colors: {pri: [[ตำแหน่ง 0-1, hex], ...], acc: [...]} (สีเฉพาะกราฟนี้ ไม่ใส่ = ใช้ของทั้งไฟล์),
#                 pc: {'i.j': hex | จุดสี}  สีรายชิ้น (ชุด i จุด j) / {'i': ...} ทั้งชุด, lab: {คีย์: ข้อความ} ป้ายที่ลูกค้าพิมพ์เอง}
#   ทั้งไฟล์: doc2slide.BR['chartc'] = {pri, acc} ส่งมาเป็น d['_pal'] ตอนวาด / ไม่มีทั้งสองอย่าง = สีตามชุด (_theme)
#   ตัวเลข ชื่อหมวด ชื่อชุด = ตาราง (cats / series / vals / items) หัวเรื่อง หัวรอง คำอธิบาย = t / s / note
#   lab: 'big' ข้อความใต้ตัวเลขใหญ่ / 'e.j' 'e.js' ป้ายเหตุการณ์จุด j (บรรทัดสอง) / 'q.0'-'q.3' ชื่อกลุ่ม 4 ช่อง (ขวาบน ซ้ายบน ขวาล่าง ซ้ายล่าง)
#   ไม่มีคำที่เราแต่งเอง: ป้าย/ชื่อกลุ่มในแกลเลอรีเป็นตัวอย่าง ว่างไว้ ลูกค้าพิมพ์ถึงขึ้น
# ชื่อ shape = 'ch:<คีย์>' ให้เว็บแตะแล้วรู้ว่าแก้อะไร: v.i.j ตัวเลข (ตารางแถว j คอลัมน์ i+1) / c.j ชื่อหมวด (แถว j คอลัมน์ 0) / s.i ชื่อชุด (หัวคอลัมน์ i+1)
#   p.i.j ชิ้นกราฟ (สีรายชิ้น pc) / lab.<k> ป้ายของลูกค้า / x.* ตัวเลขที่คิดจากตาราง (ยอดรวม %) แก้ตรงไม่ได้ / d.* ลายตกแต่ง / chart = กราฟ PowerPoint จริง
# แบบ "แก้ใน Excel ได้" = กราฟ PowerPoint จริง ชื่อหมวด ชื่อชุด ตัวเลข อยู่ในชีตฝัง (คอลัมน์ B ขึ้นไป = ค่าที่ลูกค้าใส่ตามลำดับ)
#   คอลัมน์ช่วย (ฐานที่ซ่อนของน้ำตก/กรวย/ช่วงค่า, % สะสมของพาเรโต) เป็นสูตรอ้างคอลัมน์ข้อมูล แก้ชีตแล้วกราฟตาม
from pptx.chart.data import CategoryChartData, XyChartData, BubbleChartData
from pptx.enum.chart import XL_CHART_TYPE as XT
from pptx.chart.datalabel import DataLabels
from pptx.oxml.xmlchemy import OxmlElement

TYPES = [('column', 'กราฟแท่ง', 'Column'), ('stacked_column', 'กราฟแท่งซ้อน', 'Stacked column'), ('bar', 'กราฟแท่งแนวนอน', 'Bar'),
         ('stacked_bar', 'กราฟแท่งแนวนอนซ้อน', 'Stacked bar'), ('line', 'กราฟเส้น', 'Line'), ('area', 'กราฟพื้นที่', 'Area'),
         ('pie', 'กราฟวงกลม', 'Pie'), ('donut', 'กราฟโดนัท', 'Donut'), ('funnel', 'กราฟกรวย', 'Funnel'),
         ('scatter', 'กราฟกระจาย', 'Scatter'), ('bubble', 'กราฟฟอง', 'Bubble'), ('radar', 'กราฟใยแมงมุม', 'Radar'),
         ('waterfall', 'กราฟน้ำตก', 'Waterfall'), ('marimekko', 'กราฟโมเสก', 'Marimekko'), ('combo', 'กราฟแท่งผสมเส้น', 'Combo'),
         ('pareto', 'กราฟพาเรโต', 'Pareto'), ('range', 'กราฟช่วงค่า', 'Range'), ('sankey', 'กราฟสายน้ำ', 'Sankey')]
STY, NAME, XLS = {}, {}, set()
DEF = {'area': ('area', 'area_native'), 'col': ('column', 'col_native'), 'col_note': ('column', 'col_native'), 'colS': ('stacked_column', 'scol_native'),
       'colP': ('stacked_bar', 'sbar_track'), 'donut': ('donut', 'donut_native'), 'pie': ('pie', 'pie_native'), 'line': ('line', 'line_native'),
       'radar': ('radar', 'radar_a')}


def _st(t, sid, th, xl=False):
    def deco(fn):
        STY[(t, sid)] = fn; NAME[(t, sid)] = th
        if xl: XLS.add((t, sid))
        return fn
    return deco


# ── ข้อมูล ──────────────────────────────────────────────────────────────────
def _raw(d):
    """(ชื่อหมวด, [(ชื่อชุด, ค่า)]) จากหน้ากราฟทุกรูปแบบ (series / vals / items ของโดนัท)"""
    if d.get('series'): cats, ser = list(d['cats']), [(n, list(v)) for n, v in d['series']]
    elif 'vals' in d: cats, ser = list(d['cats']), [(d.get('sname', ''), list(d['vals']))]
    else:
        its = d.get('items') or []
        cats = [r[0] for r in its]; ser = [('', [next((x for x in r[1:] if isinstance(x, (int, float)) and not isinstance(x, bool)), 0) for r in its])]
    sn = d.get('_sn') or []
    return cats, [(sn[i] if i < len(sn) and sn[i] is not None else n, v) for i, (n, v) in enumerate(ser)]


def _hex(c): return str(c).lstrip('#').upper()


def _stops(x):
    """[[ตำแหน่ง, hex], ...] (กี่จุดก็ได้ อย่างน้อย 2) หรือ hex เดียว -> [(0-1, 'RRGGBB')] เรียงตามตำแหน่ง"""
    if not x: return None
    if isinstance(x, str): return [(0.0, _hex(x)), (1.0, _hex(x))]
    st = sorted((min(1.0, max(0.0, float(p))), _hex(c)) for p, c in x)
    return st if len(st) > 1 else [(0.0, st[0][1]), (1.0, st[0][1])]


def _samp(st, t):
    t = min(1.0, max(0.0, t))
    if t <= st[0][0]: return st[0][1]
    for (p0, c0), (p1, c1) in zip(st, st[1:]):
        if t <= p1: return mix(c0, c1, 0 if p1 == p0 else (t - p0) / (p1 - p0))
    return st[-1][1]


def _seg(st, t0, t1): return [(0.0, _samp(st, t0)), (1.0, _samp(st, t1))]
def _lite(st, k, S): return [(p, mix(c, S['surf'], k)) for p, c in st]


def _theme(S):
    """สีตั้งต้น = สีของชุด: หลัก = สีเด่นของแบบหน้า ไล่จางเข้าหาพื้น / เน้น = สีรองของชุด (≥ 3:1 บนพื้น ห่างจากสีหลัก)"""
    a = P['acc2'] if cratio(P['acc2'], S['surf']) >= 3 else ink_on(P['acc2'], S['surf'], 3)
    if cratio(a, S['hi']) < 1.4: a = S['text']
    return {'pri': [(0.0, S['hi']), (1.0, mix(S['hi'], S['surf'], 0.45))], 'acc': [(0.0, a), (1.0, mix(a, S['surf'], 0.3))]}


def _data(d, S):
    D = types.SimpleNamespace(S=S, dx=[])
    D.cats, D.ser = _raw(d); D.n, D.k = len(D.cats), len(D.ser)
    nf = d.get('_nf')
    D.nf = [[(nf[min(i, len(nf) - 1)] + ['General'] * D.n)[j] for j in range(D.n)] for i in range(D.k)] if nf else [['General'] * D.n for _ in range(D.k)]
    cfg = d.get('chart') or {}; pal = cfg.get('colors') or d.get('_pal') or {}; th = _theme(S)
    D.pri = _stops(pal.get('pri')) or th['pri']; D.acc = _stops(pal.get('acc')) or th['acc']
    D.pc = {str(k): _stops(v) for k, v in (cfg.get('pc') or {}).items() if v}
    D.lab = cfg.get('lab') or {}
    return D


def _imax(D, i=0): v = D.ser[i][1]; return v.index(max(v))


def _pg(D, i, j, hi=False, df=None):
    """จุดสีของชิ้น: สีรายชิ้นของลูกค้า > ทั้งชุด > สีเน้น (ชิ้นเด่น) > ค่าที่แบบกำหนด > สีหลัก (หลายชุด = ช่วงของสีหลัก)"""
    o = D.pc.get(f'{i}.{j}') or D.pc.get(f'{i}')
    if o: return o
    if hi: return D.acc
    if df: return df
    return D.pri if D.k == 1 else _seg(D.pri, i / D.k, (i + 0.85) / D.k)


def _on(D, st, t=0.5):
    """ตัวหนังสือบนชิ้นไล่สี: วัดกับสีตรงกลางชิ้น (ที่ตัวหนังสืออยู่) เลือกขาว/เข้มของชุด ไม่ถึง 4.5:1 ดันสีต่อ (ink_on)"""
    bg = _samp(st, t); c = max((D.S['lt'], D.S['dk']), key=lambda o: cratio(o, bg))
    return c if cratio(c, bg) >= 4.5 else ink_on(c, bg, 4.5)


def _ink(D, c): return c if cratio(c, D.S['surf']) >= 4.5 else ink_on(c, D.S['surf'], 4.5)
def _trk(S): return mix(S['surf'], S['text'], 0.09)


def _fv(D, i, j, v=None):
    v = D.ser[i][1][j] if v is None else v; f = D.nf[i][j] if j < len(D.nf[i]) else 'General'
    if not f or f == 'General':
        return f'{v:,.2f}'.rstrip('0').rstrip('.') if isinstance(v, float) and v != int(v) else f'{int(round(v)):,}'
    return _xf(v, f)


def _pct(D, j, i=0):
    """สัดส่วนของชิ้น j: ตารางเป็น % อยู่แล้วใช้ตามตาราง ไม่งั้นคิดจากผลรวม"""
    if '%' in D.nf[i][j]: return _fv(D, i, j)
    return f'{round(D.ser[i][1][j] / (sum(D.ser[i][1]) or 1) * 100)}%'


def _sgn(D, i, j):
    v = D.ser[i][1][j]; t = _fv(D, i, j, abs(v))
    return ('+' if v > 0 else '−' if v < 0 else '') + t


def _nice(x):
    e = 10 ** math.floor(math.log10(x)) if x > 0 else 1
    return next(m * e for m in (1, 2, 2.5, 5, 10) if m * e >= x)


def _tops(D):
    from collections import Counter
    return [Counter(f).most_common(1)[0][0] for f in D.nf]


# ── รูปทรง ──────────────────────────────────────────────────────────────────
def _nm(sh, key): sh.name = f'ch:{key}'; return sh


def _gf(fill, st, ang=90, alpha=None, path=False):
    """ไล่สีทุกจุด (a:gsLst) บน fill ของ shape / ชุดข้อมูล / ชิ้นกราฟ / เส้น  ang 90 = บนลงล่าง 0 = ซ้ายไปขวา  path = วงกลมจากกลาง"""
    fill.gradient(); g = fill._xPr.find(qn('a:gradFill'))
    for e in list(g): g.remove(e)
    gl = etree.SubElement(g, qn('a:gsLst'))
    for p, c in st:
        cl = etree.SubElement(etree.SubElement(gl, qn('a:gs'), pos=str(int(round(p * 1e5)))), qn('a:srgbClr'), val=c)
        if alpha:
            a = alpha[0] + (alpha[1] - alpha[0]) * p
            if a < 1: etree.SubElement(cl, qn('a:alpha'), val=str(int(a * 1e5)))
    if path:
        q = str(50000); pa = etree.SubElement(g, qn('a:path'), path='circle'); etree.SubElement(pa, qn('a:fillToRect'), l=q, t=q, r=q, b=q)
    else: etree.SubElement(g, qn('a:lin'), ang=str(int(ang * 60000)), scaled='0')
    g.set('rotWithShape', '1')


def _G(s, key, kind, x, y, w, h, st, ang=90, adj=None, alpha=None):
    sh = shp(s, kind, x, y, w, max(h, 0.01), None, adj=adj); _gf(sh.fill, st, ang, alpha); return _nm(sh, key)


def _S(s, key, kind, x, y, w, h, c, adj=None, a=None, line=None, lw=1, dash=False):
    return _nm(shp(s, kind, x, y, w, max(h, 0.01), c, line=line, lw=lw, adj=adj, a=a, dash=dash), key)


def _T(s, D, key, x, y, w, h, t, sz, c, wt='md', al='c', an='m'):
    t = str(t)
    if not t.strip(): return None
    D.dx.append(t); return _nm(txt(s, x, y, w, h, t, sz, c, wt, al, an), key)


def _F(s, key, pts, st=None, ang=0, close=True, line=None, lw=2, alpha=None):
    fb = s.shapes.build_freeform(I(pts[0][0]), I(pts[0][1]))
    fb.add_line_segments([(I(a), I(b)) for a, b in pts[1:]], close=close)
    sh = fb.convert_to_shape(); base._nostyle(sh)
    if st and close: _gf(sh.fill, st, ang, alpha)
    else: sh.fill.background()
    if isinstance(line, list): _gf(sh.line.fill, line, ang); sh.line.width = Pt(lw)
    elif line: sh.line.color.rgb = rgb(line); sh.line.width = Pt(lw)
    else: sh.line.fill.background()
    return _nm(sh, key)


def _bez(p1, c1, c2, p2, k=12):
    out = []
    for q in range(1, k + 1):
        t = q / k; a, b, c, e = (1 - t) ** 3, 3 * (1 - t) ** 2 * t, 3 * (1 - t) * t * t, t ** 3
        out.append((a * p1[0] + b * c1[0] + c * c2[0] + e * p2[0], a * p1[1] + b * c1[1] + c * c2[1] + e * p2[1]))
    return out


def _smooth(pts, k=10):
    out = [pts[0]]
    for i in range(len(pts) - 1):
        p0 = pts[i - 1] if i else pts[i]; p1, p2 = pts[i], pts[i + 1]; p3 = pts[i + 2] if i + 2 < len(pts) else p2
        out += _bez(p1, (p1[0] + (p2[0] - p0[0]) / 6, p1[1] + (p2[1] - p0[1]) / 6), (p2[0] - (p3[0] - p1[0]) / 6, p2[1] - (p3[1] - p1[1]) / 6), p2, k)
    return out


def _arcadj(a0, a1, th=None):
    """มุมจากบนตามเข็ม (องศา) -> adj ของ pie/blockArc (0 = ขวา, หน่วย 60000/1e5)"""
    r = [((270 + a0) % 360) * 0.6, ((270 + a1) % 360) * 0.6]
    return r + ([th] if th is not None else [])


def _polar(cx, cy, r, a): t = math.radians(a - 90); return cx + r * math.cos(t), cy + r * math.sin(t)


def _leg(s, D, x, y, w, sts, names=None):
    names = names or [n for n, _ in D.ser]; cw = w / max(1, len(sts))
    for i, st in enumerate(sts):
        _G(s, f'p.{i}', 'oval', x + cw * i, y + 0.06, 0.18, 0.18, st)
        _T(s, D, f's.{i}', x + cw * i + 0.26, y, cw - 0.3, 0.3, names[i], 12, D.S['soft'], 'rg', 'l')


def _fz(t, w, hi=22, lo=10): return max(lo, min(hi, w * 72 / max(1, len(t)) / 0.58))


# ── กราฟ PowerPoint จริง ───────────────────────────────────────────────────────
def _xc(s, D, xt, box, cats=None, ser=None, fmts=None, xy=None):
    x, y, w, h = box
    if xy:
        cd = XyChartData() if xy == 'xy' else BubbleChartData()
        for nm, pts, f in ser:
            sr = cd.add_series(nm, number_format=f)
            for p in pts: sr.add_data_point(*p)
    else:
        cd = CategoryChartData(); cd.categories = cats
        for (nm, vs), f in zip(ser, fmts or ['General'] * len(ser)): cd.add_series(nm, vs, number_format=None if f == 'General' else f)
    gf = s.shapes.add_chart(xt, I(x), I(y), I(w), I(h), cd); _nm(gf, 'chart'); ch = gf.chart
    ch.has_title = False; ch.has_legend = False; ch.font.size = Pt(14); ch.font.color.rgb = rgb(D.S['soft'])
    if not xy and _notes(D): _book(ch, [('', cats, None)] + [(nm, vs, f) for (nm, vs), f in zip(ser, fmts or ['General'] * len(ser))], _notes(D))   # ชื่อหมวด/ชุด/ค่า ตำแหน่งเดิม + หมายเหตุ
    if xt not in (XT.PIE, XT.DOUGHNUT): ch.value_axis.has_major_gridlines = False   # เส้นตารางเปิดเองเฉพาะแบบที่ต้องอ่านค่าจากแกน (_vgrid)
    return ch


def _xdone(ch):
    for el in ch._chartSpace.iter(qn('a:defRPr'), qn('a:rPr')): base._font(el, 'rg')


def _sfill(sr, D, i, ang=90, hi=None, df=None):
    """ไล่สีทั้งชุด (คำอธิบายสีของ PowerPoint ใช้สีนี้) + ชิ้นที่ต่าง (ชิ้นเด่น / สีรายชิ้นของลูกค้า / สีต่อแถวของแบบ)"""
    _gf(sr.format.fill, _pg(D, i, -1, df=df(-1) if df else None), ang); sr.format.line.fill.background()
    for j in range(D.n):
        if f'{i}.{j}' in D.pc or j == hi or df:
            pt = sr.points[j]; _gf(pt.format.fill, _pg(D, i, j, j == hi, df(j) if df else None), ang); pt.format.line.fill.background()
    _noinv(sr)


NOTE = 'หมายเหตุ'                                          # หัวคอลัมน์ป้ายเหตุการณ์ในตาราง/ชีตฝัง (ไอซ์ 1 พ.ย. ข้อ 5) ไม่ขึ้นบนสไลด์


def _notes(D, order=None):
    """ป้ายเหตุการณ์ต่อแถว (lab['e.j'] + บรรทัดสอง 'e.js') ไม่มีสักแถว = None"""
    t = [('\n'.join(x for x in (D.lab.get(f'e.{j}', ''), D.lab.get(f'e.{j}s', '')) if x)) for j in (order or range(D.n))]
    return t if any(t) else None


def _book(ch, cols, notes=None):
    """ชีตฝังเขียนเอง: cols = [(หัว, [ค่า | ข้อความ | ('=สูตร', ค่าที่คิดแล้ว)], รูปแบบ)] คอลัมน์แรก = ชื่อหมวด / notes = คอลัมน์หมายเหตุท้ายสุด (ไม่เข้ากราฟ)"""
    if notes: cols = list(cols) + [(NOTE, notes, None)]
    import xlsxwriter
    b = io.BytesIO(); wb = xlsxwriter.Workbook(b, {'in_memory': True}); ws = wb.add_worksheet('Sheet1')
    for c, (hd, vals, f) in enumerate(cols):
        fm = wb.add_format({'num_format': f}) if f and f != 'General' else None
        ws.write_string(0, c, str(hd or ''))
        for r, v in enumerate(vals):
            if isinstance(v, tuple): ws.write_formula(r + 1, c, v[0], fm, v[1])
            elif isinstance(v, str): ws.write_string(r + 1, c, v)
            else: ws.write_number(r + 1, c, v, fm)
    ws.set_column(0, len(cols), 14); wb.close()
    ch.part.chart_workbook.update_from_xlsx_blob(b.getvalue())


def _ref(e, col, n, tag='c:val'):
    L = chr(65 + col); e.find(f'{qn(tag)}//{qn("c:f")}').text = f'Sheet1!${L}$2:${L}${n + 1}'


def _tref(e, col): e.find(f'{qn("c:tx")}//{qn("c:f")}').text = f'Sheet1!${chr(65 + col)}$1'


def _rlab(sr, col, texts, c, sz=14, pos=None, bold=False):
    """ป้ายจากเซลล์ (Value From Cells, Office 2013+) เช่น ค่าจริงที่มีเครื่องหมายของน้ำตก ชื่อจุดของกราฟกระจาย"""
    _lab(sr, c, sz, bold, pos); sr._element.find(qn('c:dLbls')).find(qn('c:showVal')).set('val', '0')
    dl = sr._element.find(qn('c:dLbls')); n = len(texts); L = chr(65 + col)
    x_ = etree.SubElement(etree.SubElement(dl, qn('c:extLst')), qn('c:ext'), uri='{CE6537A1-D6FC-4f65-9D91-7224C49458BB}', nsmap={'c15': C15})
    etree.SubElement(x_, f'{{{C15}}}showDataLabelsRange').set('val', '1')
    x_ = etree.SubElement(etree.SubElement(sr._element, qn('c:extLst')), qn('c:ext'), uri='{02D57815-91ED-43cb-92C2-25804820EDAC}', nsmap={'c15': C15})
    rg = etree.SubElement(x_, f'{{{C15}}}datalabelsRange'); etree.SubElement(rg, f'{{{C15}}}f').text = f'Sheet1!${L}$2:${L}${n + 1}'
    cache = etree.SubElement(rg, f'{{{C15}}}dlblRangeCache'); etree.SubElement(cache, qn('c:ptCount')).set('val', str(n))
    for j, t in enumerate(texts):
        etree.SubElement(etree.SubElement(cache, qn('c:pt'), idx=str(j)), qn('c:v')).text = str(t)


def _to_line(ch, k):
    """ชุดที่ k เป็นต้นไปของกราฟแท่ง ย้ายเป็นเส้นบนแกนรองขวา (Combo ของ PowerPoint) คืนกราฟเส้น"""
    pa = ch._chartSpace.find('.//' + qn('c:plotArea')); bc = pa.find(qn('c:barChart'))
    lc = OxmlElement('c:lineChart'); etree.SubElement(lc, qn('c:grouping')).set('val', 'standard'); etree.SubElement(lc, qn('c:varyColors')).set('val', '0')
    for e in bc.findall(qn('c:ser'))[k:]:
        bc.remove(e); iv = e.find(qn('c:invertIfNegative'))
        if iv is not None: e.remove(iv)
        lc.append(e)
    etree.SubElement(lc, qn('c:marker')).set('val', '1')
    for a in ('91001', '91002'): etree.SubElement(lc, qn('c:axId')).set('val', a)
    bc.addnext(lc)
    cat, val = pa.find(qn('c:catAx')), pa.find(qn('c:valAx'))
    c2, v2 = copy.deepcopy(cat), copy.deepcopy(val)
    for ax, me, other in ((c2, '91001', '91002'), (v2, '91002', '91001')):
        ax.find(qn('c:axId')).set('val', me); ax.find(qn('c:crossAx')).set('val', other)
    c2.find(qn('c:delete')).set('val', '1'); v2.find(qn('c:axPos')).set('val', 'r')
    cr = v2.find(qn('c:crosses'))
    if cr is None: cr = etree.Element(qn('c:crosses')); v2.find(qn('c:crossAx')).addnext(cr)
    cr.set('val', 'max')
    val.addnext(c2); c2.addnext(v2)
    return ch.plots[1]


def _cat_axis(ch, D, rev=False):
    _axes(ch, D.S); ch.category_axis.reverse_order = rev     # แนวนอน: แถวแรกอยู่บน


def _vgrid(va, S, fmt=None):
    va.visible = True; _grid(va, S['grid']); va.format.line.fill.background()
    va.tick_labels.font.size = Pt(12); va.tick_labels.font.color.rgb = rgb(S['soft'])
    if fmt: va.tick_labels.number_format = fmt; va.tick_labels.number_format_is_linked = False


# ── ตัวจัด: ข้อมูลพอไหม (เมนูชนิดบนเว็บ ชนิดที่ไม่พอเป็นสีเทาพร้อมเหตุผล) ──────────────────────
EVENTS = {'line_callout', 'combo_b'}                       # แบบที่วาดป้ายเหตุการณ์ (lab e.j = คอลัมน์หมายเหตุ)
ONE = {'col_capsule', 'col_cylinder', 'bar_arrow', 'bar_dots', 'line_callout', 'radar_b'}   # อินโฟกราฟิกที่วาดได้ชุดเดียว


def _why(d, t, sid=None):
    cats, ser = _raw(d); n, k = len(cats), len(ser); vs = [v for _, x in ser for v in x]
    neg = any(v < 0 for v in vs); mx = {'pie': 6, 'donut': 6, 'funnel': 6, 'marimekko': 6, 'sankey': 5, 'bubble': 8}.get(t, 8)
    if not vs or n < 2: return 'ต้องมีข้อมูลอย่างน้อย 2 แถว'
    if n > mx: return f'แบบนี้รับได้ไม่เกิน {mx} แถว ข้อมูลมี {n} แถว'
    need = {'scatter': (2, 2, 'กราฟกระจายต้องมี 2 คอลัมน์ตัวเลข (แกนนอน แกนตั้ง)'), 'bubble': (3, 3, 'Bubble ต้องมี 3 คอลัมน์ตัวเลข (แกนนอน แกนตั้ง ขนาดวง)'),
            'combo': (2, 2, 'แท่งผสมเส้นต้องมี 2 คอลัมน์ตัวเลข (แท่ง กับ เส้น)'), 'range': (2, 2, 'ช่วงค่าต้องมี 2 คอลัมน์ตัวเลข (ต่ำสุด สูงสุด)'),
            'stacked_column': (2, 3, 'แท่งซ้อนต้องมี 2-3 คอลัมน์ตัวเลข'), 'stacked_bar': (2, 3, 'แท่งซ้อนต้องมี 2-3 คอลัมน์ตัวเลข'),
            'marimekko': (2, 3, 'โมเสกต้องมี 2-3 คอลัมน์ตัวเลข'), 'sankey': (2, 4, 'สายน้ำต้องมี 2-4 คอลัมน์ตัวเลข (ปลายทาง)'),
            'pie': (1, 1, 'วงกลมต้องมีคอลัมน์ตัวเลขเดียว'), 'donut': (1, 1, 'โดนัทต้องมีคอลัมน์ตัวเลขเดียว'), 'funnel': (1, 1, 'กรวยต้องมีคอลัมน์ตัวเลขเดียว'),
            'waterfall': (1, 1, 'น้ำตกต้องมีคอลัมน์ตัวเลขเดียว (ยอดตั้งต้นแล้วตามด้วยส่วนเพิ่ม/ลด)'), 'pareto': (1, 1, 'พาเรโตต้องมีคอลัมน์ตัวเลขเดียว')}.get(t, (1, 3, 'รับได้ 1-3 คอลัมน์ตัวเลข'))
    if not need[0] <= k <= need[1]: return need[2]
    if t == 'radar' and n < 3: return 'ใยแมงมุมต้องมีอย่างน้อย 3 แถว'
    if t in ('scatter', 'waterfall', 'pareto') and n < 3: return 'ต้องมีข้อมูลอย่างน้อย 3 แถว'
    if t in ('pie', 'donut', 'funnel', 'pareto', 'bubble') and min(ser[-1][1]) <= 0: return 'ทุกค่าต้องมากกว่า 0'
    if t in ('stacked_column', 'stacked_bar', 'marimekko', 'sankey') and neg: return 'มีค่าติดลบ ซ้อน/แบ่งสัดส่วนไม่ได้'
    if t in ('marimekko', 'sankey') and any(sum(v[j] for _, v in ser) <= 0 for j in range(n)): return 'ทุกแถวต้องมีผลรวมมากกว่า 0'
    if t == 'range' and any(a > b for a, b in zip(ser[0][1], ser[1][1])): return 'คอลัมน์แรกต้องเป็นค่าต่ำสุด คอลัมน์ที่สองค่าสูงสุด ทุกแถว'
    if sid and (t, sid) not in XLS:
        if sid in ONE and k > 1: return f'แบบนี้แสดงได้ชุดเดียว ข้อมูลมี {k} คอลัมน์ตัวเลข'
        if neg and t != 'waterfall': return 'มีค่าติดลบ แบบอินโฟกราฟิกนี้วาดไม่ได้'
    return None


def chart_types(d):
    """เว็บเรียก: ทุกชนิด/แบบ ใช้กับข้อมูลหน้านี้ได้ไหม [{type th en ok why styles: [{id th xl ok why}]}]"""
    out = []
    for t, th, en in TYPES:
        sts = [dict(id=sid, th=NAME[(tt, sid)], xl=(tt, sid) in XLS, why=_why(d, t, sid)) for tt, sid in STY if tt == t]
        for x in sts: x['ok'] = x['why'] is None
        out.append(dict(type=t, th=th, en=en, ok=any(x['ok'] for x in sts), why=None if any(x['ok'] for x in sts) else sts[0]['why'], styles=sts))
    return out


def table_of(d):
    """ตารางของกราฟหน้านี้ [หัว, แถว...] ให้แผงแก้ข้อมูล (ค่าตามรูปแบบเซลล์ต้นทาง)"""
    cats, ser = _raw(d); nf = d.get('_nf')
    D = types.SimpleNamespace(ser=ser, nf=[[(nf[min(i, len(nf) - 1)] + ['General'] * len(cats))[j] for j in range(len(cats))] for i in range(len(ser))] if nf else [['General'] * len(cats)] * len(ser))
    h0 = (d.get('head') or [''])[0]; cfg = d.get('chart') or {}; lab = cfg.get('lab') or {}
    nt = ['\n'.join(x for x in (lab.get(f'e.{j}', ''), lab.get(f'e.{j}s', '')) if x) for j in range(len(cats))]
    note = any(nt) or cfg.get('style') in EVENTS                # แบบที่มีป้ายเหตุการณ์: คอลัมน์หมายเหตุท้ายตาราง (ข้อความอิสระ)
    return [[h0 if isinstance(h0, str) else h0[0]] + [n for n, _ in ser] + ([NOTE] if note else [])] + \
        [[c] + [_fv(D, i, j) for i in range(len(ser))] + ([nt[j]] if note else []) for j, c in enumerate(cats)]


def _tsid(d, kind):
    cfg = d.get('chart') or {}; t, sid = cfg.get('type'), cfg.get('style')
    if not t: t, sid = DEF.get(kind, DEF['col'])
    if (t, sid) not in STY: sid = next(k for tt, k in STY if tt == t)
    return t, sid


def _styled(prs, d, st, kind):
    t, sid = _tsid(d, kind)
    why = _why(d, t, sid)
    if why: raise ValueError(why)
    lay = (d.get('chart') or {}).get('lay')
    if lay:
        s, S, D, boxes = _lay(prs, d, lay)
    else:
        s, S, box = _frame(prs, d, st, d.get('s')); D = _data(d, S); boxes = [box]
    d.pop('_nf', None)                                     # รูปแบบตัวเลขลงชีต/ป้ายเองแล้ว ไม่ให้ doc2slide.numfmt เขียนทับ (กราฟผสม/กระจายมีหลายแกน)
    if lay and not (d.get('chart') or {}).get('type'):    # ใบ 028 ยังไม่ได้เลือกแบบกราฟเอง: เพดานเดิมของหน้ากราฟกลาง (หมวด / ป้ายต้องไม่กว้างกว่าแท่ง)
        if kind in CAP and ('cats' in d or 'items' in d): _cap(kind, d, 3 if kind == 'radar' else 2)
        if kind in ('col', 'col_note', 'colS') and d.get('series'): _fits(d, d['series'], boxes[0][2], 14 if kind == 'colS' or len(d['series']) > 1 else 16, kind == 'colS')
    STY[(t, sid)](s, D, boxes[0])
    if len(boxes) > 1:                                     # F สองกราฟ: ตารางที่สองของหน้าที่รวมมา (d['two']) ชิ้นชื่อ ch2: เว็บไม่จับเป็นชิ้นแก้ของกราฟแรก
        d2 = dict(d['two']['d'])
        if d.get('_pal'): d2.setdefault('_pal', d['_pal'])
        t2, sid2 = _tsid(d2, _kind2(d['two']))
        if _why(d2, t2, sid2): t2, sid2 = next(((x['type'], y['id']) for x in chart_types(d2) for y in x['styles'] if y['ok']), (t2, sid2))
        D2 = _data(d2, S); n0 = len(s.shapes)
        STY[(t2, sid2)](s, D2, boxes[1])
        for x in list(s.shapes)[n0:]:
            if x.name.startswith('ch:'): x.name = 'ch2:' + x.name[3:]
        D.dx += D2.dx
    d['_dx'] = D.dx                                        # ตัวเลขที่คิดจากตาราง (ยอดรวม %) ให้ scrub รู้ว่าเป็นของลูกค้า


# ══ ใบ 028 เลย์เอาต์หน้ากราฟ A-F + ปรับเอง (ไอซ์ 1 พ.ย. 2569 อนุมัติ mockup docs/doc2slide/mockups/028/) ═══════════════════
# d['chart']['lay'] = {t: top|left|corner หัวข้อ, p: 0|1 แผง, n: none|right|left คำอธิบาย, b: 0|1 ตัวเลขใหญ่, k: 1|2 กราฟ, z: fit|edge ขนาด}
# แบบสำเร็จ = ชุดค่า (LAYP) / กฎกดไม่ได้ (lay_bad) ตรงกับ gen.py invalid() / พิกัดตาม gen.py compose() หน่วย px ของสไลด์ 1600x900
# คำบนหน้า = ของลูกค้าเท่านั้น: หัวเรื่อง t หัวรอง s (หน่วย) คำอธิบาย note (ว่าง = ไม่มีในไฟล์ บนจอเป็นช่องจางให้แตะพิมพ์ ดู doc2slide.render)
# ตัวเลขใหญ่ = ค่าสูงสุดของตาราง (ตามรูปแบบเซลล์) + ชื่อชุด (หน่วย) + ชื่อแถว / วงกลม-โดนัท = % ของแถวสูงสุด  ชิ้นชื่อ ch:x.big* (คิดจากตาราง แก้ที่ตาราง)
# k=2 = หน้าที่รวมตารางของหน้ากราฟถัดไปมาไว้ (d['two'] = {i: ตำแหน่งใน ITEMS, nm: layout เดิม, d: หน้าเดิมทั้งหน้า, ct: หัวข้อในเนื้อหา}) แยกกลับได้ครบ
LAYP = {'A': dict(t='left', p=1, n='none', b=0, k=1, z='fit'), 'B': dict(t='top', p=0, n='none', b=0, k=1, z='fit'),
        'C': dict(t='top', p=0, n='right', b=0, k=1, z='fit'), 'D': dict(t='top', p=0, n='none', b=1, k=1, z='fit'),
        'E': dict(t='corner', p=0, n='none', b=0, k=1, z='edge'), 'F': dict(t='top', p=0, n='none', b=0, k=2, z='fit')}
LAYV = {'t': ('top', 'left', 'corner'), 'p': (0, 1), 'n': ('none', 'right', 'left'), 'b': (0, 1), 'k': (1, 2), 'z': ('fit', 'edge')}


def lay_norm(c):
    """ค่าที่ขาด/ผิด -> ค่าของ B (เก็บแบบเดิม 'bleed' = 'edge')"""
    c = dict(c or {}); out = {}
    for k, vs in LAYV.items():
        v = c.get(k, LAYP['B'][k]); v = 'edge' if v == 'bleed' else v
        if isinstance(vs[0], int):
            try: v = int(v)
            except Exception: v = LAYP['B'][k]
        out[k] = v if v in vs else LAYP['B'][k]
    return out


def lay_bad(c, tables=1, why2='ต้องมี 2 ตารางในหน้านี้'):
    """ตัวเลือกที่กดไม่ได้ในชุดค่า c -> {(คีย์, ค่า): เหตุผล} (= gen.py invalid ที่ไอซ์อนุมัติ)"""
    r = {}
    if c['t'] == 'corner': r[('p', 1)] = 'หัวข้อมุมเล็กไม่มีแผง'
    if c['t'] == 'left': r[('n', 'left')] = 'หัวข้ออยู่ซ้ายแล้ว'; r[('k', 2)] = 'สองกราฟใช้กับหัวข้อบนหรือมุมเล็ก'
    if tables < 2: r[('k', 2)] = why2
    if c['n'] != 'none' or c['b'] or c['p']: r[('z', 'edge')] = 'ชิดขอบใช้กับแผง คำอธิบาย หรือตัวเลขใหญ่ไม่ได้'
    if c['k'] == 2: r[('n', 'right')] = r[('n', 'left')] = r[('b', 1)] = 'สองกราฟไม่มีที่ให้'
    return r


def lay_ok(c, tables=1):
    return not any(c[k] == v for (k, v) in lay_bad(c, tables))


def _kind2(two):
    nm = two.get('nm') or ''
    return nm[4:] if nm.startswith(('chb_', 'chc_')) and nm[4:] in DEF else 'col'


def _bigof(D, t):
    """(ข้อความตัวเลข, คีย์ชื่อชุด, ชื่อแถว) ค่าสูงสุดของตาราง / วงกลม-โดนัท-กรวยสัดส่วน = % ของแถวสูงสุด"""
    i, j = max(((i, j) for i in range(D.k) for j in range(D.n)), key=lambda q: D.ser[q[0]][1][q[1]])
    if t in ('pie', 'donut'): return _pct(D, j, i), None, j
    return _fv(D, i, j), i, j


def _lay(prs, d, lay):
    """พื้น หัวเรื่อง หน่วย คำอธิบาย ตัวเลขใหญ่ ตามชุดค่า -> (สไลด์, สี, D, [กรอบกราฟ]) สี/ฟอนต์ของชุด (_style B = พื้นของชุด)"""
    c = lay_norm(lay); S = _style('B'); _CS[:] = [S]; D = _data(d, S)
    if c['k'] == 2 and not d.get('two'): c['k'] = 1      # ตารางที่สองหายไป (หน้าเดิมถูกแยกกลับ) = กราฟเดียว
    q = PX; s = None if (c['t'] == 'left' and c['p'] and c['k'] == 1) else page(prs); t_ = d.get('t', ''); sub = d.get('s') or ''
    tc = P['acc'] if cratio(P['acc'], S['surf']) >= 4.5 else S['text']      # หัวเรื่องบนพื้น: สีหลักของชุดถ้าอ่านออก
    uc = P['acc'] if cratio(P['acc'], S['surf']) >= 4.5 else S['soft']
    rule = mix(S['surf'], S['text'], 0.16); fam = T.get('head')
    note = d.get('note') or ''

    def title(x, y, w, base, lo, col, wt='rg', usz=13, ucol=None, inline=False):
        """หัวเรื่อง + หน่วยใต้หัวเรื่อง (inline = ต่อท้ายบรรทัดเดียว) คืนขอบล่าง (นิ้ว)"""
        if not t_.strip() and not sub: return y
        z = _tsz(t_, w, base, lo, wt); nl = min(3, max(1, math.ceil(_tw(t_, z, wt) / (w * 0.92)))) if t_.strip() else 0
        th = nl * z * 1.3 / 72
        if t_.strip(): txt(s, x, y, w, max(th, 0.3), t_, z, col, wt, sp=1.0, fam=fam if wt == 'rg' else None)
        if not sub: return y + th
        if inline and nl == 1:
            ux = x + _tw(t_, z, wt) + 0.18; uw = max(0.6, w - (ux - x))
            if _tw(sub, usz, 'md') <= uw:
                txt(s, ux, y, uw, th, sub, usz, ucol or uc, 'md', an='m'); return y + th
        txt(s, x + 0.02, y + th + 0.06, w, usz * 1.6 / 72, sub, usz, ucol or uc, 'md')
        return y + th + 0.06 + usz * 1.6 / 72

    def notebox(x, y, w, h):
        if not note.strip(): return
        nl_ = lambda z: math.ceil(_tw(note, z, 'rg') / (w * 0.88)) + note.count('\n')
        z = next((z for z in (18, 16, 14, 12) if nl_(z) * z * 1.45 * 1.3 / 72 <= h), 12)
        h = min(h, nl_(z) * z * 1.45 * 1.3 / 72 + 0.15)    # กล่องสูงพอดีข้อความ (ป้ายกราฟที่ยื่นออกนอกกรอบล่าง ๆ ไม่ชนกล่อง)
        if d.get('_nph'):                                  # บนจอ ยังไม่มีคำอธิบาย: กรอบเส้นประจาง + คำใบ้ (render ใส่ ไม่ออกในไฟล์)
            hh = min(h, 200 * q); _nm(shp(s, 'round', x, y, w, hh, None, line=mix(S['surf'], S['text'], 0.28), lw=1.2, adj=16 / 200, dash=True), 'd.nph')
            txt(s, x + 0.12, y, w - 0.24, hh, note, 14, mix(S['surf'], S['text'], 0.5), 'md', 'c', 'm'); return
        txt(s, x, y, w, h, note, z, S['text'], 'rg', sp=1.45)

    def bignum(x, y, w, on=None):
        t, sid = _tsid(d, 'col'); big, si, j = _bigof(D, t)
        col = on or (S['hi'] if cratio(S['hi'], S['surf']) >= 3 else S['text']); txc = on or S['text']; soft = on or S['soft']
        z = min(67, w * 72 / max(1, len(big) * 0.62)); y2 = y + z * 1.2 / 72
        bt = _T(s, D, 'x.big', x, y, min(w, _tw(big, z, 'bd') * 1.25 + 0.2), z * 1.25 / 72, big, round(z, 1), col, 'bd', 'l', 't')   # กว้างพอดีตัวเลข (เผื่อฟอนต์บนเว็บ) ไม่ตัดบรรทัด
        if bt is not None: bt.text_frame.word_wrap = False
        un = D.ser[si][0] if si is not None else ''
        if un and str(un).strip(): _T(s, D, 'x.bigu', x + 0.03, y2 + 0.05, w, 0.36, un, 15, soft, 'md', 'l', 't'); y2 += 0.42
        shp(s, 'round', x + 0.03, y2 + 0.12, 56 * q, 6 * q, col, adj=0.5)
        _T(s, D, 'x.bigc', x + 0.03, y2 + 0.3, w, 0.5, D.cats[j], 18, txc, 'bd', 'l', 't')

    if c['k'] == 2:                                        # F: สองกราฟคู่กัน หัวเรื่องของแต่ละตาราง
        d2 = d['two']['d']; boxes = []; ytop = 80 * q if c['t'] == 'top' else 48 * q
        if c['p'] and c['t'] == 'top': shp(s, 'rect', 0, 0, 1600 * q, 232 * q, S['panel'])
        ln(s, 800 * q, (250 if c['p'] else 96) * q, 800 * q, 804 * q, rule, 1.2)
        for k_, (tt, ss) in enumerate(((t_, sub), (d2.get('t', ''), d2.get('s') or ''))):
            x = (96 + k_ * 800) * q; w = 620 * q
            onp = c['p'] and c['t'] == 'top'; col = S['on'] if onp else tc
            base_ = 26 if c['t'] == 'top' else 22
            z = _tsz(tt, w, base_, 20, 'rg'); nl = min(2, max(1, math.ceil(_tw(tt, z, 'rg') / (w * 0.92)))) if str(tt).strip() else 0
            y = ytop
            if str(tt).strip(): txt(s, x, y, w, nl * z * 1.3 / 72, tt, z, col, 'rg', fam=fam); y += nl * z * 1.3 / 72
            if ss: txt(s, x + 0.02, y + 0.06, w, 0.35, ss, 13, S['on'] if onp else uc, 'md'); y += 0.06 + 0.35
            y0 = max(y + 0.25, 250 * q if onp else 0)
            if c['z'] == 'edge': boxes.append(((40 + k_ * 780) * q, y0, 740 * q, 840 * q - y0))
            else: boxes.append((x - 16 * q, y0, 640 * q, 810 * q - y0))
        return s, S, D, boxes

    if c['t'] == 'left':
        if c['p']:                                         # แผงซ้ายของเดิม (แบบ A = _frame B) คำอธิบายอยู่ท้ายแผงเมื่อไม่ได้เลือกคอลัมน์คำอธิบาย/ตัวเลขใหญ่
            dd = dict(d); dd['note'] = note if (c['n'] == 'none' and not c['b']) else ''
            if dd.get('_nph') and not dd['note']: dd.pop('_nph')
            s, S, _ = _frame(prs, dd, 'B', sub)
            x0 = 690 * q
            if c['b']: bignum(80 * q, 480 * q, 440 * q, S['on'])
        else:
            yb = title(96 * q, 96 * q, 440 * q, 36, 28.8, tc)
            ln(s, 576 * q, 150 * q, 576 * q, 790 * q, rule, 1.2); x0 = 620 * q
            if c['b']: bignum(96 * q, max(480 * q, yb + 0.4), 440 * q)
        y0, x1, y1 = 150 * q, 1512 * q, 790 * q
    elif c['t'] == 'top':
        if c['p']:
            shp(s, 'rect', 0, 0, 1600 * q, 232 * q, S['panel'])
            shp(s, 'donut', (1600 - 336) * q, -228 * q, 456 * q, 456 * q, mix(S['panel'], S['on'], 0.14), adj=56 / 456)
            z = _tsz(t_, 1150 * q, 36, 26, 'bd'); title_y = 56 * q if sub else 80 * q
            if t_.strip(): txt(s, 96 * q, title_y, 1150 * q, 0.75, t_, z, S['on'], 'bd')
            if sub: txt(s, 98 * q, 148 * q, 1150 * q, 0.35, sub, 13, S['on'], 'md')
            y0 = 300 * q
        else:
            yb = title(96 * q, 72 * q, 1300 * q, 36, 28, tc); y0 = max(268 * q, yb + 0.3)
        x0, x1, y1 = 96 * q, 1504 * q, 808 * q
    else:
        yb = title(64 * q, 48 * q, 1100 * q, 24, 20, tc, inline=True)
        x0, y0, x1, y1 = 64 * q, max(150 * q, yb + 0.3), 1536 * q, 820 * q
    if c['n'] == 'left':
        notebox(x0, y0, 340 * q, y1 - y0); ln(s, x0 + 380 * q, y0, x0 + 380 * q, y1, rule, 1.2); x0 += 420 * q
    if c['n'] == 'right':
        notebox(x1 - 340 * q, y0, 340 * q, y1 - y0); ln(s, x1 - 382 * q, y0, x1 - 382 * q, y1, rule, 1.2); x1 -= 420 * q
    if c['b'] and c['t'] != 'left':
        bignum(x0, y0 + 60 * q, 380 * q); x0 += 420 * q
    box = (x0, y0, x1 - x0, y1 - y0)
    if c['z'] == 'edge':
        box = (40 * q, y0, 1520 * q, 840 * q - y0) if c['t'] != 'left' else (x0 - 20 * q, 40 * q, 1560 * q - x0 + 20 * q, 800 * q)   # ล่าง 840: เว้นที่เลขหน้า
    return s, S, D, [box]


# ══ แบบ "แก้ใน Excel ได้" (16 แบบ) ═══════════════════════════════════════════
@_st('column', 'col_native', 'แท่งไล่สี เด่นค่าสูงสุด', True)
def _x_col(s, D, box):
    ch = _xc(s, D, XT.COLUMN_CLUSTERED, box, D.cats, D.ser, _tops(D)); pl = ch.plots[0]; pl.gap_width = 60; pl.overlap = -6
    _axes(ch, D.S); m = _imax(D) if D.k == 1 else None
    for i, sr in enumerate(pl.series):
        _sfill(sr, D, i, 90, m); _lab(sr, D.S['text'], 16 if D.k == 1 else 13, False, LP.OUTSIDE_END)
    if m is not None: _plab(pl.series[0], m, D.S['text'], 22, True, LP.OUTSIDE_END)
    if D.k > 1: _legend(ch, D.S, LG.TOP)
    _xdone(ch)


@_st('stacked_column', 'scol_native', 'ซ้อนไล่โทน', True)
def _x_scol(s, D, box, xt=XT.COLUMN_STACKED, ang=90, rev=False):
    ch = _xc(s, D, xt, box, D.cats, D.ser, _tops(D)); pl = ch.plots[0]; pl.gap_width = 60; pl.overlap = 100
    _cat_axis(ch, D, rev)
    for i, sr in enumerate(pl.series):
        _sfill(sr, D, i, ang); _lab(sr, _on(D, _pg(D, i, -1)), 13, i == 0, LP.CENTER)
        for j in range(D.n):
            if f'{i}.{j}' in D.pc: _plab(sr, j, _on(D, D.pc[f'{i}.{j}']), 13, i == 0, LP.CENTER)
    _legend(ch, D.S, LG.TOP); _xdone(ch)


@_st('bar', 'bar_native', 'แถบไล่สีซ้ายไปขวา', True)
def _x_bar(s, D, box):
    ch = _xc(s, D, XT.BAR_CLUSTERED, box, D.cats, D.ser, _tops(D)); pl = ch.plots[0]; pl.gap_width = 70; pl.overlap = -6
    _cat_axis(ch, D, True); m = _imax(D) if D.k == 1 else None
    for i, sr in enumerate(pl.series): _sfill(sr, D, i, 0, m); _lab(sr, D.S['text'], 15 if D.k == 1 else 13, False, LP.OUTSIDE_END)
    if m is not None: _plab(pl.series[0], m, D.S['text'], 20, True, LP.OUTSIDE_END)
    if D.k > 1: _legend(ch, D.S, LG.TOP)
    _xdone(ch)


@_st('stacked_bar', 'sbar_native', 'แถบซ้อนไล่โทน', True)
def _x_sbar(s, D, box): _x_scol(s, D, box, XT.BAR_STACKED, 0, True)


@_st('line', 'line_native', 'เส้นโค้งไล่สี', True)
def _x_line(s, D, box):
    ch = _xc(s, D, XT.LINE_MARKERS, box, D.cats, D.ser, _tops(D)); pl = ch.plots[0]; S = D.S
    _axes(ch, S); _vgrid(ch.value_axis, S)
    for i, sr in enumerate(pl.series):
        st = _pg(D, i, -1); _gf(sr.format.line.fill, st, 0); sr.format.line.width = Pt(5 if i == 0 else 2.5); sr.smooth = True
        sr.marker.style = XL_MARKER_STYLE.CIRCLE; sr.marker.size = 9 if i == 0 else 6
        sr.marker.format.fill.solid(); sr.marker.format.fill.fore_color.rgb = rgb(S['surf']); sr.marker.format.line.color.rgb = rgb(st[0][1])
        _lab(sr, S['soft'], 12, False, LP.ABOVE)
        for j in range(D.n):
            if f'{i}.{j}' in D.pc or (i == 0 and j == D.n - 1):
                mk = sr.points[j].marker; mk.style = XL_MARKER_STYLE.CIRCLE; mk.size = 13
                _gf(mk.format.fill, _pg(D, i, j, j == D.n - 1)); mk.format.line.color.rgb = rgb(S['surf'])
        if i == 0: _plab(sr, D.n - 1, S['text'], 18, True, LP.ABOVE)
    if D.k > 1: _legend(ch, S, LG.TOP)
    _xdone(ch)


@_st('area', 'area_native', 'พื้นไล่จางลงล่าง', True)
def _x_area(s, D, box):
    ch = _xc(s, D, XT.AREA, box, D.cats, D.ser, _tops(D)); pl = ch.plots[0]; S = D.S
    _axes(ch, S)
    for i, sr in enumerate(pl.series):
        st = _pg(D, i, -1); _gf(sr.format.fill, st, 90, (0.85, 0.12)); sr.format.line.color.rgb = rgb(st[0][1]); sr.format.line.width = Pt(3)
        _lab(sr, S['text'], 13)
    _plab(pl.series[0], _imax(D), S['text'], 20, True)
    cb = ch._chartSpace.find('.//' + qn('c:valAx') + '/' + qn('c:crossBetween'))
    if cb is not None: cb.set('val', 'between')
    if D.k > 1: _legend(ch, S, LG.TOP)
    _xdone(ch)


def _rank_df(D):
    """ชิ้นวงกลม/โดนัท: ใหญ่สุด = สีเน้น ที่เหลือไล่ช่วงสีหลักตามขนาด"""
    v = D.ser[0][1]; order = sorted(range(D.n), key=lambda j: -v[j]); r = {j: q for q, j in enumerate(order)}
    return lambda j: D.pri if j < 0 else (D.acc if r[j] == 0 else _seg(D.pri, (r[j] - 1) / max(1, D.n - 1), r[j] / max(1, D.n - 1)))


def _x_ring(s, D, box, xt, hole=None):
    ch = _xc(s, D, xt, box, D.cats, D.ser, _tops(D)); sr = ch.plots[0].series[0]; S = D.S; df = _rank_df(D)
    if hole:
        dn = ch._chartSpace.find('.//' + qn('c:doughnutChart')); hs = dn.find(qn('c:holeSize'))
        if hs is None: hs = etree.SubElement(dn, qn('c:holeSize'))
        hs.set('val', str(hole))
    _lab(sr, S['text'], 14, True)
    for j in range(D.n):
        st = _pg(D, 0, j, df=df(j)); pt = sr.points[j]; _gf(pt.format.fill, st, 45)
        pt.format.line.color.rgb = rgb(S['surf']); pt.format.line.width = Pt(2.5); _plab(sr, j, _on(D, st), 16 if st is D.acc else 14, True)
    if S['st'] == 'B': _legend(ch, S, LG.BOTTOM, 14); _manual(ch, 0.2, 0.02, 0.6, 0.82)
    else: _legend(ch, S, LG.RIGHT, 16); _manual(ch, 0.02, 0.02, 0.5, 0.96)
    _xdone(ch)


@_st('pie', 'pie_native', 'พายไล่โทน', True)
def _x_pie(s, D, box): _x_ring(s, D, box, XT.PIE)


@_st('donut', 'donut_native', 'โดนัทหนา', True)
def _x_donut(s, D, box): _x_ring(s, D, box, XT.DOUGHNUT, 58)


@_st('funnel', 'funnel_native', 'กรวยแถบกลาง', True)
def _x_funnel(s, D, box):
    """แท่งซ้อนแนวนอน: ฐานซ่อน = (ค่าสูงสุด - ค่า) / 2 เป็นสูตรในชีต แถบจึงอยู่กลางเสมอ"""
    v = D.ser[0][1]; n = D.n; mx = max(v); f = _tops(D)[0]
    ch = _xc(s, D, XT.BAR_STACKED, box, D.cats, [('', [(mx - x) / 2 for x in v]), D.ser[0]], [f, f]); pl = ch.plots[0]; pl.gap_width = 25; pl.overlap = 100
    _book(ch, [('', D.cats, None), (D.ser[0][0], v, f), ('', [(f'=(MAX($B$2:$B${n + 1})-B{j + 2})/2', (mx - x) / 2) for j, x in enumerate(v)], f)], _notes(D))
    b, sr = pl.series
    for e, col in ((b._element, 2), (sr._element, 1)): _ref(e, col, n); _tref(e, col); _ref(e, 0, n, 'c:cat')
    b.format.fill.background(); b.format.line.fill.background()
    _cat_axis(ch, D, True); ch.category_axis.format.line.fill.background()
    df = lambda j: D.pri if j < 0 else _seg(D.pri, j / n, (j + 1) / n)
    _sfill(sr, D, 0, 0, df=df); _lab(sr, D.S['text'], 14, True, LP.CENTER)
    for j in range(n): _plab(sr, j, _on(D, _pg(D, 0, j, df=df(j))), 15, True, LP.CENTER)
    _xdone(ch)


def _xy_book(ch, D, sz=False):
    """กราฟกระจาย/ฟอง: ชีต A ชื่อจุด B แกนนอน C แกนตั้ง (D ขนาดวง) ป้ายจุด = ชื่อจากคอลัมน์ A"""
    n = D.n; f = _tops(D)
    _book(ch, [('', D.cats, None)] + [(nm, v, f[i]) for i, (nm, v) in enumerate(D.ser)], _notes(D))
    e = ch.plots[0].series[0]._element
    _ref(e, 1, n, 'c:xVal'); _ref(e, 2, n, 'c:yVal'); _tref(e, 2)
    if sz: _ref(e, 3, n, 'c:bubbleSize')


def _xy_axes(ch, D):
    S = D.S
    for ax, nm in ((ch.category_axis, D.ser[0][0]), (ch.value_axis, D.ser[1][0])):
        _vgrid(ax, S); ax.format.line.color.rgb = rgb(S['grid'])
        if nm:
            ax.has_title = True; ax.axis_title.text_frame.text = nm
            r = ax.axis_title.text_frame.paragraphs[0].runs[0]; r.font.size = Pt(12); r.font.color.rgb = rgb(S['soft'])


@_st('scatter', 'scatter_a', 'จุดไล่สี + เส้นแนวโน้ม', True)
def _x_scatter(s, D, box):
    S = D.S; xs, ys = D.ser[0][1], D.ser[1][1]
    ch = _xc(s, D, XT.XY_SCATTER, box, ser=[(D.ser[1][0], list(zip(xs, ys)), _tops(D)[1])], xy='xy'); sr = ch.plots[0].series[0]
    _xy_book(ch, D); sr.format.line.fill.background()
    sr.marker.style = XL_MARKER_STYLE.CIRCLE; sr.marker.size = 15; _gf(sr.marker.format.fill, D.pri, 90, path=True); sr.marker.format.line.color.rgb = rgb(D.pri[0][1]); sr.marker.format.line.width = Pt(1.5)   # ขอบสีเดียว: ตัวพรีวิวที่ไม่วาดจุดไล่สียังเห็นจุด
    m = ys.index(max(ys))
    for j in range(D.n):
        if f'0.{j}' in D.pc or j == m:
            mk = sr.points[j].marker; mk.style = XL_MARKER_STYLE.CIRCLE; mk.size = 17; st_ = _pg(D, 0, j, j == m); _gf(mk.format.fill, st_, 90, path=True); mk.format.line.color.rgb = rgb(st_[0][1])
    tl = etree.fromstring(f'<c:trendline xmlns:c="http://schemas.openxmlformats.org/drawingml/2006/chart" xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main">'
                          f'<c:spPr><a:ln w="31750"><a:solidFill><a:srgbClr val="{_ink(D, D.acc[0][1])}"/></a:solidFill><a:prstDash val="dash"/></a:ln></c:spPr>'
                          f'<c:trendlineType val="linear"/><c:dispRSqr val="0"/><c:dispEq val="0"/></c:trendline>')
    sr._element.find(qn('c:xVal')).addprevious(tl)
    _rlab(sr, 0, D.cats, S['soft'], 11, LP.ABOVE); _xy_axes(ch, D); _xdone(ch)


@_st('bubble', 'bubble_a', 'ฟองไล่สีแบบเรเดียล', True)
def _x_bubble(s, D, box):
    S = D.S; xs, ys, zs = (v for _, v in D.ser)
    ch = _xc(s, D, XT.BUBBLE, box, ser=[(D.ser[1][0], list(zip(xs, ys, zs)), _tops(D)[1])], xy='bub'); pl = ch.plots[0]; sr = pl.series[0]
    _xy_book(ch, D, True); pl.bubble_scale = 70
    _gf(sr.format.fill, D.pri, 90, (0.92, 0.92), path=True); sr.format.line.color.rgb = rgb(S['surf'])
    m = zs.index(max(zs))
    for j in range(D.n):
        if f'0.{j}' in D.pc or j == m:
            pt = sr.points[j]; _gf(pt.format.fill, _pg(D, 0, j, j == m), 90, (0.92, 0.92), path=True); pt.format.line.color.rgb = rgb(S['surf'])
    _rlab(sr, 0, D.cats, S['text'], 12, None, True); _xy_axes(ch, D); _xdone(ch)


@_st('radar', 'radar_a', 'พื้นไล่สีโปร่ง + เส้นประ', True)
def _x_radar(s, D, box):
    S = D.S; x, y, w, h = box
    ch = _xc(s, D, XT.RADAR_FILLED, box, D.cats, D.ser, _tops(D)); pl = ch.plots[0]
    for i, sr in enumerate(pl.series):
        st = _pg(D, i, -1)
        if i == 0: _gf(sr.format.fill, st, 90, (0.6, 0.2)); sr.format.line.color.rgb = rgb(st[0][1]); sr.format.line.width = Pt(3.5)
        else:
            sr.format.fill.background(); sr.format.line.color.rgb = rgb(_ink(D, _samp(D.acc, (i - 1) / 2))); sr.format.line.width = Pt(3)
            from pptx.enum.dml import MSO_LINE_DASH_STYLE
            sr.format.line.dash_style = MSO_LINE_DASH_STYLE.DASH
    va = ch.value_axis; _vgrid(va, S); top = max(v for _, vs in D.ser for v in vs) or 1
    va.major_unit = _nice(top / 5); va.minimum_scale = 0
    ca = ch.category_axis; _grid(ca, S['grid']); ca.tick_labels.font.size = Pt(14); ca.tick_labels.font.color.rgb = rgb(S['text'])
    if D.k > 1: _legend(ch, S, LG.BOTTOM, 14)
    wf = h * 0.8 / w; _manual(ch, round(0.5 - wf / 2, 3), 0.05, round(wf, 3), 0.8); _xdone(ch)


def _wf(v):
    """น้ำตก: แถวแรก = ยอดตั้งต้น แถวสุดท้าย = ยอดรวมเมื่อเท่ากับผลรวมสะสม คืน (เป็นยอดรวม, ระดับปลาย, ฐาน, ความยาวแท่ง)"""
    n = len(v); tot = [j == 0 for j in range(n)]
    if n >= 3 and abs(v[-1] - sum(v[:-1])) <= 1e-6 * max(1, abs(v[-1])): tot[-1] = True
    lev, bse, bar = [], [], []
    for j, x in enumerate(v):
        e = x if tot[j] else lev[-1] + x; lev.append(e)
        bse.append(0 if tot[j] else min(lev[-2], e)); bar.append(x if tot[j] else abs(x))
    return tot, lev, bse, bar


@_st('waterfall', 'waterfall_a', 'แท่งลอย', True)
def _x_waterfall(s, D, box):
    """แท่งซ้อนซ่อนฐาน: ชีต B = ค่าที่ลูกค้าใส่ (มีเครื่องหมาย) C ฐาน D ความยาว E ระดับสะสม เป็นสูตรจาก B"""
    v = D.ser[0][1]; n = D.n; f = _tops(D)[0]; tot, lev, bse, bar = _wf(v)
    ch = _xc(s, D, XT.COLUMN_STACKED, box, D.cats, [('', bse), (D.ser[0][0], bar)], [f, f]); pl = ch.plots[0]; pl.gap_width = 50; pl.overlap = 100
    E = [(f'=B{j + 2}' if tot[j] else f'=E{j + 1}+B{j + 2}', lev[j]) for j in range(n)]
    C = [(f'=0' if tot[j] else f'=MIN(E{j + 1},E{j + 2})', bse[j]) for j in range(n)]
    Dc = [(f'=B{j + 2}' if tot[j] else f'=ABS(B{j + 2})', bar[j]) for j in range(n)]
    _book(ch, [('', D.cats, None), (D.ser[0][0], v, f), ('', C, f), ('', Dc, f), ('', E, f)], _notes(D))
    b, sr = pl.series
    for e, col in ((b._element, 2), (sr._element, 3)): _ref(e, col, n); _tref(e, col); _ref(e, 0, n, 'c:cat')
    b.format.fill.background(); b.format.line.fill.background(); _axes(ch, D.S)
    df = lambda j: D.pri if j < 0 or tot[j] else (D.acc if v[j] < 0 else _lite(D.pri, 0.45, D.S))
    _sfill(sr, D, 0, 90, df=df)
    _rlab(sr, 1, [_fv(D, 0, j) if tot[j] else _sgn(D, 0, j) for j in range(n)], D.S['text'], 14, LP.INSIDE_END, True)
    for j in range(n): _plab(sr, j, _on(D, _pg(D, 0, j, df=df(j))), 14, True, LP.INSIDE_END)
    _xdone(ch)


@_st('combo', 'combo_a', 'แท่งไล่สี + เส้นแกนขวา', True)
def _x_combo(s, D, box):
    S = D.S; ch = _xc(s, D, XT.COLUMN_CLUSTERED, box, D.cats, D.ser, _tops(D)); pl = ch.plots[0]; pl.gap_width = 70
    lp = _to_line(ch, 1); sr, ln_ = pl.series[0], lp.series[0]
    _sfill(sr, D, 0, 90, df=lambda j: D.pri); _lab(sr, _on(D, D.pri), 13, True, LP.INSIDE_END)
    lc = _ink(D, D.acc[0][1]); _gf(ln_.format.line.fill, D.acc, 0); ln_.format.line.width = Pt(4); ln_.smooth = False
    ln_.marker.style = XL_MARKER_STYLE.CIRCLE; ln_.marker.size = 10; ln_.marker.format.fill.solid(); ln_.marker.format.fill.fore_color.rgb = rgb(S['surf']); ln_.marker.format.line.color.rgb = rgb(lc)
    _lab(ln_, lc, 13, True, LP.ABOVE)
    _axes(ch, S); _vgrid(ch.value_axis, S)
    for ax in ch._chartSpace.findall('.//' + qn('c:valAx'))[1:]:
        ax.find(qn('c:delete')).set('val', '0')
    _legend(ch, S, LG.TOP); _xdone(ch)


@_st('pareto', 'pareto_a', 'แท่งเรียงมากไปน้อย + เส้นสะสม', True)
def _x_pareto(s, D, box):
    """เรียงมากไปน้อยในชีต (B) + % สะสมเป็นสูตร (C) + เส้น 80% (D) บนแกนรอง"""
    S = D.S; v0 = D.ser[0][1]; od = sorted(range(D.n), key=lambda j: -v0[j]); cats = [D.cats[j] for j in od]; v = [v0[j] for j in od]
    n = D.n; tot = sum(v); cum = [sum(v[:j + 1]) / tot for j in range(n)]; f = _tops(D)[0]
    ch = _xc(s, D, XT.COLUMN_CLUSTERED, box, cats, [(D.ser[0][0], v), ('', cum), ('80%', [0.8] * n)], [f, '0%', '0%']); pl = ch.plots[0]; pl.gap_width = 40
    _book(ch, [('', cats, None), (D.ser[0][0], v, f), ('', [(f'=SUM($B$2:B{j + 2})/SUM($B$2:$B${n + 1})', cum[j]) for j in range(n)], '0%'), ('80%', [0.8] * n, '0%')], _notes(D, od))
    lp = _to_line(ch, 1); sr = pl.series[0]; c1, c2 = lp.series
    for e, col in ((sr._element, 1), (c1._element, 2), (c2._element, 3)): _ref(e, col, n); _tref(e, col); _ref(e, 0, n, 'c:cat')
    few = [j == 0 or cum[j - 1] < 0.8 for j in range(n)]
    pcs = {f'0.{od.index(int(k.split(".")[1]))}': st for k, st in D.pc.items() if k.count('.') == 1}   # สีรายชิ้นตามแถวของลูกค้า ไม่ใช่ลำดับหลังเรียง
    D2 = types.SimpleNamespace(**{**vars(D), 'pc': pcs})
    _sfill(sr, D2, 0, 90, df=lambda j: D.pri if j < 0 or few[j] else _lite(D.pri, 0.55, S)); _lab(sr, S['text'], 13, True, LP.OUTSIDE_END)
    lc = _ink(D, D.acc[0][1]); c1.format.line.color.rgb = rgb(lc); c1.format.line.width = Pt(3.5); c1.smooth = False
    c1.marker.style = XL_MARKER_STYLE.CIRCLE; c1.marker.size = 9; c1.marker.format.fill.solid(); c1.marker.format.fill.fore_color.rgb = rgb(S['surf']); c1.marker.format.line.color.rgb = rgb(lc)
    _lab(c1, lc, 12, True, LP.ABOVE)
    from pptx.enum.dml import MSO_LINE_DASH_STYLE
    c2.format.line.color.rgb = rgb(S['soft']); c2.format.line.width = Pt(1.5); c2.format.line.dash_style = MSO_LINE_DASH_STYLE.DASH; c2.marker.style = XL_MARKER_STYLE.NONE; c2.smooth = False
    _axes(ch, S)
    v2 = ch._chartSpace.findall('.//' + qn('c:valAx'))[1]; v2.find(qn('c:delete')).set('val', '0')
    sc = v2.find(qn('c:scaling'))
    for tag, val in (('c:max', '1'), ('c:min', '0')):
        e = sc.find(qn(tag))
        if e is None: e = etree.SubElement(sc, qn(tag))
        e.set('val', val)
    _xdone(ch)


@_st('range', 'range_a', 'แท่งลอยต่ำสุดถึงสูงสุด', True)
def _x_range(s, D, box):
    """ฐานซ่อน = ต่ำสุด (B) แท่ง = สูงสุด - ต่ำสุด เป็นสูตร (D) ป้ายบนแท่งอ่านค่าสูงสุดจากเซลล์ C"""
    S = D.S; lo, hi = D.ser[0][1], D.ser[1][1]; n = D.n; f = _tops(D)
    ch = _xc(s, D, XT.COLUMN_STACKED, box, D.cats, [D.ser[0], ('', [b - a for a, b in zip(lo, hi)])], [f[0], f[1]]); pl = ch.plots[0]; pl.gap_width = 70; pl.overlap = 100
    _book(ch, [('', D.cats, None), (D.ser[0][0], lo, f[0]), (D.ser[1][0], hi, f[1]), ('', [(f'=C{j + 2}-B{j + 2}', hi[j] - lo[j]) for j in range(n)], f[1])], _notes(D))
    b, sr = pl.series
    for e, col in ((b._element, 1), (sr._element, 3)): _ref(e, col, n); _tref(e, col); _ref(e, 0, n, 'c:cat')
    b.format.fill.background(); b.format.line.fill.background(); _lab(b, S['soft'], 13, True, LP.INSIDE_END)
    m = hi.index(max(hi)); D2 = types.SimpleNamespace(**{**vars(D), 'pc': {k.replace('1.', '0.', 1) if k.startswith('1.') else k: v for k, v in D.pc.items()}})
    _sfill(sr, D2, 0, 90, m, df=lambda j: D.pri)
    _rlab(sr, 2, [_fv(D, 1, j) for j in range(n)], _on(D, D.pri), 13, LP.INSIDE_END, True)
    _plab(sr, m, _on(D, _pg(D2, 0, m, True)), 13, True, LP.INSIDE_END)
    _axes(ch, S); _xdone(ch)


# ══ แบบ "อินโฟกราฟิก" (24 แบบ) รูปทรงบนสไลด์ ตัวเลขทุกตัวมาจากตารางเดียวกัน ═══════════════════════
def _vcols(box, n, lab=0.5, top=0.2):
    x, y, w, h = box; bot = y + h - lab; return x, bot, y + top, bot - (y + top), w / n


def _clab(s, D, x, y, w, j, hi=False):
    _T(s, D, f'c.{j}', x, y, w, 0.42, D.cats[j], 13, D.S['text'] if hi else D.S['soft'], 'md' if hi else 'rg', 'c', 't')


@_st('column', 'col_capsule', 'แคปซูลในราง')
def _i_capsule(s, D, box):
    v = D.ser[0][1]; m = _imax(D); S = D.S; x, bot, top, H, slot = _vcols(box, D.n); bw = min(slot * 0.56, 1.1); vm = max(v) or 1
    for j, vv in enumerate(v):
        bx = x + slot * j + (slot - bw) / 2; hh = max(bw, H * vv / vm); st = _pg(D, 0, j, j == m)
        _S(s, f'd.trk.{j}', 'round', bx, top, bw, H, _trk(S), adj=0.5)
        _G(s, f'p.0.{j}', 'round', bx, bot - hh, bw, hh, st, 90, adj=0.5)
        dm = bw * 0.8; t = _fv(D, 0, j)
        _S(s, f'd.dot.{j}', 'oval', bx + (bw - dm) / 2, bot - hh + (bw - dm) / 2, dm, dm, S['surf'])
        _T(s, D, f'v.0.{j}', bx - 0.15, bot - hh + (bw - dm) / 2, bw + 0.3, dm, t, _fz(t, dm * 0.92, 20), S['text'], 'bd')
        _clab(s, D, x + slot * j, bot + 0.08, slot, j, j == m)


@_st('column', 'col_cylinder', 'ทรงกระบอก')
def _i_cylinder(s, D, box):
    v = D.ser[0][1]; m = _imax(D); S = D.S; x, bot, top, H, slot = _vcols(box, D.n, 0.6, 0.6); bw = min(slot * 0.6, 1.2); e = bw * 0.3; vm = max(v) or 1
    for j, vv in enumerate(v):
        bx = x + slot * j + (slot - bw) / 2; hh = max(0.05, H * vv / vm); st = _pg(D, 0, j, j == m)
        _S(s, f'd.sh.{j}', 'oval', bx - bw * 0.12, bot - e * 0.15, bw * 1.24, e * 0.9, S['text'], a=0.07)
        _G(s, f'p.0.{j}', 'oval', bx, bot - e / 2, bw, e, st, 0)
        _G(s, f'p.0.{j}', 'rect', bx, bot - hh, bw, hh, st, 0)
        _G(s, f'p.0.{j}', 'oval', bx, bot - hh - e / 2, bw, e, _lite(st, 0.45, S), 0)
        t = _fv(D, 0, j); _T(s, D, f'v.0.{j}', bx - 0.3, bot - hh - e / 2 - 0.48, bw + 0.6, 0.44, t, _fz(t, bw + 0.5, 22), S['text'], 'bd')
        _clab(s, D, x + slot * j, bot + e / 2 + 0.06, slot, j, j == m)
        if j and v[j - 1] and slot - bw >= 0.62:
            pc = round((vv / v[j - 1] - 1) * 100); gx = x + slot * j
            _S(s, f'd.pill.{j}', 'round', gx - 0.3, bot - 0.55, 0.6, 0.3, S['surf'], adj=0.5, line=S['grid'])
            _T(s, D, f'x.chg.{j}', gx - 0.35, bot - 0.55, 0.7, 0.3, f'{pc:+d}%', 10, S['text'] if pc >= 0 else S['soft'], 'md')


@_st('stacked_column', 'scol_pills', 'แคปซูลแยกชั้น')
def _i_scol_pills(s, D, box):
    S = D.S; x, bot, top, H, slot = _vcols(box, D.n, 0.5, 1.05); bw = min(slot * 0.55, 1.05); g = 0.05
    tots = [sum(v[j] for _, v in D.ser) for j in range(D.n)]; vm = max(tots) or 1
    _leg(s, D, x, box[1], box[2], [_pg(D, i, -1) for i in range(D.k)])
    for j in range(D.n):
        bx = x + slot * j + (slot - bw) / 2; cy = bot
        for i, (_, v) in enumerate(D.ser):
            hh = max(0.03, H * v[j] / vm - g); cy -= hh; st = _pg(D, i, j)
            _G(s, f'p.{i}.{j}', 'round', bx, cy, bw, hh, st, 90, adj=min(0.5, 0.12 / max(min(bw, hh), 0.01)))
            if hh >= 0.3: t = _fv(D, i, j); _T(s, D, f'v.{i}.{j}', bx, cy, bw, hh, t, _fz(t, bw * 0.9, 16), _on(D, st), 'md')
            cy -= g
        dm = 0.6; t = _fv(D, 0, j, tots[j])
        _S(s, f'd.tot.{j}', 'oval', bx + bw / 2 - dm / 2, cy - dm - 0.02, dm, dm, S['surf'], line=S['grid'], lw=1.5)
        _T(s, D, f'x.tot.{j}', bx + bw / 2 - 0.5, cy - dm - 0.02, 1.0, dm, t, _fz(t, dm * 0.95, 15), S['text'], 'bd')
        _clab(s, D, x + slot * j, bot + 0.08, slot, j)


def _rows(box, n, lab, right=0.0, top=0.0):
    x, y, w, h = box; return x + lab, x + w - right, (h - top) / n, y + top


@_st('bar', 'bar_arrow', 'ลูกศรริบบิ้น')
def _i_arrow(s, D, box):
    v = D.ser[0][1]; m = _imax(D); S = D.S; lab = min(1.9, box[2] * 0.28); x0, x1, rs, y0 = _rows(box, D.n, lab)
    rh = min(0.72, rs * 0.68); W = x1 - x0; vm = max(v) or 1; tip = rh * 0.5; notch = rh * 0.3
    for j, vv in enumerate(v):
        yy = y0 + rs * j + (rs - rh) / 2; L = max(tip + notch + 0.15, W * vv / vm)
        c = _samp(D.pri, 1 - j / max(1, D.n - 1)); st = _pg(D, 0, j, j == m, [(0.0, mix(c, S['surf'], 0.4)), (1.0, c)])
        _F(s, f'p.0.{j}', [(x0, yy), (x0 + L - tip, yy), (x0 + L, yy + rh / 2), (x0 + L - tip, yy + rh), (x0, yy + rh), (x0 + notch, yy + rh / 2)], st, 0)
        t = _fv(D, 0, j); sz = min(20, rh * 72 * 0.42); inside = len(t) * sz * 0.58 / 72 < L - tip - notch - 0.1
        if inside: _T(s, D, f'v.0.{j}', x0 + notch, yy, L - tip - notch - 0.06, rh, t, sz, _on(D, st), 'bd', 'r')
        else: _T(s, D, f'v.0.{j}', x0 + L + 0.08, yy, 1.4, rh, t, sz, S['text'], 'bd', 'l')
        _T(s, D, f'c.{j}', box[0], yy, lab - 0.15, rh, D.cats[j], 13, S['text'], 'md', 'r')


@_st('bar', 'bar_dots', 'จุดนับ')
def _i_dots(s, D, box):
    v = D.ser[0][1]; m = _imax(D); S = D.S; lab = min(1.6, box[2] * 0.24); x0, x1, rs, y0 = _rows(box, D.n, lab, 0.95)
    vm = max(v) or 1; unit = _nice(vm / 16); cols = max(1, math.ceil(vm / unit - 1e-9)); step = (x1 - x0) / cols; dm = min(0.3, step * 0.78, rs * 0.7)
    for j, vv in enumerate(v):
        cy = y0 + rs * (j + 0.5); k = round(vv / unit); st = _pg(D, 0, j, j == m)
        for q in range(cols):
            _S(s, f'p.0.{j}' if q < k else f'd.trk.{j}', 'oval', x0 + step * q + (step - dm) / 2, cy - dm / 2, dm, dm, _samp(st, q / max(1, cols - 1)) if q < k else _trk(S))
        _T(s, D, f'v.0.{j}', x1 + 0.08, cy - 0.25, 0.9, 0.5, _fv(D, 0, j), 18, S['text'], 'bd', 'l')
        _T(s, D, f'c.{j}', box[0], cy - 0.25, lab - 0.15, 0.5, D.cats[j], 13, S['text'], 'md', 'r')


@_st('stacked_bar', 'sbar_track', 'รางร้อยเปอร์เซ็นต์')
def _i_track(s, D, box):
    S = D.S; lab = min(1.6, box[2] * 0.22); x0, x1, rs, y0 = _rows(box, D.n, lab, 1.0, 0.5); W = x1 - x0; rh = min(0.56, rs * 0.6); g = 0.05
    _leg(s, D, x0, box[1], W, [_pg(D, i, -1) for i in range(D.k)])
    for j in range(D.n):
        yy = y0 + rs * j + (rs - rh) / 2; tot = sum(v[j] for _, v in D.ser) or 1; a = 0
        for i, (_, v) in enumerate(D.ser):
            pc = v[j] / tot; sx = x0 + W * a + (g if i else 0); sw = max(0.02, W * pc - (g if i else 0)); st = _pg(D, i, j)
            _G(s, f'p.{i}.{j}', 'round', sx, yy, sw, rh, st, 0, adj=0.5)
            t = f'{round(pc * 100)}%'
            if sw > len(t) * 0.11 + 0.1: _T(s, D, f'x.pct.{i}.{j}', sx, yy, sw, rh, t, min(15, rh * 72 * 0.45), _on(D, st), 'md')
            a += pc
        _T(s, D, f'x.tot.{j}', x1 + 0.1, yy, 0.95, rh, _fv(D, 0, j, sum(v[j] for _, v in D.ser)), 18, S['text'], 'bd', 'l')
        _T(s, D, f'c.{j}', box[0], yy, lab - 0.15, rh, D.cats[j], 13, S['text'], 'md', 'r')


def _callout(s, D, j, cx, by, cw, fill_st, box):
    """ป้ายเหตุการณ์ของลูกค้า lab['e.j'] (+ 'e.js' บรรทัดสอง) เหนือจุด j ว่าง = ไม่วาด"""
    a, _, b0 = str(D.lab.get(f'e.{j}', '')).partition('\n'); b = D.lab.get(f'e.{j}s', '') or b0   # หมายเหตุสองบรรทัด = หัว + บรรทัดรอง
    if not (a or b): return
    S = D.S; chh = 0.62 if b else 0.42; bx = min(max(cx - cw / 2, box[0]), box[0] + box[2] - cw); y = by - chh - 0.12
    if fill_st: _G(s, f'lab.e.{j}', 'round', bx, y, cw, chh, fill_st, 90, adj=0.2); fc = _on(D, fill_st)
    else: _S(s, f'lab.e.{j}', 'round', bx, y, cw, chh, S['surf'], adj=0.2, line=S['grid'], lw=1.25); fc = S['text']
    _S(s, f'd.tip.{j}', 'tri', cx - 0.07, by - 0.13, 0.14, 0.1, (fill_st or [(0, S['surf'])])[-1][1], line=None).rotation = 180
    _T(s, D, f'lab.e.{j}', bx + 0.06, y + 0.03, cw - 0.12, 0.34, a, 12, fc, 'bd')
    _T(s, D, f'lab.e.{j}s', bx + 0.06, y + 0.33, cw - 0.12, 0.26, b, 10, fc, 'rg')


@_st('line', 'line_callout', 'เส้นพร้อมป้ายเหตุการณ์')
def _i_line_callout(s, D, box):
    S = D.S; v = D.ser[0][1]; n = D.n; x, y, w, h = box; bot = y + h - 0.45; top = y + 1.2; H = bot - top; vm = max(v) or 1
    step = (w - 0.6) / max(1, n - 1); pts = [(x + 0.3 + step * j, bot - H * vv / vm) for j, vv in enumerate(v)]
    ln(s, x, bot, x + w, bot, S['grid'], 1.5)
    cw_ = min(0.44, step * 0.5)
    for j, (px, py) in enumerate(pts):
        _G(s, f'p.0.{j}', 'round', px - cw_ / 2, py, cw_, bot - py, _lite(_pg(D, 0, j), 0.62, S), 90, adj=0.25)
    _F(s, 'd.line', pts, close=False, line=D.pri, lw=3.5)
    for j, (px, py) in enumerate(pts):
        _S(s, f'p.0.{j}', 'oval', px - 0.08, py - 0.08, 0.16, 0.16, S['surf'], line=_pg(D, 0, j)[0][1], lw=2.25)
        _T(s, D, f'v.0.{j}', px - 0.5, py - 0.4, 1.0, 0.3, _fv(D, 0, j), 12, _ink(D, D.pri[0][1]), 'md')
        _T(s, D, f'c.{j}', px - step / 2, bot + 0.06, step, 0.36, D.cats[j], 11, S['soft'], 'rg', 'c', 't')
        _callout(s, D, j, px, py - 0.38, min(1.9, max(step * 1.6, 1.2)), _pg(D, 0, j) if j == n - 1 else None, box)


@_st('area', 'area_waves', 'คลื่นซ้อน')
def _i_waves(s, D, box):
    S = D.S; x, y, w, h = box; n = D.n; pan = 2.0 if D.k >= 2 else 0; W = w - pan - (1.1 if D.k > 1 else 0.2) - (0.15 if pan else 0)
    bot = y + h - 0.45; top = y + 0.2; H = bot - top; vm = max(v for _, vs in D.ser for v in vs) or 1
    ln(s, x, bot, x + W, bot, S['grid'], 1.5)
    for i, (nm, v) in enumerate(D.ser):
        st = D.pc.get(f'{i}') or (D.pri if D.k == 1 else _seg(D.pri, (D.k - 1 - i) / D.k, (D.k - 0.15 - i) / D.k))
        pts = [(x + W * j / max(1, n - 1), bot - H * vv / vm) for j, vv in enumerate(v)]; sm = [(a, min(b, bot)) for a, b in _smooth(pts)]
        _F(s, f'p.{i}', sm + [(x + W, bot), (x, bot)], st, 90, alpha=(0.85, 0.12))
        _F(s, f'p.{i}', sm, close=False, line=st[0][1], lw=3)
        _S(s, f'p.{i}', 'oval', pts[-1][0] - 0.09, pts[-1][1] - 0.09, 0.18, 0.18, S['surf'], line=st[0][1], lw=2.5)
        if D.k > 1: _T(s, D, f's.{i}', pts[-1][0] + 0.15, pts[-1][1] - 0.2, 1.0, 0.4, nm, 12, _ink(D, st[0][1]), 'bd', 'l')
    for j in range(n): _T(s, D, f'c.{j}', x + W * j / max(1, n - 1) - 0.6, bot + 0.06, 1.2, 0.36, D.cats[j], 11, S['soft'], 'rg', 'c', 't')
    if pan:
        a, b = D.ser[0][1][-1], D.ser[-1][1][-1]; px = x + w - pan
        _G(s, 'd.panel', 'round', px, top, pan, H, D.pri, 90, adj=0.1); fc = _on(D, D.pri)
        if a: _T(s, D, 'x.big', px + 0.15, top + 0.3, pan - 0.3, 0.9, f'{(b / a - 1) * 100:+.0f}%', 36, fc, 'bd')
        _T(s, D, 'lab.big', px + 0.15, top + 1.2, pan - 0.3, 0.9, D.lab.get('big', ''), 12, fc, 'rg', 'c', 't')
        _T(s, D, 'x.from', px + 0.15, top + H - 0.9, pan - 0.3, 0.7, f'{_fv(D, 0, n - 1)} → {_fv(D, D.k - 1, n - 1)}', 15, fc, 'bd')


@_st('pie', 'pie_exploded', 'พายแยกชิ้น ตัวเลขใหญ่')
def _i_pie_exploded(s, D, box):
    S = D.S; x, y, w, h = box; R = min(w * 0.26, h * 0.32); cx, cy = x + w / 2, y + h / 2; v = D.ser[0][1]; tot = sum(v); df = _rank_df(D); m = _imax(D); a = 0
    for j, vv in enumerate(v):
        sw = vv / tot * 360; mid = a + sw / 2; big = j == m; rr = R + (0.12 if big else 0); ox, oy = _polar(0, 0, 0.1 + (0.08 if big else 0), mid)
        st = _pg(D, 0, j, df=df(j))
        _G(s, f'p.0.{j}', 'pie', cx + ox - rr, cy + oy - rr, 2 * rr, 2 * rr, st, 45, adj=_arcadj(a + 0.4, a + sw - 0.4))
        lx, ly = _polar(cx, cy, rr + 0.85, mid)
        _T(s, D, f'v.0.{j}', lx - 0.9, ly - 0.42, 1.8, 0.5, _pct(D, j), 26 if big else 20, _ink(D, st[0][1]), 'bd')
        _T(s, D, f'c.{j}', lx - 0.9, ly + 0.06, 1.8, 0.36, D.cats[j], 12, S['text'], 'md', 'c', 't')
        a += sw


@_st('donut', 'donut_half', 'ครึ่งโดนัท ตัวเลขใหญ่')
def _i_donut_half(s, D, box):
    S = D.S; x, y, w, h = box; v = D.ser[0][1]; tot = sum(v); df = _rank_df(D); m = _imax(D)
    R = max(0.8, min(w * 0.36, (h - 0.5) * 0.62, w / 2 - 1.5)); cx, cy = x + w / 2, y + h - 0.35; th = R * 0.55; a = -90   # ใบ 028 กรอบแคบ: ป้ายข้าง (กว้าง 1.7) ไม่ยื่นออกนอกกรอบ
    for j, vv in enumerate(v):
        sw = vv / tot * 180; rr = R + (0.18 if j == m else 0); st = _pg(D, 0, j, df=df(j))
        _G(s, f'p.0.{j}', 'arc', cx - rr, cy - rr, 2 * rr, 2 * rr, st, 90, adj=_arcadj(a + 0.4, a + sw - 0.4, min(0.5, (th + rr - R) / (2 * rr))))
        lx, ly = _polar(cx, cy, rr + 0.6, a + sw / 2)
        _T(s, D, f'v.0.{j}', lx - 0.85, ly - 0.42, 1.7, 0.5, _pct(D, j), 24 if j == m else 19, _ink(D, st[0][1]), 'bd')
        _T(s, D, f'c.{j}', lx - 0.85, ly + 0.05, 1.7, 0.34, D.cats[j], 12, S['text'], 'md', 'c', 't')
        a += sw
    _T(s, D, 'lab.big', cx - (R - th) * 0.9, cy - 0.7, 2 * (R - th) * 0.9, 0.6, D.lab.get('big', ''), 14, S['text'], 'bd', 'c', 'b')


@_st('donut', 'donut_rings', 'วงแหวนซ้อน')
def _i_rings(s, D, box):
    S = D.S; x, y, w, h = box; v = D.ser[0][1]; tot = sum(v); df = _rank_df(D)
    R = min(w * 0.27, h * 0.48); cx, cy = x + R + 0.1, y + h / 2; sw = min(0.3, R * 0.8 / D.n * 0.72); gap = sw * 0.35
    lx = cx + R + 0.4; rs = h / D.n
    for j, vv in enumerate(v):
        r = R - j * (sw + gap); st = _pg(D, 0, j, df=df(j)); fr = min(0.9995, vv / tot)
        if r <= sw: break
        _S(s, f'd.trk.{j}', 'donut', cx - r, cy - r, 2 * r, 2 * r, _trk(S), adj=sw / (2 * r))
        _G(s, f'p.0.{j}', 'arc', cx - r, cy - r, 2 * r, 2 * r, st, 45, adj=_arcadj(0, fr * 360, sw / (2 * r)))
        yy = y + rs * j
        _G(s, f'p.0.{j}', 'round', lx, yy + rs * 0.2, 0.08, rs * 0.6, st, 90, adj=0.5)
        _T(s, D, f'v.0.{j}', lx + 0.18, yy, 1.3, rs, _pct(D, j), min(28, rs * 72 * 0.45), _ink(D, st[0][1]), 'bd', 'l')
        _T(s, D, f'c.{j}', lx + 1.5, yy, x + w - lx - 1.5, rs, D.cats[j], 13, S['text'], 'md', 'l')


def _fun_w(v): mx = max(v); return [math.sqrt(x / mx) for x in v]   # ความกว้างที่วาด = รากที่สองของค่า ขั้นท้ายยังอ่านออก (ตามแกลเลอรี)


@_st('funnel', 'funnel_blocks', 'บล็อกอัตราแปลง')
def _i_funnel_blocks(s, D, box):
    S = D.S; x, y, w, h = box; v = D.ser[0][1]; n = D.n; cw = w / n; bw = cw * 0.64; bot = y + h; Hm = h - 1.15; hs = [Hm * k for k in _fun_w(v)]
    for j in range(n):
        bx = x + cw * j; st = _pg(D, 0, j)
        _T(s, D, f'c.{j}', bx, y, cw - 0.05, 0.4, D.cats[j], 13, S['text'], 'bd', 'l', 't')
        _T(s, D, f'v.0.{j}', bx, y + 0.38, cw - 0.05, 0.4, _fv(D, 0, j), 18, S['text'], 'bd', 'l', 't')
        _G(s, f'p.0.{j}', 'round', bx, bot - hs[j], bw, hs[j], st, 90, adj=min(0.5, 0.08 / max(0.01, min(bw, hs[j]))))
        if j < n - 1:
            tx = bx + bw + 0.03; tw = cw - bw - 0.06
            _F(s, f'd.ramp.{j}', [(tx, bot - hs[j]), (tx + tw, bot - hs[j + 1]), (tx + tw, bot), (tx, bot)], _lite(st, 0.55, S), 0)
            _T(s, D, f'x.conv.{j}', tx - 0.1, bot - 0.42, tw + 0.2, 0.36, f'{round(v[j + 1] / v[j] * 100)}%', 11, _on(D, _lite(st, 0.55, S), 0.9), 'bd')


@_st('funnel', 'funnel_layers', 'กรวยชั้นซ้อน')
def _i_funnel_layers(s, D, box):
    S = D.S; x, y, w, h = box; v = D.ser[0][1]; n = D.n; fw = w * 0.56; cx = x + fw / 2; g = 0.07; lh = (h - g * (n - 1)) / n
    ws = [fw * (0.3 + 0.7 * k) for k in _fun_w(v)] + [fw * (0.3 + 0.7 * _fun_w(v)[-1]) * 0.7]
    for j in range(n):
        yy = y + j * (lh + g); w0, w1 = ws[j], ws[j + 1]; st = _pg(D, 0, j, j == n - 1, _seg(D.pri, j / n, (j + 1) / n))
        _F(s, f'p.0.{j}', [(cx - w0 / 2, yy), (cx + w0 / 2, yy), (cx + w1 / 2, yy + lh), (cx - w1 / 2, yy + lh)], st, 0)
        _S(s, f'd.cap.{j}', 'oval', cx - w0 / 2, yy - 0.07, w0, 0.14, mix(st[-1][1], S['surf'], 0.35))
        _T(s, D, f'v.0.{j}', cx - w1 / 2, yy, w1, lh, _fv(D, 0, j), min(20, lh * 72 * 0.4), _on(D, st), 'bd')
        ly = yy + lh / 2; ln(s, cx + (w0 + w1) / 4 + 0.1, ly, x + fw + 0.3, ly, S['grid'], 1.25, True)
        _S(s, f'p.0.{j}', 'oval', x + fw + 0.26, ly - 0.05, 0.1, 0.1, st[0][1])
        _T(s, D, f'c.{j}', x + fw + 0.45, ly - 0.36, w - fw - 0.45, 0.38, D.cats[j], 14, S['text'], 'bd', 'l', 'b')
        if j: _T(s, D, f'x.conv.{j}', x + fw + 0.45, ly + 0.02, w - fw - 0.45, 0.32, f'{round(v[j] / v[j - 1] * 100)}%', 12, S['soft'], 'rg', 'l', 't')


def _xy_box(box, pad=0.4):
    x, y, w, h = box; return x + pad, y + 0.1, w - pad - 0.1, h - 0.5


@_st('scatter', 'scatter_b', 'แบ่ง 4 กลุ่ม + ป้ายชี้จุดเด่น')
def _i_quad(s, D, box):
    S = D.S; X0, Y0, W, H = _xy_box(box); xs, ys = D.ser[0][1], D.ser[1][1]; g = 0.05
    lo = lambda vs: min(vs) - (max(vs) - min(vs) or 1) * 0.08; hi = lambda vs: max(vs) + (max(vs) - min(vs) or 1) * 0.08
    ax, bx_, ay, by = lo(xs), hi(xs), lo(ys), hi(ys); mx, my = (ax + bx_) / 2, (ay + by) / 2
    X = lambda v: X0 + W * (v - ax) / (bx_ - ax); Y = lambda v: Y0 + H - H * (v - ay) / (by - ay); MX, MY = X(mx), Y(my)
    quad = {0: (MX + g, Y0, X0 + W - MX - g, MY - Y0 - g, _lite(D.pri, 0.86, S)), 1: (X0, Y0, MX - X0 - g, MY - Y0 - g, _lite(D.pri, 0.92, S)),
            2: (MX + g, MY + g, X0 + W - MX - g, Y0 + H - MY - g, _lite(D.acc, 0.86, S)), 3: (X0, MY + g, MX - X0 - g, Y0 + H - MY - g, [(0.0, _trk(S)), (1.0, _trk(S))])}
    for q, (qx, qy, qw, qh, st) in quad.items():
        _G(s, f'd.q.{q}', 'round', qx, qy, qw, qh, st, 90, adj=0.06)
        _T(s, D, f'lab.q.{q}', qx + 0.15, qy + (0.1 if q < 2 else qh - 0.5), qw - 0.3, 0.4, D.lab.get(f'q.{q}', ''), 16, S['text'], 'bd', 'r' if q in (0, 2) else 'l')
    qof = lambda j: (0 if xs[j] > mx else 1) if ys[j] > my else (2 if xs[j] > mx else 3)
    top = ys.index(max(ys))
    for j in range(D.n):
        q = qof(j); st = _pg(D, 0, j, q == 2, D.pri if q == 0 else _lite(D.pri, 0.35, S) if q == 1 else [(0.0, S['soft']), (1.0, S['soft'])])
        dm = 0.26 if q == 0 else 0.2
        _G(s, f'p.0.{j}', 'oval', X(xs[j]) - dm / 2, Y(ys[j]) - dm / 2, dm, dm, st, 90)
    px, py = X(xs[top]), Y(ys[top]); cw = 2.3; cx_ = px - cw - 0.2 if px - cw - 0.2 > X0 else px + 0.2
    _S(s, 'd.call', 'round', cx_, py - 0.36, cw, 0.72, S['surf'], adj=0.2, line=S['grid'])
    _T(s, D, f'c.{top}', cx_ + 0.1, py - 0.34, cw - 0.2, 0.36, D.cats[top], 14, _ink(D, D.pri[0][1]), 'bd', 'l')
    _T(s, D, f'v.1.{top}', cx_ + 0.1, py, cw - 0.2, 0.3, f'{_fv(D, 0, top)} · {_fv(D, 1, top)}', 11, S['soft'], 'rg', 'l')
    _T(s, D, 's.0', X0, Y0 + H + 0.08, W, 0.3, D.ser[0][0], 11, S['soft'], 'rg', 'r')
    _T(s, D, 's.1', box[0], Y0, 0.35, H, D.ser[1][0], 11, S['soft'], 'rg', 'c', 'm')


def _pack(rad, cx, cy, gap=0.08, it=400):
    P_ = [[cx + math.cos(i * 2.4) * 0.3 * i, cy + math.sin(i * 2.4) * 0.3 * i] for i in range(len(rad))]
    for _ in range(it):
        for p in P_: p[0] += (cx - p[0]) * 0.02; p[1] += (cy - p[1]) * 0.03
        for i in range(len(P_)):
            for j in range(i + 1, len(P_)):
                dx, dy = P_[j][0] - P_[i][0], P_[j][1] - P_[i][1]; dd = math.hypot(dx, dy) or 1e-3; mn = rad[i] + rad[j] + gap
                if dd < mn: k = (mn - dd) / dd / 2; P_[i][0] -= dx * k; P_[i][1] -= dy * k; P_[j][0] += dx * k; P_[j][1] += dy * k
    return P_


@_st('bubble', 'bubble_b', 'ฟองเกาะกลุ่ม + ลำดับด้านข้าง')
def _i_bubble_pack(s, D, box):
    S = D.S; x, y, w, h = box; z = D.ser[2][1]; tot = sum(z); lw = w * 0.5; m = _imax(D, 2)
    k = min(lw, h) * 0.3 / math.sqrt(max(z) / tot); rad = [k * math.sqrt(v / tot) for v in z]
    P_ = _pack(rad, x + lw / 2, y + h / 2)
    xs = [p[0] for p in P_]; ys = [p[1] for p in P_]
    sc = min(1, lw / ((max(a + r for a, r in zip(xs, rad)) - min(a - r for a, r in zip(xs, rad))) or 1), h / ((max(b + r for b, r in zip(ys, rad)) - min(b - r for b, r in zip(ys, rad))) or 1))
    cx0 = (max(a + r for a, r in zip(xs, rad)) + min(a - r for a, r in zip(xs, rad))) / 2; cy0 = (max(b + r for b, r in zip(ys, rad)) + min(b - r for b, r in zip(ys, rad))) / 2
    order = sorted(range(D.n), key=lambda j: -z[j])
    for j in range(D.n):
        r = rad[j] * sc; px = x + lw / 2 + (xs[j] - cx0) * sc; py = y + h / 2 + (ys[j] - cy0) * sc; q = order.index(j)
        st = _pg(D, 2, j, j == m, D.pri if q < 2 else _lite(D.pri, 0.55, S))
        _G(s, f'p.2.{j}', 'oval', px - r, py - r, 2 * r, 2 * r, st, 90)
        if r > 0.42:
            _T(s, D, f'x.pct.{j}', px - r, py - r * 0.55, 2 * r, r * 0.7, f'{round(z[j] / tot * 100)}%', min(28, r * 72 * 0.45), _on(D, st), 'bd')
            _T(s, D, f'c.{j}', px - r, py + r * 0.12, 2 * r, r * 0.5, D.cats[j], min(12, r * 72 * 0.22), _on(D, st), 'md', 'c', 't')
    rx = x + lw + 0.3; rw = w - lw - 0.3; rs = h / D.n
    for q, j in enumerate(order):
        yy = y + rs * q; st = _pg(D, 2, j, j == m)
        _T(s, D, f'x.rank.{j}', rx, yy, 0.35, rs * 0.55, str(q + 1), 16, _ink(D, st[0][1]), 'bd', 'l')
        _T(s, D, f'c.{j}', rx + 0.35, yy, rw - 1.4, rs * 0.55, D.cats[j], 12, S['text'], 'md', 'l')
        _T(s, D, f'v.2.{j}', rx + rw - 1.05, yy, 1.05, rs * 0.55, _fv(D, 2, j), 13, S['text'], 'bd', 'r')
        _S(s, f'd.trk.{j}', 'round', rx + 0.35, yy + rs * 0.58, rw - 0.35, 0.1, _trk(S), adj=0.5)
        _G(s, f'p.2.{j}', 'round', rx + 0.35, yy + rs * 0.58, max(0.1, (rw - 0.35) * z[j] / max(z)), 0.1, st, 0, adj=0.5)


@_st('radar', 'radar_b', 'กลีบดอกไม้ไล่สีจากกลาง')
def _i_petals(s, D, box):
    S = D.S; x, y, w, h = box; v = D.ser[0][1]; n = D.n; rm = min(w, h) * 0.36; r0 = rm * 0.26; cx, cy = x + w / 2, y + h / 2
    vm = _nice(max(v) or 1); m = _imax(D); sw = 360 / n; gp = min(4, sw * 0.08)
    for j, vv in enumerate(v):
        a0, a1 = j * sw - sw / 2 + gp, j * sw + sw / 2 - gp; rb = r0 + (rm - r0) * max(0, vv) / vm; st = _pg(D, 0, j, j == m)
        _S(s, f'd.trk.{j}', 'arc', cx - rm, cy - rm, 2 * rm, 2 * rm, _trk(S), adj=_arcadj(a0, a1, (rm - r0) / (2 * rm)))
        if rb > r0 + 0.02: _G(s, f'p.0.{j}', 'arc', cx - rb, cy - rb, 2 * rb, 2 * rb, list(reversed([(1 - p, c) for p, c in st])), 90, adj=_arcadj(a0, a1, (rb - r0) / (2 * rb)))
        lx, ly = _polar(cx, cy, rm + 0.45, j * sw)
        _T(s, D, f'v.0.{j}', lx - 0.8, ly - 0.4, 1.6, 0.42, _fv(D, 0, j), 20, _ink(D, st[0][1]), 'bd')
        _T(s, D, f'c.{j}', lx - 0.8, ly + 0.02, 1.6, 0.32, D.cats[j], 11, S['soft'], 'md', 'c', 't')
    dm = (r0 - 0.06) * 2
    _S(s, 'd.mid', 'oval', cx - dm / 2, cy - dm / 2, dm, dm, S['surf'])
    _T(s, D, 'x.avg', cx - dm / 2, cy - dm / 2, dm, dm, _fv(D, 0, 0, sum(v) / n), _fz(_fv(D, 0, 0, sum(v) / n), dm * 0.9, 18), S['text'], 'bd')


@_st('waterfall', 'waterfall_b', 'แนวนอน แคปซูลลอย')
def _i_wf_h(s, D, box):
    S = D.S; v = D.ser[0][1]; tot, lev, bse, bar = _wf(v); lab = min(1.8, box[2] * 0.27); x0, x1, rs, y0 = _rows(box, D.n, lab, 1.0)
    lo_, hi_ = min(0, min(lev)), max(lev + [b + c for b, c in zip(bse, bar)]); X = lambda q: x0 + (x1 - x0) * (q - lo_) / ((hi_ - lo_) or 1); bh = min(0.46, rs * 0.55)
    for j in range(D.n):
        yy = y0 + rs * j + (rs - bh) / 2; a, b = bse[j], bse[j] + bar[j]
        if tot[j]: a, b = min(0, v[j]), max(0, v[j])
        st = _pg(D, 0, j, (not tot[j]) and v[j] < 0, D.pri if tot[j] else _lite(D.pri, 0.45, S))
        _G(s, f'p.0.{j}', 'round', X(a), yy, max(0.05, X(b) - X(a)), bh, st, 0, adj=0.5)
        _T(s, D, f'v.0.{j}', X(b) + 0.08, yy, 1.0, bh, _fv(D, 0, j) if tot[j] else _sgn(D, 0, j), 15, _ink(D, st[0][1]) if not tot[j] else S['text'], 'bd', 'l')
        _T(s, D, f'c.{j}', box[0], yy - 0.06, lab - 0.12, bh * 0.62, D.cats[j], 13, S['text'], 'bd', 'l')
        if v[0]: _T(s, D, f'x.pct.{j}', box[0], yy + bh * 0.55, lab - 0.12, 0.26, f'{round(abs(v[j]) / abs(v[0]) * 100)}%', 10, S['soft'], 'rg', 'l')
        if j < D.n - 1: e = lev[j]; ln(s, X(e), yy + bh, X(e), yy + rs, S['grid'], 1.25, True)


def _mekko(s, D, box, vert):
    S = D.S; x, y, w, h = box; g = 0.06; tots = [sum(v[j] for _, v in D.ser) for j in range(D.n)]; T_ = sum(tots)
    _leg(s, D, x, y, w, [_pg(D, i, -1) for i in range(D.k)])
    if vert:
        top, bot = y + 0.45, y + h - 0.75; W = w - g * (D.n - 1); cx = x
        for j in range(D.n):
            cw = W * tots[j] / T_; cy = bot
            for i, (_, v) in enumerate(D.ser):
                hh = (bot - top) * v[j] / tots[j]; cy -= hh; st = _pg(D, i, j)
                _G(s, f'p.{i}.{j}', 'round', cx, cy + (g / 2 if i < D.k - 1 else 0), cw, hh - g / 2, st, 90, adj=min(0.5, 0.1 / max(0.01, min(cw, hh))))
                t = f'{round(v[j] / tots[j] * 100)}%'
                if cw > 0.55 and hh > 0.35: _T(s, D, f'x.pct.{i}.{j}', cx + 0.06, cy + 0.05, cw - 0.1, 0.34, t, 14, _on(D, st), 'bd', 'l', 't')
            _T(s, D, f'c.{j}', cx, bot + 0.06, max(cw, 0.6), 0.34, D.cats[j], 12, S['text'], 'bd', 'l', 't')
            _T(s, D, f'x.share.{j}', cx, bot + 0.38, max(cw, 0.6), 0.3, f'{round(tots[j] / T_ * 100)}%', 11, S['soft'], 'rg', 'l', 't')
            cx += cw + g
    else:
        lab = min(1.6, w * 0.24); x0 = x + lab; W = w - lab; top = y + 0.45; H = h - 0.45 - g * (D.n - 1); cy = top
        for j in range(D.n):
            rh = H * tots[j] / T_; cx = x0
            for i, (_, v) in enumerate(D.ser):
                cw = W * v[j] / tots[j]; st = _pg(D, i, j)
                _G(s, f'p.{i}.{j}', 'round', cx, cy, max(0.02, cw - (g if i < D.k - 1 else 0)), rh, st, 0, adj=min(0.5, 0.1 / max(0.01, min(cw, rh))))
                t = f'{round(v[j] / tots[j] * 100)}%'
                if cw > 0.6 and rh > 0.3: _T(s, D, f'x.pct.{i}.{j}', cx + 0.08, cy, cw - 0.12, rh, t, min(14, rh * 72 * 0.5), _on(D, st), 'bd', 'l')
                cx += cw
            _T(s, D, f'c.{j}', x, cy, lab - 0.1, rh * 0.6 if rh > 0.5 else rh, D.cats[j], 12, S['text'], 'bd', 'l', 'm')
            if rh > 0.5: _T(s, D, f'x.share.{j}', x, cy + rh * 0.5, lab - 0.1, rh * 0.4, f'{round(tots[j] / T_ * 100)}%', 10, S['soft'], 'rg', 'l', 't')
            cy += rh + g


@_st('marimekko', 'mekko_a', 'โมเสกแนวตั้ง มุมโค้ง')
def _i_mekko_a(s, D, box): _mekko(s, D, box, True)


@_st('marimekko', 'mekko_b', 'โมเสกแนวนอน')
def _i_mekko_b(s, D, box): _mekko(s, D, box, False)


@_st('combo', 'combo_b', 'หัวโค้ง + ป้ายเหตุการณ์')
def _i_combo_b(s, D, box):
    S = D.S; x, y, w, h = box; n = D.n; a, b = D.ser[0][1], D.ser[1][1]; bot = y + h - 0.45; H = (h - 0.45) * 0.5; slot = w / n; bw = min(slot * 0.5, 0.9)
    va, vb = max(a) or 1, max(b) or 1; lc = _ink(D, D.acc[0][1]); pts = []
    _leg(s, D, x, y, w, [D.pri, D.acc])
    ln(s, x, bot, x + w, bot, S['grid'], 1.5)
    for j in range(n):
        cx = x + slot * (j + 0.5); top = bot - H * a[j] / va; st = _pg(D, 0, j)
        _G(s, f'p.0.{j}', 'round2', cx - bw / 2, top, bw, bot - top, st, 90, adj=[min(0.5, 0.14 / max(0.01, min(bw, bot - top))), 0])
        _T(s, D, f'v.0.{j}', cx - slot / 2, top - 0.62, slot, 0.32, _fv(D, 0, j), 13, _ink(D, D.pri[0][1]), 'bd')
        _T(s, D, f'v.1.{j}', cx - slot / 2, top - 0.32, slot, 0.28, _fv(D, 1, j), 11, lc, 'md')
        _T(s, D, f'c.{j}', cx - slot / 2, bot + 0.06, slot, 0.34, D.cats[j], 11, S['soft'], 'rg', 'c', 't')
        pts.append((cx, bot - H * b[j] / vb))
        _callout(s, D, j, cx, top - 0.62, min(1.9, max(slot * 0.95, 1.1)), D.pri if j == n - 1 else None, box)
    _F(s, 'p.1', pts, close=False, line=S['surf'], lw=7)
    _F(s, 'p.1', pts, close=False, line=D.pc.get('1') or D.acc, lw=3.5)
    for j, (px, py) in enumerate(pts): _S(s, f'p.1.{j}', 'oval', px - 0.08, py - 0.08, 0.16, 0.16, S['surf'], line=lc, lw=2.25)


@_st('pareto', 'pareto_b', 'ตัวเลขใหญ่ + แถวจัดอันดับ')
def _i_pareto_b(s, D, box):
    S = D.S; x, y, w, h = box; v0 = D.ser[0][1]; od = sorted(range(D.n), key=lambda j: -v0[j]); tot = sum(v0); n = D.n
    cum = []; c = 0
    for j in od: c += v0[j]; cum.append(c / tot)
    kf = next(q for q, cc in enumerate(cum) if cc >= 0.8) + 1; pw = min(2.4, w * 0.34)
    pst = _lite(D.acc, 0.85, S); _G(s, 'd.panel', 'round', x, y, pw, h, pst, 90, adj=0.08); pbg = _samp(pst, 0.2)
    t = f'{round(cum[kf - 1] * 100)}%'
    _T(s, D, 'x.big', x + 0.15, y + 0.3, pw - 0.3, 1.0, t, _fz(t, pw - 0.3, 54), D.acc[0][1] if cratio(D.acc[0][1], pbg) >= 4.5 else ink_on(D.acc[0][1], pbg, 4.5), 'bd', 'l')
    _T(s, D, 'lab.big', x + 0.15, y + 1.35, pw - 0.3, 0.9, D.lab.get('big', ''), 13, S['text'], 'md', 'l', 't')
    for q, j in enumerate(od[:kf]):
        yy = y + 2.35 + q * 0.36
        if yy + 0.36 > y + h: break
        _S(s, f'd.dot.{j}', 'oval', x + 0.18, yy + 0.12, 0.1, 0.1, _ink(D, D.acc[0][1]))
        _T(s, D, f'c.{j}', x + 0.34, yy, pw - 0.45, 0.34, D.cats[j], 12, S['text'], 'md', 'l')
    rx = x + pw + 0.25; rw = w - pw - 0.25; rs = h / n; bx = rx + rw * 0.42; bwm = rw * 0.58 - 1.75
    for q, j in enumerate(od):
        yy = y + rs * q; few = q < kf; cy = yy + rs / 2; st = _pg(D, 0, j, False, D.pri if few else _lite(D.pri, 0.55, S))
        dm = min(0.36, rs * 0.7)
        _G(s, f'p.0.{j}', 'oval', rx, cy - dm / 2, dm, dm, st if few else [(0.0, _trk(S)), (1.0, _trk(S))], 90)
        _T(s, D, f'x.rank.{j}', rx, cy - dm / 2, dm, dm, str(q + 1), 11, _on(D, st) if few else S['text'], 'bd')
        _T(s, D, f'c.{j}', rx + dm + 0.08, cy - 0.2, bx - rx - dm - 0.12, 0.4, D.cats[j], 12, S['text'] if few else S['soft'], 'md' if few else 'rg', 'l')
        _S(s, f'd.trk.{j}', 'round', bx, cy - 0.08, bwm, 0.16, _trk(S), adj=0.5)
        _G(s, f'p.0.{j}', 'round', bx, cy - 0.08, max(0.16, bwm * v0[j] / v0[od[0]]), 0.16, st, 0, adj=0.5)
        _T(s, D, f'v.0.{j}', bx + bwm + 0.05, cy - 0.2, 0.55, 0.4, _fv(D, 0, j), 12, S['text'], 'bd', 'l')
        rr = min(0.42, rs * 0.75)
        _S(s, f'd.ring.{j}', 'donut', x + w - rr, cy - rr / 2, rr, rr, _trk(S), adj=0.16)
        _G(s, f'x.cum.{j}', 'arc', x + w - rr, cy - rr / 2, rr, rr, D.acc if few else _lite(D.acc, 0.5, S), 45, adj=_arcadj(0, min(359.9, cum[q] * 360), 0.16))
        _T(s, D, f'x.cum.{j}', x + w - rr - 0.6, cy - 0.2, 0.56, 0.4, f'{round(cum[q] * 100)}%', 11, _ink(D, D.acc[0][1]) if few else S['soft'], 'bd', 'r')


@_st('range', 'range_b', 'แคปซูลช่วงค่า')
def _i_range_b(s, D, box):
    S = D.S; x, y, w, h = box; lo, hi = D.ser[0][1], D.ser[1][1]; n = D.n
    t = f'{_fv(D, 0, lo.index(min(lo)))}–{_fv(D, 1, hi.index(max(hi)))}'
    _T(s, D, 'x.big', x, y, w, 0.7, t, 34, S['text'], 'bd', 'l')
    top, bot = y + 0.95, y + h - 0.45; a_, b_ = min(lo), max(hi); pad = (b_ - a_) * 0.08 or 1; Y = lambda v: bot - (bot - top) * (v - a_ + pad) / (b_ - a_ + 2 * pad)
    x0 = x + 0.95; slot = (w - 0.95) / n; bw = min(slot * 0.42, 0.55); pk = hi.index(max(hi)); lw_ = lo.index(min(lo))   # ซ้ายสุดเว้นที่ให้ป้ายค่าเฉลี่ย
    avg = sum((p + q) / 2 for p, q in zip(lo, hi)) / n
    ln(s, x, Y(avg), x + w, Y(avg), S['soft'], 1.25)
    _S(s, 'd.avg', 'round', x, Y(avg) - 0.17, 0.85, 0.34, S['text'], adj=0.5)
    _T(s, D, 'x.avg', x, Y(avg) - 0.17, 0.85, 0.34, _fv(D, 0, 0, avg), 11, S['surf'], 'bd')
    for j in range(n):
        cx = x0 + slot * (j + 0.5); st = _pg(D, 0, j, j == pk, list(reversed([(1 - p, c) for p, c in D.pri])))
        if f'1.{j}' in D.pc: st = D.pc[f'1.{j}']
        _G(s, f'p.0.{j}', 'round', cx - bw / 2, Y(hi[j]), bw, max(bw, Y(lo[j]) - Y(hi[j])), st, 90, adj=0.5)
        if j == pk: _S(s, f'd.dot.{j}', 'oval', cx - 0.06, Y(hi[j]) + bw / 2 - 0.06, 0.12, 0.12, S['surf'])
        if j == lw_: _S(s, f'd.dot.{j}', 'oval', cx - 0.06, Y(lo[j]) - bw / 2 - 0.06, 0.12, 0.12, S['surf'])
        _T(s, D, f'v.1.{j}', cx - slot / 2, Y(hi[j]) - 0.32, slot, 0.3, _fv(D, 1, j), 11, S['text'], 'bd')
        _T(s, D, f'v.0.{j}', cx - slot / 2, max(Y(lo[j]), Y(hi[j]) + bw) + 0.02, slot, 0.28, _fv(D, 0, j), 10, S['soft'], 'md')
        _T(s, D, f'c.{j}', cx - slot / 2, bot + 0.06, slot, 0.34, D.cats[j], 11, S['soft'], 'rg', 'c', 't')


def _sankey(s, D, box, vert):
    """แถว = ต้นทาง คอลัมน์ตัวเลข = ปลายทาง ค่าในเซลล์ = จำนวนที่ไหล  ความหนาสาย = ค่า ไล่สีจากต้นทางไปปลายทาง"""
    S = D.S; x, y, w, h = box; src = [sum(v[j] for _, v in D.ser) for j in range(D.n)]; dst = [sum(v) for _, v in D.ser]; T_ = sum(src) or 1
    nw = 0.16; gap = 0.14
    span = (w if vert else h) - (0.0 if vert else 0.0); u0 = (y + 0.5 if vert else x + 1.6); u1 = (y + h - 1.25 if vert else x + w - 1.6)
    v0 = x if vert else y; L = (w if vert else h)
    sc0 = (L - gap * (D.n - 1)) / T_; sc1 = (L - gap * (D.k - 1)) / T_
    pos0, a = [], v0
    for t_ in src: pos0.append(a); a += t_ * sc0 + gap
    pos1, a = [], v0
    for t_ in dst: pos1.append(a); a += t_ * sc1 + gap
    P_ = (lambda u, v: (v, u)) if vert else (lambda u, v: (u, v))
    rect = lambda u, v, du, dv: (v, u, dv, du) if vert else (u, v, du, dv)
    cs = [D.pc.get(f'r.{j}') or _seg(D.pri, j / max(1, D.n), (j + 0.8) / max(1, D.n)) for j in range(D.n)]   # สีรายชิ้น: 'r.j' ต้นทาง / 'i' ปลายทาง
    ct = [D.pc.get(f'{i}') or (D.acc if i == 0 else _lite(D.pri, 0.25 + 0.5 * i / D.k, S)) for i in range(D.k)]
    o0 = list(pos0); o1 = list(pos1)
    for j in range(D.n):
        for i, (_, v) in enumerate(D.ser):
            if v[j] <= 0: continue
            a0, a1 = o0[j], o0[j] + v[j] * sc0; b0, b1 = o1[i], o1[i] + v[j] * sc1; o0[j] = a1; o1[i] = b1
            ua, ub = u0 + nw, u1; um = (ua + ub) / 2
            top = [P_(ua, a0)] + _bez(P_(ua, a0), P_(um, a0), P_(um, b0), P_(ub, b0)); botm = [P_(ub, b1)] + _bez(P_(ub, b1), P_(um, b1), P_(um, a1), P_(ua, a1))
            _F(s, f'p.{i}.{j}', top + botm, [(0.0, cs[j][0][1]), (1.0, ct[i][0][1])], 90 if vert else 0, alpha=(0.5, 0.42))
    for j, t_ in enumerate(src):
        _G(s, f'p.r.{j}', 'round', *rect(u0, pos0[j], nw, max(0.03, t_ * sc0)), cs[j], 0, adj=0.3)
        if vert:
            _T(s, D, f'c.{j}', pos0[j], y, max(0.9, t_ * sc0), 0.26, D.cats[j], 12, S['text'], 'bd', 'l', 't')
            _T(s, D, f'x.src.{j}', pos0[j], y + 0.24, max(0.9, t_ * sc0), 0.24, _fv(D, 0, 0, t_), 10, S['soft'], 'rg', 'l', 't')
        else:
            m_ = pos0[j] + t_ * sc0 / 2
            _T(s, D, f'c.{j}', x, m_ - 0.27, 1.5, 0.3, D.cats[j], 12, S['text'], 'bd', 'r')
            _T(s, D, f'x.src.{j}', x, m_ + 0.02, 1.5, 0.26, _fv(D, 0, 0, t_), 10, S['soft'], 'rg', 'r')
    for i, t_ in enumerate(dst):
        _G(s, f'p.{i}', 'round', *rect(u1, pos1[i], nw, max(0.03, t_ * sc1)), ct[i], 0, adj=0.3)
        if vert:
            cw = max(0.9, t_ * sc1 - 0.04)
            _G(s, f'd.card.{i}', 'round', pos1[i], u1 + nw + 0.1, cw, 0.95, ct[i] if i == 0 else _lite(ct[i], 0.7, S), 90, adj=0.15); fc = _on(D, ct[i] if i == 0 else _lite(ct[i], 0.7, S))
            _T(s, D, f's.{i}', pos1[i] + 0.08, u1 + nw + 0.14, cw - 0.16, 0.3, D.ser[i][0], 11, fc, 'md', 'l', 't')
            _T(s, D, f'x.dst.{i}', pos1[i] + 0.08, u1 + nw + 0.42, cw - 0.16, 0.4, _fv(D, i, 0, t_), 16, fc, 'bd', 'l', 't')
            _T(s, D, f'x.pct.{i}', pos1[i] + 0.08, u1 + nw + 0.46, cw - 0.16, 0.36, f'{round(t_ / T_ * 100)}%', 11, fc, 'md', 'r', 't')
        else:
            m_ = pos1[i] + t_ * sc1 / 2
            _T(s, D, f's.{i}', u1 + nw + 0.1, m_ - 0.3, 1.4, 0.3, D.ser[i][0], 12, S['text'], 'bd', 'l')
            _T(s, D, f'x.dst.{i}', u1 + nw + 0.1, m_, 1.4, 0.34, _fv(D, i, 0, t_), 15, _ink(D, ct[i][0][1]), 'bd', 'l')


@_st('sankey', 'sankey_a', 'สายน้ำแนวนอน')
def _i_sankey_a(s, D, box): _sankey(s, D, box, False)


@_st('sankey', 'sankey_b', 'สายน้ำแนวตั้ง + การ์ดผลลัพธ์')
def _i_sankey_b(s, D, box): _sankey(s, D, box, True)
