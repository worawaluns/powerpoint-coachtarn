"""20 เลย์เอาต์ชุด Startup Business Pitch — ลอกโครงจากเทมเพลตน้ำเงินกรมท่า (Canva)

พื้นเทาฟ้าอ่อนมีแสงฟุ้ง การ์ดมนสามระดับสี (น้ำเงินสด / น้ำเงินกลาง / กรมท่า)
แถบหัวกระดาษมีโลโก้ซ้าย เมนูแคปซูลกลาง ป้ายเลขหน้าขวา ของตกแต่งเป็นรูปทรงสามมิติสีน้ำเงิน
ปก หน้าคั่น และหน้าปิดเป็นพื้นกรมท่าไล่เฉดม่วง
"""
from eng import *
import eng
from lay import L, reg

txt = txt_big        # ขนาดขั้นต่ำตามชุด 366 ดู eng.roomy()
chart = chart_big

M = 0.62
NAVY = '19255F'
NAV = ['เกี่ยวกับเรา', 'ระบบของเรา', 'ตลาด', 'ทีม', 'ติดต่อ']


def _duo():
    return f"duo:{mix(NAVY, P['acc'], 0.30)}:{mix(P['bg'], P['acc2'], 0.16)}"


def _duo_dark():
    return f"duo:{mix(P['g1'], P['acc'], 0.25)}:{mix(P['acc2'], 'FFFFFF', 0.62)}"


def _body():
    return mix(P['bg'], P['ink'], 0.82)


def _on(fill):
    """สีหัวเรื่องกับเนื้อความบนการ์ดสีเต็ม"""
    return 'FFFFFF', {P['acc']: 'DCE3F8', P['acc2']: 'FFFFFF', NAVY: 'CAD3F0'}.get(fill, 'FFFFFF')


def _bg(s, dark=False):
    if dark:
        gradband(s, 0, 0, W, H, 315, c1=P['g1'], c2=P['g2'])
        glow(s, 10.6, 1.2, 3.4, P['acc2'], 0.55)
        return
    glow(s, 4.2, 0.9, 3.6, P['acc2'], 0.45)
    glow(s, 11.4, 6.6, 3.2, P['acc2'], 0.40)


def _chrome(s, d, nav=True, dark=False):
    c = 'C9CFF0' if dark else P['mute']
    shp(s, 'round', M, 0.34, 0.42, 0.42, P['acc'] if not dark else P['acc2'], adj=0.26)
    icon(s, 'layers', M + 0.21, 0.55, 0.24, 'FFFFFF')
    txt(s, M + 0.56, 0.32, 2.6, 0.26, d.get('brand', 'บริษัทของคุณ'), 9.5, 'FFFFFF' if dark else P['ink'], 'md')
    txt(s, M + 0.56, 0.54, 2.6, 0.24, 'สตาร์ทอัประบบร้านอาหาร', 9, c, 'rg')
    if nav:
        x0, w = 4.30, 4.90
        shp(s, 'round', x0, 0.36, w, 0.40, mix(P['g1'], 'FFFFFF', 0.10) if dark else mix(P['bg'], P['ink'], 0.05), adj=0.5)
        for i, t in enumerate(NAV):
            txt(s, x0 + i * w / 5, 0.36, w / 5, 0.40, t, 9, c, 'rg', 'c', 'm')
    if d.get('n'):
        shp(s, 'round', W - M - 1.06, 0.36, 1.06, 0.40, mix(P['g1'], 'FFFFFF', 0.10) if dark else mix(P['bg'], P['ink'], 0.05), adj=0.5)
        txt(s, W - M - 1.06, 0.36, 1.06, 0.40, f"หน้า {d['n']}", 9, c, 'rg', 'c', 'm')


def _k(s, x, y, t, dark=False, al='l', w=5.0):
    if t: txt(s, x, y, w, 0.28, t, 10, 'B9C2EE' if dark else P['mute'], 'md', al, track=1.0)


def _h(s, x, y, t, sz=36, w=6.0, c=None, al='l'):
    txt(s, x, y, w, 2.4, t, sz, c or P['ink'], 'md', al, sp=1.08)


def _p(s, x, y, w, t, sz=11, c=None, al='l'):
    if t: txt(s, x, y, w, 1.6, t, sz, c or _body(), 'rg', al, sp=1.36)


def _card(s, x, y, w, h, fill, adj=0.12):
    return shp(s, 'round', x, y, w, h, fill, adj=adj, shadow=(NAVY, 0.16, 16, 5))


def _chip(s, x, y, ic, fill, sz=0.62):
    shp(s, 'round', x, y, sz, sz, mix(fill, 'FFFFFF', 0.16), adj=0.26)
    icon(s, ic, x + sz / 2, y + sz / 2, sz * 0.48, 'FFFFFF')


def _photo(s, n, x, y, w, h, adj=0.16, topic=None, d=None, focus=(0.5, 0.45), dark=False):
    pic(s, ph(topic or (d or {}).get('topic', 'office'), n), x, y, w, h, geom='roundRect', adj=adj,
        focus=focus, mode=_duo_dark() if dark else _duo())


# ── ของตกแต่งสามมิติ ───────────────────────────────────────────────────────
def _cube(s, x, y, sz, rot):
    shp(s, 'round', x, y, sz, sz, grad=(P['acc2'], P['acc'], 135), adj=0.16, rot=rot, shadow=(NAVY, 0.30, 14, 7))


def _cubes(s, x, y, k=1.0):
    _cube(s, x, y, 0.80 * k, 18)
    _cube(s, x - 0.30 * k, y + 0.92 * k, 0.70 * k, -14)
    _cube(s, x + 0.42 * k, y + 1.62 * k, 0.62 * k, 32)


def _spring(s, cx, cy, w, n=5):
    for i in range(n):
        shp(s, 'oval', cx - w / 2 + i * 0.06, cy - i * 0.30, w, w * 0.44, None,
            line=mix(P['acc2'], P['acc'], i / (n - 1) * 0.7), lw=14, rot=-14)


def _torus(s, cx, cy, d, rot=-18):
    shp(s, 'donut', cx - d / 2, cy - d * 0.32, d, d * 0.64, grad=(P['acc2'], P['acc'], 300), adj=0.24, rot=rot,
        shadow=(NAVY, 0.28, 16, 7))


def _cone(s, x, y, sz, rot=200):
    shp(s, 'tri', x, y, sz, sz * 0.92, grad=(P['acc2'], P['acc'], 90), rot=rot, shadow=(NAVY, 0.26, 12, 5))


# ══ เลย์เอาต์ตามรูปอ้างอิง ═════════════════════════════════════════════════

@reg
def sb_cover(prs, d):
    s = page(prs)
    _bg(s, True)
    _chrome(s, {**d, 'n': ''}, True, True)
    _k(s, M, 1.62, d.get('k', ''), True, w=5.8)
    _h(s, M, 2.02, d['t'], 38, 6.2, 'FFFFFF')
    shp(s, 'round', M, 4.92, 4.30, 1.30, 'FFFFFF', a=0.08, adj=0.14)
    txt(s, M + 0.34, 5.10, 3.6, 0.28, 'นำเสนอโดย', 10, 'B9C2EE', 'rg')
    txt(s, M + 0.34, 5.42, 3.6, 0.36, d.get('by', ''), 14, 'FFFFFF', 'md')
    ln(s, M + 0.34, 5.92, M + 3.90, 5.92, 'B9C2EE', 0.8)
    st = d['tiles']; pi = d.get('pis', [0, 4, 8])
    tile = lambda x, y, w, v, lab, f: (shp(s, 'round', x, y, w, 1.75, f, adj=0.30),
                                       txt(s, x, y + 0.42, w, 0.56, v, 24, 'FFFFFF', 'md', 'c'),
                                       txt(s, x + 0.12, y + 1.06, w - 0.24, 0.30, lab, 9.5, 'DCE3F8', 'rg', 'c'))
    _photo(s, pi[0], 7.00, 1.15, 3.30, 1.75, 0.34, dark=True, d=d)
    if len(st) > 0: tile(10.45, 1.15, 2.25, *st[0], P['acc'])   # ใบงาน 021: doc2slide ส่ง tiles ว่างได้ (ไม่มีตัวเลขจากเอกสาร)
    shp(s, 'round', 7.00, 3.08, 2.00, 1.75, mix(P['g1'], NAVY, 0.6), adj=0.30)
    _cubes(s, 7.62, 3.30, 0.52)
    _photo(s, pi[1], 9.15, 3.08, 3.55, 1.75, 0.34, dark=True, d=d)
    _photo(s, pi[2], 7.00, 5.01, 1.75, 1.75, 0.34, dark=True, d=d)
    if len(st) > 1: tile(8.90, 5.01, 1.80, *st[1], P['acc2'])
    if len(st) > 2: tile(10.85, 5.01, 1.85, *st[2], NAVY)


@reg
def sb_toc(prs, d):
    s = page(prs)
    _bg(s)
    _chrome(s, d)
    _k(s, M, 1.30, d.get('k', ''))
    _h(s, M, 1.62, d['t'], 38, 5.3)
    _photo(s, d.get('pi', 0), M, 3.95, 2.55, 2.85, 0.14, d=d)
    _photo(s, d.get('pi2', 15), M + 2.70, 3.95, 2.55, 2.85, 0.14, d=d, focus=(0.6, 0.4))
    _card(s, 6.30, 1.15, 6.40, 5.65, P['acc'], 0.07)
    for i, (lab, no) in enumerate(d['items'][:8]):   # ใบงาน 021: (ชื่อ, เลขหน้า) ชื่อขึ้นก่อน ไม่งั้น doc2slide อ่านเป็นการ์ดตัวเลข 8 ช่อง
        x = 6.80 + (i % 2) * 3.00
        y = 1.62 + (i // 2) * 0.92
        txt(s, x, y, 0.56, 0.40, no, 13, 'B9C6F2', 'md')
        txt(s, x + 0.56, y, 2.40, 0.80, lab, 14, 'FFFFFF', 'md', sp=1.1)
    _spring(s, 10.9, 6.85, 1.9)


@reg
def sb_problem(prs, d):
    s = page(prs)
    _bg(s)
    _chrome(s, d, nav=False)
    _k(s, M, 1.30, d.get('k', ''))
    _h(s, M, 1.62, d['t'], 36, 4.0)
    ln(s, M, 4.42, M + 0.70, 4.42, P['ink'], 1.2)
    txt(s, M, 4.70, 3.6, 0.70, d['big'], 34, P['acc'], 'md')
    _p(s, M, 5.42, 3.6, d['biglab'], 11)
    _photo(s, d.get('pi', 0), 4.80, 1.15, 2.80, 5.65, 0.14, d=d, focus=(0.5, 0.4))
    _cubes(s, 4.30, 3.70, 0.82)
    for i, (ic, h_, body) in enumerate(d['items'][:2]):
        y = 1.15 + i * 2.90
        f = P['acc'] if i == 0 else NAVY
        hc, bc = _on(f)
        _card(s, 7.95, y, 4.75, 2.70, f, 0.10)
        _chip(s, 8.30, y + 0.36, ic, f)
        txt(s, 9.10, y + 0.36, 3.40, 0.62, h_, 16, hc, 'md', an='m')
        _p(s, 8.30, y + 1.20, 4.10, body, 11, bc)


@reg
def sb_solution(prs, d):
    s = page(prs)
    _bg(s)
    _chrome(s, d)
    _k(s, 0, 1.18, d.get('k', ''), al='c', w=W)
    _h(s, 0, 1.46, d['t'], 34, W, al='c')
    ln(s, 2.70, 2.86, 10.63, 2.86, mix(P['bg'], P['acc'], 0.40), 1.2)
    cw, gap = 2.95, 0.20
    x0 = (W - cw * 3 - gap * 2) / 2
    for i, (ic, h_, body) in enumerate(d['items'][:3]):
        x = x0 + i * (cw + gap)
        shp(s, 'oval', x + cw / 2 - 0.11, 2.75, 0.22, 0.22, NAVY)
        f = (P['acc'], P['acc2'], NAVY)[i]
        hc, bc = _on(f)
        _card(s, x, 3.30, cw, 3.45, f, 0.08)
        _chip(s, x + 0.30, 3.62, ic, f, 0.58)
        txt(s, x + 0.30, 4.42, cw - 0.60, 0.72, h_, 15, hc, 'md', sp=1.1)
        _p(s, x + 0.30, 5.18, cw - 0.60, body, 10.5, bc)


@reg
def sb_market_chart(prs, d):
    s = page(prs)
    _bg(s)
    _chrome(s, d, nav=False)
    _k(s, M, 1.30, d.get('k', ''))
    _h(s, M, 1.62, d['t'], 36, 5.2)
    for i, (lab, body) in enumerate(d['items'][:3]):
        y = 3.70 + i * 1.02
        f = (P['acc'], P['acc2'], NAVY)[i]
        shp(s, 'round', M, y, 1.62, 0.80, f, adj=0.24)
        txt(s, M, y, 1.62, 0.80, lab, 11.5, 'FFFFFF', 'md', 'c', 'm')
        _p(s, M + 1.82, y + 0.04, 3.30, body, 10.5)
    shp(s, 'round', 5.95, 1.10, 6.75, 5.70, mix(P['bg'], 'FFFFFF', 0.55), adj=0.05)
    chart(s, 'col', 6.20, 1.30, 6.30, 5.30, d['cats'], d['series'], [NAVY, P['acc2']], labels=True, fmt='#,##0',
          legend=True, gap=55, overlap=-6, sz=11, c=P['mute'])
    _torus(s, 5.30, 6.70, 1.50, -24)


@reg
def sb_model(prs, d):
    s = page(prs)
    _bg(s)
    _chrome(s, d, nav=False)
    _k(s, 0, 1.12, d.get('k', ''), al='c', w=W)
    _h(s, 0, 1.40, d['t'], 34, W, al='c')
    _photo(s, d.get('pi', 0), M, 2.50, 5.30, 4.30, 0.10, d=d)
    cw, gap = 2.30, 0.14
    for i, (tier, price, unit, cnt, body) in enumerate(d['items'][:3]):
        x = 5.10 + i * (cw + gap)
        f = (P['acc'], P['acc2'], NAVY)[i]
        hc, bc = _on(f)
        _card(s, x, 2.80, cw, 3.95, f, 0.08)
        txt(s, x + 0.26, 3.04, cw - 0.52, 0.34, tier, 12.5, bc, 'md')
        txt(s, x + 0.26, 3.42, cw - 0.52, 0.62, price, 26, hc, 'md')
        txt(s, x + 0.26, 4.06, cw - 0.52, 0.28, unit, 10, bc, 'rg')
        ln(s, x + 0.26, 4.48, x + cw - 0.26, 4.48, bc, 0.6)
        txt(s, x + 0.26, 4.60, cw - 0.52, 0.34, cnt, 13, hc, 'md')
        _p(s, x + 0.26, 5.00, cw - 0.52, body, 10, bc)


@reg
def sb_edge(prs, d):
    s = page(prs)
    _bg(s)
    _chrome(s, d, nav=False)
    shp(s, 'rect', 0, 0.95, 5.55, H - 0.95, mix(P['bg'], P['ink'], 0.035))
    _k(s, M, 1.30, d.get('k', ''))
    _h(s, M, 1.62, d['t'], 34, 4.8)
    _photo(s, d.get('pi', 0), M, 4.05, 4.40, 2.75, 0.12, d=d)
    _torus(s, M + 0.30, 6.75, 1.30, -30)
    for i, (ic, h_, body) in enumerate(d['items'][:3]):
        y = 1.15 + i * 1.92
        f = (P['acc'], P['acc2'], NAVY)[i]
        hc, bc = _on(f)
        _card(s, 6.05, y, 6.65, 1.74, f, 0.14)
        _chip(s, 6.40, y + 0.56, ic, f, 0.64)
        txt(s, 7.30, y + 0.30, 5.10, 0.40, h_, 15, hc, 'md')
        _p(s, 7.30, y + 0.78, 5.10, body, 10.5, bc)


@reg
def sb_strategy(prs, d):
    s = page(prs)
    _bg(s)
    _chrome(s, d)
    _photo(s, d.get('pi', 0), 1.30, 1.30, 2.45, 2.40, 0.40, d=d)
    _photo(s, d.get('pi2', 1), 3.95, 1.30, 2.45, 2.40, 0.40, d=d)
    _card(s, 2.10, 3.92, 2.55, 2.70, P['acc'], 0.22)
    txt(s, 2.10, 4.46, 2.55, 0.80, d['big'], 32, 'FFFFFF', 'md', 'c')
    txt(s, 2.30, 5.28, 2.15, 0.70, d['biglab'], 10.5, 'DCE3F8', 'rg', 'c', sp=1.25)
    _photo(s, d.get('pi3', 2), 4.85, 3.92, 2.45, 2.70, 0.30, d=d)
    _cone(s, 0.62, 4.40, 1.15)
    _k(s, 7.95, 1.30, d.get('k', ''))
    _h(s, 7.95, 1.62, d['t'], 34, 4.8)
    for i, (ic, body) in enumerate(d['items'][:2]):
        y = 3.62 + i * 1.62
        f = P['acc2'] if i == 0 else NAVY
        hc, bc = _on(f)
        _card(s, 7.95, y, 4.75, 1.44, f, 0.20)
        shp(s, 'oval', 8.24, y + 0.38, 0.68, 0.68, mix(f, 'FFFFFF', 0.16))
        icon(s, ic, 8.58, y + 0.72, 0.34, 'FFFFFF')
        _p(s, 9.15, y + 0.24, 3.35, body, 10.5, bc)
    _cubes(s, 12.55, 1.20, 0.50)


@reg
def sb_team(prs, d):
    s = page(prs)
    _bg(s)
    _chrome(s, d, nav=False)
    _k(s, 0, 1.12, d.get('k', ''), al='c', w=W)
    _h(s, 0, 1.40, d['t'], 34, W, al='c')
    cw, gap = 2.70, 0.30
    x0 = (W - cw * 4 - gap * 3) / 2
    for i, (name, role, bio, pi, fx) in enumerate(d['items'][:4]):
        x = x0 + i * (cw + gap)
        _photo(s, pi, x + 0.35, 2.40, cw - 0.70, 3.00, 0.22, d=d, focus=(fx, 0.25))   # กรอบแนวตั้ง ครอปเหลือคนเดียว
        txt(s, x, 5.58, cw, 0.36, name, 14, P['ink'], 'md', 'c')
        txt(s, x, 5.94, cw, 0.30, role, 10.5, P['acc'], 'md', 'c')
        _p(s, x + 0.10, 6.28, cw - 0.20, bio, 10, P['mute'], 'c')
    _cube(s, 11.95, 1.30, 0.62, 24)


@reg
def sb_thanks(prs, d):
    s = page(prs)
    _bg(s, True)
    _chrome(s, d, True, True)
    _h(s, 0, 1.30, d['t'], 54, W, 'FFFFFF', 'c')
    _p(s, 1.5, 2.50, W - 3.0, d.get('note', ''), 12, 'C9CFF0', 'c')
    cw, gap = 2.35, 0.20
    x0 = (W - cw * 5 - gap * 4) / 2
    for i, pi in enumerate(d.get('pis', [0, 4, 8, 13, 22])[:5]):
        x = x0 + i * (cw + gap)
        if i == 2:
            shp(s, 'round', x, 3.60, cw, 1.70, P['acc'], adj=0.22)
            txt(s, x, 3.82, cw, 0.60, d['big'], 24, 'FFFFFF', 'md', 'c')
            txt(s, x + 0.16, 4.44, cw - 0.32, 0.60, d['biglab'], 10, 'DCE3F8', 'rg', 'c', sp=1.2)
        else:
            _photo(s, pi, x, 3.60, cw, 1.70, 0.22, dark=True, d=d)
    for i, (lab, v) in enumerate(d['items'][:3]):
        x = M + 0.4 + i * 4.10
        txt(s, x, 5.92, 3.8, 0.28, lab, 10, 'B9C2EE', 'rg')
        txt(s, x, 6.22, 3.8, 0.36, v, 13, 'FFFFFF', 'md')


# ══ อีก 10 เลย์เอาต์ในระบบเดียวกัน ════════════════════════════════════════

@reg
def sb_div_dark(prs, d):
    s = page(prs)
    _bg(s, True)
    _chrome(s, d, True, True)
    _k(s, M, 1.75, d.get('k', ''), True)
    _h(s, M, 2.10, d['t'], 44, 6.8, 'FFFFFF')
    _p(s, M, 5.55, 5.8, d.get('note', ''), 12, 'C9CFF0')
    _photo(s, d.get('pi', 0), 8.10, 1.20, 4.60, 2.70, 0.24, dark=True, d=d)
    _photo(s, d.get('pi2', 1), 8.10, 4.10, 2.20, 2.70, 0.24, dark=True, d=d)
    shp(s, 'round', 10.50, 4.10, 2.20, 2.70, P['acc'], adj=0.24)
    _torus(s, 11.60, 5.40, 1.60)


@reg
def sb_div_light(prs, d):
    s = page(prs)
    _bg(s)
    _chrome(s, d)
    _card(s, M, 1.15, 6.70, 5.65, P['acc'], 0.08)
    _k(s, M + 0.55, 1.85, d.get('k', ''), True)
    _h(s, M + 0.55, 2.25, d['t'], 44, 5.8, 'FFFFFF')
    _p(s, M + 0.55, 4.55, 5.4, d.get('note', ''), 12, 'DCE3F8')
    _photo(s, d.get('pi', 0), 7.55, 1.15, 5.15, 5.65, 0.10, d=d)
    _spring(s, 7.40, 6.55, 1.70)


@reg
def sb_tam(prs, d):
    s = page(prs)
    _bg(s)
    _chrome(s, d)
    _k(s, M, 1.30, d.get('k', ''))
    _h(s, M, 1.62, d['t'], 34, 4.6)
    _p(s, M, 3.10, 4.2, d.get('note', ''), 11)
    cx, base = 7.25, 6.85
    for i, (dia, f) in enumerate(((5.30, mix(P['bg'], P['acc2'], 0.30)), (3.70, P['acc2']), (2.10, NAVY))):
        shp(s, 'oval', cx - dia / 2, base - dia, dia, dia, f)
    labs = d['items'][:3]
    ys = [1.86, 3.58, 5.28]
    cy = [base - 5.30 + 0.45, base - 3.70 + 0.45, base - 2.10 + 0.80]
    for i, ((tag, v, lab, money), y) in enumerate(zip(labs, ys)):
        txt(s, cx - 1.2, cy[i] - 0.10, 2.4, 0.34, tag, 12, P['ink'] if i == 0 else 'FFFFFF', 'md', 'c')
        ln(s, cx + 1.25, cy[i] + 0.08, 9.70, y + 0.22, mix(P['bg'], P['ink'], 0.35), 0.8)
        shp(s, 'oval', 9.64, y + 0.16, 0.12, 0.12, P['acc'])
        txt(s, 9.90, y - 0.12, 2.9, 0.50, v, 22, P['acc'] if i < 2 else NAVY, 'md')
        _p(s, 9.90, y + 0.42, 2.9, lab, 10)
        txt(s, 9.90, y + 0.78, 2.9, 0.28, money, 10.5, P['ink'], 'md')


@reg
def sb_impact(prs, d):
    s = page(prs)
    _bg(s)
    _chrome(s, d, nav=False)
    _k(s, M, 1.30, d.get('k', ''))
    _h(s, M, 1.62, d['t'], 34, 4.4)
    _card(s, M, 4.10, 3.70, 2.70, NAVY, 0.10)
    txt(s, M + 0.36, 4.36, 3.0, 0.90, d['big'], 44, 'FFFFFF', 'md')
    _p(s, M + 0.36, 5.38, 3.0, d['biglab'], 10.5, 'CAD3F0')
    gx, gw = 5.40, 7.30
    txt(s, gx, 1.30, 2.4, 0.28, 'ก่อนใช้ระบบ', 10, P['mute'], 'md')
    shp(s, 'round', gx + 1.10, 1.36, 0.36, 0.16, mix(P['bg'], P['ink'], 0.16), adj=0.5)
    txt(s, gx + 2.00, 1.30, 2.4, 0.28, 'หลังใช้ 6 เดือน', 10, P['acc'], 'md')
    shp(s, 'round', gx + 3.30, 1.36, 0.36, 0.16, P['acc'], adj=0.5)
    for i, (lab, a, b, unit) in enumerate(d['items'][:3]):
        y = 2.00 + i * 1.62
        txt(s, gx, y, gw, 0.34, lab, 13, P['ink'], 'md')
        mx = max(a, b)
        for j, (v, f) in enumerate(((a, mix(P['bg'], P['ink'], 0.16)), (b, P['acc']))):
            yy = y + 0.46 + j * 0.50
            bw = max((gw - 1.6) * v / mx, 0.5)
            shp(s, 'round', gx, yy, bw, 0.40, f, adj=0.5)
            txt(s, gx + bw + 0.14, yy, 1.5, 0.40, f'{v:g} {unit}', 11.5, P['ink'] if j == 0 else P['acc'], 'md', an='m')


@reg
def sb_growth(prs, d):
    s = page(prs)
    _bg(s)
    _chrome(s, d)
    _k(s, M, 1.22, d.get('k', ''))
    _h(s, M, 1.52, d['t'], 32, 8.0)
    shp(s, 'round', M, 2.40, 8.30, 4.40, mix(P['bg'], 'FFFFFF', 0.55), adj=0.05)
    n = len(d['vals'])
    chart(s, 'col', M + 0.20, 2.55, 7.90, 4.15, d['cats'], [(d['sname'], d['vals'])],
          [P['acc2']] * (n - 1) + [NAVY], labels=True, fmt='#,##0', gap=45, sz=10.5, c=P['mute'], vary=True)
    for i, (v, lab) in enumerate(d['items'][:3]):
        y = 1.15 + i * 1.92
        f = (P['acc'], NAVY, P['acc2'])[i]
        hc, bc = _on(f)
        _card(s, 9.20, y, 3.50, 1.74, f, 0.14)
        txt(s, 9.50, y + 0.22, 3.0, 0.70, v, 28, hc, 'md')
        _p(s, 9.50, y + 0.96, 3.0, lab, 10.5, bc)


@reg
def sb_bento(prs, d):
    s = page(prs)
    _bg(s)
    _chrome(s, d, nav=False)
    _k(s, M, 1.30, d.get('k', ''))
    _h(s, M, 1.62, d['t'], 34, 4.4)
    _p(s, M, 3.20, 4.1, d.get('note', ''), 11)
    _cubes(s, 1.30, 4.70, 0.62)
    it = d['items']
    spec = [(5.30, 1.15, 3.55, 2.70, P['acc']), (9.05, 1.15, 3.65, 1.65, NAVY),
            (9.05, 3.00, 3.65, 1.65, P['acc2']), (5.30, 4.05, 3.55, 2.75, NAVY)]
    for (v, lab), (x, y, w, h, f) in zip(it[:4], spec):
        hc, bc = _on(f)
        shp(s, 'round', x, y, w, h, f, adj=0.16)
        big = h > 2
        txt(s, x + 0.32, y + (0.40 if big else 0.22), w - 0.64, 0.80, v, 34 if big else 26, hc, 'md')
        _p(s, x + 0.32, y + (1.32 if big else 0.92), w - 0.64, lab, 10.5, bc)
    _photo(s, d.get('pi', 0), 9.05, 4.85, 3.65, 1.95, 0.22, d=d)


@reg
def sb_table(prs, d):
    s = page(prs)
    _bg(s)
    _chrome(s, d)
    _k(s, M, 1.18, d.get('k', ''))
    _h(s, M, 1.48, d['t'], 30, 9.0)
    cols = d['colw']; tw = W - M * 2; y0 = 2.62; rh = 0.74
    xs = [M]
    for f in cols[:-1]: xs.append(xs[-1] + tw * f)
    hi = 1
    _card(s, xs[hi] + 0.06, y0 - 0.16, tw * cols[hi] - 0.12, rh * (len(d['rows']) + 1) + 0.30, P['acc'], 0.06)
    for j, hd in enumerate(d['head']):
        txt(s, xs[j] + 0.20, y0, tw * cols[j] - 0.40, rh, hd, 12, 'FFFFFF' if j == hi else P['mute'], 'md',
            'l' if j == 0 else 'c', 'm')
    for i, row in enumerate(d['rows']):
        y = y0 + rh * (i + 1)
        ln(s, M, y, W - M, y, mix(P['bg'], P['ink'], 0.12), 0.7)
        for j, cell in enumerate(row):
            on = j == hi
            txt(s, xs[j] + 0.20, y, tw * cols[j] - 0.40, rh, cell, 11.5 if j else 12,
                'FFFFFF' if on else (P['ink'] if j == 0 else _body()), 'md' if (on or j == 0) else 'rg',
                'l' if j == 0 else 'c', 'm')


@reg
def sb_roadmap(prs, d):
    s = page(prs)
    _bg(s)
    _chrome(s, d)
    _k(s, 0, 1.12, d.get('k', ''), al='c', w=W)
    _h(s, 0, 1.40, d['t'], 32, W, al='c')
    y = 4.30
    shp(s, 'round', M, y - 0.09, W - M * 2, 0.18, mix(P['bg'], P['acc2'], 0.35), adj=0.5)
    shp(s, 'round', M, y - 0.09, (W - M * 2) * d.get('pct', 0.12), 0.18, P['acc'], adj=0.5)
    n = len(d['items'][:4]); cw = (W - M * 2) / n
    for i, (when, h_, body) in enumerate(d['items'][:4]):
        cx = M + cw * (i + 0.5)
        f = (P['acc'], P['acc2'], NAVY, P['acc'])[i]
        shp(s, 'oval', cx - 0.20, y - 0.20, 0.40, 0.40, f, line='FFFFFF', lw=3)
        up = i % 2 == 0
        cy = 2.30 if up else 4.80
        hc, bc = _on(f)
        _card(s, cx - cw / 2 + 0.12, cy, cw - 0.24, 1.70, f, 0.12)
        txt(s, cx - cw / 2 + 0.36, cy + 0.20, cw - 0.72, 0.28, when, 10.5, bc, 'md')
        txt(s, cx - cw / 2 + 0.36, cy + 0.50, cw - 0.72, 0.40, h_, 14, hc, 'md')
        _p(s, cx - cw / 2 + 0.36, cy + 0.92, cw - 0.72, body, 10, bc)
        ln(s, cx, cy + 1.70 if up else y + 0.20, cx, y - 0.20 if up else cy, f, 1.2)


@reg
def sb_funds(prs, d):
    s = page(prs)
    _bg(s)
    _chrome(s, d, nav=False)
    _k(s, M, 1.30, d.get('k', ''))
    _h(s, M, 1.62, d['t'], 32, 5.4)
    cols = [NAVY, P['acc'], P['acc2'], mix(P['bg'], P['acc2'], 0.42)]
    items = d['items'][:4]
    chart(s, 'donut', 0.90, 2.70, 4.30, 4.10, [i[0] for i in items], [('สัดส่วน', [i[1] for i in items])],
          cols, labels=False, hole=58)
    txt(s, 0.90, 4.30, 4.30, 0.56, d['big'], 26, P['ink'], 'md', 'c')
    txt(s, 0.90, 4.88, 4.30, 0.30, d['biglab'], 10.5, P['mute'], 'rg', 'c')
    for i, (lab, pct, amt, body) in enumerate(items):
        y = 1.15 + i * 1.42
        shp(s, 'round', 6.05, y, 6.65, 1.26, mix(P['bg'], 'FFFFFF', 0.6), adj=0.16)
        shp(s, 'round', 6.05, y, 0.16, 1.26, cols[i], adj=0.5)
        txt(s, 6.45, y + 0.18, 1.3, 0.60, f'{pct}%', 26, cols[i] if i < 3 else P['acc2'], 'md')
        txt(s, 7.85, y + 0.18, 3.0, 0.34, lab, 14, P['ink'], 'md')
        txt(s, 10.60, y + 0.18, 1.90, 0.34, amt, 13, P['acc'], 'md', 'r')
        _p(s, 7.85, y + 0.58, 4.65, body, 10.5)


@reg
def sb_quote(prs, d):
    s = page(prs)
    _bg(s)
    _chrome(s, d, nav=False)
    _photo(s, d.get('pi', 0), M, 1.15, 5.00, 5.65, 0.08, d=d)
    _card(s, 4.60, 4.95, 1.70, 1.50, P['acc'], 0.20)
    icon(s, 'quote', 5.45, 5.70, 0.62, 'FFFFFF')
    _k(s, 6.85, 1.40, d.get('k', ''))
    txt(s, 6.85, 1.80, 5.85, 3.0, d['t'], 22, P['ink'], 'md', sp=1.3)
    ln(s, 6.85, 5.10, 7.55, 5.10, P['acc'], 1.6)
    txt(s, 6.85, 5.30, 5.6, 0.36, d['who'], 14, P['ink'], 'md')
    _p(s, 6.85, 5.68, 5.6, d['role'], 11, P['mute'])
    _cone(s, 11.70, 5.60, 0.95, 160)
