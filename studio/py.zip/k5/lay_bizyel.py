"""20 เลย์เอาต์ชุด Business Proposal ขาว+เหลือง — ลอกโครงจากเทมเพลต Business Proposal (รูปขาวดำ 3D)

พื้นขาวนวล การ์ดมนมุมใหญ่สามสี: เหลืองสด เทาอ่อน ดำ หัวเรื่องตัวใหญ่มากสีดำ
หัวกระดาษสี่ช่องตัวเล็ก (บริษัท · ข้อเสนอ · เสนอต่อ · ปี) รูปทั้งชุดเป็นงาน 3D นามธรรมขาวดำ
ดอกจันเหลือง ป้ายแคปซูลขอบดำคู่ป้ายเหลือง
ตัวหนังสือบนเหลืองเป็นดำเสมอ (13.9) เหลืองใช้เป็นพื้นเท่านั้น ห้ามเป็นตัวหนังสือบนขาว
"""
from eng import *
import eng
from lay import L, reg

txt = txt_big        # ขนาดขั้นต่ำตามชุด 366 ดู eng.roomy()
chart = chart_big

M = 0.62
INK = '1A1A1A'
BLK = '1E1E1E'
GRY = 'E6E6E3'
MUTE = '5E5E5E'
SOFT = 'BDBDBD'        # เนื้อความบนดำ


def Y(): return P['acc']


def _duo(): return "duo:0E0E0E:F2F2F0"


def _photo(s, n, x, y, w, h, adj=0.10, focus=(0.5, 0.5), topic='mono3d', geom='roundRect'):
    return pic(s, ph(topic, n), x, y, w, h, geom=geom, adj=adj, focus=focus, mode=_duo())


def _chrome(s, d, dark=False):
    c = 'FFFFFF' if dark else INK
    m = SOFT if dark else MUTE
    shp(s, 'oval', M, 0.40, 0.11, 0.11, c)
    txt(s, M + 0.18, 0.31, 2.4, 0.28, d.get('brand', 'บริษัทของคุณ'), 9.5, c, 'bd')
    txt(s, 5.00, 0.28, 2.2, 0.50, 'ข้อเสนอโครงการ\n' + d.get('date', '8 ต.ค. 2570'), 8.5, m, 'rg', sp=1.1)
    txt(s, 7.70, 0.28, 2.4, 0.50, 'เสนอต่อ\n' + d.get('client', 'บริษัทลูกค้า'), 8.5, m, 'rg', sp=1.1)
    txt(s, W - M - 1.0, 0.31, 1.0, 0.28, d.get('yr', '2570'), 9.5, c, 'bd', 'r')


def _h(s, x, y, t, sz=46, w=7.0, c=None, al='l'):
    txt(s, x, y, w, 2.6, t, sz, c or INK, 'md', al, sp=0.98)


def _p(s, x, y, w, t, sz=11, c=None, al='l'):
    if t: txt(s, x, y, w, 2.0, t, sz, c or MUTE, 'rg', al, sp=1.36)


def _sub(s, x, y, w, t, sz=14, c=None):
    if t: txt(s, x, y, w, 1.2, t, sz, c or INK, 'md', sp=1.15)


def _card(s, x, y, w, h, f, adj=0.10):
    return shp(s, 'round', x, y, w, h, f, adj=adj)


def _on(f):
    """สีหัวเรื่อง/เนื้อความบนการ์ดแต่ละสี"""
    return ('FFFFFF', SOFT) if f == BLK else (INK, '3A3A10' if f == Y() else MUTE)


def _pills(s, x, y, a, b):
    w = len(a) * 0.10 + 0.40
    shp(s, 'round', x, y, w, 0.34, 'FFFFFF', line=INK, lw=0.8, adj=0.5)
    txt(s, x, y, w, 0.34, a, 9, INK, 'md', 'c', 'm')
    w2 = len(b) * 0.10 + 0.34
    shp(s, 'round', x + w + 0.08, y, w2, 0.34, Y(), adj=0.5)
    txt(s, x + w + 0.08, y, w2, 0.34, b, 9, INK, 'md', 'c', 'm')


def _aster(s, cx, cy, sz, c=None):
    c = c or Y()
    for a in (0, 60, 120):
        shp(s, 'round', cx - sz * 0.09, cy - sz / 2, sz * 0.18, sz, c, adj=0.5, rot=a)


# ══ เลย์เอาต์ตามรูปอ้างอิง ═════════════════════════════════════════════════

@reg
def by_cover(prs, d):
    s = page(prs)
    _chrome(s, d)
    txt(s, M, 1.30, 3.9, 1.2, '', 13, INK, 'md', sp=1.2,
        runs=[[(w, {'c': INK if i % 2 else MUTE}) for i, w in enumerate(line)] for line in d['tag']])
    for i, (v, lab) in enumerate(d['items'][:2]):
        x = M + i * 1.95
        txt(s, x, 2.75, 1.9, 0.55, v, 24, INK, 'md')
        txt(s, x, 3.30, 1.9, 0.28, lab, 9.5, MUTE, 'rg')
    _h(s, 4.55, 1.05, d['t'], 58, 8.2, al='r')
    _photo(s, d.get('pi', 16), M, 4.20, W - M * 2, 2.70, 0.08, (0.5, 0.45))
    shp(s, 'round', M, 4.20, W - M * 2, 2.70, BLK, a=0.55, adj=0.08)
    shp(s, 'round', M + 0.30, 4.45, 1.70, 0.36, None, line='FFFFFF', lw=0.8, adj=0.5)
    txt(s, M + 0.30, 4.45, 1.70, 0.36, d.get('k', 'ข้อเสนอโครงการ'), 9, 'FFFFFF', 'md', 'c', 'm')
    _aster(s, W - M - 0.55, 4.70, 0.55)
    _sub(s, M + 0.30, 5.85, 4.5, d['s'], 17, 'FFFFFF')
    for i, t in enumerate(d.get('notes', [])[:2]):
        _p(s, 6.40 + i * 3.10, 5.85, 2.8, t, 10.5, 'E0E0E0')


@reg
def by_agenda(prs, d):
    s = page(prs)
    _chrome(s, d)
    cw = (W - M * 2 - 0.45) / 4
    fills = [Y(), GRY, BLK, GRY]
    for i, (h_, body, when, big) in enumerate(d['items'][:4]):
        x = M + i * (cw + 0.15)
        f = fills[i]
        _card(s, x, 1.05, cw, 5.90, f, 0.09)
        if f == BLK:
            _photo(s, d.get('pi', 2), x, 1.05, cw, 5.90, 0.09)
            shp(s, 'round', x, 1.05, cw, 5.90, BLK, a=0.60, adj=0.09)
        hc, bc = _on(f)
        _sub(s, x + 0.30, 1.35, cw - 0.6, h_, 15, hc)
        _p(s, x + 0.30, 1.95, cw - 0.6, body, 10.5, bc)
        txt(s, x + 0.30, 3.25, cw - 0.6, 0.30, when, 10, hc, 'md')
        txt(s, x + 0.30, 5.40, cw - 0.6, 0.90, big, 34, hc, 'md')
        ln(s, x + 0.30, 6.45, x + cw - 0.30, 6.45, hc, 1.4)


@reg
def by_intro(prs, d):
    s = page(prs)
    _chrome(s, d)
    _photo(s, d.get('pi', 6), M, 1.05, 2.90, 2.85, 0.0, geom='round2SameRect')
    _photo(s, d.get('pi2', 4), M, 4.05, 2.90, 2.85, 0.0, geom='round2SameRect')
    s.shapes[-1].rotation = 180
    _h(s, 3.95, 1.25, d['t'], 50, 9.0)
    _sub(s, 3.95, 3.35, 3.2, d['s'], 16)
    for i, t in enumerate(d.get('notes', [])[:2]):
        _p(s, 7.40, 3.35 + i * 1.30, 5.3, t, 11)
    _pills(s, 3.95, 5.95, d.get('k', 'ข้อเสนอโครงการ'), d.get('yr', '2570'))


@reg
def by_exec(prs, d):
    s = page(prs)
    _chrome(s, d)
    _h(s, M, 1.10, d['t'], 50, 6.6)
    _photo(s, d.get('pi', 14), M, 3.95, 3.70, 2.95, 0.10)
    shp(s, 'round', M + 0.20, 6.10, 0.62, 0.62, BLK, adj=0.2)
    _aster(s, M + 0.51, 6.41, 0.40)
    _sub(s, 7.30, 1.30, 5.4, d['k'], 16)
    _p(s, 7.30, 1.80, 5.4, d.get('note', ''), 11)
    for i, (h_, body) in enumerate(d['items'][:2]):
        y = 4.00 + i * 1.50
        _sub(s, 4.60, y, 2.5, h_, 15)
        _p(s, 7.30, y, 5.4, body, 11)
        if i == 0: ln(s, 4.60, y + 1.25, W - M, y + 1.25, GRY, 1)


@reg
def by_solution(prs, d):
    s = page(prs)
    _chrome(s, d)
    _card(s, -0.3, 1.05, 2.20, 5.90, BLK, 0.08)
    _photo(s, d.get('pi', 13), 0, 1.05, 1.90, 5.90, 0.0, (0.5, 0.5), geom=None)
    fills = [BLK, Y(), GRY]
    for i, (tag, h_, body) in enumerate(d['items'][:3]):
        y = 1.05 + i * 2.00
        f = fills[i]
        _card(s, 2.10, y, 4.30, 1.85, f, 0.10)
        hc, bc = _on(f)
        txt(s, 2.40, y + 0.25, 0.9, 0.30, tag, 10, hc, 'md')
        _sub(s, 3.20, y + 0.22, 3.0, h_, 13.5, hc)
        _p(s, 3.20, y + 0.95, 3.0, body, 10.5, bc)
    _pills(s, 6.90, 2.10, d.get('k', 'ทางออก'), d.get('yr', '2570'))
    _h(s, 6.90, 2.65, d['t'], 48, 6.0)
    _p(s, 6.90, 4.55, 5.8, d.get('note', ''), 11)


@reg
def by_vision(prs, d):
    s = page(prs)
    _chrome(s, d)
    _photo(s, d.get('pi', 3), M, 1.05, 4.90, 2.70, 0.10, (0.5, 0.4))
    for i, (h_, body) in enumerate(d['items'][:2]):
        x = 5.70 + i * 3.55
        f = GRY if i == 0 else Y()
        _card(s, x, 1.05, 3.40, 2.70, f, 0.10)
        hc, bc = _on(f)
        txt(s, x + 0.28, 1.30, 1.0, 0.28, f'(เป้า {i + 1})', 10, hc, 'md')
        _sub(s, x + 0.28, 1.65, 2.8, h_, 15, hc)
        _p(s, x + 0.28, 2.55, 2.8, body, 10.5, bc)
    _h(s, M, 4.20, d['t'], 48, 9.0)
    shp(s, 'round', 10.90, 4.75, 1.20, 1.20, BLK, adj=0.15)
    _aster(s, 11.50, 5.35, 0.70)


@reg
def by_market(prs, d):
    s = page(prs)
    _chrome(s, d)
    _photo(s, d.get('pi', 18), 6.70, 1.05, W - M - 6.70, 3.10, 0.12, (0.5, 0.4))
    for i, (h_, body) in enumerate(d['items'][:2]):
        x = M + i * 3.35
        f = Y() if i == 0 else GRY
        _card(s, x, 1.55, 3.20, 2.60, f, 0.10)
        hc, bc = _on(f)
        txt(s, x + 0.28, 1.80, 1.2, 0.28, f'(ปัญหา {i + 1})', 10, hc, 'md')
        _sub(s, x + 0.28, 2.15, 2.7, h_, 14, hc)
        _p(s, x + 0.28, 3.00, 2.7, body, 10.5, bc)
    _h(s, M, 4.40, d['t'], 46, 9.0)
    _p(s, M, 6.25, 8.0, d.get('note', ''), 11)


@reg
def by_product(prs, d):
    s = page(prs)
    _chrome(s, d)
    _h(s, M, 1.30, d['t'], 50, 6.2)
    txt(s, M, 3.70, 1.6, 0.28, d.get('k', ''), 9.5, MUTE, 'rg')
    _sub(s, 2.30, 3.60, 4.6, d['s'], 16)
    _p(s, 2.30, 4.80, 4.6, d.get('note', ''), 11)
    x, y, w, h = 7.60, 1.05, 3.40, 6.10
    shp(s, 'round', x, y, w, h, '111111', adj=0.13)
    _photo(s, d.get('pi', 2), x + 0.16, y + 0.16, w - 0.32, h - 0.32, 0.11, (0.5, 0.6))
    shp(s, 'round', x + w / 2 - 0.55, y + 0.30, 1.10, 0.24, '111111', adj=0.5)
    _card(s, 10.25, 3.10, 2.45, 2.90, Y(), 0.12)
    txt(s, 10.45, 3.30, 2.1, 0.60, d['big'], 28, INK, 'md')
    txt(s, 10.45, 3.95, 2.1, 0.28, d['biglab'], 9.5, INK, 'md')
    _photo(s, d.get('pi2', 1), 10.45, 4.40, 2.05, 1.40, 0.10)


# ══ อีก 12 เลย์เอาต์ในระบบเดียวกัน ════════════════════════════════════════

@reg
def by_div_black(prs, d):
    s = page(prs, BLK)
    _photo(s, d.get('pi', 8), 6.60, 0.90, W - M - 6.60, 6.00, 0.08, (0.5, 0.5))
    _chrome(s, d, True)
    _pills(s, M, 2.20, d.get('k', ''), d.get('yr', '2570'))
    _h(s, M, 2.65, d['t'], 48, 6.0, 'FFFFFF')
    _p(s, M, 5.35, 5.4, d.get('note', ''), 12, SOFT)
    _aster(s, W - M - 0.40, 1.25, 0.55)


@reg
def by_div_yellow(prs, d):
    s = page(prs)
    _chrome(s, d)
    _card(s, M, 1.05, W - M * 2, 5.90, Y(), 0.06)
    _h(s, M + 0.55, 1.60, d['t'], 60, 8.5)
    _p(s, M + 0.55, 4.35, 6.0, d.get('note', ''), 13, '3A3A10')
    _photo(s, d.get('pi', 19), 9.20, 1.45, 3.10, 5.10, 0.10)
    txt(s, M + 0.55, 6.15, 4.0, 0.36, d.get('k', ''), 12, INK, 'md')


@reg
def by_stats(prs, d):
    s = page(prs)
    _chrome(s, d)
    _h(s, M, 1.10, d['t'], 44, 8.0)
    cw = (W - M * 2 - 0.45) / 4
    fills = [GRY, BLK, Y(), GRY]
    for i, (v, lab, body) in enumerate(d['items'][:4]):
        x = M + i * (cw + 0.15)
        f = fills[i]
        _card(s, x, 2.85, cw, 4.05, f, 0.09)
        hc, bc = _on(f)
        txt(s, x + 0.30, 3.15, cw - 0.6, 0.90, v, 38, hc, 'md')
        _sub(s, x + 0.30, 4.20, cw - 0.6, lab, 14, hc)
        _p(s, x + 0.30, 4.95, cw - 0.6, body, 10.5, bc)


@reg
def by_chart_bar(prs, d):
    s = page(prs)
    _chrome(s, d)
    _h(s, M, 1.10, d['t'], 42, 5.0)
    _p(s, M, 3.05, 4.6, d.get('note', ''), 11)
    _card(s, M, 4.55, 4.60, 2.35, BLK, 0.10)
    txt(s, M + 0.30, 4.80, 4.0, 0.80, d['big'], 36, Y(), 'md')
    _p(s, M + 0.30, 5.70, 4.0, d['biglab'], 10.5, SOFT)
    _card(s, 5.65, 1.05, W - M - 5.65, 5.85, 'FFFFFF', 0.06)
    n = len(d['vals'])
    chart(s, 'bar', 5.90, 1.30, W - M - 6.15, 5.40, d['cats'], [(d['sname'], d['vals'])],
          [Y()] + [GRY] * (n - 1), labels=True, fmt='0"%"', gap=45, sz=12, c=INK, vary=True)


@reg
def by_chart_line(prs, d):
    s = page(prs)
    _chrome(s, d)
    _h(s, M, 1.10, d['t'], 42, 7.6)
    _card(s, M, 2.45, 8.20, 4.45, 'FFFFFF', 0.06)
    chart(s, 'line', M + 0.20, 2.65, 7.80, 4.10, d['cats'], [(d['sname'], d['vals'])], [INK], labels=True,
          fmt='#,##0', sz=11, c=INK, lw=3, minv=0)
    for i, (v, lab) in enumerate(d['items'][:2]):
        y = 2.45 + i * 2.30
        f = Y() if i == 0 else BLK
        _card(s, 9.05, y, W - M - 9.05, 2.15, f, 0.10)
        hc, bc = _on(f)
        txt(s, 9.35, y + 0.25, 3.0, 0.70, v, 32, hc, 'md')
        _p(s, 9.35, y + 1.05, 3.0, lab, 10.5, bc)


@reg
def by_budget(prs, d):
    s = page(prs)
    _chrome(s, d)
    _h(s, M, 1.10, d['t'], 42, 6.0)
    cols = [Y(), BLK, '8C8C8A', 'D2D2CE']
    it = d['items'][:4]
    chart(s, 'donut', 0.70, 2.45, 4.50, 4.50, [x[0] for x in it], [('บาท', [x[1] for x in it])], cols, labels=False, hole=60)
    txt(s, 0.70, 4.35, 4.50, 0.55, d['big'], 26, INK, 'md', 'c')
    txt(s, 0.70, 4.90, 4.50, 0.28, d['biglab'], 10, MUTE, 'rg', 'c')
    for i, (lab, v, pct, body) in enumerate(it):
        y = 2.35 + i * 1.15
        _card(s, 5.85, y, W - M - 5.85, 1.02, GRY if i else Y(), 0.18)
        shp(s, 'oval', 6.10, y + 0.38, 0.26, 0.26, cols[i], line=INK if i == 0 else None, lw=0.8)
        _sub(s, 6.55, y + 0.12, 3.5, lab, 13)
        _p(s, 6.55, y + 0.55, 3.8, body, 10.5, '3A3A10' if i == 0 else MUTE)
        txt(s, 10.20, y + 0.12, 1.40, 0.80, f'{v:,}', 15, INK, 'md', 'r', 'm')
        txt(s, 11.65, y + 0.12, 0.85, 0.80, f'{pct}%', 13, INK, 'md', 'r', 'm')


@reg
def by_packages(prs, d):
    s = page(prs)
    _chrome(s, d)
    _h(s, M, 1.10, d['t'], 42, 9.0)
    cw = (W - M * 2 - 0.40) / 3
    for i, (name, price, rec, items) in enumerate(d['items'][:3]):
        x = M + i * (cw + 0.20)
        f = BLK if rec else GRY
        _card(s, x, 2.30, cw, 4.60, f, 0.08)
        hc, bc = _on(f)
        if rec:
            shp(s, 'round', x + cw - 1.65, 2.55, 1.40, 0.34, Y(), adj=0.5)
            txt(s, x + cw - 1.65, 2.55, 1.40, 0.34, 'แนะนำ', 9.5, INK, 'md', 'c', 'm')
        _sub(s, x + 0.30, 2.55, cw - 2.0, name, 15, hc)
        txt(s, x + 0.30, 3.15, cw - 0.6, 0.70, price, 30, Y() if rec else INK, 'md')
        ln(s, x + 0.30, 4.05, x + cw - 0.30, 4.05, SOFT if rec else '9A9A98', 0.8)
        for k, t in enumerate(items[:4]):
            shp(s, 'oval', x + 0.32, 4.33 + k * 0.58, 0.12, 0.12, Y() if rec else INK)
            _p(s, x + 0.55, 4.20 + k * 0.58, cw - 0.85, t, 10.5, bc)


@reg
def by_timeline(prs, d):
    s = page(prs)
    _chrome(s, d)
    _h(s, M, 1.10, d['t'], 42, 9.0)
    n = len(d['items'][:4]); cw = (W - M * 2) / n
    shp(s, 'round', M, 3.05, W - M * 2, 0.12, GRY, adj=0.5)
    for i, (when, h_, body) in enumerate(d['items'][:4]):
        x = M + i * cw
        hot = i == 0
        shp(s, 'oval', x, 2.93, 0.36, 0.36, Y() if hot else BLK, line=INK if hot else None, lw=1)
        _card(s, x, 3.60, cw - 0.20, 3.30, Y() if hot else GRY, 0.09)
        txt(s, x + 0.28, 3.85, cw - 0.7, 0.30, when, 10.5, INK, 'md')
        _sub(s, x + 0.28, 4.25, cw - 0.7, h_, 15)
        _p(s, x + 0.28, 5.05, cw - 0.7, body, 10.5, '3A3A10' if hot else MUTE)


@reg
def by_team(prs, d):
    s = page(prs)
    _chrome(s, d)
    _h(s, M, 1.10, d['t'], 42, 8.0)
    cw = (W - M * 2 - 0.45) / 4
    for i, (name, role, body, pi, fx) in enumerate(d['items'][:4]):
        x = M + i * (cw + 0.15)
        _card(s, x, 2.30, cw, 4.60, GRY, 0.08)
        _photo(s, pi, x + 0.18, 2.48, cw - 0.36, 2.40, 0.08, (fx, 0.3), topic='office')
        _sub(s, x + 0.28, 5.05, cw - 0.56, name, 14)
        shp(s, 'round', x + 0.28, 5.50, len(role) * 0.095 + 0.36, 0.32, Y() if i == 0 else 'FFFFFF', adj=0.5)
        txt(s, x + 0.28, 5.50, len(role) * 0.095 + 0.36, 0.32, role, 9.5, INK, 'md', 'c', 'm')
        _p(s, x + 0.28, 5.95, cw - 0.56, body, 10.5)


@reg
def by_quote(prs, d):
    s = page(prs, BLK)
    _chrome(s, d, True)
    _photo(s, d.get('pi', 7), M, 1.05, 4.40, 5.85, 0.08)
    _aster(s, 5.80, 1.70, 0.70)
    txt(s, 5.65, 2.40, 7.0, 3.0, d['t'], 22, 'FFFFFF', 'md', sp=1.3)
    ln(s, 5.65, 5.55, 6.45, 5.55, Y(), 2)
    _sub(s, 5.65, 5.75, 6.5, d['who'], 15, 'FFFFFF')
    _p(s, 5.65, 6.15, 6.8, d['role'], 11, SOFT)


@reg
def by_next(prs, d):
    s = page(prs)
    _chrome(s, d)
    _h(s, M, 1.10, d['t'], 46, 6.2)
    _p(s, M, 3.25, 5.4, d.get('note', ''), 11.5)
    for i, (h_, body) in enumerate(d['items'][:3]):
        y = 1.05 + i * 1.98
        f = [Y(), GRY, BLK][i]
        _card(s, 7.10, y, W - M - 7.10, 1.82, f, 0.12)
        hc, bc = _on(f)
        txt(s, 7.40, y + 0.25, 1.2, 0.30, f'(ขั้น {i + 1})', 10, hc, 'md')
        _sub(s, 7.40, y + 0.60, 4.9, h_, 15, hc)
        _p(s, 7.40, y + 1.10, 4.9, body, 10.5, bc)
    _photo(s, d.get('pi', 9), M, 4.40, 5.60, 2.50, 0.10, topic='mono3d')


@reg
def by_close(prs, d):
    s = page(prs)
    _chrome(s, d)
    _h(s, M, 1.10, d['t'], 64, 9.0)
    _p(s, M, 3.40, 6.0, d.get('note', ''), 13)
    _photo(s, d.get('pi', 15), M, 4.50, W - M * 2, 2.40, 0.08, (0.5, 0.5))
    shp(s, 'round', M, 4.50, W - M * 2, 2.40, BLK, a=0.62, adj=0.08)
    for i, (lab, v) in enumerate(d['items'][:3]):
        x = M + 0.40 + i * 3.80
        txt(s, x, 5.05, 3.5, 0.28, lab, 10, 'E0E0E0', 'rg')
        _sub(s, x, 5.38, 3.6, v, 15, 'FFFFFF')
    _aster(s, W - M - 0.70, 1.60, 0.90)
