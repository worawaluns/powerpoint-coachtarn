"""40 slide layouts. Each L[name](prs, d) renders one slide from a content dict.
d: t=title k=kicker s=sub items=[...] cats/vals=chart data note topic/pi=photo n=page foot=footer"""
from eng import *
import eng

L = {}
def reg(f): L[f.__name__] = f; return f
def _ft(s, d): footer(s, d.get('foot', ''), f"{d.get('n','')}" if d.get('n') else '')

# ══ COVERS ═════════════════════════════════════════════════════════════════
@reg
def cov_photo_full(prs, d):
    s = page(prs)
    pic(s, ph(d['topic'], d.get('pi', 0)), 0, 0, W, H, focus=(0.5, 0.38))
    shp(s, 'rect', 0, 0, W, H, '000000', a=0.42)
    gradband(s, 0, H * 0.45, W, H * 0.55, 90, a1=0.0, a2=0.92)
    eyebrow(s, 0.85, 0.9, d.get('k', ''), 'FFFFFF')
    txt(s, 0.85, H - 3.5, 11.2, 2.0, d['t'], d.get('tsz', 58), 'FFFFFF', 'bd', sp=1.02)
    if d.get('s'): txt(s, 0.85, H - 1.55, 8.6, 0.8, d['s'], 14, 'E9E9F2', sp=1.35)
    for i, (v, lb) in enumerate(d.get('stats', [])[:3]):
        x = 8.4 + i * 1.65
        txt(s, x, H - 1.65, 1.6, 0.5, v, 24, 'FFFFFF', 'bd'); txt(s, x, H - 1.12, 1.6, 0.4, lb, 9.5, 'D6D6E4')

@reg
def cov_split_grad(prs, d):
    s = page(prs)
    gradband(s, 0, 0, W * 0.56, H, 300)
    grid(s, 0.7, 'FFFFFF', 0.8, 0, 0, W * 0.56, H)
    pic(s, ph(d['topic'], d.get('pi', 1)), W * 0.56, 0, W * 0.44, H, focus=(0.5, 0.4))
    eyebrow(s, 0.9, 0.85, d.get('k', ''), 'FFFFFF')
    txt(s, 0.9, 2.1, 6.2, 2.4, d['t'], d.get('tsz', 46), 'FFFFFF', 'bd', sp=1.08)
    if d.get('s'): txt(s, 0.9, 4.9, 5.6, 1.0, d['s'], 13.5, 'F2F2FF', sp=1.4)
    txt(s, 0.9, H - 1.0, 6, 0.4, d.get('foot', ''), 10.5, 'E6E6FF', track=1)

@reg
def cov_glow_center(prs, d):
    s = page(prs, P['bg'])
    glow(s, W / 2, H * 0.72, 5.4, P['g2'], 0.5); glow(s, W * 0.22, H * 0.2, 3.4, P['g1'], 0.35)
    grid(s, 0.74, a=0.5)
    pill(s, W / 2 - 1.5, 0.95, 3.0, 0.42, d.get('k', ''), mix(P['bg'], P['acc'], 0.25), P['ink'], 10.5)
    txt(s, 1.1, 2.15, 11.1, 2.3, d['t'], d.get('tsz', 54), P['ink'], 'bd', 'c', sp=1.05)
    if d.get('s'): txt(s, 2.6, 4.6, 8.1, 0.9, d['s'], 14, P['mute'], 'rg', 'c', sp=1.4)
    for i, (v, lb) in enumerate(d.get('stats', [])[:3]):
        x = 2.1 + i * 3.1
        card(s, x, 5.7, 2.8, 1.1, mix(P['bg'], P['ink'], 0.06), adj=0.18)
        txt(s, x, 5.82, 2.8, 0.5, v, 22, P['acc'], 'bd', 'c'); txt(s, x, 6.38, 2.8, 0.3, lb, 9.5, P['mute'], 'rg', 'c')

@reg
def cov_grid_left(prs, d):
    s = page(prs)
    shp(s, 'rect', 0, 0, W, H, P['panel'])
    photo_wash(s, d['topic'], d.get('pi', 2), 6.9, 0, 6.44, H, a=1.0)
    gradband(s, 6.9, 0, 6.44, H, 0, a1=0.75, a2=0.0)
    eyebrow(s, 0.8, 1.0, d.get('k', ''))
    txt(s, 0.8, 1.7, 5.9, 2.6, d['t'], d.get('tsz', 44), P['ink'], 'bd', sp=1.08)
    if d.get('s'): txt(s, 0.8, 4.5, 5.4, 1.1, d['s'], 13, P['mute'], sp=1.45)
    ln(s, 0.8, 5.9, 6.2, 5.9, mix(P['bg'], P['mute'], 0.4), 0.75)
    txt(s, 0.8, 6.1, 6, 0.4, d.get('foot', ''), 10.5, P['mute'], track=1)

@reg
def cov_card_stack(prs, d):
    s = page(prs)
    gradband(s, 0, 0, W, H, 315, a1=1, a2=1)
    for i in range(3):
        shp(s, 'round', 7.3 + i * 0.42, 1.5 + i * 0.5, 4.6, 4.2 - i * 0.4, 'FFFFFF', a=0.12 + i * 0.06, adj=0.07)
    pic(s, ph(d['topic'], d.get('pi', 3)), 8.0, 2.4, 4.4, 3.2, geom='roundRect', adj=0.06)
    txt(s, 0.9, 1.35, 6.4, 0.4, d.get('k', ''), 11, 'FFFFFF', 'md', track=1.4)
    txt(s, 0.9, 2.0, 6.5, 2.6, d['t'], d.get('tsz', 46), 'FFFFFF', 'bd', sp=1.06)
    if d.get('s'): txt(s, 0.9, 4.85, 5.9, 1.0, d['s'], 13.5, 'F0F0FF', sp=1.4)
    txt(s, 0.9, H - 1.0, 6, 0.4, d.get('foot', ''), 10.5, 'EAEAFF', track=1)

@reg
def cov_band_bottom(prs, d):
    s = page(prs)
    pic(s, ph(d['topic'], d.get('pi', 4)), 0, 0, W, 4.45, focus=(0.5, 0.42))
    shp(s, 'rect', 0, 0, W, 4.45, P['bg'], a=0.25)
    shp(s, 'rect', 0, 4.45, W, H - 4.45, P['bg'])
    gradband(s, 0, 4.4, W, 0.1, 0)
    txt(s, 0.85, 4.9, 8.4, 1.6, d['t'], d.get('tsz', 42), P['ink'], 'bd', sp=1.05)
    if d.get('s'): txt(s, 0.85, 6.35, 7.4, 0.6, d['s'], 12.5, P['mute'])
    for i, (v, lb) in enumerate(d.get('stats', [])[:3]):
        x = 9.55 + 0; y = 4.85 + i * 0.78
        txt(s, x, y, 1.9, 0.44, v, 19, P['acc'], 'bd', 'r'); txt(s, x + 2.0, y + 0.08, 1.8, 0.4, lb, 10, P['mute'])

# ══ AGENDA / INTRO ═════════════════════════════════════════════════════════
@reg
def agenda_list(prs, d):
    s = page(prs); _ft(s, d)
    eyebrow(s, 0.8, 0.75, d.get('k', 'สารบัญ'))
    txt(s, 0.8, 1.2, 6, 0.9, d['t'], 34, P['ink'], 'bd')
    if d.get('s'): txt(s, 0.8, 2.25, 4.6, 1.6, d['s'], 12.5, P['mute'], sp=1.5)
    photo_wash(s, d['topic'], d.get('pi', 5), 0.8, 4.2, 4.6, 2.3, a=0.85, geom='roundRect', adj=0.08)
    for i, it in enumerate(d['items'][:6]):
        y = 1.15 + i * 0.93
        txt(s, 6.2, y, 0.8, 0.5, f'{i+1:02d}', 18, mix(P['bg'], P['acc'], 0.65), 'bd')
        txt(s, 7.0, y + 0.02, 5.4, 0.5, it[0] if isinstance(it, (list, tuple)) else it, 16, P['ink'], 'md')
        if isinstance(it, (list, tuple)) and len(it) > 1:
            txt(s, 7.0, y + 0.42, 5.4, 0.4, it[1], 10.5, P['mute'])
        ln(s, 6.2, y + 0.82, 12.5, y + 0.82, mix(P['bg'], P['mute'], 0.28), 0.5)

@reg
def agenda_cards(prs, d):
    s = page(prs); _ft(s, d)
    txt(s, 0.8, 0.8, 7, 1.0, d['t'], 32, P['ink'], 'bd')
    if d.get('s'): txt(s, 8.2, 0.95, 4.4, 0.8, d['s'], 11.5, P['mute'], 'rg', 'r', sp=1.4)
    for i, it in enumerate(d['items'][:6]):
        x = 0.8 + (i % 3) * 4.05; y = 2.2 + (i // 3) * 2.25
        on = i == d.get('hi', 0)
        if on: gradband(s, x, y, 3.8, 2.0, 315, kind='round', adj=0.08)
        else: card(s, x, y, 3.8, 2.0, adj=0.08)
        c = 'FFFFFF' if on else P['ink']
        txt(s, x + 0.4, y + 0.32, 0.8, 0.4, f'{i+1:02d}', 13, 'FFFFFF' if on else P['acc'], 'bd')
        txt(s, x + 0.4, y + 0.78, 3.0, 0.5, it[0] if isinstance(it, (list, tuple)) else it, 15, c, 'md', sp=1.15)
        if isinstance(it, (list, tuple)) and len(it) > 1:
            txt(s, x + 0.4, y + 1.42, 3.0, 0.4, it[1], 10, 'EFEFFF' if on else P['mute'])

@reg
def agenda_num_grid(prs, d):
    s = page(prs); _ft(s, d)
    gradband(s, 0, 0, 0.16, H, 90)
    txt(s, 0.9, 0.85, 6.5, 0.8, d['t'], 30, P['ink'], 'bd')
    for i, it in enumerate(d['items'][:8]):
        x = 0.9 + (i % 2) * 6.1; y = 2.0 + (i // 2) * 1.2
        txt(s, x, y, 1.0, 0.7, f'{i+1:02d}', 30, mix(P['bg'], P['acc'], 0.5), 'bd')
        txt(s, x + 1.05, y + 0.06, 4.7, 0.5, it[0] if isinstance(it, (list, tuple)) else it, 14.5, P['ink'], 'md')
        if isinstance(it, (list, tuple)) and len(it) > 1: txt(s, x + 1.05, y + 0.5, 4.7, 0.4, it[1], 10, P['mute'])

@reg
def agenda_timeline(prs, d):
    s = page(prs); _ft(s, d)
    txt(s, 0.8, 0.8, 8, 0.9, d['t'], 31, P['ink'], 'bd')
    if d.get('s'): txt(s, 0.8, 1.75, 8.4, 0.5, d['s'], 12, P['mute'])
    y = 4.2; ln(s, 1.0, y, 12.4, y, mix(P['bg'], P['mute'], 0.35), 1)
    n = len(d['items'][:5])
    for i, it in enumerate(d['items'][:5]):
        x = 1.0 + i * (11.4 / max(n - 1, 1))
        gradband(s, x - 0.19, y - 0.19, 0.38, 0.38, 0, kind='oval')
        up = i % 2 == 0
        ty = y - 1.5 if up else y + 0.45
        txt(s, x - 1.3, ty, 2.6, 0.45, it[0] if isinstance(it, (list, tuple)) else it, 13.5, P['ink'], 'md', 'c')
        if isinstance(it, (list, tuple)) and len(it) > 1:
            txt(s, x - 1.3, ty + 0.44, 2.6, 0.7, it[1], 10, P['mute'], 'rg', 'c', sp=1.3)

# ══ STATS ══════════════════════════════════════════════════════════════════
@reg
def stat_hero(prs, d):
    s = page(prs); _ft(s, d)
    photo_wash(s, d['topic'], d.get('pi', 6), 6.6, 0, 6.73, H, a=0.9)
    gradband(s, 6.6, 0, 3.0, H, 0, a1=0.9, a2=0.0)
    # เดิมไม่เคยอ่าน d['items'] เลย ข้อมูล 4 แถวใน 29 สไลด์ทั่วคลังหายไปเงียบ ๆ
    it = [i for i in d.get('items', []) if isinstance(i, (list, tuple)) and len(i) >= 2][:4]
    if it:
        shp(s, 'rect', 7.3, 0, W - 7.3, H, '0A0A0C', a=0.76)
        gap = (H - 1.7) / len(it)
        for i, row in enumerate(it):
            y = 0.9 + i * gap
            if i: ln(s, 7.9, y - 0.26, W - 0.8, y - 0.26, mix('FFFFFF', '000000', 0.58), 0.6)
            txt(s, 7.9, y, 2.6, 0.46, row[0], 23, 'FFFFFF', 'bd', sp=0.92)
            txt(s, 7.9, y + 0.5, 4.7, 0.28, row[1], 10.5, 'E9EDF4', 'md', sp=1.2)
            if len(row) > 2: txt(s, 7.9, y + 0.82, 4.7, 0.28, row[2], 9, 'C5CCD9', sp=1.25)
    eyebrow(s, 0.8, 0.9, d.get('k', ''))
    txt(s, 0.8, 1.5, 5.6, 1.4, d['t'], 26, P['ink'], 'bd', sp=1.15)
    txt(s, 0.75, 2.9, 5.8, 1.8, d['big'], fit_sz(d['big'], 5.6, 96), P['acc'], 'bd', sp=0.9)
    txt(s, 0.8, 4.72, 5.4, 1.0, d.get('biglab', ''), 13.5, P['ink'], 'md', sp=1.35)
    if d.get('s'): txt(s, 0.8, 5.82, 5.2, 0.9, d['s'], 11.5, P['mute'], sp=1.4)

@reg
def stat_trio(prs, d):
    s = page(prs); _ft(s, d)
    txt(s, 0.8, 0.8, 8.4, 0.9, d['t'], 30, P['ink'], 'bd')
    if d.get('s'): txt(s, 0.8, 1.75, 9, 0.5, d['s'], 12, P['mute'])
    for i, (v, lb, sub) in enumerate(d['items'][:3]):
        x = 0.8 + i * 4.05
        card(s, x, 2.6, 3.8, 3.2, mix(P['bg'], P['ink'], 0.05) if not P['dark'] else P['panel'], adj=0.07)
        gradband(s, x, 2.6, 3.8, 0.1, 0, kind='rect')
        txt(s, x + 0.45, 3.1, 3.0, 1.2, v, fit_w(v, 3.0, 52, 26), P['acc'], 'bd', sp=0.95)
        txt(s, x + 0.45, 4.3, 3.0, 0.5, lb, 14, P['ink'], 'md')
        txt(s, x + 0.45, 4.85, 3.0, 0.8, sub, 10.5, P['mute'], sp=1.35)

@reg
def stat_waffle(prs, d):
    s = page(prs); _ft(s, d)
    txt(s, 0.8, 0.85, 6.2, 1.5, d['t'], 28, P['ink'], 'bd', sp=1.15)
    if d.get('s'): txt(s, 0.8, 2.5, 5.4, 1.4, d['s'], 12, P['mute'], sp=1.5)
    txt(s, 0.8, 4.2, 4, 1.0, d['big'], fit_sz(d['big'], 3.9, 66), P['acc'], 'bd')
    txt(s, 0.8, 5.35, 5.2, 0.5, d.get('biglab', ''), 12.5, P['ink'], 'md')
    waffle(s, 7.3, 1.5, d['pct'], 10, 10, 0.42, 0.34)
    txt(s, 7.3, 6.0, 5, 0.4, d.get('note', ''), 10.5, P['mute'])

@reg
def stat_rings(prs, d):
    s = page(prs); _ft(s, d)
    txt(s, 0.8, 0.85, 8, 0.9, d['t'], 29, P['ink'], 'bd')
    if d.get('s'): txt(s, 0.8, 1.8, 8.6, 0.5, d['s'], 12, P['mute'])
    for i, (pct, lb, sub) in enumerate(d['items'][:4]):
        cx = 2.1 + i * 3.1
        donut_ring(s, cx, 4.0, 2.0, pct, f'{pct}%', '', P['acc'] if i % 2 == 0 else P['acc2'])
        txt(s, cx - 1.5, 5.25, 3.0, 0.4, lb, 13, P['ink'], 'md', 'c')
        txt(s, cx - 1.5, 5.68, 3.0, 0.7, sub, 10, P['mute'], 'rg', 'c', sp=1.3)

@reg
def stat_bar_left(prs, d):
    s = page(prs); _ft(s, d)
    gradband(s, 0, 0, 4.6, H, 300)
    txt(s, 0.7, 1.2, 3.4, 2.0, d['t'], 26, 'FFFFFF', 'bd', sp=1.15)
    txt(s, 0.7, 3.4, 3.4, 1.2, d['big'], fit_sz(d['big'], 3.3, 60), 'FFFFFF', 'bd')
    txt(s, 0.7, 4.7, 3.4, 0.8, d.get('biglab', ''), 12, 'F0F0FF', sp=1.3)
    for i, (v, lb, sub) in enumerate(d['items'][:4]):
        y = 0.95 + i * 1.6
        txt(s, 5.4, y, 2.2, 0.7, v, fit_w(v, 2.2, 30, 17), P['acc'], 'bd')
        txt(s, 7.8, y + 0.05, 5.0, 0.4, lb, 14, P['ink'], 'md')
        txt(s, 7.8, y + 0.5, 5.0, 0.6, sub, 10.5, P['mute'], sp=1.3)
        if i < 3: ln(s, 5.4, y + 1.35, 12.6, y + 1.35, mix(P['bg'], P['mute'], 0.28), 0.5)

@reg
def stat_dotmatrix(prs, d):
    s = page(prs); _ft(s, d)
    shp(s, 'rect', 0, 0, W, H, P['panel'] if not P['dark'] else P['bg'])
    txt(s, 0.85, 0.9, 7, 1.3, d['t'], 28, P['ink'], 'bd', sp=1.15)
    dots(s, 0.85, 2.6, 22, 8, 0.26, 0.09, mix(P['bg'], P['mute'], 0.5), 1)
    n = d['on']
    for i in range(n):
        r, q = divmod(i, 22)
        shp(s, 'oval', 0.85 + q * 0.26, 2.6 + r * 0.26, 0.09, 0.09, P['acc'])
    txt(s, 0.85, 4.95, 6, 0.9, d['big'], fit_sz(d['big'], 5.9, 44), P['acc'], 'bd')
    txt(s, 0.85, 5.95, 7.2, 0.8, d.get('biglab', ''), 12, P['mute'], sp=1.4)
    card(s, 8.6, 2.5, 3.9, 3.4, adj=0.08)
    txt(s, 8.95, 2.85, 3.2, 0.5, d.get('cardt', ''), 14, P['ink'], 'md')
    for i, t_ in enumerate(d.get('bullets', [])[:4]):
        txt(s, 8.95, 3.5 + i * 0.62, 3.2, 0.5, '— ' + t_, 11, P['mute'], sp=1.3)

# ══ CHARTS ═════════════════════════════════════════════════════════════════
@reg
def chart_bars(prs, d):
    s = page(prs); _ft(s, d)
    txt(s, 0.8, 0.85, 7.6, 0.9, d['t'], 28, P['ink'], 'bd')
    if d.get('s'): txt(s, 0.8, 1.8, 7.2, 0.5, d['s'], 12, P['mute'])
    gradbars(s, 0.9, 2.7, 8.2, 3.3, d['vals'], d['cats'], fmt=d.get('fmt', '{}'))
    card(s, 9.6, 2.6, 2.9, 3.4, adj=0.08)
    txt(s, 9.95, 2.95, 2.3, 0.4, d.get('cardt', 'อ่านจากกราฟ'), 12, P['acc'], 'md')
    for i, t_ in enumerate(d.get('bullets', [])[:3]):
        txt(s, 9.95, 3.55 + i * 0.85, 2.3, 0.8, t_, 11, P['ink'] if i == 0 else P['mute'], sp=1.35)
    if d.get('note'): txt(s, 0.9, 6.3, 8, 0.4, d['note'], 10, P['mute'])

@reg
def chart_line(prs, d):
    s = page(prs); _ft(s, d)
    txt(s, 0.8, 0.85, 8, 0.9, d['t'], 28, P['ink'], 'bd')
    if d.get('s'): txt(s, 0.8, 1.8, 8, 0.5, d['s'], 12, P['mute'])
    chart(s, 'line', 0.8, 2.5, 8.5, 3.6, d['cats'], d['series'], [P['acc'], P['acc2']], legend=len(d['series']) > 1,
          fmt=d.get('fmt', '#,##0'), sz=10)
    for i, (v, lb) in enumerate(d.get('side', [])[:3]):
        y = 2.6 + i * 1.2
        txt(s, 9.9, y, 2.8, 0.6, v, 26, P['acc'] if i == 0 else P['ink'], 'bd')
        txt(s, 9.9, y + 0.6, 2.8, 0.5, lb, 10.5, P['mute'], sp=1.3)
    if d.get('note'): txt(s, 0.8, 6.3, 9, 0.4, d['note'], 10, P['mute'])

@reg
def chart_donut_split(prs, d):
    s = page(prs); _ft(s, d)
    txt(s, 0.8, 0.85, 6.4, 1.2, d['t'], 27, P['ink'], 'bd', sp=1.15)
    chart(s, 'donut', 0.6, 2.2, 5.0, 4.2, d['cats'], [('', d['vals'])],
          [P['acc'], P['acc2'], mix(P['acc'], P['bg'], 0.45), mix(P['acc2'], P['bg'], 0.5), mix(P['mute'], P['bg'], 0.3)], legend=False, sz=9)
    for i, (c_, v) in enumerate(zip(d['cats'], d['vals'])):
        y = 2.3 + i * 0.78
        shp(s, 'round', 6.3, y + 0.12, 0.26, 0.26, [P['acc'], P['acc2'], mix(P['acc'], P['bg'], 0.45), mix(P['acc2'], P['bg'], 0.5), mix(P['mute'], P['bg'], 0.3)][i % 5], adj=0.4)
        txt(s, 6.75, y, 4.2, 0.5, c_, 13, P['ink'], 'md')
        txt(s, 11.1, y, 1.5, 0.5, f'{v}%', 16, P['acc'], 'bd', 'r')
        ln(s, 6.3, y + 0.62, 12.6, y + 0.62, mix(P['bg'], P['mute'], 0.25), 0.5)
    if d.get('note'): txt(s, 6.3, 6.1, 6.3, 0.5, d['note'], 10.5, P['mute'], sp=1.3)

@reg
def chart_hbars(prs, d):
    s = page(prs); _ft(s, d)
    txt(s, 0.8, 0.85, 8, 0.9, d['t'], 28, P['ink'], 'bd')
    if d.get('s'): txt(s, 0.8, 1.8, 8.6, 0.5, d['s'], 12, P['mute'])
    hbars(s, 0.85, 2.6, 8.6, d['rows'], fmt=d.get('fmt', '{}'))
    if d.get('big'):
        card(s, 10.0, 2.6, 2.5, 2.4, adj=0.1)
        txt(s, 10.0, 3.05, 2.5, 0.9, d['big'], fit_sz(d['big'], 2.4, 34), P['acc'], 'bd', 'c')
        txt(s, 10.1, 4.0, 2.3, 0.8, d.get('biglab', ''), 10.5, P['mute'], 'rg', 'c', sp=1.3)
    if d.get('note'): txt(s, 0.85, 6.4, 9, 0.4, d['note'], 10, P['mute'])

@reg
def chart_stack(prs, d):
    s = page(prs); _ft(s, d)
    txt(s, 0.8, 0.85, 8, 0.9, d['t'], 28, P['ink'], 'bd')
    if d.get('s'): txt(s, 0.8, 1.8, 8.6, 0.5, d['s'], 12, P['mute'])
    chart(s, 'colS', 0.8, 2.5, 8.6, 3.7, d['cats'], d['series'],
          [P['acc'], P['acc2'], mix(P['acc'], P['bg'], 0.5)], legend=True, fmt=d.get('fmt', '#,##0'), sz=10)
    for i, t_ in enumerate(d.get('bullets', [])[:3]):
        y = 2.7 + i * 1.15
        shp(s, 'rect', 9.9, y + 0.1, 0.1, 0.5, [P['acc'], P['acc2'], P['mute']][i % 3])
        txt(s, 10.15, y, 2.5, 1.0, t_, 11, P['mute'], sp=1.35)

@reg
def chart_gradbars_cut(prs, d):
    s = page(prs); _ft(s, d)
    shp(s, 'rect', 0, 0, W, H, P['panel'] if not P['dark'] else P['bg'])
    txt(s, 0.85, 1.0, 5.2, 1.8, d['t'], 27, P['ink'], 'bd', sp=1.15)
    if d.get('s'): txt(s, 0.85, 2.9, 4.6, 1.4, d['s'], 11.5, P['mute'], sp=1.5)
    for i, (v, lb) in enumerate(d.get('side', [])[:3]):
        y = 4.4 + i * 0.78
        txt(s, 0.85, y, 1.9, 0.5, v, 22, P['acc'], 'bd')
        txt(s, 2.9, y + 0.08, 3.0, 0.4, lb, 10.5, P['mute'])
    gradbars(s, 6.3, 1.5, 6.3, 4.2, d['vals'], d['cats'], fmt=d.get('fmt', '{}'), kind='snip2', adj=0.18, gap=0.34)

@reg
def chart_scatter_quad(prs, d):
    s = page(prs); _ft(s, d)
    txt(s, 0.8, 0.8, 8, 0.8, d['t'], 27, P['ink'], 'bd')
    if d.get('s'): txt(s, 0.8, 1.65, 8.4, 0.5, d['s'], 11.5, P['mute'])
    x0, y0, bw, bh = 1.6, 2.3, 7.4, 3.9
    shp(s, 'rect', x0, y0, bw, bh, mix(P['bg'], P['ink'], 0.04))
    ln(s, x0, y0 + bh / 2, x0 + bw, y0 + bh / 2, mix(P['bg'], P['mute'], 0.4), 0.75)
    ln(s, x0 + bw / 2, y0, x0 + bw / 2, y0 + bh, mix(P['bg'], P['mute'], 0.4), 0.75)
    sc = 0.01 if max(max(p[0], p[1]) for p in d['points']) > 1 else 1   # เด็คเขียนได้ทั้ง 0-1 และ 0-100
    for (px, py, lb, hot) in d['points']:
        cx, cy = x0 + bw * px * sc, y0 + bh * (1 - py * sc)
        c = P['acc'] if hot else mix(P['bg'], P['mute'], 0.75)
        shp(s, 'oval', cx - 0.16, cy - 0.16, 0.32, 0.32, c)
        txt(s, cx + 0.24, cy - 0.16, 2.6, 0.34, lb, 10.5, P['ink'] if hot else P['mute'], 'md' if hot else 'rg')
    txt(s, x0, y0 + bh + 0.12, bw, 0.3, d.get('xlab', ''), 10, P['mute'], 'rg', 'c')
    txt(s, 0.5, y0 + bh / 2 - 0.6, 1.0, 1.2, d.get('ylab', ''), 10, P['mute'], 'rg', 'c', 'm')
    for i, t_ in enumerate(d.get('bullets', [])[:3]):
        txt(s, 9.5, 2.5 + i * 1.25, 3.1, 1.1, t_, 11, P['mute'], sp=1.35)

@reg
def chart_area_spark(prs, d):
    s = page(prs); _ft(s, d)
    gradband(s, 0, 0, W, 2.5, 270, a1=0.22, a2=0.0)
    txt(s, 0.85, 0.75, 8, 0.9, d['t'], 28, P['ink'], 'bd')
    if d.get('s'): txt(s, 0.85, 1.7, 8.4, 0.5, d['s'], 12, P['mute'])
    for i, row in enumerate(d['rows'][:3]):
        y = 2.5 + i * 1.5
        card(s, 0.85, y, 11.6, 1.3, mix(P['bg'], P['ink'], 0.04), adj=0.1)
        txt(s, 1.15, y + 0.18, 3.0, 0.4, row['lab'], 13, P['ink'], 'md')
        txt(s, 1.15, y + 0.62, 3.0, 0.5, row['val'], 22, P['acc'], 'bd')
        sparkline(s, 4.6, y + 0.3, 5.2, 0.7, row['vals'])
        txt(s, 10.2, y + 0.42, 2.0, 0.5, row['chg'], 16, P['acc2'] if row.get('up', 1) else P['mute'], 'bd', 'r')
    if d.get('note'): txt(s, 0.85, 6.9, 9, 0.4, d['note'], 10, P['mute'])

# ══ CONTENT ════════════════════════════════════════════════════════════════
@reg
def two_col_cards(prs, d):
    s = page(prs); _ft(s, d)
    txt(s, 0.8, 0.85, 8.4, 0.9, d['t'], 28, P['ink'], 'bd')
    if d.get('s'): txt(s, 0.8, 1.8, 9, 0.5, d['s'], 12, P['mute'])
    for i, (h_, body) in enumerate(d['items'][:4]):
        x = 0.8 + (i % 2) * 6.1; y = 2.6 + (i // 2) * 1.9
        card(s, x, y, 5.8, 1.7, adj=0.09)
        gradband(s, x, y, 0.12, 1.7, 90)
        txt(s, x + 0.45, y + 0.22, 5.0, 0.5, h_, 15, P['ink'], 'md')
        txt(s, x + 0.45, y + 0.78, 5.0, 0.8, body, 11, P['mute'], sp=1.4)

@reg
def icon_grid(prs, d):
    s = page(prs); _ft(s, d)
    txt(s, 0.8, 0.85, 8.4, 0.9, d['t'], 28, P['ink'], 'bd')
    if d.get('s'): txt(s, 0.8, 1.8, 9.2, 0.5, d['s'], 12, P['mute'])
    n = len(d['items'][:4])
    for i, (ic, h_, body) in enumerate(d['items'][:4]):
        x = 0.8 + i * (11.7 / n)
        card(s, x, 2.6, 11.7 / n - 0.25, 3.4, adj=0.08)
        gradband(s, x + 0.42, 2.95, 1.15, 1.15, 315, kind='round', adj=0.3)
        icon(s, ic, x + 1.0, 3.53, 0.6, 'FFFFFF')
        txt(s, x + 0.42, 4.35, 11.7 / n - 1.05, 0.7, h_, 16, P['ink'], 'md', sp=1.15)
        txt(s, x + 0.42, 5.12, 11.7 / n - 1.05, 1.1, body, 10.5, P['mute'], sp=1.4)

@reg
def compare_two(prs, d):
    s = page(prs); _ft(s, d)
    txt(s, 0.8, 0.85, 9, 0.9, d['t'], 28, P['ink'], 'bd')
    if d.get('s'): txt(s, 0.8, 1.8, 9.4, 0.5, d['s'], 12, P['mute'])
    for i, (h_, tag, pts) in enumerate(d['items'][:2]):
        x = 0.8 + i * 6.1
        if i == 1: gradband(s, x, 2.5, 5.8, 3.7, 315, kind='round', adj=0.06)
        else: card(s, x, 2.5, 5.8, 3.7, adj=0.06, line=mix(P['bg'], P['mute'], 0.35))
        c = 'FFFFFF' if i == 1 else P['ink']; cm = 'EFEFFF' if i == 1 else P['mute']
        txt(s, x + 0.45, 2.8, 4.2, 0.5, h_, 18, c, 'bd')
        pill(s, x + 4.0, 2.82, 1.4, 0.4, tag, 'FFFFFF' if i == 1 else mix(P['bg'], P['acc'], 0.18),
             P['acc'] if i == 1 else P['acc'], 10)
        for j, p_ in enumerate(pts[:5]):
            y = 3.55 + j * 0.52
            shp(s, 'oval', x + 0.45, y + 0.13, 0.12, 0.12, c if i == 1 else P['acc'])
            txt(s, x + 0.75, y, 4.8, 0.45, p_, 11.5, cm if j else c, 'rg')
    if d.get('note'): txt(s, 0.8, 6.45, 11.6, 0.4, d['note'], 10.5, P['mute'])

@reg
def process_steps(prs, d):
    s = page(prs); _ft(s, d)
    txt(s, 0.8, 0.85, 9, 0.9, d['t'], 28, P['ink'], 'bd')
    if d.get('s'): txt(s, 0.8, 1.8, 9.4, 0.5, d['s'], 12, P['mute'])
    steps_arrow(s, 0.8, 2.7, 11.7, [it[0] for it in d['items'][:5]])
    n = len(d['items'][:5]); sw = 11.7 / n
    for i, it in enumerate(d['items'][:5]):
        x = 0.8 + i * sw
        txt(s, x + 0.2, 3.85, sw - 0.5, 1.6, it[1], 11, P['mute'], sp=1.45)
        if len(it) > 2: txt(s, x + 0.2, 5.5, sw - 0.5, 0.5, it[2], 12.5, P['acc'], 'bd')
    if d.get('note'): txt(s, 0.8, 6.4, 11.6, 0.4, d['note'], 10.5, P['mute'])

@reg
def timeline_h(prs, d):
    s = page(prs); _ft(s, d)
    txt(s, 0.8, 0.85, 9, 0.9, d['t'], 28, P['ink'], 'bd')
    if d.get('s'): txt(s, 0.8, 1.8, 9.4, 0.5, d['s'], 12, P['mute'])
    n = len(d['items'][:4]); cw = 11.7 / n
    gradband(s, 0.8, 3.02, 11.7, 0.08, 0)
    for i, (per, h_, body) in enumerate(d['items'][:4]):
        x = 0.8 + i * cw
        shp(s, 'oval', x + cw / 2 - 0.22, 2.84, 0.44, 0.44, P['bg'], line=P['acc'], lw=2)
        txt(s, x, 2.3, cw, 0.4, per, 11.5, P['acc'], 'bd', 'c')
        card(s, x + 0.15, 3.75, cw - 0.4, 2.3, adj=0.08)
        txt(s, x + 0.5, 4.0, cw - 1.1, 0.7, h_, 14, P['ink'], 'md', sp=1.15)
        txt(s, x + 0.5, 4.8, cw - 1.1, 1.1, body, 10.5, P['mute'], sp=1.4)

@reg
def table_plain(prs, d):
    s = page(prs); _ft(s, d)
    txt(s, 0.8, 0.85, 9, 0.9, d['t'], 28, P['ink'], 'bd')
    if d.get('s'): txt(s, 0.8, 1.8, 9.4, 0.5, d['s'], 12, P['mute'])
    th = min(3.9, 0.62 + 0.6 * len(d['rows']))      # grow rows so the table fills the page, not a thin strip
    table(s, 0.8, 2.5, 11.7, th, d['head'], d['rows'], colw=d.get('colw'),
          hf=P['acc'], hc='FFFFFF', bf=P['bg'], alt=mix(P['bg'], P['ink'], 0.04), sz=11, hsz=11.5,
          line=mix(P['bg'], P['mute'], 0.25), al=d.get('al'), bold_first=True)
    if d.get('note'): txt(s, 0.8, min(6.5, 2.5 + th + 0.35), 11.6, 0.4, d['note'], 10.5, P['mute'])

@reg
def quote_photo(prs, d):
    s = page(prs)
    pic(s, ph(d['topic'], d.get('pi', 7)), 0, 0, W, H, focus=(0.5, 0.4))
    shp(s, 'rect', 0, 0, W, H, P['bg'], a=0.72)
    gradband(s, 0, 0, W, H, 315, a1=0.35, a2=0.05)
    txt(s, 1.4, 2.0, 10.5, 2.6, d['t'], d.get('tsz', 34), P['ink'], 'bd', 'c', sp=1.3)
    ln(s, 5.9, 4.9, 7.4, 4.9, P['acc'], 2)
    if d.get('s'): txt(s, 2.4, 5.15, 8.5, 0.9, d['s'], 12.5, P['mute'], 'rg', 'c', sp=1.4)

@reg
def checklist_photo(prs, d):
    s = page(prs); _ft(s, d)
    photo_wash(s, d['topic'], d.get('pi', 8), 0, 0, 5.6, H, a=0.92)
    gradband(s, 0, 0, 5.6, H, 270, a1=0.0, a2=0.55)
    txt(s, 0.7, 5.2, 4.4, 1.4, d.get('phototxt', ''), 16, 'FFFFFF', 'md', sp=1.3)
    txt(s, 6.3, 0.9, 6.2, 1.2, d['t'], 26, P['ink'], 'bd', sp=1.15)
    for i, it in enumerate(d['items'][:6]):
        y = 2.3 + i * 0.72
        gradband(s, 6.3, y + 0.04, 0.34, 0.34, 315, kind='oval')
        icon(s, 'check', 6.47, y + 0.21, 0.2, 'FFFFFF')
        txt(s, 6.85, y, 5.6, 0.45, it[0] if isinstance(it, (list, tuple)) else it, 12.5, P['ink'], 'md')
        if isinstance(it, (list, tuple)) and len(it) > 1:
            txt(s, 6.85, y + 0.36, 5.6, 0.35, it[1], 10, P['mute'])

@reg
def matrix_2x2(prs, d):
    s = page(prs); _ft(s, d)
    txt(s, 0.8, 0.85, 9, 0.9, d['t'], 28, P['ink'], 'bd')
    if d.get('s'): txt(s, 0.8, 1.8, 9.4, 0.5, d['s'], 12, P['mute'])
    for i, (h_, body, hot) in enumerate(d['items'][:4]):
        x = 0.9 + (i % 2) * 6.0; y = 2.6 + (i // 2) * 1.9
        if hot: gradband(s, x, y, 5.7, 1.7, 315, kind='round', adj=0.07)
        else: card(s, x, y, 5.7, 1.7, adj=0.07)
        c = 'FFFFFF' if hot else P['ink']; cm = 'EFEFFF' if hot else P['mute']
        txt(s, x + 0.42, y + 0.25, 4.9, 0.5, h_, 15, c, 'md')
        txt(s, x + 0.42, y + 0.8, 4.9, 0.8, body, 10.5, cm, sp=1.4)

@reg
def photo_band_facts(prs, d):
    s = page(prs); _ft(s, d)
    txt(s, 0.8, 0.8, 8.6, 0.9, d['t'], 27, P['ink'], 'bd')
    pic(s, ph(d['topic'], d.get('pi', 9)), 0.8, 1.9, 11.7, 2.4, geom='roundRect', adj=0.05, focus=(0.5, 0.42))
    gradband(s, 0.8, 1.9, 11.7, 2.4, 0, a1=0.75, a2=0.0, kind='round', adj=0.05)
    txt(s, 1.25, 3.2, 5.2, 0.9, d.get('phototxt', ''), 15, 'FFFFFF', 'md', sp=1.25)
    for i, (v, lb) in enumerate(d['items'][:4]):
        x = 0.8 + i * 2.98
        txt(s, x, 4.7, 2.7, 0.7, v, 30, P['acc'], 'bd')
        txt(s, x, 5.45, 2.7, 0.8, lb, 10.5, P['mute'], sp=1.35)

# ══ DIVIDERS ═══════════════════════════════════════════════════════════════
@reg
def div_number_glow(prs, d):
    s = page(prs)
    glow(s, W * 0.72, H * 0.5, 4.6, P['g2'], 0.45)
    grid(s, 0.8, a=0.4)
    txt(s, 0.9, 2.7, 1.8, 1.6, d.get('num', '01'), 84, mix(P['bg'], P['acc'], 0.55), 'bd')
    txt(s, 3.0, 2.9, 7.4, 1.6, d['t'], 40, P['ink'], 'bd', sp=1.1)
    if d.get('s'): txt(s, 3.0, 4.5, 6.4, 0.7, d['s'], 12.5, P['mute'], sp=1.4)

@reg
def div_photo_band(prs, d):
    s = page(prs)
    pic(s, ph(d['topic'], d.get('pi', 10)), 0, 0, W, H, focus=(0.5, 0.4))
    shp(s, 'rect', 0, 0, W, H, '000000', a=0.5)
    gradband(s, 0, 2.6, W, 2.3, 0, a1=0.85, a2=0.15)
    txt(s, 1.0, 3.0, 9.4, 1.5, d['t'], 40, 'FFFFFF', 'bd', sp=1.08)
    if d.get('s'): txt(s, 1.0, 4.45, 7.4, 0.5, d['s'], 12.5, 'EDEDF6')
    txt(s, W - 2.4, 3.05, 1.6, 0.8, d.get('num', ''), 40, 'FFFFFF', 'bd', 'r')

@reg
def div_split_bar(prs, d):
    s = page(prs)
    shp(s, 'rect', 0, 0, W, H, P['panel'] if not P['dark'] else P['bg'])
    gradband(s, 0, H * 0.34, W, 0.14, 0)
    txt(s, 1.0, H * 0.34 - 1.9, 10.4, 1.7, d['t'], 42, P['ink'], 'bd', sp=1.08)
    txt(s, 1.0, H * 0.34 + 0.55, 8.4, 0.8, d.get('s', ''), 12.5, P['mute'], sp=1.4)
    txt(s, W - 3.0, H * 0.34 + 0.55, 2.0, 0.6, d.get('num', ''), 26, mix(P['bg'], P['acc'], 0.6), 'bd', 'r')

@reg
def div_minimal_rule(prs, d):
    s = page(prs)
    dots(s, W - 3.2, 0.7, 10, 10, 0.24, 0.07, mix(P['bg'], P['mute'], 0.5), 1)
    txt(s, 1.0, 2.6, 2.0, 0.6, d.get('num', ''), 13, P['acc'], 'bd', track=2)
    ln(s, 1.0, 3.25, 11.9, 3.25, mix(P['bg'], P['mute'], 0.4), 0.75)
    txt(s, 1.0, 3.5, 10.4, 1.6, d['t'], 38, P['ink'], 'bd', sp=1.1)
    if d.get('s'): txt(s, 1.0, 5.2, 7.4, 0.7, d['s'], 12.5, P['mute'], sp=1.4)

# ══ CLOSING ════════════════════════════════════════════════════════════════
@reg
def close_cta(prs, d):
    s = page(prs)
    gradband(s, 0, 0, W, H, 315)
    grid(s, 0.78, 'FFFFFF', 0.7)
    txt(s, 1.2, 2.2, 10.9, 1.9, d['t'], 42, 'FFFFFF', 'bd', 'c', sp=1.08)
    if d.get('s'): txt(s, 2.6, 4.2, 8.1, 0.9, d['s'], 13.5, 'F2F2FF', 'rg', 'c', sp=1.4)
    for i, it in enumerate(d.get('items', [])[:3]):
        x = 2.3 + i * 3.0
        shp(s, 'round', x, 5.3, 2.7, 0.9, 'FFFFFF', a=0.16, adj=0.2)
        txt(s, x, 5.3, 2.7, 0.9, it, 12, 'FFFFFF', 'md', 'c', 'm')

@reg
def close_contact_grad(prs, d):
    s = page(prs)
    photo_wash(s, d['topic'], d.get('pi', 11), 0, 0, W, H, a=0.35)
    gradband(s, 0, 0, W, H, 300, a1=0.9, a2=0.35)
    txt(s, 1.1, 2.3, 8.4, 1.7, d['t'], 40, 'FFFFFF', 'bd', sp=1.08)
    if d.get('s'): txt(s, 1.1, 4.1, 7.0, 0.9, d['s'], 13, 'F0F0FF', sp=1.4)
    for i, (lb, v) in enumerate(d.get('items', [])[:3]):
        y = 5.2 + i * 0.6
        txt(s, 1.1, y, 2.2, 0.4, lb, 10.5, 'D8D8F0')
        txt(s, 3.3, y - 0.03, 6.0, 0.45, v, 13, 'FFFFFF', 'md')

@reg
def close_summary_cards(prs, d):
    s = page(prs); _ft(s, d)
    txt(s, 0.8, 0.9, 9, 1.0, d['t'], 30, P['ink'], 'bd')
    if d.get('s'): txt(s, 0.8, 1.95, 9.4, 0.5, d['s'], 12, P['mute'])
    for i, (h_, body) in enumerate(d['items'][:3]):
        x = 0.8 + i * 4.05
        card(s, x, 2.7, 3.8, 2.7, adj=0.08)
        txt(s, x + 0.4, 2.95, 0.6, 0.5, f'{i+1}', 20, mix(P['bg'], P['acc'], 0.6), 'bd')
        txt(s, x + 0.4, 3.5, 3.1, 0.7, h_, 15, P['ink'], 'md', sp=1.15)
        txt(s, x + 0.4, 4.3, 3.1, 0.9, body, 10.5, P['mute'], sp=1.4)
    if d.get('cta'):
        gradband(s, 0.8, 5.7, 11.7, 0.95, 0, kind='round', adj=0.3)
        txt(s, 0.8, 5.7, 11.7, 0.95, d['cta'], 15, 'FFFFFF', 'md', 'c', 'm')

@reg
def close_next_steps(prs, d):
    s = page(prs); _ft(s, d)
    gradband(s, 0, 0, W, 2.3, 270, a1=0.3, a2=0.0)
    txt(s, 0.8, 0.85, 9, 1.0, d['t'], 30, P['ink'], 'bd')
    if d.get('s'): txt(s, 0.8, 1.85, 9.4, 0.5, d['s'], 12, P['mute'])
    for i, (who, what, when) in enumerate(d['items'][:4]):
        y = 2.6 + i * 0.92
        card(s, 0.8, y, 11.7, 0.78, mix(P['bg'], P['ink'], 0.04), adj=0.15)
        gradband(s, 0.8, y, 0.1, 0.78, 90)
        txt(s, 1.2, y, 2.6, 0.78, who, 12.5, P['acc'], 'bd', an='m')
        txt(s, 4.0, y, 6.0, 0.78, what, 12, P['ink'], an='m')
        txt(s, 10.2, y, 2.0, 0.78, when, 11.5, P['mute'], 'md', 'r', an='m')
    if d.get('note'): txt(s, 0.8, 6.5, 11.6, 0.4, d['note'], 10.5, P['mute'])

@reg
def close_thanks_photo(prs, d):
    s = page(prs)
    pic(s, ph(d['topic'], d.get('pi', 12)), 0, 0, W, H, focus=(0.5, 0.42))
    shp(s, 'rect', 0, 0, W, H, '000000', a=0.55)
    gradband(s, 0, H - 3.0, W, 3.0, 90, a1=0.0, a2=0.9)
    txt(s, 0.9, H - 2.7, 9.0, 1.3, d['t'], 40, 'FFFFFF', 'bd')
    if d.get('s'): txt(s, 0.9, H - 1.35, 7.6, 0.8, d['s'], 12.5, 'E8E8F4', sp=1.35)
    txt(s, W - 4.4, H - 1.5, 3.5, 0.5, d.get('contact', ''), 12, 'FFFFFF', 'md', 'r')

@reg
def close_kpi_recap(prs, d):
    s = page(prs); _ft(s, d)
    shp(s, 'rect', 0, 0, W, H, P['panel'] if not P['dark'] else P['bg'])
    txt(s, 0.85, 0.9, 8, 1.0, d['t'], 30, P['ink'], 'bd')
    for i, (v, lb) in enumerate(d['items'][:4]):
        x = 0.85 + (i % 2) * 6.0; y = 2.2 + (i // 2) * 2.0
        card(s, x, y, 5.7, 1.7, P['bg'] if not P['dark'] else mix(P['bg'], P['ink'], 0.06), adj=0.08)
        txt(s, x + 0.45, y + 0.3, 3.0, 1.0, v, fit_w(v, 3.0, 38, 19), P['acc'], 'bd')
        txt(s, x + 0.45, y + 1.15, 4.8, 0.4, lb, 11.5, P['mute'])
    if d.get('cta'): txt(s, 0.85, 6.3, 11.6, 0.5, d['cta'], 13, P['ink'], 'md')

# ══ EXTRA LAYOUTS (set B) ══════════════════════════════════════════════════
@reg
def stat_split_photo(prs, d):
    s = page(prs); _ft(s, d)
    pic(s, ph(d['topic'], d.get('pi', 13)), 6.9, 0, 6.44, H, focus=(0.55, 0.4))
    gradband(s, 6.9, 0, 6.44, H, 0, a1=0.85, a2=0.1)
    txt(s, 0.85, 1.1, 5.4, 1.3, d['t'], 25, P['ink'], 'bd', sp=1.2)
    gradband(s, 0.85, 2.6, 1.9, 0.09, 0)
    txt(s, 0.8, 2.95, 5.6, 1.9, d['big'], fit_sz(d['big'], 5.4, 88), P['acc'], 'bd', sp=0.92)
    txt(s, 0.85, 4.75, 5.2, 0.5, d.get('biglab', ''), 13.5, P['ink'], 'md')
    for i, (v, lb) in enumerate(d.get('items', [])[:2]):
        y = 5.45 + i * 0.75
        txt(s, 0.85, y, 1.5, 0.45, v, 20, P['acc2'] if P['dark'] else P['acc'], 'bd')
        txt(s, 2.5, y + 0.06, 3.8, 0.4, lb, 10.5, P['mute'])
    txt(s, 7.4, H - 1.2, 5.4, 0.8, d.get('phototxt', ''), 12, 'FFFFFF', 'md', sp=1.3)

@reg
def chart_bullet(prs, d):
    s = page(prs); _ft(s, d)
    txt(s, 0.8, 0.85, 9, 0.9, d['t'], 28, P['ink'], 'bd')
    if d.get('s'): txt(s, 0.8, 1.8, 9.4, 0.5, d['s'], 12, P['mute'])
    for i, (lab, act, tgt, unit) in enumerate(d['rows'][:5]):
        y = 2.5 + i * 0.86
        txt(s, 0.85, y, 3.0, 0.5, lab, 12.5, P['ink'], 'md')
        tr = 6.6
        shp(s, 'rect', 4.0, y + 0.12, tr, 0.3, mix(P['bg'], P['mute'], 0.2))
        gradband(s, 4.0, y + 0.12, tr * min(act / max(tgt, 1), 1.25), 0.3, 0)
        shp(s, 'rect', 4.0 + tr - 0.02, y + 0.02, 0.05, 0.5, P['ink'])
        txt(s, 10.8, y, 1.7, 0.5, f'{act}{unit}', 13, P['acc'], 'bd', 'r')
        txt(s, 11.0, y + 0.42, 1.5, 0.3, f'เป้า {tgt}{unit}', 9.5, P['mute'], 'rg', 'r')
    if d.get('note'): txt(s, 0.85, 6.6, 11.6, 0.4, d['note'], 10.5, P['mute'])

@reg
def kpi_strip(prs, d):
    s = page(prs); _ft(s, d)
    gradband(s, 0, 0, W, 2.05, 300)
    txt(s, 0.8, 0.45, 7.4, 0.6, d['t'], 24, 'FFFFFF', 'bd')
    for i, (v, lb) in enumerate(d['kpis'][:4]):
        x = 0.8 + i * 3.05
        txt(s, x, 1.1, 2.8, 0.5, v, 23, 'FFFFFF', 'bd')
        txt(s, x, 1.62, 2.8, 0.3, lb, 9.5, 'E6E6FF')
    gradbars(s, 0.9, 3.0, 7.6, 2.9, d['vals'], d['cats'], fmt=d.get('fmt', '{}'))
    card(s, 9.0, 2.9, 3.5, 3.1, adj=0.08)
    txt(s, 9.35, 3.2, 2.9, 0.45, d.get('cardt', ''), 13, P['acc'], 'md')
    for i, t_ in enumerate(d.get('bullets', [])[:3]):
        txt(s, 9.35, 3.8 + i * 0.78, 2.9, 0.75, '— ' + t_, 10.5, P['mute'], sp=1.35)

@reg
def list_numbered_big(prs, d):
    s = page(prs); _ft(s, d)
    photo_wash(s, d['topic'], d.get('pi', 15), 8.2, 0, 5.13, H, a=0.9)
    gradband(s, 8.2, 0, 2.2, H, 0, a1=0.9, a2=0.0)
    txt(s, 0.85, 0.9, 6.6, 1.1, d['t'], 27, P['ink'], 'bd', sp=1.15)
    for i, (h_, body) in enumerate(d['items'][:4]):
        y = 2.35 + i * 1.15
        txt(s, 0.85, y, 0.9, 0.7, f'{i+1}', 34, mix(P['bg'], P['acc'], 0.55), 'bd')
        txt(s, 1.75, y + 0.05, 5.6, 0.45, h_, 15, P['ink'], 'md')
        txt(s, 1.75, y + 0.5, 5.6, 0.6, body, 10.5, P['mute'], sp=1.35)
        ln(s, 0.85, y + 1.02, 7.4, y + 1.02, mix(P['bg'], P['mute'], 0.25), 0.5)

@reg
def cards_3_photo(prs, d):
    s = page(prs); _ft(s, d)
    txt(s, 0.8, 0.85, 9, 0.9, d['t'], 28, P['ink'], 'bd')
    if d.get('s'): txt(s, 0.8, 1.8, 9.4, 0.5, d['s'], 12, P['mute'])
    for i, (h_, body) in enumerate(d['items'][:3]):
        x = 0.8 + i * 4.05
        card(s, x, 2.5, 3.8, 3.7, adj=0.07)
        pic(s, ph(d['topic'], d.get('pi', 16) + i), x, 2.5, 3.8, 1.6, geom='roundRect', adj=0.09, focus=(0.5, 0.45))
        shp(s, 'rect', x, 3.95, 3.8, 0.15, P['panel'])
        txt(s, x + 0.4, 4.25, 3.0, 0.6, h_, 15, P['ink'], 'md', sp=1.15)
        txt(s, x + 0.4, 5.0, 3.0, 1.0, body, 10.5, P['mute'], sp=1.4)

@reg
def quote_card(prs, d):
    s = page(prs)
    gradband(s, 0, 0, W, H, 315, a1=1, a2=1)
    dots(s, 0.7, 0.6, 8, 4, 0.3, 0.08, 'FFFFFF', 0.35)
    card(s, 1.6, 1.7, 10.1, 4.1, 'FFFFFF' if P['dark'] else P['bg'], adj=0.06, shadow=True)
    icon(s, 'quote', 2.3, 2.5, 0.5, P['acc'])
    txt(s, 2.3, 2.95, 8.7, 2.0, d['t'], 26, '111111' if P['dark'] else P['ink'], 'md', sp=1.4)
    ln(s, 2.3, 4.95, 3.4, 4.95, P['acc'], 2)
    if d.get('s'): txt(s, 2.3, 5.15, 8.0, 0.5, d['s'], 11.5, P['mute'])

@reg
def region_grid(prs, d):
    s = page(prs); _ft(s, d)
    txt(s, 0.8, 0.85, 8, 0.9, d['t'], 28, P['ink'], 'bd')
    if d.get('s'): txt(s, 0.8, 1.8, 9, 0.5, d['s'], 12, P['mute'])
    mx = max(v for _, v, _ in d['items']) or 1
    for i, (name, v, note) in enumerate(d['items'][:8]):
        x = 0.8 + (i % 4) * 2.98; y = 2.6 + (i // 4) * 1.95
        k = v / mx
        shp(s, 'round', x, y, 2.75, 1.75, mix(P['bg'], P['acc'], 0.12 + 0.6 * k), adj=0.08)
        txt(s, x + 0.35, y + 0.2, 2.1, 0.4, name, 12.5, 'FFFFFF' if k > 0.55 else P['ink'], 'md')
        txt(s, x + 0.35, y + 0.6, 2.1, 0.6, f'{v:,}', 24, 'FFFFFF' if k > 0.55 else P['acc'], 'bd')
        txt(s, x + 0.35, y + 1.22, 2.1, 0.4, note, 9.5, 'F0F0FF' if k > 0.55 else P['mute'])
    if d.get('note'): txt(s, 0.8, 6.6, 11.6, 0.4, d['note'], 10.5, P['mute'])

@reg
def funnel_stages(prs, d):
    s = page(prs); _ft(s, d)
    txt(s, 0.8, 0.85, 8, 0.9, d['t'], 28, P['ink'], 'bd')
    if d.get('s'): txt(s, 0.8, 1.8, 8.6, 0.5, d['s'], 12, P['mute'])
    n = len(d['items'][:5])
    for i, (lab, v, note) in enumerate(d['items'][:5]):
        w_ = 7.6 - i * 1.25; x = 0.9 + (7.6 - w_) / 2; y = 2.6 + i * 0.78
        gradband(s, x, y, w_, 0.66, 0, kind='round', adj=0.2,
                 c1=mix(P['g1'], P['g2'], i / max(n - 1, 1)), c2=mix(P['g1'], P['g2'], min((i + 0.7) / max(n - 1, 1), 1)))
        txt(s, x, y, w_, 0.66, lab, 12.5, 'FFFFFF', 'md', 'c', 'm')
        txt(s, 8.9, y, 1.6, 0.66, f'{v:,}', 17, P['acc'], 'bd', 'r', 'm')
        txt(s, 10.7, y, 1.9, 0.66, note, 10, P['mute'], an='m')
    if d.get('note'): txt(s, 0.9, 6.55, 11.5, 0.4, d['note'], 10.5, P['mute'])

@reg
def pyramid_levels(prs, d):
    s = page(prs); _ft(s, d)
    txt(s, 0.8, 0.85, 7.4, 1.1, d['t'], 27, P['ink'], 'bd', sp=1.15)
    if d.get('s'): txt(s, 0.8, 2.1, 5.0, 1.2, d['s'], 11.5, P['mute'], sp=1.45)
    n = len(d['items'][:4])
    for i, (h_, body) in enumerate(d['items'][:4]):
        w_ = 3.0 + i * 1.6; x = 10.3 - w_ / 2 - 1.2; y = 2.0 + i * 1.15
        gradband(s, x, y, w_, 1.0, 0, kind='trapezoid' if False else 'round', adj=0.12,
                 c1=mix(P['g2'], P['g1'], i / max(n - 1, 1)), c2=mix(P['g2'], P['g1'], min((i + 0.6) / max(n - 1, 1), 1)))
        txt(s, x + 0.3, y + 0.12, w_ - 0.6, 0.4, h_, 13, 'FFFFFF', 'md', 'c')
        txt(s, x + 0.3, y + 0.55, w_ - 0.6, 0.4, body, 10, 'F0F0FF', 'rg', 'c')

@reg
def gantt_rows(prs, d):
    s = page(prs); _ft(s, d)
    txt(s, 0.8, 0.85, 9, 0.9, d['t'], 28, P['ink'], 'bd')
    if d.get('s'): txt(s, 0.8, 1.8, 9.4, 0.5, d['s'], 12, P['mute'])
    cols = d['cols']; x0, tw = 4.0, 8.2; cw = tw / len(cols)
    for i, c_ in enumerate(cols):
        txt(s, x0 + i * cw, 2.35, cw, 0.3, c_, 10, P['mute'], 'rg', 'c')
        ln(s, x0 + i * cw, 2.7, x0 + i * cw, 6.3, mix(P['bg'], P['mute'], 0.2), 0.5)
    for j, (lab, a_, b_, who) in enumerate(d['rows'][:6]):
        y = 2.8 + j * 0.6
        txt(s, 0.85, y, 3.0, 0.45, lab, 11.5, P['ink'], 'md')
        gradband(s, x0 + a_ * cw, y + 0.06, max((b_ - a_) * cw, 0.3), 0.34, 0, kind='round', adj=0.4)
        txt(s, x0 + a_ * cw + 0.15, y + 0.06, (b_ - a_) * cw - 0.3, 0.34, who, 9.5, 'FFFFFF', 'rg', an='m')
    if d.get('note'): txt(s, 0.85, 6.5, 11.6, 0.4, d['note'], 10.5, P['mute'])

@reg
def price_columns(prs, d):
    s = page(prs); _ft(s, d)
    txt(s, 0.8, 0.8, 9, 0.9, d['t'], 28, P['ink'], 'bd')
    if d.get('s'): txt(s, 0.8, 1.72, 9.4, 0.5, d['s'], 12, P['mute'])
    for i, (name, price, unit, feats, hot) in enumerate(d['items'][:3]):
        x = 0.85 + i * 4.0
        if hot: gradband(s, x, 2.4, 3.7, 3.9, 315, kind='round', adj=0.07)
        else: card(s, x, 2.5, 3.7, 3.7, adj=0.07)
        c = 'FFFFFF' if hot else P['ink']; cm = 'EDEDFF' if hot else P['mute']
        txt(s, x + 0.4, (2.7 if hot else 2.8), 2.9, 0.4, name, 13.5, c, 'md')
        txt(s, x + 0.4, (3.15 if hot else 3.25), 2.9, 0.8, price, 32, c, 'bd')
        txt(s, x + 0.4, (3.95 if hot else 4.05), 2.9, 0.35, unit, 10, cm)
        for j, f_ in enumerate(feats[:4]):
            txt(s, x + 0.4, (4.45 if hot else 4.55) + j * 0.42, 2.9, 0.4, '· ' + f_, 10.5, cm)
    if d.get('note'): txt(s, 0.85, 6.6, 11.6, 0.4, d['note'], 10.5, P['mute'])

@reg
def before_after(prs, d):
    s = page(prs); _ft(s, d)
    txt(s, 0.8, 0.85, 9, 0.9, d['t'], 28, P['ink'], 'bd')
    if d.get('s'): txt(s, 0.8, 1.8, 9.4, 0.5, d['s'], 12, P['mute'])
    card(s, 0.85, 2.6, 5.1, 3.5, mix(P['bg'], P['mute'], 0.1), adj=0.07)
    gradband(s, 7.4, 2.6, 5.1, 3.5, 315, kind='round', adj=0.07)
    for i, (title_, rows, hot) in enumerate([(d['before'][0], d['before'][1], 0), (d['after'][0], d['after'][1], 1)]):
        x = 0.85 + i * 6.55; c = 'FFFFFF' if hot else P['ink']; cm = 'EDEDFF' if hot else P['mute']
        txt(s, x + 0.45, 2.85, 4.2, 0.45, title_, 15, c, 'bd')
        for j, (k_, v_) in enumerate(rows[:4]):
            y = 3.55 + j * 0.62
            txt(s, x + 0.45, y, 2.6, 0.45, k_, 11, cm)
            txt(s, x + 3.0, y - 0.05, 1.6, 0.5, v_, 15, c, 'bd', 'r')
    shp(s, 'oval', 6.35, 4.0, 0.7, 0.7, P['acc'])
    icon(s, 'arrow-right', 6.7, 4.35, 0.32, 'FFFFFF')
    if d.get('note'): txt(s, 0.85, 6.45, 11.6, 0.4, d['note'], 10.5, P['mute'])

@reg
def heat_table(prs, d):
    s = page(prs); _ft(s, d)
    txt(s, 0.8, 0.85, 9, 0.9, d['t'], 28, P['ink'], 'bd')
    if d.get('s'): txt(s, 0.8, 1.8, 9.4, 0.5, d['s'], 12, P['mute'])
    cols = d['cols']; cw = 9.0 / len(cols)
    for i, c_ in enumerate(cols): txt(s, 3.3 + i * cw, 2.45, cw, 0.35, c_, 10.5, P['mute'], 'rg', 'c')
    mx = max(max(r[1]) for r in d['rows']) or 1
    for j, (lab, vals) in enumerate(d['rows'][:5]):
        y = 2.9 + j * 0.72
        txt(s, 0.85, y, 2.3, 0.6, lab, 11.5, P['ink'], 'md', an='m')
        for i, v in enumerate(vals):
            k = v / mx
            shp(s, 'round', 3.3 + i * cw + 0.05, y, cw - 0.1, 0.6, mix(P['bg'], P['acc'], 0.1 + 0.75 * k), adj=0.18)
            txt(s, 3.3 + i * cw, y, cw, 0.6, str(v), 12, 'FFFFFF' if k > 0.5 else P['ink'], 'md', 'c', 'm')
    if d.get('note'): txt(s, 0.85, 6.6, 11.6, 0.4, d['note'], 10.5, P['mute'])

@reg
def big_statement(prs, d):
    s = page(prs)
    shp(s, 'rect', 0, 0, W, H, P['panel'] if not P['dark'] else P['bg'])
    glow(s, W * 0.85, H * 0.18, 4.0, P['g2'], 0.5)
    txt(s, 1.0, 1.9, 11.3, 3.0, d['t'], d.get('tsz', 50), P['ink'], 'bd', sp=1.12)
    gradband(s, 1.0, 5.1, 2.2, 0.1, 0)
    if d.get('s'): txt(s, 1.0, 5.4, 8.4, 1.0, d['s'], 13, P['mute'], sp=1.45)

@reg
def photo_collage(prs, d):
    s = page(prs); _ft(s, d)
    tl = len(str(d['t']))
    txt(s, 0.8, 0.8, 8.4, 0.9, d['t'], 27 if tl <= 58 else 21, P['ink'], 'bd')
    if d.get('s'): txt(s, 0.8, 1.72 if tl <= 58 else 1.86, 9, 0.5, d['s'], 11.5, P['mute'])
    boxes = [(0.8, 2.4, 5.6, 2.2), (6.6, 2.4, 2.8, 2.2), (9.6, 2.4, 2.9, 2.2),
             (0.8, 4.8, 3.6, 1.6), (4.6, 4.8, 3.6, 1.6), (8.4, 4.8, 4.1, 1.6)]
    for i, (x, y, w_, h_) in enumerate(boxes):
        pic(s, ph(d['topic'], d.get('pi', 18) + i), x, y, w_, h_, geom='roundRect', adj=0.06, focus=(0.5, 0.45))
        if i < len(d.get('caps', [])):
            gradband(s, x, y + h_ - 0.62, w_, 0.62, 90, a1=0.0, a2=0.85, kind='round', adj=0.06)
            txt(s, x + 0.25, y + h_ - 0.48, w_ - 0.5, 0.4, d['caps'][i], 10.5, 'FFFFFF', 'md')

@reg
def faq_list(prs, d):
    s = page(prs); _ft(s, d)
    txt(s, 0.8, 0.85, 8, 0.9, d['t'], 28, P['ink'], 'bd')
    if d.get('s'): txt(s, 0.8, 1.8, 9.4, 0.5, d['s'], 12, P['mute'])
    for i, (q, a_) in enumerate(d['items'][:4]):
        y = 2.55 + i * 1.05
        card(s, 0.85, y, 11.6, 0.9, mix(P['bg'], P['ink'], 0.04), adj=0.14)
        gradband(s, 1.05, y + 0.22, 0.46, 0.46, 315, kind='round', adj=0.35)
        txt(s, 1.05, y + 0.22, 0.46, 0.46, f'{i+1}', 12, 'FFFFFF', 'bd', 'c', 'm')
        txt(s, 1.75, y + 0.12, 4.6, 0.45, q, 12.5, P['ink'], 'md')
        txt(s, 1.75, y + 0.52, 10.4, 0.35, a_, 10.5, P['mute'])
    if d.get('note'): txt(s, 0.85, 6.85, 11.6, 0.4, d['note'], 10.5, P['mute'])

@reg
def team_cards(prs, d):
    s = page(prs); _ft(s, d)
    txt(s, 0.8, 0.85, 8, 0.9, d['t'], 28, P['ink'], 'bd')
    if d.get('s'): txt(s, 0.8, 1.8, 9.4, 0.5, d['s'], 12, P['mute'])
    for i, (name, role, note) in enumerate(d['items'][:4]):
        x = 0.85 + i * 2.95
        card(s, x, 2.6, 2.7, 3.3, adj=0.08)
        pic(s, ph(d['topic'], d.get('pi', 20) + i), x + 0.75, 2.95, 1.2, 1.2, geom='ellipse', focus=(0.5, 0.35))
        txt(s, x + 0.25, 4.35, 2.2, 0.4, name, 13, P['ink'], 'md', 'c')
        txt(s, x + 0.25, 4.75, 2.2, 0.35, role, 10.5, P['acc'], 'rg', 'c')
        txt(s, x + 0.25, 5.15, 2.2, 0.7, note, 9.5, P['mute'], 'rg', 'c', sp=1.3)

@reg
def split_stat_list(prs, d):
    s = page(prs); _ft(s, d)
    gradband(s, 0, 0, 5.2, H, 300)
    txt(s, 0.7, 1.0, 3.8, 1.4, d['t'], 24, 'FFFFFF', 'bd', sp=1.2)
    txt(s, 0.7, 2.6, 3.8, 1.6, d['big'], fit_sz(d['big'], 3.7, 72), 'FFFFFF', 'bd', sp=0.95)
    txt(s, 0.7, 4.3, 3.8, 1.0, d.get('biglab', ''), 12, 'EDEDFF', sp=1.4)
    for i, (h_, body) in enumerate(d['items'][:4]):
        y = 0.95 + i * 1.5
        txt(s, 5.9, y, 0.6, 0.4, f'{i+1:02d}', 13, P['acc'], 'bd')
        txt(s, 6.6, y - 0.03, 5.9, 0.45, h_, 14.5, P['ink'], 'md')
        txt(s, 6.6, y + 0.45, 5.9, 0.8, body, 10.5, P['mute'], sp=1.35)
        if i < 3: ln(s, 5.9, y + 1.28, 12.5, y + 1.28, mix(P['bg'], P['mute'], 0.25), 0.5)

@reg
def chart_col_compare(prs, d):
    s = page(prs); _ft(s, d)
    txt(s, 0.8, 0.85, 9, 0.9, d['t'], 28, P['ink'], 'bd')
    if d.get('s'): txt(s, 0.8, 1.8, 9.4, 0.5, d['s'], 12, P['mute'])
    chart(s, 'col', 0.8, 2.5, 8.4, 3.6, d['cats'], d['series'], [P['acc'], mix(P['mute'], P['bg'], 0.35)],
          legend=True, fmt=d.get('fmt', '#,##0'), sz=10, gap=60)
    for i, (v, lb) in enumerate(d.get('side', [])[:3]):
        y = 2.7 + i * 1.15
        txt(s, 9.7, y, 2.9, 0.55, v, 24, P['acc'] if i == 0 else P['ink'], 'bd')
        txt(s, 9.7, y + 0.55, 2.9, 0.5, lb, 10.5, P['mute'], sp=1.3)
    if d.get('note'): txt(s, 0.8, 6.35, 9, 0.4, d['note'], 10, P['mute'])

@reg
def close_qr_cta(prs, d):
    s = page(prs)
    shp(s, 'rect', 0, 0, W, H, P['panel'] if not P['dark'] else P['bg'])
    gradband(s, 0, 0, W, 0.18, 0)
    glow(s, W * 0.2, H * 0.85, 3.6, P['g1'], 0.45)
    txt(s, 0.9, 1.6, 7.4, 1.8, d['t'], 36, P['ink'], 'bd', sp=1.1)
    if d.get('s'): txt(s, 0.9, 3.5, 6.6, 1.0, d['s'], 13, P['mute'], sp=1.45)
    for i, it in enumerate(d.get('items', [])[:3]):
        y = 4.7 + i * 0.6
        gradband(s, 0.9, y + 0.08, 0.26, 0.26, 0, kind='oval')
        txt(s, 1.4, y, 6.4, 0.45, it, 12, P['ink'])
    card(s, 8.6, 1.9, 3.9, 3.9, adj=0.09)
    icon(s, 'qr-code', 10.55, 3.3, 1.5, P['acc'])
    txt(s, 8.9, 4.5, 3.3, 0.5, d.get('qrt', ''), 12.5, P['ink'], 'md', 'c')
    txt(s, 8.9, 5.0, 3.3, 0.6, d.get('qrs', ''), 10, P['mute'], 'rg', 'c', sp=1.3)

# ══ VARIANTS (same content keys as their twin, different composition) ═══════
@reg
def checklist_grid(prs, d):            # twin: checklist_photo
    s = page(prs); _ft(s, d)
    txt(s, 0.8, 0.85, 8.4, 0.9, d['t'], 28, P['ink'], 'bd')
    if d.get('phototxt'): txt(s, 0.8, 1.8, 9.6, 0.5, d['phototxt'], 12, P['mute'])
    for i, it in enumerate(d['items'][:6]):
        x = 0.8 + (i % 3) * 4.0; y = 2.55 + (i // 3) * 2.0
        card(s, x, y, 3.75, 1.8, adj=0.08)
        gradband(s, x + 0.35, y + 0.3, 0.4, 0.4, 315, kind='oval')
        icon(s, 'check', x + 0.55, y + 0.5, 0.22, 'FFFFFF')
        h_ = it[0] if isinstance(it, (list, tuple)) else it
        txt(s, x + 0.95, y + 0.26, 2.6, 0.5, h_, 13, P['ink'], 'md', sp=1.15)
        if isinstance(it, (list, tuple)) and len(it) > 1:
            txt(s, x + 0.35, y + 1.02, 3.1, 0.7, it[1], 10.5, P['mute'], sp=1.35)

@reg
def before_after_rows(prs, d):         # twin: before_after
    s = page(prs); _ft(s, d)
    txt(s, 0.8, 0.85, 9, 0.9, d['t'], 28, P['ink'], 'bd')
    if d.get('s'): txt(s, 0.8, 1.8, 9.4, 0.5, d['s'], 12, P['mute'])
    txt(s, 4.6, 2.35, 3.0, 0.4, d['before'][0], 12, P['mute'], 'md', 'c')
    txt(s, 8.6, 2.35, 3.4, 0.4, d['after'][0], 12, P['acc'], 'bd', 'c')
    for i, ((k1, v1), (k2, v2)) in enumerate(zip(d['before'][1][:4], d['after'][1][:4])):
        y = 2.85 + i * 0.86
        card(s, 0.85, y, 11.6, 0.74, mix(P['bg'], P['ink'], 0.04), adj=0.16)
        txt(s, 1.25, y, 3.4, 0.74, k1, 12, P['ink'], 'md', an='m')
        txt(s, 4.6, y, 3.0, 0.74, v1, 14, P['mute'], 'rg', 'c', 'm')
        icon(s, 'arrow-right', 8.0, y + 0.37, 0.24, P['acc'])
        txt(s, 8.6, y, 3.4, 0.74, v2, 17, P['acc'], 'bd', 'c', 'm')
    if d.get('note'): txt(s, 0.85, 6.5, 11.6, 0.4, d['note'], 10.5, P['mute'])

@reg
def close_steps_cards(prs, d):         # twin: close_next_steps
    s = page(prs); _ft(s, d)
    gradband(s, 0, 0, W, 2.0, 300)
    txt(s, 0.85, 0.55, 8.4, 0.7, d['t'], 26, 'FFFFFF', 'bd')
    if d.get('s'): txt(s, 0.85, 1.3, 9.0, 0.5, d['s'], 11.5, 'EDEDFF')
    for i, (who, what, when) in enumerate(d['items'][:4]):
        x = 0.85 + (i % 2) * 6.0; y = 2.45 + (i // 2) * 2.0
        card(s, x, y, 5.7, 1.8, adj=0.08)
        txt(s, x + 0.4, y + 0.24, 3.6, 0.4, who, 12.5, P['acc'], 'bd')
        pill(s, x + 4.0, y + 0.22, 1.3, 0.4, when, mix(P['bg'], P['acc'], 0.14), P['ink'], 9.5)
        txt(s, x + 0.4, y + 0.78, 4.9, 0.9, what, 11.5, P['ink'], sp=1.35)
    if d.get('note'): txt(s, 0.85, 6.6, 11.6, 0.4, d['note'], 10.5, P['mute'])

@reg
def chart_share_bar(prs, d):           # twin: chart_donut_split
    s = page(prs); _ft(s, d)
    txt(s, 0.8, 0.9, 8.6, 1.2, d['t'], 27, P['ink'], 'bd', sp=1.15)
    tot = sum(d['vals']) or 1; x = 0.85
    cols = [P['acc'], P['acc2'], mix(P['acc'], P['bg'], 0.45), mix(P['acc2'], P['bg'], 0.5), mix(P['mute'], P['bg'], 0.35)]
    for i, v in enumerate(d['vals']):
        w_ = 11.6 * v / tot
        shp(s, 'rect', x, 2.8, w_ - 0.06, 1.1, cols[i % 5])
        if w_ > 1.0: txt(s, x, 2.8, w_ - 0.06, 1.1, f'{v}%', 16, 'FFFFFF' if i < 2 else P['ink'], 'bd', 'c', 'm')
        x += w_
    for i, c_ in enumerate(d['cats']):
        xx = 0.85 + (i % 3) * 3.95; yy = 4.4 + (i // 3) * 0.9
        shp(s, 'round', xx, yy + 0.06, 0.24, 0.24, cols[i % 5], adj=0.4)
        txt(s, xx + 0.42, yy, 3.3, 0.5, c_, 12, P['ink'], 'md')
        txt(s, xx + 0.42, yy + 0.4, 3.3, 0.35, f"{d['vals'][i]}%", 11, P['mute'])
    if d.get('note'): txt(s, 0.85, 6.4, 11.6, 0.5, d['note'], 10.5, P['mute'], sp=1.3)

@reg
def icon_rows(prs, d):                 # twin: icon_grid
    s = page(prs); _ft(s, d)
    txt(s, 0.8, 0.85, 8.4, 0.9, d['t'], 28, P['ink'], 'bd')
    if d.get('s'): txt(s, 0.8, 1.8, 9.4, 0.5, d['s'], 12, P['mute'])
    for i, (ic, h_, body) in enumerate(d['items'][:4]):
        y = 2.5 + i * 1.08
        card(s, 0.85, y, 11.6, 0.94, mix(P['bg'], P['ink'], 0.04), adj=0.13)
        gradband(s, 1.15, y + 0.22, 0.5, 0.5, 315, kind='round', adj=0.3)
        icon(s, ic, 1.4, y + 0.47, 0.26, 'FFFFFF')
        txt(s, 1.9, y + 0.16, 3.4, 0.45, h_, 13.5, P['ink'], 'md')
        txt(s, 5.4, y + 0.2, 6.8, 0.6, body, 11, P['mute'], sp=1.3)

@reg
def faq_cards(prs, d):                 # twin: faq_list
    s = page(prs); _ft(s, d)
    txt(s, 0.8, 0.85, 8.4, 0.9, d['t'], 28, P['ink'], 'bd')
    if d.get('s'): txt(s, 0.8, 1.8, 9.4, 0.5, d['s'], 12, P['mute'])
    for i, (q, a_) in enumerate(d['items'][:4]):
        x = 0.85 + (i % 2) * 6.0; y = 2.5 + (i // 2) * 2.05
        card(s, x, y, 5.7, 1.85, adj=0.08)
        icon(s, 'circle-help', x + 0.45, y + 0.45, 0.32, P['acc'])
        txt(s, x + 0.95, y + 0.22, 4.4, 0.5, q, 12.5, P['ink'], 'md', sp=1.2)
        txt(s, x + 0.45, y + 0.95, 4.9, 0.8, a_, 10.5, P['mute'], sp=1.35)

@reg
def matrix_list(prs, d):               # twin: matrix_2x2
    s = page(prs); _ft(s, d)
    txt(s, 0.8, 0.85, 8.4, 0.9, d['t'], 28, P['ink'], 'bd')
    if d.get('s'): txt(s, 0.8, 1.8, 9.4, 0.5, d['s'], 12, P['mute'])
    for i, (h_, body, hot) in enumerate(d['items'][:4]):
        y = 2.5 + i * 1.08
        gradband(s, 0.85, y, 0.1, 0.94, 90) if hot else shp(s, 'rect', 0.85, y, 0.1, 0.94, mix(P['bg'], P['mute'], 0.4))
        txt(s, 1.25, y + 0.1, 3.5, 0.5, h_, 14, P['acc'] if hot else P['ink'], 'bd' if hot else 'md')
        txt(s, 5.0, y + 0.14, 7.4, 0.7, body, 11, P['mute'], sp=1.3)
        ln(s, 0.85, y + 1.0, 12.45, y + 1.0, mix(P['bg'], P['mute'], 0.22), 0.5)

@reg
def timeline_vert(prs, d):             # twin: timeline_h
    s = page(prs); _ft(s, d)
    txt(s, 0.8, 0.85, 8.4, 0.9, d['t'], 28, P['ink'], 'bd')
    if d.get('s'): txt(s, 0.8, 1.8, 9.4, 0.5, d['s'], 12, P['mute'])
    ln(s, 1.55, 2.6, 1.55, 6.3, mix(P['bg'], P['mute'], 0.35), 1)
    for i, (per, h_, body) in enumerate(d['items'][:4]):
        y = 2.6 + i * 0.98
        gradband(s, 1.36, y, 0.38, 0.38, 0, kind='oval')
        txt(s, 2.1, y - 0.06, 2.6, 0.45, per, 12, P['acc'], 'bd')
        txt(s, 4.6, y - 0.06, 3.4, 0.45, h_, 14, P['ink'], 'md')
        txt(s, 8.1, y - 0.02, 4.3, 0.8, body, 10.5, P['mute'], sp=1.3)

@reg
def process_vertical(prs, d):          # twin: process_steps
    s = page(prs); _ft(s, d)
    photo_wash(s, d['topic'], d.get('pi', 24), 8.6, 0, 4.73, H, a=0.9)
    gradband(s, 8.6, 0, 2.0, H, 0, a1=0.9, a2=0.0)
    txt(s, 0.85, 0.9, 7.0, 1.0, d['t'], 26, P['ink'], 'bd')
    if d.get('s'): txt(s, 0.85, 1.9, 7.2, 0.5, d['s'], 11.5, P['mute'])
    for i, it in enumerate(d['items'][:5]):
        y = 2.5 + i * 0.86
        gradband(s, 0.85, y, 0.52, 0.52, 315, kind='round', adj=0.3)
        txt(s, 0.85, y, 0.52, 0.52, f'{i+1}', 14, 'FFFFFF', 'bd', 'c', 'm')
        txt(s, 1.6, y - 0.02, 2.8, 0.45, it[0], 13, P['ink'], 'md')
        txt(s, 4.5, y + 0.02, 3.3, 0.6, it[1], 10.5, P['mute'], sp=1.3)
        if len(it) > 2: txt(s, 1.6, y + 0.42, 2.8, 0.35, it[2], 10, P['acc'], 'md')
    if d.get('note'): txt(s, 0.85, 6.75, 7.4, 0.4, d['note'], 10, P['mute'])

@reg
def stats_band(prs, d):                # twin: photo_band_facts
    s = page(prs); _ft(s, d)
    txt(s, 0.85, 0.9, 7.2, 1.2, d['t'], 27, P['ink'], 'bd', sp=1.15)
    if d.get('phototxt'): txt(s, 0.85, 2.3, 6.4, 0.8, d['phototxt'], 12, P['mute'], sp=1.4)
    pic(s, ph(d['topic'], d.get('pi', 9)), 7.8, 0.9, 4.7, 2.9, geom='roundRect', adj=0.06, focus=(0.5, 0.42))
    for i, (v, lb) in enumerate(d['items'][:4]):
        x = 0.85 + (i % 2) * 6.0; y = 4.1 + (i // 2) * 1.3
        gradband(s, x, y + 0.1, 0.09, 0.9, 90)
        txt(s, x + 0.35, y, 2.4, 0.7, v, 30, P['acc'], 'bd')
        txt(s, x + 2.9, y + 0.15, 3.0, 0.7, lb, 10.5, P['mute'], sp=1.3)

@reg
def stat_trio_wide(prs, d):            # twin: stat_trio
    s = page(prs); _ft(s, d)
    shp(s, 'rect', 0, 0, W, H, P['panel'] if not P['dark'] else P['bg'])
    txt(s, 0.85, 1.0, 9.0, 1.1, d['t'], 30, P['ink'], 'bd')
    if d.get('s'): txt(s, 0.85, 2.15, 9.6, 0.5, d['s'], 12, P['mute'])
    for i, (v, lb, sub) in enumerate(d['items'][:3]):
        x = 0.85 + i * 3.95
        if i: ln(s, x - 0.35, 3.2, x - 0.35, 5.9, mix(P['bg'], P['mute'], 0.3), 0.75)
        txt(s, x, 3.2, 3.5, 1.3, v, fit_w(v, 3.5, 54, 26), P['acc'], 'bd', sp=0.95)
        txt(s, x, 4.55, 3.5, 0.45, lb, 14, P['ink'], 'md')
        txt(s, x, 5.1, 3.4, 0.8, sub, 10.5, P['mute'], sp=1.35)

@reg
def kpi_cards_photo(prs, d):           # twin: close_kpi_recap
    s = page(prs)
    pic(s, ph(d.get('topic', 'office'), d.get('pi', 26)), 0, 0, W, H, focus=(0.5, 0.4))
    shp(s, 'rect', 0, 0, W, H, P['bg'], a=0.86)
    txt(s, 0.85, 0.95, 8.6, 1.0, d['t'], 30, P['ink'], 'bd')
    for i, (v, lb) in enumerate(d['items'][:4]):
        x = 0.85 + (i % 4) * 2.98
        card(s, x, 2.4, 2.75, 2.6, mix(P['bg'], P['ink'], 0.05), adj=0.09)
        txt(s, x + 0.3, 2.75, 2.2, 0.9, v, 30, P['acc'], 'bd')
        txt(s, x + 0.3, 3.75, 2.2, 1.0, lb, 10.5, P['mute'], sp=1.35)
    if d.get('cta'):
        gradband(s, 0.85, 5.4, 11.6, 0.95, 0, kind='round', adj=0.3)
        txt(s, 0.85, 5.4, 11.6, 0.95, d['cta'], 13, 'FFFFFF', 'md', 'c', 'm')
