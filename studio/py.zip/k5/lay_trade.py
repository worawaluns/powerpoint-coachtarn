"""20 เลย์เอาต์ชุดโปรไฟล์บริษัทแนว editorial (Tradebox) — ลอกโครงจากเทมเพลตดำ + แดง + ขาว

หัวเรื่องตัวใหญ่มาก บล็อกสี่เหลี่ยมคมไม่มีมุมมน แดง ดำ เทา เรียงเป็นขั้นบันได
หน้าพื้นดำไล่แดงมีโค้งดาวเคราะห์ด้านล่าง เส้นตั้งมีจุดหัวท้ายคั่นตัวเลข หน่วยของตัวเลขเป็นสีแดง
หัวกระดาษสี่ช่อง: ชื่อบริษัท ชื่อเอกสาร ปี เลขหน้า
แดงบนดำ (4.07) ใช้กับตัวเลขและหน่วยตัวใหญ่เท่านั้น ขาวบนแดง 4.81 ใช้กับเนื้อความได้
"""
from pptx.util import Inches
from pptx.enum.text import PP_ALIGN
from eng import *
import eng
import base
from lay import L, reg

M = 0.62
K = '0E0B0D'           # ดำ
GR = 'D9D9D9'          # เทา
DR = '3A0A14'          # แดงเข้มเกือบดำ


def R(): return P['acc']


def _duo():
    return f"duo:{mix(K, R(), 0.22)}:{mix('FFFFFF', R(), 0.10)}"


def _poly(s, pts, fill):
    E = lambda v: int(Inches(v))
    fb = s.shapes.build_freeform(E(pts[0][0]), E(pts[0][1]), scale=1.0)
    fb.add_line_segments([(E(x), E(y)) for x, y in pts[1:]], close=True)
    sh = fb.convert_to_shape(); base._nostyle(sh)
    sh.fill.solid(); sh.fill.fore_color.rgb = base.rgb(fill); sh.line.fill.background()
    return sh


def _dark(s):
    gradband(s, 0, 0, W, H, 45, c1=mix(R(), K, 0.25), c2=K)
    shp(s, 'rect', 0, 0, W, H, K, a=0.35)


def _chrome(s, d, dark=False):
    c = 'FFFFFF' if dark else K
    txt(s, M, 0.32, 3.0, 0.34, d.get('brand', 'บริษัทของคุณ'), 12, c, 'md')
    txt(s, 4.70, 0.36, 2.6, 0.26, d.get('doc', 'โปรไฟล์บริษัท'), 9, c, 'rg')
    txt(s, 8.60, 0.36, 1.2, 0.26, d.get('yr', '2570'), 9, c, 'rg')
    if d.get('n'):
        txt(s, W - M - 0.8, 0.36, 0.8, 0.26, f"{int(d['n'])}", 9, c, 'rg', 'r')


def _h(s, x, y, t, sz=54, w=8.0, c=None, al='l'):
    txt(s, x, y, w, 3.0, t, sz, c or K, 'md', al, sp=0.98)


def _p(s, x, y, w, t, sz=11.5, c=None, al='l'):
    if t: txt(s, x, y, w, 2.0, t, sz, c or mix('FFFFFF', K, 0.78), 'rg', al, sp=1.36)


def _num(s, x, y, w, v, unit, sz=36, c='FFFFFF'):
    """ตัวเลขขาว หน่วยต่อท้ายสีแดง แบบต้นฉบับ"""
    txt(s, x, y, w, sz / 60, '', sz, c, 'md', runs=[[(v, {}), (unit, {'c': R()})]])


def _vline(s, x, y1, y2, c='FFFFFF'):
    ln(s, x, y1, x, y2, c, 1.2)
    for y in (y1, y2):
        shp(s, 'oval', x - 0.06, y - 0.06, 0.12, 0.12, c)


def _photo(s, n, x, y, w, h, focus=(0.5, 0.35), topic=None, d=None):
    pic(s, ph(topic or (d or {}).get('topic', 'logistics'), n), x, y, w, h, focus=focus, mode=_duo())


# ══ เลย์เอาต์ตามรูปอ้างอิง ═════════════════════════════════════════════════

@reg
def tb_cover(prs, d):
    s = page(prs, K)
    _photo(s, d.get('pi', 0), 6.70, 0, W - 6.70, H, d=d)
    gradband(s, 4.70, 0, 3.20, H, 0, c1=K, c2=K, a2=0.0)
    shp(s, 'rect', 0, 0, 6.70, H, K)
    gradband(s, 0, 0, 6.70, H, 45, c1=DR, c2=K, a1=0.9, a2=0.0)
    _chrome(s, {**d, 'n': ''}, True)
    _p(s, M, 1.30, 6.0, d.get('k', ''), 12, 'E8C7CC')
    _h(s, M, 1.80, d['t'], d.get('tsz', 68), 5.6 if 'tsz' in d else 11.0, 'FFFFFF')   # doc2slide ย่อหัวเรื่อง: อยู่ในแผงมืด ไม่ทับรูป
    shp(s, 'rect', 9.30, 4.70, W - 9.30, H - 4.70, R())
    icon(s, 'arrow-up-right', 9.80, 5.20, 0.42, 'FFFFFF')
    _p(s, 9.65, 5.65, 3.2, d.get('s', ''), 11.5, 'FFFFFF')


@reg
def tb_milestones(prs, d):
    s = page(prs)
    _chrome(s, d)
    _h(s, M, 0.95, d['t'], 54, 5.6)
    _p(s, M, 5.60, 4.2, d.get('note', ''), 12, K)
    n = len(d['items'][:4]); cw = (W - 5.10) / n
    fills = [GR, K, R(), K][:n]
    for i, (yr, ic, body) in enumerate(d['items'][:4]):
        x = 5.10 + i * cw
        top = 4.30 - i * 1.10
        f = fills[i] if i < n - 1 else R()
        shp(s, 'rect', x, top, cw, H - top, f)
        tc = K if f == GR else 'FFFFFF'
        txt(s, x + 0.25, top + 0.25, cw - 0.4, 0.70, yr, 34, tc, 'md')
        icon(s, ic, x + 0.40, top + 1.30, 0.32, tc)
        _p(s, x + 0.25, top + 1.65, cw - 0.45, body, 10.5, tc)
    icon(s, d.get('ic', 'chart-line'), 5.45, 1.20, 0.50, K)
    _p(s, 6.00, 0.98, 3.4, d.get('note2', ''), 10.5, K)


@reg
def tb_impact(prs, d):
    s = page(prs, K)
    _dark(s)
    shp(s, 'oval', -2.0, 4.70, W + 4.0, 9.0, grad=(mix(R(), K, 0.45), DR, 90))
    _chrome(s, d, True)
    n = len(d['items'][:5]); cw = (W - M * 2) / n
    ends = [6.65, 4.80, 4.35, 4.80, 6.25]          # เส้นกลางสามเส้นจบเหนือหัวเรื่อง ไม่งั้นผ่ากลางตัวหนังสือ
    for i, (ic, v, unit, lab) in enumerate(d['items'][:5]):
        x = M + 0.25 + i * cw
        _vline(s, x, 1.20, ends[i])
        icon(s, ic, x + 0.55, 1.42, 0.40, 'FFFFFF')
        _num(s, x + 0.30, 1.95, cw - 0.3, v, unit, 34)
        _p(s, x + 0.30, 2.85, cw - 0.55, lab, 11, 'F2E6E8')
    _h(s, 0, 5.20, d['t'], 46, W, 'FFFFFF', 'c')


@reg
def tb_values(prs, d):
    s = page(prs)
    gradband(s, 7.80, 0, W - 7.80, H, 0, c1='FFFFFF', c2=mix('FFFFFF', R(), 0.30))
    _poly(s, [(9.10, 2.70), (10.40, 1.40), (W, 1.40), (W, H), (9.10, H)], R())
    _photo(s, d.get('pi', 3), 9.70, 2.20, W - 9.70, H - 2.20, (0.5, 0.25), topic='office')
    _chrome(s, d)
    _p(s, M, 0.95, 4.0, d.get('k', ''), 11, K)
    _h(s, M, 1.30, d['t'], 54, 8.2)
    fills = [R(), K, GR]
    for i, (lab, body) in enumerate(d['items'][:3]):
        y = 4.05 + i * 1.10
        w = 7.80 - i * 0.90
        shp(s, 'rect', 0, y, w, 1.00, fills[i])
        tc = K if i == 2 else 'FFFFFF'
        txt(s, M + 0.10, y, 2.0, 1.00, lab, 18, tc, 'md', an='m')
        _p(s, M + 2.20, y + 0.22, w - M - 2.5, body, 11, tc)


@reg
def tb_gateway(prs, d):
    s = page(prs, K)
    _photo(s, d.get('pi', 5), 7.20, 0, W - 7.20, 2.90, d=d)
    shp(s, 'rect', 7.20, 0, W - 7.20, 2.90, K, a=0.35)
    shp(s, 'rect', 0, 2.90, 9.30, 0.02, mix(K, 'FFFFFF', 0.25))
    shp(s, 'rect', 9.30, 2.90, W - 9.30, H - 2.90, R())
    _chrome(s, d, True)
    _h(s, M, 1.10, d['t'], 96, 12.5, 'FFFFFF')
    icon(s, d.get('ic', 'trending-up'), 9.85, 3.60, 0.50, 'FFFFFF')
    _p(s, 9.75, 4.15, 3.1, d.get('note', ''), 12, 'FFFFFF')


@reg
def tb_div_white(prs, d):
    s = page(prs)
    _chrome(s, d)
    shp(s, 'rect', 0, 4.95, W * 0.62, 0.22, R())
    shp(s, 'rect', W * 0.62, 4.95, W * 0.38, 0.22, K)
    _p(s, M, 1.55, 5.0, d.get('k', ''), 12, R())
    _h(s, M, 2.00, d['t'], 80, 12.0)
    _p(s, M, 5.55, 7.0, d.get('note', ''), 12.5, K)


# ══ อีก 14 เลย์เอาต์ในระบบเดียวกัน ════════════════════════════════════════

@reg
def tb_chart_rev(prs, d):
    s = page(prs)
    _chrome(s, d)
    _h(s, M, 0.95, d['t'], 44, 5.2)
    for i, (v, unit, lab) in enumerate(d['items'][:2]):
        y = 3.40 + i * 1.55
        shp(s, 'rect', M, y, 0.10, 1.20, R() if i == 0 else K)
        _num(s, M + 0.30, y - 0.05, 4.2, v, unit, 36, K)
        _p(s, M + 0.30, y + 0.72, 4.0, lab, 11, K)
    chart(s, 'col', 5.60, 1.00, W - M - 5.60, 5.90, d['cats'], [(d['sname'], d['vals'])],
          [K] * (len(d['vals']) - 1) + [R()], labels=True, fmt='#,##0', gap=40, sz=12, c=K, vary=True)


@reg
def tb_donut(prs, d):
    s = page(prs, K)
    _dark(s)
    _chrome(s, d, True)
    _h(s, M, 0.95, d['t'], 44, 6.0, 'FFFFFF')
    cols = [R(), 'FFFFFF', GR, mix(R(), K, 0.5)]
    it = d['items'][:4]
    chart(s, 'donut', 7.10, 0.85, 5.80, 5.80, [x[0] for x in it], [('ร้อยละ', [x[1] for x in it])],
          cols, labels=False, hole=64)
    _num(s, 7.10, 3.20, 5.80, d['big'], d['bigunit'], 40)
    s.shapes[-1].text_frame.paragraphs[0].alignment = PP_ALIGN.CENTER
    txt(s, 7.10, 4.00, 5.80, 0.30, d['biglab'], 11, 'F2E6E8', 'rg', 'c')
    for i, (lab, v, body) in enumerate(it):
        y = 2.80 + i * 1.02
        shp(s, 'rect', M, y + 0.08, 0.22, 0.22, cols[i])
        txt(s, M + 0.40, y, 3.2, 0.40, lab, 14, 'FFFFFF', 'md')
        _p(s, M + 0.40, y + 0.42, 4.6, body, 10.5, 'F2E6E8')
        txt(s, 4.70, y, 1.40, 0.40, f'{v}%', 16, 'FFFFFF', 'md', 'r')


@reg
def tb_line(prs, d):
    s = page(prs)
    _chrome(s, d)
    _h(s, M, 0.95, d['t'], 44, 8.0)
    shp(s, 'rect', 9.10, 0, W - 9.10, H, K)
    chart(s, 'line', M - 0.1, 2.30, 8.20, 4.70, d['cats'], [(d['sname'], d['vals'])], [R()], labels=True,
          fmt='0.0', sz=11, c=K, lw=3.5, minv=95, maxv=100)
    for i, (v, unit, lab) in enumerate(d['items'][:3]):
        y = 1.15 + i * 1.95
        _num(s, 9.55, y, 3.4, v, unit, 40)
        _p(s, 9.55, y + 0.85, 3.3, lab, 11, 'F2E6E8')
        if i < 2: ln(s, 9.55, y + 1.65, W - M, y + 1.65, mix(K, 'FFFFFF', 0.25), 0.8)


@reg
def tb_services(prs, d):
    s = page(prs)
    _chrome(s, d)
    _h(s, M, 0.95, d['t'], 44, 5.2)
    _p(s, M, 2.40, 4.6, d.get('note', ''), 12, K)
    spec = [(5.80, 0.95, R()), (9.30, 0.95, K), (5.80, 3.95, GR), (9.30, 3.95, 'F2F2F2')]
    for (ic, h_, body), (x, y, f) in zip(d['items'][:4], spec):
        shp(s, 'rect', x, y, 3.40, 2.85, f)
        tc = 'FFFFFF' if f in (R(), K) else K
        icon(s, ic, x + 0.55, y + 0.60, 0.44, tc)
        txt(s, x + 0.30, y + 1.10, 2.9, 0.42, h_, 16, tc, 'md')
        _p(s, x + 0.30, y + 1.58, 2.9, body, 10.5, tc)


@reg
def tb_coverage(prs, d):
    s = page(prs, K)
    _dark(s)
    _chrome(s, d, True)
    _h(s, M, 0.95, d['t'], 44, 5.0, 'FFFFFF')
    _num(s, M, 2.60, 5.0, d['big'], d['bigunit'], 96)
    _p(s, M, 4.30, 4.6, d['biglab'], 12, 'F2E6E8')
    mx = max(v for _, v, _ in d['items'])
    for i, (lab, v, body) in enumerate(d['items'][:5]):
        y = 1.15 + i * 1.12
        txt(s, 6.40, y, 2.0, 0.40, lab, 14, 'FFFFFF', 'md')
        _p(s, 6.40, y + 0.42, 2.6, body, 10, 'F2E6E8')
        bw = 3.30 * v / mx
        shp(s, 'rect', 9.10, y + 0.08, 3.30, 0.42, mix(K, 'FFFFFF', 0.14))
        shp(s, 'rect', 9.10, y + 0.08, bw, 0.42, R() if i == 0 else 'FFFFFF')
        txt(s, 9.10 + bw - 0.70, y + 0.08, 0.60, 0.42, str(v), 12, 'FFFFFF' if i == 0 else K, 'md', 'r', 'm')


@reg
def tb_process(prs, d):
    s = page(prs)
    _chrome(s, d)
    _h(s, M, 0.95, d['t'], 44, 9.0)
    n = len(d['items'][:5]); cw = (W - M * 2) / n
    for i, (ic, h_, body) in enumerate(d['items'][:5]):
        x = M + 0.15 + i * cw
        _vline(s, x, 2.55, 6.70, R() if i == n - 1 else K)
        icon(s, ic, x + 0.55, 2.85, 0.40, R() if i == n - 1 else K)
        txt(s, x + 0.30, 3.40, cw - 0.4, 0.80, h_, 16, K, 'md', sp=1.05)
        _p(s, x + 0.30, 4.30, cw - 0.45, body, 10.5, K)
    shp(s, 'rect', 0, H - 0.18, W, 0.18, R())


@reg
def tb_case(prs, d):
    s = page(prs)
    _photo(s, d.get('pi', 7), 0, 0, 5.40, H, d=d)
    shp(s, 'rect', 0, H - 2.10, 5.40, 2.10, R())
    _p(s, M, H - 1.85, 4.4, d.get('client', ''), 12, 'FFFFFF')
    txt(s, 5.95, 0.32, 3.0, 0.34, d.get('brand', 'บริษัทของคุณ'), 12, K, 'md')    # หัวกระดาษเฉพาะฝั่งขาว ไม่ทับรูป
    txt(s, 8.60, 0.36, 1.2, 0.26, d.get('yr', '2570'), 9, K, 'rg')
    txt(s, W - M - 0.8, 0.36, 0.8, 0.26, f"{int(d['n'])}", 9, K, 'rg', 'r')
    _p(s, 5.95, 1.05, 6.0, d.get('k', ''), 11, R())
    _h(s, 5.95, 1.40, d['t'], 40, 6.9)
    for i, (lab, a, b) in enumerate(d['items'][:3]):
        y = 3.60 + i * 1.12
        ln(s, 5.95, y, W - M, y, GR, 1)
        txt(s, 5.95, y + 0.18, 3.0, 0.40, lab, 13, K, 'md')
        txt(s, 9.00, y + 0.10, 1.60, 0.60, a, 22, mix('FFFFFF', K, 0.45), 'md', 'r')
        icon(s, 'arrow-right', 10.95, y + 0.45, 0.30, K)
        txt(s, 11.20, y + 0.10, 1.50, 0.60, b, 22, R(), 'md', 'r')


@reg
def tb_table(prs, d):
    s = page(prs)
    _chrome(s, d)
    _h(s, M, 0.95, d['t'], 44, 9.0)
    cols = d['colw']; tw = W - M * 2; y0 = 2.35; rh = 0.84
    xs = [M]
    for f in cols[:-1]: xs.append(xs[-1] + tw * f)
    shp(s, 'rect', M, y0, tw, 0.62, K)
    for j, hd in enumerate(d['head']):
        txt(s, xs[j] + 0.22, y0, tw * cols[j] - 0.4, 0.62, hd, 12, 'FFFFFF', 'md', 'l' if j == 0 else 'c', 'm')
    for i, row in enumerate(d['rows']):
        y = y0 + 0.62 + i * rh
        hot = i == 0
        if hot: shp(s, 'rect', M, y, tw, rh, R())
        else: ln(s, M, y + rh, W - M, y + rh, GR, 1)
        for j, cell in enumerate(row):
            txt(s, xs[j] + 0.22, y, tw * cols[j] - 0.4, rh, cell, 13 if j == 0 else 12,
                'FFFFFF' if hot else K, 'md' if j in (0, len(row) - 1) else 'rg', 'l' if j == 0 else 'c', 'm')
    _p(s, M, y0 + 0.62 + len(d['rows']) * rh + 0.20, 11.5, d.get('note', ''), 10.5, P['mute'])


@reg
def tb_team(prs, d):
    s = page(prs)
    _chrome(s, d)
    _h(s, M, 0.95, d['t'], 44, 4.4)
    _p(s, M, 2.40, 3.9, d.get('note', ''), 12, K)
    cw = 2.45
    for i, (name, role, body, pi, fx) in enumerate(d['items'][:3]):
        x = 5.05 + i * (cw + 0.15)
        top = 1.00 + (2 - i) * 0.55
        _photo(s, pi, x, top, cw, 3.60, (fx, 0.25), topic='office')
        shp(s, 'rect', x, top + 3.60, cw, 0.18, R() if i == 2 else K)
        txt(s, x, top + 3.95, cw, 0.40, name, 15, K, 'md')
        txt(s, x, top + 4.35, cw, 0.30, role, 11, R(), 'md')
        _p(s, x, top + 4.70, cw, body, 10.5, K)


@reg
def tb_quote(prs, d):
    s = page(prs, R())
    _chrome(s, d, True)
    shp(s, 'rect', 0, 0, 0.30, H, K)
    icon(s, 'quote', 1.10, 1.60, 0.80, 'FFFFFF')
    txt(s, M + 0.30, 2.20, 10.6, 3.0, d['t'], 30, 'FFFFFF', 'md', sp=1.25)
    ln(s, M + 0.30, 5.60, M + 1.30, 5.60, 'FFFFFF', 2)
    txt(s, M + 0.30, 5.80, 8.0, 0.40, d['who'], 15, 'FFFFFF', 'md')
    _p(s, M + 0.30, 6.22, 8.0, d['role'], 11.5, 'FFFFFF')


@reg
def tb_why(prs, d):
    s = page(prs)
    _chrome(s, d)
    shp(s, 'rect', 0, 0.95, 0.30, 5.60, R())
    _h(s, M + 0.10, 0.95, d['t'], 44, 4.6)
    for i, (h_, body) in enumerate(d['items'][:3]):
        y = 1.05 + i * 1.95
        ln(s, 5.80, y, W - M, y, K, 1.4)
        txt(s, 5.80, y + 0.20, 6.9, 0.60, h_, 26, R() if i == 0 else K, 'md')
        _p(s, 5.80, y + 0.95, 6.9, body, 11.5, K)


@reg
def tb_fleet(prs, d):
    s = page(prs)
    _photo(s, d.get('pi', 2), 6.60, 0.95, W - 6.60 - M, 3.70, d=d)
    shp(s, 'rect', 6.60, 4.65, W - 6.60 - M, 0.20, R())
    _chrome(s, d)
    _p(s, M, 1.05, 5.0, d.get('k', ''), 12, R())
    _num(s, M, 1.40, 6.0, d['big'], d['bigunit'], 110, K)
    _p(s, M, 3.40, 5.4, d['biglab'], 12.5, K)
    n = len(d['items'][:3]); cw = (W - M * 2 - 0.40) / n
    fills = [K, GR, R()]
    for i, (v, lab) in enumerate(d['items'][:3]):
        x = M + i * (cw + 0.20)
        shp(s, 'rect', x, 5.25, cw, 1.60, fills[i])
        tc = K if fills[i] == GR else 'FFFFFF'
        txt(s, x + 0.30, 5.40, 2.2, 0.70, v, 34, tc, 'md')
        _p(s, x + 0.30, 6.15, cw - 0.6, lab, 11, tc)


@reg
def tb_next(prs, d):
    s = page(prs, K)
    _dark(s)
    _chrome(s, d, True)
    _h(s, M, 0.95, d['t'], 54, 8.0, 'FFFFFF')
    cw = (W - M * 2 - 0.40) / 3
    for i, (when, h_, body) in enumerate(d['items'][:3]):
        x = M + i * (cw + 0.20)
        top = 3.40 - i * 0.55
        f = [mix(K, 'FFFFFF', 0.10), mix(K, 'FFFFFF', 0.16), R()][i]
        shp(s, 'rect', x, top, cw, H - 0.55 - top, f)
        txt(s, x + 0.30, top + 0.30, cw - 0.6, 0.40, when, 12, 'FFFFFF', 'md')
        txt(s, x + 0.30, top + 0.80, cw - 0.6, 0.90, h_, 22, 'FFFFFF', 'md', sp=1.05)
        _p(s, x + 0.30, top + 1.80, cw - 0.6, body, 11, 'FFFFFF' if i == 2 else 'F2E6E8')


@reg
def tb_close(prs, d):
    s = page(prs, K)
    _photo(s, d.get('pi', 4), 0, 0, W, H, d=d)
    shp(s, 'rect', 0, 0, W, H, K, a=0.30)
    gradband(s, 0, 0, W * 0.70, H, 0, c1=K, c2=K, a1=0.97, a2=0.0)
    _chrome(s, d, True)
    _h(s, M, 1.30, d['t'], 88, 9.0, 'FFFFFF')
    _p(s, M, 4.55, 6.0, d.get('note', ''), 13, 'F2E6E8')
    for i, (lab, v) in enumerate(d['items'][:3]):
        y = 5.35 + i * 0.52
        txt(s, M, y, 1.8, 0.36, lab, 11, 'F2E6E8', 'rg')
        txt(s, M + 1.90, y, 5.0, 0.36, v, 13, 'FFFFFF', 'md')
    shp(s, 'rect', W - 3.20, H - 1.20, 3.20, 1.20, R())
    txt(s, W - 3.00, H - 1.20, 2.8, 1.20, d.get('cta', ''), 13, 'FFFFFF', 'md', an='m')
