"""20 เลย์เอาต์ชุดนำเสนอผลสหกิจศึกษา เทา+ส้ม+ดำ — ลอกโครงจากชุด 162 coop-b3 (ใบงาน 021, ไอซ์ "ชอบมาก" 30 ต.ค. 2569)

ต้นฉบับ: ไฟล์ .pptx ของชุด 162 (ไม่มีโค้ดเดิม) ลอกโครงทีละหน้าจากรูปในคลัง library/slides/coop-b3/
พื้นเทาอ่อน การ์ดเทากลางตัดมุมขวาบน (snip1) การ์ดเด่นส้ม มีลูกศรเฉียงมุมล่างขวา รูปขาวดำ
หัวเรื่องมีขีดส้มตั้งหน้า ตารางหัวดำ
สี: ส้ม FF5A1F กับตัวขาว = 3.1 ไม่ผ่าน → ตัวหนังสือบนส้มใช้ดำ 1B1B1B (5.5) เสมอ ส้มห้ามเป็นตัวหนังสือบนเทา (3.0)
ทุกข้อความมาจาก d (doc2slide เติมเนื้อลูกค้า) ไม่มีค่าตั้งต้นที่เป็นคำ (d.get(k, '') เท่านั้น)
ไม่มีเลข 01/02 ตกแต่ง (กฎไอซ์) ต้นฉบับมีเลขลำดับ ตัดออก
"""
from eng import *
import eng
from lay import L, reg

txt = txt_big
chart = chart_big

# พาเลตต์ของชุด ลงทะเบียนจากโมดูลนี้ (ไม่แตะ eng.py ระหว่างที่คนอื่นแก้อยู่)
eng.PAL.setdefault('coop_orange', dict(bg='EFEFEC', ink='1B1B1B', mute='5F5E5A', acc='FF5A1F', acc2='DCDDD8',
                                       g1='1B1B1B', g2='FF5A1F', dark=0, panel='DCDDD8'))

M = 0.62
K = '1B1B1B'
BG = 'EFEFEC'
CARD = 'DCDDD8'
CARD2 = 'E6E6E2'
WH = 'FFFFFF'
MU = '5F5E5A'
SOFT = 'BDBDB8'


def O(): return P['acc']


def _duo(): return f"duo:{K}:{BG}"


def _photo(s, n, x, y, w, h, topic, focus=(0.5, 0.4), geom=None, adj=None):
    return pic(s, ph(topic, n), x, y, w, h, focus=focus, mode=_duo(), geom=geom, adj=adj)


def _page(prs, bg=BG):
    s = page(prs, bg)
    shp(s, 'rect', M, 0.34, 1.10, 0.03, SOFT)            # เส้นบางมุมบนซ้ายแทนชื่อมหาวิทยาลัยในต้นฉบับ (ไม่มีคำ)
    return s


def _h(s, x, y, t, w=7.0, sz=30, c=K, bar=True):
    if bar: shp(s, 'rect', x, y + 0.10, 0.07, 0.50, O())
    txt(s, x + (0.24 if bar else 0), y, w, 1.30, t, sz, c, 'md', sp=1.08)


def _p(s, x, y, w, t, sz=13, c=MU, h=1.2, al='l'):
    if t: txt(s, x, y, w, h, t, sz, c, 'rg', al, sp=1.30)


def _arrow(s, x, y, c=K, sz=0.30):
    icon(s, 'arrow-up-right', x, y, sz, c)


def _snip(s, x, y, w, h, fill, adj=0.12):
    return shp(s, 'snip1', x, y, w, h, fill, adj=adj)


# ══ ปก / สารบัญ / ผู้นำเสนอ ════════════════════════════════════════════════

@reg
def co_cover(prs, d):
    s = page(prs, BG)
    for i in range(9):                                     # เส้นเฉียงมุมขวาบน
        x = 8.6 + i * 0.36
        ln(s, x, 0, x + 1.4, 1.0, CARD, 0.8)
    _snip(s, M, 0.95, 6.75, 3.45, WH, 0.10)
    txt(s, M + 0.45, 1.35, 5.9, 2.70, d['t'], d.get('tsz', 40), K, 'md', sp=1.08)
    _snip(s, 7.62, 0.95, W - M - 7.62, 3.45, O(), 0.10)
    _p(s, 7.98, 1.35, W - M - 8.36, d.get('s', ''), 17, K, h=2.3)
    shp(s, 'oval', W - M - 0.86, 3.70, 0.52, 0.52, K)
    _arrow(s, W - M - 0.60, 3.96, WH, 0.26)
    _photo(s, d.get('pi', 0), M, 4.72, 6.75, 2.20, d['topic'], (0.5, 0.35))
    _photo(s, d.get('pi2', 4), 7.62, 4.72, W - M - 7.62, 2.20, d['topic'], (0.5, 0.4))


@reg
def co_agenda(prs, d):
    s = _page(prs)
    _h(s, M, 0.85, d['t'], 4.6, 34)
    _p(s, M + 0.24, 2.35, 4.2, d.get('s', ''), 13)
    x, w = 6.10, W - M - 6.10
    it = d['items'][:6]
    rh = min(0.86, 5.4 / max(len(it), 1))
    for i, t in enumerate(it):
        y = 0.95 + i * rh
        txt(s, x, y, w, rh - 0.16, t, 17, K, 'md', an='m')
        ln(s, x, y + rh - 0.06, x + w, y + rh - 0.06, SOFT, 0.8)
    _arrow(s, M + 0.15, H - 0.75, O(), 0.34)


@reg
def co_profile(prs, d):
    s = _page(prs)
    _photo(s, d.get('pi', 2), M, 0.80, 4.30, 6.10, d['topic'], (0.5, 0.3))
    _h(s, 5.40, 0.80, d['t'], 7.0, 30)
    it = d['items'][:5]
    rh = min(0.86, 4.6 / max(len(it), 1))
    for i, (lab, val) in enumerate(it):
        y = 2.30 + i * rh
        txt(s, 5.64, y, 2.40, rh - 0.12, lab, 12.5, MU, 'rg', an='m')
        txt(s, 8.10, y, W - M - 8.10, rh - 0.12, val, 15, K, 'md', an='m')
        ln(s, 5.64, y + rh - 0.04, W - M, y + rh - 0.04, SOFT, 0.7)


@reg
def co_facts(prs, d):
    s = _page(prs)
    it = d['items'][:4]
    _snip(s, M, 0.80, 4.30, 2.70, O(), 0.12)
    if it:
        txt(s, M + 0.36, 1.05, 3.6, 1.00, it[0][0], 44, K, 'md')
        _p(s, M + 0.36, 2.15, 3.5, it[0][1], 13, K, h=1.0)
    _photo(s, d.get('pi', 3), 5.20, 0.80, W - M - 5.20, 2.70, d['topic'], (0.5, 0.45))
    _h(s, M, 4.15, d['t'], 4.2, 30)
    _p(s, M + 0.24, 5.55, 4.0, d.get('s', ''), 12.5, h=1.2)
    rest = it[1:]
    if rest:
        cw = (W - M - 5.20) / len(rest)
        for i, (v, lab) in enumerate(rest):
            x = 5.20 + i * cw
            ln(s, x, 4.20, x + cw - 0.30, 4.20, K, 1.0)
            txt(s, x, 4.40, cw - 0.30, 0.66, v, 24, K, 'md')
            _p(s, x, 5.15, cw - 0.36, lab, 12.5, h=1.5)


# ══ เนื้อหา ═══════════════════════════════════════════════════════════════

@reg
def co_tasks(prs, d):
    s = _page(prs)
    _h(s, M, 0.80, d['t'], 6.0, 32)
    _p(s, 7.20, 0.90, W - M - 7.20, d.get('s', ''), 12.5, h=1.0)
    it = d['items'][:4]
    n = max(len(it), 1); gap = 0.24
    cw = (W - M * 2 - gap * (n - 1)) / n
    for i, (h_, body) in enumerate(it):
        x = M + i * (cw + gap); hot = i == n - 1
        _snip(s, x, 2.35, cw, 4.45, O() if hot else CARD, 0.10)
        txt(s, x + 0.30, 2.62, cw - 0.75, 0.90, h_, 18, K, 'md', sp=1.1)
        _p(s, x + 0.30, 3.70, cw - 0.60, body, 13, K if hot else MU, h=2.4)
        _arrow(s, x + cw - 0.42, 6.42, K, 0.28)


@reg
def co_timeline_day(prs, d):
    s = _page(prs)
    _h(s, M, 0.80, d['t'], 6.6, 30)
    it = d['items'][:6]
    rh = min(0.82, 4.9 / max(len(it), 1))
    x0 = M + 0.24
    ln(s, x0 + 1.52, 2.15, x0 + 1.52, 2.15 + rh * len(it) - 0.30, SOFT, 0.8)
    for i, (tm, h_, body) in enumerate(it):
        y = 2.05 + i * rh; hot = i == len(it) // 2
        txt(s, x0, y, 1.30, 0.36, tm, 12.5, MU, 'rg')
        shp(s, 'oval', x0 + 1.44, y + 0.10, 0.16, 0.16, O() if hot else K)
        txt(s, x0 + 1.82, y - 0.02, 5.0, 0.40, h_, 14.5, K, 'md' if hot else 'rg')
        _p(s, x0 + 1.82, y + 0.34, 5.0, body, 12, h=rh - 0.34)
    pw = (W - M - 8.20 - 0.24) / 3
    for j in range(3):
        _photo(s, d.get('pi', 5) + j, 8.20 + j * (pw + 0.12), 0.80, pw, 6.10, d['topic'], (0.5, 0.35))


@reg
def co_statement(prs, d):
    s = page(prs, BG)
    _photo(s, d.get('pi', 7), 0, 0, 5.60, H, d['topic'], (0.5, 0.4))
    shp(s, 'rect', 6.30, 1.40, 0.07, 0.50, O())
    txt(s, 6.54, 1.30, W - M - 6.54, 2.60, d['t'], 32, K, 'md', sp=1.1)
    _p(s, 6.54, 4.10, W - M - 6.54, d.get('s', ''), 15, h=2.4)
    _arrow(s, W - M - 0.20, H - 0.70, O(), 0.34)


@reg
def co_problem(prs, d):
    s = page(prs, BG)
    _photo(s, d.get('pi', 8), 0, 0, 5.20, H, d['topic'], (0.5, 0.4))
    txt(s, 5.80, 0.80, W - M - 5.80, 1.50, d['t'], 28, K, 'md', sp=1.1)
    _p(s, 5.80, 2.30, W - M - 5.80, d.get('s', ''), 13, h=0.9)
    it = d['items'][:3]
    for i, (v, lab) in enumerate(it):
        y = 3.40 + i * 1.12
        ln(s, 5.80, y, W - M, y, SOFT, 0.7)
        shp(s, 'rect', 5.80, y + 0.22, 0.07, 0.56, O())
        txt(s, 6.05, y + 0.16, 2.60, 0.70, v, 28, K, 'md')
        _p(s, 8.80, y + 0.24, W - M - 8.80, lab, 13, h=0.80)


@reg
def co_scope(prs, d):
    s = _page(prs)
    _h(s, M, 0.80, d['t'], 9.0, 30)
    cw = (W - M * 2 - 0.50) / 2
    for i, (h_, lst) in enumerate(d['items'][:2]):
        x = M + i * (cw + 0.50)
        txt(s, x, 2.10, cw, 0.44, h_, 17, K, 'md')
        shp(s, 'rect', x, 2.62, cw, 0.05, O() if i == 0 else K)
        lst = lst[:4]
        rh = min(0.98, 4.0 / max(len(lst), 1))
        for j, t in enumerate(lst):
            y = 2.90 + j * rh
            shp(s, 'round', x, y, cw, rh - 0.16, WH if i == 0 else CARD2, adj=0.10)
            shp(s, 'oval', x + 0.24, y + (rh - 0.16) / 2 - 0.12, 0.24, 0.24, None, line=O(), lw=2)
            txt(s, x + 0.66, y, cw - 0.86, rh - 0.16, t, 13.5, K, 'rg', an='m')


@reg
def co_steps(prs, d):
    s = _page(prs)
    _h(s, M, 0.80, d['t'], 7.0, 30)
    _p(s, 8.20, 0.90, W - M - 8.20, d.get('s', ''), 12.5, h=1.0)
    it = d['items'][:5]
    n = max(len(it), 1); cw = (W - M * 2) / n; sq = 0.86
    ln(s, M + sq, 2.95, M + (n - 1) * cw, 2.95, SOFT, 1.0)
    for i, (h_, body) in enumerate(it):
        x = M + i * cw; hot = i == n // 2
        shp(s, 'snip1', x, 2.52, sq, sq, O() if hot else K, adj=0.18)
        icon(s, 'arrow-right', x + sq / 2, 2.95, 0.36, K if hot else WH)
        txt(s, x, 3.70, cw - 0.30, 0.80, h_, 16, K, 'md', sp=1.1)
        _p(s, x, 4.50, cw - 0.34, body, 12.5, h=2.2)


@reg
def co_chart_col(prs, d):
    s = _page(prs)
    _h(s, M, 0.80, d['t'], 4.4, 30)
    _snip(s, M, 2.55, 4.30, 4.30, O(), 0.10)
    _p(s, M + 0.34, 2.85, 3.6, d.get('s', ''), 15, K, h=3.6)
    n = len(d['vals'])
    chart(s, 'col', 5.30, 1.00, W - M - 5.30, 5.85, d['cats'], [(d.get('sname', ''), d['vals'])], [SOFT] * (n - 1) + [O()],
          labels=True, fmt='#,##0', gap=55, sz=12, c=K, vary=True)


@reg
def co_chart_bar(prs, d):
    s = _page(prs)
    _h(s, M, 0.80, d['t'], 7.0, 30)
    _p(s, M + 0.24, 1.80, 6.8, d.get('s', ''), 12.5, h=0.8)
    n = len(d['vals'])
    chart(s, 'bar', M, 2.55, 7.40, 4.35, d['cats'], [(d.get('sname', ''), d['vals'])], [K] * n,
          labels=True, fmt='#,##0', gap=60, sz=12, c=K)
    _photo(s, d.get('pi', 9), 8.60, 0.80, W - M - 8.60, 6.10, d['topic'], (0.5, 0.35))


@reg
def co_numbers(prs, d):
    s = _page(prs)
    _h(s, M, 0.80, d['t'], 7.4, 30)
    _p(s, 8.40, 0.90, W - M - 8.40, d.get('s', ''), 12.5, h=1.0)
    it = d['items'][:4]
    n = max(len(it), 1); cw = (W - M * 2) / n
    for i, (v, lab) in enumerate(it):
        x = M + i * cw
        ln(s, x, 2.90, x + cw - 0.36, 2.90, O() if i == 0 else K, 1.6 if i == 0 else 0.8)
        txt(s, x, 3.15, cw - 0.36, 1.20, v, 54, K, 'rg')
        _p(s, x, 4.55, cw - 0.40, lab, 13, h=1.6)
    _arrow(s, W - M - 0.20, H - 0.70, O(), 0.34)


@reg
def co_table(prs, d):
    s = _page(prs)
    _h(s, M, 0.80, d['t'], 9.0, 30)
    head, rows = d['head'], d['rows'][:6]
    nc = len(head); tw = W - M * 2
    cols = d.get('colw') or [1] * nc
    tot = sum(cols); cols = [c / tot for c in cols]
    y0, hh = 2.05, 0.56
    rh = min(0.62, 4.5 / max(len(rows), 1))
    shp(s, 'rect', M, y0, tw, hh, K)
    al = d.get('al') or ['l'] * nc
    cx = M
    for j, (hd, fr) in enumerate(zip(head, cols)):
        txt(s, cx + 0.20, y0, tw * fr - 0.40, hh, hd, 13.5, WH, 'md', al[j] if j < len(al) else 'l', 'm')
        cx += tw * fr
    for i, row in enumerate(rows):
        y = y0 + hh + i * rh
        shp(s, 'rect', M, y, tw, rh, WH if i % 2 == 0 else BG)
        ln(s, M, y + rh, M + tw, y + rh, CARD, 0.6)
        cx = M
        for j, (cell, fr) in enumerate(zip(row, cols)):
            txt(s, cx + 0.20, y, tw * fr - 0.40, rh, cell, 13.5, K, 'md' if j == 0 else 'rg', al[j] if j < len(al) else 'l', 'm')
            cx += tw * fr
    if d.get('note'): _p(s, M, y0 + hh + len(rows) * rh + 0.20, 10.0, d['note'], 12.5, h=0.6)


@reg
def co_list(prs, d):
    """รายการข้อความล้วน หน้าที่สอง (ใบงาน 021 ข้อ 4: ไม่ให้ co_gallery ถูกเลือกซ้ำในเด็คเดียว)"""
    s = _page(prs)
    _h(s, M, 0.80, d['t'], 4.3, 30)
    _photo(s, d.get('pi', 11), M, 3.20, 4.30, 3.70, d['topic'], (0.5, 0.35))
    it = d['items'][:6]
    rh = min(0.98, 5.9 / max(len(it), 1))
    x, w = 5.55, W - M - 5.55
    for i, t in enumerate(it):
        y = 0.90 + i * rh
        shp(s, 'rect', x, y + 0.16, 0.14, 0.14, O() if i == 0 else K)
        txt(s, x + 0.40, y, w - 0.40, rh - 0.14, t, 15, K, 'rg', sp=1.2)
        ln(s, x, y + rh - 0.06, x + w, y + rh - 0.06, SOFT, 0.7)


@reg
def co_chart_line(prs, d):
    s = _page(prs)
    _h(s, M, 0.80, d['t'], 7.4, 30)
    _p(s, M + 0.24, 1.80, 7.4, d.get('s', ''), 12.5, h=0.8)
    shp(s, 'snip1', M, 2.55, W - M * 2, 4.35, WH, adj=0.06)
    chart(s, 'line', M + 0.30, 2.75, W - M * 2 - 0.60, 3.95, d['cats'], [(d.get('sname', ''), d['vals'])], [O()],
          labels=True, fmt='#,##0.##', sz=12, c=K, lw=3)


@reg
def co_gallery(prs, d):
    s = _page(prs)
    _h(s, M, 0.80, d['t'], 4.0, 30)
    it = d['items'][:4]
    boxes = [(4.95, 0.80, 3.80, 2.95), (8.91, 0.80, W - M - 8.91, 2.95), (4.95, 3.92, 3.80, 2.98), (8.91, 3.92, W - M - 8.91, 2.98)]
    _photo(s, d.get('pi', 10), M, 3.00, 4.10, 3.90, d['topic'], (0.5, 0.35))
    for i, (x, y, w, h) in enumerate(boxes):
        _photo(s, d.get('pi', 10) + 1 + i, x, y, w, h, d['topic'], (0.5, 0.4))
        if i < len(it) and it[i]:
            shp(s, 'rect', x, y + h - 0.84, w * 0.86, 0.84, O())        # สูงพอสองบรรทัด ยาวกว่านั้นตัวจัดหน้าจะวัดว่าล้นแล้วเลือกหน้าอื่น
            txt(s, x + 0.18, y + h - 0.84, w * 0.86 - 0.32, 0.84, it[i], 12.5, K, 'md', an='m', sp=1.1)


@reg
def co_issues(prs, d):
    s = _page(prs)
    _h(s, M, 0.80, d['t'], 9.0, 30)
    it = d['items'][:3]
    rh = min(1.45, 4.7 / max(len(it), 1))
    cw = (W - M * 2 - 0.40) / 2
    for i, (prob, fix) in enumerate(it):
        y = 2.10 + i * rh
        shp(s, 'snip1', M, y, cw, rh - 0.20, CARD, adj=0.12)
        icon(s, 'triangle-alert', M + 0.42, y + (rh - 0.20) / 2, 0.34, K)
        txt(s, M + 0.80, y, cw - 1.40, rh - 0.20, prob, 13.5, K, 'md', an='m')
        _arrow(s, M + cw - 0.30, y + (rh - 0.20) / 2, O(), 0.30)
        x2 = M + cw + 0.40
        shp(s, 'round', x2, y, cw, rh - 0.20, WH, adj=0.10)
        icon(s, 'circle-check', x2 + 0.42, y + (rh - 0.20) / 2, 0.34, K)
        txt(s, x2 + 0.80, y, cw - 1.00, rh - 0.20, fix, 13.5, K, 'rg', an='m')


@reg
def co_suggest(prs, d):
    s = page(prs, BG)
    shp(s, 'rect', 0, 0, 4.60, H, K)
    txt(s, M, 0.95, 3.6, 2.4, d['t'], 32, WH, 'md', sp=1.1)
    _p(s, M, 3.40, 3.5, d.get('s', ''), 13, SOFT, h=2.0)
    _arrow(s, M + 0.15, H - 0.75, O(), 0.34)
    x, w = 5.40, W - M - 5.40
    y = 0.95
    for h_, lst in d['items'][:2]:
        txt(s, x, y, w, 0.44, h_, 17, K, 'md')
        y += 0.62
        for t in lst[:4]:
            shp(s, 'rect', x, y + 0.13, 0.13, 0.13, O())
            txt(s, x + 0.34, y, w - 0.34, 0.56, t, 13.5, K, 'rg')
            y += 0.62
        y += 0.36


# ══ หน้าคั่น / ปิด ════════════════════════════════════════════════════════

@reg
def co_div_dark(prs, d):
    s = page(prs, K)
    shp(s, 'rect', M, 2.55, 0.09, 0.80, O())
    txt(s, M + 0.34, 2.40, 8.6, 2.0, d['t'], 44, WH, 'md', sp=1.08)
    _p(s, M + 0.34, 4.55, 7.6, d.get('s', ''), 15, SOFT, h=1.4)
    _photo(s, d.get('pi', 14), 9.30, 0, W - 9.30, H, d['topic'], (0.5, 0.4))
    _arrow(s, M + 0.15, H - 0.75, O(), 0.34)


@reg
def co_div_orange(prs, d):
    s = page(prs, BG)
    _photo(s, d.get('pi', 15), 0, 0, W, 3.70, d['topic'], (0.5, 0.35))
    _snip(s, M, 2.90, 8.20, 3.85, O(), 0.08)
    txt(s, M + 0.45, 3.25, 7.3, 1.9, d['t'], 40, K, 'md', sp=1.08)
    _p(s, M + 0.45, 5.25, 7.0, d.get('s', ''), 14.5, K, h=1.2)
    shp(s, 'oval', W - M - 0.70, H - 1.05, 0.52, 0.52, K)
    _arrow(s, W - M - 0.44, H - 0.79, WH, 0.26)


@reg
def co_close(prs, d):
    s = page(prs, BG)
    _photo(s, d.get('pi', 16), M, 0.80, 7.30, 4.30, d['topic'], (0.5, 0.35))
    _snip(s, 8.20, 0.80, W - M - 8.20, 4.30, O(), 0.10)
    _p(s, 8.55, 1.15, W - M - 8.90, d.get('s', ''), 14, K, h=3.4)
    shp(s, 'rect', M, 5.55, 0.07, 1.00, O())
    txt(s, M + 0.24, 5.45, 9.5, 1.30, d['t'], 30, K, 'md', sp=1.08)
    _arrow(s, W - M - 0.20, H - 0.70, K, 0.34)
