"""20 เลย์เอาต์ชุด Pitch Deck EdTech — ลอกโครงจากเทมเพลตดำ+มิ้นต์ที่ไอซ์ส่งมา

พื้นดำ การ์ดเทาเข้มมุมมน ตัวเน้นเป็นมิ้นต์ หัวเรื่องตัวใหญ่สีขาว
ตัวหนังสือบนมิ้นต์ใช้สีดำเสมอ (ขาวบนมิ้นต์คอนทราสต์ 1.26 อ่านไม่ออกเลย)
แถบหัวทุกหน้า: สี่เหลี่ยมขาว + ชื่อบริษัท ซ้าย / ปี กลาง / ชื่อชุด ขวา
"""
from eng import *
import eng
from lay import L, reg

M = 0.70
R = 0.075


def _duo():
    if P.get('dark'):
        return f"duo:{mix(P['bg'], P['acc'], 0.20)}:{mix(P['acc'], 'FFFFFF', 0.46)}"
    return f"duo:{mix(P['ink'], P['acc'], 0.40)}:{mix(P['bg'], P['acc'], 0.12)}"


def _bar(s, d):
    shp(s, 'round', M, 0.30, 0.26, 0.26, 'FFFFFF', adj=0.22)
    txt(s, M + 0.40, 0.30, 3.2, 0.26, d.get('brand', 'บริษัทของคุณ'), 9.5, P['ink'], 'rg', an='m')
    txt(s, W / 2 - 1.0, 0.30, 2.0, 0.26, d.get('yr', '2570'), 9.5, P['ink'], 'rg', 'c', 'm')
    txt(s, W - M - 4.0, 0.30, 4.0, 0.26, d.get('kind', 'เอกสารนำเสนอระดมทุน'), 9.5, P['ink'], 'rg', 'r', 'm')


def _card(s, x, y, w, h, hot=False, adj=R):
    return shp(s, 'round', x, y, w, h, P['acc'] if hot else P['panel'], adj=adj)


def _ink(hot):
    """บนมิ้นต์ต้องเป็นสีดำ บนการ์ดเทาเป็นขาว"""
    return P['bg'] if hot else P['ink']


def _h(s, x, y, t, sz=54, w=8.0, c=None):
    txt(s, x, y, w, 2.4, t, sz, c or P['ink'], 'md', sp=1.10)


def _p(s, x, y, w, t, sz=13, hot=False, c=None):
    col = c or (mix(P['acc'], P['bg'], 0.62) if hot else mix(P['bg'], P['ink'], 0.56))
    txt(s, x, y, w, 1.5, t, sz, col, 'rg', sp=1.46)


def _pill(s, x, y, t, hot=False, sz=13):
    if not t: return 0
    w = len(t) * 0.070 + 0.46
    shp(s, 'round', x, y, w, 0.34, P['acc'] if hot else mix(P['bg'], P['ink'], 0.14), adj=0.5)
    txt(s, x, y, w, 0.34, t, sz, _ink(hot), 'md', 'c', 'm')
    return w


def _n(s, d):
    if d.get('n'):
        txt(s, W - M - 0.8, H - 0.46, 0.8, 0.24, f"{int(d['n']):02d}", 8.5, mix(P['bg'], P['ink'], 0.40), 'rg', 'r')


def _stripes(s, x, y, w, h, n=16):
    """แถบแนวตั้งถี่ ๆ ที่ต้นฉบับใช้เป็นกราฟิกตกแต่ง"""
    bw = w / (n * 1.6)
    for i in range(n):
        hh = h * (0.45 + 0.55 * ((i * 7) % 11) / 10)
        shp(s, 'rect', x + i * bw * 1.6, y + h - hh, bw, hh, mix(P['bg'], P['ink'], 0.14 + (i % 3) * 0.08))


# ══ เลย์เอาต์ตามรูปอ้างอิง ═════════════════════════════════════════════════

@reg
def ed_cover(prs, d):
    s = page(prs)
    shp(s, 'rect', 0, 0, 4.55, H, P['panel'])
    _stripes(s, 0.30, 0.90, 4.00, 3.00, 17)
    _bar(s, d)
    txt(s, 0.50, 4.90, 3.6, 0.72, d['big'], 38, P['ink'], 'md')
    _p(s, 0.50, 5.66, 3.5, d['biglab'], 13)
    _h(s, 5.10, 1.26, d['t'], 54, 7.4)
    ln(s, 5.10, 3.70, W - M, 3.70, mix(P['bg'], P['ink'], 0.26), 0.8)
    _p(s, 5.10, 3.92, 4.0, d['s'], 13)
    pic(s, ph(d['topic'], d.get('pi', 0)), 9.90, 4.10, 1.90, 1.46, geom='roundRect', adj=0.10, mode=_duo())
    _card(s, 8.20, 4.10, 1.46, 1.46)
    _p(s, 8.42, 4.96, 1.1, d.get('tag', ''), 7.5)
    _pill(s, 5.10, 5.20, d.get('yr', '2570'))
    _n(s, d)


@reg
def ed_summary(prs, d):
    s = page(prs)
    _bar(s, d)
    for i, (v, lab) in enumerate(d['items'][:2]):
        x = M + i * 2.90
        txt(s, x, 1.10, 2.6, 0.64, v, 40, P['ink'], 'md')
        _p(s, x, 1.82, 2.5, lab, 13)
    pic(s, ph(d['topic'], d.get('pi', 1)), 7.90, 1.00, W - M - 7.90, 1.86, geom='roundRect', adj=0.08, mode=_duo())
    _pill(s, M, 2.86, d.get('tag', ''), True)
    txt(s, M, 3.60, W - M * 2, 1.9, d['t'], 43, P['ink'], 'md', sp=1.22)
    x = M
    for t in d.get('tags', [])[:3]:
        x += _pill(s, x, 5.70, t) + 0.16
    _n(s, d)


@reg
def ed_problem(prs, d):
    s = page(prs)
    _bar(s, d)
    _card(s, M, 1.00, 3.10, 1.40)
    txt(s, M + 0.26, 1.22, 2.6, 0.34, d['items'][0][0], 15, P['ink'], 'md')
    _p(s, M + 0.26, 1.62, 2.6, d['items'][0][1], 12.5)
    _pill(s, 4.00, 1.00, d.get('tagA', ''))
    _pill(s, 5.50, 1.00, d.get('tagB', ''))
    _card(s, 4.00, 1.50, 2.44, 1.46, True)
    txt(s, 4.24, 1.72, 2.0, 0.54, d['big'], 33, P['bg'], 'md')
    _p(s, 4.24, 2.32, 2.0, d['biglab'], 12, hot=True)
    pic(s, ph(d['topic'], d.get('pi', 2)), 6.70, 1.00, 2.30, 3.20, geom='roundRect', adj=0.07, mode=_duo())
    for i, (h_, body) in enumerate(d['items'][1:3]):
        y = 1.00 + i * 1.70
        _card(s, 9.30, y, W - M - 9.30, 1.52)
        txt(s, 9.54, y + 0.22, 2.4, 0.56, h_, 15, P['ink'], 'md', sp=1.25)
        _p(s, 9.54, y + 0.92, 2.5, body, 12)
    _h(s, M, 4.40, d['t'], 51, 5.6)
    _n(s, d)


@reg
def ed_solution(prs, d):
    s = page(prs)
    _bar(s, d)
    _h(s, M, 1.20, d['t'], 54, 5.0)
    _card(s, 10.90, 1.00, 1.56, 2.30)
    shp(s, 'round', 11.22, 1.26, 0.92, 0.92, P['acc'], adj=0.26)
    _p(s, 11.12, 2.34, 1.2, d.get('tag', ''), 7.5)
    cw = (W - M * 2 - 0.48) / 4
    for i, (h_, body) in enumerate(d['items'][:4]):
        x = M + i * (cw + 0.16)
        hot = i == 2
        _card(s, x, 3.70, cw, 1.92, hot)
        txt(s, x + 0.26, 3.92, cw - 0.52, 0.56, h_, 15, _ink(hot), 'md', sp=1.25)
        _p(s, x + 0.26, 4.62, cw - 0.52, body, 12.5, hot)
    _n(s, d)


@reg
def ed_pain(prs, d):
    s = page(prs)
    _bar(s, d)
    _h(s, M, 1.10, d['t'], 48, 4.6)
    for i, t in enumerate(d['items'][:3]):
        y = 3.26 + i * 0.72
        shp(s, 'oval', M, y, 0.34, 0.34, None, line=mix(P['bg'], P['ink'], 0.36), lw=0.9)
        ln(s, M + 0.10, y + 0.17, M + 0.24, y + 0.17, P['ink'], 0.9)
        ln(s, M + 0.18, y + 0.10, M + 0.24, y + 0.17, P['ink'], 0.9)
        ln(s, M + 0.18, y + 0.24, M + 0.24, y + 0.17, P['ink'], 0.9)
        _p(s, M + 0.56, y + 0.02, 4.4, t, 13)
    _card(s, 5.90, 3.10, 2.90, 1.90, True)
    txt(s, 6.16, 3.36, 2.4, 0.66, d['big'], 38, P['bg'], 'md')
    _p(s, 6.16, 4.08, 2.4, d['biglab'], 12.5, hot=True)
    pic(s, ph(d['topic'], d.get('pi', 3)), 9.10, 1.00, 1.80, 2.40, geom='roundRect', adj=0.08, mode=_duo())
    _stripes(s, 11.10, 1.00, 1.50, 4.00, 8)
    _n(s, d)


@reg
def ed_opportunity(prs, d):
    s = page(prs)
    _bar(s, d)
    _h(s, M, 1.00, d['t'], 54, 10.0)
    cw = (W - M * 2 - 0.48) / 4
    for i, (h_, body, tag) in enumerate(d['items'][:4]):
        x = M + i * (cw + 0.16)
        hot = i == 0
        _card(s, x, 3.30, cw, 2.10, hot)
        if hot:
            shp(s, 'round', x + 0.24, 3.52, 0.80, 0.70, mix(P['acc'], 'FFFFFF', 0.45), adj=0.20)
            _pill(s, x + 0.24, 4.44, tag)
        else:
            txt(s, x + 0.26, 3.54, cw - 0.52, 0.56, h_, 15, P['ink'], 'md', sp=1.25)
            _p(s, x + 0.26, 4.24, cw - 0.52, body, 12.5)
    _n(s, d)


@reg
def ed_target(prs, d):
    s = page(prs)
    _bar(s, d)
    _h(s, M, 1.10, d['t'], 44, 4.2)
    gx = 5.10; cw = (W - M - gx) / 3
    for i, (num, h_) in enumerate(d['items'][:3]):
        x = gx + i * cw
        hot = i == 1
        if hot: _card(s, x, 1.00, cw - 0.14, 4.40, True)
        else: _stripes(s, x, 1.00, cw - 0.14, 4.40, 6)
        txt(s, x + 0.26, 3.10, cw - 0.52, 0.44, num, 17, _ink(hot), 'md')
        txt(s, x + 0.26, 3.70, cw - 0.52, 0.80, h_, 14.5, _ink(hot), 'md', sp=1.25)
    _n(s, d)


@reg
def ed_features(prs, d):
    s = page(prs)
    _bar(s, d)
    _h(s, M, 1.00, d['t'], 51, 6.4)
    spec = [(M, 3.30, 2.30, 1.70, True), (2.72, 2.80, 2.30, 1.70, False),
            (5.14, 2.30, 2.30, 1.70, False)]
    for (h_, body), (x, y, w, h, hot) in zip(d['items'][:3], spec):
        _card(s, x, y, w, h, hot)
        txt(s, x + 0.24, y + 0.22, w - 0.48, 0.56, h_, 14.5, _ink(hot), 'md', sp=1.25)
        _p(s, x + 0.24, y + 0.90, w - 0.48, body, 12, hot)
    _card(s, 7.86, 1.00, 2.40, 2.10, True)
    pic(s, ph(d['topic'], d.get('pi', 4)), 8.10, 1.22, 1.92, 1.10, geom='roundRect', adj=0.10, mode=_duo())
    txt(s, 8.10, 2.42, 2.0, 0.40, d['big'], 17, P['bg'], 'md')
    _p(s, 8.10, 2.78, 2.0, d['biglab'], 11, hot=True)
    _n(s, d)


@reg
def ed_value(prs, d):
    s = page(prs)
    _bar(s, d)
    for i, t in enumerate(d['items'][:4]):
        y = 1.00 + i * 0.72
        hot = i == 2
        w = 5.10 if i in (0, 3) else 6.40
        x = M + (0.60 if i in (0, 3) else 0)
        shp(s, 'round', x, y, w, 0.56, P['acc'] if hot else mix(P['bg'], P['ink'], 0.12), adj=0.5)
        txt(s, x, y, w, 0.56, t, 14.5, _ink(hot), 'md', 'c', 'm')
    _h(s, M, 4.10, d['t'], 54, 6.0)
    _card(s, 8.90, 4.00, 2.20, 1.56, True)
    _p(s, 9.14, 4.26, 1.8, d.get('note', ''), 12, hot=True)
    _n(s, d)


@reg
def ed_matrix(prs, d):
    s = page(prs)
    _bar(s, d)
    _h(s, M, 1.00, d['t'], 51, 9.0)
    tw = W - M * 2; cw0 = tw * 0.31; cw = (tw - cw0) / 3
    y0 = 2.60
    shp(s, 'rect', M, y0, tw, 0.48, P['acc'])
    txt(s, M + 0.22, y0, cw0 - 0.44, 0.48, d['head'][0], 13, P['bg'], 'md', an='m')
    for j, hd in enumerate(d['head'][1:]):
        txt(s, M + cw0 + j * cw, y0, cw, 0.48, hd, 13, P['bg'], 'md', 'c', 'm')
    for i, (name, dots) in enumerate(d['rows'][:3]):
        y = y0 + 0.48 + i * 0.74
        if i == 0: shp(s, 'rect', M, y, tw, 0.74, P['panel'])
        txt(s, M + 0.22, y, cw0 - 0.44, 0.74, name, 13.5, P['acc'] if i == 0 else P['ink'],
            'md' if i == 0 else 'rg', an='m')
        for j, k in enumerate(dots[:3]):
            cx = M + cw0 + j * cw + cw / 2
            for q in range(3):
                dx = cx - 0.34 + q * 0.34
                shp(s, 'oval', dx - 0.09, y + 0.28, 0.18, 0.18,
                    'FFFFFF' if q < k else None, line=None if q < k else mix(P['bg'], P['ink'], 0.34), lw=0.9)
    _n(s, d)


# ══ อีก 10 เลย์เอาต์ ═══════════════════════════════════════════════════════

@reg
def ed_bizmodel(prs, d):
    s = page(prs)
    _bar(s, d)
    _h(s, M, 1.10, d['t'], 42, 4.0)
    pic(s, ph(d['topic'], d.get('pi', 5)), M, 3.70, 3.40, 1.80, geom='roundRect', adj=0.07, mode=_duo())
    for i, (name, price, body) in enumerate(d['items'][:3]):
        x = 4.60 + (i % 2) * 4.10
        y = 1.00 + (i // 2) * 2.40
        txt(s, x, y, 3.8, 0.32, name, 15, P['ink'], 'md')
        txt(s, x, y + 0.40, 3.8, 0.40, price, 16.5, P['acc'], 'md')
        _p(s, x, y + 0.88, 3.8, body, 12.5)
    x = 4.60
    for t in d.get('tags', [])[:2]:
        x += _pill(s, x, 5.10, t) + 0.16
    _n(s, d)


@reg
def ed_gtm(prs, d):
    s = page(prs)
    _bar(s, d)
    _h(s, M, 1.00, d['t'], 51, 8.0)
    cw = (W - M * 2 - 0.48) / 4
    for i, (h_, body) in enumerate(d['items'][:4]):
        x = M + i * (cw + 0.16)
        y = 3.10 + (i % 2) * 0.26
        _card(s, x, y, cw, 1.96, i == 0)
        txt(s, x + 0.26, y + 0.22, cw - 0.52, 0.56, h_, 14.5, _ink(i == 0), 'md', sp=1.25)
        _p(s, x + 0.26, y + 0.92, cw - 0.52, body, 12.5, i == 0)
    _n(s, d)


@reg
def ed_traction(prs, d):
    s = page(prs)
    _bar(s, d)
    _h(s, M, 1.00, d['t'], 51, 5.0)
    _p(s, M, 2.70, 3.6, d.get('note', ''), 13)
    gx = 4.90; cw = (W - M - gx) / 4
    for i, (v, lab) in enumerate(d['items'][:4]):
        x = gx + i * cw
        hot = i == 2
        _card(s, x, 1.00 + (0 if hot else 0.22), cw - 0.14, 4.30 - (0 if hot else 0.44), hot)
        _p(s, x + 0.22, 1.24, cw - 0.50, lab, 12, hot)
        txt(s, x + 0.22, 4.40, cw - 0.50, 0.56, v, 28, _ink(hot), 'md')
    _n(s, d)


@reg
def ed_growth(prs, d):
    s = page(prs)
    _bar(s, d)
    _h(s, M, 1.10, d['t'], 44, 4.2)
    _stripes(s, M, 3.60, 4.20, 1.90, 18)
    for i, (h_, v) in enumerate(d['items'][:2]):
        x = 5.10 + i * 3.90
        _card(s, x, 1.00, 3.70, 1.70)
        txt(s, x + 0.26, 1.22, 3.2, 0.30, h_, 13.5, P['ink'], 'md')
        txt(s, x + 0.26, 1.60, 3.2, 0.44, v, 16.5, P['acc'], 'md')
    _card(s, 5.10, 3.00, 7.50, 1.60, True)
    txt(s, 5.36, 3.22, 6.8, 0.30, d['big'][0], 13.5, P['bg'], 'md')
    txt(s, 5.36, 3.60, 6.8, 0.52, d['big'][1], 27, P['bg'], 'md')
    _n(s, d)


@reg
def ed_tam(prs, d):
    s = page(prs)
    _bar(s, d)
    spec = [(M, 1.00, 4.60, 4.40, P['acc']), (3.90, 1.90, 4.20, 3.50, 'FFFFFF'),
            (7.70, 2.70, 4.40, 2.70, P['panel'])]
    inks = [P['bg'], P['bg'], P['ink']]
    for (lab, v), (x, y, w, h, fill), ic in zip(d['items'][:3], spec, inks):
        shp(s, 'round', x, y, w, h, fill, adj=R)
        txt(s, x + 0.30, y + 0.26, w - 0.60, 0.40, lab, 15, ic, 'md')
        txt(s, x + 0.30, y + 0.80, w - 0.60, 0.70, v, 40, ic, 'md')
    _p(s, M, 5.62, 9.0, d.get('note', ''), 12.5)
    _n(s, d)


@reg
def ed_forecast(prs, d):
    s = page(prs)
    _bar(s, d)
    _h(s, M, 1.00, d['t'], 44, 4.2)
    _p(s, M, 3.10, 3.0, d.get('k', ''), 13, c=P['ink'])
    txt(s, M, 3.44, 3.4, 0.52, d['big'], 28, P['acc'], 'md')
    _p(s, M, 4.06, 3.6, d.get('note', ''), 12.5)
    gx = 5.40
    for i, (v, yr) in enumerate(d['items'][:4]):
        y = 1.00 + i * 1.12
        hot = i == 3
        w = 2.60 + i * 0.30
        _card(s, gx, y, w, 0.88, hot)
        txt(s, gx + 0.26, y, w - 0.52, 0.88, v, 17, _ink(hot), 'md', an='m')
        shp(s, 'oval', gx + w + 0.30, y + 0.38, 0.14, 0.14, mix(P['bg'], P['ink'], 0.40))
        txt(s, gx + w + 0.70, y, 1.4, 0.88, yr, 13.5, P['ink'], 'rg', an='m')
    _n(s, d)


@reg
def ed_unit(prs, d):
    s = page(prs)
    _bar(s, d)
    _h(s, M, 1.20, d['t'], 36, 3.4)
    pic(s, ph(d['topic'], d.get('pi', 6)), M, 3.20, 3.30, 2.20, geom='roundRect', adj=0.07, mode=_duo())
    cw = (W - M - 4.30 - 0.20) / 2
    for i, (lab, v) in enumerate(d['items'][:4]):
        x = 4.30 + (i % 2) * (cw + 0.20)
        y = 1.00 + (i // 2) * 2.30
        _card(s, x, y, cw, 2.06)
        _p(s, x + 0.26, y + 0.24, cw - 0.52, lab, 12.5)
        txt(s, x + 0.26, y + 1.06, cw - 0.52, 0.62, v, 34, P['ink'], 'md')
    _n(s, d)


@reg
def ed_team(prs, d):
    s = page(prs)
    _bar(s, d)
    shp(s, 'round', M, 1.00, 4.60, 4.40, P['acc'], adj=R)
    pic(s, ph(d.get('ptopic', 'office'), d.get('pi', 7)), M + 0.30, 1.30, 1.90, 2.00,
        geom='roundRect', adj=0.07, focus=(0.5, 0.34), mode=_duo())
    txt(s, 2.90, 1.36, 2.3, 0.30, d['items'][0][0], 14.5, P['bg'], 'md')
    _p(s, 2.90, 1.70, 2.3, d['items'][0][1], 12, hot=True)
    txt(s, M + 0.30, 4.10, 3.2, 0.76, d['t'], 40, P['bg'], 'md')
    shp(s, 'oval', 4.46, 4.26, 0.52, 0.52, P['bg'])
    ln(s, 4.62, 4.52, 4.82, 4.52, P['acc'], 1.2)
    ln(s, 4.74, 4.44, 4.82, 4.52, P['acc'], 1.2); ln(s, 4.74, 4.60, 4.82, 4.52, P['acc'], 1.2)
    for i, (name, role) in enumerate(d['items'][1:3]):
        y = 1.00 + i * 2.26
        pic(s, ph(d.get('ptopic', 'office'), d.get('pi', 7) + 1 + i), 5.90, y, 2.10, 2.14,
            geom='roundRect', adj=0.07, focus=(0.5, 0.34), mode=_duo())
        txt(s, 8.30, y + 0.22, 4.0, 0.30, name, 14.5, P['ink'], 'md')
        _p(s, 8.30, y + 0.58, 4.0, role, 12.5)
    _n(s, d)


@reg
def ed_ask(prs, d):
    s = page(prs)
    _bar(s, d)
    _p(s, M, 1.10, 3.0, d.get('k', ''), 13, c=P['ink'])
    txt(s, M, 1.50, 6.4, 1.5, d['big'], 54, P['ink'], 'md')
    _p(s, 6.40, 1.60, 3.0, d['biglab'], 13)
    pic(s, ph(d['topic'], d.get('pi', 9)), 9.40, 1.00, W - M - 9.40, 4.40, geom='roundRect', adj=0.06, mode=_duo())
    cw = (9.10 - M - 0.42) / 4
    for i, (v, lab) in enumerate(d['items'][:4]):
        x = M + i * (cw + 0.14)
        hot = i == 0
        _card(s, x, 3.60, cw, 1.44, hot)
        txt(s, x + 0.22, 3.80, cw - 0.44, 0.48, v, 18, _ink(hot), 'md')
        _p(s, x + 0.22, 4.34, cw - 0.44, lab, 11, hot)
    _n(s, d)


@reg
def ed_thanks(prs, d):
    s = page(prs)
    _bar(s, d)
    x = M
    for lab, v in d['items'][:3]:
        _card(s, x, 1.00, 2.10, 1.26)
        _p(s, x + 0.24, 1.18, 1.7, lab, 12.5)
        txt(s, x + 0.24, 1.52, 1.8, 0.30, v, 13, P['ink'], 'rg')
        x += 2.26
    _card(s, 9.60, 1.00, 1.30, 1.90)
    pic(s, ph(d['topic'], d.get('pi', 0)), 11.00, 1.00, 1.60, 1.90, geom='roundRect', adj=0.10, mode=_duo())
    txt(s, M, 3.40, 9.4, 1.9, d['t'], 54, P['ink'], 'md', sp=1.10)
    _n(s, d)
