# ใบ 025 โน้ตผู้บรรยาย: d['_note'] ของแต่ละหน้า (Slide Studio เก็บไว้) → ช่อง Notes ของ PowerPoint จริง (notesSlide)
# doc2slide.render เรียก write(prs, seq) ก่อน prs.save ตอนทำไฟล์จริงเท่านั้น (ไม่ใช่ภาพบนจอ) / หน้าไม่มีโน้ตไม่สร้าง notesSlide ว่าง
# ponytail: ข้อความล้วน ขึ้นบรรทัด = ย่อหน้าใหม่ (python-pptx แยกที่ \n เอง) ไม่มีตัวหนา/ลิสต์ตามสเปกใบ 025

def write(prs, seq):
    for slide, (_, d) in zip(prs.slides, seq):
        t = str(d.get('_note') or '').replace('\r\n', '\n').strip('\n')
        if t.strip(): slide.notes_slide.notes_text_frame.text = t

def read(prs):
    """โน้ตเดิมของไฟล์ (หน้าที่ไม่มี = '') ไว้ให้ตัวเปิดไฟล์ pptx ใส่กลับเป็น d['_note'] (ยังไม่ได้ต่อสาย)"""
    return [s.notes_slide.notes_text_frame.text if s.has_notes_slide else '' for s in prs.slides]

if __name__ == '__main__':                                     # python3 notes_out.py = ทดสอบตัวเอง
    import io
    from pptx import Presentation
    prs = Presentation(); [prs.slides.add_slide(prs.slide_layouts[6]) for _ in range(3)]
    write(prs, [('a', {'_note': 'บรรทัดแรก\nบรรทัดสอง'}), ('b', {}), ('c', {'_note': '  '})])
    b = io.BytesIO(); prs.save(b); p2 = Presentation(io.BytesIO(b.getvalue()))
    assert read(p2) == ['บรรทัดแรก\nบรรทัดสอง', '', ''], read(p2)
    assert [s.has_notes_slide for s in p2.slides] == [True, False, False]
    print('ok')
