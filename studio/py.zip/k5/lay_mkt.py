"""20 เลย์เอาต์ชุด Marketing Strategy — ลอกโครงจากเทมเพลตน้ำเงิน-ม่วงที่ไอซ์ส่งมา

พื้นขาวนวลสลับกับแผงน้ำเงินทึบ รูปสามเหลี่ยมไล่เฉดน้ำเงินไปม่วงเป็นกราฟิกประจำชุด
ดาวสี่แฉกเป็นลายเซ็นของเทมเพลต ตัวหนังสือบนม่วงได้แค่ 4.0 จึงใช้เฉพาะตัวใหญ่
"""
from eng import *
import eng
from lay import L, reg

M = 0.72


def _duo():
    if P.get('dark'):
        return f"duo:{mix(P['bg'], P['acc'], 0.28)}:{mix(P['acc'], 'FFFFFF', 0.52)}"
    return f"duo:{mix(P['ink'], P['acc'], 0.42)}:{mix(P['bg'], P['acc'], 0.12)}"


def _star(s, cx, cy, r=0.22, c=None):
    """ดาวสี่แฉกแบบลายเซ็นของเทมเพลต ทำจากสี่เหลี่ยมข้าวหลามตัดสองอันไขว้กัน"""
    c = c or 'FFFFFF'
    shp(s, 'diamond', cx - r * 0.30, cy - r, r * 0.60, r * 2, c)
    shp(s, 'diamond', cx - r, cy - r * 0.30, r * 2, r * 0.60, c)


def _tri(s, x, y, w, h, rot=0):
    """สามเหลี่ยมไล่เฉดน้ำเงินไปม่วง กราฟิกประจำชุด"""
    return gradband(s, x, y, w, h, 300, c1=P['g1'], c2=P['g2'], kind='tri', adj=None)


def _gfx(s, x, y, w, h):
    """บล็อกกราฟิก: สี่เหลี่ยมเข้มกับสามเหลี่ยมไล่เฉดซ้อนอยู่ข้างใน"""
    shp(s, 'rect', x, y, w, h, mix(P['ink'], P['acc'], 0.30))
    _tri(s, x + w * 0.12, y + h * 0.14, w * 0.78, h * 0.72, 0)


def _chrome(s, d, light=False):
    c = 'FFFFFF' if light else P['mute']
    txt(s, M, 0.30, 3.4, 0.26, d.get('brand', 'เทมเพลตนำเสนอ'), 11, c, 'rg')
    txt(s, 4.60, 0.30, 3.4, 0.26, d.get('kind', 'แผนการตลาด'), 11, c, 'rg')
    if d.get('n'):
        txt(s, W - M - 1.6, 0.30, 1.6, 0.26, f"หน้า {int(d['n'])}", 11, c, 'rg', 'r')


def _h(s, x, y, t, sz=43, w=6.0, c=None):
    txt(s, x, y, w, 2.2, t, sz, c or P['ink'], 'md', sp=1.14)


def _p(s, x, y, w, t, sz=13, c=None):
    txt(s, x, y, w, 1.5, t, sz, c or mix(P['bg'], P['ink'], 0.72), 'rg', sp=1.44)


def _lab(s, x, y, t, light=False, sz=13):
    if t: txt(s, x, y, 4.4, 0.28, t, sz, 'D6DAFF' if light else P['mute'], 'md')


# ══ เลย์เอาต์ตามรูปอ้างอิง ═════════════════════════════════════════════════

@reg
def mk_cover(prs, d):
    s = page(prs, P['acc'])
    shp(s, 'rect', M, 0.78, W - M * 2, 3.30, 'FFFFFF')
    _chrome(s, d, True)
    _star(s, 1.30, 1.44, 0.24, P['acc'])
    _h(s, 1.70, 1.18, d['t'], 51, 6.4)
    _gfx(s, 8.60, 1.10, 3.30, 2.40)
    _p(s, 1.70, 3.10, 5.6, d['s'], 13)
    for i, (v, lab) in enumerate(d['items'][:2]):
        x = M + 0.60 + i * 5.40
        txt(s, x, 4.52, 3.0, 0.56, v, 34, 'FFFFFF', 'md')
        _p(s, x, 5.16, 4.2, lab, 12, 'D6DAFF')
    _star(s, 11.90, 4.80, 0.26)


@reg
def mk_person(prs, d):
    s = page(prs, P['bg'])
    _chrome(s, d)
    _lab(s, M, 1.00, d.get('k', ''))
    _h(s, M, 1.34, d['t'], 38, 3.6)
    pic(s, ph(d.get('ptopic', 'office'), d.get('pi', 0)), 4.60, 1.00, 1.90, 2.10,
        geom='roundRect', adj=0.06, focus=(0.5, 0.32), mode=_duo())
    txt(s, 7.00, 1.04, 3.4, 0.56, d['big'], 33, P['ink'], 'md')
    _p(s, 7.00, 1.72, 4.4, d['note'], 12)
    shp(s, 'rect', M, 3.60, W - M * 2, 2.00, P['acc'])
    txt(s, M + 0.40, 3.84, 3.0, 0.32, d['k2'], 13, 'FFFFFF', 'md')
    _p(s, M + 0.40, 4.24, 4.2, d['note2'], 12, 'D6DAFF')
    _p(s, 8.60, 4.24, 3.4, d.get('note3', ''), 12, 'D6DAFF')
    _star(s, 11.90, 3.96, 0.22)


@reg
def mk_framework(prs, d):
    s = page(prs, P['bg'])
    _chrome(s, d)
    _h(s, M, 1.10, d['t'], 48, 5.4)
    _gfx(s, 8.90, 0.96, 3.00, 2.00)
    shp(s, 'rect', M, 3.20, W - M * 2, 2.50, P['acc'])
    _star(s, 1.20, 3.70, 0.22)
    txt(s, M + 0.40, 4.00, 4.0, 0.62, d['big'], 37, 'FFFFFF', 'md')
    _p(s, M + 0.40, 4.74, 4.0, d['biglab'], 12, 'D6DAFF')
    for i, (h_, body) in enumerate(d['items'][:2]):
        x = 5.60 + i * 3.40
        txt(s, x, 3.56, 3.1, 0.32, h_, 13, 'FFFFFF', 'md')
        _p(s, x, 3.96, 3.1, body, 12, 'D6DAFF')


@reg
def mk_growth(prs, d):
    s = page(prs, P['acc'])
    _chrome(s, d, True)
    _h(s, M, 1.10, d['t'], 42, 4.0, 'FFFFFF')
    _gfx(s, M, 3.30, 3.00, 2.10)
    for i, (h_, body) in enumerate(d['items'][:2]):
        x = 4.40 + i * 4.20
        txt(s, x, 1.00, 3.9, 0.56, h_, 14, 'FFFFFF', 'md', sp=1.25)
        ln(s, x, 1.80, x + 3.9, 1.80, mix(P['acc'], 'FFFFFF', 0.36), 0.8)
        _lab(s, x, 1.96, d.get('k', ''), True, 12)
        _p(s, x, 2.32, 3.9, body, 12, 'D6DAFF')
    for i, (v, lab) in enumerate(d['stats'][:2]):
        x = 4.40 + i * 4.20
        txt(s, x, 4.30, 1.6, 0.62, v, 37, 'FFFFFF', 'md')
        _p(s, x + 1.70, 4.42, 2.2, lab, 12, 'D6DAFF')


@reg
def mk_analysis(prs, d):
    s = page(prs, P['bg'])
    shp(s, 'rect', 0, 0, W, 2.90, P['acc'])
    _chrome(s, d, True)
    _star(s, 1.20, 1.10, 0.22)
    _lab(s, 1.70, 1.00, d.get('k', ''), True)
    txt(s, 1.70, 1.36, 4.6, 0.80, d['k2'], 14, 'FFFFFF', 'md', sp=1.25)
    for i, t in enumerate(d['items'][:3]):
        _p(s, 1.70, 2.14 + i * 0.26, 4.6, '· ' + t, 11, 'D6DAFF')
    _gfx(s, 7.40, 0.70, 3.40, 2.00)
    txt(s, M, 3.60, 2.0, 0.62, d['big'], 37, P['acc'], 'md')
    _p(s, M, 4.30, 3.4, d['biglab'], 12)
    _h(s, 6.20, 3.40, d['t'], 48, 6.0)


@reg
def mk_persona(prs, d):
    s = page(prs, P['acc'])
    _chrome(s, d, True)
    _h(s, M, 1.10, d['t'], 51, 5.0, 'FFFFFF')
    _star(s, 5.60, 1.26, 0.24)
    _gfx(s, 6.60, 0.90, 3.00, 2.00)
    txt(s, M, 3.60, 1.8, 0.62, d['big'], 37, 'FFFFFF', 'md')
    _gfx(s, 2.60, 3.30, 1.70, 1.30)
    txt(s, 4.70, 3.40, 3.2, 0.60, d['k2'], 13, 'FFFFFF', 'md', sp=1.25)
    for i, t in enumerate(d['items'][:3]):
        _p(s, 8.20, 3.40 + i * 0.50, 4.2, '· ' + t, 11, 'D6DAFF')


@reg
def mk_performance(prs, d):
    s = page(prs, P['bg'])
    _chrome(s, d)
    _h(s, M, 1.10, d['t'], 51, 6.0)
    pic(s, ph(d.get('ptopic', 'retail'), d.get('pi', 6)), 7.20, 0.90, 2.90, 1.90, geom='roundRect', adj=0.06, mode=_duo())
    shp(s, 'rect', 10.40, 0, W - 10.40, H, P['acc'])
    txt(s, 10.70, 1.40, 1.8, 0.56, d['big'], 33, 'FFFFFF', 'md')
    for i, t in enumerate(d['items'][:3]):
        _p(s, 10.70, 2.20 + i * 0.56, 1.9, '· ' + t, 11, 'D6DAFF')
    _lab(s, M, 3.30, d.get('k', ''))
    _p(s, M, 3.66, 5.4, d['note'], 12)


@reg
def mk_summary(prs, d):
    s = page(prs, P['bg'])
    _chrome(s, d)
    _gfx(s, M, 1.00, 2.30, 1.90)
    _star(s, 3.50, 1.20, 0.24, P['acc'])
    _h(s, M, 3.50, d['t'], 45, 4.4)
    shp(s, 'rect', 5.10, 0.70, W - M - 5.10, H - 1.40, P['panel'])
    for i, (h_, body) in enumerate(d['items'][:3]):
        y = 1.10 + i * 1.46
        txt(s, 5.50, y, 6.4, 0.32, h_, 13, P['acc'], 'md')
        _p(s, 5.50, y + 0.40, 6.4, body, 12)
        if i < 2: ln(s, 5.50, y + 1.22, W - M - 0.40, y + 1.22, mix(P['panel'], P['ink'], 0.18), 0.7)


@reg
def mk_toc(prs, d):
    s = page(prs, P['bg'])
    _chrome(s, d)
    _h(s, M, 1.20, d['t'], 51, 6.0)
    pic(s, ph(d.get('ptopic', 'office'), d.get('pi', 2)), 8.60, 0.90, 3.30, 2.10, mode=_duo())
    shp(s, 'rect', M, 3.40, W - M * 2, 2.30, P['acc'])
    cw = (W - M * 2 - 0.80) / 2
    for i, t in enumerate(d['items'][:6]):
        x = M + 0.40 + (i % 2) * (cw + 0.10)
        y = 3.70 + (i // 2) * 0.64
        txt(s, x, y, cw - 0.20, 0.34, t, 12.5, 'FFFFFF', 'rg', an='m')
        ln(s, x, y + 0.42, x + cw - 0.20, y + 0.42, mix(P['acc'], 'FFFFFF', 0.30), 0.6)


@reg
def mk_strategy(prs, d):
    s = page(prs, P['acc'])
    _chrome(s, d, True)
    shp(s, 'rect', 9.70, 0, W - 9.70, H, P['bg'])
    _h(s, M, 1.30, d['t'], 54, 7.6, 'FFFFFF')
    _star(s, 1.10, 3.40, 0.26)
    for i, (h_, body) in enumerate(d['items'][:2]):
        x = M + i * 4.00
        txt(s, x, 3.80, 3.6, 0.32, h_, 13, 'FFFFFF', 'md')
        _p(s, x, 4.20, 3.6, body, 12, 'D6DAFF')
    _p(s, 10.00, 1.30, 2.4, d['note'], 12)
    _star(s, 11.10, 4.40, 0.40, P['acc'])


# ══ อีก 10 เลย์เอาต์ ═══════════════════════════════════════════════════════

@reg
def mk_break(prs, d):
    s = page(prs, P['bg'])
    _chrome(s, d)
    shp(s, 'rect', 4.30, 0.70, W - M - 4.30, H - 1.40, P['acc'])
    pic(s, ph(d.get('ptopic', 'retail'), d.get('pi', 5)), M, 1.40, 3.30, 2.60, geom='roundRect', adj=0.05, mode=_duo())
    _star(s, 5.00, 1.30, 0.26)
    _h(s, 4.80, 1.70, d['t'], 51, 6.0, 'FFFFFF')
    _p(s, 4.80, 4.00, 5.4, d.get('note', ''), 13, 'D6DAFF')


@reg
def mk_content(prs, d):
    s = page(prs, P['bg'])
    _chrome(s, d)
    _h(s, M, 1.10, d['t'], 42, 4.0)
    pic(s, ph(d.get('ptopic', 'retail'), d.get('pi', 3)), 4.60, 1.00, 2.60, 3.10, geom='roundRect', adj=0.05, mode=_duo())
    _lab(s, 7.60, 1.00, d.get('k', ''))
    for i, (h_, body) in enumerate(d['items'][:4]):
        y = 1.40 + i * 1.02
        txt(s, 7.60, y, 4.8, 0.32, h_, 13, P['acc'], 'md')
        _p(s, 7.60, y + 0.38, 4.8, body, 11.5)
    _p(s, M, 3.70, 3.4, d.get('note', ''), 12)


@reg
def mk_table(prs, d):
    s = page(prs, P['bg'])
    _chrome(s, d)
    for i, (v, lab) in enumerate(d['stats'][:2]):
        x = M + i * 2.60
        txt(s, x, 1.00, 2.3, 0.52, v, 30, P['acc'], 'md')
        _p(s, x, 1.62, 2.4, lab, 11.5)
    _star(s, 6.20, 1.20, 0.22, P['acc'])
    _h(s, 7.00, 0.96, d['t'], 43, 5.4)
    tw = W - M * 2; cols = d['colw']; y0 = 2.70
    shp(s, 'rect', M, y0, tw, 2.90, P['acc'])
    cx = M
    for j, (hd, fr) in enumerate(zip(d['head'], cols)):
        txt(s, cx + 0.22, y0 + 0.14, tw * fr - 0.44, 0.40, hd, 12, 'FFFFFF', 'md',
            'l' if j == 0 else 'c', 'm'); cx += tw * fr
    for i, row in enumerate(d['rows'][:3]):
        y = y0 + 0.70 + i * 0.68
        ln(s, M + 0.22, y + 0.56, W - M - 0.22, y + 0.56, mix(P['acc'], 'FFFFFF', 0.26), 0.6)
        cx = M
        for j, (cell, fr) in enumerate(zip(row, cols)):
            if cell == '1':
                k = cx + tw * fr / 2
                ln(s, k - 0.10, y + 0.26, k - 0.02, y + 0.34, 'FFFFFF', 1.4)
                ln(s, k - 0.02, y + 0.34, k + 0.12, y + 0.16, 'FFFFFF', 1.4)
            else:
                txt(s, cx + 0.22, y, tw * fr - 0.44, 0.52, cell, 12, 'FFFFFF', 'rg',
                    'l' if j == 0 else 'c', 'm')
            cx += tw * fr


@reg
def mk_swot(prs, d):
    s = page(prs, P['bg'])
    _chrome(s, d)
    cw = (W - M * 2 - 0.54) / 4
    for i, (h_, body) in enumerate(d['items'][:4]):
        x = M + i * (cw + 0.18)
        txt(s, x, 1.00, cw - 0.10, 0.60, h_, 13, P['acc'], 'md', sp=1.25)
        ln(s, x, 1.72, x + cw - 0.10, 1.72, mix(P['bg'], P['acc'], 0.30), 0.8)
        _p(s, x, 1.88, cw - 0.14, body, 11.5)
    _h(s, M, 3.80, d['t'], 48, 4.6)
    pic(s, ph(d.get('ptopic', 'retail'), d.get('pi', 4)), 5.80, 3.40, 2.20, 1.70, geom='roundRect', adj=0.07, mode=_duo())
    _p(s, 8.40, 3.80, 3.9, d.get('note', ''), 12)
    _star(s, 11.90, 3.60, 0.24, P['acc'])


@reg
def mk_tracking(prs, d):
    s = page(prs, P['acc'])
    _chrome(s, d, True)
    _h(s, M, 1.10, d['t'], 44, 4.2, 'FFFFFF')
    for i, (v, lab) in enumerate(d['stats'][:2]):
        x = M + i * 2.40
        txt(s, x, 3.30, 2.2, 0.60, v, 36, 'FFFFFF', 'md')
        _p(s, x, 4.00, 2.2, lab, 11.5, 'D6DAFF')
    gx, gy, gh = 5.40, 4.70, 1.90
    for grp in range(2):
        for i, v in enumerate(d['bars'][grp][:3]):
            x = gx + grp * 3.00 + i * 0.68
            h = gh * v / 100
            shp(s, 'rect', x, gy - h, 0.50, h, 'FFFFFF' if i == 1 else mix(P['acc'], 'FFFFFF', 0.45))
        _p(s, gx + grp * 3.00, gy + 0.14, 2.6, d['labs'][grp], 10.5, 'D6DAFF')
    _star(s, 11.50, 1.80, 0.40)
    _p(s, 10.40, 3.10, 2.2, d.get('note', ''), 11.5, 'D6DAFF')


@reg
def mk_photo_panel(prs, d):
    s = page(prs, P['bg'])
    _chrome(s, d)
    pic(s, ph(d.get('ptopic', 'office'), d.get('pi', 1)), 0, 0.70, 5.50, H - 1.40, mode=_duo())
    shp(s, 'rect', 5.80, 0.70, W - M - 5.80, H - 1.40, P['acc'])
    _h(s, 6.20, 1.10, d['t'], 43, 5.8, 'FFFFFF')
    for i, (h_, body) in enumerate(d['items'][:3]):
        y = 3.00 + i * 0.90
        txt(s, 6.20, y, 5.8, 0.30, h_, 12.5, 'FFFFFF', 'md')
        _p(s, 6.20, y + 0.34, 5.8, body, 11.5, 'D6DAFF')


@reg
def mk_steps(prs, d):
    s = page(prs, P['bg'])
    _chrome(s, d)
    _h(s, M, 1.10, d['t'], 44, 4.2)
    _p(s, M, 3.40, 4.0, d.get('note', ''), 12)
    x = 5.60
    n = len(d['items'][:4])
    ln(s, x + 0.22, 1.00, x + 0.22, 1.00 + (n - 1) * 1.16 + 0.44, mix(P['bg'], P['acc'], 0.26), 0.8)
    for i, (h_, body) in enumerate(d['items'][:4]):
        y = 1.00 + i * 1.16
        shp(s, 'oval', x, y, 0.44, 0.44, P['acc'] if i < 2 else P['panel'])
        txt(s, x, y, 0.44, 0.44, f'{i + 1}', 12, 'FFFFFF' if i < 2 else P['acc'], 'md', 'c', 'm')
        txt(s, x + 0.76, y - 0.02, 6.0, 0.34, h_, 13, P['ink'], 'md')
        _p(s, x + 0.76, y + 0.38, 5.9, body, 11.5)


@reg
def mk_kpi4(prs, d):
    s = page(prs, P['bg'])
    _chrome(s, d)
    _h(s, M, 1.00, d['t'], 45, 8.0)
    cw = (W - M * 2 - 0.54) / 4
    for i, (v, lab, body) in enumerate(d['items'][:4]):
        x = M + i * (cw + 0.18)
        hot = i == 0
        shp(s, 'rect', x, 2.80, cw, 2.60, P['acc'] if hot else P['panel'])
        txt(s, x + 0.26, 3.04, cw - 0.52, 0.62, v, 34, 'FFFFFF' if hot else P['acc'], 'md')
        txt(s, x + 0.26, 3.76, cw - 0.52, 0.32, lab, 12.5, 'FFFFFF' if hot else P['ink'], 'md')
        _p(s, x + 0.26, 4.16, cw - 0.52, body, 11.5, 'D6DAFF' if hot else None)


@reg
def mk_quote(prs, d):
    s = page(prs, P['acc'])
    _chrome(s, d, True)
    shp(s, 'rect', M, 0.78, 7.40, H - 1.56, 'FFFFFF')
    _star(s, 1.30, 1.40, 0.26, P['acc'])
    txt(s, 1.70, 1.60, 6.0, 2.2, d['t'], 28, P['ink'], 'md', sp=1.3)
    ln(s, 1.70, 4.20, 4.40, 4.20, mix(P['bg'], P['acc'], 0.30), 0.8)
    txt(s, 1.70, 4.36, 5.4, 0.32, d['who'], 13, P['acc'], 'md')
    _p(s, 1.70, 4.76, 5.4, d['role'], 11.5)
    _gfx(s, 8.60, 1.60, 3.30, 2.60)


@reg
def mk_close(prs, d):
    s = page(prs, P['acc'])
    _chrome(s, d, True)
    _star(s, 1.10, 1.50, 0.28)
    txt(s, M, 2.00, 8.4, 1.9, d['t'], 54, 'FFFFFF', 'md', sp=1.10)
    _p(s, M, 4.10, 6.2, d.get('note', ''), 13, 'D6DAFF')
    _star(s, 11.30, 2.00, 0.46)
    for i, (lab, v) in enumerate(d['items'][:3]):
        x = M + i * 3.90
        _p(s, x, 5.06, 3.6, lab, 11, 'B9C0F5')
        txt(s, x, 5.38, 3.6, 0.32, v, 12.5, 'FFFFFF', 'md')
