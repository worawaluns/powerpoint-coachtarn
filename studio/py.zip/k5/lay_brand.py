"""20 เลย์เอาต์ชุดคู่มือแบรนด์ แดง+ดำ+ขาว — ลอกโครงจากเทมเพลต Brand Guideline (Studio Shodwe)

รูปถ่ายเต็มหน้าย้อมโทนเทาเข้ม ทับม่านดำ หัวเรื่องตัวหนามากขนาดยักษ์
มุมบนซ้าย/ขวามีชื่อสตูดิโอสีแดงตัวเล็ก กลางบนมีดอกจันแดง แถบสีสามช่องแดง-ดำ-ขาว
หน้าขาวครึ่งหนึ่งคู่รูปครึ่งหนึ่ง หัวข้อแดงตัวใหญ่
แดง D0201E บนดำวัดได้ 3.51 ใช้ได้กับตัวหนังสือ >= 24pt เท่านั้น ตัวเล็กบนดำใช้แดงสว่าง F0453C (5.05)
"""
from eng import *
import eng
from lay import L, reg

txt = txt_big        # ขนาดขั้นต่ำตามชุด 366 ดู eng.roomy()
chart = chart_big

M = 0.55
K = '111111'
WH = 'FFFFFF'
SOFT = 'BEBEBE'
GREY = '5A5A5A'
RL = 'F0453C'          # แดงสว่างสำหรับตัวเล็กบนดำ


def R(): return P['acc']


def _duo(): return "duo:0D0D0D:E6E6E6"


def _photo(s, n, x, y, w, h, focus=(0.5, 0.35), topic='fashion'):
    return pic(s, ph(topic, n), x, y, w, h, focus=focus, mode=_duo())


def _full(s, n, a=0.45, focus=(0.5, 0.35), topic='fashion'):
    _photo(s, n, 0, 0, W, H, focus, topic)
    shp(s, 'rect', 0, 0, W, H, K, a=a)


def _mark(s, cx, cy, sz, c=None):
    c = c or R()
    for a in (0, 45, 90, 135):
        shp(s, 'round', cx - sz * 0.13, cy - sz / 2, sz * 0.26, sz, c, adj=0.5, rot=a)


def _corner(s, d, dark=True, mid=True):
    c = RL if dark else R()
    txt(s, M, 0.32, 3.0, 0.30, d.get('brand', 'สตูดิโอของคุณ'), 10, c, 'bd')
    txt(s, W - M - 3.0, 0.32, 3.0, 0.30, d.get('right', 'คู่มือแบรนด์'), 10, c, 'bd', 'r')
    if mid: _mark(s, W / 2, 0.48, 0.30, c)


def _h(s, x, y, t, sz=60, w=12.0, c=None, al='l'):
    txt(s, x, y, w, 3.0, t, sz, c or WH, 'bd', al, sp=0.92)


def _p(s, x, y, w, t, sz=11, c=None, al='l'):
    if t: txt(s, x, y, w, 2.0, t, sz, c or SOFT, 'rg', al, sp=1.36)


# ══ เลย์เอาต์ตามรูปอ้างอิง ═════════════════════════════════════════════════

@reg
def br_cover(prs, d):
    s = page(prs, K)
    _full(s, d.get('pi', 1), 0.40)
    _corner(s, d)
    _h(s, 0, 2.20, d['t'], 76, W, al='c')
    _p(s, 3.2, 4.85, W - 6.4, d.get('s', ''), 12.5, 'E6E6E6', 'c')


@reg
def br_toc(prs, d):
    s = page(prs, K)
    _full(s, d.get('pi', 3), 0.55, (0.7, 0.3))
    _h(s, M, 0.40, d['t'], 60, W - M * 2)
    for i, t in enumerate(d['items'][:6]):
        y = 2.55 + i * 0.68
        ln(s, M, y + 0.60, 7.4, y + 0.60, SOFT, 0.8)
        txt(s, M, y + 0.20, 1.0, 0.30, f'ที่ {i + 1}', 10, SOFT, 'md')
        txt(s, 1.6, y + 0.02, 5.8, 0.55, t, 22, WH, 'bd', 'r')


@reg
def br_colors(prs, d):
    s = page(prs, K)
    _photo(s, d.get('pi', 8), 0, 0, W, 4.95, (0.5, 0.3))
    shp(s, 'rect', 0, 0, W, 4.95, K, a=0.45)
    _corner(s, d)
    _h(s, 0, 1.35, d['t'], 64, W, al='c')
    _p(s, 3.0, 2.85, W - 6.0, d.get('note', ''), 12, 'E6E6E6', 'c')
    cw = W / 3
    for i, (name, hexv, use) in enumerate(d['items'][:3]):
        f = [R(), K, WH][i]
        tc = K if f == WH else WH
        shp(s, 'rect', i * cw, 4.95, cw, H - 4.95, f)
        txt(s, i * cw, 5.30, cw, 0.75, name, 34, tc, 'bd', 'c')
        txt(s, i * cw, 6.10, cw, 0.30, hexv, 11, tc if f != K else SOFT, 'md', 'c')
        txt(s, i * cw + 0.3, 6.50, cw - 0.6, 0.60, use, 10.5, tc if f != K else SOFT, 'rg', 'c')


@reg
def br_values(prs, d):
    s = page(prs, WH)
    _photo(s, d.get('pi', 4), 7.70, 0, W - 7.70, H, (0.5, 0.4))
    txt(s, 8.10, 0.32, 4.6, 0.30, d.get('brand', 'สตูดิโอของคุณ'), 10, WH, 'bd', 'r')
    _h(s, M, 0.55, d['t'], 64, 7.0, R())
    cw = 2.30
    for i, (h_, body) in enumerate(d['items'][:3]):
        x = M + i * (cw + 0.15)
        txt(s, x, 5.05, cw, 0.40, h_, 15, R(), 'bd')
        _p(s, x, 5.50, cw, body, 10.5, GREY)


@reg
def br_guideline(prs, d):
    s = page(prs, K)
    _full(s, d.get('pi', 10), 0.62, (0.5, 0.25))
    _corner(s, d)
    _p(s, 3.2, 2.20, W - 6.4, d.get('k', ''), 13, WH, 'c')
    txt(s, M, 4.60, 5.0, 0.30, d.get('l', ''), 12, RL, 'bd')
    txt(s, W - M - 5.0, 4.60, 5.0, 0.30, d.get('r', ''), 12, RL, 'bd', 'r')
    _h(s, 0, 4.95, d['t'], 96, W, R(), 'c')


@reg
def br_photography(prs, d):
    s = page(prs, K)
    _full(s, d.get('pi', 0), 0.45, (0.5, 0.3))
    _corner(s, d)
    _h(s, 0, 2.60, d['t'], 72, W, al='c')
    _p(s, 3.4, 4.35, W - 6.8, d.get('note', ''), 12, 'E6E6E6', 'c')


@reg
def br_typeface(prs, d):
    s = page(prs, WH)
    _photo(s, d.get('pi', 7), 0, 0, 4.60, H, (0.5, 0.3))
    _mark(s, M + 0.15, 0.48, 0.30, R())
    txt(s, M + 0.40, 0.32, 3.0, 0.30, d.get('brand', 'สตูดิโอของคุณ'), 10, WH, 'bd')
    for i, (lab, name, w) in enumerate(d['items'][:2]):
        x = 5.10 + i * 4.00
        txt(s, x, 0.55, 3.6, 0.28, lab, 10, GREY, 'md')
        txt(s, x, 0.95, 3.8, 1.0, name, 30, R(), w, sp=0.95)
    _p(s, 5.10, 3.20, 6.6, d.get('note', ''), 11.5, GREY)
    txt(s, 5.10, 4.40, 7.8, 0.90, d.get('sample', ''), 26, K, 'bd')
    txt(s, 5.10, 5.20, 7.8, 0.50, d.get('sample', ''), 16, K, 'rg')
    _h(s, 5.00, 5.85, d['t'], 72, 8.2, R())


@reg
def br_logo(prs, d):
    s = page(prs, K)
    _photo(s, d.get('pi', 2), 0, 0, W, 3.90, (0.5, 0.3))
    shp(s, 'rect', 0, 0, W, 3.90, K, a=0.45)
    _corner(s, d)
    _h(s, M, 1.15, d['t'], 64, 7.0)
    _p(s, 8.6, 1.40, 4.2, d.get('note', ''), 11, 'E6E6E6')
    cells = [(0, 3.90, K, R()), (W / 2, 3.90, WH, K), (0, 5.70, WH, R()), (W / 2, 5.70, K, WH)]
    for (x, y, f, c) in cells:
        shp(s, 'rect', x, y, W / 2, 1.80, f)
        txt(s, x, y, W / 2 - 0.9, 1.80, d.get('brand', 'สตูดิโอของคุณ'), 24, c, 'bd', 'c', 'm')
        _mark(s, x + W / 2 - 1.30, y + 0.90, 0.42, c)


# ══ อีก 12 เลย์เอาต์ในระบบเดียวกัน ════════════════════════════════════════

@reg
def br_about(prs, d):
    s = page(prs, WH)
    _corner(s, d, False, False)
    _h(s, M, 0.85, d['t'], 64, 7.5, R())
    _p(s, M, 3.10, 6.2, d.get('note', ''), 12.5, GREY)
    for i, (v, lab) in enumerate(d['items'][:3]):
        x = M + i * 2.15
        txt(s, x, 5.30, 2.1, 0.80, v, 36, K, 'bd')
        txt(s, x, 6.15, 2.0, 0.50, lab, 10.5, GREY, 'md')
    _photo(s, d.get('pi', 11), 7.70, 0.85, W - M - 7.70, H - 1.40, (0.5, 0.3))


@reg
def br_audience(prs, d):
    s = page(prs, K)
    _corner(s, d)
    _h(s, M, 0.85, d['t'], 56, 7.0)
    _p(s, M, 2.95, 5.6, d.get('note', ''), 12)
    cols = [R(), WH, '7A7A7A', '3A3A3A']
    it = d['items'][:4]
    chart(s, 'donut', 6.60, 1.05, 3.40, 3.40, [x[0] for x in it], [('ร้อยละ', [x[1] for x in it])], cols, labels=False, hole=58)
    for i, (lab, v, body) in enumerate(it):
        y = 4.75 + (i // 2) * 1.10
        x = M + (i % 2) * 6.30
        shp(s, 'rect', x, y + 0.08, 0.26, 0.26, cols[i], line=SOFT if cols[i] == '3A3A3A' else None, lw=0.6)
        txt(s, x + 0.45, y, 2.6, 0.40, lab, 14, WH, 'bd')
        _p(s, x + 0.45, y + 0.42, 4.5, body, 10.5)
        txt(s, x + 4.80, y - 0.04, 1.2, 0.60, f'{v}%', 26, RL, 'bd', 'r')
    txt(s, 10.30, 1.75, 2.4, 1.0, d['big'], 40, WH, 'bd')
    _p(s, 10.30, 2.70, 2.4, d['biglab'], 10.5)


@reg
def br_voice(prs, d):
    s = page(prs, WH)
    _corner(s, d, False)
    _h(s, M, 0.85, d['t'], 60, 12.0, R())
    cw = (W - M * 2 - 0.30) / 2
    for i, (lab, items) in enumerate(d['items'][:2]):
        x = M + i * (cw + 0.30)
        f = K if i == 0 else R()
        shp(s, 'rect', x, 2.75, cw, 4.20, f)
        txt(s, x + 0.40, 2.95, cw - 0.8, 0.70, lab, 30, WH, 'bd')
        for k, t in enumerate(items[:4]):
            txt(s, x + 0.40, 3.90 + k * 0.72, cw - 0.8, 0.60, t, 14, WH if i else SOFT, 'md')


@reg
def br_chart_reach(prs, d):
    s = page(prs, WH)
    _corner(s, d, False)
    _h(s, M, 0.85, d['t'], 52, 5.5, R())
    for i, (v, lab) in enumerate(d['items'][:2]):
        y = 3.55 + i * 1.60
        shp(s, 'rect', M, y, 0.12, 1.25, R() if i == 0 else K)
        txt(s, M + 0.35, y - 0.05, 4.5, 0.80, v, 36, K, 'bd')
        _p(s, M + 0.35, y + 0.78, 4.3, lab, 10.5, GREY)
    n = len(d['vals'])
    chart(s, 'col', 5.80, 0.95, W - M - 5.80, 6.00, d['cats'], [(d['sname'], d['vals'])],
          ['C9C9C9'] * (n - 1) + [R()], labels=True, fmt='0.0', gap=40, sz=12, c=K, vary=True)


@reg
def br_channels(prs, d):
    s = page(prs, K)
    _full(s, d.get('pi', 5), 0.70, (0.5, 0.3))
    _corner(s, d)
    _h(s, M, 0.85, d['t'], 56, 9.0)
    chart(s, 'bar', M, 2.40, 7.20, 4.60, d['cats'], [(d['sname'], d['vals'])], [RL], labels=True,
          fmt='0"%"', gap=45, sz=12, c=WH)
    _p(s, 8.40, 2.60, 4.3, d.get('note', ''), 12, 'E6E6E6')
    txt(s, 8.40, 4.60, 4.3, 1.0, d['big'], 48, RL, 'bd')
    _p(s, 8.40, 5.65, 4.3, d['biglab'], 11, 'E6E6E6')


@reg
def br_dosdonts(prs, d):
    s = page(prs, WH)
    _corner(s, d, False)
    _h(s, M, 0.85, d['t'], 56, 12.0, R())
    cw = (W - M * 2 - 0.30) / 2
    for i, (lab, n, items) in enumerate(d['items'][:2]):
        x = M + i * (cw + 0.30)
        _photo(s, n, x, 2.35, 2.20, 4.60, (0.5, 0.3))
        shp(s, 'rect', x + 2.20, 2.35, cw - 2.20, 0.70, R() if i == 0 else K)
        txt(s, x + 2.45, 2.35, cw - 2.6, 0.70, lab, 18, WH, 'bd', an='m')
        for k, t in enumerate(items[:4]):
            txt(s, x + 2.45, 3.30 + k * 0.88, cw - 2.65, 0.80, t, 12, K, 'md', sp=1.2)


@reg
def br_launch(prs, d):
    s = page(prs, K)
    _corner(s, d)
    _h(s, M, 0.85, d['t'], 56, 12.0)
    n = len(d['items'][:4]); cw = (W - M * 2) / n
    for i, (when, h_, body) in enumerate(d['items'][:4]):
        x = M + i * cw
        top = 5.20 - i * 0.85
        f = R() if i == n - 1 else ('2A2A2A' if i % 2 else '1E1E1E')
        shp(s, 'rect', x, top, cw - 0.10, H - top, f)
        txt(s, x + 0.25, top + 0.20, cw - 0.5, 0.40, when, 12, WH if f == R() else RL, 'bd')
        txt(s, x + 0.25, top + 0.65, cw - 0.5, 0.80, h_, 18, WH, 'bd', sp=1.0)
        _p(s, x + 0.25, top + 1.45, cw - 0.5, body, 10.5, WH if f == R() else SOFT)


@reg
def br_budget(prs, d):
    s = page(prs, WH)
    _corner(s, d, False)
    _h(s, M, 0.85, d['t'], 52, 7.0, R())
    cols = d['colw']; tw = W - M * 2; y0 = 2.45; rh = 0.70
    xs = [M]
    for f in cols[:-1]: xs.append(xs[-1] + tw * f)
    shp(s, 'rect', M, y0, tw, 0.60, K)
    for j, hd in enumerate(d['head']):
        txt(s, xs[j] + 0.22, y0, tw * cols[j] - 0.44, 0.60, hd, 12, WH, 'bd', 'l' if j == 0 else 'r', 'm')
    for i, row in enumerate(d['rows']):
        y = y0 + 0.60 + i * rh
        last = i == len(d['rows']) - 1
        if last: shp(s, 'rect', M, y, tw, rh, R())
        else: ln(s, M, y + rh, W - M, y + rh, 'D9D9D9', 1)
        for j, cell in enumerate(row):
            txt(s, xs[j] + 0.22, y, tw * cols[j] - 0.44, rh, cell, 13, WH if last else K,
                'bd' if (last or j == 0) else 'rg', 'l' if j == 0 else 'r', 'm')


@reg
def br_team(prs, d):
    s = page(prs, K)
    _corner(s, d)
    _h(s, M, 0.85, d['t'], 56, 9.0)
    cw = (W - M * 2 - 0.45) / 4
    for i, (name, role, n) in enumerate(d['items'][:4]):
        x = M + i * (cw + 0.15)
        _photo(s, n, x, 2.25, cw, 3.70, (0.5, 0.3))
        shp(s, 'rect', x, 5.95, cw, 1.00, R() if i == 0 else WH)
        txt(s, x + 0.20, 6.00, cw - 0.4, 0.45, name, 15, WH if i == 0 else K, 'bd')
        txt(s, x + 0.20, 6.45, cw - 0.4, 0.40, role, 11, WH if i == 0 else GREY, 'md')


@reg
def br_quote(prs, d):
    s = page(prs, R())
    _photo(s, d.get('pi', 9), 7.60, 0, W - 7.60, H, (0.5, 0.3))
    txt(s, M, 0.32, 3.0, 0.30, d.get('brand', 'สตูดิโอของคุณ'), 10, WH, 'bd')
    _mark(s, M + 0.30, 1.50, 0.60, WH)
    txt(s, M, 2.20, 6.6, 3.2, d['t'], 26, WH, 'bd', sp=1.2)
    txt(s, M, 5.75, 6.0, 0.40, d['who'], 15, WH, 'bd')
    _p(s, M, 6.15, 6.4, d['role'], 11.5, WH)


@reg
def br_div_red(prs, d):
    s = page(prs, R())
    txt(s, M, 0.32, 3.0, 0.30, d.get('brand', 'สตูดิโอของคุณ'), 10, WH, 'bd')     # บนแดง ใช้ขาว ไม่ใช่แดงซ้อนแดง
    txt(s, W - M - 3.0, 0.32, 3.0, 0.30, d.get('right', 'คู่มือแบรนด์'), 10, WH, 'bd', 'r')
    _mark(s, W / 2, 0.48, 0.30, WH)
    txt(s, M, 2.15, 6.0, 0.40, d.get('k', ''), 14, WH, 'bd')
    _h(s, M, 2.65, d['t'], 88, 12.0, WH)
    _p(s, M, 5.55, 8.0, d.get('note', ''), 13, WH)


@reg
def br_close(prs, d):
    s = page(prs, K)
    _full(s, d.get('pi', 6), 0.62, (0.5, 0.3))
    _corner(s, d)
    txt(s, M, 4.45, 5.0, 0.30, d.get('l', ''), 12, RL, 'bd')
    txt(s, W - M - 5.0, 4.45, 5.0, 0.30, d.get('r', ''), 12, RL, 'bd', 'r')
    _p(s, 3.4, 2.20, W - 6.8, d.get('note', ''), 13, WH, 'c')
    _h(s, 0, 4.85, d['t'], 104, W, R(), 'c')
