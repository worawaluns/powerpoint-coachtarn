"""กรอบกล่องข้อความสูงพอดีตัวหนังสือ (กฎไอซ์ "กรอบกล่องข้อความสูงพอดีตัวหนังสือ" ฝั่งเว็บขึ้นแล้ว V=20261101a)
กล่องที่ลูกค้าเพิ่ม/ย้าย/ย่อขยาย/แต่ง: เขียนความสูงจริงของตัวหนังสือลงไฟล์ PowerPoint ให้กรอบในแอปเท่ากับกรอบบนเว็บ
  bodyPr = <a:spAutoFit/> (PowerPoint ปรับกรอบตามคำต่อเอง) แทน normAutofit / cy = ความสูงที่วัด (lines() ตัวเดียวกับ overflow) + ขอบใน
  ตำแหน่งที่ตาเห็นคงเดิมตามจุดยึด: บน = ขอบบนคงที่ / กลาง = จุดกลางคงที่ / ล่าง = ขอบล่างคงที่
doc2slide.render เรียกหลังจัดตำแหน่ง (apply_moves) ก่อน boxmap เว็บจึงได้ความสูงใหม่ใน BOXES ตรงกับไฟล์"""
from pptx.oxml.ns import qn

EMU = 914400
INSET = int(0.04 * EMU)                                    # เผื่อหางสระ/วรรณยุกต์ล่างไม่ชนขอบ


def text_h(tf, w_emu, lines, facefile):
    """ความสูงตัวหนังสือ (EMU) = ทุกย่อหน้า: บรรทัดที่ตัดจริง × ขนาด × 1.25 × ระยะบรรทัด + ขอบในบนล่าง"""
    m = lambda v: v or 0
    w_in = max(0.1, (w_emu - m(tf.margin_left) - m(tf.margin_right)) / EMU); tot = 0.0
    for p in tf.paragraphs:
        r = next((r for r in p.runs if r.font.size), None)
        pt = r.font.size.pt if r else 18
        sp = p.line_spacing if isinstance(p.line_spacing, float) else 1.0   # ระยะบรรทัดแบบ pt ตายตัว: นับเป็น 1 เท่า
        n = lines(''.join(x.text for x in p.runs) or ' ', w_in, pt, facefile(r.font.name if r else None, bool(r and r.font.bold)))
        tot += n * pt * 1.25 * sp / 72
    return int(tot * EMU) + m(tf.margin_top) + m(tf.margin_bottom)


def fit(sh, lines, facefile):
    """กล่องหนึ่ง: ความสูง = ตัวหนังสือ + spAutoFit คงตำแหน่งตามจุดยึด คืนความสูงใหม่ (EMU)"""
    tf = sh.text_frame; bp = tf._txBody.find(qn('a:bodyPr'))
    for tag in ('a:normAutofit', 'a:noAutofit', 'a:spAutoFit'):
        for e in bp.findall(qn(tag)): bp.remove(e)
    sa = bp.makeelement(qn('a:spAutoFit'), {}); w = bp.find(qn('a:prstTxWarp'))
    (w.addnext(sa) if w is not None else bp.insert(0, sa))  # ลำดับ schema: prstTxWarp > autofit > scene3d
    h = text_h(tf, sh.width, lines, facefile) + INSET; top, old = sh.top, sh.height
    an = bp.get('anchor', 't')
    if an == 'ctr': top += (old - h) // 2
    elif an == 'b': top += old - h
    sh.top, sh.height = int(top), int(h)
    return h
