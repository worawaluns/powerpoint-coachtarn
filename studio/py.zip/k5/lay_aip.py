"""20 เลย์เอาต์ชุด AI Pitch Deck — ลอกโครงจากเทมเพลตไลม์ที่ไอซ์ส่งมา

ทุกหน้ามีแถบเว็บด้านบน: @Company ซ้าย, เมนูเม็ดยาตรงกลาง (Home เป็นไลม์), Pitch Deck ขวา
สีมีแค่ไลม์ (acc) + ดำ (ink) + ขาว + เทาอ่อน (panel) ตามต้นฉบับ
"""
from eng import *
import eng
from lay import L, reg


def _duo():
    """ย้อมรูปให้อยู่ในโทนเดียวกับพาเลตต์ของเด็ค ไม่ให้สีรูปตีกับสีธีม"""
    if P.get('dark'):
        return f"duo:{mix(P['bg'], P['acc'], 0.34)}:{mix(P['acc'], 'FFFFFF', 0.54)}"
    return f"duo:{mix(P['ink'], P['acc'], 0.42)}:{mix(P['bg'], P['acc'], 0.13)}"

M = 0.62
NAV = ['Home', 'Catalogue', 'About Us', 'FAQ', 'Contact']


# ── แถบเว็บด้านบน ที่ทุกหน้าใช้ร่วมกัน ──────────────────────────────────────
def _bar(s, d):
    ink = P['ink']
    txt(s, M, 0.34, 2.2, 0.28, d.get('brand', '@Company'), 9.5, ink, 'md')
    x = 4.62
    for i, n in enumerate(NAV):
        w = len(n) * 0.068 + 0.40
        if i == 0:
            shp(s, 'round', x, 0.30, w, 0.34, P['acc'], adj=0.5)
        txt(s, x, 0.30, w, 0.34, n, 8.5, ink if i == 0 else P['mute'], 'md' if i == 0 else 'rg', 'c', 'm')
        x += w + 0.26
    txt(s, W - M - 2.0, 0.34, 1.72, 0.28, d.get('corner', 'Pitch Deck'), 8.5, ink, 'md', 'r')
    _chev(s, W - M - 0.22, 0.38, 0.20)
    ln(s, M, 0.84, W - M, 0.84, mix(P['bg'], P['mute'], 0.28), 0.6)


def _chev(s, x, y, sz=0.26, c=None):
    """ลูกศรลงเล็ก ๆ ในกล่องไลม์ แบบที่ต้นฉบับแปะท้ายหัวเรื่อง"""
    shp(s, 'round', x, y, sz, sz, c or P['acc'], adj=0.3)
    k = sz * 0.26
    ln(s, x + sz / 2 - k, y + sz / 2 - k * 0.5, x + sz / 2, y + sz / 2 + k * 0.6, P['ink'], 1.3)
    ln(s, x + sz / 2, y + sz / 2 + k * 0.6, x + sz / 2 + k, y + sz / 2 - k * 0.5, P['ink'], 1.3)


def _pill(s, x, y, t, fill=None, c=None, sz=13.5):
    w = len(t) * 0.072 + 0.46
    shp(s, 'round', x, y, w, 0.34, fill or P['acc'], adj=0.5)
    txt(s, x, y, w, 0.34, t, sz, c or P['ink'], 'md', 'c', 'm')
    return w


def _kick(s, x, y, t):
    if t: txt(s, x, y, 4.0, 0.26, t, 13.5, P['mute'], 'md', track=0.6)


def _title(s, x, y, t, w=5.4, sz=38, chev=True):
    txt(s, x, y, w, 1.3, t, sz, P['ink'], 'md', sp=1.16)
    if chev:
        lines = t.count('\n') + 1
        last = t.split('\n')[-1]
        cx = x + min(len(last) * sz * 0.0088, w - 0.4)
        _chev(s, cx + 0.10, y + (lines - 0.52) * sz * 0.0205, 0.26)


def _dot(s, x, y, sz=0.34, dark=True):
    shp(s, 'oval', x, y, sz, sz, P['ink'] if dark else P['acc'])
    return sz


def _soft(on_acc=False):
    return mix(P['acc'], P['ink'], 0.66) if on_acc else mix(P['bg'], P['ink'], 0.58)


def _body(s, x, y, w, t, sz=13, c=None, on_acc=False):
    txt(s, x, y, w, 0.9, t, sz, c or _soft(on_acc), 'rg', sp=1.4)


# ── 1. ปก ───────────────────────────────────────────────────────────────────
@reg
def ap_cover(prs, d):
    s = page(prs); _bar(s, d)
    pic(s, ph(d['topic'], d.get('pi', 0)), M, 1.08, W - M * 2, 5.02, geom='roundRect', adj=0.055, focus=(0.5, 0.42), mode=_duo())
    shp(s, 'round', M, 1.08, W - M * 2, 5.02, '000000', a=0.30, adj=0.055)
    _pill(s, 1.05, 1.52, d.get('k', ''))
    txt(s, 1.05, 2.08, 8.2, 1.9, d['t'], d.get('tsz', 38), 'FFFFFF', 'md', sp=1.14)
    _dot(s, W - 1.42, 1.48, 0.44)
    ln(s, W - 1.30, 1.60, W - 1.14, 1.76, 'FFFFFF', 1.4); ln(s, W - 1.14, 1.60, W - 1.14, 1.76, 'FFFFFF', 1.4)
    card(s, 1.05, 4.52, 4.05, 1.22, 'FFFFFF', adj=0.12)
    txt(s, 1.28, 4.72, 3.6, 0.85, d['s'], 14, P['ink'], 'rg', sp=1.4)
    card(s, 8.35, 3.28, 3.55, 2.30, 'FFFFFF', adj=0.10, shadow=True)
    pic(s, ph(d['topic'], d.get('pi2', 3)), 8.58, 3.50, 3.09, 1.12, geom='roundRect', adj=0.09, mode=_duo())
    txt(s, 8.58, 4.74, 2.4, 0.46, d['big'], 28, P['ink'], 'md')
    _body(s, 8.58, 5.18, 2.5, d['biglab'], 13)
    _dot(s, 11.22, 4.80, 0.32, dark=False)


# ── 2. การ์ดสามใบ + หัวเรื่องล่าง ───────────────────────────────────────────
@reg
def ap_cards3(prs, d):
    s = page(prs); _bar(s, d)
    cw, gap = 3.73, 0.30
    fills = [P['panel'], P['acc'], P['ink']]
    inks = [P['ink'], P['ink'], 'FFFFFF']
    for i, (h_, body) in enumerate(d['items'][:3]):
        x = M + i * (cw + gap)
        card(s, x, 1.25, cw, 2.42, fills[i], adj=0.10)
        txt(s, x + 0.28, 1.46, 0.6, 0.3, f'{i + 1:02d}', 10, inks[i], 'md')
        txt(s, x + 0.28, 1.86, cw - 0.56, 0.68, h_, 12.5, inks[i], 'md', sp=1.25)
        _body(s, x + 0.28, 2.62, cw - 0.56, body, 13,
              'C9C9C9' if i == 2 else None, on_acc=(i == 1))
    _kick(s, M, 4.32, d.get('k', ''))
    _title(s, M, 4.66, d['t'], 5.6, 32)
    txt(s, 7.55, 4.32, 5.2, 0.56, d['s'], 16, P['ink'], 'md', sp=1.3)
    _body(s, 7.55, 5.06, 5.15, d['note'], 13.5)


# ── 3. สองคอลัมน์คร่อมรูป + การ์ดเรียงขวา ──────────────────────────────────
@reg
def ap_split_rows(prs, d):
    s = page(prs); _bar(s, d)
    txt(s, M, 1.22, 3.35, 0.62, d['s'], 14.5, P['ink'], 'md', sp=1.3)
    _body(s, M, 1.92, 3.3, d['note'], 13)
    _kick(s, M, 4.28, d.get('k', ''))
    _title(s, M, 4.60, d['t'], 3.6, 27)
    pic(s, ph(d['topic'], d.get('pi', 1)), 4.28, 1.22, 3.45, 5.05, geom='roundRect', adj=0.06, focus=(0.5, 0.45), mode=_duo())
    fills = [P['acc'], P['ink'], P['panel']]
    inks = [P['ink'], 'FFFFFF', P['ink']]
    for i, (h_, body) in enumerate(d['items'][:3]):
        y = 1.22 + i * 1.74
        x = 8.00
        card(s, x, y, W - M - x, 1.56, fills[i], adj=0.11)
        txt(s, x + 0.28, y + 0.20, 0.6, 0.28, f'{i + 1:02d}', 9.5, inks[i], 'md')
        txt(s, x + 0.28, y + 0.52, W - M - x - 0.56, 0.58, h_, 11, inks[i], 'md', sp=1.25)
        _body(s, x + 0.28, y + 1.08, W - M - x - 0.56, body, 13,
              'C9C9C9' if i == 1 else None, on_acc=(i == 0))


# ── 4. กราฟแท่งสามแท่ง + การ์ดดำ ────────────────────────────────────────────
@reg
def ap_bars(prs, d):
    s = page(prs); _bar(s, d)
    _kick(s, M, 1.30, d.get('k', ''))
    _title(s, M, 1.62, d['t'], 5.0, 29)
    _body(s, M, 2.98, 4.6, d['note'], 13.5)
    card(s, M, 3.92, 3.35, 1.32, P['ink'], adj=0.14)
    _dot(s, M + 0.26, 4.26, 0.36, dark=False)
    txt(s, M + 0.74, 4.12, 2.2, 0.62, d['big'], 38, 'FFFFFF', 'md')
    _body(s, M + 0.74, 4.74, 2.3, d['biglab'], 13, 'BFBFBF')
    n = len(d['bars'][:3]); bw, gap = 1.62, 0.34
    x0 = W - M - (bw * n + gap * (n - 1))
    for i, (lab, v, note) in enumerate(d['bars'][:3]):
        h = 2.15 + i * 0.95
        x = x0 + i * (bw + gap)
        y = 5.02 - h
        fill = P['acc'] if i == n - 1 else (P['panel'] if i == 0 else mix(P['bg'], P['mute'], 0.22))
        shp(s, 'round', x, y, bw, h, fill, adj=0.12)
        txt(s, x, y + 0.20, bw, 0.42, lab, 17, P['ink'], 'md', 'c')
        txt(s, x, 5.18, bw, 0.34, v, 15, P['ink'], 'md')
        _body(s, x, 5.56, bw, note, 13)


# ── 5. จอโน้ตบุ๊ก + การ์ดคู่ ─────────────────────────────────────────────────
@reg
def ap_laptop(prs, d):
    s = page(prs); _bar(s, d)
    _kick(s, M + 0.72, 1.42, d.get('k', ''))
    _title(s, M + 0.72, 1.74, d['t'], 5.0, 29)
    _dot(s, M, 3.92, 0.40)
    ln(s, M + 0.20, 4.02, M + 0.20, 4.20, 'FFFFFF', 1.4)
    ln(s, M + 0.13, 4.13, M + 0.20, 4.21, 'FFFFFF', 1.4); ln(s, M + 0.27, 4.13, M + 0.20, 4.21, 'FFFFFF', 1.4)
    for i, (h_, body) in enumerate(d['items'][:2]):
        x = M + 0.72 + i * 2.52
        card(s, x, 3.62, 2.34, 1.76, P['acc'] if i else 'FFFFFF', adj=0.10,
             line=None if i else mix(P['bg'], P['mute'], 0.3))
        txt(s, x + 0.24, 3.84, 1.9, 0.56, h_, 14.5, P['ink'], 'md', sp=1.25)
        _body(s, x + 0.24, 4.48, 1.86, body, 13, on_acc=bool(i))
    lx, ly, lw = 6.60, 1.46, 6.10
    lh = lw * 0.585
    shp(s, 'round', lx, ly, lw, lh, P['ink'], adj=0.035)
    pic(s, ph(d['topic'], d.get('pi', 2)), lx + 0.13, ly + 0.13, lw - 0.26, lh - 0.26, geom='roundRect', adj=0.02, mode=_duo())
    shp(s, 'round', lx - 0.26, ly + lh, lw + 0.52, 0.22, mix(P['bg'], P['ink'], 0.82), adj=0.5)


# ── 6. สี่แถวสองฝั่ง + รูป ───────────────────────────────────────────────────
@reg
def ap_infra(prs, d):
    s = page(prs); _bar(s, d)
    cw = 5.86
    for i, (h_, body) in enumerate(d['items'][:4]):
        col, row = i // 2, i % 2
        x = M + col * (cw + 0.33)
        y = (1.22 if col == 0 else 3.52) + row * 1.12
        card(s, x, y, cw, 0.98, P['acc'] if i % 2 else P['panel'], adj=0.16)
        txt(s, x + 0.26, y + 0.14, 0.5, 0.26, f'{i + 1:02d}', 14, P['ink'], 'md')
        txt(s, x + 0.86, y + 0.14, cw - 1.75, 0.28, h_, 15, P['ink'], 'md')
        _body(s, x + 0.86, y + 0.46, cw - 1.75, body, 13, on_acc=bool(i % 2))
        _chev(s, x + cw - 0.52, y + 0.33, 0.30, 'FFFFFF' if i % 2 else P['acc'])
    pic(s, ph(d['topic'], d.get('pi', 4)), M + cw + 0.33, 1.22, cw, 2.06, geom='roundRect', adj=0.09, focus=(0.5, 0.45), mode=_duo())
    _kick(s, M, 3.86, d.get('k', ''))
    _title(s, M, 4.18, d['t'], 4.4, 27)


# ── 7. หน้าพัก + แถบรูปกว้าง ────────────────────────────────────────────────
@reg
def ap_break(prs, d):
    s = page(prs); _bar(s, d)
    _pill(s, M, 1.22, d.get('k', ''))
    txt(s, M, 1.78, 6.0, 1.3, d['t'], 45, P['ink'], 'md', sp=1.14)
    _chev(s, M + 4.30, 2.42, 0.28)
    card(s, 7.95, 1.30, 4.76, 1.52, P['acc'], adj=0.11)
    txt(s, 8.22, 1.52, 1.9, 0.48, d['big'], 28, P['ink'], 'md')
    _body(s, 8.22, 2.02, 2.0, d['biglab'], 13, on_acc=True)
    pic(s, ph(d['topic'], d.get('pi2', 6)), 10.42, 1.50, 2.08, 1.12, geom='roundRect', adj=0.10, mode=_duo())
    pic(s, ph(d['topic'], d.get('pi', 5)), M, 3.28, W - M * 2, 2.84, geom='roundRect', adj=0.055, focus=(0.5, 0.45), mode=_duo())
    card(s, 0.95, 5.10, 2.56, 0.80, 'FFFFFF', adj=0.18)
    _body(s, 1.16, 5.22, 2.2, d['badgelab'], 13)
    txt(s, 1.16, 5.46, 2.2, 0.34, d['badge'], 17, P['ink'], 'md')
    _dot(s, 3.62, 5.36, 0.34)
    ln(s, 3.72, 5.53, 3.88, 5.53, 'FFFFFF', 1.4); ln(s, 3.80, 5.45, 3.80, 5.61, 'FFFFFF', 1.4)


# ── 8. ขอบคุณ + ช่องทางติดต่อ ───────────────────────────────────────────────
@reg
def ap_thanks(prs, d):
    s = page(prs); _bar(s, d)
    _pill(s, M, 1.22, d.get('k', ''))
    txt(s, M, 1.80, 6.0, 1.3, d['t'], 45, P['ink'], 'md', sp=1.14)
    _chev(s, M + 4.05, 2.44, 0.28)
    for i, (lab, val) in enumerate(d['items'][:4]):
        x = 7.90 + (i % 2) * 2.62
        y = 1.32 + (i // 2) * 0.90
        _dot(s, x, y, 0.30, dark=False)
        txt(s, x + 0.42, y - 0.02, 2.1, 0.26, lab, 13, P['mute'], 'md')
        txt(s, x + 0.42, y + 0.26, 2.2, 0.28, val, 13.5, P['ink'], 'rg')
    pic(s, ph(d['topic'], d.get('pi', 7)), M, 3.30, W - M * 2, 2.82, geom='roundRect', adj=0.055, focus=(0.5, 0.45), mode=_duo())


# ══ อีก 12 เลย์เอาต์ เติมให้ครบ 20 หน้า ════════════════════════════════════

# ── 9. สารบัญ ───────────────────────────────────────────────────────────────
@reg
def ap_agenda(prs, d):
    s = page(prs); _bar(s, d)
    _kick(s, M, 1.30, d.get('k', ''))
    _title(s, M, 1.62, d['t'], 3.8, 29)
    _body(s, M, 3.30, 3.6, d.get('note', ''), 13.5)
    x = 5.25
    for i, (h_, body) in enumerate(d['items'][:5]):
        y = 1.22 + i * 1.02
        card(s, x, y, W - M - x, 0.88, P['acc'] if i % 2 else P['panel'], adj=0.18)
        txt(s, x + 0.28, y + 0.12, 0.5, 0.26, f'{i + 1:02d}', 14, P['ink'], 'md')
        txt(s, x + 0.88, y + 0.11, 4.4, 0.28, h_, 15, P['ink'], 'md')
        _body(s, x + 0.88, y + 0.44, 5.6, body, 13, on_acc=bool(i % 2))
        _chev(s, W - M - 0.50, y + 0.29, 0.30, 'FFFFFF' if i % 2 else P['acc'])


# ── 10. หน้าคั่นบท ──────────────────────────────────────────────────────────
@reg
def ap_divider(prs, d):
    s = page(prs); _bar(s, d)
    pic(s, ph(d['topic'], d.get('pi', 8)), 6.40, 1.18, W - M - 6.40, 4.96, geom='roundRect', adj=0.06, focus=(0.5, 0.45), mode=_duo())
    _pill(s, M, 1.90, d.get('k', ''))
    txt(s, M, 2.72, 2.2, 1.3, d['num'], 54, P['acc'], 'md')
    txt(s, M, 4.10, 5.4, 1.0, d['t'], 43, P['ink'], 'md', sp=1.14)
    if d.get('s'): _body(s, M, 5.18, 5.2, d['s'], 14)


# ── 11. ขนาดตลาด สามก้อน + รูป ──────────────────────────────────────────────
@reg
def ap_market(prs, d):
    s = page(prs); _bar(s, d)
    _kick(s, M, 1.28, d.get('k', ''))
    _title(s, M, 1.60, d['t'], 5.0, 29)
    _body(s, M, 2.96, 4.8, d['note'], 13.5)
    for i, (v, lab, sub_) in enumerate(d['items'][:3]):
        y = 3.90 + i * 0.86
        ln(s, M, y, 5.55, y, mix(P['bg'], P['mute'], 0.28), 0.6)
        txt(s, M, y + 0.14, 1.75, 0.46, v, 27, P['ink'], 'md')
        txt(s, M + 1.85, y + 0.12, 1.7, 0.26, lab, 14, P['ink'], 'md')
        _body(s, M + 1.85, y + 0.40, 3.6, sub_, 13)
    pic(s, ph(d['topic'], d.get('pi', 9)), 6.30, 1.18, W - M - 6.30, 4.96, geom='roundRect', adj=0.06, focus=(0.5, 0.42), mode=_duo())
    card(s, 6.80, 4.85, 3.05, 0.92, 'FFFFFF', adj=0.18)
    txt(s, 7.02, 4.98, 2.6, 0.32, d['big'], 17, P['ink'], 'md')
    _body(s, 7.02, 5.30, 2.6, d['biglab'], 13)


# ── 12. ฟีเจอร์สี่ช่อง ──────────────────────────────────────────────────────
@reg
def ap_features(prs, d):
    s = page(prs); _bar(s, d)
    _kick(s, M, 1.28, d.get('k', ''))
    _title(s, M, 1.60, d['t'], 6.2, 29)
    _body(s, 7.80, 1.34, 4.9, d['note'], 13.5)
    cw, ch = 6.00, 1.62
    for i, (h_, body) in enumerate(d['items'][:4]):
        x = M + (i % 2) * (cw + 0.33)
        y = 3.12 + (i // 2) * (ch + 0.26)
        card(s, x, y, cw, ch, P['acc'] if i in (1, 2) else P['panel'], adj=0.11)
        _dot(s, x + 0.28, y + 0.26, 0.34, dark=(i in (1, 2)))
        txt(s, x + 0.80, y + 0.26, cw - 1.15, 0.32, h_, 15.5, P['ink'], 'md')
        _body(s, x + 0.80, y + 0.66, cw - 1.15, body, 13,
              on_acc=(i in (1, 2)))


# ── 13. โรดแมปสี่ช่วง ───────────────────────────────────────────────────────
@reg
def ap_roadmap(prs, d):
    s = page(prs); _bar(s, d)
    _kick(s, M, 1.28, d.get('k', ''))
    _title(s, M, 1.60, d['t'], 5.4, 29)
    _body(s, 7.80, 1.34, 4.9, d['note'], 13.5)
    n = len(d['items'][:4]); cw = (W - M * 2 - 0.30 * (n - 1)) / n
    ln(s, M, 3.62, W - M, 3.62, mix(P['bg'], P['mute'], 0.30), 0.7)
    for i, (per, h_, body) in enumerate(d['items'][:4]):
        x = M + i * (cw + 0.30)
        hot = i < 2
        shp(s, 'oval', x, 3.48, 0.28, 0.28, P['acc'] if hot else mix(P['bg'], P['mute'], 0.28))
        txt(s, x, 3.00, cw, 0.32, per, 15, P['ink'], 'md')
        card(s, x, 3.98, cw, 1.92, P['acc'] if hot else P['panel'], adj=0.11)
        txt(s, x + 0.26, 4.20, cw - 0.52, 0.60, h_, 15.5, P['ink'], 'md', sp=1.25)
        _body(s, x + 0.26, 4.88, cw - 0.52, body, 13,
              on_acc=hot)


# ── 14. ทีมงานสามคน ─────────────────────────────────────────────────────────
@reg
def ap_team(prs, d):
    s = page(prs); _bar(s, d)
    _kick(s, M, 1.28, d.get('k', ''))
    _title(s, M, 1.60, d['t'], 5.0, 29)
    _body(s, 7.80, 1.34, 4.9, d['note'], 13.5)
    cw = 3.98
    for i, (name, role, note) in enumerate(d['items'][:3]):
        x = M + i * (cw + 0.22)
        card(s, x, 3.10, cw, 2.82, P['panel'] if i != 1 else P['acc'], adj=0.09)
        pic(s, ph(d['topic'], d.get('pi', 10) + i), x + 0.24, 3.34, cw - 0.48, 1.26,
            geom='roundRect', adj=0.08, focus=(0.5, 0.4), mode=_duo())
        txt(s, x + 0.24, 4.74, cw - 0.48, 0.32, name, 16, P['ink'], 'md')
        txt(s, x + 0.24, 5.08, cw - 0.48, 0.28, role, 13.5, P['ink'] if i == 1 else P['mute'], 'rg')
        _body(s, x + 0.24, 5.40, cw - 0.48, note, 13,
              on_acc=(i == 1))


# ── 15. เทียบกับทางเลือกอื่น ────────────────────────────────────────────────
@reg
def ap_compare(prs, d):
    s = page(prs); _bar(s, d)
    _kick(s, M, 1.28, d.get('k', ''))
    _title(s, M, 1.60, d['t'], 6.0, 29)
    _body(s, 7.80, 1.34, 4.9, d.get('note', ''), 13.5)
    tw = W - M * 2
    cw0, cw = tw * 0.40, tw * 0.20
    y0 = 3.20
    for j, hd in enumerate(d['head']):
        x = M + (0 if j == 0 else cw0 + (j - 1) * cw)
        w = cw0 if j == 0 else cw
        if j == len(d['head']) - 1:
            shp(s, 'round', x, y0 - 0.10, w, 0.62, P['acc'], adj=0.30)
        txt(s, x + 0.20, y0, w - 0.40, 0.42, hd, 15, P['ink'], 'md', 'l' if j == 0 else 'c', 'm')
    for i, row in enumerate(d['rows'][:4]):
        y = y0 + 0.68 + i * 0.72
        ln(s, M, y - 0.06, W - M, y - 0.06, mix(P['bg'], P['mute'], 0.25), 0.6)
        for j, cell in enumerate(row):
            x = M + (0 if j == 0 else cw0 + (j - 1) * cw)
            w = cw0 if j == 0 else cw
            txt(s, x + 0.20, y, w - 0.40, 0.56, cell, 14.5, P['ink'],
                'md' if j == len(row) - 1 else 'rg', 'l' if j == 0 else 'c', 'm')


# ── 16. แพ็กเกจราคา ─────────────────────────────────────────────────────────
@reg
def ap_pricing(prs, d):
    s = page(prs); _bar(s, d)
    _kick(s, M, 1.28, d.get('k', ''))
    _title(s, M, 1.60, d['t'], 6.0, 29)
    _body(s, 7.80, 1.34, 4.9, d.get('note', ''), 13.5)
    cw = 3.98
    for i, (name, price, unit, feats) in enumerate(d['items'][:3]):
        x = M + i * (cw + 0.22)
        hot = i == 1
        card(s, x, 3.05, cw, 2.92, P['acc'] if hot else P['panel'], adj=0.09)
        txt(s, x + 0.30, 3.28, cw - 0.60, 0.30, name, 15, P['ink'], 'md')
        txt(s, x + 0.30, 3.66, cw - 0.60, 0.52, price, 31, P['ink'], 'md')
        _body(s, x + 0.30, 4.22, cw - 0.60, unit, 13,
              on_acc=hot)
        ln(s, x + 0.30, 4.62, x + cw - 0.30, 4.62,
           mix(P['acc'], P['ink'], 0.25) if hot else mix(P['bg'], P['mute'], 0.28), 0.6)
        for j, f in enumerate(feats[:3]):
            txt(s, x + 0.56, 4.74 + j * 0.38, cw - 0.86, 0.32, f, 13, P['ink'], 'rg', an='m')
            shp(s, 'oval', x + 0.30, 4.86 + j * 0.38, 0.11, 0.11, P['ink'])


# ── 17. เคสลูกค้า รูปซ้าย ผลขวา ─────────────────────────────────────────────
@reg
def ap_case(prs, d):
    s = page(prs); _bar(s, d)
    pic(s, ph(d['topic'], d.get('pi', 13)), M, 1.18, 5.95, 4.96, geom='roundRect', adj=0.06, focus=(0.5, 0.45), mode=_duo())
    card(s, 1.05, 4.92, 4.35, 1.00, 'FFFFFF', adj=0.16)
    txt(s, 1.28, 5.08, 3.9, 0.60, d['caption'], 14, P['ink'], 'rg', sp=1.35)
    _kick(s, 7.05, 1.28, d.get('k', ''))
    _title(s, 7.05, 1.60, d['t'], 5.2, 27)
    _body(s, 7.05, 2.92, 5.4, d['note'], 13.5)
    for i, (v, lab) in enumerate(d['items'][:3]):
        y = 4.02 + i * 0.74
        shp(s, 'round', 7.05, y, 1.55, 0.58, P['acc'] if i == 0 else P['panel'], adj=0.26)
        txt(s, 7.05, y, 1.55, 0.58, v, 16.5, P['ink'], 'md', 'c', 'm')
        txt(s, 8.78, y, 3.9, 0.58, lab, 14, P['ink'], 'rg', an='m')


# ── 18. ตัวเลขผลงานแถวเดียว + แถบรูป ────────────────────────────────────────
@reg
def ap_traction(prs, d):
    s = page(prs); _bar(s, d)
    _kick(s, M, 1.28, d.get('k', ''))
    _title(s, M, 1.60, d['t'], 6.2, 29)
    _body(s, 7.80, 1.34, 4.9, d.get('note', ''), 13.5)
    n = len(d['items'][:4]); cw = (W - M * 2 - 0.26 * (n - 1)) / n
    for i, (v, lab) in enumerate(d['items'][:4]):
        x = M + i * (cw + 0.26)
        card(s, x, 3.02, cw, 1.26, P['acc'] if i % 2 else P['panel'], adj=0.13)
        txt(s, x + 0.26, 3.22, cw - 0.52, 0.48, v, 30, P['ink'], 'md')
        _body(s, x + 0.26, 3.74, cw - 0.52, lab, 13,
              on_acc=bool(i % 2))
    pic(s, ph(d['topic'], d.get('pi', 16)), M, 4.54, W - M * 2, 1.60, geom='roundRect', adj=0.09, focus=(0.5, 0.45), mode=_duo())


# ── 19. คำพูดลูกค้าบนพื้นไลม์ ───────────────────────────────────────────────
@reg
def ap_quote(prs, d):
    s = page(prs); _bar(s, d)
    card(s, M, 1.18, W - M * 2, 4.96, P['acc'], adj=0.05)
    txt(s, 1.60, 1.92, 7.6, 0.6, '“', 54, P['ink'], 'md')
    txt(s, 1.60, 2.52, 7.9, 2.1, d['t'], 33, P['ink'], 'md', sp=1.28)
    ln(s, 1.60, 4.95, 4.40, 4.95, mix(P['acc'], P['ink'], 0.3), 0.8)
    txt(s, 1.60, 5.08, 5.4, 0.30, d['who'], 15, P['ink'], 'md')
    _body(s, 1.60, 5.40, 5.4, d['role'], 13, on_acc=True)
    pic(s, ph(d['topic'], d.get('pi', 17)), 9.75, 1.80, 2.70, 3.72, geom='roundRect', adj=0.09, focus=(0.5, 0.4), mode=_duo())


# ── 20. สิ่งที่ขอ + ขั้นต่อไป ───────────────────────────────────────────────
@reg
def ap_ask(prs, d):
    s = page(prs); _bar(s, d)
    _kick(s, M, 1.28, d.get('k', ''))
    _title(s, M, 1.60, d['t'], 5.6, 29)
    card(s, M, 3.02, 5.60, 2.14, P['ink'], adj=0.10)
    txt(s, M + 0.34, 3.28, 4.9, 0.56, d['big'], 37, P['acc'], 'md')
    _body(s, M + 0.34, 3.92, 4.9, d['biglab'], 13.5, 'BFBFBF')
    for i, (h_, body, when) in enumerate(d['items'][:3]):
        y = 1.30 + i * 1.62
        x = 6.75
        card(s, x, y, W - M - x, 1.44, P['acc'] if i == 0 else P['panel'], adj=0.11)
        txt(s, x + 0.28, y + 0.18, 0.5, 0.26, f'{i + 1:02d}', 14, P['ink'], 'md')
        txt(s, x + 0.88, y + 0.17, W - M - x - 1.70, 0.30, h_, 15, P['ink'], 'md')
        _body(s, x + 0.88, y + 0.50, W - M - x - 1.70, body, 13,
              on_acc=(i == 0))
        txt(s, x + 0.88, y + 1.06, W - M - x - 1.70, 0.26, when, 13, P['ink'], 'md')
