"""20 เลย์เอาต์ชุด Business Proposal — ลอกโครงจากเทมเพลตส้ม+ครีมที่ไอซ์ส่งมา

พื้นครีม เลขหน้าใหญ่สีส้มมุมบนซ้าย หัวเรื่องสองโทน (ดำ + ส้ม)
สี่เหลี่ยมส้มเล็ก ๆ วางเหลื่อมมุมรูป แถบดำใช้คู่กับครีมเป็นตัวตัด
ตัวหนังสือส้มใช้บนครีมเท่านั้น (ส้มบนดำคอนทราสต์ 3.2 ไม่ผ่าน)
"""
from eng import *
import eng
from lay import L, reg

M = 0.74


def _duo():
    if P.get('dark'):
        return f"duo:{mix(P['bg'], P['acc'], 0.26)}:{mix(P['acc'], 'FFFFFF', 0.50)}"
    return f"duo:{mix(P['ink'], P['acc'], 0.40)}:{mix(P['bg'], P['acc'], 0.10)}"


def _chrome(s, d, on_acc=False):
    c = P['bg'] if on_acc else P['mute']
    txt(s, W - M - 3.4, 0.34, 3.4, 0.26, d.get('kind', 'เอกสารข้อเสนอ'), 9, c, 'rg', 'r')
    shp(s, 'rect', M, H - 0.52, 0.22, 0.22, P['bg'] if on_acc else P['acc'])


def _num(s, d):
    if d.get('num'):
        txt(s, M, 0.72, 1.6, 0.78, d['num'], 43, P['acc'], 'md')


def _tag(s, x, y, t='#ข้อเสนอธุรกิจ', c=None):
    if t: txt(s, x, y, 3.4, 0.26, t, 13, c or P['acc'], 'md')


def _h2(s, x, y, a, b, sz=38, w=6.4):
    """หัวเรื่องสองโทน ท่อนแรกดำ ท่อนสองส้ม แบบต้นฉบับ"""
    txt(s, x, y, w, 0.80, a, sz, P['ink'], 'md')
    txt(s, x, y + sz * 0.0225, w, 0.80, b, sz, P['acc'], 'md')


def _p(s, x, y, w, t, sz=13, c=None):
    txt(s, x, y, w, 1.5, t, sz, c or mix(P['bg'], P['ink'], 0.74), 'rg', sp=1.46)


def _sq(s, x, y, sz=0.46, c=None):
    """สี่เหลี่ยมส้มเล็ก ๆ ที่ต้นฉบับวางเหลื่อมมุมรูป"""
    shp(s, 'rect', x, y, sz, sz, c or P['acc'])


def _photo(s, d, pi, x, y, w, h, sq=None):
    pic(s, ph(d['topic'], pi), x, y, w, h, mode=_duo())
    if sq == 'tr': _sq(s, x + w - 0.24, y - 0.22)
    elif sq == 'bl': _sq(s, x - 0.22, y + h - 0.24)
    elif sq == 'br': _sq(s, x + w - 0.24, y + h - 0.24)


def _n(s, d):
    if d.get('n'):
        txt(s, W - M - 0.8, H - 0.52, 0.8, 0.26, f"{int(d['n']):02d}", 8.5, P['mute'], 'rg', 'r')


# ══ เลย์เอาต์ตามรูปอ้างอิง ═════════════════════════════════════════════════

@reg
def pp_cover(prs, d):
    s = page(prs, P['acc'])
    shp(s, 'rect', 8.30, 0, W - 8.30, H, P['bg'])
    _photo(s, d, d.get('pi', 0), 8.30, 0, W - 8.30, 3.90)
    shp(s, 'rect', 8.30, 3.90, W - 8.30, H - 3.90, P['ink'])
    _chrome(s, d, True)
    txt(s, M, 0.90, 3.0, 0.70, d.get('yr', '2570'), 28, P['bg'], 'md')
    _p(s, M, 1.86, 3.4, d['s'], 13.5, mix(P['acc'], P['bg'], 0.76))
    txt(s, M, 2.60, 7.2, 1.8, d['t'], 54, P['bg'], 'md', sp=1.04)
    txt(s, 8.70, 4.26, 3.5, 0.34, d['k'], 14.5, P['bg'], 'md')
    _p(s, 8.70, 4.70, 3.5, d['note'], 12.5, mix(P['ink'], P['bg'], 0.68))
    _tag(s, 8.70, 5.66, d.get('tag', ''), mix(P['ink'], P['acc'], 0.84))


@reg
def pp_stage(prs, d):
    s = page(prs)
    _chrome(s, d); _num(s, d); _n(s, d)
    _tag(s, M, 1.62)
    _h2(s, M, 1.94, d['t1'], d['t2'], 43, 6.6)
    txt(s, M, 4.50, 2.4, 0.56, d.get('yr', '2570'), 21, P['acc'], 'md')
    _p(s, M, 5.16, 5.2, d['note'], 13)
    _photo(s, d, d.get('pi', 1), 6.30, 2.20, 2.90, 2.00, 'tr')
    _photo(s, d, d.get('pi2', 5), 9.50, 2.70, 3.10, 2.70, 'bl')
    _p(s, 7.40, 1.12, 3.0, d.get('k', ''), 13, P['acc'])


@reg
def pp_about(prs, d):
    s = page(prs)
    _chrome(s, d); _num(s, d); _n(s, d)
    _tag(s, M, 1.62)
    _h2(s, M, 1.94, d['t1'], d['t2'], 37, 5.4)
    _photo(s, d, d.get('pi', 2), M, 3.20, 2.70, 2.30, 'br')
    txt(s, 4.00, 3.30, 3.6, 0.52, d['k'], 28, P['ink'], 'md')
    _p(s, 4.00, 4.00, 3.4, d['note'], 13)
    _photo(s, d, d.get('pi2', 6), 7.90, 1.40, 4.70, 2.70, 'bl')
    _p(s, 7.90, 4.40, 4.6, d.get('note2', ''), 13)
    _tag(s, 7.90, 5.40, d.get('tag', ''))


@reg
def pp_vision(prs, d):
    s = page(prs)
    _chrome(s, d); _num(s, d); _n(s, d)
    _tag(s, M, 1.62)
    _h2(s, M, 1.94, d['t1'], d['t2'], 37, 4.6)
    txt(s, M, 3.60, 6.0, 1.3, d['big'], 28, P['ink'], 'md', sp=1.26)
    _p(s, M, 5.10, 5.8, d.get('note', ''), 13)
    _photo(s, d, d.get('pi', 3), 7.80, 1.30, 4.80, 4.00, 'tr')


@reg
def pp_mission(prs, d):
    s = page(prs)
    _chrome(s, d); _num(s, d); _n(s, d)
    _tag(s, M, 1.62)
    _h2(s, M, 1.94, d['t1'], d['t2'], 37, 4.6)
    _photo(s, d, d.get('pi', 4), 5.00, 1.30, 4.00, 2.60, 'br')
    for i, (h_, body) in enumerate(d['items'][:2]):
        y = 4.30 + i * 0.90
        shp(s, 'rect', M, y, 0.74, 0.60, P['acc'] if i == 0 else P['ink'])
        txt(s, M, y, 0.74, 0.60, f'({i + 1:02d})', 9, P['bg'], 'md', 'c', 'm')
        txt(s, M + 0.94, y - 0.02, 4.0, 0.30, h_, 14, P['ink'], 'md')
        _p(s, M + 0.94, y + 0.30, 7.6, body, 12.5)


@reg
def pp_team6(prs, d):
    s = page(prs)
    _chrome(s, d); _num(s, d); _n(s, d)
    _tag(s, M, 1.62)
    _h2(s, M, 1.94, d['t1'], d['t2'], 37, 4.2)
    txt(s, M, 4.10, 4.4, 0.60, d['big'], 33, P['acc'], 'md')
    _p(s, M, 4.86, 4.4, d.get('note', ''), 13)
    gx = 6.00; cw, ch = 2.14, 1.50
    for i, (name, role) in enumerate(d['items'][:6]):
        x = gx + (i % 3) * (cw + 0.10)
        y = 1.20 + (i // 3) * (ch + 0.14)
        _photo(s, d, d.get('pi', 7) + i, x, y, cw, ch)
        shp(s, 'rect', x, y + ch - 0.30, cw, 0.30, P['bg'], a=0.86)
        txt(s, x + 0.10, y + ch - 0.30, cw - 0.20, 0.30, name, 12, P['ink'], 'md', an='m')


@reg
def pp_problem(prs, d):
    s = page(prs)
    _chrome(s, d); _num(s, d); _n(s, d)
    _tag(s, M, 1.62)
    _h2(s, M, 1.94, d['t1'], d['t2'], 37, 4.2)
    _p(s, M, 3.40, 3.8, d['note'], 13)
    _photo(s, d, d.get('pi', 2), 4.70, 1.00, 4.20, 2.20, 'tr')
    _photo(s, d, d.get('pi2', 6), M, 4.40, 3.60, 1.60)
    txt(s, 4.70, 4.20, 5.4, 0.86, d['big'], 48, P['ink'], 'md')
    shp(s, 'rect', 9.40, 3.40, 3.20, 1.86, P['acc'])
    _p(s, 9.66, 3.64, 2.7, d.get('note2', ''), 12.5, mix(P['acc'], P['bg'], 0.80))


@reg
def pp_solution(prs, d):
    s = page(prs)
    _chrome(s, d); _num(s, d); _n(s, d)
    _tag(s, M, 1.62)
    _h2(s, M, 1.94, d['t1'], d['t2'], 37, 5.4)
    for i, t in enumerate(d['items'][:2]):
        y = 3.30 + i * 1.00
        shp(s, 'rect', M, y + 0.06, 0.22, 0.22, P['ink'] if i else P['acc'])
        _p(s, M + 0.46, y, 4.6, t, 13)
    _photo(s, d, d.get('pi', 3), 6.20, 1.20, 6.40, 3.90, 'bl')
    _sq(s, 5.90, 4.70, 0.52)


@reg
def pp_bars(prs, d):
    s = page(prs)
    _chrome(s, d); _num(s, d); _n(s, d)
    _tag(s, M, 1.62)
    _h2(s, M, 1.94, d['t1'], d['t2'], 37, 5.0)
    gx, gy = 5.60, 1.30
    gw, gh = W - M - gx, 3.30
    n = len(d['bars'][:14]); bw = gw / n * 0.62
    mx = max(d['bars'][:14]) or 1
    for i, v in enumerate(d['bars'][:14]):
        x = gx + gw / n * (i + 0.5) - bw / 2
        h = gh * (v / mx)
        shp(s, 'rect', x, gy + gh - h, bw, h, P['acc'])
    ln(s, gx, gy + gh + 0.10, W - M, gy + gh + 0.10, mix(P['bg'], P['ink'], 0.26), 0.8)
    for i, (lab, v) in enumerate(d['foot'][:2]):
        x = gx + i * 3.30
        shp(s, 'rect', x, gy + gh + 0.32, 0.16, 0.16, P['acc'] if i == 0 else P['ink'])
        _p(s, x + 0.30, gy + gh + 0.26, 3.0, f'{lab} {v}', 12.5)
    _p(s, M, 4.30, 4.4, d.get('note', ''), 13)


@reg
def pp_donut(prs, d):
    s = page(prs)
    _chrome(s, d); _num(s, d); _n(s, d)
    _tag(s, M, 1.62)
    _h2(s, M, 1.94, d['t1'], d['t2'], 37, 4.2)
    cx, cy, dia = 2.60, 4.10, 2.00
    a = d['ring']
    ring(s, cx, cy, dia, a[0] / 100, P['ink'], mix(P['bg'], P['ink'], 0.16), 0.26)
    st = (270 + 3.6 * a[0]) % 360
    en = (270 + 3.6 * (a[0] + a[1])) % 360
    shp(s, 'arc', cx - dia / 2, cy - dia / 2, dia, dia, P['acc'], adj=[st * 0.6, en * 0.6, 0.26])
    txt(s, cx - 1.30, cy - 0.92, 0.9, 0.30, f'({a[0]}%)', 8.5, P['ink'], 'rg', 'c', 'm')
    txt(s, cx + 0.56, cy + 0.80, 0.9, 0.30, f'({a[1]}%)', 8.5, P['ink'], 'rg', 'c', 'm')
    txt(s, M, 5.42, 2.6, 0.30, d.get('yr', '2570'), 10, P['acc'], 'md')
    shp(s, 'rect', 5.30, 1.00, W - M - 5.30, H - 1.74, P['acc'])
    _p(s, 5.60, 1.30, 3.0, d.get('note', ''), 12.5, mix(P['acc'], P['bg'], 0.80))
    txt(s, 5.60, 2.60, 6.6, 1.5, d['big'], 54, P['bg'], 'md')


# ══ อีก 10 เลย์เอาต์ ═══════════════════════════════════════════════════════

@reg
def pp_product(prs, d):
    s = page(prs)
    _chrome(s, d); _num(s, d); _n(s, d)
    _tag(s, M, 1.62)
    _h2(s, M, 1.94, d['t1'], d['t2'], 37, 5.0)
    gx = M; cw = (W - M * 2 - 0.36) / 3
    for i in range(3):
        _photo(s, d, d.get('pi', 1) + i, gx + i * (cw + 0.18), 3.20, cw, 1.80,
               'tr' if i == 1 else None)
    for i, t in enumerate(d['items'][:2]):
        x = M + i * 4.40
        shp(s, 'rect', x, 5.26, 0.18, 0.18, P['ink'] if i else P['acc'])
        _p(s, x + 0.36, 5.20, 3.9, t, 12.5)
    txt(s, 8.90, 1.20, 3.7, 0.80, d['big'], 37, P['ink'], 'md')


@reg
def pp_revenue(prs, d):
    s = page(prs)
    _chrome(s, d); _num(s, d); _n(s, d)
    _tag(s, M, 1.62)
    _h2(s, M, 1.94, d['t1'], d['t2'], 37, 4.6)
    txt(s, M, 3.40, 3.6, 0.52, d['big'], 27, P['ink'], 'md')
    _p(s, M, 4.06, 3.8, d.get('note', ''), 13)
    bx, by, bw, bh = 5.10, 1.10, W - M - 5.10, 4.20
    shp(s, 'rect', bx, by, bw, bh, P['ink'])
    vals = d['line'][:12]; mx = max(vals) or 1
    pts = [(bx + 0.40 + i * (bw - 0.90) / (len(vals) - 1),
            by + bh - 0.70 - (bh - 1.40) * (v / mx)) for i, v in enumerate(vals)]
    for a_, b_ in zip(pts, pts[1:]):
        ln(s, a_[0], a_[1], b_[0], b_[1], P['acc'], 1.8)
    hi = max(range(len(vals)), key=lambda i: vals[i])
    ln(s, pts[hi][0], by + 0.50, pts[hi][0], by + bh - 0.60, mix(P['ink'], P['bg'], 0.34), 0.7, dash=True)
    txt(s, pts[hi][0] - 0.80, by + 0.34, 1.6, 0.28, d.get('peak', ''), 9, P['bg'], 'md', 'c')
    _p(s, bx + 0.40, by + bh - 0.52, 3.0, d.get('xlab', ''), 12, mix(P['ink'], P['bg'], 0.60))


@reg
def pp_calendar(prs, d):
    s = page(prs)
    _chrome(s, d); _num(s, d); _n(s, d)
    _tag(s, M, 1.62)
    _h2(s, M, 1.94, d['t1'], d['t2'], 37, 4.6)
    _photo(s, d, d.get('pi', 4), M, 3.30, 3.40, 1.90)
    for i, (dt, body) in enumerate(d['items'][:2]):
        x = M + i * 1.80
        txt(s, x, 5.36, 1.7, 0.30, dt, 13.5, P['ink'], 'md')
    _p(s, M, 5.70, 3.4, d['items'][0][1], 12)
    cx, cy = 5.00, 1.10
    shp(s, 'rect', cx, cy, W - M - cx, 4.30, P['ink'])
    txt(s, cx + 0.30, cy + 0.24, 3.0, 0.32, d.get('month', ''), 11, P['bg'], 'md')
    cw = (W - M - cx - 0.60) / 7
    for r in range(5):
        for c in range(7):
            n_ = r * 7 + c + 1
            if n_ > 31: continue
            x = cx + 0.30 + c * cw; y = cy + 0.80 + r * 0.66
            hot = n_ in d.get('mark', [])
            if hot: shp(s, 'oval', x + cw / 2 - 0.20, y, 0.40, 0.40, P['acc'])
            txt(s, x, y, cw, 0.40, str(n_), 8.5,
                P['bg'] if hot else mix(P['ink'], P['bg'], 0.62), 'md' if hot else 'rg', 'c', 'm')


@reg
def pp_service(prs, d):
    s = page(prs)
    _chrome(s, d); _num(s, d); _n(s, d)
    _tag(s, M, 1.62)
    _h2(s, M, 1.94, d['t1'], d['t2'], 37, 5.0)
    _p(s, M, 3.30, 4.0, d.get('note', ''), 13)
    _photo(s, d, d.get('pi', 5), M, 4.30, 2.20, 1.50, 'tr')
    _photo(s, d, d.get('pi2', 2), 3.20, 3.80, 3.10, 2.00)
    _photo(s, d, d.get('pi3', 6), 6.60, 1.20, 3.20, 2.40, 'bl')
    txt(s, 10.10, 3.90, 2.5, 0.60, d['big'], 28, P['ink'], 'md')
    _p(s, 10.10, 4.60, 2.5, d.get('note2', ''), 12.5)


@reg
def pp_milestone(prs, d):
    s = page(prs)
    _chrome(s, d); _num(s, d); _n(s, d)
    _tag(s, M, 1.62)
    _h2(s, M, 1.94, d['t1'], d['t2'], 37, 5.4)
    _p(s, M, 3.20, 4.6, d.get('note', ''), 13)
    gx, gy, gw, gh = 5.20, 1.30, W - M - 5.20, 3.40
    n = len(d['items'][:4])
    pts = [(gx + i * gw / (n - 1), gy + gh - i * gh / (n - 0.4)) for i in range(n)]
    for a_, b_ in zip(pts, pts[1:]):
        ln(s, a_[0], a_[1], b_[0], b_[1], mix(P['bg'], P['ink'], 0.30), 1.4)
    for i, ((v, lab), (x, y)) in enumerate(zip(d['items'][:4], pts)):
        shp(s, 'rect', x - 0.14, y - 0.14, 0.28, 0.28, P['acc'] if i % 2 == 0 else P['ink'])
        txt(s, x - 0.90, y - 0.62, 1.8, 0.30, v, 13.5, P['ink'], 'md', 'c')
        _p(s, x - 0.90, y + 0.22, 1.8, lab, 7.5)
    txt(s, 9.40, 4.90, 3.2, 0.60, d['big'], 31, P['ink'], 'md')


@reg
def pp_partner(prs, d):
    s = page(prs)
    _chrome(s, d); _num(s, d); _n(s, d)
    _tag(s, M, 1.62)
    _h2(s, M, 1.94, d['t1'], d['t2'], 37, 4.2)
    _p(s, M, 3.60, 4.0, d.get('note', ''), 13)
    _photo(s, d, d.get('pi', 1), 5.20, 1.10, 3.40, 2.00, 'br')
    _photo(s, d, d.get('pi2', 5), 8.90, 1.60, 3.70, 2.20)
    _photo(s, d, d.get('pi3', 3), 5.20, 3.40, 3.40, 2.00)
    txt(s, 8.90, 4.10, 3.5, 0.52, d.get('yr', '2570'), 19, P['acc'], 'md')
    _p(s, 8.90, 4.76, 3.6, d.get('note2', ''), 12.5)


@reg
def pp_table(prs, d):
    s = page(prs)
    _chrome(s, d); _num(s, d); _n(s, d)
    _tag(s, M, 1.62)
    _h2(s, M, 1.94, d['t1'], d['t2'], 37, 7.0)
    tw = W - M * 2; cols = d['colw']; y0 = 3.20
    shp(s, 'rect', M, y0, tw, 0.52, P['ink'])
    cx = M
    for j, (hd, fr) in enumerate(zip(d['head'], cols)):
        txt(s, cx + 0.22, y0, tw * fr - 0.44, 0.52, hd, 13.5, P['bg'], 'md', 'l' if j == 0 else 'r', 'm'); cx += tw * fr
    for i, row in enumerate(d['rows'][:4]):
        y = y0 + 0.52 + i * 0.56
        if i % 2 == 0: shp(s, 'rect', M, y, tw, 0.56, P['panel'])
        cx = M
        for j, (cell, fr) in enumerate(zip(row, cols)):
            txt(s, cx + 0.22, y, tw * fr - 0.44, 0.56, cell, 13.5,
                P['acc'] if j == len(cols) - 1 else P['ink'],
                'md' if j == len(cols) - 1 else 'rg', 'l' if j == 0 else 'r', 'm'); cx += tw * fr
    if d.get('note'): _p(s, M, y0 + 0.52 + len(d['rows'][:4]) * 0.56 + 0.18, 9.6, d['note'], 12.5)


@reg
def pp_steps(prs, d):
    s = page(prs)
    _chrome(s, d); _num(s, d); _n(s, d)
    _tag(s, M, 1.62)
    _h2(s, M, 1.94, d['t1'], d['t2'], 37, 4.2)
    x = 5.60
    n = len(d['items'][:4])
    ln(s, x + 0.19, 1.20, x + 0.19, 1.20 + (n - 1) * 1.16 + 0.38, mix(P['bg'], P['ink'], 0.22), 0.8)
    for i, (h_, body) in enumerate(d['items'][:4]):
        y = 1.20 + i * 1.16
        shp(s, 'rect', x, y, 0.38, 0.38, P['acc'] if i < 2 else P['ink'])
        txt(s, x, y, 0.38, 0.38, f'{i + 1}', 13.5, P['bg'], 'md', 'c', 'm')
        txt(s, x + 0.70, y - 0.02, 6.2, 0.32, h_, 14.5, P['ink'], 'md')
        _p(s, x + 0.70, y + 0.34, 6.1, body, 12.5)
    _p(s, M, 3.80, 4.2, d.get('note', ''), 13)


@reg
def pp_quote(prs, d):
    s = page(prs)
    _chrome(s, d); _n(s, d)
    shp(s, 'rect', 0, 0, 5.60, H, P['ink'])
    _photo(s, d, d.get('pi', 6), 0.50, 1.20, 4.60, 3.00)
    txt(s, 0.50, 4.60, 4.6, 0.34, d['who'], 14.5, P['bg'], 'md')
    _p(s, 0.50, 4.98, 4.6, d['role'], 12.5, mix(P['ink'], P['bg'], 0.62))
    txt(s, 6.30, 1.60, 1.2, 0.9, '"', 54, P['acc'], 'md')
    txt(s, 6.30, 2.50, 5.9, 2.4, d['t'], 28, P['ink'], 'md', sp=1.3)


@reg
def pp_close(prs, d):
    s = page(prs, P['acc'])
    _chrome(s, d, True)
    txt(s, M, 1.90, 8.2, 1.9, d['t'], 54, P['bg'], 'md', sp=1.08)
    _p(s, M, 4.00, 6.0, d.get('note', ''), 13.5, mix(P['acc'], P['bg'], 0.80))
    shp(s, 'rect', 8.90, 1.20, W - M - 8.90, 4.20, P['ink'])
    for i, (lab, v) in enumerate(d['items'][:3]):
        y = 1.60 + i * 1.20
        _p(s, 9.20, y, 3.0, lab, 12.5, mix(P['ink'], P['bg'], 0.60))
        txt(s, 9.20, y + 0.30, 3.1, 0.32, v, 13.5, P['bg'], 'md')
