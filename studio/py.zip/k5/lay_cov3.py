"""ปกชุดที่ 3 — เน้น "ดีไซน์" ไม่ใช่แค่สีกับตัวใหญ่ (2 ต.ค. 2569)

ไอซ์ติว่า "แค่วาง text ใหญ่ๆ ไม่มีดีไซน์หรือ layout อะไรเลย ดูเอามาขายไม่ได้"
สิ่งที่เติมเข้ามาในชุดนี้ (ถอดจากงาน pitch deck ที่คนชื่นชอบบน Behance):
  1 โครงกริดที่มองเห็น  2 ความลึกแบบซ้อนชั้นมีเงา  3 ภาษารูปทรงที่ใช้ซ้ำ
  4 พื้นผิว (hatch / dot / glow)  5 ตัวอักษรโปร่งมีแต่เส้นขอบ + ผสมน้ำหนักในบรรทัดเดียว
  6 ของประกอบเอกสาร (เลขหน้า ดัชนี แท็ก เส้นคั่น)  7 รูปทำดูโอโทนให้เข้าสี ไม่ใช่รูปดิบ
"""
from eng import *
import eng
from lay import L, reg
from lay_cov2 import _fg, _hdr, _arrowbtn
from pptx.util import Pt as _Pt
from pptx.oxml.ns import qn as _qn
from lxml import etree as _et


# ── primitive เพิ่ม ───────────────────────────────────────────────────────
def ghost(s, x, y, w, h, t, sz, c, al='l', an='t', sp=0.95, wt='bd', fam=None, k=0.3):
    """ตัวอักษรโตจาง ๆ เป็นฉากหลัง

    หมายเหตุ: เคยลองทำเป็นตัวโปร่งมีแต่เส้นขอบ (a:ln + a:noFill ใน rPr) XML ถูกต้อง
    แต่ตัวเรนเดอร์ของ PowerPoint ไม่สนใจ a:noFill แล้วถมสีทึบกลับมา เลยใช้สีจางแทน
    """
    return txt(s, x, y, w, h, t, sz, mix(P['bg'], c, k), wt, al, an, sp=sp, fam=fam)


def hatch(s, x, y, w, h, c=None, step=0.17, lw=0.6, a=0.28, ang=1, on=None):
    """ลายเส้นเฉียงถี่ ๆ ใช้เป็นพื้นผิว ไม่ให้พื้นสีแบนโล่ง

    on = สีพื้นที่ลายนี้วางทับ ต้องส่งมาเมื่อวาดบนแผงสี ไม่งั้นมันผสมกับ P['bg']
    แล้วออกมาเข้มเต็มที่จนพาดทับตัวเลขใหญ่
    """
    c = mix(on or P['bg'], c or P['ink'], a)
    mode = eng.vch(2, 4)
    if mode == 1:                                  # จุด
        cols, rows_ = max(2, int(w / (step * 1.7))), max(2, int(h / (step * 1.7)))
        for i in range(cols):
            for j in range(rows_):
                shp(s, 'oval', x + (i + 0.5) * w / cols, y + (j + 0.5) * h / rows_,
                    lw * 0.055, lw * 0.055, c)
        return
    if mode == 2:                                  # เส้นนอนห่าง ๆ
        k = max(2, int(h / (step * 2.2)))
        for j in range(k): ln(s, x, y + (j + 0.5) * h / k, x + w, y + (j + 0.5) * h / k, c, lw)
        return
    if mode == 3: step, ang = step * 1.5, -1       # เฉียงกลับทาง ห่างขึ้น
    n = int((w + h) / step)
    for i in range(n):
        d = i * step
        x1, y1 = x + d, y
        x2, y2 = x, y + d * ang
        if x1 > x + w: y1 += (x1 - (x + w)) / ang; x1 = x + w
        if y2 > y + h: x2 += (y2 - (y + h)) * ang; y2 = y + h
        if x2 > x + w or y1 > y + h: continue
        ln(s, x1, y1, x2, y2, c, lw)


def duo(s, topic, pi, x, y, w, h, geom=None, adj=None, focus=(0.5, 0.4), base=None, tint=None, k=0.44):
    """รูปดูโอโทน: ย้อมให้เข้าสีชุด แทนรูปสต็อกดิบ ๆ

    k ต่ำ = สีเด่น รูปจาง · เคยตั้ง 0.62 แล้วไอซ์ว่าหม่น เพราะรูปเทา ๆ กลบสีไปหมด
    """
    if geom == 'roundRect':      # ทรงกลาง ๆ ที่ไม่ได้บังคับ สลับได้ตาม variant ให้ไม่ซ้ำ
        geom = eng.vpick('roundRect', 'round1Rect', 'snip1Rect', 'round2SameRect', ch=1)
    kind = {'ellipse': 'oval', None: 'rect'}.get(geom, 'round')   # ส่ง geom ให้ตรงรูป ไม่งั้นวงกลมได้กรอบเหลี่ยม
    ad = None if kind == 'oval' else adj
    shp(s, kind, x, y, w, h, base or P['acc'], adj=ad)
    pic(s, ph(topic, pi), x, y, w, h, geom=geom, adj=adj, focus=focus, a=k)
    shp(s, kind, x, y, w, h, tint or P['acc2'], a=0.3, adj=ad)
    shp(s, kind, x, y, w, h, base or P['acc'], a=0.22, adj=ad)


def cells(s, x, y, w, h, items, lab_c=None, val_c=None, line_c=None):
    """แถบข้อมูลล่างแบ่งช่องด้วยเส้นผม แบบเอกสารจริง"""
    items = [it for it in (items or []) if str(it[0]).strip()]
    if not items: return                   # ไม่มีตัวเลขก็ไม่ต้องขีดแถบว่าง
    n = len(items); cw = w / n
    for i, (v, lb) in enumerate(items):
        cx = x + i * cw
        if i: ln(s, cx, y + 0.06, cx, y + h - 0.06, line_c or mix(P['bg'], P['ink'], 0.26), 0.6)
        # 0.55 ให้สีที่เฉียด 4.9 พอดี พอแถบนี้ไปอยู่ใต้เงาการ์ด พื้นเข้มขึ้นนิดเดียวก็ตกเหลือ 4.53
        txt(s, cx + 0.22, y + 0.08, cw - 0.44, 0.26, lb, 8.5, lab_c or tone(P['bg'], 0.72), 'md', track=1.1)
        txt(s, cx + 0.22, y + 0.38, cw - 0.44, 0.44, v, 17, val_c or P['ink'], 'bd')


def _idx(s, x, y, items, c=None, gap=0.46):
    """ดัชนีเลขเล็ก ๆ ไล่ลงข้างซ้าย"""
    c = c or tone(P['bg'], 0.5)
    for i, t in enumerate(items[:4]):
        txt(s, x, y + i * gap, 0.44, 0.3, f'{i + 1:02d}', 9, c, 'bd')
        txt(s, x + 0.5, y + i * gap, 4.0, 0.3, t, 9.5, c)


# ── A. กริดบรรณาธิการ + การ์ดเหลื่อม ──────────────────────────────────────

TTL2 = []

def ttl2(s, x, y, w, t, sz, c, maxh=None, n=3, h=1.32, lo=32, wt1='lt', dry=False, **kw):
    """หัวข้อหลายบรรทัดที่เคยพิมพ์ y ของบรรทัดถัดไปเองแล้วชนกัน

    รุ่นแรกบังคับให้ทุกบรรทัดต้นฉบับอยู่บรรทัดเดียว ผลคือ b01 หัวข้อ 44pt ถูกย่อเหลือ 27pt
    จนปกโล่ง — ที่ต้องคุมจริง ๆ คือความสูงรวม ไม่ใช่จำนวนบรรทัด ปล่อยให้ตัดคำได้
    แล้วค่อยย่อถ้าสูงเกิน maxh จากนั้นคิด y ของบรรทัดถัดไปจากจำนวนบรรทัดที่ตัดจริง
    """
    ls = [v for v in str(t).split('\n') if v.strip()][:n]
    if not ls: return y
    if not dry: TTL2.append(1)               # doc2slide.render ดูว่าหน้านี้ใช้ ttl2 (เว็บปิด Enter ในหัวเรื่อง เพราะแต่ละบรรทัดเป็นกล่องแยก)
    # พื้นหัวข้อปก: ต่ำกว่า lo คือเล็กเกินจะเป็นปก เด็ค 50 ชุดสั่ง tsz มา 26-30
    # ย่อลงได้ถึง lo เท่านั้น และถ้าสั่งมาต่ำกว่า lo อยู่แล้วก็ดันขึ้นให้ถึง
    sz = max(sz, lo)

    def rows(v, size):                      # กี่บรรทัดเมื่อตัดคำในกล่องกว้าง w
        return max(1, -(-int(size * 0.50 * len(v)) // int(72 * w)))   # 0.50em ตรงกับที่ LibreOffice ตัดจริง

    if maxh:
        while sz > lo and sum(rows(v, sz) for v in ls) * sz / 72 * h > maxh: sz -= 1
    lh = sz / 72 * h
    yy = y
    for i, v in enumerate(ls):
        r = rows(v, sz)
        if not dry:                     # dry=True แค่บอกว่าหัวข้อจะจบที่ y เท่าไหร่ ยังไม่วาด
            txt(s, x, yy, w, r * lh + 0.22, v, sz, c,
                'bd' if (i or len(ls) == 1) else wt1, sp=0.96, **kw)
        yy += r * lh
    return yy


def vlabel(s, x, cy, t, sz, c, span=4.4, track=1.5, al='c'):
    """ป้ายตั้งริมข้าง — กล่องต้องยาวพอให้ข้อความอยู่บรรทัดเดียว

    เดิมตรึงกล่องไว้ 3.4" พอ kicker ยาว 36 ตัว ("INDUSTRIAL WASTEWATER QUALITY REPORT")
    มันตัดเป็นสองบรรทัด บรรทัดสองไปโผล่นอกกล่อง ซึ่งหลังหมุน 270 องศาคือหลุดขอบสไลด์
    และไปเฉียดหัวข้อ (e16 g10) · x = ขอบของแถบที่ป้ายจะไปนั่ง, cy = กึ่งกลางแนวตั้ง
    """
    t = str(t or '').strip()
    if not t: return
    while sz > 7 and len(t) * (sz * 0.56 / 72 + track / 72) > span: sz -= 0.5
    h = sz / 72 * 1.5
    tb = txt(s, x + h / 2 - span / 2, cy - h / 2, span, h, t, sz, c, 'md', al, 'm', track=track)
    tb.rotation = 270
    return tb


def subline(s, x, y, w, t, sz, c, limit, h=1.34, lo=9.5, **kw):
    """คำโปรยใต้หัวข้อ ที่ต้องจบก่อน limit เสมอ

    เดิมทุกเลย์เอาต์ตรึง y ของคำโปรยไว้ตายตัว พอหัวข้อถูกบังคับพื้น 32pt แล้วกินลงมา
    คำโปรยก็โดนทับ (q09 q05 h09 h11 g21 ชนกันจริงเห็นในรูป)
    ตัวนี้ย่อคำโปรยลงจนพอดีที่ว่าง ถ้าย่อถึง lo แล้วยังไม่พอก็ไม่วาด ดีกว่าวาดทับกัน
    """
    t = str(t or '').strip()
    if not t or y >= limit: return y
    while sz >= lo:
        rows = max(1, -(-int(sz * 0.50 * len(t)) // int(72 * w)))
        hh = rows * sz / 72 * h
        if y + hh <= limit:
            txt(s, x, y, w, hh + 0.08, t, sz, c, **kw)
            return y + hh
        sz -= 0.5
    return y


@reg
def cv_editorial(prs, d):
    s = page(prs, P['bg'])
    ink = P['ink']
    for i in range(1, 12):                      # กริด 12 คอลัมน์ให้เห็นราง ๆ
        ln(s, 0.7 + i * (W - 1.4) / 12, 0.62, 0.7 + i * (W - 1.4) / 12, H - 0.62,
           mix(P['bg'], ink, 0.07), 0.5)
    ln(s, 0.7, 1.12, W - 0.7, 1.12, mix(P['bg'], ink, 0.5), 0.8)
    ln(s, 0.7, H - 1.02, W - 0.7, H - 1.02, mix(P['bg'], ink, 0.22), 0.6)
    _hdr(s, d.get('foot', ''), '', d.get('k', ''), tone(P['bg'], 0.6))

    duo(s, d['topic'], d.get('pi', 0), 7.05, 1.12, W - 7.05, 4.3, focus=(0.46, 0.4), k=0.52)
    hatch(s, 7.05, 1.12, 1.5, 4.3, 'FFFFFF', 0.13, 0.5, 0.5)
    card(s, 5.55, 3.5, 3.1, 2.12, P['bg'], adj=0.04, shadow=True)
    duo(s, d['topic'], d.get('pi', 0) + 3, 5.7, 3.65, 2.8, 1.82, geom='roundRect', adj=0.04, k=0.5)

    yb = ttl2(s, 0.7, 1.6, 4.85, d['t'], d.get('tsz', 46), ink, maxh=2.5)
    shp(s, 'rect', 0.7, yb + 0.1, 2.4, 0.17, P['acc'])
    vlabel(s, 0.03, 3.15, d.get('k', ''), 9.5, tone(P['bg'], 0.55), span=4.6)
    subline(s, 0.7, max(yb + 0.52, 4.3), 4.5, d.get('s'), 12.5, tone(P['bg'], 0.7), 5.36, sp=1.42)
    shp(s, 'rect', 0, H - 0.58, W, 0.58, P['acc'])
    cells(s, 0.7, 5.42, 4.6, 0.74, (d.get('stats') or [])[:2])
    txt(s, W - 2.0, H - 0.44, 1.3, 0.3, '01 / 20', 10, _fg(P['acc']), 'bd', 'r')
    txt(s, 0.7, H - 0.44, 6.0, 0.3, d.get('foot', ''), 10, _fg(P['acc']), 'md', track=0.9)


# ── B. โปสเตอร์เลขโปร่ง ───────────────────────────────────────────────────
@reg
def cv_outline_poster(prs, d):
    s = page(prs, P['bg'])
    glow(s, W * 0.28, H * 0.22, 5.4, P['acc'], 0.18)   # 0.45 ทำให้พื้นใต้หัวข้อสว่างจนเหลือ 4.70
    hatch(s, 0, H - 2.6, 4.4, 2.6, P['acc2'], 0.2, 0.7, 0.4)
    st = d.get('stats', []) or [('2570', '')]
    # เคยวางเลขลายน้ำ 176pt ไว้ตรงนี้ด้วย ghost() วัดคอนทราสต์ได้ 1.23-1.65 ทุกใบ
    # และมันไปนั่งหลังหัวข้อพอดี (b03 เลข 18 ทับ "เพิ่มยอดขายออนไลน์") เปลี่ยนเป็น
    # วงแหวนเส้น ไม่ใช่ตัวหนังสือ จะได้ไม่ต้องมาเถียงเรื่องคอนทราสต์ของของที่ไม่ได้ให้อ่าน
    # วงแหวนพาดหลังหัวข้อ ความเข้มต้องไม่กินคอนทราสต์ของหัวข้อ (เคยทำหัวข้อขาวเหลือ 4.70)
    rk = 0.5
    while rk > 0.08 and cratio(P['ink'], mix(P['bg'], P['acc'], rk)) < 5.6: rk -= 0.06
    for i, k in enumerate((0.0, 0.5, 1.0)):
        r = 4.6 + k * 1.5
        shp(s, 'oval', 2.5 + (4.6 - r) / 2, 1.0 + (4.6 - r) / 2, r, r, None,
            line=mix(P['bg'], P['acc'], rk * (1 - i * 0.26)), lw=1.4 - i * 0.35)
    # กรอบสีเต็มรอบรูป — ทั้งใบเคยไม่มีบล็อกสีเต็มเกิน 1% (วัดได้ 0.98%)
    shp(s, 'round', 8.22, 0.44, 4.66, 5.56, P['acc'], adj=0.09)
    duo(s, d['topic'], d.get('pi', 1), 8.5, 0.72, 4.1, 5.0, geom='roundRect', adj=0.1,
        base=P['acc'], tint=P['acc2'], k=0.58)
    ln(s, 0.74, 1.2, 7.9, 1.2, mix(P['bg'], P['ink'], 0.4), 0.7)
    pill(s, 0.74, 0.62, 2.5, 0.5, d.get('k', ''), P['acc'], _fg(P['acc']), 10)
    yb = ttl2(s, 0.74, 2.5, 7.3, d['t'], d.get('tsz', 50), P['ink'], maxh=2.3, wt1='bd')
    subline(s, 0.74, max(yb + 0.22, 5.0), 6.6, d.get('s'), 13, tone(P['bg'], 0.72), 5.94, sp=1.42)
    chipc = ink_on(P['acc'], P['bg'])          # P['acc'] ดิบ ๆ บนพื้นอ่อนวัดได้ 2.06
    for i, (v, lb) in enumerate(st[1:4]):
        x = 0.74 + i * 2.5
        shp(s, 'round', x, 6.0, 2.3, 0.6, None, line=P['acc'], lw=1.0, adj=0.5)
        txt(s, x, 6.0, 2.3, 0.6, f'{v}  {lb}', 10.5, chipc, 'md', 'c', 'm')
    txt(s, W - 4.6, H - 0.74, 3.86, 0.3, d.get('foot', ''), 9.5, tone(P['bg'], 0.55), 'rg', 'r', track=0.8)


# ── C. แผงซ้อนสามชั้น ─────────────────────────────────────────────────────
@reg
def cv_stacked(prs, d):
    s = page(prs, P['panel'])
    dots(s, 0.5, 0.5, 26, 14, 0.5, 0.045, mix(P['panel'], P['ink'], 0.3), 0.9)
    # แผ่นล่างสุดเป็นสีเต็ม ไม่ใช่สีผสม — ทั้งใบเคยเหลือบล็อกสีเต็มใหญ่สุดแค่ 0.66%
    shp(s, 'round', 1.42, 1.5, 9.3, 4.5, P['acc'], adj=0.05)
    shp(s, 'round', 1.06, 1.22, 9.3, 4.5, mix(P['panel'], P['acc'], 0.5), adj=0.05)
    card(s, 0.7, 0.94, 9.3, 4.5, P['bg'], adj=0.05, shadow=True)
    txt(s, 1.16, 1.36, 5.0, 0.3, d.get('k', ''), 10, ink_on(P['acc'], P['bg']), 'md', track=1.3)
    yb = ttl2(s, 1.16, 1.86, 7.0, d['t'], d.get('tsz', 44), P['ink'], maxh=1.95, wt1='bd')
    ry = max(3.96, yb + 0.14)                  # เส้นคั่นต้องตามก้นหัวข้อ ไม่ใช่ค่าตรึง
    ln(s, 1.16, ry, 6.1, ry, mix(P['bg'], P['ink'], 0.22), 0.7)
    subline(s, 1.16, ry + 0.2, 6.0, d.get('s'), 12.5, tone(P['bg'], 0.7), 5.40, sp=1.42)
    duo(s, d['topic'], d.get('pi', 2), 8.55, 2.3, 3.5, 3.5, geom='ellipse',
        base=P['acc'], tint=P['acc2'], k=0.6)
    shp(s, 'oval', 8.55, 2.3, 3.5, 3.5, None, line=P['acc'], lw=1.1)
    _arrowbtn(s, 8.3, 5.5, 0.94, P['acc'], 'arrow-up-right', _fg(P['acc']))
    cells(s, 0.7, 6.1, 7.4, 0.82, d.get('stats', [])[:3],
          lab_c=tone(P['panel'], 0.62), val_c=P['ink'],
          line_c=mix(P['panel'], P['ink'], 0.25))
    txt(s, 0.7, H - 0.48, 5.0, 0.26, d.get('foot', ''), 9, tone(P['panel'], 0.5), track=0.8)


# ── D. ดูโอโทนเต็มใบ + แถบข้อมูลเส้นผม ────────────────────────────────────
@reg
def cv_duotone_full(prs, d):
    s = page(prs, P['bg'])
    pic(s, ph(d['topic'], d.get('pi', 3)), 0, 0, W, H, focus=(0.52, 0.38), a=0.42)
    shp(s, 'rect', 0, 0, W, H, P['bg'], a=0.34)
    shp(s, 'rect', 0, 0, W, H, P['acc'], a=0.3)
    gradband(s, 0, H * 0.18, W, H * 0.82, 90, a1=0.0, a2=0.94, c1='08080A', c2='08080A')
    shp(s, 'rect', 0, 2.3, W, H - 2.3, '08080A', a=0.42)   # หัวข้ออยู่ที่ 2.52 ม่านไล่สียังบางตรงนั้น
    hatch(s, W - 3.6, 0, 3.6, 2.8, 'FFFFFF', 0.2, 0.6, 0.45)
    # หัวกระดาษ 8.5pt ขาวบนรูปวัดได้ 1.70 — ปูม่านมืดบนหัวไว้ให้ตัวขาวอ่านออก
    # ม่านไล่สีล้วนยังไม่พอ ตรงตีนตัวอักษรมันจางไปแล้ว (วัดได้ 3.68 ที่ e04)
    # ดำทึบ 0.62 แปลว่าต่อให้รูปขาวสนิทก็ยังได้ 4.5 แล้วค่อยไล่จางลงด้านล่าง
    shp(s, 'rect', 0, 0, W, 0.92, '000000', a=0.62)
    gradband(s, 0, 0.92, W, 0.85, 90, a1=0.62, a2=0.0, c1='000000', c2='000000')
    ln(s, 0.78, 0.62, 0.78, H - 0.62, 'FFFFFF', 0.8)
    # ป้ายตั้งหมุน 270 กินแนวตั้ง 3.4" ถ้าเริ่มที่ 2.6 หัวป้ายจะไปโผล่ที่ y 1.05 ซึ่งม่านยังไม่ถึง
    # (ม่านแบนเริ่ม 2.3 ม่านไล่สีเริ่ม 1.35) ตัวขาวตรงนั้นวัดได้ต่ำกว่า 4.5 ราว 30% ของพิกเซล
    vlabel(s, 0.06, 4.5, d.get('k', ''), 9.5, 'FFFFFF', span=3.6)
    _hdr(s, d.get('foot', ''), '', '01 / 20', 'FFFFFF')
    t = d['t'].split('\n')
    # เดิมตัดที่ t[:2] บรรทัดที่สามของหัวข้อหายไปเงียบ ๆ
    sz, lh = max(32, d.get('tsz', 54)), 0      # 32pt คือพื้นหัวข้อปก เท่ากับ ttl2
    while sz > 32 and sum(max(1, int(sz * 0.58 * len(v) / (72 * 9.2)) + 1) for v in t[:3]) * sz / 72 * 1.32 > 2.0:
        sz -= 1
    lh = sz / 72 * 1.32
    yb = 2.52
    for i, v in enumerate(t[:3]):
        txt(s, 1.3, yb, 9.2, lh + 0.2, v, sz,
            'FFFFFF' if i == 0 else ink_on(P['acc2'], '14161C'), 'lt' if i == 0 else 'bd', sp=0.95)
        yb += lh
    shp(s, 'rect', 1.3, yb + 0.12, 2.2, 0.16, P['acc2'] if _fg(P['acc']) == _fg(P['bg']) else P['acc'])
    subline(s, 1.3, yb + 0.44, 6.4, d.get('s'), 13, 'EEF1F8', 5.78, sp=1.42)
    cells(s, 1.3, 5.84, 10.4, 0.8, d.get('stats', [])[:3],
          lab_c='C9D2E4', val_c='FFFFFF', line_c=mix('FFFFFF', '000000', 0.55))
    # แถบสีเต็มล่างสุด — ไม่มีชิ้นนี้ทั้งใบไม่เหลือสีเต็มเลย (วัดได้ 0.00%)
    shp(s, 'rect', 0, H - 0.62, W, 0.62, P['acc'])
    txt(s, 1.3, H - 0.46, 7.0, 0.3, d.get('foot', ''), 9.5, _fg(P['acc']), 'md', track=0.9)


COV3 = ['cv_editorial', 'cv_outline_poster', 'cv_stacked', 'cv_duotone_full']


# ══ อีก 8 โครง ใช้ภาษาออกแบบเดียวกัน แต่คนละ skeleton ════════════════════

@reg
def cv_rail_left(prs, d):
    """แถบสีเต็มความสูงริมซ้าย + เนื้อหาบนกระดาษ + รูปดูโอโทนมุมขวาล่าง"""
    s = page(prs, P['bg'])
    shp(s, 'rect', 0, 0, 2.5, H, P['acc'])
    hatch(s, 0, H - 3.0, 2.5, 3.0, 'FFFFFF', 0.19, 0.6, 0.5)
    vlabel(s, 0.23, 2.77, d.get('k', ''), 10, _fg(P['acc']), span=4.4)
    txt(s, 1.0, 0.74, 1.0, 0.4, '01', 22, _fg(P['acc']), 'bd')
    for i in range(1, 5):
        ln(s, 2.5 + i * (W - 2.5) / 5, 0.7, 2.5 + i * (W - 2.5) / 5, H - 0.7, mix(P['bg'], P['ink'], 0.07), 0.5)
    ln(s, 3.1, 1.24, W - 0.72, 1.24, mix(P['bg'], P['ink'], 0.45), 0.8)
    txt(s, 3.1, 0.78, 5.4, 0.3, d.get('foot', ''), 9.5, tone(P['bg'], 0.6), 'md', track=1.1)
    yb = ttl2(s, 3.1, 1.7, 5.6, d['t'], d.get('tsz', 44), P['ink'], maxh=2.2)
    shp(s, 'rect', 3.1, yb + 0.08, 2.2, 0.16, P['acc'])
    subline(s, 3.1, yb + 0.44, 5.1, d.get('s'), 12.5, tone(P['bg'], 0.72), 5.64, sp=1.42)
    duo(s, d['topic'], d.get('pi', 4), 8.9, 3.2, 3.72, 3.5, geom='roundRect', adj=0.07)
    cells(s, 3.1, 5.7, 5.2, 0.82, d.get('stats', [])[:2])


@reg
def cv_frame_window(prs, d):
    """กรอบเส้นเต็มใบ + ช่องรูปดูโอโทนกลาง + หัวข้อคร่อมกรอบ"""
    s = page(prs, P['bg'])
    dots(s, 0.4, 0.4, 27, 15, 0.48, 0.04, mix(P['bg'], P['ink'], 0.3), 0.9)
    shp(s, 'rect', 0.62, 0.62, W - 1.24, H - 1.24, None, line=mix(P['bg'], P['ink'], 0.4), lw=1.1)
    duo(s, d['topic'], d.get('pi', 5), 4.3, 1.5, 4.7, 4.5, geom='roundRect', adj=0.05)
    card(s, 0.95, 2.4, 4.3, 3.5, P['bg'], adj=0.05, shadow=True)
    txt(s, 1.26, 2.66, 3.7, 0.3, d.get('k', ''), 10, ink_on(P['acc'], P['bg']), 'md', track=1.2)
    yb = ttl2(s, 1.26, 3.06, 3.7, d['t'], d.get('tsz', 36), P['ink'], maxh=1.8, wt1='bd')
    st = d.get('stats') or []
    if st and str(st[0][0]).strip():
        card(s, 8.1, 3.9, 4.1, 2.2, P['acc'], adj=0.05, shadow=True)
        txt(s, 8.44, 4.16, 3.4, 0.9, st[0][0], fit_sz(st[0][0], 3.4, 50), _fg(P['acc']), 'bd', sp=0.92)
        txt(s, 8.44, 5.28, 3.4, 0.6, st[0][1], 11.5, _fg(P['acc']), sp=1.35)
    if d.get('s'): txt(s, 1.26, yb + 0.16, 3.7, 0.8, d['s'], 11, tone(P['bg'], 0.7), sp=1.38)
    _hdr(s, d.get('foot', ''), '', '01 / 20', tone(P['bg'], 0.55))


@reg
def cv_top_slab(prs, d):
    """แผ่นสีหนาครึ่งบน หัวข้อใหญ่ + การ์ดเหลื่อมลงมาครึ่งล่าง"""
    s = page(prs, P['bg'])
    fg = _fg(P['acc'])
    # เดิมตรึงแผ่นสีไว้ 3.5" และการ์ดที่ 2.96" พอหัวข้อถูกบังคับพื้น 32pt แล้วยาว 3 บรรทัด
    # (1.76" จบที่ 3.18") การ์ดก็ขึ้นมาทับบรรทัดสุดท้ายหายไปครึ่งตัว — เห็นจริง 5 จาก 7 ใบ
    yb0 = ttl2(s, 0.8, 1.42, 8.6, d['t'], d.get('tsz', 50), fg, maxh=1.9, wt1='bd', dry=True)
    cy = max(2.96, yb0 + 0.16)                 # การ์ดเริ่มใต้ก้นหัวข้อเสมอ
    ch = 5.82 - cy                             # และจบก่อนแถบตัวเลขที่ 5.9
    shp(s, 'rect', 0, 0, W, cy + 0.54, P['acc'])
    hatch(s, W - 4.2, 0, 4.2, cy + 0.54, 'FFFFFF', 0.21, 0.6, 0.45)
    pill(s, 0.8, 0.72, 2.3, 0.52, d.get('k', ''), P['bg'], P['ink'], 10.5)
    ttl2(s, 0.8, 1.42, 8.6, d['t'], d.get('tsz', 50), fg, maxh=1.9, wt1='bd')
    card(s, 0.8, cy, 5.4, ch, P['bg'], adj=0.05, shadow=True)
    subline(s, 1.16, cy + 0.34, 4.7, d.get('s'), 13, tone(P['bg'], 0.78), cy + ch - 0.62, sp=1.44)
    ln(s, 1.16, cy + ch - 0.52, 5.84, cy + ch - 0.52, mix(P['bg'], P['ink'], 0.2), 0.7)
    txt(s, 1.16, cy + ch - 0.36, 4.7, 0.3, d.get('foot', ''), 9.5, tone(P['bg'], 0.6), track=0.9)
    duo(s, d['topic'], d.get('pi', 6), 6.6, cy, 5.9, ch, geom='roundRect', adj=0.06)
    cells(s, 0.8, 5.9, 11.7, 0.82, d.get('stats', [])[:3])


@reg
def cv_circle_cut(prs, d):
    """วงกลมรูปใหญ่ชนขอบขวา + หัวข้อซ้าย + วงแหวนซ้อน"""
    s = page(prs, P['bg'])
    shp(s, 'oval', 7.3, -1.5, 7.3, 7.3, mix(P['bg'], P['acc'], 0.16))
    # วงแหวนสีเต็มรอบรูป แทนเส้น 1pt — เส้นบางทำให้ทั้งใบไม่มีบล็อกสีเต็ม (วัดได้ 0.60%)
    shp(s, 'oval', 7.9, -0.9, 6.1, 6.1, P['acc'])
    duo(s, d['topic'], d.get('pi', 7), 8.25, -0.55, 5.4, 5.4, geom='ellipse')
    hatch(s, 0, 4.6, 4.6, 2.9, P['acc'], 0.2, 0.6, 0.5)
    _hdr(s, d.get('foot', ''), d.get('k', ''), '', tone(P['bg'], 0.58))
    ln(s, 0.76, 1.1, 6.9, 1.1, mix(P['bg'], P['ink'], 0.42), 0.8)
    yb = ttl2(s, 0.76, 1.7, 6.2, d['t'], d.get('tsz', 46), P['ink'], maxh=2.3)
    shp(s, 'rect', 0.76, yb + 0.1, 2.3, 0.17, P['acc'])
    subline(s, 0.76, yb + 0.48, 5.6, d.get('s'), 12.5, tone(P['bg'], 0.72), 5.84, sp=1.42)
    _arrowbtn(s, 6.5, 5.1, 0.92, P['acc'], 'arrow-up-right', _fg(P['acc']))
    cells(s, 0.76, 5.9, 6.2, 0.82, d.get('stats', [])[:2])


@reg
def cv_strip_stack(prs, d):
    """สามแถบนอนซ้อนกัน แถบกลางเป็นรูป"""
    s = page(prs, P['bg'])
    shp(s, 'rect', 0, 0, W, 2.3, P['acc'])
    fg = _fg(P['acc'])
    txt(s, 0.8, 0.6, 6.0, 0.3, d.get('k', ''), 10.5, fg, 'md', track=1.3)
    txt(s, 0.8, 1.02, 9.0, 1.1, d['t'].split('\n')[0], d.get('tsz', 46), fg, 'bd', sp=0.95)
    duo(s, d['topic'], d.get('pi', 8), 0, 2.42, W, 2.1)
    rest = '\n'.join(d['t'].split('\n')[1:])
    if rest:
        card(s, 0.8, 2.86, 5.4, 1.24, P['bg'], adj=0.06, shadow=True)
        txt(s, 1.1, 2.86, 4.8, 1.24, rest, d.get('tsz', 46) * 0.62, P['ink'], 'bd', an='m', sp=0.98)
    if d.get('s'): txt(s, 0.8, 4.76, 7.0, 0.9, d['s'], 13, tone(P['bg'], 0.74), sp=1.42)
    ln(s, 0.8, 5.78, W - 0.8, 5.78, mix(P['bg'], P['ink'], 0.26), 0.7)
    cells(s, 0.8, 5.94, 11.7, 0.82, d.get('stats', [])[:3])
    txt(s, W - 2.2, 0.6, 1.4, 0.3, '01 / 20', 9.5, fg, 'rg', 'r')


@reg
def cv_tag_grid(prs, d):
    """หัวข้อซ้าย + ตารางการ์ดสี่ช่องขวา"""
    s = page(prs, P['panel'])
    for i in range(1, 6):
        ln(s, i * W / 6, 0.6, i * W / 6, H - 0.6, mix(P['panel'], P['ink'], 0.07), 0.5)
    _hdr(s, d.get('foot', ''), '', d.get('k', ''), tone(P['panel'], 0.55))
    t = d['t'].split('\n')
    yb = ttl2(s, 0.76, 1.5, 5.4, d['t'], d.get('tsz', 44), P['ink'], maxh=2.3)
    shp(s, 'rect', 0.76, yb + 0.1, 2.1, 0.16, P['acc'])
    subline(s, 0.76, yb + 0.46, 5.0, d.get('s'), 12.5, tone(P['panel'], 0.72), 5.50, sp=1.42)
    _arrowbtn(s, 1.22, 6.0, 0.9, P['acc'], 'arrow-up-right', _fg(P['acc']))
    duo(s, d['topic'], d.get('pi', 9), 6.5, 0.9, 2.9, 2.6, geom='roundRect', adj=0.07)
    st = d.get('stats') or []
    if st and str(st[0][0]).strip():
        card(s, 9.62, 0.9, 3.0, 2.6, P['acc'], adj=0.07)
        txt(s, 9.92, 1.2, 2.4, 0.9, st[0][0], fit_sz(st[0][0], 2.4, 44), _fg(P['acc']), 'bd', sp=0.92)
        txt(s, 9.92, 2.3, 2.4, 0.8, st[0][1], 10.5, _fg(P['acc']), sp=1.3)
    for i, (v, lb) in enumerate(st[1:3]):
        card(s, 6.5 + i * 3.12, 3.72, 2.9, 2.6, P['bg'], adj=0.07)
        txt(s, 6.8 + i * 3.12, 4.02, 2.3, 0.6, v, 26, P['ink'], 'bd')
        txt(s, 6.8 + i * 3.12, 4.68, 2.3, 0.8, lb, 10.5, tone(P['bg'], 0.66), sp=1.3)


@reg
def cv_corner_wedge(prs, d):
    """ลิ่มสีมุมบนขวา + รูปเต็มล่าง + หัวข้อบนกระดาษ"""
    s = page(prs, P['bg'])
    shp(s, 'rect', 7.2, 0, W - 7.2, 2.9, P['acc'])
    shp(s, 'rtri', 5.9, 0, 1.3, 2.9, P['acc'], rot=180)
    hatch(s, 7.2, 0, W - 7.2, 2.9, 'FFFFFF', 0.2, 0.6, 0.5)
    st = d.get('stats', []) or [('', '')]
    txt(s, 7.9, 0.74, 4.4, 0.3, st[0][1], 10, _fg(P['acc']), 'md', track=1.1)
    txt(s, 7.9, 1.1, 4.4, 1.3, st[0][0], fit_sz(st[0][0], 4.4, 58), _fg(P['acc']), 'bd', sp=0.92)
    txt(s, 0.78, 0.74, 5.4, 0.3, d.get('k', ''), 10, ink_on(P['acc'], P['bg']), 'md', track=1.2)
    ln(s, 0.78, 1.14, 5.6, 1.14, mix(P['bg'], P['ink'], 0.42), 0.8)
    yb = ttl2(s, 0.78, 1.52, 5.6, d['t'], d.get('tsz', 42), P['ink'], maxh=1.8, wt1='bd')
    if d.get('s'): txt(s, 0.78, yb + 0.2, 5.4, 0.9, d['s'], 12.5, tone(P['bg'], 0.72), sp=1.42)
    duo(s, d['topic'], d.get('pi', 10), 0.78, 4.5, W - 1.56, 2.2, geom='roundRect', adj=0.045)
    txt(s, 0.78, H - 0.62, 6.0, 0.3, d.get('foot', ''), 9.5, tone(P['bg'], 0.6), track=0.9)


@reg
def cv_photo_card_center(prs, d):
    """การ์ดรูปใหญ่กลางจอ หัวข้อคร่อมบน-ล่าง"""
    s = page(prs, P['acc'])
    hatch(s, 0, 0, W, H, 'FFFFFF', 0.26, 0.5, 0.35)
    fg = _fg(P['acc'])
    txt(s, 0.8, 0.66, 6.0, 0.3, d.get('k', ''), 10.5, fg, 'md', track=1.3)
    txt(s, 0.8, 1.04, 11.0, 1.2, d['t'].split('\n')[0], d.get('tsz', 48), fg, 'lt', sp=0.95)
    card(s, 0.8, 2.36, W - 1.6, 3.0, P['bg'], adj=0.05, shadow=True)
    duo(s, d['topic'], d.get('pi', 11), 0.96, 2.52, 5.3, 2.68, geom='roundRect', adj=0.05, focus=(0.5, 0.4), k=0.48)
    rest = '\n'.join(d['t'].split('\n')[1:])
    if rest: txt(s, 6.6, 2.78, 5.4, 1.2, rest, d.get('tsz', 48) * 0.66, P['ink'], 'bd', sp=0.98)
    if d.get('s'): txt(s, 6.6, 4.0, 5.3, 1.0, d['s'], 12.5, tone(P['bg'], 0.72), sp=1.42)
    cells(s, 0.8, 5.62, 11.7, 0.82, d.get('stats', [])[:3],
          lab_c=ink_on(mix(P['acc'], fg, 0.66), P['acc']), val_c=fg, line_c=mix(P['acc'], fg, 0.35))


COV3 += ['cv_rail_left', 'cv_frame_window', 'cv_top_slab', 'cv_circle_cut',
         'cv_strip_stack', 'cv_tag_grid', 'cv_corner_wedge', 'cv_photo_card_center']
