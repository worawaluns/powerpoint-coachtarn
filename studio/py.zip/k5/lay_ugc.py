"""20 เลย์เอาต์ชุดแฟ้มสะสมผลงาน ฟ้าพาสเทล+ครีม — ลอกโครงจากเทมเพลต UGC Creator Portfolio

พื้นฟ้าพาสเทลกับครีม ลายทางตั้งขาว-ฟ้า แถบเมนูบนสี่ช่อง ประกายดาวสี่แฉก
ม็อกอัปมือถือเรียงแถว กรอบลูกไม้ (เส้นประซ้อน) หัวเรื่องน้ำเงินตัวใหญ่ วลีที่สองสีฟ้าอ่อนกว่า
แทนตัวเขียนลายมือของต้นฉบับด้วยฟอนต์ Athiti ตัวหนา (ฟอนต์ใช้ได้แค่สามตัว)
ตัวหนังสือบนฟ้าพาสเทลใช้น้ำเงินเข้ม 2B3F7A (7.9) ฟ้ากลาง 4A66B8 ใช้บนครีมเท่านั้น (5.05)
"""
from eng import *
import eng
from lay import L, reg
from pptx.enum.chart import XL_LABEL_POSITION

txt = txt_big        # ขนาดขั้นต่ำตามชุด 366 ดู eng.roomy()
chart = chart_big

M = 0.62
PB = 'DCE5F5'          # ฟ้าพาสเทล
CR = 'FBF7EE'
INK = '2B3F7A'
ACC = '4A66B8'
MUTE = '5A6585'
WH = 'FFFFFF'
NAV = ['เกี่ยวกับฉัน', 'ผลงาน', 'นักเรียน', 'แผนพัฒนา']


def _duo(): return "duo:1E2D5C:F1F4FB"


def _photo(s, n, x, y, w, h, geom=None, adj=None, focus=(0.5, 0.35)):
    return pic(s, ph('teach', n), x, y, w, h, geom=geom, adj=adj, focus=focus, mode=_duo())


def _stripes(s, x, y, w, h, a=PB, b=WH, step=0.36):
    shp(s, 'rect', x, y, w, h, b)
    i = 0
    while i * step < w:
        if i % 2 == 0: shp(s, 'rect', x + i * step, y, min(step, w - i * step), h, a)
        i += 1


def _spark(s, cx, cy, sz, c=None):
    c = c or ACC
    shp(s, 'diamond', cx - sz * 0.12, cy - sz / 2, sz * 0.24, sz, c)
    shp(s, 'diamond', cx - sz / 2, cy - sz * 0.12, sz, sz * 0.24, c)


def _nav(s, hi=None):
    cw = (W - M * 2) / 4
    shp(s, 'rect', M, 0.20, W - M * 2, 0.50, CR, line=INK, lw=1)
    for i, t in enumerate(NAV):
        if i: ln(s, M + i * cw, 0.20, M + i * cw, 0.70, INK, 1)
        if hi == i: shp(s, 'rect', M + i * cw, 0.20, cw, 0.50, PB, line=INK, lw=1)
        txt(s, M + i * cw, 0.20, cw, 0.50, t, 11, INK, 'md', 'c', 'm')


def _h(s, x, y, t, sz=44, w=7.0, al='l', c=None):
    """บรรทัดแรกน้ำเงินเข้ม บรรทัดถัดไปฟ้า แทนตัวเขียนลายมือ"""
    lines = t.split('\n')
    runs = [[(ln_, {'c': (c or INK) if i == 0 else ACC})] for i, ln_ in enumerate(lines)]
    txt(s, x, y, w, 2.8, '', sz, c or INK, 'bd', al, sp=1.0, runs=runs)


def _p(s, x, y, w, t, sz=11.5, c=None, al='l'):
    if t: txt(s, x, y, w, 2.0, t, sz, c or MUTE, 'rg', al, sp=1.42)


def _lace(s, x, y, w, h, f=CR):
    shp(s, 'rect', x - 0.14, y - 0.14, w + 0.28, h + 0.28, None, line=ACC, lw=1.4, dash=True)
    shp(s, 'rect', x - 0.06, y - 0.06, w + 0.12, h + 0.12, None, line=ACC, lw=0.8)
    shp(s, 'rect', x, y, w, h, f)


def _phone(s, n, x, y, w, h, focus=(0.5, 0.35)):
    shp(s, 'round', x, y, w, h, '1B1B1F', adj=0.16)
    _photo(s, n, x + 0.07, y + 0.07, w - 0.14, h - 0.14, 'roundRect', 0.14, focus)


def _card(s, x, y, w, h, f=WH):
    return shp(s, 'round', x, y, w, h, f, adj=0.06, shadow=('2B3F7A', 0.10, 10, 3))


# ══ เลย์เอาต์ตามรูปอ้างอิง ═════════════════════════════════════════════════

@reg
def ug_cover(prs, d):
    s = page(prs, PB)
    _nav(s)
    for (x, y, z) in ((2.2, 2.0, 0.6), (10.9, 2.6, 0.45), (3.2, 5.6, 0.35), (11.6, 5.4, 0.5), (6.6, 1.5, 0.3)):
        _spark(s, x, y, z, WH)
    _h(s, 0, 2.35, d['t'], 66, W, 'c')
    txt(s, 0, 4.60, W, 0.50, d.get('s', ''), 18, INK, 'md', 'c')
    txt(s, M, H - 0.65, 5.0, 0.30, d.get('mail', ''), 11, MUTE, 'rg')
    txt(s, W - M - 2.0, H - 0.65, 2.0, 0.30, d.get('yr', '2570'), 11, MUTE, 'rg', 'r')


@reg
def ug_about(prs, d):
    s = page(prs, CR)
    _photo(s, d.get('pi', 0), M, 0.60, 5.00, 6.30, focus=(0.5, 0.25))
    _h(s, 6.10, 0.70, d['t'], 54, 6.6)
    _p(s, 6.10, 2.55, 6.4, d['note'], 13, INK)
    _p(s, 6.10, 4.45, 6.4, d.get('note2', ''), 12.5)


@reg
def ug_lace(prs, d):
    s = page(prs, WH)
    _stripes(s, 0, 0, W, H)
    _lace(s, 1.60, 1.60, W - 3.20, 4.30)
    _h(s, 1.60, 2.00, d['t'], 40, W - 3.20, 'c')
    _p(s, 2.40, 3.85, W - 4.80, d.get('note', ''), 13, MUTE, 'c')
    _spark(s, 1.60, 1.60, 0.70)


@reg
def ug_education(prs, d):
    s = page(prs, CR)
    _h(s, M, 0.55, d['t'], 54, 12.0)
    for i, (name, yr, body) in enumerate(d['items'][:2]):
        x = M + i * 6.10
        txt(s, x, 2.70, 3.9, 0.60, name, 24, ACC, 'bd')
        txt(s, x + 3.90, 2.82, 1.9, 0.40, yr, 13, ACC, 'md', 'r')
        _p(s, x, 3.50, 5.6, body, 12.5)
    _spark(s, 12.30, 1.10, 0.55)


@reg
def ug_skills(prs, d):
    s = page(prs, PB)
    _photo(s, d.get('pi', 2), M, 0.70, 5.40, 3.80, focus=(0.5, 0.3))
    shp(s, 'rect', M, 0.70, 5.40, 3.80, None, line=WH, lw=8)
    _h(s, 6.40, 0.80, d['t'], 48, 6.4)
    _p(s, 6.40, 2.75, 6.2, d.get('note', ''), 12.5, INK)
    for i, t in enumerate(d['items'][:4]):
        x = M + (i % 2) * 2.75
        y = 4.90 + (i // 2) * 0.95
        shp(s, 'round', x, y, 2.55, 0.75, WH, adj=0.2)
        txt(s, x, y, 2.55, 0.75, t, 13, INK, 'md', 'c', 'm')


@reg
def ug_stats(prs, d):
    s = page(prs, CR)
    shp(s, 'rect', 0, 0.75, W, 1.30, PB)
    n = len(d['items'][:4]); cw = W / n
    for i, (v, lab) in enumerate(d['items'][:4]):
        txt(s, i * cw, 0.80, cw, 0.70, v, 30, INK, 'bd', 'c')
        txt(s, i * cw, 1.48, cw, 0.40, lab, 12, INK, 'md', 'c')
    _h(s, M, 2.45, d['t'], 48, 6.0)
    for i, (n_, cap) in enumerate(d['phones'][:3]):
        x = 4.40 + i * 2.10
        _phone(s, n_, x, 3.10, 1.80, 3.70)
        txt(s, x - 0.10, 6.88, 2.0, 0.40, cap, 11, INK, 'md', 'c')
    _h(s, 10.80, 5.50, d.get('t2', ''), 30, 2.4)


@reg
def ug_clients(prs, d):
    s = page(prs, PB)
    _h(s, M, 0.55, d['t'], 54, 6.0)
    for i, (n, cap) in enumerate(d['phones'][:3]):
        x = M + i * 2.20
        _phone(s, n, x, 2.70, 1.80, 3.60)
        txt(s, x - 0.10, 6.40, 2.10, 0.40, cap, 11, INK, 'md', 'c')
    _p(s, 7.60, 2.20, 5.1, d.get('note', ''), 13, INK)
    for i, t in enumerate(d.get('tags', [])[:4]):
        x = 7.60 + (i % 2) * 2.60
        y = 4.40 + (i // 2) * 0.90
        shp(s, 'round', x, y, 2.40, 0.62, WH, adj=0.5)
        txt(s, x, y, 2.40, 0.62, t, 12.5, INK, 'bd', 'c', 'm')


@reg
def ug_photos(prs, d):
    s = page(prs, CR)
    _h(s, M, 0.55, d['t'], 44, 3.3)
    spec = [(M, 2.45, 3.20, 4.45), (3.95, 0.60, 3.00, 3.05), (3.95, 3.85, 3.00, 3.05), (7.15, 0.60, 3.00, 6.30)]
    for (x, y, w, h), n in zip(spec, d.get('pis', [3, 4, 5, 6])):
        _photo(s, n, x, y, w, h, focus=(0.5, 0.4))
    _p(s, 10.45, 1.20, 2.3, d.get('note', ''), 12, INK)
    for (x, y, z) in ((11.6, 4.3, 0.5), (10.9, 5.6, 0.35)):
        _spark(s, x, y, z)


@reg
def ug_videos(prs, d):
    s = page(prs, PB)
    _h(s, M, 0.45, d['t'], 50, 9.0)
    n = len(d['phones'][:5]); cw = 2.10; gap = 0.30
    x0 = (W - n * cw - (n - 1) * gap) / 2
    for i, (p, cap) in enumerate(d['phones'][:5]):
        x = x0 + i * (cw + gap)
        _phone(s, p, x, 1.80, cw, 4.30)
        txt(s, x - 0.10, 6.25, cw + 0.2, 0.60, cap, 11.5, INK, 'md', 'c', sp=1.1)


@reg
def ug_projects(prs, d):
    s = page(prs, WH)
    _stripes(s, 0, 0, 7.00, H)
    _h(s, M, 0.90, d['k'], 32, 6.0)
    txt(s, M, 3.60, 6.0, 2.4, d['t'], 60, ACC, 'bd', sp=0.95)
    for i, n in enumerate(d.get('pis', [7, 8, 9, 10])[:4]):
        x = 7.40 + (i % 2) * 2.85
        y = 0.60 + (i // 2) * 3.25
        p = _photo(s, n, x, y, 2.65, 3.05, focus=(0.5, 0.35))
        p.rotation = (-4, 3, 2, -3)[i]


@reg
def ug_testimonials(prs, d):
    s = page(prs, PB)
    _h(s, 0, 0.45, d['t'], 48, W, 'c')
    cw = (W - M * 2 - 0.50) / 3
    for i, (n, who, quote) in enumerate(d['items'][:3]):
        x = M + i * (cw + 0.25)
        _photo(s, n, x, 1.65, cw, 2.40, focus=(0.5, 0.35))
        txt(s, x, 4.20, cw, 0.40, who, 15, INK, 'bd')
        _p(s, x, 4.70, cw, quote, 11.5, INK)


@reg
def ug_services(prs, d):
    s = page(prs, CR)
    _spark(s, 4.20, 1.10, 0.36)
    _h(s, 4.70, 0.60, d['t'], 50, 5.0)
    for i, t in enumerate(d['items'][:8]):
        y = 2.45 + i * 0.54
        shp(s, 'oval', 4.75, y + 0.15, 0.12, 0.12, INK)
        txt(s, 5.05, y, 4.6, 0.45, t, 13, INK, 'md')
    _photo(s, d.get('pi', 11), 9.80, 1.80, 2.90, 4.40, focus=(0.5, 0.35))
    _p(s, 4.75, 6.85, 8.0, d.get('note', ''), 11)


@reg
def ug_close(prs, d):
    s = page(prs, WH)
    _stripes(s, 0, 0, W, H)
    _h(s, 0, 1.50, d['t'], 64, W, 'c')
    shp(s, 'rect', W / 2 - 1.60, 5.10, 3.20, 0.60, CR, line=INK, lw=1)
    txt(s, W / 2 - 1.60, 5.10, 3.20, 0.60, d.get('cta', ''), 14, INK, 'md', 'c', 'm')
    for (x, y, z) in ((2.0, 1.2, 0.55), (11.4, 1.6, 0.45), (2.6, 5.9, 0.4), (11.0, 6.2, 0.5)):
        _spark(s, x, y, z)


# ══ อีก 7 เลย์เอาต์ในระบบเดียวกัน ═════════════════════════════════════════

@reg
def ug_toc(prs, d):
    s = page(prs, CR)
    _nav(s)
    _h(s, M, 1.10, d['t'], 50, 5.0)
    _photo(s, d.get('pi', 1), M, 3.20, 4.40, 3.70, focus=(0.5, 0.35))
    for i, t in enumerate(d['items'][:6]):
        y = 1.15 + i * 0.95
        _spark(s, 5.90, y + 0.30, 0.34)
        txt(s, 6.30, y, 6.4, 0.60, t, 18, INK, 'md', an='m')
        ln(s, 6.30, y + 0.80, W - M, y + 0.80, PB, 1.2)


@reg
def ug_chart_score(prs, d):
    s = page(prs, CR)
    _h(s, M, 0.55, d['t'], 44, 5.0)
    _p(s, M, 2.40, 4.4, d.get('note', ''), 12)
    for i, (v, lab) in enumerate(d['items'][:2]):
        y = 4.15 + i * 1.40
        _card(s, M, y, 4.40, 1.20, PB)
        txt(s, M + 0.30, y, 1.9, 1.20, v, 30, INK, 'bd', an='m')
        _p(s, M + 2.20, y + 0.30, 2.1, lab, 10.5, INK)
    _card(s, 5.50, 0.60, W - M - 5.50, 6.30)
    chart(s, 'col', 5.70, 0.80, W - M - 5.90, 5.90, d['cats'], d['series'], ['A9BBE3', ACC], labels=True,
          fmt='0.0', legend=True, gap=60, overlap=-10, sz=12, c=INK)


@reg
def ug_chart_pass(prs, d):
    s = page(prs, PB)
    _h(s, M, 0.55, d['t'], 44, 8.0)
    _card(s, M, 2.00, 8.20, 4.90)
    chart(s, 'line', M + 0.20, 2.20, 7.80, 4.50, d['cats'], [(d['sname'], d['vals'])], [ACC], labels=True,
          fmt='0"%"', sz=11, c=INK, lw=3, minv=0, maxv=100, lblpos=XL_LABEL_POSITION.ABOVE)
    for i, (v, lab) in enumerate(d['items'][:3]):
        y = 2.00 + i * 1.66
        _card(s, 9.10, y, W - M - 9.10, 1.48, CR)
        txt(s, 9.35, y + 0.12, 3.2, 0.60, v, 26, INK, 'bd')
        _p(s, 9.35, y + 0.78, 3.2, lab, 10.5, INK)


@reg
def ug_hours(prs, d):
    s = page(prs, CR)
    _h(s, M, 0.55, d['t'], 44, 7.0)
    cols = [INK, ACC, 'A9BBE3', PB]
    it = d['items'][:4]
    chart(s, 'donut', 0.60, 2.10, 4.70, 4.70, [x[0] for x in it], [('ชั่วโมง', [x[1] for x in it])], cols, labels=False, hole=60)
    txt(s, 0.60, 4.05, 4.70, 0.60, d['big'], 28, INK, 'bd', 'c')
    txt(s, 0.60, 4.65, 4.70, 0.30, d['biglab'], 10.5, MUTE, 'rg', 'c')
    for i, (lab, v, body) in enumerate(it):
        y = 2.15 + i * 1.20
        _card(s, 5.85, y, W - M - 5.85, 1.04)
        shp(s, 'rect', 6.10, y + 0.38, 0.28, 0.28, cols[i], line=INK if i == 3 else None, lw=0.8)
        txt(s, 6.60, y + 0.12, 4.0, 0.40, lab, 14, INK, 'bd')
        _p(s, 6.60, y + 0.55, 4.4, body, 10.5)
        txt(s, 10.80, y + 0.12, 1.70, 0.80, f'{v} ชม.', 18, ACC, 'bd', 'r', 'm')


@reg
def ug_table(prs, d):
    s = page(prs, WH)
    _stripes(s, 0, 0, W, 0.80)
    _h(s, M, 1.00, d['t'], 40, 9.0)
    cols = d['colw']; tw = W - M * 2; y0 = 2.20; rh = 0.80
    xs = [M]
    for f in cols[:-1]: xs.append(xs[-1] + tw * f)
    shp(s, 'rect', M, y0, tw, 0.60, INK)
    for j, hd in enumerate(d['head']):
        txt(s, xs[j] + 0.22, y0, tw * cols[j] - 0.44, 0.60, hd, 12, WH, 'md', 'l' if j == 0 else 'c', 'm')
    for i, row in enumerate(d['rows']):
        y = y0 + 0.60 + i * rh
        shp(s, 'rect', M, y, tw, rh, CR if i % 2 == 0 else PB)
        for j, cell in enumerate(row):
            txt(s, xs[j] + 0.22, y, tw * cols[j] - 0.44, rh, cell, 12.5 if j == 0 else 12, INK,
                'bd' if j == 0 else 'rg', 'l' if j == 0 else 'c', 'm')


@reg
def ug_plan(prs, d):
    s = page(prs, PB)
    _nav(s, 3)
    _h(s, M, 1.10, d['t'], 46, 9.0)
    n = len(d['items'][:3]); cw = (W - M * 2 - 0.50) / n
    for i, (when, h_, body) in enumerate(d['items'][:3]):
        x = M + i * (cw + 0.25)
        _lace(s, x + 0.14, 2.90, cw - 0.28, 3.70, CR if i != 1 else WH)
        _spark(s, x + 0.55, 3.35, 0.40)
        txt(s, x + 0.95, 3.15, cw - 1.2, 0.40, when, 13, ACC, 'bd')
        txt(s, x + 0.40, 3.75, cw - 0.8, 0.80, h_, 17, INK, 'bd', sp=1.05)
        _p(s, x + 0.40, 4.65, cw - 0.8, body, 11.5)


@reg
def ug_div(prs, d):
    s = page(prs, WH)
    _stripes(s, 0, 0, 6.40, H)
    _photo(s, d.get('pi', 13), 6.80, 0.60, W - M - 6.80, 6.30, focus=(0.5, 0.35))
    _lace(s, 0.90, 2.10, 5.00, 3.20)
    txt(s, 1.20, 2.35, 4.4, 0.40, d.get('k', ''), 13, ACC, 'md')
    _h(s, 1.20, 2.80, d['t'], 42, 4.5)
