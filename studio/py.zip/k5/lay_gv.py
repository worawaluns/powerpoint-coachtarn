"""20 เลย์เอาต์ตระกูลรายงานครู (ชุด 11 grades + ชุด 35 vpa) โมดูลเดียว สองพาเลตต์ — ใบงาน 021

ต้นฉบับ: .pptx ใน slides-k5/out-old/ (11 รายงานผลการเรียน, 35 นำเสนอผลงาน ว.PA) ไม่มีโค้ดเดิม ชุด map (14) ตระกูลเดียวกัน
พื้นขาว หัวเรื่องหนากึ่งกลาง การ์ดเทาม่วงอ่อน กล่องกรมท่าเข้มสรุป หน้าคั่นแผงสีครึ่งซ้ายมีวงกลมขาวใส่ไอคอน
สีหลัก (acc) = สีของชุด / acc2 = สีรอง (เขียวมะนาว / ทอง) ใช้ตัวกรมท่าบน acc2 เสมอ
ต้นฉบับมีเลข 01-05 ตกแต่งที่สารบัญ ขั้นตอน การ์ด → ตัดออก ใช้จุด/แถบสีแทน (กฎไอซ์)
ทุกข้อความมาจาก d ไม่มีค่าตั้งต้นที่เป็นคำ
"""
from eng import *
import eng
from lay import L, reg

txt = txt_big
chart = chart_big

# acc เขียวต้นฉบับ 10C78A ตัวขาวไม่ผ่าน → 0B7A55 (5.3) / น้ำเงิน 3F4FB8 (7.0)
eng.PAL.setdefault('gv_forest', dict(bg='FFFFFF', ink='1E2350', mute='667085', acc='0B7A55', acc2='8CC63E',
                                     g1='0B7A55', g2='8CC63E', dark=0, panel='F4F5FB'))
eng.PAL.setdefault('gv_navygold', dict(bg='FFFFFF', ink='1E2350', mute='667085', acc='3F4FB8', acc2='E0B23A',
                                       g1='3F4FB8', g2='E0B23A', dark=0, panel='F4F5FB'))

M = 0.70
NAVY = '1E2350'
MU = '667085'
CARD = 'F4F5FB'
WH = 'FFFFFF'
LINE = 'E3E5EF'


def A(): return P['acc']
def B(): return P['acc2']
def T(): return mix(P['acc'], WH, 0.88)                    # พื้นอ่อนของสีชุด


def _duo(): return f"duo:{mix(NAVY, A(), 0.35)}:{mix(WH, A(), 0.10)}"


def _photo(s, d, n, x, y, w, h, focus=(0.5, 0.4), geom='roundRect', adj=0.06):
    return pic(s, ph(d['topic'], n), x, y, w, h, focus=focus, mode=_duo(), geom=geom, adj=adj)


def _hd(s, d, y=0.50):
    txt(s, M, y, W - M * 2, 0.70, d['t'], 28, NAVY, 'bd', 'c')
    if d.get('s'): txt(s, 2.0, y + 0.70, W - 4.0, 0.46, d['s'], 13, MU, 'rg', 'c')


def _p(s, x, y, w, t, sz=12.5, c=MU, h=1.0, al='l'):
    if t: txt(s, x, y, w, h, t, sz, c, 'rg', al, sp=1.25)


def _card(s, x, y, w, h, f=CARD, adj=0.08):
    return shp(s, 'round', x, y, w, h, f, adj=adj)


# ══ ปก / สารบัญ / คั่น / ข้อความ / ปิด ═══════════════════════════════════

@reg
def gv_cover(prs, d):
    s = page(prs, WH)
    txt(s, M, 1.10, 6.2, 2.4, d['t'], d.get('tsz', 40), NAVY, 'bd', sp=1.1)
    shp(s, 'rect', M, 3.70, 1.60, 0.10, B())
    _card(s, 7.50, 0.70, W - M - 7.50, 3.30, A(), 0.06)
    shp(s, 'oval', W - M - 1.60, 0.95, 1.20, 1.20, WH, a=0.14)
    if d.get('s'): txt(s, 7.90, 1.20, W - M - 8.40, 2.50, d['s'], 20, WH, 'md', an='b', sp=1.2)   # ต้นฉบับวางตัวเลขเด่นในการ์ดสี
    _photo(s, d, d.get('pi', 0), 7.50, 4.25, W - M - 7.50, 2.55)


@reg
def gv_agenda(prs, d):
    s = page(prs, WH)
    _hd(s, d)
    it = d['items'][:6]
    rh = min(0.86, 4.9 / max(len(it), 1))
    for i, t in enumerate(it):
        y = 1.95 + i * rh
        shp(s, 'oval', M + 0.10, y + rh / 2 - 0.16, 0.24, 0.24, A() if i % 2 == 0 else B())
        txt(s, M + 0.60, y, 6.6, rh - 0.10, t, 17, NAVY, 'md', an='m')
        ln(s, M + 0.60, y + rh - 0.04, 7.80, y + rh - 0.04, LINE, 0.8)
    _card(s, 8.50, 1.95, W - M - 8.50, 4.80, CARD, 0.06)
    cx = 8.50 + (W - M - 8.50) / 2
    shp(s, 'oval', cx - 0.70, 2.55, 1.40, 1.40, A())
    icon(s, 'graduation-cap', cx, 3.25, 0.70, WH)
    _p(s, 8.80, 4.35, W - M - 9.10, d.get('note', ''), 13, NAVY, h=2.1, al='c')


@reg
def gv_div_circle(prs, d):
    s = page(prs, WH)
    shp(s, 'rect', 0, 0, 4.60, H, A())
    shp(s, 'oval', -1.0, H - 2.0, 3.0, 3.0, WH, a=0.10)
    shp(s, 'oval', 2.10, H / 2 - 1.45, 2.90, 2.90, WH)
    icon(s, 'book-open', 3.55, H / 2, 1.30, A())
    txt(s, 5.80, 2.50, W - M - 5.80, 1.80, d['t'], 40, NAVY, 'bd', sp=1.1)
    _p(s, 5.80, 4.40, W - M - 5.80, d.get('s', ''), 15, MU, h=1.5)


@reg
def gv_div_band(prs, d):
    s = page(prs, WH)
    shp(s, 'rect', 0, 0, W, H, A())
    shp(s, 'oval', W - 4.6, H / 2 - 2.3, 4.6, 4.6, WH, a=0.10)
    shp(s, 'oval', W - 3.9, H / 2 - 1.6, 3.2, 3.2, WH)
    icon(s, 'bar-chart-3', W - 2.3, H / 2, 1.30, A())
    txt(s, M + 0.3, 2.40, 7.6, 1.8, d['t'], 40, WH, 'bd', sp=1.1)
    _p(s, M + 0.3, 4.35, 7.2, d.get('s', ''), 15, WH, h=1.5)


@reg
def gv_statement(prs, d):
    s = page(prs, WH)
    shp(s, 'rect', 0, 3.90, W, H - 3.90, T())
    shp(s, 'tri', W / 2 - 1.6, 3.90, 3.2, 1.6, WH, rot=180)
    txt(s, M + 0.5, 1.10, W - M * 2 - 1.0, 2.40, d['t'], 32, NAVY, 'bd', 'c', 'm', sp=1.15)
    _p(s, 2.0, 5.55, W - 4.0, d.get('s', ''), 15, NAVY, h=1.4, al='c')


@reg
def gv_close(prs, d):
    s = page(prs, WH)
    shp(s, 'rect', 8.70, 0, W - 8.70, H, A())
    shp(s, 'oval', W - 1.9, -0.9, 2.6, 2.6, WH, a=0.12)
    txt(s, 9.20, 2.70, W - 9.60, 1.20, d['t'], 40, WH, 'bd')
    _p(s, 9.20, 3.95, W - 9.60, d.get('s', ''), 14, WH, h=1.8)
    _photo(s, d, d.get('pi', 9), M, 0.90, 7.30, 5.70)


# ══ ตัวเลข ═════════════════════════════════════════════════════════════════

@reg
def gv_answer(prs, d):
    """คำตอบก่อน: แถบกรมท่าสรุป + การ์ดตัวเลขสามใบต่อสายจากแถบ"""
    s = page(prs, WH)
    _hd(s, {'t': d['t']})
    shp(s, 'round', 2.4, 1.50, W - 4.8, 0.95, NAVY, adj=0.18)
    shp(s, 'oval', 2.65, 1.70, 0.55, 0.55, B())
    txt(s, 3.40, 1.50, W - 6.1, 0.95, d.get('s', ''), 15, WH, 'md', an='m', sp=1.15)
    it = d['items'][:3]; n = max(len(it), 1)
    gap = 0.30; cw = (W - M * 2 - gap * (n - 1)) / n
    ln(s, W / 2, 2.45, W / 2, 2.85, LINE, 1.2)
    if n > 1: ln(s, M + cw / 2, 2.85, W - M - cw / 2, 2.85, LINE, 1.2)
    for i, (v, lab) in enumerate(it):
        x = M + i * (cw + gap)
        ln(s, x + cw / 2, 2.85, x + cw / 2, 3.20, LINE, 1.2)
        _card(s, x, 3.20, cw, 3.40)
        txt(s, x + 0.2, 3.65, cw - 0.4, 1.0, v, 40, A() if i % 2 == 0 else NAVY, 'bd', 'c')
        _p(s, x + 0.3, 4.85, cw - 0.6, lab, 14, NAVY, h=1.5, al='c')


@reg
def gv_kpi4(prs, d):
    s = page(prs, WH)
    _hd(s, d)
    it = d['items'][:4]; n = max(len(it), 1)
    gap = 0.26; cw = (W - M * 2 - gap * (n - 1)) / n
    for i, (v, lab) in enumerate(it):
        x = M + i * (cw + gap)
        _card(s, x, 2.10, cw, 4.50, WH)
        shp(s, 'round', x, 2.10, cw, 4.50, None, line=LINE, adj=0.08)
        shp(s, 'oval', x + 0.35, 2.50, 0.62, 0.62, A() if i % 2 == 0 else B())
        txt(s, x + 0.35, 3.45, cw - 0.7, 0.90, v, 34, NAVY, 'bd')
        _p(s, x + 0.35, 4.50, cw - 0.7, lab, 13.5, MU, h=1.9)


# ══ กราฟจริง ═══════════════════════════════════════════════════════════════

@reg
def gv_chart_col(prs, d):
    s = page(prs, WH)
    _hd(s, d)
    n = len(d['vals']); side = d.get('items') or []
    w = 8.6 if side else W - M * 2
    chart(s, 'col', M, 1.95, w, 4.85, d['cats'], [(d.get('sname', ''), d['vals'])], [A() if i % 2 == 0 else B() for i in range(n)],
          labels=True, fmt='#,##0.##', gap=50, sz=12, c=NAVY, vary=True)
    for i, (v, lab) in enumerate(side[:3]):
        y = 2.05 + i * 1.60
        _card(s, 9.70, y, W - M - 9.70, 1.40)
        txt(s, 9.95, y + 0.15, 2.6, 0.30, lab, 12, MU, 'rg')
        txt(s, 9.95, y + 0.50, 2.6, 0.70, v, 28, A(), 'bd')


@reg
def gv_chart_line(prs, d):
    s = page(prs, WH)
    _hd(s, d)
    ser = d['series']
    cols = [A(), B(), NAVY, MU][:len(ser)]
    chart(s, 'line', M, 1.95, W - M * 2, 4.85, d['cats'], ser, cols, labels=False, fmt='#,##0.##', legend=len(ser) > 1, sz=12, c=NAVY, grid=True, lw=3)


@reg
def gv_chart_bar(prs, d):
    s = page(prs, WH)
    _hd(s, d)
    ser = d['series']
    w = 8.4 if d.get('note') else W - M * 2
    chart(s, 'bar', M, 1.95, w, 4.85, d['cats'], ser, [mix(A(), WH, 0.70), A(), B(), NAVY][:len(ser)] if len(ser) > 1 else [A()],
          labels=True, fmt='#,##0.##', legend=len(ser) > 1, gap=45, sz=12, c=NAVY)
    if d.get('note'):
        _card(s, 9.50, 2.10, W - M - 9.50, 4.50, A(), 0.06)
        _p(s, 9.80, 2.45, W - M - 10.10, d['note'], 15, WH, h=3.9)


# ══ หัวข้อคู่คำอธิบาย / ลำดับ / รายการ ════════════════════════════════════

@reg
def gv_groups3(prs, d):
    s = page(prs, WH)
    _hd(s, d)
    it = d['items'][:3]; n = max(len(it), 1)
    gap = 0.26; cw = (W - M * 2 - gap * (n - 1)) / n
    tints = [mix(A(), WH, 0.88), mix(B(), WH, 0.82), CARD]
    for i, (h_, body) in enumerate(it):
        x = M + i * (cw + gap)
        _card(s, x, 2.05, cw, 4.65, tints[i % 3], 0.05)
        shp(s, 'rect', x + 0.35, 2.40, 0.50, 0.08, A() if i != 1 else NAVY)
        txt(s, x + 0.35, 2.65, cw - 0.7, 0.80, h_, 18, NAVY, 'bd', sp=1.1)
        _p(s, x + 0.35, 3.55, cw - 0.7, body, 13.5, NAVY, h=2.9)


@reg
def gv_compare2(prs, d):
    s = page(prs, WH)
    _hd(s, d)
    cw = (W - M * 2 - 0.40) / 2
    for i, (h_, lst) in enumerate(d['items'][:2]):
        x = M + i * (cw + 0.40); f = mix(A(), WH, 0.88) if i == 0 else mix(B(), WH, 0.82)
        _card(s, x, 2.05, cw, 4.65, f, 0.05)
        shp(s, 'oval', x + 0.35, 2.35, 0.60, 0.60, A() if i == 0 else NAVY)
        icon(s, 'check' if i == 0 else 'target', x + 0.65, 2.65, 0.32, WH)
        txt(s, x + 1.15, 2.35, cw - 1.5, 0.60, h_, 18, NAVY, 'bd', an='m')
        for j, t in enumerate(lst[:5]):
            y = 3.25 + j * 0.66
            ln(s, x + 0.35, y + 0.58, x + cw - 0.35, y + 0.58, WH, 1.2)
            txt(s, x + 0.35, y, cw - 0.7, 0.56, t, 14, NAVY, 'rg', an='m')


@reg
def gv_channels(prs, d):
    s = page(prs, WH)
    _hd(s, d)
    it = d['items'][:5]
    rh = min(1.10, 4.8 / max(len(it), 1))
    for i, (h_, body) in enumerate(it):
        y = 1.95 + i * rh
        shp(s, 'oval', M, y + (rh - 0.70) / 2, 0.70, 0.70, A() if i % 2 == 0 else B())
        _card(s, M + 0.95, y + 0.06, W - M * 2 - 0.95, rh - 0.16, CARD, 0.14)
        txt(s, M + 1.20, y + 0.06, 2.80, rh - 0.16, h_, 15, A() if i % 2 == 0 else NAVY, 'bd', an='m')
        txt(s, M + 4.10, y + 0.06, W - M * 2 - 4.40, rh - 0.16, body, 13.5, NAVY, 'rg', an='m')


@reg
def gv_timeline(prs, d):
    s = page(prs, WH)
    _hd(s, d)
    it = d['items'][:5]; n = max(len(it), 1)
    y0 = 4.30; cw = (W - M * 2) / n
    ln(s, M, y0, W - M, y0, LINE, 3)
    for i, (per, h_, body) in enumerate(it):
        cx = M + cw * (i + 0.5); up = i % 2 == 0
        shp(s, 'oval', cx - 0.22, y0 - 0.22, 0.44, 0.44, WH, line=A() if up else B(), lw=4)
        txt(s, cx - cw / 2, y0 + (0.35 if up else -0.70), cw, 0.34, per, 14, A() if up else NAVY, 'bd', 'c')
        by = 2.05 if up else 5.10
        ln(s, cx, y0 - 0.25 if up else y0 + 0.25, cx, by + 1.20 if up else by, LINE, 1, dash=True)
        _card(s, cx - cw / 2 + 0.08, by, cw - 0.16, 1.20, CARD, 0.10)
        txt(s, cx - cw / 2 + 0.2, by + 0.10, cw - 0.4, 0.36, h_, 14, NAVY, 'bd', 'c')
        _p(s, cx - cw / 2 + 0.2, by + 0.50, cw - 0.4, body, 12, MU, h=0.66, al='c')


@reg
def gv_next(prs, d):
    s = page(prs, WH)
    _hd(s, d)
    it = d['items'][:4]
    side = bool(d.get('note'))
    w = 8.3 if side else W - M * 2
    rh = min(1.10, 4.7 / max(len(it), 1))
    for i, (h_, body) in enumerate(it):
        y = 2.00 + i * rh
        _card(s, M, y, w, rh - 0.18, WH, 0.12)
        shp(s, 'round', M, y, w, rh - 0.18, None, line=LINE, adj=0.12)
        shp(s, 'round', M + 0.22, y + (rh - 0.18) / 2 - 0.25, 0.50, 0.50, A() if i % 2 == 0 else B(), adj=0.25)
        txt(s, M + 0.95, y, w * 0.55, rh - 0.18, h_, 15, NAVY, 'bd', an='m')
        txt(s, M + 0.95 + w * 0.55, y, w * 0.45 - 1.15, rh - 0.18, body, 13, MU, 'rg', 'r', 'm')
    if side:
        _card(s, 9.40, 2.00, W - M - 9.40, 4.60, NAVY, 0.06)
        shp(s, 'oval', 9.75, 2.35, 0.60, 0.60, B())
        _p(s, 9.75, 3.20, W - M - 10.05, d['note'], 15, WH, h=3.2)


@reg
def gv_process(prs, d):
    s = page(prs, WH)
    _hd(s, d)
    it = d['items'][:5]; n = max(len(it), 1)
    cw = (W - M * 2) / n
    for i, (h_, body) in enumerate(it):
        x = M + i * cw; f = A() if i < (n + 1) // 2 else B()
        shp(s, 'chev' if i else 'pent', x, 2.30, cw + 0.10, 1.05, f, adj=0.30)
        txt(s, x + 0.45, 2.30, cw - 0.75, 1.05, h_, 14.5, WH if f == A() else NAVY, 'bd', an='m', sp=1.1)
        _p(s, x + 0.15, 3.65, cw - 0.35, body, 13, MU, h=2.6)
    if d.get('note'):
        shp(s, 'round', M + 0.5, 6.05, W - M * 2 - 1.0, 0.55, CARD, adj=0.5)
        txt(s, M + 0.7, 6.05, W - M * 2 - 1.4, 0.55, d['note'], 13, NAVY, 'rg', 'c', 'm')


@reg
def gv_cards3(prs, d):
    s = page(prs, WH)
    _hd(s, d)
    it = d['items'][:3]; n = max(len(it), 1)
    gap = 0.30; cw = (W - M * 2 - gap * (n - 1)) / n
    for i, (h_, body) in enumerate(it):
        x = M + i * (cw + gap); f = mix(B(), WH, 0.82) if i == n - 1 else CARD
        _card(s, x, 2.00, cw, 4.70, f, 0.05)
        shp(s, 'rect', x + 0.40, 2.45, 0.80, 0.10, A() if i != n - 1 else NAVY)
        txt(s, x + 0.40, 2.80, cw - 0.8, 0.90, h_, 18, NAVY, 'bd', sp=1.1)
        _p(s, x + 0.40, 3.85, cw - 0.8, body, 13.5, MU, h=2.6)


@reg
def gv_hex(prs, d):
    s = page(prs, WH)
    _hd(s, d)
    cx, cy = 3.70, 4.35
    shp(s, 'hex', cx - 0.85, cy - 0.74, 1.70, 1.48, NAVY)
    txt(s, cx - 0.75, cy - 0.60, 1.50, 1.20, d.get('k', ''), 13, WH, 'bd', 'c', 'm')
    it = d['items'][:6]
    import math
    for i, t in enumerate(it):
        a = math.radians(-90 + i * 60); hx, hy = cx + 1.62 * math.cos(a), cy + 1.62 * math.sin(a)
        shp(s, 'hex', hx - 0.80, hy - 0.70, 1.60, 1.40, A() if i % 2 == 0 else B())
        y = 1.95 + i * 0.78
        shp(s, 'oval', 7.00, y + 0.12, 0.30, 0.30, A() if i % 2 == 0 else B())
        txt(s, 7.50, y, W - M - 7.50, 0.60, t, 15, NAVY, 'md', an='m')
        ln(s, 7.50, y + 0.68, W - M, y + 0.68, LINE, 0.7)


@reg
def gv_table(prs, d):
    s = page(prs, WH)
    _hd(s, d)
    head, rows = d['head'], d['rows'][:6]
    nc = len(head); tw = W - M * 2
    cols = d.get('colw') or [1] * nc; tot = sum(cols); cols = [c / tot for c in cols]
    al = d.get('al') or ['l'] * nc
    y0, hh = 1.95, 0.56
    rh = min(0.66, 4.5 / max(len(rows), 1))
    shp(s, 'round', M, y0, tw, hh, NAVY, adj=0.25)
    cx = M
    for j, (hd, fr) in enumerate(zip(head, cols)):
        txt(s, cx + 0.22, y0, tw * fr - 0.44, hh, hd, 13.5, WH, 'md', al[j] if j < len(al) else 'l', 'm'); cx += tw * fr
    for i, row in enumerate(rows):
        y = y0 + hh + 0.08 + i * rh
        if i % 2 == 0: shp(s, 'round', M, y, tw, rh - 0.06, CARD, adj=0.25)
        cx = M
        for j, (cell, fr) in enumerate(zip(row, cols)):
            txt(s, cx + 0.22, y, tw * fr - 0.44, rh - 0.06, cell, 13, NAVY, 'md' if j == 0 else 'rg', al[j] if j < len(al) else 'l', 'm'); cx += tw * fr
    if d.get('note'): _p(s, M, y0 + hh + 0.15 + len(rows) * rh, 10, d['note'], 12, h=0.6)
