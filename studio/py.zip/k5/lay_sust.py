"""20 เลย์เอาต์ชุด Sustainability — ลอกโครงจากเทมเพลตเขียวเข้ม+การ์ดขาวที่ไอซ์ส่งมา

พื้นเขียวเข้มทั้งเล่ม สลับกับการ์ดขาวเต็มหน้า
ตัวหนังสือบนการ์ดขาวใช้เขียวเข้ม บนพื้นเขียวใช้ขาว
ชิปกลมใส่รูปคน และลูกศรในวงกลมเป็นลายเซ็นของชุด
"""
from eng import *
import eng
from lay import L, reg

M = 0.76
DK = '17362C'          # ตัวหนังสือบนการ์ดขาว
DKM = '5A7A6C'         # ตัวรองบนการ์ดขาว


def _duo():
    if P.get('dark'):
        return f"duo:{mix(P['bg'], P['acc'], 0.30)}:{mix(P['acc'], 'FFFFFF', 0.58)}"
    return f"duo:{mix(P['ink'], P['acc'], 0.40)}:{mix(P['bg'], P['acc'], 0.12)}"


def _chrome(s, d, on_white=False):
    c = DKM if on_white else mix(P['bg'], P['ink'], 0.52)
    txt(s, M, 0.32, 3.6, 0.26, d.get('brand', 'สื่อสารองค์กร'), 11, c, 'rg')
    txt(s, 4.90, 0.32, 3.6, 0.26, d.get('kind', 'ความยั่งยืน'), 11, c, 'rg')
    if d.get('n'):
        txt(s, W - M - 1.5, 0.32, 1.5, 0.26, f"หน้า {int(d['n']):02d}", 11, c, 'rg', 'r')


def _card(s, x, y, w, h, adj=0.05):
    return shp(s, 'round', x, y, w, h, 'FFFFFF', adj=adj)


def _h(s, x, y, t, sz=46, w=6.4, c=None):
    txt(s, x, y, w, 2.3, t, sz, c or P['ink'], 'md', sp=1.14)


def _sub(s, x, y, t, c=None):
    """บรรทัดรองใต้หัวเรื่อง มีขีดสั้นนำหน้าแบบต้นฉบับ"""
    if not t: return
    shp(s, 'rect', x, y + 0.11, 0.16, 0.05, c or P['acc2'])
    txt(s, x + 0.30, y, 5.4, 0.28, t, 11, c or P['acc2'], 'rg')


def _p(s, x, y, w, t, sz=11.5, c=None):
    txt(s, x, y, w, 1.5, t, sz, c or mix(P['bg'], P['ink'], 0.62), 'rg', sp=1.46)


def _pw(s, x, y, w, t, sz=11.5):
    """เนื้อความบนการ์ดขาว"""
    txt(s, x, y, w, 1.5, t, sz, DKM, 'rg', sp=1.46)


def _arrow(s, cx, cy, r=0.17, c=None, down=False):
    c = c or P['ink']
    shp(s, 'oval', cx - r, cy - r, r * 2, r * 2, None, line=c, lw=0.9)
    if down:
        ln(s, cx, cy - r * 0.42, cx, cy + r * 0.40, c, 0.9)
        ln(s, cx - r * 0.26, cy + r * 0.14, cx, cy + r * 0.42, c, 0.9)
        ln(s, cx + r * 0.26, cy + r * 0.14, cx, cy + r * 0.42, c, 0.9)
    else:
        ln(s, cx - r * 0.42, cy, cx + r * 0.40, cy, c, 0.9)
        ln(s, cx + r * 0.14, cy - r * 0.26, cx + r * 0.42, cy, c, 0.9)
        ln(s, cx + r * 0.14, cy + r * 0.26, cx + r * 0.42, cy, c, 0.9)


def _chip(s, x, y, d, pi, name, w=2.40):
    """ชิปรูปคนกลม ๆ พร้อมชื่อ แบบที่ต้นฉบับใช้มุมล่าง"""
    shp(s, 'round', x, y, w, 0.56, mix(P['bg'], 'FFFFFF', 0.14), adj=0.5)
    pic(s, ph(d.get('ptopic', 'office'), pi), x + 0.06, y + 0.06, 0.44, 0.44,
        geom='ellipse', focus=(0.5, 0.32), mode=_duo())
    txt(s, x + 0.60, y, w - 0.72, 0.56, name, 10, 'FFFFFF', 'rg', an='m')


def _n(s, d, on_white=False):
    pass


# ══ เลย์เอาต์ตามรูปอ้างอิง ═════════════════════════════════════════════════

@reg
def su_cover(prs, d):
    s = page(prs)
    shp(s, 'rect', 0, 0, 6.90, H, mix(P['bg'], '000000', 0.12))
    _chrome(s, d)
    _h(s, M, 1.30, d['t'], 50, 5.6)
    ln(s, 7.40, 1.14, W - M, 1.14, mix(P['bg'], P['ink'], 0.30), 1.0)
    _p(s, M, 3.40, 4.8, d['s'], 12)
    for i, t in enumerate(d['labels'][:3]):
        txt(s, 7.40, 1.30 + i * 0.40, 5.2, 0.30, t, 11,
            'FFFFFF' if i == 2 else mix(P['bg'], P['ink'], 0.58), 'md' if i == 2 else 'rg')
    pic(s, ph(d['topic'], d.get('pi', 0)), 1.40, 4.10, W - 1.40 - M, 2.10, mode=_duo())
    _chip(s, M, 4.50, d, d.get('pi2', 2), d.get('who', 'ผู้นำเสนอ'))


@reg
def su_why(prs, d):
    s = page(prs)
    _chrome(s, d)
    pic(s, ph(d['topic'], d.get('pi', 1)), 0, 0.80, 5.40, H - 1.60, mode=_duo())
    _h(s, 5.90, 1.00, d['t'], 44, 6.2)
    _sub(s, 5.90, 2.98, d.get('k', ''))
    cw = (W - M - 5.90) / 3
    for i, (v, lab, body) in enumerate(d['items'][:3]):
        x = 5.90 + i * cw
        _arrow(s, x + 0.17, 3.60, 0.17)
        txt(s, x, 4.00, cw - 0.3, 0.56, v, 26, 'FFFFFF', 'md')
        txt(s, x, 4.70, cw - 0.35, 0.30, lab, 11.5, 'FFFFFF', 'md')
        _p(s, x, 5.08, cw - 0.40, body, 10.5)


@reg
def su_culture(prs, d):
    s = page(prs)
    _chrome(s, d)
    _card(s, M, 0.90, W - M * 2, H - 1.80)
    _h(s, M + 0.50, 1.26, d['t'], 40, 4.6, DK)
    _sub(s, M + 0.50, 3.06, d.get('k', ''), DKM)
    pic(s, ph(d['topic'], d.get('pi', 3)), 7.20, 1.26, 4.60, 1.60, geom='roundRect', adj=0.05, mode=_duo())
    for i, (h_, body) in enumerate(d['items'][:4]):
        x = M + 0.50 + (i % 2) * 5.30
        y = 3.56 + (i // 2) * 1.36
        shp(s, 'oval', x, y, 0.40, 0.40, P['acc'])
        txt(s, x, y, 0.40, 0.40, f'{i + 1:02d}', 10, 'FFFFFF', 'md', 'c', 'm')
        txt(s, x + 0.56, y - 0.02, 4.5, 0.30, h_, 11.5, DK, 'md')
        _pw(s, x + 0.56, y + 0.34, 4.5, body, 10)


@reg
def su_engage(prs, d):
    s = page(prs)
    _chrome(s, d)
    _card(s, M, 0.90, W - M * 2, H - 1.80)
    _h(s, M + 0.50, 1.26, d['t'], 40, 4.4, DK)
    _sub(s, M + 0.50, 3.00, d.get('k', ''), DKM)
    shp(s, 'round', M + 0.50, 3.50, 3.90, 0.62, P['acc'], adj=0.5)
    _arrow(s, M + 0.80, 3.81, 0.15, 'FFFFFF')
    txt(s, M + 1.14, 3.50, 3.1, 0.62, d['chip'], 11, 'FFFFFF', 'md', an='m')
    _pw(s, M + 0.50, 4.30, 4.3, d.get('note', ''), 10.5)
    for i, (h_, body) in enumerate(d['items'][:3]):
        y = 1.56 + i * 1.78
        pic(s, ph(d['topic'], d.get('pi', 4) + i), 5.90, y, 0.84, 0.84,
            geom='ellipse', focus=(0.5, 0.36), mode=_duo())
        txt(s, 7.00, y, 4.8, 0.30, h_, 11.5, DK, 'md')
        _pw(s, 7.00, y + 0.36, 4.8, body, 10)


@reg
def su_behavior(prs, d):
    s = page(prs)
    _chrome(s, d)
    _card(s, M, 0.90, W - M * 2, H - 1.80)
    _h(s, M + 0.50, 1.26, d['t'], 40, 5.4, DK)
    _arrow(s, 7.00, 1.50, 0.18, DK, down=True)
    _pw(s, 7.50, 1.26, 4.3, d.get('note', ''), 10.5)
    cw = (W - M * 2 - 1.00 - 0.48) / 4
    for i, (h_, body) in enumerate(d['items'][:4]):
        x = M + 0.50 + i * (cw + 0.16)
        shp(s, 'round', x, 3.20, cw, 2.72, mix(P['bg'], 'FFFFFF', 0.06), adj=0.07)
        txt(s, x + 0.24, 3.50, cw - 0.48, 0.44, f'{i + 1:02d}.', 18, 'FFFFFF', 'md')
        txt(s, x + 0.24, 4.18, cw - 0.48, 0.30, h_, 11.5, 'FFFFFF', 'md')
        _p(s, x + 0.24, 4.60, cw - 0.48, body, 10.5, mix(P['bg'], 'FFFFFF', 0.72))


@reg
def su_programs(prs, d):
    s = page(prs)
    _chrome(s, d)
    for i in range(2):
        pic(s, ph(d['topic'], d.get('pi', 6) + i), M + i * 1.70, 1.10, 1.56, 1.56,
            geom='ellipse', focus=(0.5, 0.36), mode=_duo())
    _h(s, 5.20, 1.00, d['t'], 44, 6.4)
    _sub(s, 5.20, 2.98, d.get('k', ''))
    cw = (W - M * 2 - 0.30) / 2
    for i, (h_, body) in enumerate(d['items'][:4]):
        x = M + (i % 2) * (cw + 0.30)
        y = 3.46 + (i // 2) * 1.44
        shp(s, 'round', x, y, cw, 0.52, mix(P['bg'], 'FFFFFF', 0.10), adj=0.5)
        txt(s, x + 0.30, y, cw - 1.00, 0.52, f'{i + 1:02d}. {h_}', 11, 'FFFFFF', 'md', an='m')
        _arrow(s, x + cw - 0.36, y + 0.26, 0.15)
        _p(s, x + 0.30, y + 0.60, cw - 0.40, body, 10)


@reg
def su_training(prs, d):
    s = page(prs)
    _chrome(s, d)
    _h(s, M, 1.10, d['t'], 44, 4.6)
    _sub(s, M, 3.08, d.get('k', ''))
    _p(s, M, 3.52, 4.4, d['note'], 10.5)
    txt(s, M, 4.70, 2.0, 0.56, d['big'], 24, 'FFFFFF', 'md')
    _p(s, M, 5.32, 4.2, d['biglab'], 10)
    for i, (h_, body) in enumerate(d['items'][:3]):
        y = 1.10 + i * 1.70
        shp(s, 'round', 5.90, y, W - M - 5.90, 1.46, mix(P['bg'], '000000', 0.14), adj=0.07)
        pic(s, ph(d['topic'], d.get('pi2', 14) + i), 6.14, y + 0.30, 0.86, 0.86,
            geom='roundRect', adj=0.22, focus=(0.5, 0.36), mode=_duo())
        txt(s, 7.24, y + 0.30, 4.4, 0.30, h_, 12, 'FFFFFF', 'md')
        _p(s, 7.24, y + 0.68, 4.4, body, 10.5)


@reg
def su_comms(prs, d):
    s = page(prs)
    _chrome(s, d)
    _card(s, M, 0.90, W - M * 2, H - 1.80)
    _h(s, M + 0.50, 1.26, d['t'], 40, 4.2, DK)
    _sub(s, M + 0.50, 3.06, d.get('k', ''), DKM)
    for i, (h_, body) in enumerate(d['items'][:4]):
        y = 1.40 + i * 1.28
        pic(s, ph(d['topic'], d.get('pi2', 16) + i), 5.60, y, 0.72, 0.72,
            geom='roundRect', adj=0.22, focus=(0.5, 0.36), mode=_duo())
        txt(s, 6.56, y, 3.1, 0.30, h_, 12, DK, 'md')
        _pw(s, 6.56, y + 0.36, 3.2, body, 10.5)
    pic(s, ph(d['topic'], d.get('pi', 8)), 9.90, 3.00, 2.20, 2.10, geom='roundRect', adj=0.06, mode=_duo())


@reg
def su_tracking(prs, d):
    s = page(prs)
    _chrome(s, d)
    _card(s, M, 0.90, W - M * 2, H - 1.80)
    txt(s, M, 1.30, W, 0.80, d['t'], 40, DK, 'md', 'c')
    _sub(s, 5.50, 2.26, d.get('k', ''), DKM)
    cw = (W - M * 2 - 1.00 - 0.44) / 3
    for i, (cap, body) in enumerate(d['items'][:3]):
        x = M + 0.50 + i * (cw + 0.22)
        pic(s, ph(d['topic'], d.get('pi', 9) + i), x, 2.90, cw, 1.70,
            geom='roundRect', adj=0.05, mode=_duo())
        txt(s, x, 4.76, cw, 0.30, cap, 11.5, DK, 'md')
        _pw(s, x, 5.10, cw, body, 10)


@reg
def su_thanks(prs, d):
    s = page(prs)
    pic(s, ph(d['topic'], d.get('pi', 11)), 0, 0, W, H, mode=_duo())
    shp(s, 'rect', 0, 0, W, H, '0E241C', a=0.74)
    _chrome(s, d)
    _chip(s, M, 1.20, d, d.get('pi2', 2), d.get('who', 'ผู้นำเสนอ'))
    txt(s, M, 3.80, 11.0, 1.9, d['t'], 54, 'FFFFFF', 'md')
    _p(s, M, 5.70, 7.0, d.get('note', ''), 11)


# ══ อีก 10 เลย์เอาต์ ═══════════════════════════════════════════════════════

@reg
def su_toc(prs, d):
    s = page(prs)
    _chrome(s, d)
    _h(s, M, 1.10, d['t'], 44, 4.2)
    _sub(s, M, 3.08, d.get('k', ''))
    x = 5.40
    for i, (h_, body) in enumerate(d['items'][:5]):
        y = 1.02 + i * 1.12
        txt(s, x, y, 0.8, 0.30, f'{i + 1:02d}', 12, P['acc2'], 'md')
        txt(s, x + 0.86, y, 6.0, 0.30, h_, 12, 'FFFFFF', 'md')
        _p(s, x + 0.86, y + 0.34, 6.0, body, 10)
        if i < 4: ln(s, x, y + 0.92, W - M, y + 0.92, mix(P['bg'], P['ink'], 0.18), 0.6)


@reg
def su_divider(prs, d):
    s = page(prs)
    pic(s, ph(d['topic'], d.get('pi', 12)), 7.20, 0, W - 7.20, H, mode=_duo())
    shp(s, 'rect', 7.20, 0, W - 7.20, H, '17362C', a=0.32)
    _chrome(s, d)
    txt(s, M, 2.10, 2.6, 1.1, d['num'], 56, mix(P['bg'], 'FFFFFF', 0.34), 'md')
    _h(s, M, 3.40, d['t'], 42, 5.8)
    if d.get('s'): _p(s, M, 4.90, 5.6, d['s'], 11)


@reg
def su_stats3(prs, d):
    s = page(prs)
    _chrome(s, d)
    _h(s, M, 1.00, d['t'], 44, 6.4)
    _sub(s, M, 2.60, d.get('k', ''))
    cw = (W - M * 2 - 0.44) / 3
    for i, (v, lab, body) in enumerate(d['items'][:3]):
        x = M + i * (cw + 0.22)
        shp(s, 'round', x, 3.20, cw, 2.76, mix(P['bg'], 'FFFFFF', 0.08) if i != 1 else P['acc'], adj=0.07)
        txt(s, x + 0.28, 3.48, cw - 0.56, 0.62, v, 28, 'FFFFFF', 'md')
        txt(s, x + 0.28, 4.26, cw - 0.56, 0.30, lab, 12, 'FFFFFF', 'md')
        _p(s, x + 0.28, 4.66, cw - 0.56, body, 10.5, mix(P['bg'], 'FFFFFF', 0.74))


@reg
def su_table(prs, d):
    s = page(prs)
    _chrome(s, d)
    _card(s, M, 0.90, W - M * 2, H - 1.80)
    _h(s, M + 0.50, 1.26, d['t'], 40, 8.0, DK)
    tw = W - M * 2 - 1.00; cols = d['colw']; x0 = M + 0.50; y0 = 2.90
    shp(s, 'rect', x0, y0, tw, 0.52, P['acc'])
    cx = x0
    for j, (hd, fr) in enumerate(zip(d['head'], cols)):
        txt(s, cx + 0.22, y0, tw * fr - 0.44, 0.52, hd, 11, 'FFFFFF', 'md', 'l' if j == 0 else 'r', 'm'); cx += tw * fr
    for i, row in enumerate(d['rows'][:4]):
        y = y0 + 0.52 + i * 0.54
        if i % 2 == 0: shp(s, 'rect', x0, y, tw, 0.54, 'F0F5F2')
        cx = x0
        for j, (cell, fr) in enumerate(zip(row, cols)):
            txt(s, cx + 0.22, y, tw * fr - 0.44, 0.54, cell, 11,
                mix(P['acc'], '000000', 0.30) if j == len(cols) - 1 else DK,
                'md' if j == len(cols) - 1 else 'rg', 'l' if j == 0 else 'r', 'm'); cx += tw * fr
    if d.get('note'): _pw(s, x0, y0 + 0.52 + len(d['rows'][:4]) * 0.54 + 0.18, tw, d['note'], 10)


@reg
def su_timeline(prs, d):
    s = page(prs)
    _chrome(s, d)
    _h(s, M, 1.00, d['t'], 44, 7.0)
    n = len(d['items'][:4]); cw = (W - M * 2) / n
    ln(s, M, 3.50, W - M, 3.50, mix(P['bg'], P['ink'], 0.24), 0.8)
    for i, (per, h_, body) in enumerate(d['items'][:4]):
        x = M + i * cw
        shp(s, 'oval', x, 3.36, 0.28, 0.28, P['acc2'] if i < 2 else mix(P['bg'], P['ink'], 0.28))
        txt(s, x, 2.90, cw - 0.4, 0.30, per, 11.5, P['acc2'] if i < 2 else None, 'md')
        txt(s, x, 3.84, cw - 0.50, 0.56, h_, 12, 'FFFFFF', 'md', sp=1.25)
        _p(s, x, 4.54, cw - 0.52, body, 10)


@reg
def su_compare(prs, d):
    s = page(prs)
    _chrome(s, d)
    _card(s, M, 0.90, W - M * 2, H - 1.80)
    _h(s, M + 0.50, 1.26, d['t'], 40, 8.0, DK)
    cw = (W - M * 2 - 1.00 - 0.40) / 2
    for c, (ttl, rows) in enumerate(zip(d['heads'], [d['before'], d['after']])):
        x = M + 0.50 + c * (cw + 0.40)
        hot = c == 1
        shp(s, 'round', x, 2.80, cw, 3.00, P['acc'] if hot else 'F0F5F2', adj=0.06)
        txt(s, x + 0.30, 3.06, cw - 0.60, 0.32, ttl, 12, 'FFFFFF' if hot else DK, 'md')
        for i, (lab, v) in enumerate(rows[:4]):
            y = 3.62 + i * 0.52
            txt(s, x + 0.30, y, cw - 2.30, 0.40, lab, 11, 'FFFFFF' if hot else DK, 'rg', an='m')
            txt(s, x + cw - 2.10, y, 1.80, 0.40, v, 12, 'FFFFFF' if hot else mix(P['acc'], '000000', 0.26), 'md', 'r', 'm')


@reg
def su_quote(prs, d):
    s = page(prs)
    _chrome(s, d)
    pic(s, ph(d.get('ptopic', 'office'), d.get('pi', 13)), W - 4.40, 0.90, 4.40 - M, H - 1.80,
        geom='roundRect', adj=0.05, focus=(0.5, 0.4), mode=_duo())
    txt(s, M, 1.40, 1.2, 0.9, '"', 64, P['acc2'], 'md')
    txt(s, M, 2.30, 7.0, 2.2, d['t'], 22, 'FFFFFF', 'md', sp=1.3)
    ln(s, M, 4.84, M + 2.8, 4.84, mix(P['bg'], P['ink'], 0.30), 0.8)
    txt(s, M, 5.00, 5.2, 0.32, d['who'], 12, 'FFFFFF', 'md')
    _p(s, M, 5.40, 5.2, d['role'], 10.5)


@reg
def su_kpi4(prs, d):
    s = page(prs)
    _chrome(s, d)
    _card(s, M, 0.90, W - M * 2, H - 1.80)
    _h(s, M + 0.50, 1.26, d['t'], 40, 8.0, DK)
    cw = (W - M * 2 - 1.00 - 0.54) / 4
    for i, (v, lab, body) in enumerate(d['items'][:4]):
        x = M + 0.50 + i * (cw + 0.18)
        hot = i == 0
        shp(s, 'round', x, 2.90, cw, 2.90, P['acc'] if hot else 'F0F5F2', adj=0.07)
        txt(s, x + 0.26, 3.18, cw - 0.52, 0.62, v, 26, 'FFFFFF' if hot else mix(P['acc'], '000000', 0.26), 'md')
        txt(s, x + 0.26, 3.96, cw - 0.52, 0.30, lab, 11.5, 'FFFFFF' if hot else DK, 'md')
        _p(s, x + 0.26, 4.36, cw - 0.52, body, 10.5,
           mix(P['acc'], 'FFFFFF', 0.72) if hot else DKM)


@reg
def su_steps(prs, d):
    s = page(prs)
    _chrome(s, d)
    _h(s, M, 1.00, d['t'], 44, 4.4)
    _p(s, M, 3.20, 4.2, d.get('note', ''), 10.5)
    x = 5.80
    n = len(d['items'][:4])
    ln(s, x + 0.21, 1.16, x + 0.21, 1.16 + (n - 1) * 1.38 + 0.42, mix(P['bg'], P['ink'], 0.22), 0.8)
    for i, (h_, body) in enumerate(d['items'][:4]):
        y = 1.16 + i * 1.38
        shp(s, 'oval', x, y, 0.42, 0.42, P['acc'] if i < 2 else mix(P['bg'], P['ink'], 0.20))
        txt(s, x, y, 0.42, 0.42, f'{i + 1}', 11, 'FFFFFF', 'md', 'c', 'm')
        txt(s, x + 0.74, y - 0.02, 6.0, 0.32, h_, 12, 'FFFFFF', 'md')
        _p(s, x + 0.74, y + 0.36, 5.9, body, 10)


@reg
def su_next(prs, d):
    s = page(prs)
    _chrome(s, d)
    _h(s, M, 1.00, d['t'], 44, 8.0)
    cw = (W - M * 2 - 0.44) / 3
    for i, (h_, body, when) in enumerate(d['items'][:3]):
        x = M + i * (cw + 0.22)
        hot = i == 0
        shp(s, 'round', x, 2.80, cw, 2.70, P['acc'] if hot else mix(P['bg'], 'FFFFFF', 0.08), adj=0.07)
        txt(s, x + 0.30, 3.04, 0.8, 0.32, f'{i + 1:02d}', 13, 'FFFFFF', 'md')
        txt(s, x + 0.30, 3.48, cw - 0.60, 0.56, h_, 12, 'FFFFFF', 'md', sp=1.25)
        _p(s, x + 0.30, 4.18, cw - 0.60, body, 10, mix(P['bg'], 'FFFFFF', 0.76))
        ln(s, x + 0.30, 4.96, x + cw - 0.30, 4.96, mix(P['bg'], 'FFFFFF', 0.26), 0.6)
        txt(s, x + 0.30, 5.08, cw - 0.60, 0.28, when, 10, 'FFFFFF', 'md')
