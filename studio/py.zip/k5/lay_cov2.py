"""ปกชุดที่ 2 — 10 เลย์เอาต์ใหม่ ถอดมาจาก ref ที่ไอซ์ส่ง (2 ต.ค. 2569)

ของเดิมมีปกแค่ 6 แบบใช้กับ 348 ชุด เลยซ้ำกันทั้งคลัง ไฟล์นี้เพิ่มอีก 10 แบบ
ใช้ content dict ชุดเดียวกับปกเดิม (t, k, s, topic, pi, stats, foot) สลับได้ด้วยการแก้ชื่อ layout อย่างเดียว

สิ่งที่หยิบมาจาก ref: สนามสีเต็มหน้า · หัวข้อใหญ่มากแบบผสมน้ำหนัก · ป้ายยาแคปซูลซ้อนตัวหนังสือ ·
แผงรูปมุมมนใหญ่ · ปุ่มกลมลูกศรเฉียง · มุมตัดเฉียง 45 องศา · แถบหัวกระดาษตัวเล็กมาก ·
ไฮไลต์แคปซูลหลังคำ · แถบข้อมูลล่างมีไอคอน · ป้ายตั้งด้านข้าง
"""
from eng import *
import eng
from lay import L, reg


def _hdr(s, left, mid='', right='', c=None):
    """แถบหัวกระดาษตัวเล็กมาก แบบ ref pitch deck"""
    c = c or tone(P['bg'], 0.6)   # P['mute'] จางเกินจนตกคอนทราสต์ใน 3 พาเลตต์
    txt(s, 0.72, 0.42, 4.0, 0.26, left, 8.5, c, 'md', track=1.6)
    if mid: txt(s, W / 2 - 2, 0.42, 4.0, 0.26, mid, 8.5, c, 'rg', 'c', track=1.0)
    if right: txt(s, W - 4.72, 0.42, 4.0, 0.26, right, 8.5, c, 'rg', 'r', track=1.0)


def _arrowbtn(s, cx, cy, d, fill=None, ic='arrow-up-right', icc=None):
    shp(s, 'oval', cx - d / 2, cy - d / 2, d, d, fill or P['acc2'])
    icon(s, ic, cx, cy, d * 0.46, icc or P['ink'])


def _fg(c):
    """สีตัวอักษรที่อ่านออกบนพื้นสี c

    เดิมตัดสินด้วย luma > 150 ซึ่งไม่ตรงกับสายตา: พื้นสีกลางอย่างเทาหิน/เขียวมอส
    ได้ตัวขาววัดคอนทราสต์จริงแค่ 3.1-3.5 ตอนนี้วัดทั้งสองทางแล้วเลือกที่ชนะ
    """
    w, b = cratio('FFFFFF', c), cratio('101010', c)
    return 'FFFFFF' if w >= b else '101010'


def _tw(t, sz, pad=0.62):
    """ความกว้างกล่องที่พอดีข้อความไทย (ประมาณ 0.56em ต่อตัว) + ระยะขอบ"""
    return min(W - 1.6, sz / 72 * 0.56 * len(t) + pad)


def _stats(s, x, y, stats, vc, lc, gap=1.9, vsz=20, lsz=9.5):
    for i, (v, lb) in enumerate(stats[:3]):
        txt(s, x + i * gap, y, gap - 0.1, 0.42, v, vsz, vc, 'bd')
        txt(s, x + i * gap, y + 0.46, gap - 0.1, 0.32, lb, lsz, lc)


# ── 1. สนามสีเต็มหน้า + ป้ายซ้อนหัวข้อ + แผงรูปมุมมน (ref: Corporate Overview) ──
@reg
def cov_badge_overlap(prs, d):
    s = page(prs, P['acc'])
    glow(s, W * 0.18, H * 0.18, 4.6, 'FFFFFF', 0.18)
    pic(s, ph(d['topic'], d.get('pi', 0)), 7.35, 0.62, 5.3, 6.26,
        geom='round1Rect', adj=0.30, focus=(0.5, 0.42))
    txt(s, 0.86, 1.0, 6.3, 2.5, d['t'], d.get('tsz', 56), 'FFFFFF', 'lt', sp=0.98)
    bw = min(3.3, 0.24 * len(d.get('k', '')) + 0.8)
    pill(s, 0.86, 3.58, bw, 0.62, d.get('k', ''), P['acc2'], '101010', 13)
    _arrowbtn(s, 8.55, 5.0, 1.08)
    if d.get('s'):
        txt(s, 0.86, 4.72, 5.9, 0.44, (d.get('foot') or 'ภาพรวม')[:22], 19, 'FFFFFF', 'bd')
        txt(s, 0.86, 5.3, 5.9, 1.4, d['s'], 13, 'E8ECFF', sp=1.45)


# ── 2. ขาว หัวข้อใหญ่ เส้นคั่นบาง รูปแถบยาวล่าง (ref: Strategic Content Marketing) ──
@reg
def cov_rule_letterbox(prs, d):
    s = page(prs)
    txt(s, 0.86, 0.78, 8.6, 1.9, d['t'], d.get('tsz', 50), P['acc'], 'bd', sp=1.0)
    shp(s, 'oval', W - 1.32, 0.8, 0.46, 0.46, P['acc'])
    txt(s, W - 5.4, 1.42, 4.0, 0.3, d.get('foot', ''), 9.5, P['mute'], 'rg', 'r')
    ln(s, 0.86, 2.94, W - 0.86, 2.94, P['acc'], 1.1)
    if d.get('k'): txt(s, 0.86, 3.1, 6, 0.32, d['k'], 10.5, P['acc'], 'md', track=0.8)
    pic(s, ph(d['topic'], d.get('pi', 1)), 0.86, 3.72, W - 1.72, 2.82,
        geom='roundRect', adj=0.03, focus=(0.5, 0.45))
    if d.get('s'): txt(s, 0.86, 6.72, 9.0, 0.4, d['s'], 12, P['mute'])


# ── 3. กระดาษอ่อน หัวข้อทึบ + แผงมุมตัดเฉียงมีตัวเลขใหญ่ (ref: Empowering Growth) ──
@reg
def cov_angular_stat(prs, d):
    s = page(prs, P['panel'])
    _hdr(s, d.get('foot', '')[:22], 'PRESENTATION', d.get('k', ''))
    pic(s, ph(d['topic'], d.get('pi', 2)), 0.72, 0.95, W - 1.44, 2.62,
        geom='roundRect', adj=0.02, focus=(0.5, 0.4))
    shp(s, 'rect', 0.72, 3.92, 0.11, 1.42, P['acc'])
    txt(s, 1.02, 3.86, 7.3, 1.6, d['t'], d.get('tsz', 40), P['ink'], 'bd', sp=1.04)
    if d.get('s'): txt(s, 1.02, 5.56, 7.0, 0.8, d['s'], 11, P['mute'], sp=1.4)
    st = d.get('stats', [])
    shp(s, 'snipd', 8.72, 3.86, 3.88, 1.92, P['acc'], adj=(0.17, 0.0))
    if st:
        txt(s, 9.1, 4.04, 3.1, 0.3, st[0][1], 9.5, 'FFF0E6', 'rg', track=0.8)
        txt(s, 9.1, 4.36, 3.1, 0.9, st[0][0], 38, 'FFFFFF', 'bd', sp=0.95)
    icon(s, 'arrow-up-right', 12.08, 4.28, 0.42, 'FFFFFF')
    if len(st) > 1: txt(s, 9.1, 5.24, 3.2, 0.5, st[1][1], 9, 'FFE6D4', sp=1.3)


# ── 4. รูปเต็มหน้าย้อมสี + ป้ายตั้งข้าง + แถบมุมล่างขวา (ref: Silentzo) ──
@reg
def cov_wash_sidebar(prs, d):
    s = page(prs)
    pic(s, ph(d['topic'], d.get('pi', 3)), 0, 0, W, H, focus=(0.5, 0.42))
    shp(s, 'rect', 0, 0, W, H, P['acc'], a=0.82)
    ln(s, 1.12, 0.7, 1.12, H - 0.7, 'FFFFFF', 0.9)
    tb = txt(s, -0.95, 2.6, 2.6, 0.34, d.get('k', ''), 10.5, 'FFFFFF', 'md', 'c', track=1.4)
    tb.rotation = 270
    txt(s, 1.62, 2.52, 9.4, 1.8, d['t'], d.get('tsz', 60), 'FFFFFF', 'bd', sp=0.98)
    if d.get('s'): txt(s, 1.62, 4.46, 7.6, 0.5, d['s'], 15, 'EEF2FF', sp=1.35)
    shp(s, 'rect', 8.9, H - 1.02, W - 8.9, 1.02, P['acc2'])
    txt(s, 9.2, H - 0.86, 3.6, 0.5, d.get('foot', '')[:26], 13, '14110C', 'md', an='m')


# ── 5. แผงมนสองฝั่ง ซ้ายสี ขวารูป + ปุ่มแคปซูล (ref: Town Hall) ──
@reg
def cov_split_round(prs, d):
    s = page(prs)
    shp(s, 'round', 0.6, 0.6, 6.3, H - 1.2, P['acc'], adj=0.045)
    pic(s, ph(d['topic'], d.get('pi', 4)), 7.05, 0.6, W - 7.65, H - 1.2,
        geom='roundRect', adj=0.045, focus=(0.5, 0.42))
    icon(s, 'layers', 1.26, 1.34, 0.46, 'FFFFFF')
    txt(s, 1.72, 1.16, 4.4, 0.36, d.get('foot', '')[:22], 11.5, 'FFFFFF', 'md')
    txt(s, 1.26, 2.12, 5.1, 2.6, d['t'], d.get('tsz', 42), 'FFFFFF', 'bd', sp=1.02)
    if d.get('s'): txt(s, 1.26, 4.92, 4.7, 0.9, d['s'], 12.5, 'EAEEFF', sp=1.4)
    pill(s, 1.26, 6.02, 2.25, 0.56, d.get('k', 'เริ่มนำเสนอ'), P['acc2'], '101010', 12)


# ── 6. สนามสีเต็ม หัวข้อทึบใหญ่ + แถบรูป + แถบข้อมูลไอคอนล่าง (ref: Marketing Plan) ──
@reg
def cov_field_strip(prs, d):
    s = page(prs)
    shp(s, 'rect', 0, 0, W, 3.92, P['acc2'])
    shp(s, 'rect', 0.62, 0, 0.62, 0.62, mix(P['acc2'], P['acc'], 0.45))
    pill(s, 0.92, 0.82, 2.0, 0.46, d.get('k', ''), 'FFFFFF', '101010', 10.5)
    txt(s, 0.92, 1.42, 7.6, 2.3, d['t'], d.get('tsz', 52), '101010', 'bd', sp=0.98)
    txt(s, W - 5.0, 0.88, 4.1, 0.36, d.get('foot', ''), 11.5, '101010', 'md', 'r')
    pic(s, ph(d['topic'], d.get('pi', 5)), 0, 3.92, W, 2.0, focus=(0.5, 0.45))
    if d.get('s'):
        shp(s, 'rect', 6.9, 3.92, W - 6.9, 2.0, '000000', a=0.52)
        txt(s, 7.25, 4.3, 5.4, 1.3, d['s'], 13, 'FFFFFF', sp=1.4)
    shp(s, 'round', 0.62, 6.1, W - 1.24, 0.86, P['bg'], adj=0.42, line=mix(P['bg'], P['ink'], 0.1), lw=0.75)
    ics = ['map-pin', 'smartphone', 'globe', 'mail']
    for i, (v, lb) in enumerate(d.get('stats', [])[:3]):
        x = 1.05 + i * 3.9
        shp(s, 'oval', x, 6.33, 0.4, 0.4, mix(P['bg'], P['acc2'], 0.5))
        icon(s, ics[i % len(ics)], x + 0.2, 6.53, 0.23, P['ink'])
        txt(s, x + 0.56, 6.29, 3.2, 0.3, v, 11.5, P['ink'], 'md')
        txt(s, x + 0.56, 6.57, 3.2, 0.28, lb, 9, P['mute'])


# ── 7. ปกแบบนิตยสาร หัวข้อใหญ่มาก รูปซ้อนทับ (ref: ГРАДСТРОЙ) ──
@reg
def cov_magazine(prs, d):
    s = page(prs, P['acc'])
    grid(s, 1.1, 'FFFFFF', 0.28)
    txt(s, 0.7, 0.58, 12.0, 1.9, d['t'], d.get('tsz', 62), 'FFFFFF', 'bd', sp=0.92)
    pic(s, ph(d['topic'], d.get('pi', 6)), 4.35, 2.62, 4.9, 3.42,
        geom='roundRect', adj=0.05, focus=(0.5, 0.35))
    txt(s, 0.7, 2.68, 3.4, 0.34, d.get('k', ''), 10, 'FFE9DA', 'md', track=1.1)
    for i, (v, lb) in enumerate(d.get('stats', [])[:3]):
        y = 3.18 + i * 1.06
        txt(s, 0.7, y, 3.2, 0.56, v, 26, 'FFFFFF', 'bd', sp=0.95)
        txt(s, 0.7, y + 0.56, 3.2, 0.3, lb, 9.5, 'FFE0C9')
    if d.get('s'):
        shp(s, 'round', 9.55, 2.62, 3.1, 3.42, 'FFFFFF', a=0.16, adj=0.07)
        txt(s, 9.85, 2.94, 2.5, 2.8, d['s'], 12, 'FFFFFF', sp=1.45)
    txt(s, 0.7, H - 0.86, 6, 0.34, d.get('foot', ''), 10, 'FFD9BF', track=0.8)


# ── 8. การ์ดใหญ่บนสนามสี + ชิปแคปซูล + ดอกจัน (ref: Influencer Partnerships) ──
@reg
def cov_card_chips(prs, d):
    s = page(prs, P['acc2'])
    card(s, 0.66, 0.66, W - 1.32, H - 1.32, P['bg'], adj=0.045, shadow=True)
    txt(s, 1.2, 1.02, 5.0, 0.32, d.get('foot', '')[:26], 10, P['mute'], 'md', track=0.9)
    txt(s, W - 3.2, 1.02, 2.0, 0.32, d.get('k', ''), 10, P['mute'], 'rg', 'r')
    pic(s, ph(d['topic'], d.get('pi', 7)), 1.2, 1.72, 4.9, 3.5,
        geom='roundRect', adj=0.06, focus=(0.5, 0.42))
    shp(s, 'round', 1.2, 1.72, 2.1, 0.52, P['ink'], adj=0.5)
    txt(s, 1.2, 1.72, 2.1, 0.52, d.get('k', 'ภาพรวม')[:14], 10, P['bg'], 'md', 'c', 'm')
    txt(s, 6.55, 1.62, 5.6, 2.3, d['t'], d.get('tsz', 44), P['ink'], 'bd', sp=1.0)
    txt(s, 11.35, 1.5, 0.7, 0.7, '*', 46, P['acc'], 'bd', 'c')
    if d.get('s'): txt(s, 6.55, 4.12, 5.3, 1.0, d['s'], 12.5, P['mute'], sp=1.42)
    for i, (v, lb) in enumerate(d.get('stats', [])[:3]):
        x = 6.55 + i * 1.92
        shp(s, 'round', x, 5.42, 1.78, 0.92, mix(P['bg'], P['acc2'], 0.4), adj=0.16)
        txt(s, x + 0.16, 5.54, 1.5, 0.4, v, 16, P['ink'], 'bd')
        txt(s, x + 0.16, 5.96, 1.5, 0.3, lb, 8.5, P['mute'])
    _arrowbtn(s, 2.5, 5.9, 0.86, P['ink'], 'arrow-right', P['bg'])
    txt(s, 3.12, 5.68, 2.6, 0.44, d.get('s', '')[:22] or 'ดูรายละเอียด', 11.5, P['ink'], 'md', an='m')


# ── 9. ประโยคใหญ่ มีไฮไลต์แคปซูลหลังคำ (ref: We are proud of what we achieved) ──
@reg
def cov_highlight_quote(prs, d):
    s = page(prs, P['panel'])
    card(s, 0.66, 0.66, W - 1.32, 4.5, P['bg'], adj=0.05)
    pill(s, 1.14, 1.1, 1.7, 0.46, d.get('k', ''), mix(P['bg'], P['acc2'], 0.55), P['ink'], 10)
    lines = d['t'].split('\n')
    sz = d.get('tsz', 42)
    for i, lnx in enumerate(lines[:3]):
        y = 1.92 + i * (sz / 62)
        if lnx.startswith('*'):
            lnx = lnx[1:]
            wpx = min(W - 2.6, 0.30 * sz / 42 * len(lnx) + 0.7)
            shp(s, 'round', 1.14, y - 0.04, wpx, sz / 62 - 0.06, P['acc'], adj=0.5)
            txt(s, 1.14, y, wpx, sz / 62 - 0.06, lnx, sz, 'FFFFFF', 'bd', 'c', 'm')
        else:
            txt(s, 1.14, y, 10.4, sz / 62, lnx, sz, P['ink'], 'bd', an='m')
    _arrowbtn(s, W - 1.56, 4.4, 0.9, mix(P['bg'], P['ink'], 0.9), 'arrow-right', P['bg'])
    pic(s, ph(d['topic'], d.get('pi', 8)), 0.66, 5.34, 5.4, 1.5,
        geom='roundRect', adj=0.09, focus=(0.5, 0.4))
    if d.get('s'): txt(s, 6.3, 5.5, 6.4, 1.2, d['s'], 13, P['mute'], sp=1.45)
    txt(s, 6.3, 6.56, 6.4, 0.3, d.get('foot', ''), 9.5, P['mute'], 'rg', 'r', track=0.8)


# ── 10. เลขปีตัวโตจาง ๆ มุมขวา + แถบสถิติล่าง ──
@reg
def cov_year_ghost(prs, d):
    s = page(prs)
    shp(s, 'rect', 0, 0, W, 0.14, P['acc'])
    _hdr(s, d.get('foot', '')[:24], '', d.get('k', ''))
    big = (d.get('stats') or [('2570', '')])[0][0]
    txt(s, 0.8, 0.95, 7.0, 3.4, big, 132, mix(P['bg'], P['acc'], 0.13), 'bd', sp=0.8)
    txt(s, 0.8, 2.0, 7.4, 2.4, d['t'], d.get('tsz', 48), P['ink'], 'bd', sp=1.0)
    if d.get('s'): txt(s, 0.8, 4.52, 6.4, 0.9, d['s'], 13, P['mute'], sp=1.42)
    pic(s, ph(d['topic'], d.get('pi', 9)), 8.2, 1.5, 4.4, 3.1,
        geom='roundRect', adj=0.05, focus=(0.5, 0.4))
    ln(s, 0.8, 5.76, W - 0.8, 5.76, mix(P['bg'], P['mute'], 0.3), 0.7)
    _stats(s, 0.8, 5.96, d.get('stats', [])[1:4] or d.get('stats', []), P['acc'], P['mute'], gap=3.0, vsz=22)
    _arrowbtn(s, W - 1.22, 6.28, 0.78, P['acc'], 'arrow-up-right', 'FFFFFF')


COV2 = ['cov_badge_overlap', 'cov_rule_letterbox', 'cov_angular_stat', 'cov_wash_sidebar',
        'cov_split_round', 'cov_field_strip', 'cov_magazine', 'cov_card_chips',
        'cov_highlight_quote', 'cov_year_ghost']


# ══ ชุดที่ 2 เพิ่มอีก 8 แบบ (2 ต.ค. 2569 รอบสอง) ═══════════════════════════

# ── 11. กรอบเส้นใหญ่ หัวข้ออยู่ใน รูปโผล่มุม ──
@reg
def cov_corner_frame(prs, d):
    s = page(prs)
    shp(s, 'rect', 0.56, 0.56, W - 1.12, H - 1.12, None, line=P['acc'], lw=1.6)
    pic(s, ph(d['topic'], d.get('pi', 0)), W - 5.0, H - 3.5, 4.44, 2.94,
        geom='roundRect', adj=0.04, focus=(0.5, 0.4))
    pill(s, 1.1, 1.1, min(3.0, 0.24 * len(d.get('k', '')) + 0.7), 0.52, d.get('k', ''),
         mix(P['bg'], P['acc'], 0.16), P['acc'], 11)
    txt(s, 1.1, 2.0, 8.0, 2.4, d['t'], d.get('tsz', 50), P['ink'], 'bd', sp=1.0)
    if d.get('s'): txt(s, 1.1, 4.5, 6.4, 1.0, d['s'], 13, P['mute'], sp=1.42)
    _stats(s, 1.1, 5.72, d.get('stats', []), P['acc'], P['mute'], gap=2.3, vsz=22)
    txt(s, 1.1, H - 1.1, 5.4, 0.3, d.get('foot', ''), 9.5, P['mute'], track=0.8)


# ── 12. สามแถบสีตั้ง หัวข้อพาด ตัวเลขล่าง ──
@reg
def cov_stat_band(prs, d):
    s = page(prs, P['panel'])
    cs = [P['acc'], mix(P['bg'], P['ink'], 0.88), P['acc2']]
    for i, c in enumerate(cs):
        shp(s, 'rect', 0.0 + i * (W / 3), 0, W / 3, H, c)
    shp(s, 'rect', 0, 2.42, W, H - 2.42, P['bg'])
    txt(s, 0.9, 2.78, 9.6, 1.9, d['t'], d.get('tsz', 48), P['ink'], 'bd', sp=1.0)
    txt(s, 0.9, 1.5, 6.0, 0.34, d.get('k', ''), 11, 'FFFFFF', 'md', track=1.3)
    if d.get('s'): txt(s, 0.9, 4.86, 7.4, 0.8, d['s'], 13, P['mute'], sp=1.4)
    ln(s, 0.9, 5.84, W - 0.9, 5.84, mix(P['bg'], P['mute'], 0.3), 0.7)
    for i, (v, lb) in enumerate(d.get('stats', [])[:3]):
        x = 0.9 + i * 4.0
        txt(s, x, 6.06, 3.6, 0.5, v, 26, P['acc'], 'bd')
        txt(s, x, 6.6, 3.6, 0.3, lb, 9.5, P['mute'])
    _arrowbtn(s, W - 1.3, 1.62, 0.84, P['bg'], 'arrow-up-right', P['ink'])


# ── 13. พื้นเข้ม หัวข้อใหญ่ รูปเล็กมุมขวาบน แถวสถิติล่าง ──
@reg
def cov_photo_inset_dark(prs, d):
    s = page(prs, P['ink'] if not P['dark'] else P['bg'])
    base_c = P['bg'] if P['dark'] else P['ink']
    txtc = 'FFFFFF'
    glow(s, W * 0.76, H * 0.2, 4.0, P['acc'], 0.5)
    pic(s, ph(d['topic'], d.get('pi', 1)), 7.9, 0.78, 4.6, 2.9,
        geom='roundRect', adj=0.05, focus=(0.5, 0.4))
    eyebrow(s, 0.9, 0.95, d.get('k', ''), P['acc'])
    txt(s, 0.9, 1.72, 6.6, 2.8, d['t'], d.get('tsz', 50), txtc, 'bd', sp=1.0)
    if d.get('s'): txt(s, 0.9, 4.46, 6.2, 1.0, d['s'], 13, mix(base_c, txtc, 0.62), sp=1.42)
    ln(s, 0.9, 5.66, W - 0.9, 5.66, mix(base_c, txtc, 0.28), 0.7)
    for i, (v, lb) in enumerate(d.get('stats', [])[:3]):
        x = 0.9 + i * 4.0
        txt(s, x, 5.86, 3.6, 0.48, v, 24, P['acc'], 'bd')
        txt(s, x, 6.36, 3.6, 0.3, lb, 9.5, mix(base_c, txtc, 0.55))
    txt(s, 0.9, H - 0.72, 6, 0.3, d.get('foot', ''), 9.5, mix(base_c, txtc, 0.45), track=0.8)


# ── 14. แบ่งทแยง สีกับรูป ──
@reg
def cov_diag_split(prs, d):
    s = page(prs)
    pic(s, ph(d['topic'], d.get('pi', 2)), 0, 0, W, H, focus=(0.62, 0.42))
    shp(s, 'rect', 0, 0, W, H, '000000', a=0.18)
    # แบ่งทแยงให้คมด้วยสี่เหลี่ยม + สามเหลี่ยมมุมฉากต่อกัน (หมุน tri แล้วกรอบเพี้ยน)
    shp(s, 'rect', 0, 0, 6.0, H, P['acc'])
    shp(s, 'rtri', 6.0, 0, 2.5, H, P['acc'])
    txt(s, 0.95, 1.5, 6.0, 0.34, d.get('k', ''), 11, 'FFFFFF', 'md', track=1.3)
    txt(s, 0.95, 2.1, 6.1, 2.5, d['t'], d.get('tsz', 46), 'FFFFFF', 'bd', sp=1.02)
    if d.get('s'): txt(s, 0.95, 4.74, 5.2, 1.0, d['s'], 12.5, 'F0F3FF', sp=1.4)
    txt(s, 0.95, H - 1.0, 5.4, 0.3, d.get('foot', ''), 9.5, 'E8ECFF', track=0.8)
    _arrowbtn(s, 2.0, 5.86, 0.96, P['acc2'], 'arrow-up-right', '101010')


# ── 15. หัวข้อ + แถวชิปหัวข้อย่อย (ref: agenda chips) ──
@reg
def cov_tag_rows(prs, d):
    s = page(prs, P['acc'])
    shp(s, 'round', 0.62, 0.62, 7.3, H - 1.24, P['bg'], adj=0.05)
    pic(s, ph(d['topic'], d.get('pi', 3)), 8.2, 0.62, W - 8.82, H - 1.24,
        geom='roundRect', adj=0.06, focus=(0.5, 0.42))
    txt(s, 1.16, 1.06, 5.0, 0.32, d.get('foot', ''), 10, P['mute'], 'md', track=0.9)
    txt(s, 1.16, 1.66, 6.2, 2.2, d['t'], d.get('tsz', 44), P['ink'], 'bd', sp=1.0)
    if d.get('s'): txt(s, 1.16, 4.02, 6.0, 0.9, d['s'], 12.5, P['mute'], sp=1.42)
    for i, (v, lb) in enumerate(d.get('stats', [])[:3]):
        y = 5.0 + i * 0.66
        shp(s, 'round', 1.16, y, 6.2, 0.56, mix(P['bg'], P['acc'], 0.1), adj=0.5)
        shp(s, 'oval', 1.3, y + 0.13, 0.3, 0.3, P['acc'])
        txt(s, 1.76, y, 3.4, 0.56, v, 12.5, P['ink'], 'md', an='m')
        txt(s, 5.2, y, 2.0, 0.56, lb, 10, P['mute'], 'rg', 'r', 'm')


# ── 16. ตัวเลขใหญ่ซ้าย หัวข้อขวา แถบรูปล่าง (ref: +310% / 245+) ──
@reg
def cov_big_number(prs, d):
    s = page(prs)
    _hdr(s, d.get('foot', ''), '', d.get('k', ''))
    st = d.get('stats', []) or [('', '')]
    shp(s, 'round', 0.7, 1.05, 5.0, 3.1, P['acc'], adj=0.07)
    txt(s, 1.08, 1.32, 4.3, 1.9, st[0][0], fit_sz(st[0][0], 4.3, 84), 'FFFFFF', 'bd', sp=0.92)
    txt(s, 1.08, 3.3, 4.3, 0.6, st[0][1], 12.5, 'FFFFFF', sp=1.35)
    txt(s, 6.1, 1.2, 6.5, 2.4, d['t'], d.get('tsz', 42), P['ink'], 'bd', sp=1.02)
    if d.get('s'): txt(s, 6.1, 3.42, 6.2, 0.9, d['s'], 12.5, P['mute'], sp=1.4)
    pic(s, ph(d['topic'], d.get('pi', 4)), 0.7, 4.46, W - 1.4, 2.26,
        geom='roundRect', adj=0.04, focus=(0.5, 0.45))
    for i, (v, lb) in enumerate(st[1:3]):
        shp(s, 'round', 8.3 + i * 2.15, 4.78, 1.95, 0.88, P['bg'], adj=0.16)
        txt(s, 8.45 + i * 2.15, 4.9, 1.7, 0.4, v, 16, P['ink'], 'bd')
        txt(s, 8.45 + i * 2.15, 5.3, 1.7, 0.28, lb, 8.5, P['mute'])


# ── 17. แถบริบบิ้นสีพาดบนรูป ──
@reg
def cov_ribbon(prs, d):
    s = page(prs)
    pic(s, ph(d['topic'], d.get('pi', 5)), 0, 0, W, H, focus=(0.5, 0.36))
    shp(s, 'rect', 0, 0, W, H, '000000', a=0.3)
    shp(s, 'rect', 0, 2.66, W, 2.26, P['acc'], a=0.96)
    txt(s, 0.95, 2.0, 7.0, 0.36, d.get('k', ''), 11, 'FFFFFF', 'md', track=1.4)
    txt(s, 0.95, 2.94, 10.2, 1.7, d['t'], d.get('tsz', 50), 'FFFFFF', 'bd', sp=1.0)
    if d.get('s'): txt(s, 0.95, 4.34, 7.0, 0.5, d['s'], 13, 'FFF3E8', sp=1.35)
    shp(s, 'rect', 0, H - 1.32, W, 1.32, '000000', a=0.55)
    shp(s, 'rect', 0.95, H - 1.06, 0.1, 0.78, P['acc2'])
    txt(s, 1.26, H - 1.02, 6.0, 0.4, d.get('foot', ''), 11, 'FFFFFF', 'md', an='m')
    _stats(s, 8.5, H - 1.08, d.get('stats', [])[:2], 'FFFFFF', 'D8DEE8', gap=2.2, vsz=20)


# ── 18. เบนโตะสี่ช่อง รูป ไอคอน ตัวเลข ข้อความ ──
@reg
def cov_bento_tiles(prs, d):
    s = page(prs, P['panel'])
    txt(s, 0.74, 0.76, 7.6, 0.34, d.get('k', ''), 10.5, P['acc'], 'md', track=1.2)
    txt(s, 0.74, 1.22, 7.8, 1.9, d['t'], d.get('tsz', 44), P['ink'], 'bd', sp=1.0)
    if d.get('s'): txt(s, 0.74, 3.22, 6.6, 0.8, d['s'], 12.5, P['mute'], sp=1.4)
    pic(s, ph(d['topic'], d.get('pi', 6)), 8.72, 0.72, 3.88, 3.3,
        geom='roundRect', adj=0.07, focus=(0.5, 0.4))
    st = d.get('stats', [])
    card(s, 0.74, 4.3, 3.9, 2.48, P['acc'], adj=0.07)
    if st:
        txt(s, 1.06, 4.6, 3.3, 1.0, st[0][0], fit_sz(st[0][0], 3.3, 48), 'FFFFFF', 'bd', sp=0.95)
        txt(s, 1.06, 5.72, 3.3, 0.7, st[0][1], 11.5, 'FFFFFF', sp=1.35)
    card(s, 4.86, 4.3, 3.64, 2.48, P['bg'], adj=0.07)
    shp(s, 'oval', 5.18, 4.6, 0.6, 0.6, mix(P['bg'], P['acc'], 0.18))
    icon(s, 'target', 5.48, 4.9, 0.32, P['acc'])
    if len(st) > 1:
        txt(s, 5.18, 5.38, 3.0, 0.5, st[1][0], 22, P['ink'], 'bd')
        txt(s, 5.18, 5.92, 3.0, 0.6, st[1][1], 11, P['mute'], sp=1.3)
    card(s, 8.72, 4.3, 3.88, 2.48, P['bg'], adj=0.07)
    if len(st) > 2:
        txt(s, 9.04, 4.6, 3.2, 0.5, st[2][0], 22, P['ink'], 'bd')
        txt(s, 9.04, 5.14, 3.2, 0.6, st[2][1], 11, P['mute'], sp=1.3)
    _arrowbtn(s, 12.06, 6.24, 0.74, P['acc'], 'arrow-up-right', 'FFFFFF')
    txt(s, 9.04, 6.1, 2.4, 0.4, d.get('foot', '')[:20], 10, P['mute'], an='m')


COV2 += ['cov_corner_frame', 'cov_stat_band', 'cov_photo_inset_dark', 'cov_diag_split',
         'cov_tag_rows', 'cov_big_number', 'cov_ribbon', 'cov_bento_tiles']


# ══ ชุดที่ 3: ปกกว้าง สีเด่นเต็มใบ (ไอซ์ขอ 2 ต.ค. 2569 รอบสาม) ════════════
# หลัก: สนามสีเต็มหน้าไม่มีขอบขาว · หัวข้อใหญ่กินความกว้าง · ข้อมูลรองตัวเล็กมาก
# ฟอนต์ใช้แค่ plex กับ athiti ตามที่ไอซ์กำหนด

# ── 19. ตัวหนังสือมหึมาเต็มความกว้าง ──
@reg
def cov_mega_type(prs, d):
    s = page(prs, P['bg'])
    _hdr(s, d.get('foot', ''), '', d.get('k', ''), tone(P['bg'], 0.62))
    ln(s, 0.7, 0.86, W - 0.7, 0.86, mix(P['bg'], P['ink'], 0.3), 0.8)
    txt(s, 0.68, 1.5, W - 1.36, 3.6, d['t'], d.get('tsz', 92), P['ink'], 'bd', sp=0.86)
    if d.get('s'): txt(s, 0.7, 5.5, 7.2, 0.9, d['s'], 15, tone(P['bg'], 0.72), sp=1.4)
    for i, (v, lb) in enumerate(d.get('stats', [])[:3]):
        x = 8.3 + i * 1.72
        txt(s, x, 5.5, 1.6, 0.44, v, 21, P['acc'], 'bd')
        txt(s, x, 5.98, 1.6, 0.3, lb, 9, tone(P['bg'], 0.6))
    shp(s, 'rect', 0, H - 0.34, W, 0.34, P['acc'])


# ── 20. ครึ่งต่อครึ่ง สีกับรูป ชนขอบทั้งใบ ──
@reg
def cov_split_half(prs, d):
    s = page(prs, P['bg'])
    pic(s, ph(d['topic'], d.get('pi', 0)), W * 0.5, 0, W * 0.5, H, focus=(0.5, 0.4))
    txt(s, 0.8, 0.82, 5.4, 0.32, d.get('foot', ''), 11, tone(P['bg'], 0.72), 'md', track=0.9)
    txt(s, 0.8, 1.62, 5.5, 3.2, d['t'], d.get('tsz', 58), P['ink'], 'bd', sp=0.94)
    if d.get('s'): txt(s, 0.8, 5.04, 5.2, 1.0, d['s'], 14, tone(P['bg'], 0.76), sp=1.42)
    pill(s, 0.8, 6.18, 2.4, 0.6, d.get('k', ''), P['acc'], P['bg'] if P['dark'] else 'FFFFFF', 12.5)


# ── 21. แถบรูปพาดกลาง หัวข้อบน ข้อมูลล่าง ──
@reg
def cov_band_wide(prs, d):
    s = page(prs, P['bg'])
    txt(s, 0.74, 0.7, 6.0, 0.32, d.get('k', ''), 11, P['acc'], 'md', track=1.2)
    txt(s, 0.74, 1.18, W - 1.48, 1.9, d['t'], d.get('tsz', 58), P['ink'], 'bd', sp=0.95)
    pic(s, ph(d['topic'], d.get('pi', 1)), 0, 3.36, W, 2.4, focus=(0.5, 0.42))
    if d.get('s'): txt(s, 0.74, 6.0, 7.0, 0.9, d['s'], 13.5, tone(P['bg'], 0.72), sp=1.4)
    for i, (v, lb) in enumerate(d.get('stats', [])[:3]):
        x = 8.2 + i * 1.72
        txt(s, x, 6.0, 1.6, 0.44, v, 21, P['acc'], 'bd')
        txt(s, x, 6.48, 1.6, 0.3, lb, 9, tone(P['bg'], 0.6))


# ── 22. รูปทะลุขอบขวา ไม่มีกรอบ ──
@reg
def cov_edge_photo(prs, d):
    s = page(prs, P['bg'])
    pic(s, ph(d['topic'], d.get('pi', 2)), 6.4, 0, W - 6.4, H, geom='round1Rect', adj=0.22, focus=(0.46, 0.4))
    txt(s, 0.86, 1.0, 5.3, 0.32, d.get('k', ''), 11, P['acc'], 'md', track=1.2)
    txt(s, 0.86, 1.6, 5.4, 3.0, d['t'], d.get('tsz', 54), P['ink'], 'bd', sp=0.95)
    if d.get('s'): txt(s, 0.86, 4.9, 5.0, 1.0, d['s'], 13.5, tone(P['bg'], 0.74), sp=1.42)
    ln(s, 0.86, 6.1, 5.9, 6.1, mix(P['bg'], P['ink'], 0.3), 0.7)
    txt(s, 0.86, 6.28, 5.4, 0.32, d.get('foot', ''), 10.5, tone(P['bg'], 0.66), track=0.8)


# ── 23. สองสีตัดกัน หัวข้อพาดคร่อม ──
@reg
def cov_two_tone(prs, d):
    s = page(prs, P['bg'])
    band = P['acc'] if _fg(P['acc']) != _fg(P['bg']) else mix(P['bg'], P['ink'], 0.9)
    shp(s, 'rect', 0, 0, W, H * 0.46, band)
    bfg = _fg(band)
    txt(s, 0.8, 0.72, 7.0, 0.32, d.get('k', ''), 11, bfg, 'md', track=1.2)
    txt(s, 0.8, 1.5, 9.4, 1.5, d['t'].split('\n')[0], d.get('tsz', 62), bfg, 'bd', sp=0.92)
    rest = '\n'.join(d['t'].split('\n')[1:])
    if rest: txt(s, 0.8, 3.56, 9.4, 1.5, rest, d.get('tsz', 62), P['ink'], 'bd', sp=0.92)
    if d.get('s'): txt(s, 0.8, 5.3, 6.6, 1.0, d['s'], 14, tone(P['bg'], 0.74), sp=1.42)
    pic(s, ph(d['topic'], d.get('pi', 3)), 9.4, 4.5, 3.2, 2.14, geom='roundRect', adj=0.07, focus=(0.5, 0.4))
    txt(s, 0.8, H - 0.76, 6.0, 0.3, d.get('foot', ''), 10, tone(P['bg'], 0.6), track=0.8)


# ── 24. หัวข้อเป็นบล็อกสีทีละบรรทัด ──
@reg
def cov_block_title(prs, d):
    s = page(prs, P['bg'])
    lines = [x for x in d['t'].split('\n') if x][:3]
    sz = d.get('tsz', 54); lh = sz / 72 * 1.52
    cols = [P['acc'], P['acc2'], mix(P['bg'], P['ink'], 0.92)]
    for i, lnx in enumerate(lines):
        y = 1.46 + i * (lh + 0.13)
        wpx = _tw(lnx, sz, 0.9)
        c = cols[i % 3]
        shp(s, 'rect', 0.8, y, wpx, lh, c)
        txt(s, 1.1, y, wpx - 0.6, lh, lnx, sz, _fg(c), 'bd', an='m')
    txt(s, 0.8, 0.8, 7.0, 0.32, d.get('k', ''), 11, P['acc'], 'md', track=1.2)
    y2 = 1.46 + len(lines) * (lh + 0.13) + 0.3
    if d.get('s'): txt(s, 0.84, y2, 7.2, 0.9, d['s'], 13.5, tone(P['bg'], 0.74), sp=1.42)
    pic(s, ph(d['topic'], d.get('pi', 4)), 8.9, y2 - 0.1, 3.7, 2.3, geom='roundRect', adj=0.06, focus=(0.5, 0.4))
    txt(s, 0.84, H - 0.76, 6.0, 0.3, d.get('foot', ''), 10, tone(P['bg'], 0.6), track=0.8)


# ── 25. ประโยคเดียวเต็มจอ ไม่มีรูป ──
@reg
def cov_full_quote(prs, d):
    s = page(prs, P['bg'])
    glow(s, W * 0.82, H * 0.18, 5.0, P['acc'], 0.35)
    txt(s, 0.8, 0.78, 6.0, 0.32, d.get('k', ''), 11, P['acc'], 'md', track=1.3)
    txt(s, 0.8, 1.7, 11.0, 3.6, d['t'], d.get('tsz', 66), P['ink'], 'bd', sp=0.95)
    shp(s, 'rect', 0.84, 5.56, 1.5, 0.1, P['acc'])
    if d.get('s'): txt(s, 0.8, 5.84, 8.2, 0.9, d['s'], 14, tone(P['bg'], 0.74), sp=1.42)
    txt(s, W - 4.8, H - 0.86, 4.0, 0.32, d.get('foot', ''), 10.5, tone(P['bg'], 0.6), 'rg', 'r', track=0.8)
    _arrowbtn(s, W - 1.3, 1.5, 0.92, P['acc'], 'arrow-up-right', P['bg'])


# ── 26. ตัวเลข/คำโตเต็มใบ มีชิปรูปเล็ก ──
@reg
def cov_poster_num(prs, d):
    s = page(prs, P['bg'])
    st = d.get('stats', []) or [('', '')]
    txt(s, 0.78, 0.76, 7.0, 0.32, d.get('k', ''), 11, P['acc'], 'md', track=1.3)
    txt(s, 0.74, 1.1, 8.6, 3.4, st[0][0], fit_sz(st[0][0], 8.6, 150), P['acc'], 'bd', sp=0.82)
    txt(s, 0.84, 4.5, 6.0, 0.4, st[0][1], 15, tone(P['bg'], 0.78), 'md')
    txt(s, 0.8, 5.16, 7.6, 1.6, d['t'], d.get('tsz', 40), P['ink'], 'bd', sp=1.0)
    pic(s, ph(d['topic'], d.get('pi', 5)), 9.0, 1.3, 3.6, 2.9, geom='roundRect', adj=0.08, focus=(0.5, 0.4))
    if d.get('s'): txt(s, 9.0, 4.42, 3.6, 1.4, d['s'], 12, tone(P['bg'], 0.7), sp=1.4)
    txt(s, 9.0, H - 0.8, 3.6, 0.3, d.get('foot', ''), 10, tone(P['bg'], 0.6), track=0.8)


COV2 += ['cov_mega_type', 'cov_split_half', 'cov_band_wide', 'cov_edge_photo',
         'cov_two_tone', 'cov_block_title', 'cov_full_quote', 'cov_poster_num']
