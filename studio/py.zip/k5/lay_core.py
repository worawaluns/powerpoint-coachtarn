"""เลย์เอาต์ชุด core (ks_*) สำหรับเด็คที่ Slide Studio สร้างด้วย AI — ต่อยอดภาษาภาพของ Clear Report (lay_tesla.py)

ใช้ภาษาภาพเดียวกับ ti_: พื้นขาว แผงมุมมน 0.18 นิ้ว ขีดสีสั้นเหนือหัวเรื่อง ท้ายหน้า (ชื่องาน · เลขหน้า) รูปสีจริงไม่ย้อม
ต่างจาก ti_ ตรงที่ตัวหนังสือโตตามโหมด (ti_ เนื้อ 13pt ใช้ไม่ได้ทั้งยืนพูดและประชุม) และมีหน้าชนิดที่ ti_ ไม่มี:
กราฟมีเส้นเกณฑ์ แท่งเทียบเป้า ไทม์ไลน์มีหมุด หน้าเทียบสองฝั่ง ตารางราคาเน้นแพ็กแนะนำ ปฏิทินสัปดาห์ ตารางงาน ฯลฯ
ผิวสีมาจากพาเลตต์ core_* ใน eng.py: acc = ตัวหนังสือ/จุดเน้น (>= 5.9 บนขาว) · b = บล็อกสด ตัวหนังสือ ink · w = สีเตือน · dk = แผงเข้ม ตัวขาว
โหมด: เด็คเรียก setmode('talk') ยืนพูด (หัว 40 เนื้อ 24 ป้าย >= 20) หรือ setmode('meet') ประชุม (หัว 32 เนื้อ 18) · ป้ายกราฟ/ป้ายเล็ก >= 14
"""
import re
from eng import *
import eng
from lay import L
import lay as _lay
import functools


def reg(f):
    """ลงทะเบียนเลย์เอาต์ + ใส่โน้ตผู้พูดจาก d['notes'] (สูตรคำนวณ ข้อมูลที่ขาด ไว้ในโน้ต ไม่ขึ้นสไลด์)"""
    @functools.wraps(f)
    def w(prs, d):
        f(prs, d)
        if d.get('notes'): notes(prs.slides[-1], d['notes'])
    return _lay.reg(w)
from lay_tesla import _adj, _hair, _dot, RAD

M = 0.62
R = W - M
TOP = 0.62
GREY = 'C5CAD3'        # แท่ง/ท่อนที่ไม่ใช่จุดเน้น (ไม่ใช่ตัวหนังสือ)
GREY2 = 'E3E6EB'

MODE = 'talk'
ZS = {'talk': dict(t=40, h2=28, b=24, l=20, s=20, cov=46),
      'meet': dict(t=32, h2=24, b=18, l=16, s=14, cov=44)}


def setmode(m):
    global MODE
    MODE = m


# ── ขั้นตัวอักษรตายตัวต่อโหมด (ไอซ์ 6 พ.ย. 2569: "ติดแค่เรื่องขนาด font บางจุด") ──
# ทุกขนาดที่ส่งเข้า txt/chart ถูกดูดเข้าขั้นที่ใกล้ที่สุด (เสมอกันปัดขึ้น) ห้ามมีขนาดอื่น
# ยืนพูด: ท้ายหน้า 11 · ป้าย 20 · เนื้อ 24 · หัวรอง 28 · หัว 40 · ตัวเลขเด่น 80 (96 เฉพาะตัวเลขยักษ์)
# ประชุม: ท้ายหน้า 11 · ป้าย 14 · เนื้อ 18 · หัวรอง 24 · หัว 32 · ตัวเลขเด่น 60
SCALE = {'talk': (11, 20, 24, 28, 40, 80, 96), 'meet': (11, 14, 18, 24, 32, 60)}


def snap(sz):
    return min(SCALE[MODE], key=lambda v: (abs(v - sz), -v))


def txt(s, x, y, w, h, t, sz=14, c=None, wt='rg', al='l', an='t', sp=1.0, track=0, fam=None, runs=None, caps=False):
    if runs:
        runs = [[(tx, {**o, 'sz': snap(o['sz'])} if 'sz' in o else o) for tx, o in pr] for pr in runs]
    return base.txt(s, x, y, w, h, t, snap(sz), c, wt, al, an, sp, track, fam, runs, caps)


def chart(*a, **k):
    k['sz'] = snap(k.get('sz', 14))
    return base.chart(*a, **k)


def Z(k):
    return ZS[MODE][k]


def LH(sz, n=1, sp=1.12):
    """ความสูงกล่องตัวหนังสือไทย n บรรทัด (เผื่อสระบนล่าง)"""
    return n * sz * sp * 1.42 / 72 + 0.06


def rich(t, hc, base=None):
    """'[[...]]' = ช่วงสีเน้น  คืน runs ให้ txt()"""
    out = []
    for line in t.split('\n'):
        parts = re.split(r'\[\[(.+?)\]\]', line)
        out.append([(p, {'c': hc} if i % 2 else ({'c': base} if base else {})) for i, p in enumerate(parts) if p])
    return out


def T(s, x, y, w, h, t, sz, c=None, wt='rg', al='l', an='t', sp=1.12, hc=None):
    c = c or P['ink']
    if '[[' in t:
        return txt(s, x, y, w, h, '', sz, c, wt, al, an, sp, runs=rich(t, hc or P['acc'], c))
    return txt(s, x, y, w, h, t, sz, c, wt, al, an, sp)


def chrome(s, d, dark=False):
    c = 'FFFFFF' if dark else P['mute']
    txt(s, M, H - 0.46, 7.0, 0.3, d.get('foot', ''), 11, c, 'rg')
    if d.get('n'):
        txt(s, R - 1.0, H - 0.46, 1.0, 0.3, f"{int(d['n'])}", 11, c, 'md', 'r')


def title(s, d, x=M, y=TOP, w=None, sz=None, c=None, dark=False, tick=True):
    sz = sz or Z('t'); w = w or (R - x)
    if tick:
        shp(s, 'rect', x, y - 0.18, 0.5, 0.06, P['b'] if dark else P['acc'])
    n = d['t'].count('\n') + 1
    T(s, x, y, w, LH(sz, n, 1.05), d['t'], sz, c or ('FFFFFF' if dark else P['ink']), 'md', sp=1.05,
      hc=P['b'] if dark else P['acc'])
    return y + LH(sz, n, 1.05)


def panel(s, x, y, w, h, fill=None, line=None, shadow=False, r=RAD):
    return shp(s, 'round', x, y, w, h, fill or P['panel'], line=line, adj=_adj(w, h, r),
               shadow=('000000', 0.12, 18, 5) if shadow else None)


def photo(s, d, n, x, y, w, h, topic=None, focus=(0.5, 0.45), round_=True, shadow=False):
    pic(s, ph(topic or d.get('topic', 'office'), n), x, y, w, h, geom='roundRect' if round_ else None,
        adj=_adj(w, h) if round_ else None, focus=focus, shadow=('000000', 0.16, 20, 6) if shadow else None)


def num(s, x, y, w, v, unit='', sz=72, c=None, al='l', usz=None, wt='md'):
    c = c or P['ink']
    usz = usz or max(Z('l'), int(sz * 0.36))
    runs = [[(v, {})] + ([(unit, {'sz': usz})] if unit else [])]
    return txt(s, x, y, w, LH(sz, 1, 1.0), '', sz, c, wt, al, runs=runs)


def ico_disc(s, name, cx, cy, d_, fill, c):
    shp(s, 'oval', cx - d_ / 2, cy - d_ / 2, d_, d_, fill)
    icon(s, name, cx, cy, d_ * 0.52, c)


def person(s, x, y, sz, c):
    """คนหนึ่งคน (หัวกลม + ลำตัวมุมมน) กว้าง sz สูง sz*1.25"""
    hd = sz * 0.46
    shp(s, 'oval', x + (sz - hd) / 2, y, hd, hd, c)
    shp(s, 'round2', x + sz * 0.1, y + hd + sz * 0.06, sz * 0.8, sz * 0.62, c, adj=[0.45, 0])


def fixed_chart(ch, fx, fy, fw, fh):
    """ล็อกกรอบพื้นที่วาดกราฟด้านใน (สัดส่วนของกรอบกราฟ) จะได้รู้ตำแหน่งแท่งแน่นอนแล้ววางเส้นเกณฑ์/ป้ายทับได้ตรง"""
    from lxml import etree
    from pptx.oxml.ns import qn
    pa = ch._chartSpace.find('.//' + qn('c:plotArea'))
    old = pa.find(qn('c:layout'))
    if old is not None: pa.remove(old)
    lay_ = etree.SubElement(pa, qn('c:layout')); pa.remove(lay_); pa.insert(0, lay_)
    ml = etree.SubElement(lay_, qn('c:manualLayout'))
    for tag, v in (('layoutTarget', 'inner'), ('xMode', 'edge'), ('yMode', 'edge'),
                   ('x', fx), ('y', fy), ('w', fw), ('h', fh)):
        etree.SubElement(ml, qn('c:' + tag)).set('val', str(v))


def tag(s, x, y, t, fill, c, sz=None, h=None, w=None, al='c'):
    sz = sz or Z('s'); h = h or LH(sz, 1, 1.0) + 0.08
    w = w or (len(t) * sz * 0.0085 + 0.5)
    shp(s, 'round', x, y, w, h, fill, adj=0.5)
    txt(s, x, y, w, h, t, sz, c, 'md', al, 'm')
    return w


# ══ ปก 3 แบบ ═══════════════════════════════════════════════════════════════

@reg
def ks_cover_split(prs, d):
    """ปกแบ่ง 7:5 ข้อความซ้าย แถบสีบาง รูปขวาตกขอบ ป้ายแปะบนรูป"""
    s = page(prs)
    px = 7.55
    photo(s, d, d.get('pi', 0), px, 0, W - px, H, round_=False, focus=d.get('focus', (0.5, 0.4)))
    shp(s, 'rect', px - 0.34, 0, 0.34, H, P['b'])
    txt(s, M, 1.05, 6.4, 0.4, d.get('k', ''), Z('l'), P['acc'], 'md')
    n = d['t'].count('\n') + 1; cz = Z('cov') + 10
    T(s, M, 1.55, 6.6, LH(cz, n, 1.02), d['t'], cz, P['ink'], 'bd', sp=1.02)
    y = 1.55 + LH(cz, n, 1.02) + 0.15
    T(s, M, y, 6.2, LH(Z('h2'), 2), d.get('s', ''), Z('h2') - 2, P['mute'], 'rg')
    _hair(s, M, 6.15, px - 0.7, P['ink'], 1.0)
    txt(s, M, 6.3, px - 1.3, 0.4, d.get('meta', ''), Z('l'), P['ink'], 'md')
    if d.get('tag'):
        tag(s, px + 0.4, H - 1.15, d['tag'], 'FFFFFF', P['ink'], Z('l'))


@reg
def ks_cover_block(prs, d):
    """ปกบล็อกสีเต็มซ้าย หัวเรื่องขาวมีคำเน้นเหลือง รูปมุมมนขวา สติกเกอร์วงกลมตัวเลขทับรอยต่อ (ไม่ใส่ badge = ไม่มีสติกเกอร์)"""
    s = page(prs)
    shp(s, 'rect', 0, 0, 7.6, H, P['dk'])
    photo(s, d, d.get('pi', 0), 7.95, M, R - 7.95, H - 2 * M, focus=d.get('focus', (0.5, 0.45)))
    txt(s, M, 1.0, 6.6, 0.45, d.get('k', ''), Z('l') + 2, P['b'], 'md')
    n = d['t'].count('\n') + 1
    T(s, M, 1.6, 6.7, LH(Z('cov'), n, 1.02), d['t'], Z('cov'), 'FFFFFF', 'bd', sp=1.02, hc=P['b'])
    y = 1.6 + LH(Z('cov'), n, 1.02) + 0.2
    T(s, M, y, 6.0, LH(Z('b'), 2), d.get('s', ''), Z('b'), 'FFFFFF', 'rg')
    txt(s, M, H - 1.05, 6.0, 0.4, d.get('meta', ''), Z('l'), 'FFFFFF', 'md')
    if d.get('badge'):
        cx, cy, dd = 7.6, 5.2, 2.25
        shp(s, 'oval', cx - dd / 2, cy - dd / 2, dd, dd, P['b'], shadow=('000000', 0.18, 16, 4))
        txt(s, cx - dd / 2, cy - 0.8, dd, 0.4, d.get('badge_k', ''), Z('s'), P['ink'], 'md', 'c')
        txt(s, cx - dd / 2, cy - 0.42, dd, 0.9, d['badge'], 50, P['ink'], 'bd', 'c')
        txt(s, cx - dd / 2, cy + 0.42, dd, 0.4, d.get('badge_s', ''), Z('s'), P['ink'], 'md', 'c')


@reg
def ks_cover_full(prs, d):
    """ปกรูปเต็มหน้า ม่านเข้มทางซ้าย หัวเรื่องขาวคำเน้นสีคาราเมล แถวตัวเลขสามตัวท้าย"""
    s = page(prs, P['dk'])
    pic(s, ph(d.get('topic', 'office'), d.get('pi', 0)), 0, 0, W, H, focus=d.get('focus', (0.5, 0.45)))
    right = d.get('side') == 'r'
    ox = W - 7.4 if right else 0; L0 = ox + M           # ด้านที่วางข้อความ (side='r' = ข้อความขวา คนในรูปอยู่ซ้าย)
    shp(s, 'rect', ox, 0, 7.4, H, P['dk'], a=0.88)
    if right: gradband(s, ox - 3.0, 0, 3.0, H, 0, c1=P['dk'], c2=P['dk'], a1=0.0, a2=0.88)
    else: gradband(s, 7.4, 0, 3.0, H, 0, c1=P['dk'], c2=P['dk'], a1=0.88, a2=0.0)
    M_ = L0
    tag(s, M_, 0.95, d.get('k', ''), P['b'], P['ink'], Z('s'))
    n = d['t'].count('\n') + 1
    T(s, M_, 1.65, 7.0, LH(Z('cov') + 4, n, 1.02), d['t'], Z('cov') + 4, 'FFFFFF', 'bd', sp=1.02, hc=P['b'])
    y = 1.65 + LH(Z('cov') + 4, n, 1.02) + 0.1
    T(s, M_, y, 6.3, LH(Z('b'), 2), d.get('s', ''), Z('b'), 'FFFFFF', 'rg')
    items = d.get('items', [])[:3]
    for i, (v, lab) in enumerate(items):
        x = M_ + i * 2.2
        ln(s, x, 5.55, x + 1.95, 5.55, P['b'], 1.5)
        txt(s, x, 5.68, 2.0, 0.62, v, 34, 'FFFFFF', 'bd')
        T(s, x, 6.30, 2.0, 0.8, lab, Z('s'), 'FFFFFF', 'rg', sp=1.0)


# ══ หน้าสรุป ═══════════════════════════════════════════════════════════════

@reg
def ks_kpi_ask(prs, d):
    """สรุปหน้าเดียว: การ์ดตัวเลขสามใบ + แถบอ่อนมีขีดสีซ้าย "สิ่งที่ขอวันนี้" ด้านล่าง"""
    s = page(prs); chrome(s, d)
    y0 = title(s, d) + 0.3
    bh = 1.25
    cards = d['cards'][:3]; g = 0.3; cw = (R - M - 2 * g) / 3; ch = H - 0.62 - y0 - bh - 0.35
    for i, (v, unit, lab, sub) in enumerate(cards):
        x = M + i * (cw + g)
        panel(s, x, y0, cw, ch)
        txt(s, x + 0.4, y0 + 0.35, cw - 0.7, 0.4, lab, Z('l'), P['mute'], 'md')
        num(s, x + 0.4, y0 + 0.85, cw - 0.5, v, unit, 60, P['acc'] if i == 0 else P['ink'])
        T(s, x + 0.4, y0 + ch - 0.35 - LH(Z('b'), 1), cw - 0.6, LH(Z('b'), 1), sub, Z('b'), P['ink'], 'rg')
    by = H - 0.62 - bh
    panel(s, M, by, R - M, bh, P['b'])
    ico_disc(s, d.get('ic', 'handshake'), M + 0.7, by + bh / 2, 0.8, P['dk'], 'FFFFFF')
    txt(s, M + 1.35, by + 0.16, 6, 0.36, d.get('ask_k', 'สิ่งที่ขอวันนี้'), Z('s'), P['ink'], 'md')
    T(s, M + 1.35, by + 0.5, R - M - 1.6, bh - 0.55, d['ask'], Z('h2'), P['ink'], 'md', hc=P['ink'])


@reg
def ks_answer(prs, d):
    """คำตอบก่อน: หัวเรื่องใหญ่ + สิ่งที่ขอสองข้อทางซ้าย · แผงขวาตัวเลขยักษ์สามแถว"""
    s = page(prs); chrome(s, d)
    y = title(s, d, w=6.2) + 0.3
    for ic, t in d['asks'][:3]:
        ico_disc(s, ic, M + 0.4, y + 0.42, 0.8, P['b'], P['ink'])
        T(s, M + 1.05, y, 5.0, LH(Z('b'), 2), t, Z('b'), P['ink'], 'md', an='m')
        y += 1.05
    px = 7.15; pw = R - px
    panel(s, px, TOP - 0.1, pw, H - TOP - 0.55)
    rows = d['rows'][:3]; rh = (H - TOP - 0.85) / len(rows)
    for i, (v, unit, lab, hot) in enumerate(rows):
        yy = TOP + 0.1 + i * rh
        if i: _hair(s, px + 0.4, yy - 0.05, R - 0.4)
        num(s, px + 0.4, yy + 0.05, pw - 0.6, v, unit, 66, P['w'] if hot == 2 else (P['acc'] if hot else P['ink']))
        T(s, px + 0.42, yy + 1.08, pw - 0.6, LH(Z('b'), 1), lab, Z('b'), P['mute'], 'md')


# ══ กราฟ ═══════════════════════════════════════════════════════════════════

@reg
def ks_hbarref(prs, d):
    """แท่งนอน (กราฟ Excel) เส้นเกณฑ์ทึบ + เส้นค่าเฉลี่ยประ ป้ายค่าหลบเส้น แท่งที่เป็นประเด็นสีเตือน · แผงข้อเท็จจริงขวา"""
    s = page(prs); chrome(s, d)
    y0 = title(s, d) + 0.25
    cats = [c for c, _ in d['bars']]; vals = [v for _, v in d['bars']]
    hot = d.get('hot', [])
    cols = [P['w'] if c in hot else GREY for c in cats]
    cx, cy, cw, chh = M, y0 + 0.45, 8.55, H - 0.75 - (y0 + 0.45)
    mx = d.get('maxv', 50)
    ch = chart(s, 'bar', cx, cy, cw, chh, cats, [('คะแนน', vals)], cols, labels=False, axis=False,
               vary=True, gap=45, sz=Z('l'), c=P['ink'], maxv=mx, minv=0)
    ch.category_axis.reverse_order = True
    fx, fy, fw, fh = 0.13, 0.02, 0.76, 0.96
    fixed_chart(ch, fx, fy, fw, fh)
    ix, iy, iw, ih = cx + fx * cw, cy + fy * chh, fw * cw, fh * chh
    slot = ih / len(vals)
    refs = [(ix + iw * v / mx, lab, {'mute': P['mute'], 'warn': P['w']}.get(c, c), dash) for v, lab, c, dash in d.get('refs', [])]
    lw_ = 0.9
    for i, v in enumerate(vals):
        yy = iy + i * slot + slot / 2
        x0 = ix + iw * v / mx + 0.12
        for rx, *_ in sorted(refs):                     # ป้ายค่าห้ามทับเส้นอ้างอิง: ชนเส้นไหนก็ขยับไปหลังเส้นนั้น
            if x0 - 0.1 <= rx <= x0 + lw_: x0 = rx + 0.14
        txt(s, x0, yy - 0.26, lw_ + 0.4, 0.52, f'{v:g}', Z('l') + 2, P['w'] if cats[i] in hot else P['ink'], 'md', an='m')
    for k, (xx, lab, c, dash) in enumerate(refs):
        ln(s, xx, iy - 0.4, xx, iy + ih, c, 1.75, dash=dash)
        if dash: txt(s, xx + 0.08, iy - 0.78, 3.4, 0.4, lab, Z('s'), c, 'md', 'l')
        else: txt(s, xx - 3.48, iy - 0.78, 3.4, 0.4, lab, Z('s'), c, 'md', 'r')
    px = 9.55; pw = R - px
    panel(s, px, y0 + 0.05, pw, H - 0.62 - y0 - 0.05)
    yy = y0 + 0.35
    for v, lab in d.get('facts', [])[:2]:
        T(s, px + 0.35, yy, pw - 0.6, LH(48), v, 48, P['ink'], 'md')
        T(s, px + 0.35, yy + 48 / 72 * 1.15 + 0.2, pw - 0.6, LH(Z('l'), 2), lab, Z('l'), P['mute'], 'rg')
        yy += 1.95


@reg
def ks_colref(prs, d):
    """แท่งตั้งเต็มหน้า (กราฟ Excel) เส้นประค่าเฉลี่ย ป้ายข้อความตรงจุด เส้นแบ่งช่วง · ค่าทุกแท่งเป็นแถวใต้ชื่อเดือน (ไม่ชนเส้น ไม่จมในแท่ง)"""
    s = page(prs); chrome(s, d)
    y0 = title(s, d) + 0.15
    cats = d['cats']; vals = d['vals']; mx = d['maxv']
    cols = d['cols']; hot = d.get('hot', len(vals) - 1)
    cx, cy, cw, chh = M, y0 + 0.2, R - M, H - 0.7 - (y0 + 0.2)
    ch = chart(s, 'col', cx, cy, cw, chh, cats, [('ยอดขาย', vals)], cols, labels=False, axis=False,
               vary=True, gap=60, sz=Z('l'), c=P['ink'], maxv=mx, minv=0)
    fx, fy, fw, fh = 0.02, 0.02, 0.96, 0.74
    fixed_chart(ch, fx, fy, fw, fh)
    ix, iy, iw, ih = cx + fx * cw, cy + fy * chh, fw * cw, fh * chh
    slot = iw / len(vals)
    yv = lambda v: iy + ih * (1 - v / mx)
    vy = iy + ih + 0.5
    for i, v in enumerate(vals):
        xc = ix + slot * (i + 0.5)
        txt(s, xc - slot / 2, vy, slot, 0.45, f'{v:,}', Z('l') + 4 if i == hot else Z('l') + 2,
            P['acc'] if i == hot else P['ink'], 'bd' if i == hot else 'md', 'c')
    if d.get('avg'):
        v, lab = d['avg']
        ln(s, ix, yv(v), ix + iw, yv(v), P['mute'], 1.5, dash=True)
        txt(s, ix + 0.05, yv(v) - 0.42, 3.8, 0.36, lab, Z('s'), P['mute'], 'md', 'l')
    for i, lab in d.get('callouts', []):
        xc = ix + slot * (i + 0.5); yt = yv(vals[i]) - 1.35
        panel(s, xc - 1.9, yt, 2.6, 0.7, 'FFFFFF', line=GREY, r=0.12)
        T(s, xc - 1.85, yt + 0.02, 2.5, 0.66, lab, Z('s'), P['ink'], 'md', 'c', 'm', sp=1.0)
    if d.get('split') is not None:
        i, lab = d['split']
        xx = ix + slot * i
        ln(s, xx, iy - 0.1, xx, iy + ih, P['acc'], 1.5, dash=True)
        tag(s, xx + 0.1, iy - 0.08, lab, P['acc'], 'FFFFFF', Z('s'))


@reg
def ks_share100(prs, d):
    """แท่ง 100% แนวนอนแท่งเดียวเต็มกว้าง ชื่อช่องทางบนแท่ง ท่อนเล็กใช้กรอบเส้นประเป็น "โอกาส" · ตัวเลขข้างสองตัวด้านล่าง"""
    s = page(prs); chrome(s, d)
    y0 = title(s, d) + 0.25
    txt(s, M, y0, 8, 0.4, d.get('cap', ''), Z('s'), P['mute'], 'md')
    by, bh = y0 + 0.5, 1.45
    items = d['items']; tot = sum(p for p, *_ in items); bw = R - M; x = M
    for k, (pct, lab, style) in enumerate(items):
        w = bw * pct / tot
        if style == 'hot':
            shp(s, 'rect', x, by, w - 0.04, bh, P['acc'])
            txt(s, x + 0.3, by + 0.18, w - 0.5, 0.5, lab, Z('l'), 'FFFFFF', 'md')
            txt(s, x + 0.3, by + 0.6, w - 0.5, 0.8, f'{pct:g}%', 40, 'FFFFFF', 'bd')
        elif style == 'gap':
            shp(s, 'rect', x + 0.02, by, w - 0.04, bh, 'FFFFFF', line=P['acc'], lw=2, dash=True)
            txt(s, x - 1.6, by + bh + 0.1, w + 1.6, 0.4, lab, Z('l'), P['acc'], 'md', 'r')
            txt(s, x - 1.6, by + bh + 0.48, w + 1.6, 0.6, f'{pct:g}%', 30, P['acc'], 'bd', 'r')
        else:
            shp(s, 'rect', x, by, w - 0.04, bh, GREY if k == 1 else GREY2)
            txt(s, x + 0.25, by + 0.18, w - 0.35, 0.5, lab, Z('l'), P['ink'], 'md')
            txt(s, x + 0.25, by + 0.6, w - 0.35, 0.8, f'{pct:g}%', 30, P['ink'], 'md')
        x += w
    ny = by + bh + 1.25; nw = 3.9
    for i, (v, unit, lab) in enumerate(d.get('stats', [])[:2]):
        x = M + i * (nw + 0.3)
        panel(s, x, ny, nw, H - 0.62 - ny)
        num(s, x + 0.35, ny + 0.2, nw - 0.5, v, unit, 48, P['ink'])
        T(s, x + 0.35, ny + 1.05, nw - 0.6, LH(Z('b')), lab, Z('b'), P['mute'], 'rg')
    if d.get('note'):
        x = M + 2 * (nw + 0.3)
        T(s, x + 0.1, ny + 0.25, R - x - 0.1, H - 0.8 - ny, d['note'], Z('b'), P['ink'], 'md')


@reg
def ks_target(prs, d):
    """เทียบเป้า: แท่งจริงทึบเทา + แท่งเป้าโปร่งขอบสี (แท่งที่เป็นประเด็นทึบสี) ป้าย % เหนือแท่ง เส้นประ "เดือนดีที่สุด" · แผงรวมขวา (อ่อน)"""
    s = page(prs); chrome(s, d)
    y0 = title(s, d) + 0.2
    bars = d['bars']; mx = d['maxv']
    base = H - 1.55; top = y0 + 0.75; hh = base - top
    x0, x1 = M + 0.2, 9.1
    slot = (x1 - x0) / len(bars); bw = slot * 0.56
    yv = lambda v: base - hh * v / mx
    for i, (lab, v, kind, pct, why) in enumerate(bars):
        xc = x0 + slot * (i + 0.5); x = xc - bw / 2
        if kind == 'real':
            shp(s, 'rect', x, yv(v), bw, base - yv(v), GREY)
        elif kind == 'hot':
            shp(s, 'rect', x, yv(v), bw, base - yv(v), P['acc'])
        else:
            shp(s, 'rect', x, yv(v), bw, base - yv(v), P['panel'], line=P['acc'], lw=2.25)
        txt(s, xc - 1.2, yv(v) - 0.92, 2.4, 0.45, pct, Z('h2'), P['acc'] if kind != 'real' else P['mute'], 'bd', 'c')
        txt(s, xc - 1.2, yv(v) - 0.48, 2.4, 0.38, f'{v:,}', Z('l'), P['ink'], 'md', 'c')
        txt(s, xc - 1.2, base + 0.1, 2.4, 0.4, lab, Z('l'), P['ink'], 'md', 'c')
        if why: T(s, xc - 1.25, base + 0.5, 2.5, 0.4, why, Z('s'), P['mute'], 'rg', 'c')
    _hair(s, x0, base, x1, P['ink'], 1.0)
    if d.get('ref'):
        v, lab = d['ref']
        ln(s, x0, yv(v), x1, yv(v), P['mute'], 1.25, dash=True)
    px = 9.6; pw = R - px; ph_ = H - 0.62 - y0 - 0.1
    panel(s, px, y0 + 0.1, pw, ph_, P['panel'])
    shp(s, 'rect', px, y0 + 0.1 + 0.3, 0.08, ph_ - 0.6, P['acc'])
    txt(s, px + 0.4, y0 + 0.45, pw - 0.6, 0.4, d.get('tot_k', ''), Z('l'), P['mute'], 'md')
    txt(s, px + 0.4, y0 + 0.9, pw - 0.5, 0.9, d.get('tot', ''), 44, P['acc'], 'bd')
    T(s, px + 0.4, y0 + 0.9 + 44 / 72 * 1.15 + 0.25, pw - 0.6, 2.6, d.get('tot_s', ''), Z('b'), P['ink'], 'rg')


@reg
def ks_cards3x(prs, d):
    """การ์ดสามใบเรียงเดือน ตัวเลขใหญ่ เส้นคั่น แล้วบรรทัดผลที่ต้องได้ (การ์ดเด่นพื้นสีเน้น) · ชิปเดียวมุมขวาบน · แถบสรุปด้านล่าง"""
    s = page(prs); chrome(s, d)
    y0 = title(s, d, w=R - M - 3.2) + 0.3
    if d.get('chip'): tag(s, R - 2.9, TOP - 0.05, d['chip'], P['b'], P['ink'], Z('l'), w=2.9, h=0.55)
    cards = d['cards'][:3]; g = 0.3; cw = (R - M - 2 * g) / 3; ch = 3.3
    for i, (mon, v, lab2, v2, hot) in enumerate(cards):
        x = M + i * (cw + g)
        f, c1, c2, c3 = (P['acc'], 'FFFFFF', 'FFFFFF', 'FFFFFF') if hot else (P['panel'], P['ink'], P['mute'], P['acc'])
        panel(s, x, y0, cw, ch, f)
        txt(s, x + 0.38, y0 + 0.3, cw - 0.7, 0.45, mon, Z('h2'), c1, 'bd')
        txt(s, x + 0.38, y0 + 0.88, cw - 0.7, 0.35, d.get('k1', ''), Z('s'), c2, 'rg')
        num(s, x + 0.38, y0 + 1.15, cw - 0.5, v, '', 54, c1)
        _hair(s, x + 0.38, y0 + 2.2, x + cw - 0.38, 'FFFFFF' if hot else GREY)
        txt(s, x + 0.38, y0 + 2.3, cw - 0.7, 0.35, lab2, Z('s'), c2, 'rg')
        txt(s, x + 0.38, y0 + 2.62, cw - 0.7, 0.55, v2, 28, c3, 'bd')
    yy = y0 + ch + 0.25; bh = H - 0.68 - yy
    panel(s, M, yy, R - M, bh, P['b'])
    T(s, M + 0.4, yy, R - M - 0.6, bh, d.get('foot2', ''), Z('b') + 2, P['ink'], 'md', an='m', hc=P['ink'])


# ══ หน้าภาพ/กระบวนการ ═════════════════════════════════════════════════════

@reg
def ks_week(prs, d):
    """ปฏิทินสัปดาห์ 7 ช่อง (วันไลฟ์ทึบสี) + แถบยาวแถวเดียวใต้ปฏิทินสำหรับสิ่งที่ทำทุกวัน · เดิม→ใหม่ · รูปแนวตั้งขวา"""
    s = page(prs); chrome(s, d)
    px = 9.25
    photo(s, d, d.get('pi', 0), px, TOP - 0.1, R - px, H - TOP - 0.5, focus=d.get('focus', (0.5, 0.35)))
    y0 = title(s, d, w=px - M - 0.3) + 0.3
    days = d['days']; g = 0.12; cw = (px - 0.35 - M - 6 * g) / 7; chh = 1.75
    for i, (nm, live) in enumerate(days):
        x = M + i * (cw + g)
        panel(s, x, y0, cw, chh, P['acc'] if live else P['panel'], r=0.12)
        c = 'FFFFFF' if live else P['ink']
        txt(s, x, y0 + 0.2, cw, 0.42, nm, Z('b'), c, 'bd', 'c')
        if live:
            txt(s, x, y0 + 0.78, cw, 0.8, d.get('live', 'ไลฟ์\n2 ทุ่ม'), Z('l'), c, 'md', 'c', sp=1.05)
    ty = y0 + chh + 0.15; tw = 7 * cw + 6 * g
    shp(s, 'round', M, ty, tw, 0.62, P['b'], adj=0.3)
    icon(s, 'video', M + 0.42, ty + 0.31, 0.36, P['ink'])
    T(s, M + 0.8, ty, tw - 1.0, 0.62, d.get('daily', ''), Z('l') + 2, P['ink'], 'md', an='m')
    yy = ty + 0.95
    T(s, M, yy, px - M - 0.4, LH(Z('h2')), d.get('change', ''), Z('h2'), P['ink'], 'md')
    T(s, M, yy + 0.65, px - M - 0.4, LH(Z('b'), 2), d.get('who', ''), Z('b'), P['mute'], 'rg')


@reg
def ks_timeline(prs, d):
    """ไทม์ไลน์แนวนอนเส้นเดียวตามวันจริง หัวเดือนเป็นแถบ หมุดโปรเหนือเส้น เส้นตายใต้เส้น (สีเตือน) แถบคอลเลกชันล่าง ช่องว่างเส้นประให้เติม"""
    s = page(prs); chrome(s, d)
    y0 = title(s, d) + 0.25
    months = d['months']; tot = sum(n for _, n in months)
    x0, x1 = M, R
    X = lambda day: x0 + (x1 - x0) * day / tot
    ly = y0 + 1.75
    acc = 0
    for i, (nm, n) in enumerate(months):
        xa, xb = X(acc), X(acc + n)
        shp(s, 'rect', xa + 0.03, y0, xb - xa - 0.06, 0.48, P['panel'])
        txt(s, xa + 0.2, y0, xb - xa, 0.48, nm, Z('l'), P['ink'], 'md', an='m')
        acc += n
    shp(s, 'rect', x0, ly - 0.03, x1 - x0, 0.06, P['ink'])
    for day, lab, sub in d.get('above', []):
        x = X(day)
        ln(s, x, ly - 0.95, x, ly, P['acc'], 1.5)
        shp(s, 'oval', x - 0.13, ly - 0.13, 0.26, 0.26, P['acc'])
        txt(s, x + 0.12, ly - 1.05, 3.4, 0.42, lab, Z('h2'), P['acc'], 'bd')
        txt(s, x + 0.12, ly - 0.62, 3.4, 0.4, sub, Z('l') + 2, P['ink'], 'md')
    for day, lab, sub in d.get('below', []):
        x = X(day)
        ln(s, x, ly, x, ly + 0.55, P['w'], 1.75)
        shp(s, 'oval', x - 0.16, ly - 0.16, 0.32, 0.32, P['w'])
        panel(s, x - 0.1, ly + 0.55, 4.3, 1.0, P['w'], r=0.12)
        txt(s, x + 0.12, ly + 0.6, 4.0, 0.42, lab, Z('l') + 2, 'FFFFFF', 'bd')
        txt(s, x + 0.12, ly + 1.0, 4.0, 0.42, sub, Z('b'), 'FFFFFF', 'rg')
    by = ly + 1.85; bh = H - 0.68 - by
    for d0, d1, lab, kind in d.get('bands', []):
        xa, xb = X(d0) + 0.03, X(d1) - 0.03
        if kind == 'gap':
            shp(s, 'round', xa, by, xb - xa, bh, 'FFFFFF', line=P['mute'], lw=1.5, adj=0.12, dash=True)
            T(s, xa + 0.2, by, xb - xa - 0.3, bh, lab, Z('l'), P['mute'], 'md', an='m')
        else:
            shp(s, 'round', xa, by, xb - xa, bh, P['b'], adj=0.12)
            icon(s, 'shirt', xa + 0.45, by + bh / 2, 0.42, P['ink'])
            T(s, xa + 0.85, by, xb - xa - 0.95, bh, lab, Z('l') + 2, P['ink'], 'md', an='m')


@reg
def ks_photo_bars(prs, d):
    """รูปเต็มซ้ายครึ่งหน้า ขวาเป็นแท่งเทียบสั้นสองแท่ง (วงเล็บช่องว่าง) + ขั้นตอนสองขั้นมีไอคอน"""
    s = page(prs); chrome(s, d)
    pw_ = 5.35
    photo(s, d, d.get('pi', 0), 0, 0, pw_, H, round_=False, focus=d.get('focus', (0.5, 0.5)))
    x = pw_ + 0.55; w = R - x
    y = title(s, d, x=x, w=w) + 0.25
    bars = d['bars']; mx = max(v for _, v, _ in bars)
    bw = w - 1.6
    for i, (lab, v, hot) in enumerate(bars):
        yy = y + i * 0.82
        txt(s, x, yy, 2.8, 0.36, lab, Z('s'), P['mute'], 'md')
        shp(s, 'round', x, yy + 0.38, max(bw * v / mx, 0.2), 0.32, P['acc'] if hot else GREY, adj=0.5)
        txt(s, x + bw * v / mx + 0.12, yy + 0.2, 1.4, 0.6, f'{v:g}%', 32, P['acc'] if hot else P['ink'], 'bd')
    if d.get('gap'):
        T(s, x, y + 1.72, w, 0.4, d['gap'], Z('s'), P['acc'], 'md')
    yy = y + 2.25
    for i, (ic, t) in enumerate(d['steps'][:2]):
        panel(s, x, yy, w, 0.95, P['panel'], r=0.12)
        ico_disc(s, ic, x + 0.5, yy + 0.475, 0.62, P['acc'], 'FFFFFF')
        T(s, x + 0.95, yy, w - 1.1, 0.95, t, Z('b'), P['ink'], 'md', an='m')
        yy += 1.1


@reg
def ks_risk2(prs, d):
    """เทียบสองฝั่ง แผงทึบซ้าย (เข้ม ตัวเลขสีเตือน) แผงอ่อนขวา (ลูกศรลด) แต่ละฝั่งมีป้าย ตัวเลขยักษ์ คำอธิบาย หมายเหตุ"""
    s = page(prs); chrome(s, d)
    y0 = title(s, d) + 0.3
    g = 0.3; cw = (R - M - g) / 2; ch = H - 0.62 - y0
    for i, c in enumerate(d['sides'][:2]):
        x = M + i * (cw + g)
        dark = i == 0
        f = P['dk'] if dark else P['panel']
        ct, cm = ('FFFFFF', 'FFFFFF') if dark else (P['ink'], P['mute'])
        panel(s, x, y0, cw, ch, f)
        ico_disc(s, c['ic'], x + 0.75, y0 + 0.72, 0.8, P['b'], P['ink'])
        txt(s, x + 1.35, y0 + 0.5, cw - 1.6, 0.45, c['k'], Z('h2'), ct, 'md', an='m')
        T(s, x + 0.45, y0 + 1.3, cw - 0.7, 1.3, c['v'], 80, P['w'] if dark else P['acc'], 'bd')
        T(s, x + 0.45, y0 + 2.6, cw - 0.8, LH(Z('b'), 2), c['s'], Z('b') + 2, ct, 'md')
        if c.get('note'):
            _hair(s, x + 0.45, y0 + ch - 1.0, x + cw - 0.45, 'FFFFFF' if dark else GREY)
            T(s, x + 0.45, y0 + ch - 0.88, cw - 0.8, 0.8, c['note'], Z('s'), cm, 'rg')


@reg
def ks_checklist(prs, d):
    """ตารางเช็กลิสต์สามคอลัมน์ (งาน / ผู้รับผิดชอบ / เริ่ม) ช่องติ๊ก แถวสำคัญไฮไลต์ ช่องว่างให้กรอกในที่ประชุม"""
    s = page(prs); chrome(s, d)
    y0 = title(s, d) + 0.25
    cx = [M, 7.6, 10.6]; cw = [6.8, 2.8, R - 10.6]
    for j, h_ in enumerate(d['head']):
        txt(s, cx[j] + (0.75 if j == 0 else 0), y0, cw[j], 0.36, h_, Z('s'), P['mute'], 'md')
    _hair(s, M, y0 + 0.45, R, P['ink'], 1.25)
    rows = d['rows']; rh = (H - 0.75 - y0 - 0.55) / len(rows)
    for i, (task, who, when, hot) in enumerate(rows):
        y = y0 + 0.55 + i * rh
        if hot: shp(s, 'rect', M - 0.1, y + 0.04, R - M + 0.2, rh - 0.08, P['b'])
        shp(s, 'round', M + 0.1, y + rh / 2 - 0.2, 0.4, 0.4, 'FFFFFF', line=P['ink'], lw=1.5, adj=0.2)
        T(s, cx[0] + 0.75, y, cw[0] - 0.8, rh, task, Z('b') + 2, P['ink'], 'md', an='m')
        if who:
            txt(s, cx[1], y, cw[1], rh, who, Z('b'), P['ink'], 'md', an='m')
        else:
            ln(s, cx[1], y + rh / 2 + 0.18, cx[1] + 2.3, y + rh / 2 + 0.18, P['mute'], 1.0)
        txt(s, cx[2], y, cw[2], rh, when, Z('b'), P['ink'], 'md' if hot else 'rg', an='m')
        if not hot: _hair(s, M, y + rh, R)


@reg
def ks_waffle(prs, d):
    """คนทีละคนเป็นตาราง (หนึ่งรูป = หนึ่งคน) กลุ่มที่เป็นประเด็นสีเตือน ที่เหลือเทา · ตัวเลขสัดส่วนใหญ่ซ้าย · ชิปรายกลุ่มใต้ตาราง"""
    s = page(prs); chrome(s, d)
    lw_ = 5.0
    y = title(s, d, w=lw_) + 0.35
    T(s, M, y, lw_, 1.3, d['big'], 96, P['w'], 'bd')
    T(s, M, y + 1.45, lw_ - 0.2, LH(Z('b'), 2), d['big_s'], Z('b'), P['ink'], 'md')
    groups = d['groups']                     # [(ชื่อ, จำนวน, เด่นไหม)] เรียงจากกลุ่มเด่น
    cols, sz, g = 11, 0.5, 0.13
    x0, y0 = 6.15, TOP
    k = 0
    for nm, n, hot in groups:
        for _ in range(n):
            r_, c_ = divmod(k, cols)
            person(s, x0 + c_ * (sz + g), y0 + r_ * (sz * 1.25 + g), sz, P['w'] if hot else GREY)
            k += 1
    rows = -(-k // cols)
    cy = y0 + rows * (sz * 1.25 + g) + 0.25
    x = x0
    for nm, n, hot in groups:
        w = tag(s, x, cy, f'{nm}  {n} คน', P['w'] if hot else P['panel'], 'FFFFFF' if hot else P['ink'], Z('l'), w=2.18)
        x += w + 0.12
        if x > R - 2.1: x = x0; cy += 0.62
    if d.get('note'):
        T(s, x0, cy + 0.75, R - x0, 0.5, d['note'], Z('s'), P['mute'], 'rg')


@reg
def ks_photo_chain(prs, d):
    """รูปเต็มซ้าย ขวาเป็นห่วงโซ่เหตุผลแนวตั้ง (ไอคอน + ข้อความ + ลูกศรลง) การ์ดสูงตามบรรทัดจริง ปิดท้ายด้วยแถบ "ส่วนที่ทำได้ดี" """
    s = page(prs); chrome(s, d)
    pw_ = 4.9
    photo(s, d, d.get('pi', 0), 0, 0, pw_, H, round_=False, focus=d.get('focus', (0.5, 0.5)))
    x = pw_ + 0.55; w = R - x
    y = title(s, d, x=x, w=w) + 0.2
    steps = d['steps']
    for i, (ic, t, hot) in enumerate(steps):
        hh = LH(Z('b'), t.count('\n') + 1, 1.05) + 0.3          # ขอบบนล่าง >= 0.15 นิ้ว (~14px)
        f = P['w'] if hot else P['panel']
        panel(s, x, y, w, hh, f, r=0.14)
        ico_disc(s, ic, x + 0.52, y + hh / 2, 0.62, 'FFFFFF' if hot else P['acc'], P['w'] if hot else 'FFFFFF')
        T(s, x + 1.0, y, w - 1.15, hh, t, Z('b'), 'FFFFFF' if hot else P['ink'], 'md', an='m', sp=1.05)
        y += hh
        if i < len(steps) - 1:
            shp(s, 'tri', x + 0.38, y + 0.05, 0.28, 0.16, P['mute'], rot=180)
            y += 0.26
    if d.get('good'):
        y += 0.22; hh = LH(Z('b'), 1) + 0.3
        shp(s, 'round', x, y, w, hh, 'FFFFFF', line=P['acc'], lw=1.75, adj=0.2)
        icon(s, 'circle-check', x + 0.5, y + hh / 2, 0.42, P['acc'])
        T(s, x + 1.0, y, w - 1.15, hh, d['good'], Z('b'), P['acc'], 'md', an='m')


@reg
def ks_gantt(prs, d):
    """แผนรายสัปดาห์แบบขั้นบันได: เส้นตารางวาดก่อน แล้วแถบช่วงทับ (ช่วงเด่นทึบ ช่วงสุดท้ายมีขอบ) หัวสัปดาห์มีหมุดทดสอบ ชิปเวลาเรียนมุมขวา"""
    s = page(prs); chrome(s, d)
    y0 = title(s, d, w=7.6) + 0.25
    if d.get('chip'):
        tag(s, R - 4.9, TOP - 0.1, d['chip'], P['b'], P['ink'], Z('l'), w=4.9, h=0.62)
    nw = d.get('weeks', 6); gx = M + 0.1; gw = R - gx
    cw = gw / nw
    if d.get('quiz'):
        shp(s, 'diamond', R - 4.75, TOP + 0.74, 0.3, 0.3, P['acc'])
        txt(s, R - 4.35, TOP + 0.62, 4.35, 0.55, d['quiz'], Z('s'), P['ink'], 'md', 'l', 'm')
    yy0 = y0 + 1.0
    for k in range(1, nw):                              # เส้นตารางก่อน แถบช่วงวาดทับทีหลัง
        ln(s, gx + k * cw, y0 + 0.6, gx + k * cw, H - 0.75, GREY2, 1.0)
    for i in range(nw):
        x = gx + i * cw
        shp(s, 'rect', x + 0.03, y0, cw - 0.06, 0.55, P['panel'])
        txt(s, x, y0, cw - 0.3, 0.55, f'สัปดาห์ {i + 1}', Z('s'), P['ink'], 'md', 'c', 'm')
        if d.get('quiz'): shp(s, 'diamond', x + cw - 0.38, y0 + 0.15, 0.24, 0.24, P['acc'])
    for i, lab in d.get('dates', []):
        txt(s, gx + i * cw, y0 + 0.58, cw, 0.4, lab, Z('s'), P['acc'], 'bd', 'c')
    yy = yy0
    rh = (H - 0.75 - yy) / len(d['phases'])
    for a, b, lab, hot in d['phases']:
        x = gx + a * cw + 0.05; w = (b - a) * cw - 0.1
        if hot == 1: f, c, ln_ = P['dk'], 'FFFFFF', None
        elif hot == 2: f, c, ln_ = P['b'], P['ink'], None
        else: f, c, ln_ = P['panel'], P['ink'], P['acc']
        shp(s, 'round', x, yy + 0.06, w, rh - 0.18, f, line=ln_, lw=2.0, adj=0.18)
        T(s, x + 0.25, yy + 0.06, w - 0.4, rh - 0.18, lab, Z('b'), c, 'md', an='m', sp=1.0)
        yy += rh


@reg
def ks_groups(prs, d):
    """แบ่งกลุ่ม: แผ่นตัวเลขสามแผ่นเรียงแถว (จำนวนกลุ่ม คนต่อกลุ่ม ครูต่อกลุ่ม) + การ์ดสีบล็อกพี่เลี้ยง · รูปมุมมนขวา"""
    s = page(prs); chrome(s, d)
    px = 8.75
    photo(s, d, d.get('pi', 0), px, TOP - 0.1, R - px, H - TOP - 0.5, focus=d.get('focus', (0.5, 0.4)))
    w = px - M - 0.4
    y = title(s, d, w=w) + 0.3
    stats = d['stats'][:3]; g = 0.22; tw = (w - g * (len(stats) - 1)) / len(stats); th = 2.05
    for i, (v, lab) in enumerate(stats):
        x = M + i * (tw + g)
        panel(s, x, y, tw, th, P['panel'])
        txt(s, x + 0.3, y + 0.25, tw - 0.4, 0.95, v, 52, P['acc'], 'bd')
        T(s, x + 0.3, y + 0.25 + 52 / 72 * 1.15 + 0.2, tw - 0.45, LH(Z('l'), 2), lab, Z('l'), P['ink'], 'md', sp=1.05)
    y += th + 0.25
    hh = H - 0.62 - y
    panel(s, M, y, w, hh, P['b'])
    icon(s, 'hand-heart', M + 0.55, y + hh / 2, 0.55, P['ink'])
    T(s, M + 1.05, y, w - 1.25, hh, d['mentor'], Z('b'), P['ink'], 'md', an='m')


@reg
def ks_beforeafter(prs, d):
    """ตอนนี้ → เป้า: สองแถว แต่ละแถวมีชื่อตัวชี้วัด ค่าตอนนี้ (แผงอ่อน) ลูกศร ค่าเป้า (แผงเข้ม ตัวขาว) และชิปผลต่าง"""
    s = page(prs); chrome(s, d)
    y0 = title(s, d) + 0.2
    lx, ax, bx = M, 5.0, 8.95; aw = 3.25; bw = R - bx
    txt(s, ax, y0, aw, 0.4, d.get('ha', 'ตอนนี้'), Z('l'), P['mute'], 'md', 'c')
    txt(s, bx, y0, bw, 0.4, d.get('hb', 'เป้าหมาย'), Z('l'), P['acc'], 'bd', 'c')
    rows = d['rows'][:2]; rh = (H - 0.7 - y0 - 0.5) / len(rows) - 0.2
    for i, (lab, a, b, delta) in enumerate(rows):
        y = y0 + 0.5 + i * (rh + 0.2)
        T(s, lx, y, ax - lx - 0.3, rh, lab, Z('h2'), P['ink'], 'md', an='m')
        panel(s, ax, y, aw, rh)
        T(s, ax, y + 0.02, aw, rh - 0.78, a, 66, P['mute'], 'md', 'c', 'm')
        shp(s, 'arrow', ax + aw + 0.18, y + rh / 2 - 0.3, bx - ax - aw - 0.36, 0.6, P['b'])
        panel(s, bx, y, bw, rh, P['dk'])
        T(s, bx, y - 0.06, bw, rh - 0.8, b, 66, 'FFFFFF', 'bd', 'c', 'm')
        tag(s, bx + bw / 2 - 1.3, y + rh - 0.5, delta, P['b'], P['ink'], Z('s'), w=2.6, h=0.42)   # ห่างตัวเลขใหญ่ >= 0.1 นิ้ว


@reg
def ks_ask_dark(prs, d):
    """หน้าขออนุมัติพื้นสีเข้มทั้งหน้า: การ์ดขาวสองใบ (ไอคอน ป้ายติ๊ก หัวข้อ ตัวเลข รายละเอียด) + บรรทัดสิ่งที่จะทำต่อ"""
    s = page(prs, P['dk']); chrome(s, d, True)
    y0 = title(s, d, dark=True) + 0.3
    cards = d['cards'][:2]; g = 0.35; cw = (R - M - g) / 2; ch = 3.3
    for i, (ic, k, v, sub) in enumerate(cards):
        x = M + i * (cw + g)
        panel(s, x, y0, cw, ch, 'FFFFFF', shadow=True)
        ico_disc(s, ic, x + 0.75, y0 + 0.75, 0.9, P['b'], P['ink'])
        tag(s, x + cw - 2.2, y0 + 0.45, d.get('chip', 'ขออนุมัติ'), P['panel'], P['acc'], Z('s'), w=1.85)
        txt(s, x + 0.45, y0 + 1.35, cw - 0.8, 0.5, k, Z('h2'), P['ink'], 'md')
        T(s, x + 0.45, y0 + 1.85, cw - 0.6, 0.9, v, 44, P['acc'], 'bd')
        T(s, x + 0.45, y0 + 2.62, cw - 0.8, 0.6, sub, Z('l'), P['mute'], 'rg')
    yy = y0 + ch + 0.35
    icon(s, d.get('ic', 'message-circle'), M + 0.28, yy + 0.32, 0.5, P['b'])
    T(s, M + 0.75, yy, R - M - 0.8, 0.7, d.get('next', ''), Z('b'), 'FFFFFF', 'md', an='m')


# ══ หน้าขาย ═══════════════════════════════════════════════════════════════

@reg
def ks_quad(prs, d):
    """ปัญหาสี่ช่อง 2x2 แผ่นใหญ่ ไอคอนในวง หัวข้อ + ข้อความหนึ่งบรรทัด แผ่นที่เป็นประเด็นพื้นสีบล็อก"""
    s = page(prs); chrome(s, d)
    y0 = title(s, d) + 0.25
    items = d['items'][:4]; g = 0.28; cw = (R - M - g) / 2; ch = (H - 0.62 - y0 - g) / 2
    for i, (ic, h_, body, hot) in enumerate(items):
        x = M + (i % 2) * (cw + g); y = y0 + (i // 2) * (ch + g)
        panel(s, x, y, cw, ch, P['b'] if hot else P['panel'])
        ico_disc(s, ic, x + 0.75, y + ch / 2, 0.95, P['dk'] if hot else P['acc'], 'FFFFFF')
        txt(s, x + 1.5, y + ch / 2 - 0.62, cw - 1.75, 0.55, h_, Z('h2'), P['ink'], 'bd')
        T(s, x + 1.5, y + ch / 2 - 0.02, cw - 1.75, LH(Z('b'), 2), body, Z('b'), P['ink'] if hot else P['mute'], 'rg')


@reg
def ks_photostat(prs, d):
    """รูปตกขอบครึ่งซ้าย ขวาเป็นตัวเลขยักษ์พร้อมหน่วย แกนเวลาเต็มช่วง (ขีดทุกชั่วโมง) ไฮไลต์ช่วงที่เป็นปัญหา"""
    s = page(prs); chrome(s, d)
    pw_ = 6.2
    photo(s, d, d.get('pi', 0), 0, 0, pw_, H, round_=False, focus=d.get('focus', (0.5, 0.5)))
    x = pw_ + 0.6; w = R - x
    y = title(s, d, x=x, w=w) + 0.2
    num(s, x - 0.05, y, w, d['big'], d.get('unit', ''), 132, P['acc'], usz=40, wt='bd')
    T(s, x, y + 132 / 72 * 1.0 + 0.35, w, LH(Z('b')), d.get('big_s', ''), Z('b'), P['ink'], 'md')
    by = y + 3.35
    a, b, lab = d['band']
    hrs = d.get('hours', (6, 12)); span = hrs[1] - hrs[0]
    X = lambda h_: x + w * (h_ - hrs[0]) / span
    txt(s, X(a), by - 0.5, X(b) - X(a), 0.4, lab, Z('s'), P['acc'], 'bd', 'c')
    shp(s, 'round', x, by, w, 0.42, GREY2, adj=0.5)
    shp(s, 'round', X(a), by, X(b) - X(a), 0.42, P['b'], adj=0.5)
    for h_ in range(hrs[0], hrs[1] + 1):
        ln(s, X(h_), by + 0.46, X(h_), by + 0.58, P['mute'], 1.0)
        if h_ not in (hrs[0], hrs[1], a, b): continue
        al = 'l' if h_ == hrs[0] else ('r' if h_ == hrs[1] else 'c')
        bx = X(h_) - (0 if al == 'l' else (0.9 if al == 'r' else 0.45))
        txt(s, bx, by + 0.6, 0.9, 0.4, f'{h_}:00', Z('s'), P['ink'] if a <= h_ <= b else P['mute'], 'bd' if a <= h_ <= b else 'rg', al)


@reg
def ks_versus(prs, d):
    """วันนี้ vs ใช้ระบบ: แผงอ่อนซ้าย (กากบาท) แผงเข้มขวา (ติ๊กสีคาราเมล) ลูกศรวงกลมกลางรอยต่อ"""
    s = page(prs); chrome(s, d)
    y0 = title(s, d) + 0.3
    g = 0.5; cw = (R - M - g) / 2; ch = H - 0.62 - y0
    for side, (hd, rows) in enumerate(d['sides'][:2]):
        x = M + side * (cw + g); dark = side == 1
        panel(s, x, y0, cw, ch, P['dk'] if dark else P['panel'])
        txt(s, x + 0.45, y0 + 0.3, cw - 0.8, 0.5, hd, Z('h2'), P['b'] if dark else P['mute'], 'bd')
        rh = (ch - 1.05) / len(rows)
        for i, t in enumerate(rows):
            y = y0 + 0.95 + i * rh
            icon(s, 'check' if dark else 'x', x + 0.68, y + 0.36, 0.42, P['b'] if dark else P['mute'])
            T(s, x + 1.15, y, cw - 1.5, rh - 0.1, t, Z('b'), 'FFFFFF' if dark else P['ink'], 'md' if dark else 'rg')
    cx = M + cw + g / 2; cy = y0 + ch / 2
    shp(s, 'oval', cx - 0.45, cy - 0.45, 0.9, 0.9, P['b'], shadow=('000000', 0.18, 10, 3))
    icon(s, 'arrow-right', cx, cy, 0.46, P['ink'])


@reg
def ks_feature5(prs, d):
    """ศูนย์กลางเป็นเครื่อง POS ที่วาด (หน้าจอมีกราฟแท่งจิ๋ว) ฟีเจอร์ซ้ายสองขวาสอง เส้นโยงเข้าหาเครื่อง แถบช่องทางจ่ายเงินด้านล่าง"""
    s = page(prs); chrome(s, d)
    y0 = title(s, d) + 0.2
    dx, dw = 5.75, 1.85; dy, dh = y0 + 0.05, 3.55
    panel(s, dx, dy, dw, dh, P['dk'], shadow=True, r=0.22)
    shp(s, 'round', dx + 0.15, dy + 0.18, dw - 0.3, dh - 0.75, 'FFFFFF', adj=0.06)
    for k, hv in enumerate([0.45, 0.8, 0.6, 1.1, 0.95]):
        bx = dx + 0.3 + k * 0.26
        shp(s, 'rect', bx, dy + 1.9 - hv, 0.17, hv, P['acc'] if k == 3 else GREY)
    txt(s, dx + 0.15, dy + 2.05, dw - 0.3, 0.4, d.get('device', 'ยอดทุกสาขา'), Z('s'), P['ink'], 'md', 'c')
    shp(s, 'oval', dx + dw / 2 - 0.12, dy + dh - 0.42, 0.24, 0.24, P['b'])
    items = d['items'][:4]; colw = dx - M - 0.45
    for i, (ic, h_, body) in enumerate(items):
        left = i < 2
        x = M if left else dx + dw + 0.45
        cw_ = colw if left else R - x
        y = dy + (i % 2) * 1.85
        ico_disc(s, ic, x + 0.45, y + 0.45, 0.8, P['b'], P['ink'])
        T(s, x + 1.05, y + 0.05, cw_ - 1.05, 0.55, h_, Z('b'), P['ink'], 'bd')
        T(s, x + 1.05, y + 0.6, cw_ - 1.05, LH(Z('b'), 2), body, Z('b'), P['mute'], 'rg')
        ln(s, (x + colw - 0.1) if left else (dx + dw + 0.08), y + 0.45, dx - 0.08 if left else x - 0.1, y + 0.45, GREY, 1.25, dash=True)
    py = dy + dh + 0.3; phh = H - 0.62 - py
    panel(s, M, py, R - M, phh, P['panel'])
    icon(s, 'qr-code', M + 0.55, py + phh / 2, 0.5, P['acc'])
    T(s, M + 1.1, py, R - M - 1.3, phh, d.get('pay', ''), Z('b'), P['ink'], 'md', an='m')


@reg
def ks_gauge(prs, d):
    """ผลที่คาด สองแผงอ่อน: ซ้ายแท่งเทียบตอนนี้/หลังใช้ (สีเขียวหัวเป็ด) ขวาตัวเลขยักษ์ลูกศรลง · ป้าย "คาดการณ์" """
    s = page(prs); chrome(s, d)
    y0 = title(s, d) + 0.3
    g = 0.3; lw_ = 5.7; ch = H - 0.62 - y0
    q = d['queue']
    panel(s, M, y0, lw_, ch)
    txt(s, M + 0.45, y0 + 0.3, lw_ - 2.6, 0.5, q['k'], Z('h2'), P['ink'], 'md')
    tag(s, M + lw_ - 2.1, y0 + 0.32, d.get('chip', 'คาดการณ์'), 'FFFFFF', P['mute'], Z('s'), w=1.8)
    mx = q['max']; bw = lw_ - 0.9
    for i, (lab, a, b, txt_, c) in enumerate(q['rows']):
        y = y0 + 1.15 + i * 1.5
        txt(s, M + 0.45, y, lw_ - 0.8, 0.42, lab, Z('l'), P['mute'], 'md')
        shp(s, 'round', M + 0.45, y + 0.5, bw * b / mx, 0.5, mix(c, 'FFFFFF', 0.55), adj=0.5)
        shp(s, 'round', M + 0.45, y + 0.5, bw * a / mx, 0.5, c, adj=0.5)
        if txt_: txt(s, M + 0.45 + bw * b / mx + 0.15, y + 0.4, 2.4, 0.7, txt_, 28, c if c != GREY else P['ink'], 'bd')
    x = M + lw_ + g; w = R - x
    panel(s, x, y0, w, ch, P['panel'])
    txt(s, x + 0.45, y0 + 0.3, w - 1.4, 0.5, d['waste_k'], Z('h2'), P['ink'], 'md')
    icon(s, 'trending-down', x + w - 0.7, y0 + 0.55, 0.55, P['w'])
    pre, big = d['waste'] if isinstance(d['waste'], tuple) else ('', d['waste'])
    txt(s, x + 0.4, y0 + 1.05, w - 0.65, 1.4, '', 80, P['w'], 'bd', runs=[[(pre, {'sz': 40}), (big, {})]])   # ห่างขอบการ์ด >= 0.25 นิ้ว
    T(s, x + 0.45, y0 + 1.05 + 80 / 72 * 1.15 + 0.3, w - 0.8, 1.2, d.get('waste_s', ''), Z('b'), P['ink'], 'rg')


@reg
def ks_pricing(prs, d):
    """ตารางราคาสามแพ็ก แพ็กแนะนำยกสูงกว่า พื้นเข้ม ริบบิ้นสีบล็อก · ราคาใหญ่ หน่วย รวม 12 สาขา บรรทัดรายปี รายการสิ่งที่ได้"""
    s = page(prs); chrome(s, d)
    y0 = title(s, d) + 0.25
    packs = d['packs'][:3]; g = 0.28; cw = (R - M - 2 * g) / 3
    for i, p in enumerate(packs):
        x = M + i * (cw + g); hot = p.get('hot')
        y = y0 - (0.25 if hot else 0); ch = H - 0.62 - y
        f, c1, c2, cc = (P['dk'], 'FFFFFF', 'FFFFFF', P['b']) if hot else (P['panel'], P['ink'], P['mute'], P['acc'])
        panel(s, x, y, cw, ch, f, shadow=hot)
        if hot: tag(s, x + cw - 1.85, y + 0.25, d.get('rec', 'แนะนำ'), P['b'], P['ink'], Z('s'), w=1.6)
        txt(s, x + 0.4, y + 0.22, cw - 0.8, 0.5, p['name'], Z('h2'), c1, 'bd')
        num(s, x + 0.4, y + 0.6, cw - 0.6, p['price'], '', 48, cc, wt='bd')
        yy = y + 0.6 + 48 / 72 * 1.15 + 0.12
        txt(s, x + 0.4, yy, cw - 0.6, 0.36, d.get('unit', 'บาท / สาขา / เดือน'), Z('s'), c2, 'rg')
        yy += 0.4
        for line in [p['tot']] + ([p['year']] if p.get('year') else []):
            txt(s, x + 0.4, yy, cw - 0.5, 0.36, line, Z('s'), cc if line == p.get('year') else c2, 'md')
            yy += 0.38
        _hair(s, x + 0.4, yy + 0.06, x + cw - 0.4, 'FFFFFF' if hot else GREY)
        yy += 0.14
        for t in p['feat']:
            icon(s, 'check', x + 0.55, yy + 0.27, 0.3, cc)
            T(s, x + 0.85, yy, cw - 0.95, 0.5, t, Z('b'), c1, 'rg')
            yy += 0.43


@reg
def ks_receipt(prs, d):
    """ใบเสร็จจำลองกว้าง: แถวคำนวณมีเส้นประคั่น บรรทัดรวมสีเน้น · การ์ดอ่อนเล็กขวา "จ่ายครั้งเดียว" """
    s = page(prs); chrome(s, d)
    y0 = title(s, d) + 0.3
    rw = 8.2; ch = H - 0.62 - y0
    panel(s, M, y0, rw, ch, 'FFFFFF', line=GREY, shadow=True)
    shp(s, 'rect', M, y0 + 0.02, rw, 0.12, P['b'])
    txt(s, M + 0.45, y0 + 0.32, rw - 0.9, 0.42, d.get('rk', ''), Z('l'), P['mute'], 'md')
    rows = d['rows']; rh = (ch - 1.0) / len(rows)
    for i, (lab, v, kind) in enumerate(rows):
        y = y0 + 0.82 + i * rh
        tot = kind == 'tot'
        if tot: shp(s, 'rect', M + 0.25, y + 0.02, rw - 0.5, rh - 0.06, P['panel'])
        T(s, M + 0.45, y, 4.6, rh, lab, Z('b'), P['ink'], 'bd' if tot else 'rg', an='m')
        txt(s, M + 4.6, y, rw - 5.05, rh, v, Z('b') + (6 if tot else 0), P['acc'] if tot or kind == 'neg' else P['ink'], 'bd' if tot else 'md', 'r', 'm')
        if i < len(rows) - 1 and not tot and rows[i + 1][2] != 'tot':
            ln(s, M + 0.45, y + rh, M + rw - 0.45, y + rh, GREY, 1.0, dash=True)
    x = M + rw + 0.3; w = R - x; hh = 2.6
    panel(s, x, y0, w, hh, P['panel'])
    txt(s, x + 0.35, y0 + 0.28, w - 0.6, 0.4, d['ok'], Z('s'), P['mute'], 'md')
    txt(s, x + 0.35, y0 + 0.7, w - 0.5, 0.65, d['ov'], 36, P['ink'], 'bd')
    T(s, x + 0.35, y0 + 0.7 + 36 / 72 * 1.15 + 0.15, w - 0.55, 1.0, d.get('os', ''), Z('s'), P['mute'], 'rg', sp=1.1)


@reg
def ks_roadmap(prs, d):
    """เส้นทางสามขั้นเป็นลูกศรเชฟรอนใหญ่เต็มกว้าง (บล็อก → สีเน้น → สีผล) · หัวเรื่องซ้ายบน รูปมุมมนขวาบน"""
    s = page(prs); chrome(s, d)
    px = 8.3 if 'pi' in d else R + 0.3
    if 'pi' in d: photo(s, d, d['pi'], px, TOP - 0.1, R - px, 2.95, focus=d.get('focus', (0.5, 0.45)))
    yt = title(s, d, w=px - M - 0.3)
    T(s, M, yt + 0.1, px - M - 0.4, LH(Z('b'), 1), d.get('s', ''), Z('b'), P['mute'], 'rg')
    axis = d.get('axis', [])
    steps = d['steps'][:3]; y = yt + 0.85; hh = H - 0.62 - y - (1.0 if axis else 0); n = len(steps)
    sw = (R - M + 0.35 * (n - 1)) / n
    for i, (h_, sub, ic) in enumerate(steps):
        x = M + i * (sw - 0.35)
        f, c = (P['b'], P['ink']) if i == 0 else ((P['acc'], 'FFFFFF') if i == 1 else (P['w'], 'FFFFFF'))
        shp(s, 'pent' if i == 0 else 'chev', x, y, sw, hh, f, adj=0.18)
        tx = x + (0.45 if i == 0 else 0.95)
        icon(s, ic, tx + 0.3, y + 0.65, 0.55, c)
        T(s, tx, y + 1.1, sw - 1.45, 0.6, h_, Z('h2'), c, 'bd')
        T(s, tx, y + 1.72, sw - 1.45, 1.0, sub, Z('b'), c, 'rg')
    if axis:                                            # แกนเวลาใต้ลูกศร: ช่วงละขั้น (จากขั้น a ถึงขั้น b)
        ay = y + hh + 0.35
        ln(s, M, ay, R, ay, P['ink'], 1.5)
        for a, b, lab in axis:
            xa = M + a * (sw - 0.35) + (0.05 if a else 0); xb = M + (b + 1) * (sw - 0.35) + (0.35 if b == n - 1 else 0) - 0.05
            shp(s, 'rect', xa, ay - 0.05, xb - xa, 0.1, P['acc'])
            shp(s, 'oval', xa - 0.08, ay - 0.08, 0.16, 0.16, P['acc'])
            txt(s, xa, ay + 0.14, xb - xa, 0.45, lab, Z('l'), P['ink'], 'bd', 'c')


@reg
def ks_cta(prs, d):
    """ปิดการขาย: แผงเข้มซ้ายเต็มสูง (หัวเรื่องขาว คำเน้นคาราเมล ประโยครองหนึ่งบรรทัด) ขวาเป็นแบบฟอร์มให้เลือกวันนี้"""
    s = page(prs)
    lw_ = 7.0
    shp(s, 'rect', 0, 0, lw_, H, P['dk'])
    shp(s, 'rect', M, 1.6, 0.5, 0.06, P['b'])
    n = d['t'].count('\n') + 1
    T(s, M, 1.85, lw_ - M - 0.4, LH(Z('cov') + 6, n, 1.02), d['t'], Z('cov') + 6, 'FFFFFF', 'bd', sp=1.02, hc=P['b'])
    y = 1.85 + LH(Z('cov') + 6, n, 1.02) + 0.3
    T(s, M, y, lw_ - M - 0.6, LH(Z('b'), 2), d.get('s', ''), Z('b'), 'FFFFFF', 'rg')
    txt(s, M, H - 0.46, 6, 0.3, d.get('foot', ''), 11, 'FFFFFF', 'rg')
    if d.get('n'): txt(s, R - 1.0, H - 0.46, 1.0, 0.3, f"{int(d['n'])}", 11, P['mute'], 'md', 'r')
    x = lw_ + 0.6; w = R - x
    txt(s, x, TOP, w, 0.55, d.get('fk', ''), Z('h2'), P['ink'], 'bd')
    y = TOP + 0.95
    for lab, val in d['fields']:
        txt(s, x, y, w, 0.42, lab, Z('l'), P['mute'], 'md')
        if val:
            tag(s, x, y + 0.5, val, P['b'], P['ink'], Z('b'), w=2.4, h=0.62)
        else:
            ln(s, x, y + 1.05, R, y + 1.05, P['ink'], 1.25)
        y += 1.32


# ══ เพิ่มรอบ 3 (6 พ.ย. 2569) ═══════════════════════════════════════════════

@reg
def ks_overview(prs, d):
    """ภาพรวมปัญหา: หัวเรื่องใหญ่ซ้าย + บริบทสองบรรทัดมีไอคอน · แผงขวาตัวเลขยักษ์สองแถว (ค่าเด่นสีเตือน) พร้อมแถบเทียบก่อน/หลัง"""
    s = page(prs); chrome(s, d)
    y = title(s, d) + 0.35
    py = y - 0.05
    for ic, t in d.get('ctx', [])[:3]:
        hh = LH(Z('b'), t.count('\n') + 1, 1.05)
        ico_disc(s, ic, M + 0.4, y + max(hh, 0.8) / 2, 0.8, P['b'], P['ink'])
        T(s, M + 1.05, y, 5.2, max(hh, 0.8), t, Z('b'), P['ink'], 'md', an='m', sp=1.05)
        y += max(hh, 0.8) + 0.3
    px = 7.3; pw = R - px; phh = H - 0.62 - py
    panel(s, px, py, pw, phh)
    a = d['a']; b = d['b']
    num(s, px + 0.45, py + 0.2, pw - 0.6, a[0], a[1], 72, P['w'], wt='bd')
    T(s, px + 0.45, py + 0.2 + 72 / 72 * 1.12 + 0.25, pw - 0.7, LH(Z('b')), a[2], Z('b'), P['ink'], 'md')
    yy = py + 2.15
    _hair(s, px + 0.45, yy - 0.05, R - 0.45)
    yy += 0.08
    txt(s, px + 0.45, yy, pw - 0.6, 0.42, b[0], Z('l'), P['mute'], 'md')
    vals = b[1]; mx = d.get('bmax', max(it[1] for it in vals))
    for i, it in enumerate(vals):
        lab, v = it[:2]; disp = it[2] if len(it) > 2 else f'{v:g}'
        ry = yy + 0.5 + i * 0.75
        hot = i == len(vals) - 1
        txt(s, px + 0.45, ry, 1.2, 0.6, lab, Z('l'), P['ink'], 'md', an='m')
        bw = (pw - 3.3) * v / mx
        shp(s, 'round', px + 1.55, ry + 0.12, bw, 0.36, P['w'] if hot else GREY, adj=0.5)
        txt(s, px + 1.55 + bw + 0.12, ry, 1.6, 0.6, disp, 30, P['w'] if hot else P['ink'], 'bd', an='m')


@reg
def ks_failtable(prs, d):
    """ตารางรายห้อง (ห้อง / นักเรียน / ไม่ผ่าน / สัดส่วนมีแถบในช่อง) แถวเด่นพื้นสีอ่อนตัวสีเตือน แถวรวมเส้นหนา · ตัวเลขสรุปซ้าย"""
    s = page(prs); chrome(s, d)
    lw_ = 4.3
    y = title(s, d) + 0.3
    num(s, M, y, lw_, d['big'], d.get('unit', ''), 80, P['w'], wt='bd', usz=32)
    T(s, M, y + 80 / 72 * 1.12 + 0.3, lw_ - 0.2, LH(Z('b'), 2), d['big_s'], Z('b'), P['ink'], 'md', sp=1.05)
    if d.get('ring'):
        pct, lab = d['ring']; rd = 1.8; ry = H - 0.58 - rd
        chart(s, 'donut', M - 0.1, ry, rd, rd, ['a', 'b'], [('r', [pct, 100 - pct])], [P['w'], GREY2], labels=False, hole=76)
        txt(s, M - 0.1, ry + rd / 2 - 0.25, rd, 0.5, f'{pct}%', 20, P['w'], 'bd', 'c', 'm')
        T(s, M + rd + 0.1, ry, lw_ - rd - 0.1, rd, lab, Z('l'), P['ink'], 'md', an='m', sp=1.05)
    tx = M + lw_ + 0.4; tw = R - tx
    cx = [tx, tx + 1.7, tx + 3.3, tx + 4.9]; cws = [1.6, 1.5, 1.5, tw - 4.9]
    hy = y
    for j, h_ in enumerate(d['head']):
        txt(s, cx[j] + (0.2 if j == 0 else (0.35 if j == 3 else 0)), hy, cws[j], 0.42, h_, Z('s'), P['mute'], 'md', 'l' if j in (0, 3) else 'r')
    _hair(s, tx, hy + 0.48, R, P['ink'], 1.25)
    rows = d['rows']; n = len(rows); rh = min(0.72, (H - 0.75 - hy - 0.55) / n)
    for i, (room, cnt, fail, hot) in enumerate(rows):
        yy = hy + 0.55 + i * rh
        tot = hot == 2
        if hot == 1: shp(s, 'rect', tx, yy + 0.03, tw, rh - 0.06, mix(P['w'], 'FFFFFF', 0.88))
        c = P['w'] if hot == 1 else P['ink']; wt = 'bd' if hot else 'rg'
        txt(s, cx[0] + 0.2, yy, cws[0], rh, room, Z('b'), c, wt, an='m')
        txt(s, cx[1], yy, cws[1], rh, f'{cnt}', Z('b'), P['ink'], 'rg', 'r', 'm')
        txt(s, cx[2], yy, cws[2], rh, f'{fail}', Z('b'), c, 'bd', 'r', 'm')
        pct = fail / cnt * 100
        bx = cx[3] + 0.35; bwm = cws[3] - 1.7
        shp(s, 'round', bx, yy + rh / 2 - 0.12, max(bwm * pct / 50, 0.06), 0.24, P['w'] if hot == 1 else (P['ink'] if tot else GREY), adj=0.5)
        txt(s, bx + bwm * pct / 50 + 0.12, yy, 1.3, rh, f'{pct:.1f}%', Z('l'), c, wt, an='m')
        if tot: ln(s, tx, yy, R, yy, P['ink'], 1.5)
        elif i < n - 1 and rows[i + 1][3] != 2: _hair(s, tx, yy + rh, R)


@reg
def ks_donut(prs, d):
    """โดนัทช่องทาง (กราฟ Excel) ตัวเลขเด่นกลางวง รายการสีข้างวงเรียงมากไปน้อย ช่องที่เป็นโอกาสมีป้ายบอก · การ์ดตัวเลขข้างล่างขวา"""
    s = page(prs); chrome(s, d)
    y0 = title(s, d) + 0.2
    items = d['items']                                  # [(ชื่อ, %, สี)] สีเป็นคีย์ acc/b/grey/grey2
    cmap = {'acc': P['acc'], 'b': P['b'], 'grey': GREY, 'grey2': GREY2, 'ink': P['ink']}
    cols = [cmap[c] for *_, c in items]
    dd = H - 0.75 - y0
    dx = M + 0.2
    chart(s, 'donut', dx, y0, dd, dd, [n for n, *_ in items], [('สัดส่วน', [v for _, v, _ in items])], cols, labels=False, hole=58)
    txt(s, dx, y0 + dd / 2 - 0.62, dd, 0.8, d.get('big', ''), 44, P['acc'], 'bd', 'c')
    txt(s, dx, y0 + dd / 2 + 0.22, dd, 0.4, d.get('biglab', ''), Z('l'), P['ink'], 'md', 'c')
    lx = dx + dd + 0.5; lw_ = 4.1
    txt(s, lx, y0 + 0.05, lw_, 0.4, d.get('cap', ''), Z('s'), P['mute'], 'md')
    for i, (nm, v, c) in enumerate(items):
        y = y0 + 0.6 + i * 0.95
        shp(s, 'round', lx, y + 0.12, 0.34, 0.34, cmap[c], adj=0.25)
        txt(s, lx + 0.55, y, 2.4, 0.6, nm, Z('b'), P['ink'], 'md', an='m')
        txt(s, lx + 2.85, y, 1.2, 0.6, f'{v:g}%', 30, P['acc'] if c == 'acc' else P['ink'], 'bd', 'r', 'm')
        if i < len(items) - 1: _hair(s, lx, y + 0.8, lx + lw_)
    for nm, note in d.get('flag', []):
        k = [n for n, *_ in items].index(nm)
        tag(s, lx, y0 + 0.6 + k * 0.95 + 0.62, note, P['panel'], P['acc'], Z('s'), w=lw_, h=0.42, al='l')
    cx_ = lx + lw_ + 0.4; cw = R - cx_
    if d.get('stat'):
        v, unit, lab = d['stat']; ch = 2.3; cy = H - 0.62 - ch
        panel(s, cx_, cy, cw, ch)
        txt(s, cx_ + 0.3, cy + 0.22, cw - 0.4, 0.4, lab, Z('l'), P['mute'], 'md')
        num(s, cx_ + 0.3, cy + 0.7, cw - 0.4, v, unit, 48, P['ink'])


@reg
def ks_twofig(prs, d):
    """สองตัวเลขแยกฐาน: แผ่นใหญ่สองแผ่นเคียงกัน (ตัวเลข + ความหมาย + ฐานที่วัด) ไม่ลบกัน · แถวขั้นตอนสองขั้นมีไอคอนด้านล่าง"""
    s = page(prs); chrome(s, d)
    y0 = title(s, d) + 0.3
    figs = d['figs'][:2]; g = 0.3; fw = (R - M - g) / 2; fh = 2.3
    for i, (v, lab, base, hot) in enumerate(figs):
        x = M + i * (fw + g)
        panel(s, x, y0, fw, fh, P['panel'])
        vw = d.get('vw', 3.0)
        num(s, x + 0.4, y0 + 0.3, vw, v, '', 72, P['acc'] if hot else P['ink'], wt='bd')
        T(s, x + vw + 0.3, y0 + 0.4, fw - vw - 0.6, LH(Z('h2'), 2), lab, Z('h2'), P['ink'], 'md', sp=1.05)
        T(s, x + 0.4, y0 + 0.3 + 72 / 72 * 1.12 + 0.3, fw - 0.7, LH(Z('l')), base, Z('l'), P['mute'], 'rg')
    y = y0 + fh + 0.45
    steps = d['steps'][:4]; n = len(steps); sh = min(1.5, H - 0.62 - y); ov = 0.3
    sw = (R - M + ov * (n - 1)) / n
    for i, (ic, t) in enumerate(steps):                 # แถบขั้นตอนเชฟรอนต่อกันเต็มกว้าง ขั้นสุดท้ายสีเน้น
        x = M + i * (sw - ov); last = i == n - 1
        f, c = (P['acc'], 'FFFFFF') if last else (P['panel'], P['ink'])
        shp(s, 'pent' if i == 0 else 'chev', x, y, sw, sh, f, adj=0.22)
        tx = x + (0.4 if i == 0 else 0.75)
        ico_disc(s, ic, tx + 0.35, y + sh / 2, 0.7, 'FFFFFF' if last else P['acc'], P['acc'] if last else 'FFFFFF')
        T(s, tx + 0.85, y, sw - 1.75 - (0 if i == 0 else 0.2), sh, t, Z('b') + 2, c, 'bd', an='m', sp=1.0)


@reg
def ks_equation(prs, d):
    """สมการเงินออกแบบบวกเลขแนวตั้ง: แถวละรายการ (ป้าย + คำอธิบายซ้าย ตัวเลข hero ชิดขวา มีเครื่องหมาย + / = นำหน้า) แถวผลรวมพื้นเข้ม"""
    s = page(prs); chrome(s, d)
    y0 = title(s, d) + 0.35
    tiles = d['tiles'][:3]; g = 0.18
    rh = (H - 0.62 - y0 - g * 2) / 3
    for i, (k, v, sub) in enumerate(tiles):
        y = y0 + i * (rh + g); last = i == 2
        panel(s, M, y, R - M, rh, P['dk'] if last else P['panel'])
        ct = 'FFFFFF' if last else P['ink']
        txt(s, M + 0.45, y + 0.18, 6.5, 0.45, k, Z('h2'), P['b'] if last else P['ink'], 'bd')
        T(s, M + 0.45, y + 0.72, 6.5, rh - 0.8, sub.replace('\n', ' '), Z('b'), ct, 'rg')
        txt(s, R - 6.2, y, 5.75, rh, ('= ' if last else ('+ ' if i else '')) + v, 60, ct if last else P['ink'], 'bd', 'r', 'm')
    if d.get('note'):
        T(s, M, H - 0.6, R - M, 0.4, d['note'], Z('b'), P['ink'], 'md', hc=P['w'])


@reg
def ks_vtable(prs, d):
    """ตอนนี้ ↔ ใช้ระบบ แบบตาราง: คอลัมน์หัวข้อ (ไอคอน) · ตอนนี้ (กากบาทเทา) · ใช้ระบบ (ติ๊กสีผล หัวคอลัมน์ทึบ) แถวละเรื่อง · แถบท้าย"""
    s = page(prs); chrome(s, d)
    y0 = title(s, d) + 0.2
    c0, c1 = M, M + 2.75; c2 = c1 + 4.35; w1 = 4.25; w2 = R - c2
    txt(s, c1 + 0.2, y0, w1, 0.48, d.get('ha', 'ตอนนี้'), Z('l') + 2, P['mute'], 'bd', an='m')
    shp(s, 'round', c2, y0, w2, 0.5, P['w'], adj=0.3)
    txt(s, c2 + 0.3, y0, w2 - 0.4, 0.5, d.get('hb', 'ใช้ระบบ'), Z('l') + 2, 'FFFFFF', 'bd', an='m')
    rows = d['rows']; foot = d.get('foot2')
    yb = H - 0.62 - (0.75 if foot else 0)
    rh = (yb - y0 - 0.65) / len(rows)
    for i, (ic, topic, now, aft) in enumerate(rows):
        y = y0 + 0.62 + i * rh
        shp(s, 'rect', c2, y + 0.04, w2, rh - 0.08, mix(P['w'], 'FFFFFF', 0.9))
        ico_disc(s, ic, c0 + 0.35, y + rh / 2, 0.62, P['b'], P['ink'])
        T(s, c0 + 0.8, y, 1.9, rh, topic, Z('b'), P['ink'], 'bd', an='m')
        icon(s, 'x', c1 + 0.38, y + rh / 2, 0.34, P['mute'])
        T(s, c1 + 0.75, y, w1 - 0.8, rh, now, Z('b'), P['mute'], 'rg', an='m', sp=1.0)
        icon(s, 'check', c2 + 0.38, y + rh / 2, 0.36, P['w'])
        T(s, c2 + 0.75, y, w2 - 0.85, rh, aft, Z('b'), P['ink'], 'md', an='m', sp=1.0)
        if i < len(rows) - 1: _hair(s, c0, y + rh, c2 - 0.1)
    if foot:
        icon(s, 'qr-code', M + 0.3, yb + 0.4, 0.42, P['acc'])
        T(s, M + 0.75, yb + 0.1, R - M - 0.8, 0.6, foot, Z('b'), P['ink'], 'md', an='m')


@reg
def ks_yearone(prs, d):
    """เงินปีแรก: แท่งแนวนอนเดียวแบ่งสองท่อน (ค่าระบบ / ค่าอุปกรณ์) มีป้ายบนท่อน ผลรวมตัวใหญ่ขวาบน · แผ่นสองแผ่นล่าง (ปีถัดไป / เฉลี่ยต่อสาขา)"""
    s = page(prs); chrome(s, d)
    y0 = title(s, d) + 0.3
    parts = d['parts']; tot = sum(v for _, v, _ in parts)
    txt(s, M, y0, 6, 0.42, d.get('cap', ''), Z('l'), P['mute'], 'md')
    txt(s, R - 5.0, y0 - 0.15, 5.0, 0.9, d['tot'], 54, P['acc'], 'bd', 'r')
    by = y0 + 0.95; bh = 1.5; bw = R - M; x = M
    for i, (lab, v, sub) in enumerate(parts):
        w = bw * v / tot
        f, c = (P['acc'], 'FFFFFF') if i == 0 else (P['b'], P['ink'])
        shp(s, 'rect', x, by, w - 0.04, bh, f)
        txt(s, x + 0.3, by + 0.18, w - 0.5, 0.42, lab, Z('l'), c, 'md')
        txt(s, x + 0.3, by + 0.62, w - 0.5, 0.75, v and f'{v:,}', 40, c, 'bd')
        T(s, x + 0.02, by + bh + 0.12, w - 0.1, 0.42, sub, Z('s'), P['mute'], 'rg')
        x += w
    cy = by + bh + 0.75; chh = H - 0.62 - cy
    cards = d.get('cards', [])[:2]; g = 0.3; cw = (R - M - g) / 2
    for i, (v, lab) in enumerate(cards):
        x = M + i * (cw + g)
        panel(s, x, cy, cw, chh)
        txt(s, x + 0.4, cy + 0.1, 2.5, chh - 0.2, v, 40, P['ink'], 'bd', an='m')
        T(s, x + 2.85, cy, cw - 3.0, chh, lab, Z('b'), P['mute'], 'md', an='m', sp=1.0)


@reg
def ks_pricetable(prs, d):
    """ตารางเทียบราคาสามแพ็ก รายเดือนกับรายปี: หัวคอลัมน์ แถวละแพ็ก แถวแนะนำพื้นเข้มตัวขาว คอลัมน์สุดท้าย (จ่ายรายปีหลังลด) ตัวหนาสีเน้น"""
    s = page(prs); chrome(s, d)
    y0 = title(s, d) + 0.35
    head = d['head']; rows = d['rows']; nc = len(head)
    c0w = 2.6; cw = (R - M - c0w) / (nc - 1)
    X = [M] + [M + c0w + i * cw for i in range(nc - 1)]
    for j, h_ in enumerate(head):
        T(s, X[j] + (0.3 if j == 0 else 0), y0, (c0w if j == 0 else cw) - 0.3, 0.85, h_, Z('s'), P['mute'], 'md',
          'l' if j == 0 else 'r', 'b', sp=1.0)
    _hair(s, M, y0 + 0.95, R, P['ink'], 1.25)
    rh = min(1.05, (H - 0.75 - y0 - 1.05 - (0.7 if d.get('note') else 0)) / len(rows))
    for i, r in enumerate(rows):
        y = y0 + 1.05 + i * rh; hot = r[-1]
        if hot: panel(s, M - 0.1, y + 0.03, R - M + 0.2, rh - 0.06, P['dk'], r=0.12)
        c = 'FFFFFF' if hot else P['ink']
        txt(s, X[0] + 0.3, y, c0w - 0.3, rh, r[0], Z('h2'), P['b'] if hot else c, 'bd', an='m')
        for j, v in enumerate(r[1:-1], 1):
            last = j == nc - 1
            txt(s, X[j], y, cw - 0.3, rh, v, Z('b') + (4 if last else 0), (P['b'] if hot else P['acc']) if last else c,
                'bd' if last or hot else 'rg', 'r', 'm')
        if not hot and i < len(rows) - 1 and not rows[i + 1][-1]: _hair(s, M, y + rh, R)
    if d.get('note'):
        T(s, M, H - 0.62 - 0.6, R - M, 0.55, d['note'], Z('b'), P['ink'], 'md', an='m')


@reg
def ks_offer(prs, d):
    """ปิดการขายแบบสรุปข้อเสนอ: แผงเข้มซ้าย (หัวเรื่อง) · การ์ดข้อเสนอขวา ชิปใหญ่สี่ช่อง (แพ็ก/สาขา/วัน/ราคา) + สามขั้นสั้นมีเลขวงกลม"""
    s = page(prs)
    lw_ = 5.0
    shp(s, 'rect', 0, 0, lw_, H, P['dk'])
    shp(s, 'rect', M, 2.0, 0.5, 0.06, P['b'])
    n = d['t'].count('\n') + 1
    T(s, M, 2.25, lw_ - M - 0.3, LH(Z('cov'), n, 1.02), d['t'], Z('cov'), 'FFFFFF', 'bd', sp=1.02, hc=P['b'])
    txt(s, M, H - 0.46, 5, 0.3, d.get('foot', ''), 11, 'FFFFFF', 'rg')
    if d.get('n'): txt(s, R - 1.0, H - 0.46, 1.0, 0.3, f"{int(d['n'])}", 11, P['mute'], 'md', 'r')
    x = lw_ + 0.55; w = R - x
    txt(s, x, TOP, w, 0.5, d.get('ok', 'ข้อเสนอ'), Z('l'), P['mute'], 'md')
    one = len(d['steps']) == 1
    chips = d['chips'][:4]; g = 0.2; cw = (w - g * (len(chips) - 1)) / len(chips); chh = 3.2 if one else 1.55
    for i, (v, lab) in enumerate(chips):
        cx = x + i * (cw + g); last = i == len(chips) - 1
        panel(s, cx, TOP + 0.5, cw, chh, P['b'] if last else P['panel'])
        txt(s, cx, TOP + 0.5 + chh / 2 - 0.7, cw, 0.8, v, 36, P['ink'] if last else P['acc'], 'bd', 'c')
        txt(s, cx, TOP + 0.5 + chh / 2 + 0.2, cw, 0.45, lab, Z('s'), P['ink'], 'md', 'c')
    y = TOP + 0.5 + chh + 0.45
    txt(s, x, y, w, 0.45, d.get('sk', 'เริ่มยังไง'), Z('l'), P['mute'], 'md')
    y += 0.55; steps = d['steps'][:3]; sh = min(1.1, (H - 0.62 - y - 0.2 * (len(steps) - 1)) / len(steps))
    for i, t in enumerate(steps):
        yy = y + i * (sh + 0.2)
        shp(s, 'round', x, yy, w, sh, 'FFFFFF', line=GREY, lw=1.25, adj=_adj(w, sh, 0.14))
        shp(s, 'oval', x + 0.3, yy + sh / 2 - 0.3, 0.6, 0.6, P['acc'])
        if one: icon(s, 'flag', x + 0.6, yy + sh / 2, 0.32, 'FFFFFF')
        else: txt(s, x + 0.3, yy + sh / 2 - 0.3, 0.6, 0.6, str(i + 1), Z('l'), 'FFFFFF', 'bd', 'c', 'm')
        T(s, x + 1.15, yy, w - 1.3, sh, t, Z('b'), P['ink'], 'md', an='m')
