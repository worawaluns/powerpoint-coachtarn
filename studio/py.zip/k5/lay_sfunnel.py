"""20 เลย์เอาต์ชุดกรวยการขาย & Pipeline พื้นขาว ชมพูกุหลาบ-เทาน้ำเงิน-ม่วง-เขียวน้ำทะเล-ส้มทอง — ลอกโครงจากชุด 242 salespipeline (ใบงาน 021)

ต้นฉบับ: .pptx ใน Downloads/02 Coach Tarn/By Coach Tarn/อัปขึ้น Drive 06 สีใหม่/242 ... (ไม่มีโค้ดเดิม k6 หาย)
หัวเรื่องกึ่งกลาง ขีดชมพูสั้นใต้หัว บล็อกไล่สีห้าเฉดตามลำดับ ไม่มีรูปถ่าย
สี: เขียว 14A38B / ส้ม E0901E ต้นฉบับกับตัวขาวไม่ผ่าน → 0E7A67 / B45309
ไม่วาดโดนัท/เกจ/กรวยที่บอกค่า (doc2slide ส่งจำนวนที่ไม่ใช่สัดส่วนมาได้ = กราฟหลอกตา) กรวยในชุดนี้เป็นรายการขั้นตอน ไม่มีตัวเลข
ทุกข้อความมาจาก d ไม่มีค่าตั้งต้นที่เป็นคำ ไม่มีเลข 01/02 ตกแต่ง
"""
from eng import *
import eng
from lay import L, reg

txt = txt_big
chart = chart_big
import base
from pptx.enum.shapes import MSO_SHAPE
base.KIND.setdefault('trap', MSO_SHAPE.TRAPEZOID)       # ใบงาน 021: กรวยต้องใช้สี่เหลี่ยมคางหมู ไม่แตะ base.py

eng.PAL.setdefault('sf_rose', dict(bg='FFFFFF', ink='1F2937', mute='5B6275', acc='C7285D', acc2='3B4256',
                                   g1='C7285D', g2='7C3AED', dark=0, panel='F6F3F7'))

M = 0.70
INK = '1F2937'
MU = '5B6275'
WH = 'FFFFFF'
PAN = 'F6F3F7'
LINE = 'E6E1E8'
RO, SL, VI, TE, AM = 'C7285D', '3B4256', '7C3AED', '0E7A67', 'B45309'
SEQC = [RO, SL, VI, TE, AM]
LIGHT = {RO: 'E0517F', SL: '5A627A', VI: '9B6BF2', TE: '23A58C', AM: 'D9822B'}


def _c(i): return SEQC[i % len(SEQC)]
def _g(c, ang=90): return (LIGHT[c], c, ang)


def _hd(s, d, y=0.50):
    txt(s, M, y, W - M * 2, 0.66, d['t'], 28, INK, 'md', 'c')
    if d.get('s'): txt(s, 2.0, y + 0.68, W - 4.0, 0.46, d['s'], 13, MU, 'rg', 'c')
    shp(s, 'rect', W / 2 - 0.30, y + 1.24, 0.60, 0.05, RO)


def _p(s, x, y, w, t, sz=12.5, c=MU, h=1.0, al='l'):
    if t: txt(s, x, y, w, h, t, sz, c, 'rg', al, sp=1.25)


# ══ ปก / สารบัญ / คั่น / ข้อความ / ปิด ═══════════════════════════════════

@reg
def sf_cover(prs, d):
    s = page(prs, WH)
    shp(s, 'rect', 0, 0, 7.80, H, grad=(RO, 'A3204C', 90))
    for i in range(6):
        ln(s, 0.70, 1.0 + i * 0.12, 3.4, 1.0 + i * 0.12, WH, 0.6)
    txt(s, 0.90, 1.90, 6.4, 2.6, d['t'], d.get('tsz', 42), WH, 'md', sp=1.08)
    _p(s, 0.90, 4.70, 6.0, d.get('s', ''), 16, WH, h=1.6)
    for i, c in enumerate(SEQC[:4]):                       # กรวยตกแต่ง (ไม่มีคำ ไม่มีค่า)
        w = 4.0 - i * 0.75
        shp(s, 'trap', 8.55 + (4.0 - w) / 2, 1.40 + i * 1.15, w, 0.95, grad=_g(c, 0), rot=180)


@reg
def sf_agenda(prs, d):
    s = page(prs, WH)
    _hd(s, d)
    it = d['items'][:6]
    rh = min(0.82, 4.9 / max(len(it), 1))
    for i, t in enumerate(it):
        y = 2.00 + i * rh; c = _c(i)
        shp(s, 'round', 2.4, y, 0.16, rh - 0.18, c, adj=0.5)
        txt(s, 2.85, y, W - 5.2, rh - 0.18, t, 17, INK, 'md', an='m')
        ln(s, 2.85, y + rh - 0.08, W - 2.4, y + rh - 0.08, LINE, 0.7)


@reg
def sf_div(prs, d):
    s = page(prs, WH)
    shp(s, 'rect', 0, 0, W, H, grad=(SL, '252A3A', 90))
    shp(s, 'rect', M, 3.05, 1.10, 0.08, RO)
    txt(s, M, 1.60, 9.5, 1.40, d['t'], 44, WH, 'md')
    _p(s, M, 3.40, 8.5, d.get('s', ''), 16, 'D5D8E2', h=1.4)


@reg
def sf_statement(prs, d):
    s = page(prs, PAN)
    shp(s, 'oval', M, 1.25, 0.80, 0.80, RO)
    icon(s, 'chevrons-up', M + 0.40, 1.65, 0.42, WH)
    txt(s, M, 2.30, W - M * 2 - 1.0, 2.60, d['t'], 34, INK, 'md', sp=1.12)
    _p(s, M, 5.05, 10.0, d.get('s', ''), 15, MU, h=1.4)


@reg
def sf_close(prs, d):
    s = page(prs, WH)
    shp(s, 'rect', 0, H - 0.40, W, 0.40, grad=(RO, VI, 0))
    txt(s, M, 2.40, W - M * 2, 1.30, d['t'], 44, INK, 'md', 'c')
    _p(s, 2.0, 3.80, W - 4.0, d.get('s', ''), 15, MU, h=1.4, al='c')


# ══ รายการ / หัวข้อคู่คำอธิบาย / ลำดับ ═════════════════════════════════════

@reg
def sf_funnel(prs, d):
    """ขั้นตอนเรียงเป็นกรวย (ไม่มีตัวเลข ความกว้างเป็นของตกแต่ง)"""
    s = page(prs, WH)
    _hd(s, d)
    it = d['items'][:5]; n = max(len(it), 1)
    rh = min(0.95, 4.7 / n)
    for i, t in enumerate(it):
        w = 7.6 - i * (3.6 / max(n - 1, 1)); x = (W - w) / 2; y = 2.05 + i * rh; c = _c(i)
        shp(s, 'trap', x, y, w, rh - 0.10, grad=_g(c, 0), rot=180, adj=0.12)
        txt(s, x + 0.5, y, w - 1.0, rh - 0.10, t, 15, WH, 'md', 'c', 'm')


@reg
def sf_pairs3(prs, d):
    s = page(prs, WH)
    _hd(s, d)
    it = d['items'][:3]; n = max(len(it), 1)
    gap = 0.30; cw = (W - M * 2 - gap * (n - 1)) / n
    for i, (h_, body) in enumerate(it):
        x = M + i * (cw + gap); c = _c(i)
        shp(s, 'round', x, 2.10, cw, 4.55, PAN, adj=0.06)
        shp(s, 'rect', x, 2.10, cw, 0.12, c)
        txt(s, x + 0.35, 2.55, cw - 0.7, 0.80, h_, 18, INK, 'md', sp=1.1)
        _p(s, x + 0.35, 3.50, cw - 0.7, body, 13.5, MU, h=2.9)


@reg
def sf_voices(prs, d):
    s = page(prs, WH)
    _hd(s, d)
    it = d['items'][:3]; n = max(len(it), 1)
    gap = 0.30; cw = (W - M * 2 - gap * (n - 1)) / n
    for i, (say, who) in enumerate(it):
        x = M + i * (cw + gap); c = _c(i)
        shp(s, 'round', x, 2.10, cw, 4.55, mix(c, WH, 0.90), adj=0.06)
        shp(s, 'oval', x + 0.35, 2.40, 0.56, 0.56, c)
        icon(s, 'message-circle', x + 0.63, 2.68, 0.30, WH)
        txt(s, x + 0.35, 3.20, cw - 0.7, 2.60, say, 14, INK, 'rg', sp=1.3)
        txt(s, x + 0.35, 5.95, cw - 0.7, 0.40, who, 12.5, c, 'md')


@reg
def sf_actions(prs, d):
    s = page(prs, WH)
    _hd(s, d)
    it = d['items'][:6]; n = len(it)
    cols = 3 if n in (3, 5, 6) else 2
    rows = -(-n // cols)
    gap = 0.26; cw = (W - M * 2 - gap * (cols - 1)) / cols; ch = (4.65 - gap * (rows - 1)) / max(rows, 1)
    for i, (h_, body) in enumerate(it):
        x = M + (i % cols) * (cw + gap); y = 2.05 + (i // cols) * (ch + gap); c = _c(i)
        shp(s, 'round', x, y, cw, ch, WH, line=LINE, adj=0.08)
        shp(s, 'oval', x + 0.28, y + 0.28, 0.46, 0.46, mix(c, WH, 0.82))
        shp(s, 'oval', x + 0.42, y + 0.42, 0.18, 0.18, c)
        txt(s, x + 0.95, y + 0.24, cw - 1.2, 0.56, h_, 15, INK, 'md', an='m')
        _p(s, x + 0.28, y + 0.90, cw - 0.56, body, 12.5, MU, h=max(ch - 1.0, 0.4))


@reg
def sf_compare2(prs, d):
    s = page(prs, WH)
    _hd(s, d)
    cw = (W - M * 2 - 0.40) / 2
    for i, (h_, lst) in enumerate(d['items'][:2]):
        x = M + i * (cw + 0.40); c = RO if i == 0 else SL
        shp(s, 'round', x, 2.05, cw, 0.75, c, adj=0.20)
        txt(s, x + 0.35, 2.05, cw - 0.7, 0.75, h_, 17, WH, 'md', an='m')
        for j, t in enumerate(lst[:5]):
            y = 3.00 + j * 0.74
            shp(s, 'oval', x + 0.30, y + 0.22, 0.18, 0.18, c)
            txt(s, x + 0.70, y, cw - 1.0, 0.62, t, 14, INK, 'rg', an='m')
            ln(s, x + 0.30, y + 0.68, x + cw - 0.30, y + 0.68, LINE, 0.7)


@reg
def sf_timeline_pins(prs, d):
    s = page(prs, WH)
    _hd(s, d)
    it = d['items'][:5]; n = max(len(it), 1)
    y0 = 4.30; cw = (W - M * 2) / n
    ln(s, M, y0, W - M, y0, LINE, 1.6, dash=True)
    for i, (per, h_, body) in enumerate(it):
        cx = M + cw * (i + 0.5); c = _c(i); up = i % 2 == 0
        shp(s, 'oval', cx - 0.09, y0 - 0.09, 0.18, 0.18, c)
        py = y0 - 0.95 if up else y0 + 0.30
        shp(s, 'tear', cx - 0.32, py, 0.64, 0.64, grad=_g(c), rot=135 if up else 315)
        ty = 2.00 if up else 5.35
        txt(s, cx - cw / 2 + 0.08, ty, cw - 0.16, 0.32, per, 13, c, 'md', 'c')
        txt(s, cx - cw / 2 + 0.08, ty + 0.34, cw - 0.16, 0.36, h_, 14, INK, 'md', 'c')
        _p(s, cx - cw / 2 + 0.08, ty + 0.70, cw - 0.16, body, 12, h=0.6, al='c')


@reg
def sf_timeline_stairs(prs, d):
    s = page(prs, WH)
    _hd(s, d)
    it = d['items'][:4]; n = max(len(it), 1)
    gap = 0.24; cw = (W - M * 2 - gap * (n - 1)) / n
    for i, (per, h_, body) in enumerate(it):
        x = M + i * (cw + gap); c = _c(i); h = 1.50 + i * 0.85; y = H - 0.55 - h
        shp(s, 'rect', x, y, cw, h, grad=_g(c))
        txt(s, x + 0.25, y + 0.15, cw - 0.5, 0.32, per, 13, WH, 'md')
        txt(s, x + 0.25, y + 0.48, cw - 0.5, 0.40, h_, 15, WH, 'md')
        _p(s, x + 0.25, y + 0.92, cw - 0.5, body, 12, WH, h=max(h - 1.0, 0.4))


# ══ ตัวเลข ═════════════════════════════════════════════════════════════════

@reg
def sf_band4(prs, d):
    s = page(prs, WH)
    _hd(s, d)
    it = d['items'][:4]; n = max(len(it), 1)
    shp(s, 'round', M, 2.30, W - M * 2, 2.50, grad=(RO, SL, 0), adj=0.06)
    cw = (W - M * 2) / n
    for i, (v, lab) in enumerate(it):
        x = M + i * cw
        if i: ln(s, x, 2.70, x, 4.40, WH, 0.8)
        txt(s, x + 0.2, 2.75, cw - 0.4, 0.90, v, 34, WH, 'md', 'c')
        _p(s, x + 0.25, 3.75, cw - 0.5, lab, 13, WH, h=0.9, al='c')
    _p(s, M, 5.10, W - M * 2, d.get('note', ''), 13, MU, h=1.2)


@reg
def sf_coins(prs, d):
    s = page(prs, WH)
    _hd(s, d)
    it = d['items'][:4]; n = max(len(it), 1)
    cw = (W - M * 2) / n
    for i, (v, lab) in enumerate(it):
        cx = M + cw * (i + 0.5); c = _c(i)
        shp(s, 'oval', cx - 0.75, 2.20, 1.50, 1.50, grad=_g(c, 45))
        shp(s, 'oval', cx - 0.55, 2.40, 1.10, 1.10, None, line=WH, lw=1.5)
        txt(s, cx - cw / 2 + 0.1, 3.95, cw - 0.2, 0.70, v, 30, c, 'md', 'c')
        _p(s, cx - cw / 2 + 0.2, 4.70, cw - 0.4, lab, 13, MU, h=1.6, al='c')


@reg
def sf_kpi_cards(prs, d):
    s = page(prs, WH)
    _hd(s, d)
    it = d['items'][:4]; n = max(len(it), 1)
    gap = 0.26; cw = (W - M * 2 - gap * (n - 1)) / n
    for i, (v, lab) in enumerate(it):
        x = M + i * (cw + gap); c = _c(i)
        shp(s, 'round', x, 2.15, cw, 4.40, WH, line=LINE, adj=0.06)
        txt(s, x + 0.30, 2.45, cw - 0.6, 0.40, lab, 13, MU, 'rg')
        txt(s, x + 0.30, 2.95, cw - 0.6, 0.90, v, 34, INK, 'md')
        shp(s, 'rect', x + 0.30, 4.10, cw - 0.6, 0.06, grad=_g(c, 0))


# ══ ตาราง / กราฟจริง ═══════════════════════════════════════════════════════

@reg
def sf_table(prs, d):
    s = page(prs, WH)
    _hd(s, d)
    head, rows = d['head'], d['rows'][:6]
    nc = len(head); tw = W - M * 2
    cols = d.get('colw') or [1] * nc; tot = sum(cols); cols = [c / tot for c in cols]
    al = d.get('al') or ['l'] * nc
    y0, hh = 2.10, 0.54
    rh = min(0.60, 4.4 / max(len(rows), 1))
    shp(s, 'rect', M, y0, tw, hh, grad=(RO, 'A3204C', 0))
    cx = M
    for j, (hd, fr) in enumerate(zip(head, cols)):
        txt(s, cx + 0.18, y0, tw * fr - 0.36, hh, hd, 13.5, WH, 'md', al[j] if j < len(al) else 'l', 'm'); cx += tw * fr
    for i, row in enumerate(rows):
        y = y0 + hh + i * rh
        shp(s, 'rect', M, y, tw, rh, PAN if i % 2 else WH)
        cx = M
        for j, (cell, fr) in enumerate(zip(row, cols)):
            txt(s, cx + 0.18, y, tw * fr - 0.36, rh, cell, 13, INK, 'md' if j == 0 else 'rg', al[j] if j < len(al) else 'l', 'm'); cx += tw * fr
    if d.get('note'): _p(s, M, y0 + hh + len(rows) * rh + 0.18, 10, d['note'], 12, h=0.6)


@reg
def sf_chart_col(prs, d):
    s = page(prs, WH)
    _hd(s, d)
    n = len(d['vals'])
    chart(s, 'col', M, 2.05, W - M * 2, 4.85, d['cats'], [(d.get('sname', ''), d['vals'])], [_c(i) for i in range(n)],
          labels=True, fmt='#,##0.##', gap=60, sz=12, c=INK, vary=True)


@reg
def sf_chart_bar(prs, d):
    s = page(prs, WH)
    _hd(s, d)
    n = len(d['vals'])
    chart(s, 'bar', M, 2.05, W - M * 2, 4.85, d['cats'], [(d.get('sname', ''), d['vals'])], [_c(i) for i in range(n)],
          labels=True, fmt='#,##0.##', gap=55, sz=12, c=INK, vary=True)


@reg
def sf_chart_line(prs, d):
    s = page(prs, WH)
    _hd(s, d)
    ser = d['series']
    chart(s, 'line', M, 2.05, W - M * 2, 4.85, d['cats'], ser, [RO, SL, VI, TE][:len(ser)], labels=False, fmt='#,##0.##',
          legend=len(ser) > 1, sz=12, c=INK, grid=True, lw=3)


@reg
def sf_chart_stack(prs, d):
    s = page(prs, WH)
    _hd(s, d)
    ser = d['series']
    chart(s, 'colS', M, 2.05, W - M * 2, 4.85, d['cats'], ser, [RO, SL, VI, TE, AM][:len(ser)], labels=True, fmt='#,##0.##',
          legend=True, gap=80, overlap=100, sz=12, c=INK, lblc=WH)
