"""20 เลย์เอาต์ชุดรายงานแคมเปญ ฟ้า+ครีม — ลอกโครงจากเทมเพลต Gloss Motion (Strategic Proposal)

พื้นครีมอุ่น การ์ดครีมมนมุมเล็กวางบนรูปเต็มหน้า รูปทั้งชุดย้อมโทนน้ำเงิน-ครีม
หัวกระดาษสามช่องตัวเล็ก (ประเภทเอกสาร · แบรนด์ · ปี) หัวเรื่องน้ำเงินเข้มน้ำหนักกลาง วลีเน้นเป็นสีฟ้า
การ์ดตัวเลขขาวเรียงแถวบนรูป ม็อกอัปมือถือ รูปครอปวงรี ป้ายแคปซูลกรมท่า
ฟ้า 5E8FD6 บนครีม/ขาวไม่ผ่านกับตัวเล็ก ใช้น้ำเงิน 2F5FA8 (5.57) กับตัวหนังสือ ฟ้าใช้กับพื้นที่และตัวใหญ่เท่านั้น
"""
from eng import *
import eng
from lay import L, reg
from pptx.enum.chart import XL_LABEL_POSITION

txt = txt_big        # ขนาดขั้นต่ำตามชุด 366 ดู eng.roomy()
chart = chart_big

M = 0.62
CR = 'F6F0E6'
CARD = 'FBF8F2'
INK = '1F2B45'
MUTE = '5E6577'
BL = '2F5FA8'
SKY = '5E8FD6'
LINE = 'DCD4C6'


def _duo(): return "duo:14254A:F3ECDF"


def _photo(s, n, x, y, w, h, adj=None, focus=(0.5, 0.4), geom=None):
    g = geom or ('roundRect' if adj else None)
    return pic(s, ph('beauty', n), x, y, w, h, geom=g, adj=adj, focus=focus, mode=_duo())


def _chrome(s, d, light=False):
    c = 'FFFFFF' if light else MUTE
    txt(s, M, 0.30, 3.2, 0.28, d.get('doc', 'รายงานแคมเปญ'), 9, c, 'md')
    txt(s, W / 2 - 1.5, 0.30, 3.0, 0.28, d.get('brand', 'แบรนด์ของคุณ'), 9, c, 'md', 'c')
    txt(s, W - M - 1.5, 0.30, 1.5, 0.28, d.get('yr', '2570'), 9, c, 'md', 'r')
    ln(s, M, 0.68, W - M, 0.68, 'FFFFFF' if light else LINE, 0.6)


def _h(s, x, y, t, sz=34, w=6.0, c=None, al='l', hi=None):
    """หัวเรื่อง บรรทัดที่ขึ้นต้นด้วย * เป็นสีฟ้า/น้ำเงิน แทนตัวเอียงของต้นฉบับ"""
    c = c or INK
    runs = []
    for line in t.split('\n'):
        star = line.startswith('*')
        runs.append([(line.lstrip('*'), {'c': (hi or BL) if star else c})])
    txt(s, x, y, w, 2.6, '', sz, c, 'md', al, sp=1.04, runs=runs)


def _p(s, x, y, w, t, sz=11, c=None, al='l'):
    if t: txt(s, x, y, w, 2.0, t, sz, c or MUTE, 'rg', al, sp=1.38)


def _card(s, x, y, w, h, f=CARD, adj=0.04):
    return shp(s, 'round', x, y, w, h, f, adj=adj)


def _pill(s, x, y, t, f=INK, c='FFFFFF'):
    w = len(t) * 0.10 + 0.40
    shp(s, 'round', x, y, w, 0.34, f, adj=0.5)
    txt(s, x, y, w, 0.34, t, 9.5, c, 'md', 'c', 'm')


def _full(s, n, a=0.25, focus=(0.5, 0.35)):
    _photo(s, n, 0, 0, W, H, focus=focus)
    if a: shp(s, 'rect', 0, 0, W, H, '14254A', a=a)


# ══ เลย์เอาต์ตามรูปอ้างอิง ═════════════════════════════════════════════════

@reg
def gl_cover(prs, d):
    s = page(prs, '14254A')
    _photo(s, d.get('pi', 0), 0, 0, 9.20, H, focus=(0.5, 0.3))
    gradband(s, 0, 0, 6.0, H, 0, c1='14254A', c2='14254A', a1=0.75, a2=0.0)
    shp(s, 'rect', 9.20, 0, W - 9.20, H, BL)
    _chrome(s, d, True)
    _h(s, M, 2.30, d['t'], 50, 7.6, 'FFFFFF', hi='CFE0F7')
    _p(s, 9.60, 1.30, 3.2, d.get('s', ''), 13, 'F3ECDF')
    txt(s, M, H - 0.75, 3.0, 0.30, d.get('yr', '2570'), 10, 'F3ECDF', 'md')
    for i, (v, lab) in enumerate(d['items'][:2]):
        y = 4.40 + i * 1.30
        txt(s, 9.60, y, 3.2, 0.62, v, 28, 'FFFFFF', 'md')
        _p(s, 9.60, y + 0.62, 3.2, lab, 10.5, 'DCE7F7')


@reg
def gl_deliver(prs, d):
    s = page(prs, CR)
    _chrome(s, d)
    _h(s, M, 1.05, d['t'], 34, 9.0)
    _photo(s, d.get('pi', 8), M, 2.25, 4.60, 4.70, 0.03)
    for i, t in enumerate(d['items'][:5]):
        y = 2.30 + i * 0.94
        shp(s, 'oval', 5.75, y + 0.14, 0.12, 0.12, BL)
        _p(s, 6.05, y, 6.6, t, 12, INK)
        if i < 4: ln(s, 6.05, y + 0.80, W - M, y + 0.80, LINE, 0.6)


@reg
def gl_feed(prs, d):
    s = page(prs, CR)
    _chrome(s, d)
    _card(s, M, 1.00, W - M * 2, 5.95, 'FFFFFF', 0.03)
    _h(s, M + 0.40, 1.40, d['t'], 36, 6.0)
    _p(s, M + 0.40, 3.30, 5.6, d.get('note', ''), 12, INK)
    _p(s, M + 0.40, 4.55, 5.6, d.get('note2', ''), 10.5)
    _pill(s, M + 0.40, 6.25, d.get('k', 'ดูผลงาน'))
    shp(s, 'round', 7.30, 1.30, W - M - 7.70, 5.35, CARD, adj=0.03)
    x, y, w, h = 8.95, 1.65, 2.40, 4.70
    shp(s, 'round', x, y, w, h, '111111', adj=0.14)
    _photo(s, d.get('pi', 4), x + 0.10, y + 0.10, w - 0.20, h - 0.20, 0.12, (0.5, 0.3))
    shp(s, 'round', x + w / 2 - 0.40, y + 0.20, 0.80, 0.16, '111111', adj=0.5)


@reg
def gl_numbers(prs, d):
    s = page(prs)
    _full(s, d.get('pi', 2), 0.60)
    _chrome(s, d, True)
    _h(s, 0, 1.15, d['t'], 36, W, 'FFFFFF', 'c', hi='CFE0F7')
    cw = (W - M * 2 - 0.45) / 4
    for i, (v, lab) in enumerate(d['items'][:4]):
        x = M + i * (cw + 0.15)
        _card(s, x, 3.30, cw, 3.10, 'FFFFFF', 0.03)
        txt(s, x + 0.25, 3.50, cw - 0.5, 0.80, v, 32, INK, 'md')
        _p(s, x + 0.25, 5.10, cw - 0.5, lab, 10.5)


@reg
def gl_needs(prs, d):
    s = page(prs, CR)
    _chrome(s, d)
    _h(s, M, 1.10, d['t'], 36, 7.0)
    _p(s, M, 2.70, 6.8, d.get('note', ''), 12)
    _pill(s, M, 5.60, d.get('k', ''))
    _photo(s, d.get('pi', 7), 8.30, 1.00, 4.40, 2.85, geom='ellipse', focus=(0.5, 0.3))
    _photo(s, d.get('pi2', 10), 8.30, 4.05, 4.40, 2.85, geom='ellipse', focus=(0.5, 0.5))


@reg
def gl_services(prs, d):
    s = page(prs, CR)
    _chrome(s, d)
    _photo(s, d.get('pi', 1), M, 1.00, 5.00, 5.95, 0.03, (0.5, 0.3))
    _h(s, 6.10, 1.10, d['t'], 34, 6.5)
    for i, (h_, body) in enumerate(d['items'][:3]):
        y = 2.55 + i * 1.45
        shp(s, 'oval', 6.10, y + 0.12, 0.12, 0.12, BL)
        txt(s, 6.40, y, 6.0, 0.36, h_, 13, BL, 'md')
        _p(s, 6.40, y + 0.42, 6.2, body, 11)


@reg
def gl_vision(prs, d):
    s = page(prs)
    _full(s, d.get('pi', 5), 0.10, (0.4, 0.4))
    _card(s, 7.70, 0.55, W - 7.70 - 0.40, H - 1.10, CARD, 0.03)
    _h(s, 8.10, 0.95, d['t'], 40, 4.6)
    txt(s, 8.10, 4.10, 4.4, 0.30, d.get('k', ''), 10.5, BL, 'md')
    _p(s, 8.10, 4.50, 4.4, d.get('note', ''), 12, INK)


@reg
def gl_banner(prs, d):
    s = page(prs)
    _full(s, d.get('pi', 9), 0.45, (0.5, 0.5))
    _chrome(s, d, True)
    shp(s, 'rect', 3.60, 1.45, 6.10, 3.75, 'FFFFFF')
    _photo(s, d.get('pi2', 6), 3.72, 1.57, 5.86, 3.51, focus=(0.5, 0.35))
    _p(s, 2.6, 5.55, W - 5.2, d['t'], 15, 'FFFFFF', 'c')


@reg
def gl_story(prs, d):
    s = page(prs, CR)
    _chrome(s, d)
    _card(s, M, 1.00, W - M * 2, 5.95, 'FFFFFF', 0.03)
    _photo(s, d.get('pi', 11), M + 0.30, 1.30, W - M * 2 - 0.60, 3.40, 0.03, (0.5, 0.35))
    _h(s, M + 0.30, 5.00, d['t'], 34, 6.0)
    _p(s, 7.40, 5.05, 5.0, d.get('note', ''), 11.5)


@reg
def gl_apart(prs, d):
    s = page(prs)
    _full(s, d.get('pi', 3), 0.58, (0.5, 0.3))
    _chrome(s, d, True)
    _h(s, M, 1.00, d['t'], 40, 9.0, 'FFFFFF', hi='CFE0F7')
    cw = (W - M * 2 - 0.45) / 4
    for i, (h_, body) in enumerate(d['items'][:4]):
        x = M + i * (cw + 0.15)
        _card(s, x, 4.45, cw, 2.40, CARD, 0.03)
        txt(s, x + 0.25, 4.65, cw - 0.5, 0.40, h_, 14, INK, 'md')
        _p(s, x + 0.25, 5.25, cw - 0.5, body, 10.5)


@reg
def gl_team(prs, d):
    s = page(prs, CR)
    _chrome(s, d)
    _h(s, 0, 1.05, d['t'], 36, W, al='c')
    _p(s, 2.5, 2.45, W - 5.0, d.get('note', ''), 11.5, al='c')
    n = len(d['items'][:5]); cw = 2.10; gap = 0.22
    x0 = (W - n * cw - (n - 1) * gap) / 2
    for i, (name, role, pi) in enumerate(d['items'][:5]):
        x = x0 + i * (cw + gap)
        pic(s, ph('office', pi), x, 3.35, cw, 2.50, geom='roundRect', adj=0.06, focus=(0.5, 0.3), mode=_duo())
        txt(s, x, 6.00, cw, 0.36, name, 13, INK, 'md', 'c')
        txt(s, x, 6.38, cw, 0.32, role, 10.5, BL, 'md', 'c')


@reg
def gl_shine(prs, d):
    s = page(prs, CR)
    _chrome(s, d)
    _h(s, 0, 1.05, d['t'], 36, W, al='c')
    pos = [(1.30, 2.70), (4.05, 2.35), (6.80, 2.70), (9.55, 2.35)]
    for (x, y), (n, cap) in zip(pos, d['items'][:4]):
        _photo(s, n, x, y, 2.50, 3.60, 0.03, (0.5, 0.3))
        txt(s, x, y + 3.72, 2.50, 0.34, cap, 11, INK, 'md', 'c')


# ══ อีก 8 เลย์เอาต์ในระบบเดียวกัน ═════════════════════════════════════════

@reg
def gl_toc(prs, d):
    s = page(prs, CR)
    _chrome(s, d)
    _h(s, M, 1.05, d['t'], 40, 5.0)
    _photo(s, d.get('pi', 2), M, 3.10, 4.40, 3.85, 0.03, (0.5, 0.3))
    for i, (no, t) in enumerate(d['items'][:6]):
        y = 1.10 + i * 0.97
        ln(s, 5.80, y + 0.88, W - M, y + 0.88, LINE, 0.8)
        txt(s, 5.80, y + 0.18, 1.0, 0.50, no, 15, BL, 'md')
        txt(s, 6.90, y + 0.12, 5.8, 0.60, t, 18, INK, 'md')


@reg
def gl_chart_channel(prs, d):
    s = page(prs, CR)
    _chrome(s, d)
    _h(s, M, 1.05, d['t'], 34, 5.0)
    _p(s, M, 2.65, 4.4, d.get('note', ''), 11.5)
    _card(s, M, 4.35, 4.40, 2.60, BL, 0.04)
    txt(s, M + 0.30, 4.55, 3.8, 0.80, d['big'], 36, 'FFFFFF', 'md')
    _p(s, M + 0.30, 5.45, 3.8, d['biglab'], 10.5, 'DCE7F7')
    _card(s, 5.40, 1.00, W - M - 5.40, 5.95, 'FFFFFF', 0.03)
    n = len(d['vals'])
    chart(s, 'bar', 5.65, 1.20, W - M - 5.90, 5.55, d['cats'], [(d['sname'], d['vals'])],
          ['C9D6EA'] * (n - 1) + [BL], labels=True, fmt='0.0', gap=45, sz=12, c=INK, vary=True)


@reg
def gl_chart_trend(prs, d):
    s = page(prs)
    _full(s, d.get('pi', 12), 0.72, (0.5, 0.5))
    _chrome(s, d, True)
    _h(s, M, 1.00, d['t'], 34, 8.0, 'FFFFFF')
    _card(s, M, 2.10, 8.30, 4.85, CARD, 0.03)
    chart(s, 'line', M + 0.20, 2.30, 7.90, 4.50, d['cats'], [(d['sname'], d['vals'])], [BL], labels=True,
          fmt='0.00', sz=10.5, c=INK, lw=3, minv=0, lblpos=XL_LABEL_POSITION.ABOVE)
    for i, (v, lab) in enumerate(d['items'][:3]):
        y = 2.10 + i * 1.65
        _card(s, 9.15, y, W - M - 9.15, 1.50, 'FFFFFF', 0.04)
        txt(s, 9.40, y + 0.15, 3.2, 0.62, v, 26, INK, 'md')
        _p(s, 9.40, y + 0.82, 3.2, lab, 10.5)


@reg
def gl_budget(prs, d):
    s = page(prs, CR)
    _chrome(s, d)
    _h(s, M, 1.05, d['t'], 34, 7.0)
    cols = [BL, INK, SKY, 'C9D6EA']
    it = d['items'][:4]
    chart(s, 'donut', 0.60, 2.25, 4.60, 4.60, [x[0] for x in it], [('ร้อยละ', [x[2] for x in it])], cols, labels=False, hole=60)
    txt(s, 0.60, 4.15, 4.60, 0.60, d['big'], 26, INK, 'md', 'c')
    txt(s, 0.60, 4.75, 4.60, 0.30, d['biglab'], 10.5, MUTE, 'rg', 'c')
    for i, (lab, v, pct, body) in enumerate(it):
        y = 2.20 + i * 1.18
        _card(s, 5.80, y, W - M - 5.80, 1.02, 'FFFFFF', 0.10)
        shp(s, 'rect', 6.05, y + 0.38, 0.26, 0.26, cols[i])
        txt(s, 6.55, y + 0.12, 3.6, 0.40, lab, 14, INK, 'md')
        _p(s, 6.55, y + 0.54, 3.8, body, 10.5)
        txt(s, 10.10, y + 0.12, 1.50, 0.80, v, 15, INK, 'md', 'r', 'm')
        txt(s, 11.65, y + 0.12, 0.85, 0.80, f'{pct}%', 14, BL, 'md', 'r', 'm')


@reg
def gl_table(prs, d):
    s = page(prs, CR)
    _chrome(s, d)
    _h(s, M, 1.05, d['t'], 34, 9.0)
    cols = d['colw']; tw = W - M * 2; y0 = 2.20; rh = 0.78
    xs = [M]
    for f in cols[:-1]: xs.append(xs[-1] + tw * f)
    shp(s, 'rect', M, y0, tw, 0.60, INK)
    for j, hd in enumerate(d['head']):
        txt(s, xs[j] + 0.22, y0, tw * cols[j] - 0.44, 0.60, hd, 12, 'FFFFFF', 'md', 'l' if j == 0 else 'c', 'm')
    for i, row in enumerate(d['rows']):
        y = y0 + 0.60 + i * rh
        shp(s, 'rect', M, y, tw, rh, 'FFFFFF' if i % 2 == 0 else CARD)
        for j, cell in enumerate(row):
            last = j == len(row) - 1
            txt(s, xs[j] + 0.22, y, tw * cols[j] - 0.44, rh, cell, 12.5 if j == 0 else 12,
                BL if last else INK, 'md' if (j == 0 or last) else 'rg', 'l' if j == 0 else 'c', 'm')
    _p(s, M, y0 + 0.60 + len(d['rows']) * rh + 0.18, 11.5, d.get('note', ''), 10.5)


@reg
def gl_div(prs, d):
    s = page(prs, BL)
    _photo(s, d.get('pi', 0), 7.20, 0, W - 7.20, H, focus=(0.5, 0.3))
    _chrome(s, d, True)
    txt(s, M, 2.30, 4.0, 0.36, d.get('k', ''), 12, 'DCE7F7', 'md')
    _h(s, M, 2.75, d['t'], 48, 6.4, 'FFFFFF', hi='CFE0F7')
    _p(s, M, 5.00, 6.0, d.get('note', ''), 12.5, 'F3ECDF')


@reg
def gl_quote(prs, d):
    s = page(prs, CR)
    _chrome(s, d)
    _photo(s, d.get('pi', 7), W - M - 4.40, 1.00, 4.40, 5.95, 0.03, (0.5, 0.3))
    icon(s, 'quote', M + 0.40, 1.60, 0.80, BL)
    txt(s, M, 2.30, 7.4, 3.0, d['t'], 22, INK, 'md', sp=1.32)
    ln(s, M, 5.55, M + 0.80, 5.55, BL, 2)
    txt(s, M, 5.75, 7.0, 0.40, d['who'], 15, INK, 'md')
    _p(s, M, 6.15, 7.4, d['role'], 11.5)


@reg
def gl_close(prs, d):
    s = page(prs)
    _full(s, d.get('pi', 1), 0.40, (0.5, 0.3))
    _chrome(s, d, True)
    _card(s, 0.70, 1.20, 5.80, 5.20, CARD, 0.03)
    _h(s, 1.10, 1.60, d['t'], 44, 5.2)
    _p(s, 1.10, 3.60, 5.0, d.get('note', ''), 12, INK)
    for i, (lab, v) in enumerate(d['items'][:3]):
        y = 4.60 + i * 0.50
        txt(s, 1.10, y, 1.5, 0.36, lab, 11, MUTE, 'rg')
        txt(s, 2.60, y, 3.8, 0.36, v, 12.5, INK, 'md')
