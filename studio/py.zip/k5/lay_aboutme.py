"""20 เลย์เอาต์ชุดแนะนำตัว ชมพู+เบอร์กันดี+ครีม — ลอกโครงจากเทมเพลต About Me (ชมพูหวาน)

พื้นชมพูอ่อน ลายทางตั้งชมพูสลับครีม แฟ้มมีแถบหัว กรอบรูปหัวใจแบบล็อกเก็ต ดาวกระจาย
แถบฟิล์มรูปขอบแสตมป์ โพลารอยด์เอียงมีคลิปหนีบ ป้ายแคปซูลชมพู การ์ดรูปหัวใจ การ์ดขอบหยัก
หัวเรื่องเบอร์กันดีตัวหนาแทนตัวเขียนลายมือของต้นฉบับ (ฟอนต์ใช้ได้แค่สามตัว)
เบอร์กันดีบนชมพูอ่อน 8.25 บนครีม 9.57 ตัวหนังสือทั้งชุดใช้เบอร์กันดีหรือเทาชมพูเข้ม
"""
from eng import *
import eng
from lay import L, reg

txt = txt_big        # ขนาดขั้นต่ำตามชุด 366 ดู eng.roomy()
chart = chart_big

M = 0.62
PK = 'FBE1E7'          # ชมพูอ่อน
PK2 = 'F4B9C7'         # ชมพูกลาง
CR = 'FFF7EC'          # ครีม
BU = '7A1E35'          # เบอร์กันดี
MUTE = '6E4A55'
SILV = 'C9C3C6'


def _duo(): return "duo:4A1222:FCE9EE"


def _photo(s, n, x, y, w, h, geom='rect', adj=None, focus=(0.5, 0.3)):
    return pic(s, ph('aboutme', n), x, y, w, h, geom=geom, adj=adj, focus=focus, mode=_duo())


def _stripes(s, x, y, w, h, a=PK, b=CR, step=0.42):
    shp(s, 'rect', x, y, w, h, b)
    i = 0
    while i * step < w:
        if i % 2 == 0: shp(s, 'rect', x + i * step, y, min(step, w - i * step), h, a)
        i += 1


def _star(s, cx, cy, sz, c=None):
    shp(s, 'star', cx - sz / 2, cy - sz / 2, sz, sz, c or BU)


def _sparkles(s, pts, c=None):
    for (x, y, sz) in pts:
        _star(s, x, y, sz, c or mix(PK2, 'FFFFFF', 0.3))


def _h(s, x, y, t, sz=40, w=8.0, al='l', c=None):
    txt(s, x, y, w, 2.6, t, sz, c or BU, 'bd', al, sp=1.02)


def _p(s, x, y, w, t, sz=11.5, c=None, al='l'):
    if t: txt(s, x, y, w, 2.0, t, sz, c or MUTE, 'rg', al, sp=1.4)


def _pill(s, x, y, w, t, f=PK2):
    shp(s, 'round', x, y, w, 0.40, f, adj=0.5)
    txt(s, x, y, w, 0.40, t, 11, BU, 'md', 'c', 'm')


def _clip(s, cx, y, h=0.80):
    shp(s, 'round', cx - 0.12, y, 0.24, h, None, line='9A9396', lw=2.4, adj=0.5)
    shp(s, 'round', cx - 0.06, y + 0.12, 0.12, h - 0.24, None, line='9A9396', lw=1.6, adj=0.5)


def _polaroid(s, n, x, y, w, h, rot=0):
    shp(s, 'rect', x, y, w, h, 'FFFFFF', rot=rot, shadow=('7A1E35', 0.16, 10, 3))
    p = _photo(s, n, x + 0.12, y + 0.12, w - 0.24, h - 0.55)
    p.rotation = rot


def _stamp(s, x, y, w, h, f=CR):
    shp(s, 'rect', x, y, w, h, f, line=PK2, lw=2.2, dash=True)


def _folder(s, x, y, w, h):
    shp(s, 'round2', x + 0.40, y - 0.36, w * 0.36, 0.50, mix(PK2, PK, 0.4), adj=0.4)
    shp(s, 'round', x, y, w, h, mix(PK, 'FFFFFF', 0.25), adj=0.04, shadow=('7A1E35', 0.10, 12, 3))
    shp(s, 'rect', x + 0.30, y + 0.55, w - 0.60, 0.16, 'FFFFFF')


def _locket(s, n, x, y, sz):
    shp(s, 'heart', x - 0.10, y - 0.10, sz + 0.20, sz + 0.12, SILV, shadow=('000000', 0.18, 10, 3))
    _photo(s, n, x + 0.08, y + 0.06, sz - 0.16, sz - 0.20, geom='heart', focus=(0.5, 0.25))
    shp(s, 'oval', x + sz / 2 - 0.16, y - 0.42, 0.32, 0.32, None, line=SILV, lw=3)


def _chrome(s, d):
    txt(s, M, 0.32, 5.0, 0.30, d.get('name', 'ชื่อของคุณ') + '  |  ' + d.get('date', 'วันที่'), 10, MUTE, 'md')


# ══ เลย์เอาต์ตามรูปอ้างอิง ═════════════════════════════════════════════════

@reg
def am_cover(prs, d):
    s = page(prs, PK)
    _folder(s, M, 0.95, W - M * 2, 6.10)
    txt(s, M + 0.45, 1.05, 5.0, 0.36, d.get('name', '') + '  |  ' + d.get('date', ''), 12, MUTE, 'md')
    _sparkles(s, [(2.3, 2.6, 0.32), (1.6, 4.2, 0.22), (3.4, 5.6, 0.28), (10.6, 5.9, 0.26), (8.7, 1.9, 0.22), (11.8, 3.9, 0.3)])
    _h(s, 1.8, 2.35, d['t'], 72, 7.6, 'c')
    _p(s, 2.6, 5.05, 6.0, d.get('s', ''), 14, BU, 'c')
    _locket(s, d.get('pi', 4), 9.40, 1.90, 2.90)


@reg
def am_profile(prs, d):
    s = page(prs, CR)
    _stripes(s, 0, 0, 4.60, H)
    shp(s, 'rect', 0.85, 0.75, 3.00, 6.10, 'FFFFFF', line=PK2, lw=3, dash=True)
    _photo(s, d.get('pi', 3), 1.05, 0.95, 2.60, 2.75, focus=(0.5, 0.2))
    _photo(s, d.get('pi2', 5), 1.05, 3.90, 2.60, 2.75, focus=(0.5, 0.2))
    _clip(s, 2.35, 0.40)
    _h(s, 5.40, 1.00, d['t'], 52, 7.0)
    shp(s, 'rect', 5.40, 4.10, 3.60, 0.50, PK)
    txt(s, 5.50, 4.10, 6.0, 0.50, d['name_full'], 18, BU, 'bd', an='m')
    _p(s, 5.40, 4.80, 6.8, d.get('note', ''), 12.5)


@reg
def am_story(prs, d):
    s = page(prs, PK)
    _stripes(s, 0, 0, W, H, PK2, PK, 0.30)
    shp(s, 'rect', 0.80, 0.70, W - 1.60, H - 1.40, 'FFFFFF', shadow=('7A1E35', 0.10, 12, 3))
    _sparkles(s, [(1.4, 1.3, 0.24), (2.2, 6.2, 0.2), (11.6, 1.4, 0.26), (11.9, 5.9, 0.22), (6.4, 6.4, 0.2)], PK2)
    _h(s, 0, 1.45, d['t'], 48, W, 'c')
    _p(s, 2.3, 2.95, W - 4.6, d['note'], 15, MUTE, 'c')


@reg
def am_facts(prs, d):
    s = page(prs, CR)
    _stripes(s, 0, 0, W, 1.30, PK, CR, 0.30)
    _h(s, 0, 0.30, d['t'], 44, W, 'c')
    _polaroid(s, d.get('pi', 2), W / 2 - 1.55, 2.00, 3.10, 3.90, -2)
    _clip(s, W / 2 + 0.80, 1.65)
    for i, (lab, v) in enumerate(d['items'][:6]):
        x = M + 0.30 if i < 3 else W - M - 3.60
        y = 2.20 + (i % 3) * 1.45
        _pill(s, x, y, 3.30, lab)
        txt(s, x, y + 0.48, 3.30, 0.80, v, 12.5, BU, 'md', 'c', sp=1.15)


@reg
def am_journey(prs, d):
    s = page(prs, CR)
    _stripes(s, 0, 0, W, 1.75, PK, PK2, 0.30)
    _h(s, 0, 0.45, d['t'], 44, W, 'c')
    _stripes(s, 0, H - 0.70, W, 0.70, PK, PK2, 0.30)
    n = len(d['items'][:4]); cw = (W - M * 2) / n
    for i, (yr, h_, body) in enumerate(d['items'][:4]):
        cx = M + cw * (i + 0.5)
        _star(s, cx, 2.55, 0.48)
        txt(s, cx - cw / 2, 3.05, cw, 0.40, yr, 13, BU, 'bd', 'c')
        txt(s, cx - cw / 2 + 0.15, 3.50, cw - 0.3, 0.75, h_, 14, BU, 'md', 'c', sp=1.1)
        _p(s, cx - cw / 2 + 0.25, 4.35, cw - 0.5, body, 11.5, MUTE, 'c')
        if i: ln(s, cx - cw + 0.40, 2.55, cx - 0.40, 2.55, PK2, 1.5, dash=True)


@reg
def am_strengths(prs, d):
    s = page(prs, CR)
    _stripes(s, 0, 0, W, H, CR, mix(PK, CR, 0.5), 0.30)
    _h(s, 0, 0.45, d['t'], 44, W, 'c')
    for i, (h_, body, n) in enumerate(d['items'][:2]):
        x = 1.80 + i * 5.10
        shp(s, 'heart', x, 1.75, 4.60, 4.70, PK2, shadow=('7A1E35', 0.12, 12, 3))
        _clip(s, x + 1.10, 1.45)
        txt(s, x + 0.60, 2.45, 3.40, 0.40, h_, 15, BU, 'bd', 'c')
        _photo(s, n, x + 1.45, 3.00, 1.70, 1.30, focus=(0.5, 0.5))
        _p(s, x + 0.95, 4.40, 2.70, body, 11, BU, 'c')


@reg
def am_keywords(prs, d):
    s = page(prs, PK)
    _stripes(s, 0, 0, W, H, PK, PK2, 0.30)
    shp(s, 'rect', 0, 0, W, 2.05, PK)
    _h(s, 0, 0.35, d['t'], 44, W, 'c')
    cw = 3.40; gap = 0.45
    x0 = (W - cw * 3 - gap * 2) / 2
    for i, (h_, body) in enumerate(d['items'][:3]):
        x = x0 + i * (cw + gap)
        _stamp(s, x, 2.55, cw, 3.80)
        _star(s, x + cw / 2, 3.15, 0.42)
        txt(s, x + 0.25, 3.55, cw - 0.5, 0.45, h_, 16, BU, 'bd', 'c')
        _p(s, x + 0.35, 4.15, cw - 0.7, body, 11.5, MUTE, 'c')


@reg
def am_headed(prs, d):
    s = page(prs, PK)
    _stripes(s, 0, 4.20, W, H - 4.20, PK, CR, 0.30)
    _h(s, 0, 0.40, d['t'], 44, W, 'c')
    shp(s, 'rect', 0.95, 1.55, W - 1.90, 5.30, 'FFFFFF', rot=-0.6, shadow=('7A1E35', 0.12, 10, 3))
    shp(s, 'rect', 0.80, 1.70, W - 1.90, 5.30, 'FFFFFF', shadow=('7A1E35', 0.12, 10, 3))
    _clip(s, W - 2.20, 1.35)
    for i, (lab, body) in enumerate(d['items'][:3]):
        y = 2.20 + i * 1.50
        txt(s, 1.40, y, 2.20, 0.40, lab, 15, BU, 'bd')
        _p(s, 3.80, y, 8.2, body, 12.5, MUTE)
        if i < 2: ln(s, 1.40, y + 1.05, W - 1.70, y + 1.05, PK2, 1, dash=True)


@reg
def am_thanks(prs, d):
    s = page(prs, PK)
    _folder(s, M, 0.95, W - M * 2, 6.10)
    _sparkles(s, [(2.0, 2.0, 0.28), (3.3, 5.8, 0.24), (8.6, 1.8, 0.2), (8.3, 6.0, 0.26), (1.6, 4.6, 0.2)])
    _h(s, 2.2, 2.20, d['t'], 72, 7.0, 'c')
    _p(s, 2.7, 5.00, 6.0, d.get('note', ''), 13, BU, 'c')
    _locket(s, d.get('pi', 5), 9.40, 2.20, 2.70)


# ══ อีก 11 เลย์เอาต์ในระบบเดียวกัน ════════════════════════════════════════

@reg
def am_toc(prs, d):
    s = page(prs, CR)
    _stripes(s, W - 4.40, 0, 4.40, H)
    _polaroid(s, d.get('pi', 1), W - 3.80, 1.30, 3.10, 3.90, 3)
    _clip(s, W - 2.25, 0.95)
    _h(s, M, 0.80, d['t'], 48, 7.0)
    for i, t in enumerate(d['items'][:6]):
        y = 2.75 + i * 0.70
        _star(s, M + 0.20, y + 0.22, 0.30)
        txt(s, M + 0.60, y, 6.8, 0.50, t, 16, BU, 'md')
        ln(s, M + 0.60, y + 0.60, 8.0, y + 0.60, PK2, 0.8, dash=True)


@reg
def am_skills(prs, d):
    s = page(prs, CR)
    _stripes(s, 0, 0, 0.55, H)
    _h(s, 1.00, 0.70, d['t'], 40, 5.0)
    _p(s, 1.00, 2.20, 4.2, d.get('note', ''), 12)
    for i, (v, lab) in enumerate(d['items'][:2]):
        y = 4.15 + i * 1.40
        _stamp(s, 1.00, y, 4.00, 1.20, 'FFFFFF')
        txt(s, 1.25, y + 0.12, 1.6, 0.90, v, 30, BU, 'bd', an='m')
        _p(s, 2.85, y + 0.25, 2.0, lab, 10.5)
    shp(s, 'rect', 5.60, 0.70, W - M - 5.60, 6.25, 'FFFFFF', line=PK2, lw=2)
    chart(s, 'bar', 5.80, 0.90, W - M - 6.00, 5.85, d['cats'], [(d['sname'], d['vals'])], [PK2] * (len(d['vals']) - 1) + [BU],
          labels=True, fmt='0" ปี"', gap=45, sz=12, c=BU, vary=True)


@reg
def am_time(prs, d):
    s = page(prs, PK)
    _stripes(s, 0, 0, W, H, PK, mix(PK, CR, 0.6), 0.30)
    shp(s, 'rect', 0.70, 0.60, W - 1.40, H - 1.20, CR, shadow=('7A1E35', 0.10, 12, 3))
    _h(s, 1.10, 0.90, d['t'], 40, 6.0)
    cols = [BU, PK2, 'E9A9B9']
    it = d['items'][:3]
    chart(s, 'donut', 1.00, 2.10, 4.50, 4.50, [x[0] for x in it], [('ร้อยละ', [x[1] for x in it])], cols, labels=False, hole=60)
    txt(s, 1.00, 4.00, 4.50, 0.60, d['big'], 28, BU, 'bd', 'c')
    txt(s, 1.00, 4.60, 4.50, 0.30, d['biglab'], 10.5, MUTE, 'rg', 'c')
    for i, (lab, v, body) in enumerate(it):
        y = 2.25 + i * 1.40
        shp(s, 'heart', 6.10, y + 0.08, 0.38, 0.36, cols[i])
        txt(s, 6.70, y, 4.0, 0.42, lab, 15, BU, 'bd')
        _p(s, 6.70, y + 0.48, 5.0, body, 11)
        txt(s, 10.80, y, 1.40, 0.50, f'{v}%', 22, BU, 'bd', 'r')


@reg
def am_plan(prs, d):
    s = page(prs, CR)
    _stripes(s, 0, 0, W, 1.30, PK, CR, 0.30)
    _h(s, M, 1.55, d['t'], 40, 5.0)
    _p(s, M, 3.05, 4.5, d.get('note', ''), 12)
    _pill(s, M, 5.20, 3.40, d.get('k', ''))
    shp(s, 'rect', 5.70, 1.55, W - M - 5.70, 5.40, 'FFFFFF', line=PK2, lw=2)
    chart(s, 'col', 5.90, 1.75, W - M - 6.10, 5.00, d['cats'], [(d['sname'], d['vals'])], [PK2, 'E9A9B9', BU],
          labels=True, fmt='0', gap=60, sz=12, c=BU, vary=True)


@reg
def am_div(prs, d):
    s = page(prs, PK)
    _stripes(s, 0, 0, 5.20, H, PK2, PK, 0.30)
    _polaroid(s, d.get('pi', 0), 1.10, 1.35, 3.20, 4.20, -3)
    _clip(s, 2.70, 1.00)
    _sparkles(s, [(6.0, 1.4, 0.3), (11.8, 1.9, 0.24), (12.0, 6.0, 0.28)], PK2)
    txt(s, 6.00, 2.30, 6.0, 0.40, d.get('k', ''), 14, MUTE, 'md')
    _h(s, 6.00, 2.80, d['t'], 54, 6.6)
    _p(s, 6.00, 4.95, 6.2, d.get('note', ''), 13)


@reg
def am_work(prs, d):
    s = page(prs, CR)
    _stripes(s, 0, H - 1.10, W, 1.10, PK, CR, 0.30)
    _h(s, M, 0.70, d['t'], 40, 9.0)
    cw = (W - M * 2 - 0.50) / 3
    for i, (v, h_, body) in enumerate(d['items'][:3]):
        x = M + i * (cw + 0.25)
        _stamp(s, x, 2.10, cw, 3.90, 'FFFFFF' if i != 1 else PK)
        txt(s, x + 0.35, 2.40, cw - 0.7, 0.90, v, 40, BU, 'bd')
        txt(s, x + 0.35, 3.40, cw - 0.7, 0.45, h_, 15, BU, 'bd')
        _p(s, x + 0.35, 3.95, cw - 0.7, body, 11.5)


@reg
def am_hobbies(prs, d):
    s = page(prs, PK)
    _h(s, 0, 0.45, d['t'], 44, W, 'c')
    spec = [(0.90, 1.90, 2.70, -3), (3.85, 2.20, 2.70, 2), (6.80, 1.90, 2.70, -2), (9.75, 2.20, 2.70, 3)]
    for (x, y, w, r), (n, cap) in zip(spec, d['items'][:4]):
        _polaroid(s, n, x, y, w, 3.30, r)
        txt(s, x, y + 3.45, w, 0.40, cap, 13, BU, 'md', 'c')
    _sparkles(s, [(1.0, 6.4, 0.26), (12.3, 6.5, 0.3), (6.6, 6.6, 0.22)], PK2)


@reg
def am_week(prs, d):
    s = page(prs, CR)
    _h(s, M, 0.60, d['t'], 40, 9.0)
    cols = d['colw']; tw = W - M * 2; y0 = 1.95; rh = 0.82
    xs = [M]
    for f in cols[:-1]: xs.append(xs[-1] + tw * f)
    shp(s, 'rect', M, y0, tw, 0.60, BU)
    for j, hd in enumerate(d['head']):
        txt(s, xs[j] + 0.22, y0, tw * cols[j] - 0.44, 0.60, hd, 12, 'FFFFFF', 'md', 'l' if j == 0 else 'c', 'm')
    for i, row in enumerate(d['rows']):
        y = y0 + 0.60 + i * rh
        shp(s, 'rect', M, y, tw, rh, PK if i % 2 == 0 else 'FFFFFF')
        for j, cell in enumerate(row):
            txt(s, xs[j] + 0.22, y, tw * cols[j] - 0.44, rh, cell, 12.5 if j == 0 else 12, BU,
                'bd' if j == 0 else 'rg', 'l' if j == 0 else 'c', 'm')


@reg
def am_quote(prs, d):
    s = page(prs, PK)
    _stripes(s, 0, 0, W, H, PK, PK2, 0.30)
    shp(s, 'rect', 1.30, 1.10, W - 2.60, 5.30, CR, shadow=('7A1E35', 0.12, 12, 3))
    _star(s, W / 2, 1.90, 0.60)
    txt(s, 2.10, 2.55, W - 4.20, 2.40, d['t'], 26, BU, 'bd', 'c', sp=1.3)
    _p(s, 2.10, 5.25, W - 4.20, d.get('who', ''), 13, MUTE, 'c')


@reg
def am_team(prs, d):
    s = page(prs, CR)
    _stripes(s, 0, 0, W, 1.30, PK, CR, 0.30)
    _h(s, 0, 1.55, d['t'], 40, W, 'c')
    _p(s, 2.5, 2.60, W - 5.0, d.get('note', ''), 12, MUTE, 'c')
    cw = (W - M * 2 - 0.60) / 4
    for i, (name, role) in enumerate(d['items'][:4]):
        x = M + i * (cw + 0.20)
        _stamp(s, x, 3.55, cw, 2.60, 'FFFFFF')
        shp(s, 'heart', x + cw / 2 - 0.40, 3.85, 0.80, 0.74, PK2 if i else BU)
        txt(s, x + 0.20, 4.80, cw - 0.4, 0.40, name, 15, BU, 'bd', 'c')
        _p(s, x + 0.20, 5.25, cw - 0.4, role, 11, MUTE, 'c')


@reg
def am_contact(prs, d):
    s = page(prs, PK)
    _stripes(s, 0, 0, 5.40, H, PK2, PK, 0.30)
    _polaroid(s, d.get('pi', 3), 1.20, 1.25, 3.10, 4.20, 3)
    _clip(s, 2.75, 0.90)
    _h(s, 6.10, 1.10, d['t'], 48, 6.4)
    for i, (lab, v) in enumerate(d['items'][:4]):
        y = 3.30 + i * 0.85
        _pill(s, 6.10, y, 2.00, lab)
        txt(s, 8.35, y - 0.02, 4.4, 0.44, v, 15, BU, 'md', an='m')
