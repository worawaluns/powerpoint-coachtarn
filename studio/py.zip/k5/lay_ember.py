"""20 เลย์เอาต์ชุด Process Infographic — ลอกโครงจากเทมเพลตดำ+ส้มที่ไอซ์ส่งมา

พื้นดำทั้งเล่ม แผงไล่เฉดส้มเป็นตัวเน้น วงแหวนและพายเป็นส้มบนวงเทาเข้ม
ตัวหนังสือบนแผงส้มใช้สีเข้มเสมอ (ขาวบนส้มคอนทราสต์ไม่ผ่าน)
"""
from eng import *
import eng
from lay import L, reg

M = 0.70


def _duo():
    if P.get('dark'):
        return f"duo:{mix(P['bg'], P['acc'], 0.24)}:{mix(P['acc'], 'FFFFFF', 0.52)}"
    return f"duo:{mix(P['ink'], P['acc'], 0.42)}:{mix(P['bg'], P['acc'], 0.13)}"


def _grad(s, x, y, w, h, ang=315, adj=None, kind='rect'):
    return gradband(s, x, y, w, h, ang, c1=P['g1'], c2=P['g2'], kind=kind, adj=adj)


def _on():
    """สีตัวหนังสือที่วางบนแผงส้ม"""
    return P['bg']


def _h(s, x, y, t, sz=40, w=7.0, c=None):
    txt(s, x, y, w, 2.1, t, sz, c or P['ink'], 'md', sp=1.16)


def _p(s, x, y, w, t, sz=13.5, c=None):
    txt(s, x, y, w, 1.5, t, sz, c or mix(P['bg'], P['ink'], 0.58), 'rg', sp=1.44)


def _lab(s, x, y, t, c=None, sz=13):
    if t: txt(s, x, y, 4.6, 0.28, t, sz, c or P['mute'], 'md')


def _dot(s, cx, cy, r=0.13, c=None):
    shp(s, 'oval', cx - r, cy - r, r * 2, r * 2, c or P['acc2'])


def _chrome(s, d, on_grad=False):
    c = _on() if on_grad else mix(P['bg'], P['ink'], 0.50)
    txt(s, M, 0.34, 4.0, 0.26, d.get('brand', 'รายงานกระบวนการบริการ'), 9, c, 'rg')
    if d.get('n'):
        txt(s, W - M - 0.9, 0.34, 0.9, 0.26, f"{int(d['n']):02d}", 9, c, 'rg', 'r')


def _pie(s, cx, cy, dia, pct, c=None, rest=None):
    """พายเต็มวง ไม่ใช่โดนัท แบบที่ต้นฉบับใช้"""
    shp(s, 'oval', cx - dia / 2, cy - dia / 2, dia, dia, rest or 'FFFFFF')
    if pct >= 99.5:
        shp(s, 'oval', cx - dia / 2, cy - dia / 2, dia, dia, c or P['acc']); return
    st, en = 270, (270 + 3.6 * pct) % 360
    shp(s, 'pie', cx - dia / 2, cy - dia / 2, dia, dia, c or P['acc'], adj=[st * 0.6, en * 0.6])


# ══ เลย์เอาต์ตามรูปอ้างอิง ═════════════════════════════════════════════════

@reg
def em_cover(prs, d):
    s = page(prs)
    _grad(s, 0, 0, W, H, 315)
    _chrome(s, d, True)
    txt(s, M, 1.70, 9.6, 1.3, d['t'], 54, _on(), 'md', sp=1.12)
    _p(s, M, 3.10, 9.0, d['s'], 14.5, mix(P['bg'], P['g1'], 0.26))
    ln(s, M, 3.96, W - M, 3.96, mix(P['g2'], P['bg'], 0.30), 0.9)
    for i, (h_, body) in enumerate(d['items'][:2]):
        x = M + i * 7.40
        txt(s, x, 4.22, 4.4, 0.32, h_, 14.5, _on(), 'md')
        _p(s, x, 4.62, 4.4, body, 13, mix(P['bg'], P['g1'], 0.26))


@reg
def em_rows_panel(prs, d):
    s = page(prs)
    _chrome(s, d)
    for i, (h_, body, v) in enumerate(d['items'][:3]):
        y = 1.26 + i * 1.60
        _dot(s, M + 0.14, y + 0.14)
        txt(s, M + 0.46, y, 4.4, 0.32, h_, 15, P['ink'], 'md')
        _p(s, M + 0.46, y + 0.40, 4.5, body, 13)
        bx, bw = M + 0.46, 4.10
        shp(s, 'round', bx, y + 1.00, bw, 0.14, mix(P['bg'], P['ink'], 0.18), adj=0.5)
        _grad(s, bx, y + 1.00, bw * v / 100, 0.14, 0, adj=0.5, kind='round')
        txt(s, bx + bw + 0.20, y + 0.88, 0.80, 0.36, f'{v}%', 13.5, P['ink'], 'rg', an='m')
    _grad(s, 6.30, 0, W - 6.30, H, 315)
    txt(s, 6.80, 1.30, 5.2, 1.9, d['t'], 37, _on(), 'md', sp=1.18)
    _p(s, 6.80, 3.56, 5.0, d['note'], 13, mix(P['bg'], P['g1'], 0.24))
    txt(s, 6.80, 5.10, 4.4, 0.56, d['foot2'], 14.5, _on(), 'md', sp=1.25)


@reg
def em_toc(prs, d):
    s = page(prs)
    _chrome(s, d)
    _h(s, M, 1.10, d['t'], 37, 4.4)
    for i, h_ in enumerate(d['items'][:3]):
        y = 2.46 + i * 1.02
        txt(s, M, y, 4.6, 0.46, h_, 17, P['ink'], 'md', an='m')
        txt(s, 5.10, y, 0.9, 0.46, f'{i + 1:02d}.', 17, P['acc'], 'md', 'r', 'm')
        ln(s, M, y + 0.74, 6.00, y + 0.74, mix(P['bg'], P['ink'], 0.16), 0.7)
    _grad(s, 6.80, 0.70, W - M - 6.80, H - 1.40, 315)
    _p(s, 7.24, 1.20, 4.5, d['note'], 13, mix(P['bg'], P['g1'], 0.24))
    txt(s, 7.24, 4.70, 4.5, 0.60, d.get('tag', ''), 13, _on(), 'md')


@reg
def em_summary4(prs, d):
    s = page(prs)
    _grad(s, 0, 0, 8.60, H, 315)
    _chrome(s, d, True)
    txt(s, M, 1.10, 5.0, 0.70, d['t'], 37, _on(), 'md')
    for i, (v, lab, body) in enumerate(d['items'][:4]):
        x = M + (i % 2) * 3.80
        y = 2.30 + (i // 2) * 1.80
        txt(s, x, y, 2.2, 0.56, v, 34, _on(), 'md')
        txt(s, x, y + 0.62, 3.3, 0.30, lab, 13.5, _on(), 'md')
        _p(s, x, y + 0.96, 3.4, body, 13, mix(P['bg'], P['g1'], 0.22))
    pic(s, ph(d['topic'], d.get('pi', 0)), 8.60, 0, W - 8.60, H, mode=_duo())


@reg
def em_stats_quote(prs, d):
    s = page(prs)
    _chrome(s, d)
    for i, (v, lab) in enumerate(d['items'][:4]):
        x = M + i * 3.00
        _dot(s, x + 0.12, 1.14)
        txt(s, x, 1.40, 2.6, 0.52, v, 30, P['acc'], 'md')
        txt(s, x, 2.00, 2.7, 0.30, lab, 13.5, P['ink'], 'md')
        _p(s, x, 2.34, 2.8, d['notes'][i] if i < len(d.get('notes', [])) else '', 12.5)
    pic(s, ph(d['topic'], d.get('pi', 1)), 0, 3.80, 5.90, H - 3.80, mode=_duo())
    _grad(s, 5.90, 4.20, W - 5.90, 1.70, 0)
    txt(s, 6.40, 4.48, 6.2, 0.90, f'"{d["quote"]}"', 16, _on(), 'md', sp=1.3)
    _p(s, 6.40, 5.46, 6.0, d['who'], 13, mix(P['bg'], P['g1'], 0.24))


@reg
def em_pies3(prs, d):
    s = page(prs)
    _chrome(s, d)
    _h(s, M, 2.50, d['t'], 37, 2.9)
    for i, (pct, h_, body) in enumerate(d['items'][:3]):
        y = 1.06 + i * 1.62
        _pie(s, 5.00, y + 0.54, 1.00, pct, rest=mix(P['bg'], P['ink'], 0.14))
        txt(s, 4.56, y + 0.36, 0.9, 0.34, f'{pct}%', 13, P['bg'], 'md', 'c', 'm')
        txt(s, 5.86, y + 0.26, 3.2, 0.32, h_, 14.5, P['ink'], 'md')
        _p(s, 5.86, y + 0.64, 3.3, body, 13)
        _dot(s, 4.18, y + 0.54, 0.11)
    pic(s, ph(d['topic'], d.get('pi', 2)), 9.40, 0.70, W - M - 9.40, H - 1.40, geom='roundRect', adj=0.05, mode=_duo())


@reg
def em_rings3(prs, d):
    s = page(prs)
    _chrome(s, d)
    cw = (W - M * 2) / 3
    for i, (pct, v, lab, pts) in enumerate(d['items'][:3]):
        x = M + i * cw
        cx, cy = x + 0.90, 1.80
        ring(s, cx, cy, 1.52, pct / 100, P['acc'], mix(P['bg'], P['ink'], 0.16), 0.14)
        txt(s, cx - 0.76, cy - 0.20, 1.52, 0.40, f'{pct}%', 15, P['ink'], 'md', 'c', 'm')
        txt(s, x, 2.98, cw - 0.4, 0.56, v, 31, P['acc'], 'md')
        txt(s, x, 3.62, cw - 0.4, 0.30, lab, 13.5, P['ink'], 'md')
        for j, t in enumerate(pts[:3]):
            y = 4.06 + j * 0.46
            ln(s, x + 0.04, y + 0.16, x + 0.13, y + 0.25, P['acc'], 1.3)
            ln(s, x + 0.13, y + 0.25, x + 0.30, y + 0.06, P['acc'], 1.3)
            _p(s, x + 0.44, y, cw - 0.84, t, 12.5)


@reg
def em_timeline4(prs, d):
    s = page(prs)
    _grad(s, 0, 0, W, H, 315)
    _chrome(s, d, True)
    txt(s, M, 1.00, 6.0, 0.70, d['t'], 37, _on(), 'md')
    ln(s, W / 2, 2.10, W / 2, H - 0.90, mix(P['g2'], P['bg'], 0.26), 0.9)
    ln(s, M, 3.96, W - M, 3.96, mix(P['g2'], P['bg'], 0.26), 0.9)
    for i, (v, h_, when, body) in enumerate(d['items'][:4]):
        x = M + (i % 2) * 6.20
        y = 2.26 + (i // 2) * 1.92
        txt(s, x, y, 1.5, 0.52, v, 30, _on(), 'md')
        txt(s, x + 1.70, y, 3.4, 0.28, h_, 13.5, _on(), 'md')
        _p(s, x + 1.70, y + 0.30, 3.4, when, 12.5, mix(P['bg'], P['g1'], 0.30))
        _p(s, x + 1.70, y + 0.62, 3.6, body, 12.5, mix(P['bg'], P['g1'], 0.22))


@reg
def em_bignum_ghost(prs, d):
    s = page(prs)
    _chrome(s, d)
    _grad(s, 0, 0, 2.30, H, 90)
    _p(s, 0.34, 1.00, 1.7, d.get('k', ''), 13, _on())
    txt(s, 0.34, 5.30, 1.7, 0.50, d.get('yr', ''), 17, _on(), 'md')
    for i, g in enumerate(d['ghost'][:2]):
        txt(s, 2.90, 1.10 + i * 1.10, 4.0, 1.0, g, 54, mix(P['bg'], P['acc'], 0.22), 'md')
    txt(s, 2.90, 3.40, 5.0, 1.5, d['big'], 54, P['ink'], 'md')
    shp(s, 'rect', 8.30, 0, W - 8.30, H, P['panel'])
    txt(s, 8.74, 1.10, 4.0, 0.62, d['t'], 16, P['acc'], 'md', sp=1.25)
    for i, body in enumerate(d['items'][:3]):
        _p(s, 8.74, 2.06 + i * 1.10, 3.9, body, 13)


@reg
def em_curve(prs, d):
    s = page(prs)
    _chrome(s, d)
    _h(s, M, 1.00, d['t'], 34, 4.2)
    _p(s, M, 2.70, 4.2, d['note'], 13)
    pts = [(6.30, 3.34, 0.92), (7.90, 2.26, 0.86), (9.70, 2.54, 0.86), (11.30, 3.30, 0.98)]
    for a_, b_ in zip(pts, pts[1:]):
        ln(s, a_[0], a_[1], b_[0], b_[1], mix(P['bg'], P['acc'], 0.45), 2.4)
    for (v, lab), (cx, cy, dia) in zip(d['items'][:4], pts):
        shp(s, 'oval', cx - dia / 2, cy - dia / 2, dia, dia, P['acc'])
        txt(s, cx - dia / 2, cy - dia / 2, dia, dia, v, 14.5, P['bg'], 'md', 'c', 'm')
    pic(s, ph(d['topic'], d.get('pi', 3)), 8.10, 0.76, 1.60, 1.14, geom='ellipse', mode=_duo())
    n = len(d['foot'][:4]); cw = (W - M * 2) / n
    ln(s, M, 4.70, W - M, 4.70, mix(P['bg'], P['ink'], 0.16), 0.7)
    for i, (v, lab) in enumerate(d['foot'][:4]):
        x = M + i * cw
        txt(s, x, 4.90, cw - 0.3, 0.50, v, 27, P['acc'], 'md')
        _p(s, x, 5.46, cw - 0.4, lab, 12.5)


# ══ อีก 10 เลย์เอาต์ ═══════════════════════════════════════════════════════

@reg
def em_hbars(prs, d):
    s = page(prs)
    _chrome(s, d)
    txt(s, M, 1.00, 5.4, 1.1, d['t'], 34, P['ink'], 'md', sp=1.2)
    gx, gw = 4.70, W - M - 4.70
    mx = max(v for _, v in d['items'][:2]) or 1
    for i, (lab, v) in enumerate(d['items'][:2]):
        y = 1.26 + i * 1.10
        bw = gw * (v / mx) * 0.92
        _grad(s, gx + gw - bw, y, bw, 0.72, 0, adj=0.14, kind='round')
        txt(s, gx + gw - bw + 0.24, y, 1.4, 0.72, f'{v}%', 16, _on(), 'md', an='m')
        _p(s, M, y + 0.14, 3.6, lab, 13)
    n = len(d['foot'][:8]); cw = (W - M * 2) / n
    ln(s, M, 4.40, W - M, 4.40, mix(P['bg'], P['ink'], 0.16), 0.7)
    for i, lab in enumerate(d['foot'][:8]):
        x = M + i * cw
        h = 0.34 + (i % 4) * 0.30
        _grad(s, x, 4.40 - h, cw - 0.22, h, 90)
        _p(s, x, 4.52, cw - 0.2, lab, 7.5)


@reg
def em_divider(prs, d):
    s = page(prs)
    pic(s, ph(d['topic'], d.get('pi', 4)), 0, 0, W, H, mode=_duo())
    shp(s, 'rect', 0, 0, W, H, '0E0C0B', a=0.62)
    _chrome(s, d)
    _grad(s, 0, 2.40, 0.90, 1.70, 90)
    txt(s, 1.40, 2.42, 2.4, 1.0, d['num'], 54, P['acc'], 'md')
    _h(s, 1.40, 3.60, d['t'], 40, 8.0)
    if d.get('s'): _p(s, 1.40, 4.84, 7.2, d['s'], 13.5)


@reg
def em_grid4(prs, d):
    s = page(prs)
    _chrome(s, d)
    _h(s, M, 1.00, d['t'], 37, 6.0)
    _p(s, 7.60, 1.06, 5.0, d.get('note', ''), 13)
    cw, ch = 5.90, 1.70
    for i, (h_, body) in enumerate(d['items'][:4]):
        x = M + (i % 2) * (cw + 0.34)
        y = 2.80 + (i // 2) * (ch + 0.26)
        if i == 0: _grad(s, x, y, cw, ch, 315, adj=0.09, kind='round')
        else: shp(s, 'round', x, y, cw, ch, P['panel'], adj=0.09)
        txt(s, x + 0.32, y + 0.26, cw - 0.64, 0.32, h_, 15, _on() if i == 0 else P['ink'], 'md')
        _p(s, x + 0.32, y + 0.68, cw - 0.64, body, 13,
           mix(P['bg'], P['g1'], 0.24) if i == 0 else None)


@reg
def em_table(prs, d):
    s = page(prs)
    _chrome(s, d)
    _h(s, M, 1.00, d['t'], 37, 8.0)
    tw = W - M * 2; cols = d['colw']; y0 = 2.46
    _grad(s, M, y0, tw, 0.54, 0)
    cx = M
    for j, (hd, fr) in enumerate(zip(d['head'], cols)):
        txt(s, cx + 0.22, y0, tw * fr - 0.44, 0.54, hd, 13.5, _on(), 'md', 'l' if j == 0 else 'r', 'm'); cx += tw * fr
    for i, row in enumerate(d['rows'][:5]):
        y = y0 + 0.54 + i * 0.58
        if i % 2 == 0: shp(s, 'rect', M, y, tw, 0.58, P['panel'])
        cx = M
        for j, (cell, fr) in enumerate(zip(row, cols)):
            txt(s, cx + 0.22, y, tw * fr - 0.44, 0.58, cell, 13.5,
                P['acc'] if j == len(cols) - 1 else mix(P['bg'], P['ink'], 0.80),
                'md' if j == len(cols) - 1 else 'rg', 'l' if j == 0 else 'r', 'm'); cx += tw * fr
    if d.get('note'): _p(s, M, y0 + 0.54 + len(d['rows'][:5]) * 0.58 + 0.18, 9.6, d['note'], 12.5)


@reg
def em_steps(prs, d):
    s = page(prs)
    _chrome(s, d)
    _h(s, M, 1.00, d['t'], 37, 4.4)
    _p(s, M, 3.00, 4.2, d.get('note', ''), 13)
    x = 5.80
    n = len(d['items'][:4])
    ln(s, x + 0.20, 1.14, x + 0.20, 1.14 + (n - 1) * 1.32 + 0.40, mix(P['bg'], P['ink'], 0.18), 0.8)
    for i, (h_, body) in enumerate(d['items'][:4]):
        y = 1.14 + i * 1.32
        shp(s, 'oval', x, y, 0.40, 0.40, P['acc'] if i < 2 else mix(P['bg'], P['ink'], 0.22))
        txt(s, x, y, 0.40, 0.40, f'{i + 1}', 14.5, P['bg'] if i < 2 else P['ink'], 'md', 'c', 'm')
        txt(s, x + 0.70, y - 0.02, 6.0, 0.34, h_, 15, P['ink'], 'md')
        _p(s, x + 0.70, y + 0.38, 5.9, body, 13)


@reg
def em_compare(prs, d):
    s = page(prs)
    _chrome(s, d)
    _h(s, M, 1.00, d['t'], 37, 8.0)
    cw = (W - M * 2 - 0.42) / 2
    for c, (ttl, rows) in enumerate(zip(d['heads'], [d['before'], d['after']])):
        x = M + c * (cw + 0.42)
        hot = c == 1
        if hot: _grad(s, x, 2.56, cw, 3.10, 315, adj=0.07, kind='round')
        else: shp(s, 'round', x, 2.56, cw, 3.10, P['panel'], adj=0.07)
        txt(s, x + 0.32, 2.80, cw - 0.64, 0.34, ttl, 15, _on() if hot else P['ink'], 'md')
        for i, (lab, v) in enumerate(rows[:4]):
            y = 3.34 + i * 0.56
            txt(s, x + 0.32, y, cw - 1.70, 0.40, lab, 13,
                _on() if hot else mix(P['bg'], P['ink'], 0.80), 'rg', an='m')
            txt(s, x + cw - 1.50, y, 1.20, 0.40, v, 15, _on() if hot else P['acc'], 'md', 'r', 'm')
            ln(s, x + 0.32, y + 0.46, x + cw - 0.32, y + 0.46,
               mix(P['g2'], P['bg'], 0.26) if hot else mix(P['bg'], P['ink'], 0.16), 0.6)


@reg
def em_team(prs, d):
    s = page(prs)
    _chrome(s, d)
    _h(s, M, 1.00, d['t'], 37, 5.6)
    _p(s, 7.60, 1.06, 5.0, d.get('note', ''), 13)
    cw = (W - M * 2 - 0.44) / 3
    for i, (name, role, note) in enumerate(d['items'][:3]):
        x = M + i * (cw + 0.22)
        shp(s, 'round', x, 2.66, cw, 3.00, P['panel'], adj=0.07)
        pic(s, ph(d.get('ptopic', 'office'), d.get('pi', 5) + i), x + 0.26, 2.90, cw - 0.52, 1.30,
            geom='roundRect', adj=0.07, focus=(0.5, 0.36), mode=_duo())
        txt(s, x + 0.26, 4.34, cw - 0.52, 0.32, name, 15, P['ink'], 'md')
        _p(s, x + 0.26, 4.70, cw - 0.52, role, 13, P['acc'])
        _p(s, x + 0.26, 5.02, cw - 0.52, note, 12.5)


@reg
def em_quote(prs, d):
    s = page(prs)
    _chrome(s, d)
    pic(s, ph(d.get('ptopic', 'office'), d.get('pi', 8)), W - 4.40, 0.80, 4.40 - M, H - 1.60,
        geom='roundRect', adj=0.05, focus=(0.5, 0.4), mode=_duo())
    txt(s, M, 1.46, 1.2, 0.9, '"', 54, P['acc'], 'md')
    txt(s, M, 2.34, 7.0, 2.2, d['t'], 30, P['ink'], 'md', sp=1.3)
    ln(s, M, 4.92, M + 2.8, 4.92, mix(P['bg'], P['ink'], 0.22), 0.8)
    txt(s, M, 5.08, 5.2, 0.32, d['who'], 15, P['ink'], 'md')
    _p(s, M, 5.46, 5.2, d['role'], 13)


@reg
def em_kpi4(prs, d):
    s = page(prs)
    _chrome(s, d)
    _h(s, M, 1.00, d['t'], 37, 8.0)
    cw = (W - M * 2 - 0.54) / 4
    for i, (v, lab, body) in enumerate(d['items'][:4]):
        x = M + i * (cw + 0.18)
        hot = i == 0
        if hot: _grad(s, x, 2.70, cw, 2.56, 315, adj=0.09, kind='round')
        else: shp(s, 'round', x, 2.70, cw, 2.56, P['panel'], adj=0.09)
        txt(s, x + 0.26, 2.96, cw - 0.52, 0.62, v, 33, _on() if hot else P['acc'], 'md')
        txt(s, x + 0.26, 3.66, cw - 0.52, 0.30, lab, 13.5, _on() if hot else P['ink'], 'md')
        _p(s, x + 0.26, 4.02, cw - 0.52, body, 12.5, mix(P['bg'], P['g1'], 0.24) if hot else None)


@reg
def em_close(prs, d):
    s = page(prs)
    _grad(s, 0, 0, W, H, 315)
    _chrome(s, d, True)
    txt(s, M, 2.00, 8.4, 1.9, d['t'], 54, _on(), 'md', sp=1.12)
    _p(s, M, 4.10, 6.4, d.get('note', ''), 14, mix(P['bg'], P['g1'], 0.24))
    ln(s, M, 5.00, W - M, 5.00, mix(P['g2'], P['bg'], 0.28), 0.9)
    for i, (lab, v) in enumerate(d['items'][:3]):
        x = M + i * 3.90
        _p(s, x, 5.18, 3.6, lab, 12.5, mix(P['bg'], P['g1'], 0.32))
        txt(s, x, 5.48, 3.6, 0.32, v, 14, _on(), 'md')
