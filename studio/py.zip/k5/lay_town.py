"""20 เลย์เอาต์ชุด Town Hall — ลอกโครงจากเทมเพลตน้ำเงิน+มิ้นต์ที่ไอซ์ส่งมา

หน้าเป็นสองพื้น: พื้นขาวนวล (panel) กับพื้นน้ำเงินเต็ม (acc) สลับกันไป
ปุ่มและจุดเน้นใช้มิ้นต์ (acc2) โลโก้มุมล่างซ้ายทุกหน้าที่ไม่ใช่ปก
"""
from eng import *
import eng
from lay import L, reg


def _duo():
    """ย้อมรูปให้อยู่ในโทนเดียวกับพาเลตต์ของเด็ค ไม่ให้สีรูปตีกับสีธีม"""
    if P.get('dark'):
        return f"duo:{mix(P['bg'], P['acc'], 0.34)}:{mix(P['acc'], 'FFFFFF', 0.54)}"
    return f"duo:{mix(P['ink'], P['acc'], 0.42)}:{mix(P['bg'], P['acc'], 0.13)}"

M = 0.78


def _logo(s, x, y, light=False, name=None, sz=0.30):
    """เครื่องหมายบริษัท: สี่เหลี่ยมมนมีรูปธงขาวอยู่ข้างใน"""
    c = 'FFFFFF' if light else P['acc']
    ic = P['acc'] if light else 'FFFFFF'
    shp(s, 'round', x, y, sz, sz, c, adj=0.26)
    shp(s, 'rect', x + sz * 0.26, y + sz * 0.24, sz * 0.17, sz * 0.52, ic)
    shp(s, 'tri', x + sz * 0.50, y + sz * 0.24, sz * 0.24, sz * 0.30, ic, rot=180)
    if name:
        txt(s, x + sz + 0.16, y + 0.01, 3.0, 0.28, name, 15, 'FFFFFF' if light else P['ink'], 'md')


def _foot(s, d, light=False):
    _logo(s, M, H - 0.92, light)


def _lab(s, x, y, t, light=False):
    if t: txt(s, x, y, 4.0, 0.24, t, 13, 'C9D6FF' if light else P['mute'], 'md')


def _h(s, x, y, t, sz=38, w=6.4, light=False):
    txt(s, x, y, w, 1.3, t, sz, 'FFFFFF' if light else P['acc'], 'md', sp=1.16)


def _p(s, x, y, w, t, sz=13.5, light=False):
    txt(s, x, y, w, 1.4, t, sz, 'DCE6FF' if light else mix(P['bg'], P['ink'], 0.62), 'rg', sp=1.42)


def _btn(s, x, y, t, sz=13.5):
    w = len(t) * 0.072 + 0.52
    shp(s, 'round', x, y, w, 0.40, P['acc2'], adj=0.5)
    txt(s, x, y, w, 0.40, t, sz, P['ink'], 'md', 'c', 'm')
    return w


def _mark(s, x, y, sz=0.26):
    """สามเหลี่ยมมุมเล็ก ๆ ที่ต้นฉบับใช้คั่นหัวข้อ"""
    shp(s, 'tri', x, y, sz, sz * 0.8, P['acc'], rot=315)


# ══ 7 เลย์เอาต์ตามรูปอ้างอิง ═══════════════════════════════════════════════

@reg
def tw_cover(prs, d):
    s = page(prs, P['acc'])
    pw = 5.95
    pic(s, ph(d['topic'], d.get('pi', 0)), W - pw, 0, pw, H, focus=(0.45, 0.35), mode=_duo())
    _logo(s, M, 0.78, True, d.get('brand', 'Your Company'))
    txt(s, M, 1.62, 6.3, 2.9, d['t'], d.get('tsz', 42), 'FFFFFF', 'md', sp=1.12)
    txt(s, M, 4.72, 5.6, 0.86, d['s'], 16, 'DCE6FF', 'rg', sp=1.4)
    _btn(s, M, 5.86, d.get('cta', 'อ่านต่อ'), 9)


@reg
def tw_agenda(prs, d):
    s = page(prs, P['panel'])
    _h(s, M, 0.86, d['t'], 41, 5.0)
    _mark(s, 5.62, 1.72)
    x, w = 6.10, W - M - 6.10
    for i, it in enumerate(d['items'][:7]):
        y = 1.98 + i * 0.52
        txt(s, x, y, w, 0.36, it, 16.5, P['acc'], 'rg', an='m')
        ln(s, x, y + 0.42, x + w, y + 0.42, mix(P['panel'], P['acc'], 0.35), 0.7)
    _foot(s, d)


@reg
def tw_qa(prs, d):
    s = page(prs, P['acc'])
    pw = 4.55
    pic(s, ph(d['topic'], d.get('pi', 1)), W - pw, 0, pw, H, focus=(0.5, 0.45), mode=_duo())
    _h(s, M, 0.86, d['t'], 41, 5.6, True)
    _lab(s, M, 1.78, d.get('k', ''), True)
    _p(s, M, 2.14, 6.6, d['note'], 13.5, True)
    _btn(s, M, 4.52, d.get('cta', 'ถามได้เลย'))
    _foot(s, d, True)


@reg
def tw_stats3(prs, d):
    s = page(prs, P['acc'])
    _h(s, M, 0.86, d['t'], 41, 7.0, True)
    _lab(s, M, 1.78, d.get('k', ''), True)
    y0 = 2.42
    ln(s, M, y0, W - M, y0, mix(P['acc'], 'FFFFFF', 0.45), 0.8)
    cw = (W - M * 2) / 3
    for i, (v, unit, lab, body) in enumerate(d['items'][:3]):
        x = M + i * cw
        if i:
            ln(s, x, y0, x, H - 1.35, mix(P['acc'], 'FFFFFF', 0.30), 0.7)
            shp(s, 'tri', x - 0.13, y0, 0.26, 0.20, P['acc'], rot=180)
        txt(s, x + 0.34, y0 + 0.36, 2.6, 0.98, v, 54, 'FFFFFF', 'md')
        txt(s, x + 0.34 + len(v) * 0.49, y0 + 0.84, 1.0, 0.36, unit, 16, 'FFFFFF','md')
        txt(s, x + 0.34, y0 + 1.30, cw - 0.68, 0.30, lab, 15, 'FFFFFF', 'md')
        _p(s, x + 0.34, y0 + 1.70, cw - 0.78, body, 13, True)
    _foot(s, d, True)


@reg
def tw_gantt(prs, d):
    s = page(prs, P['panel'])
    _h(s, M, 0.86, d['t'], 41, 7.0)
    _lab(s, M, 1.78, d.get('k', ''))
    _p(s, M, 2.10, W - M * 2, d['note'], 13)
    gx, gw = 3.30, W - M - 3.30
    cols = d['cols']; n = len(cols); cwid = gw / n
    top, rh = 3.62, 0.58
    for j, c in enumerate(cols):
        txt(s, gx + j * cwid, top - 0.40, cwid, 0.28, c, 8.5, P['mute'], 'rg')
        if j: ln(s, gx + j * cwid, top - 0.10, gx + j * cwid, top + len(d['rows'][:4]) * rh, mix(P['panel'], P['ink'], 0.16), 0.6)
    for i, (lab, a_, b_) in enumerate(d['rows'][:4]):
        y = top + i * rh
        txt(s, M, y, 2.3, 0.34, lab, 14, P['ink'], 'rg', an='m')
        bx = gx + a_ * cwid; bw = max((b_ - a_) * cwid, 0.5)
        shp(s, 'rect', bx, y + 0.05, bw, 0.26, P['acc'])
        shp(s, 'rect', bx + bw - 0.07, y + 0.05, 0.07, 0.26, P['acc2'])
        txt(s, bx + 0.12, y + 0.05, bw - 0.24, 0.26, d.get('bart', ''), 7, 'FFFFFF', 'rg', an='m')
    mx = gx + d.get('now', 1.6) * cwid
    ln(s, mx, top - 0.52, mx, top + len(d['rows'][:4]) * rh + 0.18, P['acc2'], 1.1)
    shp(s, 'tri', mx, top - 0.60, 0.20, 0.20, P['acc2'], rot=90)
    _foot(s, d)


@reg
def tw_icons3(prs, d):
    s = page(prs, P['panel'])
    _h(s, M, 0.86, d['t'], 41, 7.0)
    _lab(s, M, 1.78, d.get('k', ''))
    cw = (W - M * 2 - 0.46) / 3
    for i, (h_, body) in enumerate(d['items'][:3]):
        x = M + i * (cw + 0.23)
        card(s, x, 2.28, cw, 3.42, 'FFFFFF', adj=0.07, line=mix(P['panel'], P['acc'], 0.25))
        shp(s, 'round', x + 0.34, 2.60, 0.90, 0.90, mix(P['panel'], P['acc'], 0.14), adj=0.22)
        _glyph(s, i, x + 0.52, 2.78, 0.54)
        txt(s, x + 0.34, 3.80, cw - 0.68, 0.62, h_, 16.5, P['acc'], 'md', sp=1.25)
        _p(s, x + 0.34, 4.54, cw - 0.68, body, 13)
    _foot(s, d)


def _glyph(s, k, x, y, sz):
    """ไอคอนเรขาคณิตสามแบบ แบบเดียวกับที่ต้นฉบับใช้"""
    c = P['acc']
    if k == 0:
        shp(s, 'moon', x, y, sz * 0.52, sz, c, rot=20)
        shp(s, 'moon', x + sz * 0.48, y, sz * 0.52, sz, c, rot=200)
    elif k == 1:
        shp(s, 'tri', x, y, sz * 0.5, sz, c, rot=180)
        shp(s, 'tri', x + sz * 0.5, y, sz * 0.5, sz * 0.52, c, rot=180)
        shp(s, 'tri', x + sz * 0.5, y + sz * 0.52, sz * 0.5, sz * 0.48, c)
    else:
        for r in range(2):
            for q in range(2):
                shp(s, 'pie' if (r + q) % 2 else 'rect', x + q * sz * 0.52, y + r * sz * 0.52,
                    sz * 0.44, sz * 0.44, c, adj=[0, 270] if (r + q) % 2 else None)


@reg
def tw_thanks(prs, d):
    s = page(prs, P['acc'])
    _logo(s, W - M - 2.6, 0.80, True, d.get('brand', 'Your Company'))
    txt(s, M, 2.35, 8.0, 2.5, d['t'], 48, 'FFFFFF', 'md', sp=1.16)
    if d.get('s'): _p(s, M, 5.10, 6.4, d['s'], 15, True)


# ══ อีก 13 เลย์เอาต์ เติมให้ครบ 20 หน้า ════════════════════════════════════

@reg
def tw_welcome(prs, d):
    s = page(prs, P['panel'])
    pic(s, ph(d['topic'], d.get('pi', 2)), 0, 0, W, 3.05, focus=(0.5, 0.38), mode=_duo())
    _h(s, M, 3.42, d['t'], 41, 6.0)
    _lab(s, M, 4.36, d.get('k', ''))
    _p(s, M, 4.68, 5.6, d['note'], 13.5)
    for i, (v, lb) in enumerate(d['items'][:3]):
        x = 7.35 + i * 1.86
        txt(s, x, 3.72, 1.7, 0.56, v, 37, P['acc'], 'md')
        _p(s, x, 4.34, 1.7, lb, 13)
    _foot(s, d)


@reg
def tw_two_col(prs, d):
    s = page(prs, P['panel'])
    _h(s, M, 0.86, d['t'], 41, 7.4)
    _lab(s, M, 1.84, d.get('k', ''))
    cw = (W - M * 2 - 0.42) / 2
    for i, (h_, body) in enumerate(d['items'][:2]):
        x = M + i * (cw + 0.42)
        card(s, x, 2.26, cw, 2.05, 'FFFFFF', adj=0.08, line=mix(P['panel'], P['acc'], 0.25))
        txt(s, x + 0.34, 2.52, cw - 0.68, 0.40, h_, 16.5, P['acc'], 'md')
        _p(s, x + 0.34, 3.02, cw - 0.68, body, 13)
    pic(s, ph(d['topic'], d.get('pi', 3)), M, 4.56, W - M * 2, 2.08, geom='roundRect', adj=0.08, focus=(0.5, 0.42), mode=_duo())
    _foot(s, d)


@reg
def tw_divider(prs, d):
    s = page(prs, P['acc'])
    txt(s, M, 2.20, 3.0, 1.5, d['num'], 54, mix(P['acc'], 'FFFFFF', 0.45), 'md')
    txt(s, M, 3.72, 8.2, 1.2, d['t'], 47, 'FFFFFF', 'md', sp=1.14)
    if d.get('s'): _p(s, M, 4.98, 7.0, d['s'], 14.5, True)
    _btn(s, M, 5.86, d.get('cta', 'ไปต่อ'))
    _foot(s, d, True)


@reg
def tw_bars(prs, d):
    s = page(prs, P['panel'])
    _h(s, M, 0.86, d['t'], 41, 7.0)
    _lab(s, M, 1.84, d.get('k', ''))
    _p(s, M, 2.16, W - M * 2, d.get('note', ''), 13)
    n = len(d['bars'][:5]); gw = W - M * 2
    bw = gw / n * 0.46
    base, top = 5.72, 3.30
    mx = max(v for _, v, _ in d['bars'][:5]) or 1
    ln(s, M, base, W - M, base, mix(P['panel'], P['ink'], 0.2), 0.7)
    for i, (lab, v, note) in enumerate(d['bars'][:5]):
        cx = M + gw / n * (i + 0.5)
        h = (base - top) * v / mx
        gradband(s, cx - bw / 2, base - h, bw, h, 90, c1=P['acc'], c2=mix(P['acc'], 'FFFFFF', 0.45))
        txt(s, cx - bw / 2 - 0.3, base - h - 0.44, bw + 0.6, 0.36, note, 16, P['acc'], 'md', 'c')
        txt(s, cx - gw / n / 2, base + 0.14, gw / n, 0.30, lab, 14, P['ink'], 'rg', 'c')
    _foot(s, d)


@reg
def tw_timeline(prs, d):
    s = page(prs, P['acc'])
    _h(s, M, 0.86, d['t'], 41, 7.0, True)
    _lab(s, M, 1.84, d.get('k', ''), True)
    n = len(d['items'][:4]); cw = (W - M * 2) / n
    ln(s, M, 3.28, W - M, 3.28, mix(P['acc'], 'FFFFFF', 0.35), 0.8)
    for i, (per, h_, body) in enumerate(d['items'][:4]):
        x = M + i * cw
        shp(s, 'oval', x, 3.14, 0.28, 0.28, P['acc2'] if i < 2 else 'FFFFFF')
        txt(s, x, 2.62, cw - 0.4, 0.32, per, 15.5, P['acc2'] if i < 2 else 'FFFFFF', 'md')
        txt(s, x, 3.68, cw - 0.45, 0.56, h_, 16, 'FFFFFF', 'md', sp=1.25)
        _p(s, x, 4.38, cw - 0.52, body, 13, True)
    _foot(s, d, True)


@reg
def tw_people(prs, d):
    s = page(prs, P['panel'])
    _h(s, M, 0.86, d['t'], 41, 7.0)
    _lab(s, M, 1.84, d.get('k', ''))
    cw = (W - M * 2 - 0.46) / 3
    for i, (name, role, note) in enumerate(d['items'][:3]):
        x = M + i * (cw + 0.23)
        card(s, x, 2.32, cw, 3.38, 'FFFFFF', adj=0.07, line=mix(P['panel'], P['acc'], 0.25))
        pic(s, ph(d.get('ptopic', 'office'), d.get('pi', 4) + i), x + 0.28, 2.58, cw - 0.56, 1.42,
            geom='roundRect', adj=0.07, focus=(0.5, 0.36), mode=_duo())
        txt(s, x + 0.28, 4.18, cw - 0.56, 0.34, name, 16.5, P['acc'], 'md')
        txt(s, x + 0.28, 4.56, cw - 0.56, 0.28, role, 13.5, P['mute'], 'rg')
        _p(s, x + 0.28, 4.92, cw - 0.56, note, 13)
    _foot(s, d)


@reg
def tw_quote(prs, d):
    s = page(prs, P['acc'])
    pw = 4.30
    pic(s, ph(d.get('ptopic', 'office'), d.get('pi', 7)), W - pw, 0, pw, H, focus=(0.5, 0.4), mode=_duo())
    txt(s, M, 1.55, 1.2, 0.9, '"', 54, P['acc2'], 'md')
    txt(s, M, 2.42, 7.4, 2.3, d['t'], 31, 'FFFFFF', 'md', sp=1.3)
    ln(s, M, 5.02, M + 3.0, 5.02, mix(P['acc'], 'FFFFFF', 0.45), 0.8)
    txt(s, M, 5.18, 5.4, 0.30, d['who'], 15.5, 'FFFFFF', 'md')
    _p(s, M, 5.52, 5.4, d['role'], 13.5, True)
    _foot(s, d, True)


@reg
def tw_table(prs, d):
    s = page(prs, P['panel'])
    _h(s, M, 0.86, d['t'], 41, 7.4)
    _lab(s, M, 1.84, d.get('k', ''))
    tw = W - M * 2; cols = d['colw']; y0 = 2.46
    shp(s, 'rect', M, y0, tw, 0.56, P['acc'])
    cx = M
    for j, (hd, fr) in enumerate(zip(d['head'], cols)):
        txt(s, cx + 0.22, y0, tw * fr - 0.44, 0.56, hd, 14.5, 'FFFFFF', 'md', 'l' if j == 0 else 'r', 'm')
        cx += tw * fr
    for i, row in enumerate(d['rows'][:5]):
        y = y0 + 0.56 + i * 0.60
        if i % 2 == 0: shp(s, 'rect', M, y, tw, 0.60, 'FFFFFF')
        cx = M
        for j, (cell, fr) in enumerate(zip(row, cols)):
            txt(s, cx + 0.22, y, tw * fr - 0.44, 0.60, cell, 15, P['ink'],
                'md' if j == len(cols) - 1 else 'rg', 'l' if j == 0 else 'r', 'm')
            cx += tw * fr
    if d.get('note'): _p(s, M, y0 + 0.56 + len(d['rows'][:5]) * 0.60 + 0.20, 9.5, d['note'], 13)
    _foot(s, d)


@reg
def tw_compare(prs, d):
    s = page(prs, P['panel'])
    _h(s, M, 0.86, d['t'], 41, 7.4)
    _lab(s, M, 1.84, d.get('k', ''))
    cw = (W - M * 2 - 0.42) / 2
    for c, (ttl, rows) in enumerate(zip(d['heads'], [d['before'], d['after']])):
        x = M + c * (cw + 0.42)
        hot = c == 1
        card(s, x, 2.30, cw, 3.46, P['acc'] if hot else 'FFFFFF', adj=0.07,
             line=None if hot else mix(P['panel'], P['acc'], 0.25))
        txt(s, x + 0.32, 2.54, cw - 0.64, 0.36, ttl, 16, 'FFFFFF' if hot else P['acc'], 'md')
        for i, (lab, v) in enumerate(rows[:4]):
            y = 3.14 + i * 0.64
            txt(s, x + 0.32, y, cw - 1.80, 0.44, lab, 14, 'FFFFFF' if hot else P['ink'], 'rg', an='m')
            txt(s, x + cw - 1.60, y, 1.28, 0.44, v, 16, 'FFFFFF' if hot else P['acc'], 'md', 'r', 'm')
            ln(s, x + 0.32, y + 0.52, x + cw - 0.32, y + 0.52,
               mix(P['acc'], 'FFFFFF', 0.3) if hot else mix(P['panel'], P['ink'], 0.14), 0.6)
    _foot(s, d)


@reg
def tw_steps(prs, d):
    s = page(prs, P['panel'])
    _h(s, M, 0.86, d['t'], 41, 5.0)
    _lab(s, M, 1.84, d.get('k', ''))
    _p(s, M, 2.16, 4.4, d.get('note', ''), 13)
    x = 5.95
    n = len(d['items'][:4])
    ln(s, x + 0.19, 1.12, x + 0.19, 1.12 + (n - 1) * 1.30 + 0.38, mix(P['panel'], P['acc'], 0.35), 0.8)
    for i, (h_, body) in enumerate(d['items'][:4]):
        y = 1.12 + i * 1.30
        shp(s, 'oval', x, y, 0.38, 0.38, P['acc'])
        txt(s, x, y, 0.38, 0.38, f'{i + 1}', 15, 'FFFFFF', 'md', 'c', 'm')
        txt(s, x + 0.66, y - 0.04, 6.0, 0.38, h_, 16.5, P['acc'], 'md')
        _p(s, x + 0.66, y + 0.40, 5.9, body, 13)
    _foot(s, d)


@reg
def tw_photo_list(prs, d):
    s = page(prs, P['panel'])
    pic(s, ph(d['topic'], d.get('pi', 5)), 0, 0, 5.70, H, focus=(0.5, 0.42), mode=_duo())
    _h(s, 6.40, 0.92, d['t'], 38, 5.9)
    _lab(s, 6.40, 2.10, d.get('k', ''))
    for i, (h_, body) in enumerate(d['items'][:4]):
        y = 2.48 + i * 1.02
        txt(s, 6.40, y, 0.44, 0.30, f'{i + 1:02d}', 14.5, P['acc'], 'md')
        txt(s, 7.00, y, 5.5, 0.30, h_, 16, P['acc'], 'md')
        _p(s, 7.00, y + 0.34, 5.4, body, 13)
        ln(s, 6.40, y + 0.86, W - M, y + 0.86, mix(P['panel'], P['acc'], 0.28), 0.6)
    _foot(s, d)


@reg
def tw_kpi4(prs, d):
    s = page(prs, P['acc'])
    _h(s, M, 0.86, d['t'], 41, 7.4, True)
    _lab(s, M, 1.84, d.get('k', ''), True)
    cw = (W - M * 2 - 0.42) / 2
    for i, (v, lab, body) in enumerate(d['items'][:4]):
        x = M + (i % 2) * (cw + 0.42)
        y = 2.34 + (i // 2) * 1.86
        card(s, x, y, cw, 1.62, mix(P['acc'], 'FFFFFF', 0.12), adj=0.08)
        txt(s, x + 0.34, y + 0.22, 2.4, 0.56, v, 40, P['acc2'] if i % 3 == 0 else 'FFFFFF', 'md')
        txt(s, x + 0.34, y + 0.84, cw - 0.68, 0.30, lab, 15, 'FFFFFF', 'md')
        _p(s, x + 0.34, y + 1.16, cw - 0.68, body, 13, True)
    _foot(s, d, True)


@reg
def tw_next(prs, d):
    s = page(prs, P['panel'])
    _h(s, M, 0.86, d['t'], 41, 7.4)
    _lab(s, M, 1.84, d.get('k', ''))
    cw = (W - M * 2 - 0.46) / 3
    for i, (h_, body, who) in enumerate(d['items'][:3]):
        x = M + i * (cw + 0.23)
        card(s, x, 2.34, cw, 2.92, 'FFFFFF' if i else P['acc'], adj=0.07,
             line=mix(P['panel'], P['acc'], 0.25) if i else None)
        txt(s, x + 0.32, 2.58, 0.6, 0.32, f'{i + 1:02d}', 15.5, 'FFFFFF' if not i else P['acc'], 'md')
        txt(s, x + 0.32, 3.06, cw - 0.64, 0.62, h_, 16.5, 'FFFFFF' if not i else P['acc'], 'md', sp=1.25)
        _p(s, x + 0.32, 3.84, cw - 0.64, body, 13, light=not i)
        ln(s, x + 0.32, 4.68, x + cw - 0.32, 4.68,
           mix(P['acc'], 'FFFFFF', 0.35) if not i else mix(P['panel'], P['ink'], 0.14), 0.6)
        txt(s, x + 0.32, 4.80, cw - 0.64, 0.28, who, 13.5, 'FFFFFF' if not i else P['ink'], 'md')
    _btn(s, M, 5.70, d.get('cta', 'เริ่มสัปดาห์หน้า'))
    _foot(s, d)


@reg
def tw_divider2(prs, d):
    """หน้าคั่นแบบที่สอง (กฎไอซ์: ห้ามใช้โครงซ้ำในเด็คเดียว) พื้นขาว รูปคาดขวา"""
    s = page(prs, P['panel'])
    pic(s, ph(d['topic'], d.get('pi', 6)), 7.15, 0, W - 7.15, H, focus=(0.5, 0.42), mode=_duo())
    txt(s, M, 2.00, 3.0, 1.5, d['num'], 54, mix(P['panel'], P['acc'], 0.55), 'md')
    ln(s, M, 3.52, 5.95, 3.52, mix(P['panel'], P['acc'], 0.4), 0.9)
    txt(s, M, 3.72, 5.5, 1.2, d['t'], 44, P['acc'], 'md', sp=1.14)
    if d.get('s'): _p(s, M, 4.96, 5.3, d['s'], 14.5)
    _btn(s, M, 5.86, d.get('cta', 'ไปต่อ'))
    _foot(s, d)
