"""20 เลย์เอาต์ชุด Modern Technology — ลอกโครงจากเทมเพลตน้ำเงิน-ม่วงเข้มที่ไอซ์ส่งมา

พื้นเข้มทั้งเล่ม มีแถบเมนูเว็บด้านบน (โลโก้ขีด + Home/About Us/Product/Service + Menu)
จุดเน้นเป็นไล่เฉดน้ำเงินไปม่วง ป้ายในวงเล็บเหลี่ยมที่มุมล่าง
"""
from eng import *
import eng
from lay import L, reg


def _duo():
    """ย้อมรูปให้อยู่ในโทนเดียวกับพาเลตต์ของเด็ค ไม่ให้สีรูปตีกับสีธีม"""
    if P.get('dark'):
        return f"duo:{mix(P['bg'], P['acc'], 0.34)}:{mix(P['acc'], 'FFFFFF', 0.54)}"
    return f"duo:{mix(P['ink'], P['acc'], 0.42)}:{mix(P['bg'], P['acc'], 0.13)}"

M = 0.70
NAV = ['Home', 'About Us', 'Product', 'Service']


def _bar(s, d, on_light=False):
    c = P['ink'] if not on_light else '0B0B1E'
    for i, w in enumerate((0.16, 0.09, 0.05)):
        shp(s, 'rect', M + i * 0.20, 0.36, w, 0.10, c if i < 2 else mix(P['bg'], c, 0.45))
    x = 2.55
    for n in NAV:
        w = len(n) * 0.068 + 0.30
        txt(s, x, 0.32, w, 0.26, n, 13, c, 'rg', 'c', 'm'); x += w + 0.22
    txt(s, W - M - 1.50, 0.32, 1.10, 0.26, 'Menu', 13, c, 'rg', 'r', 'm')
    for i in range(3):
        shp(s, 'oval', W - M - 0.30 + i * 0.11, 0.395, 0.07, 0.07, c)


def _tag(s, x, y, t, c=None):
    if t: txt(s, x, y, 3.4, 0.26, f'[{t}]', 13, c or P['mute'], 'rg')


def _foot(s, d, l='Technology', m2='Modern Company', c=None):
    _tag(s, M, H - 0.62, l, c)
    _tag(s, 5.30, H - 0.62, m2, c)
    if d.get('n'): txt(s, W - M - 0.8, H - 0.62, 0.8, 0.26, str(int(d['n'])), 8, c or P['mute'], 'rg', 'r')


def _h(s, x, y, t, sz=48, w=6.4, c=None, wt='md'):
    txt(s, x, y, w, 2.2, t, sz, c or P['ink'], wt, sp=1.14)


def _p(s, x, y, w, t, sz=13, c=None):
    txt(s, x, y, w, 1.5, t, sz, c or P['mute'], 'rg', sp=1.44)


def _grad(s, x, y, w, h, ang=315, adj=None, kind='rect'):
    return gradband(s, x, y, w, h, ang, c1=P['acc'], c2=P['acc2'], kind=kind, adj=adj)


def _pill(s, x, y, t, fill=None, c=None, sz=13):
    w = len(t) * 0.070 + 0.46
    shp(s, 'round', x, y, w, 0.36, fill or mix(P['bg'], P['ink'], 0.14), adj=0.5)
    txt(s, x, y, w, 0.36, t, sz, c or P['ink'], 'md', 'c', 'm')
    return w


# ══ เลย์เอาต์ตามรูปอ้างอิง ═════════════════════════════════════════════════

@reg
def m_cover(prs, d):
    s = page(prs)
    _grad(s, 6.10, 0, W - 6.10, H, 300)
    _bar(s, d)
    _h(s, M, 1.70, d['t'], 54, 5.2)
    pic(s, ph(d['topic'], d.get('pi', 0)), M, 3.92, 3.10, 1.72, geom='roundRect', adj=0.05, mode=_duo())
    _tag(s, 6.70, 1.74, d.get('k', ''), 'DCE2FF')
    txt(s, 6.70, 2.24, 4.6, 0.62, d['s'], 15.5, 'FFFFFF', 'md', sp=1.3)
    txt(s, 6.70, 3.06, 4.6, 0.80, d['big'], 45, 'FFFFFF', 'md')
    _p(s, 6.70, 3.98, 4.9, d['note'], 13, 'D6DEFF')
    shp(s, 'tri', 11.90, 0.98, 0.42, 0.42, 'FFFFFF', rot=180)
    _foot(s, d)


@reg
def m_toc(prs, d):
    s = page(prs)
    _grad(s, 0, 0, W, H, 300)
    shp(s, 'rect', 0, 0, W, H, '07071A', a=0.58)
    _bar(s, d)
    _tag(s, M, 1.12, d.get('k', 'Table Content Overview'), 'C6CEFF')
    for i, (h_, body) in enumerate(d['items'][:3]):
        y = 1.62 + i * 1.26
        txt(s, M, y + 0.14, 0.9, 0.42, f'({i + 1:02d})', 10, 'C6CEFF', 'rg')
        txt(s, M + 1.30, y, 5.6, 0.68, h_, 34, 'FFFFFF', 'md')
        _p(s, 7.40, y + 0.10, 2.9, body, 13, 'C6CEFF')
        ln(s, M, y + 1.02, W - M, y + 1.02, mix('07071A', 'FFFFFF', 0.22), 0.6)
    pic(s, ph(d['topic'], d.get('pi', 4)), 9.95, 1.56, 2.68, 2.46, geom='roundRect', adj=0.05, mode=_duo())
    shp(s, 'tri', W - 1.30, H - 1.52, 0.46, 0.46, 'FFFFFF', rot=180)
    _foot(s, d, c='C6CEFF')


@reg
def m_hero(prs, d):
    s = page(prs, P['panel'])
    _grad(s, 0, 2.90, W, H - 2.90, 0)
    shp(s, 'rect', 0, 0, W, 4.70, '0B0B1E')
    _bar(s, d)
    _tag(s, M, 1.00, d.get('k', ''), 'B9C1F0')
    _tag(s, 3.50, 1.00, d.get('k2', ''), 'B9C1F0')
    _h(s, M, 1.70, d['t'], 51, 6.2)
    txt(s, 7.20, 1.06, 1.0, 0.32, f"[{d.get('num', '01')}]", 11, 'FFFFFF', 'rg')
    _p(s, 7.20, 1.62, 3.2, d['note'], 13.5, 'C8CEF2')
    pic(s, ph(d['topic'], d.get('pi', 1)), 7.20, 2.86, 2.70, 1.98, geom='roundRect', adj=0.05, mode=_duo())
    txt(s, M, 5.16, 3.3, 0.60, d['s'], 15, 'FFFFFF', 'md', sp=1.3)
    txt(s, 4.70, 5.16, 1.8, 0.60, d['big'], 34, 'FFFFFF', 'md', an='m')
    _p(s, 6.60, 5.24, 2.4, d['biglab'], 13, 'DCE2FF')
    _foot(s, d, c='C8CEF2')


@reg
def m_white(prs, d):
    s = page(prs, 'FFFFFF')
    _bar(s, d, True)
    parts = d['t'].split('|')
    y = 1.30
    for i, part in enumerate(parts[:3]):
        txt(s, M, y + i * 0.78, 9.4, 0.76, part, 51,
            '0B0B1E' if i != 1 else P['acc2'], 'md')
    for i, (lab, body) in enumerate(d['items'][:2]):
        x = M + i * 5.30
        _tag(s, x, 4.26, lab, '6E7390')
        _p(s, x, 4.72, 4.6, body, 13.5, '41465E')
    _foot(s, d, c='6E7390')


@reg
def m_stat_cards(prs, d):
    s = page(prs, 'FFFFFF')
    _bar(s, d, True)
    txt(s, M, 1.30, 3.2, 1.3, d['t'], 45, P['acc2'], 'md', sp=1.14)
    shp(s, 'rect', 3.95, 0.88, 2.70, H - 1.60, '15152E')
    txt(s, 4.22, 1.26, 2.2, 0.60, d['items'][0][0], 34, 'FFFFFF', 'md')
    txt(s, 4.22, 1.92, 2.2, 0.28, d['items'][0][1], 14, 'FFFFFF', 'md')
    _p(s, 4.22, 2.28, 2.2, d['items'][0][2], 13, 'A7ADD2')
    for i, (v, lab, body) in enumerate(d['items'][1:3]):
        x = M + i * 6.35
        y = 4.30
        txt(s, x, y, 2.4, 0.62, v, 37, '0B0B1E', 'md')
        txt(s, x, y + 0.68, 2.4, 0.28, lab, 14, '0B0B1E', 'md')
        _p(s, x, y + 1.02, 2.5, body, 13, '41465E')
    _grad(s, 9.70, 0.88, W - M - 9.70, H - 1.60, 300)
    _p(s, 10.00, 1.26, 2.3, d['note'], 13, 'E2E7FF')
    shp(s, 'round', 2.00, 5.86, 1.45, 0.40, P['acc'], adj=0.5)
    txt(s, 2.00, 5.86, 1.45, 0.40, d.get('cta', 'อ่านต่อ'), 8, 'FFFFFF', 'md', 'c', 'm')
    _foot(s, d, c='6E7390')


@reg
def m_person(prs, d):
    s = page(prs)
    _grad(s, 5.20, 0, W - 5.20, H, 300)
    _bar(s, d)
    _h(s, M, 1.42, d['t'], 42, 4.0)
    _p(s, M, 4.04, 4.0, d['note'], 13)
    pic(s, ph(d.get('ptopic', 'office'), d.get('pi', 2)), 4.70, 0.90, 3.40, H - 1.56, geom='roundRect', adj=0.04, focus=(0.5, 0.34), mode=_duo())
    txt(s, 8.50, 1.30, 4.0, 0.40, d['name'], 17, 'FFFFFF', 'md')
    _p(s, 8.50, 1.74, 4.0, d['role'], 13.5, 'DCE2FF')
    for i, (v, lab) in enumerate(d['items'][:2]):
        y = 3.70 + i * 0.84
        txt(s, 8.50, y, 1.55, 0.44, v, 18, 'FFFFFF', 'md')
        _p(s, 10.20, y + 0.02, 2.2, lab, 13, 'E2E7FF')
    _foot(s, d, c='C8CEF2')


@reg
def m_rows_grad(prs, d):
    s = page(prs)
    _bar(s, d)
    pic(s, ph(d['topic'], d.get('pi', 6)), 0, 0.84, 4.20, H - 0.84, focus=(0.5, 0.42), mode=_duo())
    for i, (h_, body, v) in enumerate(d['items'][:2]):
        y = 1.34 + i * 2.32
        _grad(s, 4.35, y, 4.95, 2.06, 0, adj=None)
        txt(s, 4.62, y + 0.34, 2.5, 0.56, h_, 16, 'FFFFFF', 'md', sp=1.25)
        _p(s, 4.62, y + 1.04, 2.6, body, 13, 'DCE2FF')
        txt(s, 7.45, y + 0.60, 1.7, 0.72, v, 37, 'FFFFFF', 'md')
    pic(s, ph(d['topic'], d.get('pi2', 9)), 9.45, 0.84, W - 9.45, H - 0.84, focus=(0.5, 0.45), mode=_duo())
    shp(s, 'rect', 9.45, 0.84, W - 9.45, H - 0.84, '07071A', a=0.35)
    txt(s, 9.80, 2.30, 3.0, 0.90, d['big'], 48, 'FFFFFF', 'md')
    _p(s, 9.80, 3.26, 2.9, d['biglab'], 13, 'C8CEF2')
    _foot(s, d, c='C8CEF2')


@reg
def m_screens(prs, d):
    s = page(prs, 'FFFFFF')
    _bar(s, d, True)
    shp(s, 'rect', 0, 2.50, W, H - 2.50, '0B0B1E')
    _tag(s, M, 1.10, d.get('k', ''), '6E7390')
    _tag(s, 3.50, 1.10, d.get('k2', ''), '6E7390')
    _h(s, M, 3.00, d['t'], 46, 4.4)
    _p(s, M, 5.30, 5.6, d['note'], 13, 'A7ADD2')
    lx, ly, lw = 6.40, 1.46, 5.40
    lh = lw * 0.60
    shp(s, 'round', lx, ly, lw, lh, '20203C', adj=0.04)
    pic(s, ph(d['topic'], d.get('pi', 3)), lx + 0.12, ly + 0.12, lw - 0.24, lh - 0.24, geom='roundRect', adj=0.02, mode=_duo())
    shp(s, 'round', lx - 0.30, ly + lh, lw + 0.60, 0.20, '33335A', adj=0.5)
    _grad(s, 10.60, 4.20, 2.04, 1.26, 300, adj=0.10, kind='round')
    txt(s, 10.82, 4.38, 1.7, 0.26, d['biglab'], 13, 'FFFFFF', 'md')
    txt(s, 10.82, 4.72, 1.7, 0.52, d['big'], 28, 'FFFFFF', 'md')
    _foot(s, d, c='A7ADD2')


@reg
def m_bignum(prs, d):
    s = page(prs)
    pic(s, ph(d['topic'], d.get('pi', 7)), 0, 0, W, H, focus=(0.5, 0.45), mode=_duo())
    shp(s, 'rect', 0, 0, W, H, '07071A', a=0.76)
    _bar(s, d)
    txt(s, M, 2.00, 7.0, 1.6, d['big'], 54, 'FFFFFF', 'md')
    txt(s, M, 3.72, 6.0, 0.40, d['biglab'], 16.5, P['acc2'], 'md')
    _p(s, M, 4.40, 6.2, d['note'], 14)
    _foot(s, d)


# ══ อีก 11 เลย์เอาต์ ═══════════════════════════════════════════════════════

@reg
def m_divider(prs, d):
    s = page(prs)
    _grad(s, 0, 0, W, H, 300)
    shp(s, 'rect', 0, 0, W, H, '07071A', a=0.50)
    _bar(s, d)
    pic(s, ph(d['topic'], d.get('pi', 8)), 7.60, 1.10, W - M - 7.60, H - 2.00, geom='roundRect', adj=0.05, mode=_duo())
    txt(s, M, 2.10, 2.6, 1.3, d['num'], 54, mix('07071A', 'FFFFFF', 0.50), 'md')
    txt(s, M, 3.52, 6.2, 1.2, d['t'], 43, 'FFFFFF', 'md', sp=1.14)
    if d.get('s'): _p(s, M, 4.80, 6.0, d['s'], 14, 'C8CEF2')
    _foot(s, d, c='C8CEF2')


@reg
def m_grid4(prs, d):
    s = page(prs)
    _bar(s, d)
    _tag(s, M, 1.06, d.get('k', ''))
    _h(s, M, 1.46, d['t'], 43, 6.4)
    _p(s, 7.60, 1.12, 5.0, d.get('note', ''), 13)
    cw, ch = 6.00, 1.62
    for i, (h_, body) in enumerate(d['items'][:4]):
        x = M + (i % 2) * (cw + 0.32)
        y = 3.26 + (i // 2) * (ch + 0.24)
        if i == 1: _grad(s, x, y, cw, ch, 300, adj=0.09, kind='round')
        else: card(s, x, y, cw, ch, P['panel'], adj=0.09)
        txt(s, x + 0.30, y + 0.24, cw - 0.60, 0.32, h_, 15.5, 'FFFFFF', 'md')
        _p(s, x + 0.30, y + 0.64, cw - 0.60, body, 13, 'DCE2FF' if i == 1 else None)
    _foot(s, d)


@reg
def m_timeline(prs, d):
    s = page(prs)
    _bar(s, d)
    _tag(s, M, 1.06, d.get('k', ''))
    _h(s, M, 1.46, d['t'], 43, 7.0)
    n = len(d['items'][:4]); cw = (W - M * 2) / n
    ln(s, M, 3.80, W - M, 3.80, mix(P['bg'], P['ink'], 0.20), 0.8)
    for i, (per, h_, body) in enumerate(d['items'][:4]):
        x = M + i * cw
        shp(s, 'oval', x, 3.66, 0.28, 0.28, P['acc'] if i < 2 else mix(P['bg'], P['ink'], 0.26))
        txt(s, x, 3.16, cw - 0.4, 0.32, per, 15.5, P['acc2'] if i < 2 else P['mute'], 'md')
        txt(s, x, 4.18, cw - 0.45, 0.56, h_, 16, 'FFFFFF', 'md', sp=1.25)
        _p(s, x, 4.88, cw - 0.52, body, 13)
    _foot(s, d)


@reg
def m_table(prs, d):
    s = page(prs)
    _bar(s, d)
    _tag(s, M, 1.06, d.get('k', ''))
    _h(s, M, 1.46, d['t'], 43, 7.6)
    tw = W - M * 2; cols = d['colw']; y0 = 3.00
    _grad(s, M, y0, tw, 0.52, 0)
    cx = M
    for j, (hd, fr) in enumerate(zip(d['head'], cols)):
        txt(s, cx + 0.20, y0, tw * fr - 0.40, 0.52, hd, 14, 'FFFFFF', 'md', 'l' if j == 0 else 'r', 'm'); cx += tw * fr
    for i, row in enumerate(d['rows'][:5]):
        y = y0 + 0.52 + i * 0.56
        if i % 2 == 0: shp(s, 'rect', M, y, tw, 0.56, P['panel'])
        cx = M
        for j, (cell, fr) in enumerate(zip(row, cols)):
            txt(s, cx + 0.20, y, tw * fr - 0.40, 0.56, cell, 14.5,
                'FFFFFF' if j == len(cols) - 1 else mix(P['bg'], P['ink'], 0.82),
                'md' if j == len(cols) - 1 else 'rg', 'l' if j == 0 else 'r', 'm'); cx += tw * fr
    if d.get('note'): _p(s, M, y0 + 0.52 + len(d['rows'][:5]) * 0.56 + 0.18, 9.5, d['note'], 13)
    _foot(s, d)


@reg
def m_compare(prs, d):
    s = page(prs)
    _bar(s, d)
    _tag(s, M, 1.06, d.get('k', ''))
    _h(s, M, 1.46, d['t'], 43, 7.6)
    cw = (W - M * 2 - 0.40) / 2
    for c, (ttl, rows) in enumerate(zip(d['heads'], [d['before'], d['after']])):
        x = M + c * (cw + 0.40)
        hot = c == 1
        if hot: _grad(s, x, 3.00, cw, 3.10, 300, adj=0.07, kind='round')
        else: card(s, x, 3.00, cw, 3.10, P['panel'], adj=0.07)
        txt(s, x + 0.32, 3.24, cw - 0.64, 0.34, ttl, 15, 'FFFFFF', 'md')
        for i, (lab, v) in enumerate(rows[:4]):
            y = 3.78 + i * 0.56
            txt(s, x + 0.32, y, cw - 1.70, 0.40, lab, 13.5, mix(P['bg'], P['ink'], 0.80), 'rg', an='m')
            txt(s, x + cw - 1.50, y, 1.20, 0.40, v, 15.5, 'FFFFFF', 'md', 'r', 'm')
            ln(s, x + 0.32, y + 0.46, x + cw - 0.32, y + 0.46, mix(P['bg'], P['ink'], 0.20), 0.6)
    _foot(s, d)


@reg
def m_pricing(prs, d):
    s = page(prs)
    _bar(s, d)
    _tag(s, M, 1.06, d.get('k', ''))
    _h(s, M, 1.46, d['t'], 43, 7.6)
    cw = (W - M * 2 - 0.44) / 3
    for i, (name, price, unit, feats) in enumerate(d['items'][:3]):
        x = M + i * (cw + 0.22)
        hot = i == 1
        if hot: _grad(s, x, 2.96, cw, 2.96, 300, adj=0.07, kind='round')
        else: card(s, x, 2.96, cw, 2.96, P['panel'], adj=0.07)
        txt(s, x + 0.30, 3.18, cw - 0.60, 0.30, name, 15, 'FFFFFF', 'md')
        txt(s, x + 0.30, 3.58, cw - 0.60, 0.56, price, 31, 'FFFFFF', 'md')
        _p(s, x + 0.30, 4.20, cw - 0.60, unit, 13, 'DCE2FF' if hot else None)
        ln(s, x + 0.30, 4.60, x + cw - 0.30, 4.60, mix(P['bg'], P['ink'], 0.24), 0.6)
        for j, f in enumerate(feats[:3]):
            txt(s, x + 0.56, 4.72 + j * 0.36, cw - 0.86, 0.30, f, 13, mix(P['bg'], P['ink'], 0.85), 'rg', an='m')
            shp(s, 'oval', x + 0.30, 4.84 + j * 0.36, 0.10, 0.10, P['acc2'] if not hot else 'FFFFFF')
    _foot(s, d)


@reg
def m_team(prs, d):
    s = page(prs)
    _bar(s, d)
    _tag(s, M, 1.06, d.get('k', ''))
    _h(s, M, 1.46, d['t'], 43, 6.0)
    _p(s, 7.60, 1.12, 5.0, d.get('note', ''), 13)
    cw = (W - M * 2 - 0.44) / 3
    for i, (name, role, note) in enumerate(d['items'][:3]):
        x = M + i * (cw + 0.22)
        card(s, x, 3.06, cw, 2.92, P['panel'], adj=0.07)
        pic(s, ph(d.get('ptopic', 'office'), d.get('pi', 10) + i), x + 0.26, 3.30, cw - 0.52, 1.26,
            geom='roundRect', adj=0.07, focus=(0.5, 0.36), mode=_duo())
        txt(s, x + 0.26, 4.72, cw - 0.52, 0.32, name, 16, 'FFFFFF', 'md')
        _p(s, x + 0.26, 5.08, cw - 0.52, role, 13, P['acc2'])
        _p(s, x + 0.26, 5.40, cw - 0.52, note, 13)
    _foot(s, d)


@reg
def m_process(prs, d):
    s = page(prs)
    _bar(s, d)
    _tag(s, M, 1.06, d.get('k', ''))
    _h(s, M, 1.46, d['t'], 43, 4.6)
    _p(s, M, 3.70, 4.4, d.get('note', ''), 13)
    x = 5.90
    n = len(d['items'][:4])
    ln(s, x + 0.19, 1.14, x + 0.19, 1.14 + (n - 1) * 1.32 + 0.38, mix(P['bg'], P['ink'], 0.20), 0.8)
    for i, (h_, body) in enumerate(d['items'][:4]):
        y = 1.14 + i * 1.32
        shp(s, 'oval', x, y, 0.38, 0.38, P['acc'] if i < 2 else mix(P['bg'], P['ink'], 0.22))
        txt(s, x, y, 0.38, 0.38, f'{i + 1}', 15, 'FFFFFF', 'md', 'c', 'm')
        txt(s, x + 0.66, y - 0.02, 6.0, 0.32, h_, 16, 'FFFFFF', 'md')
        _p(s, x + 0.66, y + 0.36, 5.9, body, 13)
    _foot(s, d)


@reg
def m_quote(prs, d):
    s = page(prs)
    _grad(s, 0, 0, W, H, 300)
    shp(s, 'rect', 0, 0, W, H, '07071A', a=0.52)
    _bar(s, d)
    pic(s, ph(d.get('ptopic', 'office'), d.get('pi', 13)), W - 4.30, 1.00, 4.30 - M, H - 2.00, geom='roundRect', adj=0.05, focus=(0.5, 0.4), mode=_duo())
    txt(s, M, 1.50, 1.2, 0.9, '"', 54, 'FFFFFF', 'bd')
    txt(s, M, 2.36, 7.2, 2.2, d['t'], 30, 'FFFFFF', 'md', sp=1.3)
    ln(s, M, 4.92, M + 2.8, 4.92, mix('07071A', 'FFFFFF', 0.38), 0.8)
    txt(s, M, 5.08, 5.2, 0.30, d['who'], 15, 'FFFFFF', 'md')
    _p(s, M, 5.42, 5.2, d['role'], 13, 'C8CEF2')
    _foot(s, d, c='C8CEF2')


@reg
def m_market(prs, d):
    s = page(prs)
    _bar(s, d)
    _tag(s, M, 1.06, d.get('k', ''))
    _h(s, M, 1.46, d['t'], 43, 5.2)
    _p(s, M, 3.30, 5.0, d['note'], 13)
    for i, (v, lab, sub_) in enumerate(d['items'][:3]):
        y = 4.28 + i * 0.74
        ln(s, M, y, 5.80, y, mix(P['bg'], P['ink'], 0.18), 0.6)
        txt(s, M, y + 0.12, 1.8, 0.42, v, 17, 'FFFFFF', 'md')
        txt(s, M + 1.90, y + 0.10, 1.7, 0.26, lab, 13.5, 'FFFFFF', 'md')
        _p(s, M + 1.90, y + 0.36, 3.7, sub_, 13)
    _grad(s, 6.60, 1.00, W - M - 6.60, H - 2.00, 300, adj=0.06, kind='round')
    txt(s, 7.00, 1.60, 4.8, 0.84, d['big'], 48, 'FFFFFF', 'md')
    _p(s, 7.00, 2.56, 4.8, d['biglab'], 13.5, 'DCE2FF')
    _p(s, 7.00, 4.10, 4.8, d.get('note2', ''), 13, 'DCE2FF')
    _foot(s, d)


@reg
def m_thanks(prs, d):
    s = page(prs)
    pic(s, ph(d['topic'], d.get('pi', 14)), 0, 0, W, H, focus=(0.5, 0.45), mode=_duo())
    shp(s, 'rect', 0, 0, W, H, '07071A', a=0.72)
    _bar(s, d)
    txt(s, M, 2.26, 8.2, 2.0, d['t'], 54, 'FFFFFF', 'md', sp=1.12)
    for i, (lab, v) in enumerate(d['items'][:3]):
        x = M + i * 3.60
        y = 5.00
        _pill(s, x, y, lab, mix('07071A', 'FFFFFF', 0.16))
        _p(s, x, y + 0.48, 3.2, v, 13, 'C8CEF2')
    _foot(s, d, c='C8CEF2')
