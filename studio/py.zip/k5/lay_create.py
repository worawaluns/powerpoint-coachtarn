"""20 เลย์เอาต์ชุดเวิร์กช็อปการเรียนรู้เชิงสร้างสรรค์ ดำ+เหลือง+ครีม — ลอกโครงจากเทมเพลต Licoria & Co.

สลับหน้าดำกับหน้าครีม บล็อกเหลืองมนมุมใหญ่ซ้อนใต้รูป รูปมนมุมมีรอยบากตัดมุม
ดอกจันเหลืองแปดแฉก ลูกศรเฉียงเหลือง หัวกระดาษมีขีดตั้งเหลืองคั่นชื่อ หัวเรื่องเหลืองบนดำ / ดำบนครีม
ตัวหนังสือบนเหลืองใช้ดำเสมอ (12.7) เหลืองบนครีมห้ามเป็นตัวหนังสือ
"""
from eng import *
import eng
from lay import L, reg

txt = txt_big        # ขนาดขั้นต่ำตามชุด 366 ดู eng.roomy()
chart = chart_big

M = 0.62
K = '1C1C1C'
CR = 'EFEDE6'
MUTE = '5A5852'
SOFT = 'BDBDB8'


def Y(): return P['acc']


def _duo(): return f"duo:{mix(K, '3A3420', 0.5)}:{mix(CR, Y(), 0.12)}"


def _photo(s, n, x, y, w, h, adj=0.10, focus=(0.5, 0.45), geom='roundRect'):
    return pic(s, ph('learn', n), x, y, w, h, geom=geom, adj=adj, focus=focus, mode=_duo())


def _chrome(s, d, dark):
    c = 'FFFFFF' if dark else K
    for x, t in ((M, d.get('brand', 'สตูดิโอของคุณ')), (M + 2.40, d.get('doc', 'เวิร์กช็อป'))):
        shp(s, 'rect', x, 0.36, 0.05, 0.28, Y())
        txt(s, x + 0.15, 0.34, 2.2, 0.32, t, 10, c, 'md')
    shp(s, 'rect', W - M - 0.05, 0.36, 0.05, 0.28, Y())
    txt(s, W - M - 1.4, 0.34, 1.25, 0.32, d.get('yr', '2570'), 10, c, 'md', 'r')


def _page(prs, d, dark):
    s = page(prs, K if dark else CR)
    _chrome(s, d, dark)
    return s


def _h(s, x, y, t, sz=40, w=7.0, dark=True, al='l'):
    txt(s, x, y, w, 2.6, t, sz, Y() if dark else K, 'md', al, sp=1.02)


def _p(s, x, y, w, t, sz=11.5, dark=True, c=None, al='l'):
    if t: txt(s, x, y, w, 2.0, t, sz, c or (SOFT if dark else MUTE), 'rg', al, sp=1.38)


def _star(s, cx, cy, sz, c=None):
    c = c or Y()
    for a in (0, 45, 90, 135):
        shp(s, 'round', cx - sz * 0.07, cy - sz / 2, sz * 0.14, sz, c, adj=0.5, rot=a)
    shp(s, 'oval', cx - sz * 0.16, cy - sz * 0.16, sz * 0.32, sz * 0.32, c)


def _arrow(s, x, y, sz, c=None):
    c = c or Y()
    shp(s, 'rect', x, y + sz * 0.70, sz, sz * 0.30, c)
    shp(s, 'rect', x + sz * 0.70, y, sz * 0.30, sz, c)
    shp(s, 'rect', x + sz * 0.05, y + sz * 0.30, sz * 0.95, sz * 0.22, c, rot=45)


def _blob(s, x, y, w, h, c=None, adj=0.14):
    return shp(s, 'round', x, y, w, h, c or Y(), adj=adj)


def _dots(s, x, y, w, h, c):
    for i in range(int(w / 0.12)):
        for j in range(int(h / 0.12)):
            if (i + j) % 2 == 0:
                shp(s, 'oval', x + i * 0.12, y + j * 0.12, 0.03, 0.03, c)


# ══ เลย์เอาต์ตามรูปอ้างอิง ═════════════════════════════════════════════════

@reg
def cr_cover(prs, d):
    s = _page(prs, d, True)
    _blob(s, -0.4, 4.30, 7.40, 3.60, adj=0.12)
    _h(s, M, 1.05, d['t'], 52, 9.5)
    _arrow(s, W - M - 1.20, 1.10, 1.20)
    _p(s, M, 4.65, 3.4, d.get('s', ''), 12, c=K)
    _photo(s, d.get('pi', 0), 4.20, 4.10, W - M - 4.20, 2.90, 0.12)
    for i in range(3): _star(s, 4.80 + i * 0.55, 4.65, 0.42)
    _dots(s, M, 7.05, 4.0, 0.36, mix(K, 'FFFFFF', 0.25))


@reg
def cr_space(prs, d):
    s = _page(prs, d, False)
    _h(s, M, 1.00, d['t'], 40, 7.5, False, 'c')
    _photo(s, d.get('pi', 3), 1.40, 2.80, 6.00, 3.70, 0.10)
    shp(s, 'pie', 0.30, 5.10, 2.40, 2.40, Y(), adj=[180 * 0.6, 270 * 0.6])
    shp(s, 'round', 8.55, 0.95, W - 8.55 + 0.4, 6.15, K, adj=0.08)
    for i, (h_, body) in enumerate(d['items'][:4]):
        y = 1.40 + i * 1.40
        _star(s, 8.95, y + 0.18, 0.34)
        txt(s, 9.30, y, 3.4, 0.40, h_, 14, 'FFFFFF', 'md')
        _p(s, 9.30, y + 0.42, 3.4, body, 10.5)


@reg
def cr_steps_side(prs, d):
    s = _page(prs, d, False)
    _h(s, M, 1.00, d['t'], 40, 6.2, False)
    _p(s, M, 2.35, 6.0, d.get('note', ''), 11.5, False)
    _photo(s, d.get('pi', 9), M, 3.45, 6.60, 3.55, 0.12)
    for i, (h_, body) in enumerate(d['items'][:3]):
        y = 1.00 + i * 2.05
        _blob(s, 7.70, y, W - M - 7.70, 1.85, adj=0.14)
        shp(s, 'rect', 8.00, y + 0.32, 0.20, 0.20, K)
        txt(s, 8.35, y + 0.20, 4.0, 0.40, h_, 14, K, 'md')
        _p(s, 8.00, y + 0.70, W - M - 8.30, body, 10.5, c=K)


@reg
def cr_journey(prs, d):
    s = _page(prs, d, False)
    _h(s, M, 1.00, d['t'], 44, 9.5, False)
    _blob(s, M, 3.20, W - M * 2 + 0.6, 3.80, adj=0.08)
    n = len(d['items'][:5]); cw = (W - M * 2 - 0.4) / n
    for i, (h_, body) in enumerate(d['items'][:5]):
        x = M + 0.30 + i * cw
        if i: shp(s, 'rect', x - 0.15, 3.65, 0.03, 2.90, K)
        txt(s, x, 3.65, cw - 0.4, 0.80, f'{i + 1:02d}.', 34, K, 'md')
        txt(s, x, 4.60, cw - 0.4, 0.80, h_, 14, K, 'md', sp=1.1)
        _p(s, x, 5.45, cw - 0.4, body, 10.5, c=K)


@reg
def cr_center(prs, d):
    s = _page(prs, d, True)
    _h(s, M, 1.00, d['t'], 44, 9.0)
    _photo(s, d.get('pi', 7), M, 2.95, 7.70, 3.95, 0.10)
    shp(s, 'rect', 9.00, 2.95, 0.05, 3.95, Y())
    _p(s, 9.30, 3.00, 3.5, d.get('note', ''), 12)
    _arrow(s, W - M - 0.70, 1.15, 0.70)
    _dots(s, M, 7.05, W - M * 2, 0.30, mix(K, 'FFFFFF', 0.20))


@reg
def cr_meet(prs, d):
    s = _page(prs, d, True)
    _photo(s, d.get('pi', 4), M, 1.00, 5.80, 5.90, 0.10, geom='snip1Rect')
    _h(s, 7.10, 1.20, d['t'], 44, 5.6)
    for i in range(2): _star(s, 7.55 + i * 0.85, 3.65, 0.65)
    _p(s, 7.10, 4.35, 5.6, d.get('note', ''), 12)


# ══ อีก 14 เลย์เอาต์ในระบบเดียวกัน ════════════════════════════════════════

@reg
def cr_agenda(prs, d):
    s = _page(prs, d, True)
    _h(s, M, 1.00, d['t'], 44, 5.0)
    _blob(s, M, 3.40, 4.70, 3.55, adj=0.10)
    _photo(s, d.get('pi', 1), M + 0.25, 3.65, 4.20, 3.05, 0.10)
    for i, (when, h_) in enumerate(d['items'][:5]):
        y = 1.05 + i * 1.18
        ln(s, 6.10, y + 1.05, W - M, y + 1.05, mix(K, 'FFFFFF', 0.25), 0.8)
        txt(s, 6.10, y + 0.20, 1.7, 0.50, when, 14, Y(), 'md')
        txt(s, 7.90, y + 0.15, 4.8, 0.70, h_, 17, 'FFFFFF', 'md')


@reg
def cr_why(prs, d):
    s = _page(prs, d, False)
    _h(s, M, 1.00, d['t'], 44, 6.4, False)
    _p(s, M, 2.55, 5.8, d.get('note', ''), 12, False)
    shp(s, 'round', 7.30, 0.95, W - 7.30 + 0.5, 6.15, K, adj=0.08)
    txt(s, 7.70, 1.40, 5.0, 1.30, d['big'], 66, Y(), 'md')
    _p(s, 7.70, 2.75, 5.0, d['biglab'], 12)
    for i, (v, lab) in enumerate(d['items'][:2]):
        y = 4.15 + i * 1.40
        txt(s, 7.70, y, 2.0, 0.70, v, 30, 'FFFFFF', 'md')
        _p(s, 9.80, y + 0.12, 2.9, lab, 10.5)
    _photo(s, d.get('pi', 2), M, 4.10, 6.10, 2.90, 0.12)


@reg
def cr_div_yellow(prs, d):
    s = page(prs, Y())
    for x, t in ((M, d.get('brand', 'สตูดิโอของคุณ')), (M + 2.40, d.get('doc', 'เวิร์กช็อป'))):
        shp(s, 'rect', x, 0.36, 0.05, 0.28, K)
        txt(s, x + 0.15, 0.34, 2.2, 0.32, t, 10, K, 'md')
    txt(s, M, 2.10, 4.0, 0.40, d.get('k', ''), 14, K, 'md')
    txt(s, M, 2.60, 8.0, 2.6, d['t'], 60, K, 'md', sp=1.0)
    _p(s, M, 5.20, 7.0, d.get('note', ''), 13, c=K)
    _star(s, 10.80, 3.60, 2.60, K)


@reg
def cr_div_dark(prs, d):
    s = _page(prs, d, True)
    _photo(s, d.get('pi', 13), 6.80, 1.00, W - M - 6.80, 5.90, 0.10, geom='snip1Rect')
    txt(s, M, 2.10, 4.0, 0.40, d.get('k', ''), 14, 'FFFFFF', 'md')
    _h(s, M, 2.60, d['t'], 54, 6.0)
    _p(s, M, 5.10, 5.6, d.get('note', ''), 12.5)
    _arrow(s, M, 6.10, 0.60)


@reg
def cr_formats(prs, d):
    s = _page(prs, d, False)
    _h(s, M, 1.00, d['t'], 40, 9.0, False)
    cw = (W - M * 2 - 0.40) / 3
    for i, (ic, h_, size, body) in enumerate(d['items'][:3]):
        x = M + i * (cw + 0.20)
        hot = i == 1
        _blob(s, x, 2.35, cw, 4.60, Y() if hot else K, 0.08)
        shp(s, 'oval', x + 0.35, 2.70, 0.80, 0.80, K if hot else Y())
        icon(s, ic, x + 0.75, 3.10, 0.42, Y() if hot else K)
        txt(s, x + 0.35, 3.75, cw - 0.7, 0.45, h_, 18, K if hot else 'FFFFFF', 'md')
        txt(s, x + 0.35, 4.25, cw - 0.7, 0.35, size, 12, K if hot else Y(), 'md')
        _p(s, x + 0.35, 4.80, cw - 0.7, body, 11, not hot, c=K if hot else None)


@reg
def cr_chart_skill(prs, d):
    s = _page(prs, d, True)
    _h(s, M, 1.00, d['t'], 40, 5.0)
    _p(s, M, 2.50, 4.4, d.get('note', ''), 11.5)
    for i, (v, lab) in enumerate(d['items'][:2]):
        y = 4.10 + i * 1.45
        shp(s, 'rect', M, y, 0.06, 1.15, Y())
        txt(s, M + 0.25, y - 0.05, 4.0, 0.70, v, 30, 'FFFFFF', 'md')
        _p(s, M + 0.25, y + 0.68, 4.0, lab, 10.5)
    _blob(s, 5.55, 1.00, W - M - 5.55, 5.90, CR, 0.06)
    chart(s, 'bar', 5.80, 1.20, W - M - 6.05, 5.50, d['cats'], d['series'], ['9A9890', Y()], labels=True,
          fmt='0"%"', legend=True, gap=50, overlap=-10, sz=11, c=K, maxv=100)


@reg
def cr_chart_enrol(prs, d):
    s = _page(prs, d, False)
    _h(s, M, 1.00, d['t'], 40, 8.0, False)
    _blob(s, M, 2.35, 8.20, 4.60, 'FFFFFF', 0.06)
    n = len(d['vals'])
    chart(s, 'col', M + 0.20, 2.55, 7.80, 4.20, d['cats'], [(d['sname'], d['vals'])], ['C9C6BC'] * (n - 1) + [K],
          labels=True, fmt='#,##0', gap=45, sz=11, c=K, vary=True)
    for i, (v, lab) in enumerate(d['items'][:2]):
        y = 2.35 + i * 2.35
        f = Y() if i == 0 else K
        _blob(s, 9.05, y, W - M - 9.05, 2.20, f, 0.10)
        txt(s, 9.35, y + 0.25, 3.0, 0.75, v, 32, K if i == 0 else Y(), 'md')
        _p(s, 9.35, y + 1.10, 3.0, lab, 10.5, i == 1, c=K if i == 0 else None)


@reg
def cr_budget(prs, d):
    s = _page(prs, d, True)
    _h(s, M, 1.00, d['t'], 40, 7.0)
    cols = [Y(), 'FFFFFF', '9A9890', '55534D']
    it = d['items'][:4]
    chart(s, 'donut', 0.60, 2.30, 4.60, 4.60, [x[0] for x in it], [('บาท', [x[1] for x in it])], cols, labels=False, hole=60)
    txt(s, 0.60, 4.20, 4.60, 0.60, d['big'], 26, 'FFFFFF', 'md', 'c')
    txt(s, 0.60, 4.80, 4.60, 0.30, d['biglab'], 10.5, SOFT, 'rg', 'c')
    for i, (lab, v, pct, body) in enumerate(it):
        y = 2.30 + i * 1.18
        _blob(s, 5.80, y, W - M - 5.80, 1.02, mix(K, 'FFFFFF', 0.08), 0.18)
        shp(s, 'rect', 6.05, y + 0.38, 0.26, 0.26, cols[i])
        txt(s, 6.55, y + 0.12, 3.6, 0.40, lab, 14, 'FFFFFF', 'md')
        _p(s, 6.55, y + 0.54, 3.8, body, 10.5)
        txt(s, 10.20, y + 0.12, 1.40, 0.80, f'{v:,}', 15, 'FFFFFF', 'md', 'r', 'm')
        txt(s, 11.65, y + 0.12, 0.85, 0.80, f'{pct}%', 14, Y(), 'md', 'r', 'm')


@reg
def cr_schedule(prs, d):
    s = _page(prs, d, False)
    _h(s, M, 1.00, d['t'], 40, 9.0, False)
    cols = d['colw']; tw = W - M * 2; y0 = 2.30; rh = 0.78
    xs = [M]
    for f in cols[:-1]: xs.append(xs[-1] + tw * f)
    _blob(s, M, y0, tw, 0.62, K, 0.25)
    for j, hd in enumerate(d['head']):
        txt(s, xs[j] + 0.22, y0, tw * cols[j] - 0.44, 0.62, hd, 12, Y(), 'md', 'l' if j == 0 else 'c', 'm')
    for i, row in enumerate(d['rows']):
        y = y0 + 0.72 + i * rh
        _blob(s, M, y, tw, rh - 0.10, Y() if i == 0 else 'FFFFFF', 0.18)
        for j, cell in enumerate(row):
            txt(s, xs[j] + 0.22, y, tw * cols[j] - 0.44, rh - 0.10, cell, 12, K, 'md' if j == 0 else 'rg',
                'l' if j == 0 else 'c', 'm')


@reg
def cr_facilitators(prs, d):
    s = _page(prs, d, True)
    _h(s, M, 1.00, d['t'], 40, 9.0)
    cw = (W - M * 2 - 0.60) / 4
    for i, (name, role, body, pi) in enumerate(d['items'][:4]):
        x = M + i * (cw + 0.20)
        _blob(s, x, 2.30, cw, 4.65, mix(K, 'FFFFFF', 0.08), 0.07)
        _photo(s, pi, x + 0.15, 2.45, cw - 0.30, 2.35, 0.08, (0.5, 0.35))
        txt(s, x + 0.25, 5.00, cw - 0.5, 0.40, name, 14, 'FFFFFF', 'md')
        txt(s, x + 0.25, 5.42, cw - 0.5, 0.32, role, 11, Y(), 'md')
        _p(s, x + 0.25, 5.85, cw - 0.5, body, 10.5)


@reg
def cr_quote(prs, d):
    s = _page(prs, d, False)
    _blob(s, M, 1.00, 5.30, 5.90, Y(), 0.10)
    _photo(s, d.get('pi', 11), M + 0.30, 1.30, 4.70, 5.30, 0.10)
    _star(s, 6.70, 1.70, 0.70, K)
    txt(s, 6.40, 2.40, 6.3, 3.0, d['t'], 22, K, 'md', sp=1.32)
    shp(s, 'rect', 6.40, 5.40, 0.80, 0.06, K)
    txt(s, 6.40, 5.60, 6.0, 0.40, d['who'], 15, K, 'md')
    _p(s, 6.40, 6.02, 6.3, d['role'], 11, False)


@reg
def cr_next(prs, d):
    s = _page(prs, d, True)
    _h(s, M, 1.00, d['t'], 44, 6.4)
    _p(s, M, 2.55, 5.8, d.get('note', ''), 12)
    _arrow(s, M, 5.60, 1.00)
    for i, (h_, body) in enumerate(d['items'][:3]):
        y = 1.00 + i * 2.00
        f = Y() if i == 0 else mix(K, 'FFFFFF', 0.08)
        _blob(s, 7.00, y, W - M - 7.00, 1.82, f, 0.14)
        txt(s, 7.30, y + 0.25, 0.8, 0.50, f'{i + 1:02d}.', 22, K if i == 0 else Y(), 'md')
        txt(s, 8.20, y + 0.25, 4.3, 0.45, h_, 15, K if i == 0 else 'FFFFFF', 'md')
        _p(s, 8.20, y + 0.75, 4.3, body, 10.5, i != 0, c=K if i == 0 else None)


@reg
def cr_close(prs, d):
    s = _page(prs, d, True)
    _blob(s, 6.40, 4.30, W - 6.40 + 0.4, 3.60, adj=0.12)
    _photo(s, d.get('pi', 12), M, 1.00, 5.40, 5.90, 0.10, geom='snip1Rect')
    _h(s, 6.70, 1.05, d['t'], 52, 6.1)
    for i in range(2): _star(s, 7.10 + i * 0.75, 3.55, 0.55)
    for i, (lab, v) in enumerate(d['items'][:3]):
        y = 4.75 + i * 0.62
        txt(s, 6.80, y, 1.6, 0.40, lab, 11, K, 'rg')
        txt(s, 8.40, y, 4.3, 0.40, v, 13, K, 'md')


@reg
def cr_outcomes(prs, d):
    s = _page(prs, d, False)
    _h(s, M, 1.00, d['t'], 40, 9.0, False)
    cw = (W - M * 2 - 0.60) / 4
    for i, (v, lab, body) in enumerate(d['items'][:4]):
        x = M + i * (cw + 0.20)
        top = 2.40 + (i % 2) * 0.45
        f = K if i % 2 == 0 else Y()
        _blob(s, x, top, cw, 6.95 - top, f, 0.08)
        txt(s, x + 0.30, top + 0.30, cw - 0.6, 0.80, v, 36, Y() if f == K else K, 'md')
        txt(s, x + 0.30, top + 1.25, cw - 0.6, 0.45, lab, 15, 'FFFFFF' if f == K else K, 'md')
        _p(s, x + 0.30, top + 1.80, cw - 0.6, body, 11, f == K, c=None if f == K else K)
