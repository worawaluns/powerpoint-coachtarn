# ปกชุดที่สาม — คู่สีขายกว้างและกลุ่มดูแพง คนละโครงกับ lay_cov2 / lay_cov3 ทั้งหมด
# ทุกตัวใช้ tone() / ink_on() / ttl2() ตั้งแต่แรก จะได้ไม่ต้องไล่แก้คอนทราสต์ย้อนหลังอีก
from eng import *
import eng
from lay import L, reg
from lay_cov2 import _hdr, _fg, _arrowbtn
from lay_cov3 import hatch, ghost, duo, cells, ttl2, subline, vlabel, _idx


def _ft(s, t, c=None):
    """ท้ายหน้าซ้ายล่าง ใช้ร่วมกันทั้งไฟล์"""
    if t: txt(s, 0.8, H - 0.62, 7.0, 0.3, t, 9.5, c or tone(P['bg'], 0.6), track=0.9)


def _chips(s, x, y, items, c_line=None, c_txt=None, w=2.6, h=0.56, gap=0.22):
    """ชิปตัวเลขเรียงแนวนอน แบบป้ายในเอกสารจริง ไม่ใช่ปุ่ม"""
    for i, (v, lb) in enumerate(items):
        xx = x + i * (w + gap)
        shp(s, 'round', xx, y, w, h, None, line=c_line or P['acc'], lw=1.0, adj=0.5)
        txt(s, xx, y, w, h, f'{v}  {lb}', 9.5, c_txt or tone(P['bg'], 0.85), 'md', 'c', 'm')


# ── 1. โค้งใหญ่กวาดจากขวา ────────────────────────────────────────────────
@reg
def cx_arc_hero(prs, d):
    """วงโค้งสีเต็มครึ่งขวา หัวข้อซ้าย ชิปตัวเลขเรียงล่าง"""
    s = page(prs, P['bg'])
    shp(s, 'oval', 6.6, -2.6, 12.0, 12.0, P['acc'])
    shp(s, 'oval', 7.5, -1.7, 10.2, 10.2, None, line=mix(P['acc'], _fg(P['acc']), 0.25), lw=1.2)
    duo(s, d['topic'], d.get('pi', 0), 8.15, 1.05, 4.1, 4.1, geom='ellipse',
        base=P['acc'], tint=P['acc2'], k=0.5)
    hatch(s, 0, H - 2.3, 2.4, 2.3, P['acc'], 0.2, 0.6, 0.5)
    # kicker เคยอยู่ช่องขวาของ _hdr ซึ่งนั่งทับวงโค้ง P['acc'] พอดี แต่สีคิดจาก P['bg']
    # เลยวัดได้ 1.06-2.17 ทั้ง 7 ใบ ย้ายมาช่องซ้ายที่เป็นพื้นเปล่า — mirror() ก็ยังเปล่า
    # เพราะวงโค้งพลิกตามไปด้วย · foot อยู่ล่างแล้ว ไม่ต้องซ้ำบนหัว
    _hdr(s, d.get('k', ''), '', '', tone(P['bg'], 0.58))
    ln(s, 0.8, 1.06, 6.3, 1.06, mix(P['bg'], P['ink'], 0.4), 0.8)
    yb = ttl2(s, 0.8, 1.52, 6.0, d['t'], d.get('tsz', 48), P['ink'], maxh=2.6)
    shp(s, 'rect', 0.8, yb + 0.12, 2.2, 0.17, P['acc'])
    subline(s, 0.8, yb + 0.5, 5.6, d.get('s'), 12.5, tone(P['bg'], 0.72), 5.66, sp=1.42)
    _chips(s, 0.8, 5.72, (d.get('stats') or [])[:2])
    _ft(s, d.get('foot', ''))


# ── 2. สามแถบสีซ้อนแนวนอน ────────────────────────────────────────────────
@reg
def cx_band_trio(prs, d):
    """แถบสีสามชั้นความสูงไม่เท่ากัน หัวข้ออยู่แถบกลาง รูปเป็นแถบยาวล่าง"""
    s = page(prs, P['bg'])
    shp(s, 'rect', 0, 0, W, 1.5, P['acc'])
    hatch(s, W - 3.1, 0, 3.1, 1.5, _fg(P['acc']), 0.2, 0.6, 0.35, on=P['acc'])
    fg1 = _fg(P['acc'])
    txt(s, 0.8, 0.5, 6.4, 0.5, d.get('k', ''), 11.5, fg1, 'md', an='m', track=1.4)
    txt(s, W - 4.8, 0.5, 4.0, 0.5, '01 / 20', 10, fg1, 'bd', 'r', 'm')

    # แผงรูปเริ่มที่ 4.5 ทุกอย่างต้องจบก่อนนั้น ไม่งั้นโดนทับหายทั้งบรรทัด
    # (เดิม 4.25 กับ maxh 1.55 ไม่พอใส่หัวข้อ 3 บรรทัดที่พื้น 32pt ซึ่งสูง 1.76")
    yb = ttl2(s, 0.8, 1.86, 8.4, d['t'], d.get('tsz', 46), P['ink'], maxh=1.78)
    subline(s, 0.8, yb + 0.16, 7.4, d.get('s'), 12, tone(P['bg'], 0.72), 4.44, sp=1.38)
    st = (d.get('stats') or [])
    if st and str(st[0][0]).strip():
        card(s, 9.5, 1.86, 3.03, 2.0, P['acc'], adj=0.07)
        txt(s, 9.78, 2.1, 2.5, 0.8, st[0][0], fit_sz(st[0][0], 2.5, 38), _fg(P['acc']), 'bd', sp=0.92)
        txt(s, 9.78, 3.04, 2.5, 0.6, st[0][1], 10, _fg(P['acc']), sp=1.3)

    duo(s, d['topic'], d.get('pi', 1), 0, 4.5, W, 2.45, base=P['acc'], tint=P['bg'], k=0.36)
    # a2=0.72 ให้ม่านตรง cells แค่ 0.44 ป้ายขาววัดได้ 4.23 · เต็ม 1.0 แล้วได้ 4.5 แม้รูปขาวสนิท
    gradband(s, 0, 4.5, W, 2.45, 90, a1=0.0, a2=1.0, c1='0A0A0C', c2='0A0A0C')
    cells(s, 0.8, 5.86, 8.0, 0.82, (d.get('stats') or [])[1:4],
          lab_c='E8ECF4', val_c='FFFFFF', line_c=mix('FFFFFF', '000000', 0.55))
    # แถบรูปจบที่ 6.80 ตัวขาวที่ 7.00 ไปตกบนพื้น P['bg'] สว่าง วัดได้ 1.07
    txt(s, 0.8, H - 0.5, 7.0, 0.3, d.get('foot', ''), 9.5, tone(P['bg'], 0.6), track=0.9)


# ── 3. การ์ดกระจกบนสนามแสง ───────────────────────────────────────────────
@reg
def cx_glass_card(prs, d):
    """สนามแสงเรืองสองจุด + การ์ดโปร่งขอบบางวางหัวข้อ"""
    s = page(prs, P['bg'])
    glow(s, W * 0.24, H * 0.46, 5.6, P['acc'], 0.7)   # เดิม cy=H*0.26 แสงเลยพาดแถบหัวกระดาษ
    glow(s, W * 0.82, H * 0.78, 5.4, P['acc2'], 0.6)
    dots(s, 0.5, 0.5, 27, 15, 0.48, 0.035, mix(P['bg'], P['ink'], 0.25), 0.9)
    # กรอบสีเต็มรอบรูป — พาเลตต์มืดเคยเหลือบล็อกสีเต็มใหญ่สุดแค่ 0.25% ทั้งใบ
    shp(s, 'round', 7.62, 1.22, 5.16, 5.06, P['acc'], adj=0.07)
    duo(s, d['topic'], d.get('pi', 2), 7.9, 1.5, 4.6, 4.5, geom='roundRect', adj=0.07, k=0.5)

    lift = surf_for(P['ink'], mix(P['bg'], P['ink'], 0.09))
    shp(s, 'round', 0.8, 1.3, 6.6, 4.9, lift, line=mix(P['bg'], P['ink'], 0.26), lw=0.9,
        adj=0.045, shadow=('000000', 0.22, 26, 10))
    txt(s, 1.22, 1.78, 4.8, 0.3, d.get('k', ''), 10, ink_on(P['acc'], lift), 'md', track=1.3)
    yb = ttl2(s, 1.22, 2.22, 5.8, d['t'], d.get('tsz', 44), P['ink'], maxh=1.75)
    ry = yb + 0.22                             # เดิม min(.., 4.3) ทำให้เส้นขีดพาดกลางหัวข้อยาว
    if ry < 4.9: ln(s, 1.22, ry, 6.6, ry, mix(lift, P['ink'], 0.22), 0.7)
    # cells อยู่ที่ 5.08 คำโปรยสูง 0.56 ต้องจบก่อน
    subline(s, 1.22, yb + 0.3, 5.6, d.get('s'), 12, tone(lift, 0.72), 5.02, sp=1.38)
    cells(s, 1.22, 5.08, 5.76, 0.82, (d.get('stats') or [])[:2],
          lab_c=tone(lift, 0.6), val_c=P['ink'], line_c=mix(lift, P['ink'], 0.22))
    _hdr(s, d.get('foot', ''), '', '01 / 20', tone(P['bg'], 0.92))   # มีแสงเรืองทับ ต้องเข้มกว่าปกติ


# ── 4. หัวนิตยสาร ────────────────────────────────────────────────────────
@reg
def cx_mast_rule(prs, d):
    """ชื่อหัวเรื่องตัวใหญ่พาดบน มีเส้นคู่ขนาบ แถบรูปยาว แล้วหัวข้อใหญ่ใต้รูป"""
    s = page(prs, P['bg'])
    ln(s, 0.8, 0.92, W - 0.8, 0.92, mix(P['bg'], P['ink'], 0.5), 1.0)
    txt(s, 0.8, 1.06, 9.0, 0.6, d.get('k', ''), 19, P['ink'], 'bd', track=2.2)
    txt(s, W - 4.8, 1.12, 4.0, 0.4, d.get('foot', ''), 9.5, tone(P['bg'], 0.6), 'rg', 'r', track=1.1)
    ln(s, 0.8, 1.8, W - 0.8, 1.8, mix(P['bg'], P['ink'], 0.28), 0.6)

    duo(s, d['topic'], d.get('pi', 3), 0.8, 2.0, W - 1.6, 2.15, base=P['acc'], tint=P['acc2'], k=0.44)
    st = (d.get('stats') or [('', '')])
    shp(s, 'rect', 0.8, 2.0, 2.7, 2.15, P['acc'], a=0.94)
    txt(s, 1.06, 2.5, 2.2, 0.8, st[0][0], fit_sz(st[0][0], 2.2, 34), _fg(P['acc']), 'bd', sp=0.92)
    txt(s, 1.06, 3.36, 2.2, 0.6, st[0][1], 9.5, _fg(P['acc']), sp=1.28)

    yb = ttl2(s, 0.8, 4.3, 8.2, d['t'], d.get('tsz', 48), P['ink'], maxh=1.45)
    subline(s, 0.8, yb + 0.12, 7.6, d.get('s'), 11, tone(P['bg'], 0.72), 6.24, sp=1.3)
    _arrowbtn(s, 11.9, 5.1, 0.95, P['acc'], 'arrow-right', _fg(P['acc']))
    ln(s, 0.8, 6.3, W - 0.8, 6.3, mix(P['bg'], P['ink'], 0.22), 0.6)
    cells(s, 0.8, 6.44, 8.0, 0.78, (d.get('stats') or [])[1:4])   # ตัวที่ 0 โชว์ในแผงบนแล้ว


# ── 5. ตัวเลขยักษ์ซ้าย ───────────────────────────────────────────────────
@reg
def cx_num_left(prs, d):
    """ตัวเลขตัวใหญ่มากเป็นพระเอกฝั่งซ้าย หัวข้อเรียงขวา มีกริดเส้นผมทั้งใบ"""
    s = page(prs, P['bg'])
    for i in range(1, 8):
        ln(s, i * W / 8, 0.7, i * W / 8, H - 0.7, mix(P['bg'], P['ink'], 0.07), 0.5)
    _hdr(s, '', '', d.get('k', ''), tone(P['bg'], 0.58))
    st = (d.get('stats') or [('', '')])
    big = st[0][0] or '2570'
    shp(s, 'rect', 0, 1.5, 6.0, 4.2, P['acc'])
    hatch(s, 0, 4.7, 6.0, 1.0, _fg(P['acc']), 0.22, 0.6, 0.3, on=P['acc'])   # ไว้ชายล่าง ไม่พาดตัวเลข
    fg1 = _fg(P['acc'])
    txt(s, 0.8, 2.3, 5.0, 1.9, big, fit_sz(big, 5.0, 104), fg1, 'bd', sp=0.9)
    ln(s, 0.8, 4.42, 5.0, 4.42, mix(P['acc'], fg1, 0.4), 0.8)
    txt(s, 0.8, 4.6, 5.0, 0.6, st[0][1], 12, fg1, 'md', sp=1.3)

    yb = ttl2(s, 6.7, 1.7, 5.8, d['t'], d.get('tsz', 42), P['ink'], maxh=2.2)
    shp(s, 'rect', 6.7, yb + 0.12, 2.0, 0.16, P['acc'])
    subline(s, 6.7, yb + 0.48, 5.6, d.get('s'), 12.5, tone(P['bg'], 0.72), 4.84, sp=1.42)
    duo(s, d['topic'], d.get('pi', 4), 6.7, 4.9, 5.83, 1.8, geom='roundRect', adj=0.1, k=0.48)
    _ft(s, d.get('foot', ''))


# ── 6. สีกวาดทแยง ────────────────────────────────────────────────────────
@reg
def cx_wedge_sweep(prs, d):
    """แถบสีทแยงหนาพาดกลางใบ รูปอยู่ฝั่งขวาหลังแถบ หัวข้ออยู่ฝั่งพื้นเรียบ"""
    s = page(prs, P['bg'])
    duo(s, d['topic'], d.get('pi', 5), 9.2, 0, W - 9.2, H, base=P['bg'], tint=P['acc'], k=0.44)
    # แถบต้องกว้างกว่าความสูงพอสมควร ไม่งั้น adj ทำให้มันบางเป็นเสี้ยว
    shp(s, 'para', 6.6, -0.6, 4.0, H + 1.2, P['acc'], adj=0.3)
    shp(s, 'para', 6.25, -0.6, 0.55, H + 1.2, mix(P['acc'], _fg(P['acc']), 0.32), adj=0.3)
    txt(s, 0.8, 0.52, 5.0, 0.3, d.get('k', ''), 10, ink_on(P['acc'], P['bg']), 'md', track=1.3)
    ln(s, 0.8, 0.94, 5.6, 0.94, mix(P['bg'], P['ink'], 0.42), 0.8)
    yb = ttl2(s, 0.8, 1.3, 5.2, d['t'], d.get('tsz', 40), P['ink'], maxh=2.4)
    shp(s, 'rect', 0.8, yb + 0.1, 1.8, 0.16, P['acc'])
    subline(s, 0.8, yb + 0.4, 5.2, d.get('s'), 11, tone(P['bg'], 0.72), 4.94, sp=1.36)
    st = (d.get('stats') or [])
    for i, (v, lb) in enumerate(st[:2]):
        y = 5.0 + i * 0.86
        txt(s, 0.8, y, 2.0, 0.42, v, 22, P['ink'], 'bd')
        txt(s, 0.8, y + 0.46, 5.2, 0.28, lb, 9, tone(P['bg'], 0.62), track=0.8)
    txt(s, 0.8, H - 0.62, 5.2, 0.3, d.get('foot', ''), 9, tone(P['bg'], 0.6), track=0.8)


# ── 7. เบนโตะสี่ช่อง ─────────────────────────────────────────────────────
@reg
def cx_bento4(prs, d):
    """สี่ช่องขนาดไม่เท่ากัน ช่องหัวข้อ ช่องรูป ช่องตัวเลขสีเต็ม ช่องหัวเรื่อง"""
    s = page(prs, P['bg'])
    dots(s, 0.5, 0.5, 26, 14, 0.5, 0.04, mix(P['bg'], P['ink'], 0.22), 0.9)
    _hdr(s, d.get('foot', ''), '', '01 / 20', tone(P['bg'], 0.58))
    lift = surf_for(P['ink'], mix(P['bg'], P['ink'], 0.07))

    card(s, 0.8, 1.1, 7.2, 3.3, lift, adj=0.05, shadow=True)
    txt(s, 1.16, 1.48, 5.6, 0.3, d.get('k', ''), 10, ink_on(P['acc'], lift), 'md', track=1.3)
    yb = ttl2(s, 1.16, 1.9, 6.5, d['t'], d.get('tsz', 40), P['ink'], maxh=1.42)
    subline(s, 1.16, yb + 0.16, 6.3, d.get('s'), 11, tone(lift, 0.72), 4.30, sp=1.36)

    st = (d.get('stats') or [('', '')])
    card(s, 8.3, 1.1, 4.23, 3.3, P['acc'], adj=0.05)
    hatch(s, 8.3, 3.5, 4.23, 0.9, _fg(P['acc']), 0.21, 0.6, 0.3, on=P['acc'])
    txt(s, 8.66, 1.62, 3.5, 1.0, st[0][0], fit_sz(st[0][0], 3.5, 50), _fg(P['acc']), 'bd', sp=0.92)
    txt(s, 8.66, 2.78, 3.5, 0.8, st[0][1], 11, _fg(P['acc']), sp=1.32)
    _arrowbtn(s, 11.9, 3.9, 0.84, mix(P['acc'], _fg(P['acc']), 0.18), 'arrow-up-right', _fg(P['acc']))

    duo(s, d['topic'], d.get('pi', 6), 0.8, 4.6, 4.9, 2.2, geom='roundRect', adj=0.07, k=0.48)
    card(s, 6.0, 4.6, 6.53, 2.2, lift, adj=0.05)
    cells(s, 6.36, 4.94, 5.8, 0.9, st[1:4],
          lab_c=tone(lift, 0.6), val_c=P['ink'], line_c=mix(lift, P['ink'], 0.22))
    txt(s, 6.36, 6.12, 5.6, 0.3, d.get('foot', ''), 9.5, tone(lift, 0.6), track=0.9)


# ── 8. กลางหน้าแบบงานพรีเมียม ────────────────────────────────────────────
@reg
def cx_centre_luxe(prs, d):
    """จัดกลาง เว้นที่เยอะ เส้นบางคู่ หัวเรื่องตัวห่าง ตัวเลขสามช่องล่าง"""
    s = page(prs, P['bg'])
    # เดิมคลุมม่าน bg a=0.62 ทั้งใบ เหลือสีเต็มแค่เส้น 1.4pt วัดความอิ่มสีได้ 0.07
    duo(s, d['topic'], d.get('pi', 7), 0, 0, W, 2.9, base=P['acc'], tint=P['acc2'], k=0.62)
    gradband(s, 0, 1.9, W, 1.0, 90, a1=0.0, a2=1.0, c1=P['bg'], c2=P['bg'])
    # หัวกระดาษนั่งบนรูปที่ย้อมสีไว้ ความสว่างไม่นิ่ง วัดได้ 4.58 แต่ครึ่งหนึ่งของพิกเซลต่ำกว่า 4.5
    # ปูสีแบรนด์ทึบบนแถบหัวก่อน แล้วใช้ _fg() ซึ่งรับประกันบนสีแบรนด์ล้วน
    shp(s, 'rect', 0, 0, W, 0.95, P['acc'], a=0.97)   # 0.9 ยังปล่อยรูปทะลุมา 10% ตัวขาวเหลือ 4.43
    _hdr(s, d.get('foot', ''), '', '01 / 20', _fg(P['acc']))
    shp(s, 'rect', 0, 2.72, W, 0.42, P['acc'])      # เส้น 0.16" บางเกิน ทั้งใบเหลือสีเต็มไม่ถึง 2%
    shp(s, 'rect', 0.62, 3.34, W - 1.24, H - 3.96, None, line=mix(P['bg'], P['ink'], 0.3), lw=0.9)
    txt(s, W / 2 - 4, 3.42, 8.0, 0.3, d.get('k', ''), 10, ink_on(P['acc'], P['bg']), 'md', 'c', track=3.0)
    yb = ttl2(s, W / 2 - 4.8, 3.78, 9.6, d['t'], d.get('tsz', 50), P['ink'], maxh=1.26, al='c')
    # คำโปรยยาวตัดเป็นสองบรรทัดจริง (h03 ล้นกล่อง 0.42" ออกมา 4px) กล่องต้องสูงตามจำนวนบรรทัด
    sb = subline(s, W / 2 - 3.6, yb + 0.14, 7.2, d.get('s'), 11.5, tone(P['bg'], 0.72), 5.74, al='c', sp=1.34)
    st = (d.get('stats') or [])[:3]
    sy = min(max(5.86, sb + 0.14), 6.02)       # แถวตัวเลขต้องอยู่ใต้ก้นคำโปรยเสมอ ไม่ใช่ค่าตรึง
    for i, (v, lb) in enumerate(st):
        x = W / 2 - (len(st) * 2.9) / 2 + i * 2.9
        if i: ln(s, x - 0.1, sy, x - 0.1, sy + 0.66, mix(P['bg'], P['ink'], 0.24), 0.6)
        txt(s, x, sy, 2.7, 0.42, v, 21, P['ink'], 'bd', 'c')
        txt(s, x, sy + 0.46, 2.7, 0.3, lb, 9.5, tone(P['bg'], 0.6), 'rg', 'c', track=0.9)
    # foot อยู่ที่ 6.52 ทับป้ายใต้ตัวเลข (6.32-6.62) จริง 4 ใบ · ย้ายลงใต้กรอบเส้นที่ 6.88
    txt(s, W / 2 - 4, H - 0.46, 8.0, 0.3, d.get('foot', ''), 9.5, tone(P['bg'], 0.6), 'rg', 'c', track=1.1)


# ── 9. ตั๋ว ───────────────────────────────────────────────────────────────
@reg
def cx_ticket(prs, d):
    """ต้นขั้วสีซ้ายมีตัวหนังสือตั้ง เส้นปรุ แล้วแผ่นหลักวางหัวข้อ"""
    s = page(prs, P['bg'])
    lift = surf_for(P['ink'], mix(P['bg'], P['ink'], 0.06))
    card(s, 0.7, 0.8, W - 1.4, H - 1.6, lift, adj=0.035, shadow=True)
    shp(s, 'round2', 0.7, 0.8, 2.5, H - 1.6, P['acc'], adj=0.14, rot=180)
    hatch(s, 0.7, 0.8, 2.5, H - 1.6, _fg(P['acc']), 0.2, 0.6, 0.32, on=P['acc'])
    vlabel(s, 1.11, 3.75, d.get('k', ''), 10.5, _fg(P['acc']), span=3.8, track=1.8)
    txt(s, 1.0, 1.2, 1.9, 0.4, '01', 22, _fg(P['acc']), 'bd')
    for i in range(18):                 # เส้นปรุวาดเป็นจุด ๆ เอง เส้นประของ pptx จางเกินจะเห็น
        yy = 1.1 + i * ((H - 2.2) / 17)
        shp(s, 'oval', 3.32, yy, 0.11, 0.11, mix(lift, P['ink'], 0.3))

    yb = ttl2(s, 3.7, 1.5, 5.3, d['t'], d.get('tsz', 42), P['ink'], maxh=2.2)
    shp(s, 'rect', 3.7, yb + 0.12, 2.0, 0.16, P['acc'])
    subline(s, 3.7, yb + 0.48, 5.1, d.get('s'), 12, tone(lift, 0.72), 5.24, sp=1.42)
    duo(s, d['topic'], d.get('pi', 8), 9.3, 1.5, 3.1, 3.1, geom='roundRect', adj=0.09, k=0.48)
    cells(s, 3.7, 5.3, 8.7, 0.86, (d.get('stats') or [])[:3],
          lab_c=tone(lift, 0.6), val_c=P['ink'], line_c=mix(lift, P['ink'], 0.22))
    txt(s, 3.7, 6.42, 6.0, 0.3, d.get('foot', ''), 9, tone(lift, 0.58), track=0.9)


# ── 10. รูปวงกลมมีรัศมี ──────────────────────────────────────────────────
@reg
def cx_halo_photo(prs, d):
    """รูปวงกลมกลางบนมีวงแหวนล้อม หัวข้ออยู่ใต้รูป จัดกลาง"""
    s = page(prs, P['bg'])
    BAND = 4.08                          # ขอบบนแถบสีล่าง ทุกอย่างคิดจากค่านี้
    shp(s, 'rect', 0, BAND, W, H - BAND, P['acc'])
    hatch(s, 0, BAND, W, H - BAND, _fg(P['acc']), 0.22, 0.6, 0.25, on=P['acc'])
    for i, k in enumerate((0.0, 0.36, 0.72)):
        r = 2.85 + k * 1.5
        shp(s, 'oval', W / 2 - r / 2, 1.08 + (2.85 - r) / 2, r, r, None,
            line=mix(P['bg'], P['acc'], 0.8 - i * 0.22), lw=1.1 - i * 0.25)
    duo(s, d['topic'], d.get('pi', 9), W / 2 - 1.42, 1.08, 2.85, 2.85, geom='ellipse', k=0.46)
    _hdr(s, d.get('foot', ''), '', d.get('k', ''), tone(P['bg'], 0.58))

    fg1 = _fg(P['acc'])
    # โปสเตอร์จัดกลางไม่พอที่จะมีทั้งคำโปรยและแถวตัวเลข เลือกตัวเลขแล้วให้หัวข้อใหญ่แทน
    ttl2(s, W / 2 - 4.6, BAND + 0.34, 9.2, d['t'], d.get('tsz', 42), fg1, maxh=1.5, al='c')
    st = (d.get('stats') or [])[:3]
    for i, (v, lb) in enumerate(st):
        x = W / 2 - (len(st) * 3.0) / 2 + i * 3.0
        if i: ln(s, x - 0.1, 6.46, x - 0.1, 7.06, mix(P['acc'], fg1, 0.35), 0.6)
        txt(s, x, 6.46, 2.8, 0.36, v, 20, fg1, 'bd', 'c')
        # ผสม fg กลับเข้าหา acc 8% ก็พอทำให้ตกจาก 4.6 เหลือ 4.33 — ดันกลับด้วย ink_on
        txt(s, x, 6.86, 2.8, 0.28, lb, 9.5, ink_on(mix(P['acc'], fg1, 0.92), P['acc']), 'rg', 'c', track=0.8)


COV4 = ['cx_arc_hero', 'cx_band_trio', 'cx_glass_card', 'cx_mast_rule', 'cx_num_left',
        'cx_wedge_sweep', 'cx_bento4', 'cx_centre_luxe', 'cx_ticket', 'cx_halo_photo']
