"""20 เลย์เอาต์ชุด Corporate Performance Review — ลอกโครงจากเทมเพลตดำ+น้ำเงินสด

พื้นดำทั้งเล่ม บล็อกไล่เฉดน้ำเงินเป็นตัวเน้น หัวเรื่องเป็นตัวพิมพ์ใหญ่น้ำหนักกลาง
มุมบนซ้าย ชื่อบริษัท มุมบนขวา ปี มุมล่างซ้าย ชื่อรายงาน มุมล่างขวา เลขหน้า
"""
from eng import *
import eng
from lay import L, reg

M = 0.72


def _duo():
    """ย้อมรูปให้อยู่ในโทนเดียวกับพาเลตต์ของเด็ค"""
    if P.get('dark'):
        return f"duo:{mix(P['bg'], P['acc'], 0.30)}:{mix(P['acc'], 'FFFFFF', 0.58)}"
    return f"duo:{mix(P['ink'], P['acc'], 0.42)}:{mix(P['bg'], P['acc'], 0.13)}"


def _chrome(s, d, light=False):
    c = '15151C' if light else mix(P['bg'], P['ink'], 0.72)
    txt(s, M, 0.34, 3.0, 0.26, d.get('brand', 'บริษัทของคุณ'), 8, c, 'rg')
    txt(s, W - M - 1.4, 0.34, 1.4, 0.26, d.get('yr', '2570'), 8, c, 'rg', 'r')
    txt(s, M, H - 0.56, 4.6, 0.26, d.get('foot', ''), 11, c, 'rg')
    if d.get('n'):
        txt(s, W - M - 1.0, H - 0.56, 1.0, 0.26, f"{int(d['n']):02d}", 11, c, 'rg', 'r')


def _h(s, x, y, t, sz=43, w=8.0, c=None, wt='md'):
    txt(s, x, y, w, 2.2, t, sz, c or P['ink'], wt, sp=1.16)


def _p(s, x, y, w, t, sz=13, c=None):
    txt(s, x, y, w, 1.5, t, sz, c or mix(P['bg'], P['ink'], 0.62), 'rg', sp=1.44)


def _grad(s, x, y, w, h, ang=0, adj=None, kind='rect'):
    return gradband(s, x, y, w, h, ang, c1=P['g1'], c2=P['g2'], kind=kind, adj=adj)


def _arrow(s, cx, cy, r=0.17, c=None):
    """วงกลมมีลูกศรชี้ขวา แบบที่ต้นฉบับใช้คั่นรายการ"""
    c = c or P['ink']
    shp(s, 'oval', cx - r, cy - r, r * 2, r * 2, None, line=c, lw=0.9)
    ln(s, cx - r * 0.42, cy, cx + r * 0.40, cy, c, 0.9)
    ln(s, cx + r * 0.14, cy - r * 0.26, cx + r * 0.42, cy, c, 0.9)
    ln(s, cx + r * 0.14, cy + r * 0.26, cx + r * 0.42, cy, c, 0.9)


def _stripes(s, x, y, w, h, n=4):
    """แถบไล่เฉดซ้อนกันเป็นชั้น ที่ต้นฉบับใช้เป็นพื้นหลังตกแต่ง"""
    bh = h / (n * 1.8)
    for i in range(n):
        _grad(s, x, y + i * bh * 1.8, w * (1 - i * 0.12), bh)


# ══ เลย์เอาต์ตามรูปอ้างอิง ═════════════════════════════════════════════════

@reg
def pr_cover(prs, d):
    s = page(prs)
    _stripes(s, 0, 2.70, 4.60, 3.40, 4)
    shp(s, 'rect', 3.30, 0.90, W - M - 3.30, H - 1.80, '0A0A10')
    _chrome(s, d)
    _p(s, 3.76, 1.22, 4.0, d['s'], 13.5)
    pic(s, ph(d['topic'], d.get('pi', 0)), 9.30, 1.16, 2.30, 1.40, mode=_duo())
    txt(s, 3.76, 2.26, 8.2, 2.5, d['t'], 51, 'FFFFFF', 'md', sp=1.14, caps=True)
    _p(s, 3.76, 5.10, 4.4, d.get('note', ''), 13)


@reg
def pr_toc(prs, d):
    s = page(prs)
    _chrome(s, d)
    pic(s, ph(d['topic'], d.get('pi', 1)), M, 0.96, 2.62, 2.72, mode=_duo())
    _h(s, M, 4.00, d['t'], 37, 2.9)
    for i, (h_, body) in enumerate(d['items'][:5]):
        y = 0.96 + i * 1.02
        txt(s, 3.70, y, 0.7, 0.34, f'{i + 1:02d}', 16, 'FFFFFF', 'md', an='m')
        _grad(s, 4.55, y, W - M - 4.55, 0.74, 0)
        txt(s, 4.80, y, 5.2, 0.74, h_, 15, 'FFFFFF', 'md', an='m')
        _p(s, 10.20, y + 0.12, 2.2, body, 13, 'D4D4FF')
    _p(s, M, 5.32, 2.9, d.get('note', ''), 13)


@reg
def pr_photo_stats(prs, d):
    s = page(prs)
    _chrome(s, d)
    pic(s, ph(d['topic'], d.get('pi', 2)), 0, 0.90, 4.90, H - 1.80, mode=_duo())
    shp(s, 'rect', 5.20, 0.90, W - M - 5.20, H - 1.80, '0D0D14')
    for i, (v, lab) in enumerate(d['items'][:4]):
        x = 5.70 + (i % 2) * 3.30
        y = 1.36 + (i // 2) * 1.44
        _arrow(s, x, y + 0.30)
        txt(s, x + 0.40, y, 2.5, 0.60, v, 36, 'FFFFFF', 'md')
        _p(s, x + 0.40, y + 0.64, 2.6, lab, 13)
    ln(s, 5.70, 4.56, 11.60, 4.56, mix(P['bg'], P['ink'], 0.26), 0.7)
    _h(s, 5.70, 4.76, d['t'], 31, 5.9, wt='md')


@reg
def pr_rows_card(prs, d):
    s = page(prs)
    _chrome(s, d)
    _h(s, M, 1.00, d['t'], 37, 9.4)
    shp(s, 'rect', M, 2.62, W - M * 2, 3.26, '0F0F18')
    for i, (h_, body) in enumerate(d['items'][:3]):
        y = 2.92 + i * 0.96
        txt(s, M + 0.36, y, 0.7, 0.32, f'{i + 1:02d}', 15, P['acc2'], 'md')
        txt(s, M + 1.16, y, 4.0, 0.32, h_, 15, 'FFFFFF', 'md')
        _p(s, M + 1.16, y + 0.34, 5.4, body, 13)
    pic(s, ph(d['topic'], d.get('pi', 3)), 8.10, 2.92, 3.60, 2.64, mode=_duo())
    _grad(s, 8.10, 5.26, 3.60, 0.30, 0)


@reg
def pr_block_text(prs, d):
    s = page(prs)
    _chrome(s, d)
    _grad(s, 0, 1.80, 5.40, 2.70, 0)
    _h(s, 0.90, 2.34, d['t'], 34, 4.0, 'FFFFFF')
    _p(s, 6.10, 2.00, 5.0, d['note'], 13.5)
    _arrow(s, 11.80, 2.16, 0.20)
    _stripes(s, 0, 5.00, 4.20, 1.40, 3)
    _p(s, 6.10, 4.60, 5.0, d.get('note2', ''), 13)


@reg
def pr_bars_rows(prs, d):
    s = page(prs)
    _chrome(s, d)
    _h(s, M, 1.00, d['t'], 37, 5.6)
    for i, (lab, body) in enumerate(d['items'][:3]):
        y = 3.00 + i * 0.84
        txt(s, M, y, 0.6, 0.34, f'{i + 1}.', 15, P['acc2'], 'md', an='m')
        _p(s, M + 0.70, y + 0.04, 4.6, body, 13)
        ln(s, M, y + 0.62, 5.80, y + 0.62, mix(P['bg'], P['ink'], 0.18), 0.6)
    gx = 6.60; gw = W - M - gx
    mx = max(v for _, v in d['bars'][:3]) or 1
    for i, (lab, v) in enumerate(d['bars'][:3]):
        y = 2.30 + i * 0.86
        bw = gw * (v / mx)
        _grad(s, gx + gw - bw, y, bw, 0.62, 0)
        txt(s, gx, y, gw - 0.90, 0.62, lab, 14, 'FFFFFF', 'rg', an='m')
        txt(s, gx + gw - 0.86, y, 0.70, 0.62, f'{v}%', 15.5, 'FFFFFF', 'md', 'r', 'm')


@reg
def pr_circles(prs, d):
    s = page(prs)
    _chrome(s, d)
    _h(s, M, 1.00, d['t'], 37, 9.4)
    base = [(2.05, 4.92, 1.16), (3.95, 4.26, 1.36), (6.05, 4.26, 1.36), (7.95, 4.92, 1.16)]
    for i, (it, (cx, cy, dia)) in enumerate(zip(d['items'][:4], base)):
        v, lab = it
        _grad(s, cx - dia / 2, cy - dia / 2, dia, dia, 300, kind='oval')
        txt(s, cx - dia / 2, cy - 0.40, dia, 0.30, lab, 13, 'DDDDFF', 'rg', 'c', 'm')
        txt(s, cx - dia / 2, cy - 0.02, dia, 0.40, v, 17, 'FFFFFF', 'md', 'c', 'm')
        if i: ln(s, base[i - 1][0], base[i - 1][1] - base[i - 1][2] / 2 - 0.10,
                 cx, cy - dia / 2 - 0.10, mix(P['bg'], P['ink'], 0.22), 0.7)
    _p(s, 9.40, 4.00, 3.2, d['note'], 13)


@reg
def pr_three_cols(prs, d):
    s = page(prs)
    _chrome(s, d)
    cw = 2.62
    for i, (v, lab) in enumerate(d['items'][:3]):
        x = M + i * cw
        if i == 1: _grad(s, x, 0.96, cw - 0.10, 4.20, 90)
        else: shp(s, 'rect', x, 0.96, cw - 0.10, 4.20, '0E0E16')
        txt(s, x + 0.28, 1.22, cw - 0.56, 0.62, v, 37, 'FFFFFF', 'md')
        _p(s, x + 0.28, 1.94, cw - 0.62, lab, 13, 'D4D4FF' if i == 1 else None)
    shp(s, 'rect', M + cw * 3, 0.96, W - M - (M + cw * 3), 4.20, '0A0A12')
    _h(s, M + cw * 3 + 0.40, 1.60, d['t'], 33, 3.9)


@reg
def pr_white_cols(prs, d):
    s = page(prs, 'FFFFFF')
    _chrome(s, d, True)
    _h(s, M, 1.10, d['t'], 37, 9.0, '15151C')
    cw = (W - M * 2 - 0.60) / 3
    for i, (h_, body) in enumerate(d['items'][:3]):
        x = M + i * (cw + 0.30)
        _p(s, x, 2.86, cw, h_, 14, '2A2A38')
        _p(s, x, 4.00, cw, body, 13, '55556A')
        ln(s, x, 5.42, x + cw, 5.42, 'D8D8E2', 0.7)
        txt(s, x, 5.54, cw, 0.28, f'{i + 1:02d}', 13, '8A8AA2', 'rg')
    _stripes(s, 0, H - 1.10, 2.60, 1.10, 2)


@reg
def pr_thanks(prs, d):
    s = page(prs)
    _chrome(s, d)
    _h(s, M, 1.90, d['t'], 51, 6.6, wt='md')
    _p(s, M, 4.40, 5.2, d.get('note', ''), 13.5)
    pic(s, ph(d['topic'], d.get('pi', 5)), 8.30, 1.00, 2.10, 1.50, mode=_duo())
    _stripes(s, 8.30, 2.80, 2.10, 1.70, 3)
    _arrow(s, 9.00, 5.00, 0.20)
    _p(s, 10.90, 1.10, 1.70, d.get('note2', ''), 13)


# ══ อีก 10 เลย์เอาต์ ═══════════════════════════════════════════════════════

@reg
def pr_divider(prs, d):
    s = page(prs)
    pic(s, ph(d['topic'], d.get('pi', 6)), 7.00, 0, W - 7.00, H, mode=_duo())
    shp(s, 'rect', 7.00, 0, W - 7.00, H, '050509', a=0.40)
    _chrome(s, d)
    _stripes(s, 0, 1.40, 3.40, 1.30, 3)
    txt(s, M, 3.10, 2.6, 1.2, d['num'], 54, mix(P['bg'], P['ink'], 0.34), 'md')
    _h(s, M, 4.30, d['t'], 38, 5.6)
    if d.get('s'): _p(s, M, 5.42, 5.4, d['s'], 13.5)


@reg
def pr_photo_bars(prs, d):
    s = page(prs, 'FFFFFF')
    _chrome(s, d, True)
    pic(s, ph(d['topic'], d.get('pi', 7)), M, 1.00, 2.10, 1.60, mode=_duo())
    pic(s, ph(d['topic'], d.get('pi2', 11)), 2.98, 1.00, 2.10, 1.60, mode=_duo())
    _h(s, M, 3.10, d['t'], 33, 4.4, '15151C')
    gx = 5.60; gw = W - M - gx
    mx = max(v for _, v in d['bars'][:4]) or 1
    for i, (lab, v) in enumerate(d['bars'][:4]):
        y = 1.04 + i * 1.22
        bw = max(gw * 0.52 * (v / mx), 0.9)        # เดิมแท่งยาวเต็มคอลัมน์ ป้ายเลยเหลือที่ไม่พอจนบีบเป็นเส้น
        if i % 2 == 0: _grad(s, gx, y, bw, 0.62, 0)
        else: shp(s, 'rect', gx, y, bw, 0.62, 'E4E4F0')
        txt(s, gx + 0.22, y, bw - 0.44, 0.62, f'{v}%', 15.5, 'FFFFFF' if i % 2 == 0 else '15151C', 'md', an='m')
        _p(s, gx, y + 0.68, W - M - gx, lab, 13, '55556A')


@reg
def pr_blocks(prs, d):
    s = page(prs)
    _chrome(s, d)
    _h(s, M, 1.90, d['t'], 34, 3.6)
    spec = [(4.50, 1.00, 2.90, 1.70), (7.60, 1.00, 4.00, 1.70),
            (4.50, 2.90, 2.90, 2.20), (7.60, 2.90, 4.00, 2.20)]
    for i, (it, (x, y, w, h)) in enumerate(zip(d['items'][:4], spec)):
        v, lab = it
        if i in (1, 2): _grad(s, x, y, w, h, 300)
        else: shp(s, 'rect', x, y, w, h, '0F0F18')
        txt(s, x + 0.28, y + 0.24, w - 0.56, 0.62, v, 34, 'FFFFFF', 'md')
        _p(s, x + 0.28, y + 0.94, w - 0.56, lab, 13, 'D4D4FF' if i in (1, 2) else None)
    pic(s, ph(d['topic'], d.get('pi', 8)), M, 4.00, 3.40, 1.90, mode=_duo())


@reg
def pr_chart(prs, d):
    s = page(prs)
    _chrome(s, d)
    _h(s, M, 4.40, d['t'], 33, 4.2)
    gx, gw = 4.80, W - M - 4.80
    n = len(d['bars'][:3]); bw = gw / n * 0.46
    base, top = 4.00, 1.10
    mx = max(v for _, v in d['bars'][:3]) or 1
    for i, (lab, v) in enumerate(d['bars'][:3]):
        cx = gx + gw / n * (i + 0.5)
        h = (base - top) * (v / mx)
        if i == 1: shp(s, 'rect', cx - bw / 2, base - h, bw, h, 'FFFFFF')
        else: _grad(s, cx - bw / 2, base - h, bw, h, 90)
        txt(s, cx - bw / 2, base + 0.14, bw, 0.32, f'{v}%', 15, 'FFFFFF', 'md', 'c')
        _p(s, cx - bw / 2 - 0.3, base + 0.50, bw + 0.6, lab, 13, None)
    for i, (v, lab) in enumerate(d['items'][:2]):
        x = M + i * 1.90
        txt(s, x, 1.10, 1.7, 0.62, v, 37, 'FFFFFF', 'md')
        _p(s, x, 1.80, 1.7, lab, 13)


@reg
def pr_list_block(prs, d):
    s = page(prs)
    _chrome(s, d)
    for i, (h_, body) in enumerate(d['items'][:3]):
        y = 1.00 + i * 0.86
        txt(s, M, y, 0.6, 0.32, f'{i + 1}.', 15, P['acc2'], 'md')
        txt(s, M + 0.66, y, 5.0, 0.32, h_, 15, 'FFFFFF', 'md')
        _p(s, M + 0.66, y + 0.34, 5.0, body, 13)
        ln(s, M, y + 0.74, 6.10, y + 0.74, mix(P['bg'], P['ink'], 0.18), 0.6)
    _grad(s, 6.80, 1.00, W - M - 6.80, 2.46, 300)
    _arrow(s, 7.20, 1.40, 0.18)
    txt(s, 7.14, 1.86, 3.4, 0.80, d['big'], 45, 'FFFFFF', 'md')
    _p(s, 7.14, 2.76, 4.2, d['biglab'], 13, 'D4D4FF')
    shp(s, 'rect', 0, 4.20, 6.10, 1.70, '0F0F18')
    _h(s, 0.90, 4.52, d['t'], 30, 4.6)
    _p(s, 6.80, 4.44, 5.0, d.get('note', ''), 13)


@reg
def pr_quote(prs, d):
    s = page(prs, 'FFFFFF')
    _chrome(s, d, True)
    pic(s, ph(d['topic'], d.get('pi', 9)), M, 1.00, 3.90, 4.30, mode=_duo())
    txt(s, 5.30, 1.30, 7.2, 2.6, f'"{d["t"]}"', 27, '15151C', 'md', sp=1.34)
    _arrow(s, 5.52, 4.60, 0.20, '15151C')
    txt(s, 6.00, 4.44, 5.0, 0.30, d['who'], 15, '15151C', 'md')
    _p(s, 6.00, 4.78, 5.0, d['role'], 13, '55556A')


@reg
def pr_desc_blocks(prs, d):
    s = page(prs)
    _chrome(s, d)
    _h(s, M, 1.00, d['t'], 37, 9.4)
    n = len(d['items'][:4])
    for i, (num, h_, body) in enumerate(d['items'][:4]):
        x = M + i * 2.98
        h = 2.90 - i * 0.42
        y = 5.80 - h
        if i == 0: _grad(s, x, y, 2.74, h, 90)
        else: shp(s, 'rect', x, y, 2.74, h, '0F0F18')
        txt(s, x + 0.28, y + 0.22, 1.2, 0.56, num, 31, 'FFFFFF', 'md')
        txt(s, x + 0.28, y + 0.88, 2.2, 0.30, h_, 14, 'FFFFFF', 'md')
        _p(s, x + 0.28, y + 1.22, 2.2, body, 13, 'D4D4FF' if i == 0 else None)


@reg
def pr_table(prs, d):
    s = page(prs)
    _chrome(s, d)
    _h(s, M, 1.00, d['t'], 37, 9.4)
    tw = W - M * 2; cols = d['colw']; y0 = 2.56
    _grad(s, M, y0, tw, 0.52, 0)
    cx = M
    for j, (hd, fr) in enumerate(zip(d['head'], cols)):
        txt(s, cx + 0.20, y0, tw * fr - 0.40, 0.52, hd, 14, 'FFFFFF', 'md', 'l' if j == 0 else 'r', 'm'); cx += tw * fr
    for i, row in enumerate(d['rows'][:5]):
        y = y0 + 0.52 + i * 0.56
        if i % 2 == 0: shp(s, 'rect', M, y, tw, 0.56, '0F0F18')
        cx = M
        for j, (cell, fr) in enumerate(zip(row, cols)):
            txt(s, cx + 0.20, y, tw * fr - 0.40, 0.56, cell, 14.5,
                'FFFFFF' if j == len(cols) - 1 else mix(P['bg'], P['ink'], 0.78),
                'md' if j == len(cols) - 1 else 'rg', 'l' if j == 0 else 'r', 'm'); cx += tw * fr
    if d.get('note'): _p(s, M, y0 + 0.52 + len(d['rows'][:5]) * 0.56 + 0.18, 9.6, d['note'], 13)


@reg
def pr_timeline(prs, d):
    s = page(prs)
    _chrome(s, d)
    _h(s, M, 1.00, d['t'], 37, 7.4)
    n = len(d['items'][:4]); cw = (W - M * 2) / n
    ln(s, M, 3.70, W - M, 3.70, mix(P['bg'], P['ink'], 0.20), 0.8)
    for i, (per, h_, body) in enumerate(d['items'][:4]):
        x = M + i * cw
        shp(s, 'oval', x, 3.56, 0.28, 0.28, P['acc2'] if i < 2 else mix(P['bg'], P['ink'], 0.26))
        txt(s, x, 3.06, cw - 0.4, 0.32, per, 15.5, P['acc2'] if i < 2 else None, 'md')
        txt(s, x, 4.08, cw - 0.45, 0.56, h_, 16, 'FFFFFF', 'md', sp=1.25)
        _p(s, x, 4.78, cw - 0.52, body, 13)


@reg
def pr_next(prs, d):
    s = page(prs)
    _chrome(s, d)
    _h(s, M, 1.00, d['t'], 37, 9.4)
    cw = (W - M * 2 - 0.44) / 3
    for i, (h_, body, when) in enumerate(d['items'][:3]):
        x = M + i * (cw + 0.22)
        if i == 0: _grad(s, x, 2.62, cw, 2.90, 300)
        else: shp(s, 'rect', x, 2.62, cw, 2.90, '0F0F18')
        txt(s, x + 0.30, 2.86, 0.8, 0.34, f'{i + 1:02d}', 16.5, 'FFFFFF', 'md')
        txt(s, x + 0.30, 3.34, cw - 0.60, 0.60, h_, 16, 'FFFFFF', 'md', sp=1.25)
        _p(s, x + 0.30, 4.08, cw - 0.60, body, 13, 'D4D4FF' if i == 0 else None)
        ln(s, x + 0.30, 4.88, x + cw - 0.30, 4.88, mix(P['bg'], P['ink'], 0.26), 0.6)
        txt(s, x + 0.30, 5.00, cw - 0.60, 0.28, when, 13, 'FFFFFF', 'md')
