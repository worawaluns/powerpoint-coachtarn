"""20 เลย์เอาต์ชุดรายงานผลงานแบบ Impact Report — ลอกโครงจาก Tesla Impact Report 2022 (ref-templates/21-tesla-impact-*.jpg)

พื้นขาวนวล FAFAF7 แผงเทามน F0F0EC รองกราฟและตาราง หัวเรื่องดำตัวกลางซ้ายบน เนื้อความเทา ท้ายหน้าเทาเล็ก (รายงาน · ส่วน · หน้า)
หนึ่งส่วนหนึ่งสีเน้น (อำพัน เขียว ส้ม ม่วง): a1-a4 ใช้กับตัวเลข/ตัวหนังสือ (>= 4.9 บนแผง), b1-b4 ใช้กับแถบ บล็อก callout (ตัวหนังสือดำบนบล็อก >= 7.1)
หน้าคั่นพื้นดำ หัวเรื่องขาวซ้าย รูปมุมมนขวา · ตัวเลขใหญ่สีเน้นกับป้ายเทาเล็ก · ประโยคสองโทน (เทา 5F5F5F 6.1 + ดำ) เหนือรูปกว้าง
บนพื้นดำ: ขาว 19.7, เทา A3A3A3 7.8, สีเน้นสด b1-b4 >= 7.4
"""
from eng import *
import eng
from lay import L, reg

txt = txt_big        # ขนาดขั้นต่ำตามชุด 366
chart = chart_big

M = 0.62
R = W - M
TOP = 0.55
K = '0B0B0B'           # พื้นดำหน้าคั่น
GREY = 'A3A3A3'        # ตัวรองบนพื้นดำ
LIGHT = 'C9C9C4'       # แถบปีเก่า/แถบรอง (ไม่ใช่ตัวหนังสือ)
MID = '8F8F8A'         # แถบชั้นกลาง (ไม่ใช่ตัวหนังสือ)
LINE = 'D9D9D4'        # เส้นคั่นบาง
RAD = 0.18             # รัศมีมุมมนทุกแผงและรูป (นิ้ว)


def _sec(d):
    return int(d.get('sec', 0) or 0)


def A(d):
    """สีเน้นสำหรับตัวหนังสือ/ตัวเลขของส่วนนี้"""
    k = _sec(d)
    return P[f'a{k}'] if k else P['ink']


def B(d):
    """สีเน้นสดสำหรับแถบ บล็อก และตัวหนังสือบนพื้นดำ"""
    k = _sec(d)
    return P[f'b{k}'] if k else P['ink']


def _adj(w, h, r=RAD):
    return min(0.5, r / max(min(w, h), 0.01))


def _duo(d):
    # Ice 5 พ.ย. 2569: "สีหม่นๆแต่ละสไลด์ไปครับ" -> รูปสีจริงแบบ Tesla ไม่ย้อม duotone
    return None


def _photo(s, d, n, x, y, w, h, topic=None, focus=(0.5, 0.45), shadow=True):
    pic(s, ph(topic or d.get('topic', 'logistics'), n), x, y, w, h, geom='roundRect', adj=_adj(w, h),
        mode=_duo(d), focus=focus, shadow=('000000', 0.16, 20, 6) if shadow else None)


def _panel(s, x, y, w, h, fill=None):
    return shp(s, 'round', x, y, w, h, fill or P['panel'], adj=_adj(w, h))


def _chrome(s, d, dark=False):
    c = GREY if dark else P['mute']
    txt(s, M, H - 0.50, 3.4, 0.26, d.get('foot', ''), 9, c, 'rg')
    if d.get('part'):
        txt(s, 4.10, H - 0.50, 4.0, 0.26, d['part'], 9, c, 'rg')
    if d.get('n'):
        txt(s, R - 1.0, H - 0.50, 1.0, 0.26, f"{int(d['n'])}", 9, c, 'rg', 'r')


def _title(s, t, x=M, y=TOP, w=5.4, sz=26, c=None):
    txt(s, x, y, w, 1.4, t, sz, c or P['ink'], 'md', sp=1.05)


def _body(s, x, y, w, t, sz=13, c=None, h=3.0):
    if t: txt(s, x, y, w, h, t, sz, c or P['mute'], 'rg', sp=1.38)


def _num(s, x, y, w, v, unit='', sz=48, c=None, al='l', h=None):
    c = c or P['ink']
    txt(s, x, y, w, h or sz / 52, '', sz, c, 'md', al, runs=[[(v, {}), (unit, {'sz': max(14, int(sz * 0.5))})]] if unit else [[(v, {})]])


def _callout(s, d, x, y, w, h, ic, t, sz=15):
    shp(s, 'round', x, y, w, h, B(d), adj=_adj(w, h, 0.14))
    icon(s, ic, x + 0.55, y + h / 2, 0.42, P['ink'])
    txt(s, x + 1.0, y, w - 1.2, h, t, sz, P['ink'], 'md', an='m', sp=1.1)


def _dot(s, x, y, c, d_=0.14):
    shp(s, 'oval', x, y, d_, d_, c)


def _two_tone(s, x, y, w, parts, sz=34, h=3.0):
    """ประโยคสองโทน: parts = [(ข้อความ, True=ดำ/False=เทา), ...]"""
    txt(s, x, y, w, h, '', sz, P['ink'], 'md', sp=1.12,
        runs=[[(t, {'c': P['ink'] if k else P['mute']}) for t, k in parts]])


def _hair(s, x1, y, x2, c=None, w=0.75):
    ln(s, x1, y, x2, y, c or LINE, w)


# ══ เลย์เอาต์ที่ลอกตรงจากรายงาน ═══════════════════════════════════════════

@reg
def ti_cover(prs, d):
    """หน้า 1: รูปเต็มหน้า ชื่อรายงานซ้ายล่าง ปีซ้อนสองบรรทัดขวาล่าง"""
    s = page(prs, K)
    pic(s, ph(d.get('topic', 'logistics'), d.get('pi', 0)), 0, 0, W, H, mode=_duo(d), focus=(0.5, 0.4))
    gradband(s, 0, 1.6, W, H - 1.6, 90, c1=K, c2=K, a1=0.0, a2=0.92)
    shp(s, 'rect', 0, 3.70, W, H - 3.70, K, a=0.62)
    txt(s, M, 3.90, 8.4, 0.4, d.get('k', ''), 15, 'E6E6E6', 'md')
    txt(s, M, 4.45, 9.2, 2.0, d['t'], 46, 'FFFFFF', 'md', sp=1.02)
    _body(s, M, 6.30, 8.0, d.get('s', ''), 13, 'D4D4D4', 0.6)
    yr = d.get('yr', '2568')
    txt(s, R - 2.4, 4.45, 2.4, 2.4, f"{yr[:2]}\n{yr[2:]}", 66, 'FFFFFF', 'md', 'r', sp=0.92)


@reg
def ti_letter(prs, d):
    """หน้า 2: หัวเรื่องซ้ายบน ข้อความเทาสองคอลัมน์ ลงชื่อท้าย + ตัวเลขสามตัวขวา"""
    s = page(prs)
    _chrome(s, d)
    _title(s, d['t'], w=7.0)
    cols = d['cols']
    for i, t in enumerate(cols[:2]):
        _body(s, M + i * 4.55, 1.75, 4.15, t, 13.5, h=4.2)
    txt(s, M, 5.85, 4.0, 0.36, d.get('who', ''), 15, P['ink'], 'md')
    txt(s, M, 6.22, 5.0, 0.3, d.get('role', ''), 12, P['mute'], 'rg')
    x = 10.05
    for i, (v, unit, lab) in enumerate(d.get('items', [])[:3]):
        y = 1.75 + i * 1.55
        _hair(s, x, y, R)
        _num(s, x, y + 0.18, R - x, v, unit, 32, A(d))
        txt(s, x, y + 0.88, R - x, 0.5, lab, 12, P['mute'], 'rg', sp=1.2)


@reg
def ti_index(prs, d):
    """หน้า 12/26/45: แถบรูปสี่ใบเป็นสารบัญ เส้นคั่น แล้วตัวเลขเด่นห้าตัวสีตามส่วน"""
    s = page(prs)
    _chrome(s, d)
    _title(s, d['t'], w=8.0, sz=24)
    cards = d['cards'][:4]; g = 0.28; cw = (W - 2 * M - g * (len(cards) - 1)) / len(cards)
    for i, (title, pages, pi, topic) in enumerate(cards):
        x = M + i * (cw + g)
        txt(s, x, 1.40, cw, 0.34, title, 14, P['ink'], 'md')
        txt(s, x, 1.74, cw, 0.3, pages, 11, P['mute'], 'rg')
        _photo(s, {'sec': i + 1}, pi, x, 2.15, cw, 1.75, topic)
    _hair(s, M, 4.35, R)
    items = d['items'][:5]; iw = (W - 2 * M) / len(items)
    for i, (v, unit, lab, sec) in enumerate(items):
        x = M + i * iw
        _num(s, x, 4.62, iw - 0.15, v, unit, 36, A({'sec': sec}))
        txt(s, x, 5.42, iw - 0.3, 0.8, lab, 12, P['mute'], 'rg', sp=1.2)


@reg
def ti_opener(prs, d):
    """หน้า 3/11/25: หน้าคั่นพื้นดำ หัวเรื่องใหญ่ซ้าย คำโปรยเทา รูปมุมมนขวา"""
    s = page(prs, K)
    _photo(s, d, d.get('pi', 0), 6.85, 0.45, W - 6.85 - 0.45, 6.30, shadow=False)
    shp(s, 'rect', M, 2.45, 0.55, 0.05, B(d))
    txt(s, M, 2.70, 5.9, 2.2, d['t'], 46, 'FFFFFF', 'md', sp=1.02)
    _body(s, M, 4.55, 5.2, d.get('s', ''), 14, GREY, 1.4)
    _chrome(s, d, True)


@reg
def ti_tiles(prs, d):
    """หน้า 7: หัวเรื่อง + ย่อหน้าสั้น แล้วแผ่นตัวเลขเล็ก 4x2 ไอคอนซ้าย ตัวเลขสีเน้น"""
    s = page(prs)
    _chrome(s, d)
    _title(s, d['t'], w=5.4)
    _body(s, M, 1.70, 5.6, d.get('body', ''), 13, h=1.2)
    items = d['items'][:8]; g = 0.22; cw = (W - 2 * M - 3 * g) / 4; ch = 1.55
    for i, (ic, v, unit, lab) in enumerate(items):
        x = M + (i % 4) * (cw + g); y = 3.25 + (i // 4) * (ch + g)
        _panel(s, x, y, cw, ch)
        icon(s, ic, x + 0.45, y + 0.52, 0.36, A(d))
        _num(s, x + 0.85, y + 0.22, cw - 0.95, v, unit, 24, A(d))
        txt(s, x + 0.85, y + 0.78, cw - 1.0, 0.7, lab, 12, P['mute'], 'rg', sp=1.15)


@reg
def ti_statement(prs, d):
    """หน้า 13/27/31: ประโยคสองโทนตัวใหญ่ซ้าย รูปมุมมนมีเงาขวา"""
    s = page(prs)
    _chrome(s, d)
    shp(s, 'rect', M, 2.05, 0.45, 0.04, B(d))
    txt(s, M, 2.20, 5.4, 0.34, d.get('k', ''), 13, A(d), 'md')
    _two_tone(s, M, 2.75, 5.6, d['parts'], 34)
    _photo(s, d, d.get('pi', 0), 6.80, TOP, R - 6.80, 6.20)


@reg
def ti_split(prs, d):
    """หน้า 8: แผงกว้างมีแถบแบ่งสัดส่วนเป็นท่อน ตัวเลข % ใต้แต่ละท่อน"""
    s = page(prs)
    _chrome(s, d)
    _title(s, d['t'], w=5.4)
    _body(s, M, 1.70, 5.6, d.get('body', ''), 13, h=1.3)
    if d.get('note'): _body(s, 7.0, 1.70, R - 7.0, d['note'], 13, h=1.3)
    py, phh = 3.35, 3.35
    _panel(s, M, py, W - 2 * M, phh)
    txt(s, M + 0.4, py + 0.32, 8, 0.34, d.get('ptitle', ''), 14, P['ink'], 'md')
    txt(s, M + 0.4, py + 0.66, 8, 0.3, d.get('psub', ''), 12, P['mute'], 'rg')
    items = d['items']; tot = sum(p for p, *_ in items); bw = W - 2 * M - 0.8; g = 0.06
    x = M + 0.4; by = py + 1.35
    shades = [B(d), mix(B(d), 'FFFFFF', 0.30), mix(B(d), 'FFFFFF', 0.55), mix(B(d), 'FFFFFF', 0.75)]
    for i, (pct, lab, sub) in enumerate(items):
        w = (bw - g * (len(items) - 1)) * pct / tot
        shp(s, 'round', x, by, w, 0.16, shades[i % 4], adj=0.5)
        tw = max(w, min(1.9, R - 0.4 - x))
        txt(s, x, by + 0.38, tw, 0.5, f'{pct:g}%', 24, P['ink'], 'md')
        txt(s, x, by + 0.95, tw - 0.1, 0.34, lab, 13, P['ink'], 'md')
        txt(s, x, by + 1.30, tw - 0.1, 0.6, sub, 12, P['mute'], 'rg', sp=1.15)
        x += w + g


@reg
def ti_stack2(prs, d):
    """หน้า 4/5: แผงมีแถบเทียบสองแถว (ก่อน/หลัง) แต่ละแถวแบ่งท่อนตามองค์ประกอบ + คำอธิบายสีด้านล่าง"""
    s = page(prs)
    _chrome(s, d)
    _title(s, d['t'], w=5.6)
    _body(s, M, 1.70, 5.4, d.get('body', ''), 13, h=1.4)
    if d.get('call'): _callout(s, d, 7.0, 1.72, R - 7.0, 0.95, d.get('ic', 'coins'), d['call'], 14)
    py, phh = 3.40, 3.30
    _panel(s, M, py, W - 2 * M, phh)
    comps = d['comps']                     # [(ชื่อ, ค่าแถวบน, ค่าแถวล่าง)]
    rows = d['rows']                       # [(ชื่อแถว, ป้ายรวม)] 2 แถว
    cols = [P['ink'], B(d), MID, LIGHT]
    mx = max(sum(c[1] for c in comps), sum(c[2] for c in comps))
    x0, bw = M + 2.15, W - 2 * M - 2.15 - 1.85
    for r, (name, tot) in enumerate(rows[:2]):
        y = py + 0.45 + r * 0.95
        txt(s, M + 0.4, y - 0.05, 1.7, 0.4, name, 15, P['ink'], 'md')
        x = x0
        for i, c in enumerate(comps):
            w = bw * c[1 + r] / mx
            shp(s, 'rect', x, y + 0.04, max(w - 0.03, 0.02), 0.24, cols[i % 4])
            x += w
        txt(s, x + 0.2, y - 0.04, 1.7, 0.4, tot, 15, A(d) if r else P['ink'], 'md')
    ly = py + 2.40; lw = (W - 2 * M - 0.8) / len(comps)
    _hair(s, M + 0.4, ly - 0.20, R - 0.4)
    for i, (name, a, b) in enumerate(comps):
        x = M + 0.4 + i * lw
        _dot(s, x, ly + 0.08, cols[i % 4])
        txt(s, x + 0.25, ly, lw - 0.3, 0.32, name, 12, P['ink'], 'md')
        txt(s, x + 0.25, ly + 0.32, lw - 0.3, 0.32, f'{a:.2f} → {b:.2f}', 12, P['mute'], 'rg')


@reg
def ti_3cards(prs, d):
    """หน้า 9/10: แผงสามใบ ตัวเลขใหญ่สีเน้น เส้นคั่น แล้วแถวย่อยมีแถบบางเทียบก่อน/หลัง"""
    s = page(prs)
    _chrome(s, d)
    _title(s, d['t'], w=8.5)
    cards = d['cards'][:3]; g = 0.32; cw = (W - 2 * M - g * 2) / 3; y0, chh = 1.60, 5.15
    for i, c in enumerate(cards):
        x = M + i * (cw + g)
        _panel(s, x, y0, cw, chh)
        txt(s, x + 0.35, y0 + 0.30, cw - 0.7, 0.6, c['h'], 14, P['ink'], 'md', sp=1.1)
        _num(s, x + 0.35, y0 + 0.92, cw - 0.5, c['v'], c.get('u', ''), 44, A(d))
        txt(s, x + 0.35, y0 + 1.82, cw - 0.7, 0.32, c.get('lab', ''), 12, P['mute'], 'rg')
        _hair(s, x + 0.35, y0 + 2.30, x + cw - 0.35)
        for j, (lab, a, b, fa, fb) in enumerate(c['rows'][:3]):
            y = y0 + 2.50 + j * 0.72
            txt(s, x + 0.35, y, 1.55, 0.6, lab, 12, P['ink'], 'rg', sp=1.1)
            mx = max(a, b) or 1; tw = cw - 0.35 - 1.95 - 0.35
            shp(s, 'round', x + 1.95, y + 0.10, max(tw * a / mx, 0.08), 0.08, LIGHT, adj=0.5)
            shp(s, 'round', x + 1.95, y + 0.26, max(tw * b / mx, 0.08), 0.08, B(d), adj=0.5)
            txt(s, x + 1.95, y + 0.36, tw, 0.3, f'{fa} → {fb}', 11, P['mute'], 'rg')
        txt(s, x + 0.35, y0 + chh - 0.55, cw - 0.7, 0.32, c.get('foot', ''), 11, P['mute'], 'rg')


@reg
def ti_photo3(prs, d):
    """หน้า 22/24: การ์ดสูงสามใบ ส่วนบนเป็นแผงเทามีไอคอน+หัวข้อ ส่วนล่างเป็นรูปที่จางขึ้นไปหาแผง"""
    s = page(prs)
    _chrome(s, d)
    _title(s, d['t'], w=8.5)
    items = d['items'][:3]; g = 0.30; cw = (W - 2 * M - g * 2) / 3; y0, chh, top = 1.45, 5.30, 2.05
    for i, (ic, h_, body, pi) in enumerate(items):
        x = M + i * (cw + g)
        _photo(s, d, pi, x, y0, cw, chh, shadow=False, focus=(0.5, 0.6))
        shp(s, 'round2', x, y0, cw, top, P['panel'], adj=[_adj(cw, top), 0])
        gradband(s, x, y0 + top - 0.01, cw, 0.95, 90, c1=P['panel'], c2=P['panel'], a1=1.0, a2=0.0)
        icon(s, ic, x + 0.55, y0 + 0.50, 0.38, A(d))
        txt(s, x + 0.35, y0 + 0.85, cw - 0.7, 0.45, h_, 16, P['ink'], 'md')
        txt(s, x + 0.35, y0 + 1.25, cw - 0.6, 0.8, body, 12, P['mute'], 'rg', sp=1.2)


@reg
def ti_widestate(prs, d):
    """หน้า 17/49: ประโยคสองโทนเต็มกว้างด้านบน รูปมุมมนกว้างด้านล่าง"""
    s = page(prs)
    _chrome(s, d)
    _two_tone(s, M, TOP, 11.0, d['parts'], 32, 1.9)
    _photo(s, d, d.get('pi', 0), M, 2.55, W - 2 * M, 4.10, focus=(0.5, 0.55))


@reg
def ti_table(prs, d):
    """หน้า 23: ข้อความ + บล็อก callout ซ้าย ตารางในแผงขวา แถวเด่นสีดำ แถวอื่นสีเทา"""
    s = page(prs)
    _chrome(s, d)
    _title(s, d['t'], w=4.9)
    _body(s, M, 1.75, 4.6, d.get('body', ''), 13, h=2.2)
    if d.get('call'): _callout(s, d, M, 4.20, 4.4, 1.0, d.get('ic', 'trending-up'), d['call'], 15)
    _body(s, M, 5.45, 4.4, d.get('note', ''), 11, h=0.8)
    px, py, pw, phh = 5.95, TOP, R - 5.95, 6.20
    _panel(s, px, py, pw, phh)
    txt(s, px + 0.4, py + 0.35, pw - 0.8, 0.7, d.get('ptitle', ''), 15, P['ink'], 'md', sp=1.1)
    head = d['head']; rows = d['rows']
    cx = [px + 0.4, px + 2.0, px + 3.55, px + 4.85]; cw = [1.6, 1.4, 1.25, pw - 4.85 - 0.4]
    hy = py + 1.25
    for j, h_ in enumerate(head):
        txt(s, cx[j], hy, cw[j], 0.3, h_, 11, P['mute'], 'rg', 'l' if j == 0 else 'r')
    for i, r in enumerate(rows):
        y = hy + 0.45 + i * 0.66
        hot, tot = r[-1] == 1, r[-1] == 2
        c = P['ink'] if (hot or tot) else P['mute']
        for j, v in enumerate(r[:4]):
            txt(s, cx[j], y + 0.08, cw[j], 0.45, v, 15 if j else 14, c, 'md' if (j and (hot or tot)) or tot else 'rg', 'l' if j == 0 else 'r')
        _hair(s, px + 0.4, y + 0.60, px + pw - 0.4, P['ink'] if tot else ('8A8A86' if hot else LINE), 1.0 if tot else 0.75)
    _body(s, px + 0.4, py + phh - 0.65, pw - 0.8, d.get('src', ''), 11, h=0.4)


@reg
def ti_photocard(prs, d):
    """หน้า 50: ข้อความซ้าย รูปใหญ่ขวา มีการ์ดขาวซ้อนบนรูปแสดงตัวเลขรายปี"""
    s = page(prs)
    _chrome(s, d)
    _title(s, d['t'], w=4.8)
    _body(s, M, 1.75, 4.6, d.get('body', ''), 13, h=2.6)
    if d.get('call'): _callout(s, d, M, 4.70, 4.4, 1.0, d.get('ic', 'users'), d['call'], 15)
    px = 5.95
    _photo(s, d, d.get('pi', 0), px, TOP, R - px, 6.20, focus=(d.get('fx', 0.85), 0.4))
    cx, cy, cw, chh = R - 3.05, TOP + 0.30, 2.75, 5.60
    shp(s, 'round', cx, cy, cw, chh, 'FFFFFF', adj=_adj(cw, chh, 0.14), shadow=('000000', 0.14, 16, 4))
    shp(s, 'oval', cx + 0.3, cy + 0.3, 0.36, 0.36, B(d))
    icon(s, d.get('ic2', 'users'), cx + 0.48, cy + 0.48, 0.22, P['ink'])
    txt(s, cx + 0.3, cy + 0.80, cw - 0.5, 0.36, d.get('ctitle', ''), 14, P['ink'], 'md')
    for i, (lab, v, unit) in enumerate(d['rows'][:4]):
        y = cy + 1.30 + i * 1.05
        _hair(s, cx + 0.3, y, cx + cw - 0.3)
        txt(s, cx + 0.3, y + 0.10, cw - 0.5, 0.3, lab, 11, P['mute'], 'rg')
        _num(s, cx + 0.3, y + 0.38, cw - 0.5, v, unit, 24, A(d) if i % 2 else P['ink'])


@reg
def ti_iconcards(prs, d):
    """หน้า 42/52/55: หัวเรื่องบน แผง 3x2 ไอคอนสีเน้น หัวข้อดำ คำอธิบายเทา"""
    s = page(prs)
    _chrome(s, d)
    _title(s, d['t'], w=8.5)
    items = d['items'][:6]; g = 0.26; cw = (W - 2 * M - 2 * g) / 3; ch = 2.45
    for i, (ic, h_, body) in enumerate(items):
        x = M + (i % 3) * (cw + g); y = 1.50 + (i // 3) * (ch + g)
        _panel(s, x, y, cw, ch)
        icon(s, ic, x + 0.55, y + 0.55, 0.40, A(d))
        txt(s, x + 0.35, y + 0.98, cw - 0.7, 0.42, h_, 16, P['ink'], 'md')
        txt(s, x + 0.35, y + 1.42, cw - 0.6, 0.95, body, 12, P['mute'], 'rg', sp=1.2)


@reg
def ti_targets(prs, d):
    """หน้า 60: แถวแผงขวา ชื่อตัวชี้วัดใหญ่ซ้าย แถบสองเส้น (ปีนี้/เป้า) พร้อมค่า"""
    s = page(prs)
    _chrome(s, d)
    shp(s, 'oval', M, TOP + 0.04, 0.40, 0.40, P['ink'])
    icon(s, 'arrow-right', M + 0.20, TOP + 0.24, 0.24, 'FFFFFF')
    _title(s, d['t'], x=M + 0.62, w=4.3, sz=24)
    _body(s, M, 1.60, 4.5, d.get('body', ''), 13, h=3.0)
    rows = d['rows'][:4]; px = 5.75; pw = R - px; g = 0.18
    rh = (6.75 - TOP - g * (len(rows) - 1)) / len(rows)
    for i, (name, l1, v1, s1, l2, v2, s2) in enumerate(rows):
        y = TOP + i * (rh + g)
        _panel(s, px, y, pw, rh)
        txt(s, px + 0.4, y, 2.4, rh, name, 18, P['ink'], 'md', an='m', sp=1.1)
        bx = px + 2.9; bw = pw - 2.9 - 1.55; mx = max(v1, v2) or 1
        for j, (lab, v, sv, c) in enumerate(((l1, v1, s1, MID), (l2, v2, s2, B(d)))):
            yy = y + rh / 2 - 0.42 + j * 0.50
            txt(s, bx, yy - 0.02, 1.0, 0.3, lab, 11, P['mute'], 'rg')
            shp(s, 'round', bx + 1.0, yy + 0.08, bw - 1.0, 0.10, mix(P['panel'], LIGHT, 0.5), adj=0.5)
            shp(s, 'round', bx + 1.0, yy + 0.08, (bw - 1.0) * v / mx, 0.10, c, adj=0.5)
            txt(s, bx + bw + 0.15, yy - 0.06, 1.3, 0.36, sv, 14, A(d) if j else P['ink'], 'md')


# ══ เลย์เอาต์ที่เติมในระบบเดียวกัน ═══════════════════════════════════════

@reg
def ti_colchart(prs, d):
    """ข้อความ + callout ซ้าย แผงขวามีกราฟแท่ง Excel (ปีเก่าเทา ปีนี้สีเน้น)"""
    s = page(prs)
    _chrome(s, d)
    _title(s, d['t'], w=4.9)
    _body(s, M, 1.75, 4.5, d.get('body', ''), 13, h=2.4)
    if d.get('call'): _callout(s, d, M, 4.45, 4.4, 1.0, d.get('ic', 'trending-up'), d['call'], 15)
    px, py, pw, phh = 5.95, TOP, R - 5.95, 6.20
    _panel(s, px, py, pw, phh)
    txt(s, px + 0.4, py + 0.35, pw - 3.0, 0.4, d.get('ptitle', ''), 15, P['ink'], 'md')
    txt(s, px + 0.4, py + 0.72, pw - 3.0, 0.3, d.get('psub', ''), 12, P['mute'], 'rg')
    ser = d['series']; cols = [LIGHT, B(d)]
    for i, (nm, _) in enumerate(ser[:2]):
        x = px + pw - 2.6 + i * 1.2
        _dot(s, x, py + 0.47, cols[i]); txt(s, x + 0.22, py + 0.38, 1.0, 0.3, nm, 12, P['ink'], 'rg')
    chart(s, 'col', px + 0.25, py + 1.25, pw - 0.5, phh - 1.55, d['cats'], ser, cols,
          gap=55, overlap=-8, sz=12, c=P['mute'], lblc=P['ink'])


@reg
def ti_donut(prs, d):
    """ข้อความซ้าย แผงขวามีกราฟโดนัท Excel วงบาง ตัวเลขรวมกลางวง รายการสีข้างวง"""
    s = page(prs)
    _chrome(s, d)
    _title(s, d['t'], w=4.9)
    _body(s, M, 1.75, 4.5, d.get('body', ''), 13, h=3.2)
    px, py, pw, phh = 5.95, TOP, R - 5.95, 6.20
    _panel(s, px, py, pw, phh)
    txt(s, px + 0.4, py + 0.35, pw - 0.8, 0.4, d.get('ptitle', ''), 15, P['ink'], 'md')
    txt(s, px + 0.4, py + 0.72, pw - 0.8, 0.3, d.get('psub', ''), 12, P['mute'], 'rg')
    items = d['items']; cols = [B(d), P['ink'], MID, LIGHT]
    dx, dy, dd = px + 0.35, py + 1.30, 4.40
    chart(s, 'donut', dx, dy, dd, dd, [n for n, *_ in items], [('ต้นทุน', [v for _, v, _ in items])], cols,
          labels=False, hole=72)
    txt(s, dx, dy + dd / 2 - 0.55, dd, 0.6, d.get('big', ''), 30, P['ink'], 'md', 'c')
    txt(s, dx, dy + dd / 2 + 0.08, dd, 0.3, d.get('biglab', ''), 12, P['mute'], 'rg', 'c')
    lx = px + 5.05; tot = sum(v for _, v, _ in items)
    for i, (nm, v, unit) in enumerate(items):
        y = py + 1.75 + i * 1.02
        _dot(s, lx, y + 0.12, cols[i % 4])
        txt(s, lx + 0.28, y, pw - 5.4, 0.34, nm, 13, P['ink'], 'md')
        txt(s, lx + 0.28, y + 0.36, pw - 5.4, 0.34, f'{v:.2f} {unit} · {v / tot * 100:.0f}%', 12, P['mute'], 'rg')


@reg
def ti_linechart(prs, d):
    """ข้อความ + แถวตัวเลขคู่ซ้าย แผงขวามีกราฟเส้น Excel เส้นบาง ไม่มีเส้นตาราง"""
    s = page(prs)
    _chrome(s, d)
    _title(s, d['t'], w=4.9)
    _body(s, M, 1.75, 4.5, d.get('body', ''), 13, h=2.2)
    for i, (v, lab, sub) in enumerate(d.get('specs', [])[:2]):
        y = 4.35 + i * 0.95
        _hair(s, M, y, M + 4.4)
        txt(s, M, y + 0.15, 1.9, 0.6, v, 26, A(d) if i else P['ink'], 'md')
        txt(s, M + 2.0, y + 0.18, 2.4, 0.3, lab, 13, P['ink'], 'md')
        txt(s, M + 2.0, y + 0.48, 2.4, 0.3, sub, 11, P['mute'], 'rg')
    px, py, pw, phh = 5.95, TOP, R - 5.95, 6.20
    _panel(s, px, py, pw, phh)
    txt(s, px + 0.4, py + 0.35, pw - 3.0, 0.4, d.get('ptitle', ''), 15, P['ink'], 'md')
    txt(s, px + 0.4, py + 0.72, pw - 3.0, 0.3, d.get('psub', ''), 12, P['mute'], 'rg')
    ser = d['series']; cols = [MID, B(d)]
    for i, (nm, _) in enumerate(ser[:2]):
        x = px + pw - 2.6 + i * 1.2
        _dot(s, x, py + 0.47, cols[i]); txt(s, x + 0.22, py + 0.38, 1.0, 0.3, nm, 12, P['ink'], 'rg')
    from pptx.enum.chart import XL_LABEL_POSITION
    chart(s, 'line', px + 0.25, py + 1.25, pw - 0.5, phh - 1.55, d['cats'], ser, cols,
          fmt='0.0', sz=12, c=P['mute'], lblc=P['ink'], lw=2.25, minv=d.get('minv'), maxv=d.get('maxv'),
          lblpos=XL_LABEL_POSITION.ABOVE)


@reg
def ti_darkstats(prs, d):
    """หน้า 37: พื้นดำ หัวเรื่องขาวซ้าย ตัวเลขสีเน้นเรียงแถวพร้อมป้าย รูปจางเข้าพื้นดำทางขวา"""
    s = page(prs, K)
    pic(s, ph(d.get('topic', 'logistics'), d.get('pi', 0)), 5.6, 0, W - 5.6, H, mode=_duo(d), focus=(0.5, 0.5))
    gradband(s, 5.6, 0, 3.4, H, 0, c1=K, c2=K, a1=1.0, a2=0.0)
    shp(s, 'rect', M, TOP + 0.08, 0.45, 0.04, B(d))
    txt(s, M, TOP + 0.25, 5.4, 1.4, d['t'], 32, 'FFFFFF', 'md', sp=1.05)
    _body(s, M, 2.30, 5.0, d.get('s', ''), 13, GREY, 0.8)
    for i, (v, lab, sub) in enumerate(d['items'][:4]):
        y = 3.20 + i * 0.92
        txt(s, M, y, 1.9, 0.7, v, 30, B(d), 'md')
        txt(s, M + 2.0, y + 0.05, 3.4, 0.34, lab, 14, 'FFFFFF', 'md')
        txt(s, M + 2.0, y + 0.40, 3.4, 0.3, sub, 12, GREY, 'rg')
    _chrome(s, d, True)


@reg
def ti_ask(prs, d):
    """หน้าปิด: พื้นดำ ตัวเลขขออนุมัติใหญ่ รายการงบมีเส้นคั่น รูปซ้อนสองใบขวา ข้อมูลติดต่อท้าย"""
    s = page(prs, K)
    rx = 8.55
    _photo(s, d, d.get('pi', 0), rx, 0.45, R - rx + 0.17, 3.15, d.get('topic2'), shadow=False)
    _photo(s, d, d.get('pi2', 1), rx, 3.78, R - rx + 0.17, 3.15, shadow=False)
    shp(s, 'rect', M, TOP + 0.08, 0.45, 0.04, B(d))
    txt(s, M, TOP + 0.25, 7.0, 0.4, d.get('k', ''), 15, 'FFFFFF', 'md')
    _num(s, M, 1.10, 7.4, d['big'], d.get('unit', ''), 66, B(d))
    _body(s, M, 2.40, 7.2, d.get('s', ''), 14, GREY, 0.9)
    for i, (lab, v) in enumerate(d['items'][:3]):
        y = 3.45 + i * 0.62
        _hair(s, M, y, M + 7.3, '3A3A3A')
        txt(s, M, y + 0.14, 5.4, 0.4, lab, 14, 'FFFFFF', 'rg')
        txt(s, M + 5.4, y + 0.14, 1.9, 0.4, v, 14, 'FFFFFF', 'md', 'r')
    _hair(s, M, 3.45 + 3 * 0.62, M + 7.3, '3A3A3A')
    txt(s, M, 5.55, 7.3, 0.36, d.get('who', ''), 14, 'FFFFFF', 'md')
    txt(s, M, 5.92, 7.3, 0.6, d.get('contact', ''), 12, GREY, 'rg', sp=1.3)
    _chrome(s, d, True)
