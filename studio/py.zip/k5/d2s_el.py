# ใบ 027 คลังองค์ประกอบ: SVG → รูปทรง PowerPoint (custGeom) ที่เปลี่ยนสีได้ในแอป + ภาพบนจอจากรูปทรงชุดเดียวกัน (เว็บ = ไฟล์)
# ไอซ์ 1 พ.ย. 2569 "จะมีเรื่องอยากเพิ่มฟีเจอร์พวก icon svg , infographic ที่ให้ user เลือกค้นหาเพิ่มได้ด้วยนะ ... เหมือนพวก canva"
# d['add'][N] = {'el': {...}, 'r': [x, y, w, h]} หน่วย 960×540 (= pt)
#   el.k = 'ico'  ไอคอนเวกเตอร์ svg = '<svg viewBox>…' c = [สีหลัก, สีรอง] ('T:primary' | 'P:acc' | '#hex' | None = สีเดิมของชุด)
#   el.k = 'map'  แผนที่ไทย (ไฟล์ MAPF ในเครื่อง) pc = {iso: สี}
#   el.k = 'pic'  ไอคอนที่แปลงเป็นรูปทรงไม่ได้ / ธง / อีโมจิ 3 มิติ: p:pic PNG (o['img']) + svgBlip ถ้ามี svg
#   el.k = 'pat'  ลายพื้น: สี่เหลี่ยม blipFill แบบปูกระเบื้อง (PNG o['img']) tw = ความกว้างกระเบื้องบนสไลด์ (pt)
# รูปทรงของเรา (ลูกศร ป้าย กรอบ เส้นคั่น ชิ้นอินโฟกราฟิก) = d['add'][N] = {'t': ข้อความ, 'ns': {prst, fill, line, ...}} กล่องข้อความแบบรูปทรง แก้คำบนสไลด์ได้
import re, math
from xml.etree import ElementTree as ET

MAPF = '/k5/el/thailand-provinces.svg'               # เว็บเขียนไฟล์นี้ลงเครื่อง Python ตอนวางแผนที่ / เปิดงานที่มีแผนที่
CCBY = {                                              # ชุด CC BY 4.0: บรรทัดเครดิตลงโน้ตของหน้านั้นตอนส่งออก (ไอซ์ข้อ 3) คำตาม CREDITS.md
    'solar': 'Solar Icon Set by 480 Design, CC BY 4.0 (https://creativecommons.org/licenses/by/4.0/). Icons may have been recoloured or resized.',
    'streamline': 'Icons by Streamline (https://streamlinehq.com), CC BY 4.0 (https://creativecommons.org/licenses/by/4.0/). Icons may have been recoloured or resized.',
    'thmap': 'Map of Thailand from @svg-maps/thailand by Tae Noppakun Wongsrinoppakun, based on MapSVG (mapsvg.com), CC BY 4.0 (https://creativecommons.org/licenses/by/4.0/). Thai names, ISO codes and regions added; paths unchanged.',
    'hero': 'Hero Patterns by Steve Schoger (https://heropatterns.com), CC BY 4.0 (https://creativecommons.org/licenses/by/4.0/). Patterns may have been recoloured.'}
CCSET = {'solar': 'solar', 'sl': 'streamline', 'slf': 'streamline', 'slp': 'streamline', 'slu': 'streamline', 'slc': 'streamline', 'thmap': 'thmap', 'hero': 'hero'}

class Unsupported(Exception): pass

# ── อ่าน SVG ────────────────────────────────────────────────────────────────
_NUM = re.compile(r'[-+]?(?:\d+\.?\d*|\.\d+)(?:[eE][-+]?\d+)?')
_TOK = re.compile(r'[MmLlHhVvCcSsQqTtAaZz]|[-+]?(?:\d+\.?\d*|\.\d+)(?:[eE][-+]?\d+)?')

def _mul(a, b):
    return (a[0] * b[0] + a[2] * b[1], a[1] * b[0] + a[3] * b[1], a[0] * b[2] + a[2] * b[3], a[1] * b[2] + a[3] * b[3],
            a[0] * b[4] + a[2] * b[5] + a[4], a[1] * b[4] + a[3] * b[5] + a[5])

def _tf(s):
    m = (1, 0, 0, 1, 0, 0)
    for name, args in re.findall(r'(\w+)\s*\(([^)]*)\)', s or ''):
        v = [float(x) for x in _NUM.findall(args)]
        if name == 'matrix' and len(v) == 6: t = tuple(v)
        elif name == 'translate': t = (1, 0, 0, 1, v[0], v[1] if len(v) > 1 else 0)
        elif name == 'scale': t = (v[0], 0, 0, v[1] if len(v) > 1 else v[0], 0, 0)
        elif name == 'rotate':
            a = math.radians(v[0]); c, s_ = math.cos(a), math.sin(a); t = (c, s_, -s_, c, 0, 0)
            if len(v) == 3: t = _mul(_mul((1, 0, 0, 1, v[1], v[2]), t), (1, 0, 0, 1, -v[1], -v[2]))
        elif name == 'skewX': t = (1, 0, math.tan(math.radians(v[0])), 1, 0, 0)
        elif name == 'skewY': t = (1, math.tan(math.radians(v[0])), 0, 1, 0, 0)
        else: continue
        m = _mul(m, t)
    return m

def _arc(x1, y1, rx, ry, phi, fa, fs, x2, y2):
    """ส่วนโค้ง SVG → cubic (ไม่เกิน 90° ต่อช่วง)"""
    if rx == 0 or ry == 0: return [(x1, y1, x2, y2, x2, y2)]
    rx, ry = abs(rx), abs(ry); p = math.radians(phi); cp, sp = math.cos(p), math.sin(p)
    dx, dy = (x1 - x2) / 2, (y1 - y2) / 2; x1p, y1p = cp * dx + sp * dy, -sp * dx + cp * dy
    lam = x1p ** 2 / rx ** 2 + y1p ** 2 / ry ** 2
    if lam > 1: rx, ry = rx * math.sqrt(lam), ry * math.sqrt(lam)
    num = rx * rx * ry * ry - rx * rx * y1p * y1p - ry * ry * x1p * x1p; den = rx * rx * y1p * y1p + ry * ry * x1p * x1p
    co = math.sqrt(max(0, num / den)) if den else 0
    if fa == fs: co = -co
    cxp, cyp = co * rx * y1p / ry, -co * ry * x1p / rx
    cx, cy = cp * cxp - sp * cyp + (x1 + x2) / 2, sp * cxp + cp * cyp + (y1 + y2) / 2
    ang = lambda ux, uy, vx, vy: math.atan2(ux * vy - uy * vx, ux * vx + uy * vy)
    t1 = ang(1, 0, (x1p - cxp) / rx, (y1p - cyp) / ry); dt = ang((x1p - cxp) / rx, (y1p - cyp) / ry, (-x1p - cxp) / rx, (-y1p - cyp) / ry)
    if not fs and dt > 0: dt -= 2 * math.pi
    elif fs and dt < 0: dt += 2 * math.pi
    n = max(1, int(math.ceil(abs(dt) / (math.pi / 2) - 1e-9))); d = dt / n; k = 4 / 3 * math.tan(d / 4); out = []
    pt = lambda t: (cx + rx * math.cos(t) * cp - ry * math.sin(t) * sp, cy + rx * math.cos(t) * sp + ry * math.sin(t) * cp)
    dv = lambda t: (-rx * math.sin(t) * cp - ry * math.cos(t) * sp, -rx * math.sin(t) * sp + ry * math.cos(t) * cp)
    for i in range(n):
        a, b = t1 + i * d, t1 + (i + 1) * d; (ax, ay), (bx, by), (dax, day), (dbx, dby) = pt(a), pt(b), dv(a), dv(b)
        out.append((ax + k * dax, ay + k * day, bx - k * dbx, by - k * dby, bx, by))
    return out

def parse_d(d):
    """path d → [subpath] / subpath = [('M', x, y), ('C', x1, y1, x2, y2, x, y) ..., ('Z',)?]  ทุกเส้นเป็น cubic"""
    toks = _TOK.findall(d or ''); i = 0; out = []; cur = None; x = y = sx = sy = 0; cmd = None; lc = None
    def num():
        nonlocal i; v = float(toks[i]); i += 1; return v
    def line(nx, ny):
        cur.append(('C', x + (nx - x) / 3, y + (ny - y) / 3, x + 2 * (nx - x) / 3, y + 2 * (ny - y) / 3, nx, ny))
    while i < len(toks):
        t = toks[i]
        if t.isalpha(): cmd = t; i += 1
        elif cmd is None: raise Unsupported('path')
        c = cmd; rel = c.islower(); C = c.upper()
        if C == 'Z':
            if cur: cur.append(('Z',)); x, y = sx, sy
            cur = None; lc = None; continue
        if C == 'M':
            nx, ny = num(), num()
            if rel: nx, ny = x + nx, y + ny
            cur = [('M', nx, ny)]; out.append(cur); x, y = sx, sy = nx, ny; cmd = 'l' if rel else 'L'; lc = None; continue
        if cur is None: cur = [('M', x, y)]; out.append(cur)
        if C == 'L':
            nx, ny = num(), num()
            if rel: nx, ny = x + nx, y + ny
            line(nx, ny); x, y = nx, ny; lc = None
        elif C == 'H':
            nx = num(); nx = x + nx if rel else nx; line(nx, y); x = nx; lc = None
        elif C == 'V':
            ny = num(); ny = y + ny if rel else ny; line(x, ny); y = ny; lc = None
        elif C in 'CS':
            if C == 'C': a, b = num(), num()
            if C == 'C' and rel: a, b = x + a, y + b
            c2, d2, nx, ny = num(), num(), num(), num()
            if rel: c2, d2, nx, ny = x + c2, y + d2, x + nx, y + ny
            if C == 'S': a, b = (2 * x - lc[0], 2 * y - lc[1]) if lc and lc[2] == 'C' else (x, y)
            cur.append(('C', a, b, c2, d2, nx, ny)); lc = (c2, d2, 'C'); x, y = nx, ny
        elif C in 'QT':
            if C == 'Q':
                qx, qy = num(), num()
                if rel: qx, qy = x + qx, y + qy
            else: qx, qy = (2 * x - lc[0], 2 * y - lc[1]) if lc and lc[2] == 'Q' else (x, y)
            nx, ny = num(), num()
            if rel: nx, ny = x + nx, y + ny
            cur.append(('C', x + 2 / 3 * (qx - x), y + 2 / 3 * (qy - y), nx + 2 / 3 * (qx - nx), ny + 2 / 3 * (qy - ny), nx, ny)); lc = (qx, qy, 'Q'); x, y = nx, ny
        elif C == 'A':
            rx, ry, ph = num(), num(), num()
            fl = toks[i]
            if len(fl) > 1 and fl[0] in '01' and fl[1] in '01':   # ธงติดกัน "a1 1 0 011 1" (มีในบางชุด)
                fa, fs = int(fl[0]), int(fl[1]); rest = fl[2:]; i += 1
                if rest: toks.insert(i, rest)
            else:
                fa = int(num())
                fl = toks[i]
                if len(fl) > 1 and fl[0] in '01' and fl[1] not in 'eE.': fs = int(fl[0]); toks[i] = fl[1:]
                else: fs = int(num())
            nx, ny = num(), num()
            if rel: nx, ny = x + nx, y + ny
            for seg in _arc(x, y, rx, ry, ph, fa, fs, nx, ny): cur.append(('C',) + seg)
            x, y = nx, ny; lc = None
        else: raise Unsupported('cmd ' + c)
    return [s for s in out if len(s) > 1]

def _ellipse(cx, cy, rx, ry):
    k = 0.5522847498
    return [[('M', cx + rx, cy), ('C', cx + rx, cy + k * ry, cx + k * rx, cy + ry, cx, cy + ry), ('C', cx - k * rx, cy + ry, cx - rx, cy + k * ry, cx - rx, cy),
             ('C', cx - rx, cy - k * ry, cx - k * rx, cy - ry, cx, cy - ry), ('C', cx + k * rx, cy - ry, cx + rx, cy - k * ry, cx + rx, cy), ('Z',)]]

def _rect(x, y, w, h, rx, ry):
    if not rx and not ry: return parse_d('M%s %sh%sv%sh%sz' % (x, y, w, h, -w))
    rx = min(rx or ry, w / 2); ry = min(ry or rx, h / 2)
    return parse_d(f'M{x + rx} {y}H{x + w - rx}A{rx} {ry} 0 0 1 {x + w} {y + ry}V{y + h - ry}A{rx} {ry} 0 0 1 {x + w - rx} {y + h}H{x + rx}A{rx} {ry} 0 0 1 {x} {y + h - ry}V{y + ry}A{rx} {ry} 0 0 1 {x + rx} {y}Z')

def _f(v, d=0.0):
    try: return float(_NUM.match(str(v).strip()).group(0))
    except Exception: return d

INH = ('fill', 'stroke', 'stroke-width', 'fill-opacity', 'stroke-opacity', 'fill-rule', 'stroke-linecap', 'stroke-linejoin', 'stroke-dasharray')
BAD = ('clipPath', 'filter', 'image', 'text', 'pattern', 'linearGradient', 'radialGradient', 'foreignObject', 'marker', 'switch', 'symbol')

def _attrs(e):
    a = {k.split('}')[-1]: v for k, v in e.attrib.items()}
    for kv in (a.pop('style', '') or '').split(';'):
        if ':' in kv: k, v = kv.split(':', 1); a[k.strip()] = v.strip()
    return a

def parse(svg):
    """SVG ทั้งไฟล์ → (viewBox, [รายการที่วาด]) รายการ = dict(sub, fill, stroke, sw, fa, sa, rule, cap, join, dash, tone)
    ของที่แปลงเป็นรูปทรงไม่ได้ (ไล่สี mask ที่ตัดทะลุ clipPath ฟิลเตอร์ รูป ตัวอักษร use) → Unsupported"""
    try: root = ET.fromstring(svg)
    except ET.ParseError as e: raise Unsupported('xml')
    vb = [_f(x) for x in (root.get('viewBox') or '').replace(',', ' ').split()]
    if len(vb) != 4: vb = [0, 0, _f(root.get('width'), 24), _f(root.get('height'), 24)]
    ids = {e.get('id'): e for e in root.iter() if e.get('id')}
    out = []
    def walk(e, st, m, op, tone):
        tag = e.tag.split('}')[-1]
        if tag in BAD: raise Unsupported(tag)
        if tag in ('defs', 'title', 'desc', 'metadata', 'mask', 'style'): return
        a = _attrs(e); st = dict(st)
        for k in INH:
            if k in a: st[k] = a[k]
        if 'clip-path' in a or 'filter' in a: raise Unsupported('clip')
        m = _mul(m, _tf(a.get('transform'))); op = op * _f(a.get('opacity', 1), 1)
        if tag == 'use':                                    # <use href="#id"> = ชิ้นใน defs ที่ตำแหน่ง x y
            ref = ids.get((a.get('href') or '').lstrip('#'))
            if ref is None or ref.tag.split('}')[-1] in ('symbol', 'svg'): raise Unsupported('use')
            m = _mul(m, (1, 0, 0, 1, _f(a.get('x')), _f(a.get('y'))))
            sub_st = {k: v for k, v in st.items()}
            return walk(ref, sub_st, m, op, tone)
        if 'mask' in a:
            mk = ids.get((re.search(r'#([^)\'"]+)', a['mask']) or [None, None])[1])
            if mk is None: raise Unsupported('mask')
            col = st.get('fill', '#000')
            n0 = len(out)
            for c in mk: walk(c, {'fill': '#000'}, m, op, tone)
            for it in out[n0:]:                            # mask = ความสว่าง: ขาว = สีของชิ้นเต็ม เทา = สีเดียวกันจางลง (สีรอง) ดำ = ตัดทะลุ ทำไม่ได้
                for p, al in (('fill', 'fa'), ('stroke', 'sa')):
                    if it[p] is None: continue
                    L = _lum(it[p])
                    if L is None or L < 0.04: raise Unsupported('mask-cut')
                    it[p] = col; it[al] *= L
                    if L < 0.9: it['tone'] = 2
            return
        if tag in ('g', 'svg', 'a'):
            for c in e: walk(c, st, m, op, tone)
            return
        if tag == 'path': sub = parse_d(a.get('d', ''))
        elif tag == 'rect': sub = _rect(_f(a.get('x')), _f(a.get('y')), _f(a.get('width')), _f(a.get('height')), _f(a.get('rx')), _f(a.get('ry')))
        elif tag == 'circle': sub = _ellipse(_f(a.get('cx')), _f(a.get('cy')), _f(a.get('r')), _f(a.get('r')))
        elif tag == 'ellipse': sub = _ellipse(_f(a.get('cx')), _f(a.get('cy')), _f(a.get('rx')), _f(a.get('ry')))
        elif tag == 'line': sub = parse_d('M%s %sL%s %s' % (_f(a.get('x1')), _f(a.get('y1')), _f(a.get('x2')), _f(a.get('y2'))))
        elif tag in ('polyline', 'polygon'):
            v = _NUM.findall(a.get('points', ''))
            if len(v) < 4: return
            sub = parse_d('M' + ' '.join(v) + ('z' if tag == 'polygon' else ''))
        else: return
        if not sub: return
        fill = st.get('fill', '#000'); stroke = st.get('stroke', 'none')
        if 'url(' in str(fill) + str(stroke): raise Unsupported('gradient')
        sw = _f(st.get('stroke-width', 1), 1) * math.sqrt(abs(m[0] * m[3] - m[1] * m[2]))
        sub = [[(s[0],) + tuple(v for j in range(1, len(s), 2) for v in (m[0] * s[j] + m[2] * s[j + 1] + m[4], m[1] * s[j] + m[3] * s[j + 1] + m[5])) for s in sp] for sp in sub]
        nofill = str(fill).strip() in ('none', 'transparent'); nostroke = str(stroke).strip() in ('none', 'transparent') or sw <= 0
        if nofill and nostroke: return
        da = str(st.get('stroke-dasharray', 'none')).strip()
        out.append(dict(sub=sub, fill=None if nofill else fill.strip(), stroke=None if nostroke else stroke.strip(), sw=sw,
                        fa=op * _f(st.get('fill-opacity', 1), 1), sa=op * _f(st.get('stroke-opacity', 1), 1), rule=st.get('fill-rule', 'nonzero'),
                        cap=st.get('stroke-linecap', 'butt'), join=st.get('stroke-linejoin', 'miter'), dash=da not in ('none', '0', ''), tone=tone))
    rs = {k: v for k, v in _attrs(root).items() if k in INH}
    for c in root: walk(c, rs, (1, 0, 0, 1, 0, 0), 1.0, 1)
    if not out: raise Unsupported('empty')
    return vb, out

# ── สี ────────────────────────────────────────────────────────────────────
_NAMED = {'black': '000000', 'white': 'FFFFFF', 'red': 'FF0000', 'none': None}
def _hex(c):
    c = str(c).strip()
    if c.lower() in _NAMED: return _NAMED[c.lower()]
    if c.startswith('#'):
        h = c[1:]
        if len(h) == 3: h = ''.join(x * 2 for x in h)
        return h[:6].upper() if re.fullmatch(r'[0-9a-fA-F]{6}', h[:6]) else None
    m = re.match(r'rgb\(\s*(\d+)\D+(\d+)\D+(\d+)', c)
    return '%02X%02X%02X' % tuple(int(x) for x in m.groups()) if m else None

def _lum(c):
    h = _hex(c)
    if h is None: return None
    r, g, b = (int(h[i:i + 2], 16) / 255 for i in (0, 2, 4))
    return 0.2126 * r + 0.7152 * g + 0.0722 * b

def slots(items):
    """แต่ละสีในไอคอน → ช่อง 1 (หลัก) / 2 (รอง) / 0 (คงสีเดิม = ขาว)  currentColor = หลัก (ส่วนจาง/โทนสองของ mask = รอง)
    ไอคอนหลายสี: สีเข้มสุด = หลัก สีอื่น = รอง ขาวคงเดิม"""
    fixed = sorted({_hex(it[p]) for it in items for p in ('fill', 'stroke') if it[p] and it[p] != 'currentColor' and _hex(it[p])}, key=lambda h: _lum('#' + h))
    fixed = [h for h in fixed if _lum('#' + h) < 0.97]
    dark = fixed[0] if fixed else None
    def slot(c, al, tone):
        if c == 'currentColor': return 2 if (al < 0.95 or tone == 2) else 1
        h = _hex(c)
        if h is None or h not in fixed: return 0
        return 1 if h == dark and not any(it.get(p) == 'currentColor' for it in items for p in ('fill', 'stroke')) else 2
    return slot

def multi(items):
    """มีกี่ช่องสีที่เปลี่ยนได้ (1 = สีเดียว / 2 = สองโทนหรือหลายสี)"""
    sl = slots(items)
    return max([sl(it[p], it[a], it['tone']) for it in items for p, a in (('fill', 'fa'), ('stroke', 'sa')) if it[p]] + [1])

# ── จัดเส้นย่อยเป็นพื้นแบบ PowerPoint ─────────────────────────────────────────
def _flat(sp):
    pts = []; x = y = 0
    for s in sp:
        if s[0] == 'M': x, y = s[1], s[2]; pts.append((x, y))
        elif s[0] == 'C':
            for t in (0.25, 0.5, 0.75, 1):
                u = 1 - t; pts.append((u ** 3 * x + 3 * u * u * t * s[1] + 3 * u * t * t * s[3] + t ** 3 * s[5], u ** 3 * y + 3 * u * u * t * s[2] + 3 * u * t * t * s[4] + t ** 3 * s[6]))
            x, y = s[5], s[6]
    return pts

def _area(p): return sum(p[i][0] * p[i - 1][1] - p[i - 1][0] * p[i][1] for i in range(len(p))) / 2
def _inpoly(pt, p):
    x, y = pt; c = False; j = len(p) - 1
    for i in range(len(p)):
        (xi, yi), (xj, yj) = p[i], p[j]
        if (yi > y) != (yj > y) and x < (xj - xi) * (y - yi) / ((yj - yi) or 1e-12) + xi: c = not c
        j = i
    return c

def fill_groups(sub, rule):
    """PowerPoint ระบายพื้นเส้นย่อยใน a:path เดียวแบบคู่-คี่ ส่วน SVG ส่วนใหญ่ใช้ nonzero (เส้นทิศเดียวกันซ้อนกันยังทึบ)
    จึงแยก: ขอบนอก (ข้างในทึบ ข้างนอกโปร่ง) + รูของมัน = a:path หนึ่งอัน / เส้นที่ข้างในข้างนอกเหมือนกัน = ไม่ต้องวาด
    ponytail: ตัดสินจากจุดแรกของเส้น เส้นที่ตัดกันเองหรือแตะกันพอดีอาจผิด"""
    P = [_flat(s) for s in sub]; A = [_area(p) for p in P]; n = len(sub)
    if n == 1: return [[0]] if abs(A[0]) > 1e-9 else []
    kind = []
    for i in range(n):
        if abs(A[i]) < 1e-9: kind.append(None); continue
        pt = P[i][0]; cont = [j for j in range(n) if j != i and abs(A[j]) > 1e-9 and _inpoly(pt, P[j])]
        if rule == 'evenodd': wo = len(cont) % 2; wi = (len(cont) + 1) % 2
        else: wo = sum(1 if A[j] > 0 else -1 for j in cont); wi = wo + (1 if A[i] > 0 else -1)
        kind.append('o' if wi and not wo else 'h' if wo and not wi else None)
    outs = [i for i in range(n) if kind[i] == 'o']; grp = {i: [i] for i in outs}
    for i in range(n):
        if kind[i] != 'h': continue
        cs = [o for o in outs if _inpoly(P[i][0], P[o])]
        if cs: grp[min(cs, key=lambda o: abs(A[o]))].append(i)
    return list(grp.values())

# ── รูปทรงที่จะวาด (ใช้ทั้งไฟล์และจอ) ─────────────────────────────────────────
def shapes(svg, c=(None, None), pc=None):
    """→ (viewBox, [dict(paths=[[subpath]], fill, stroke, fa, sa, sw, cap, join, dash, name)])  สีเป็นค่าที่ลูกค้าเลือกหรือ hex เดิม"""
    vb, items = parse(svg); sl = slots(items); c1, c2 = (list(c) + [None, None])[:2]; out = []
    def col(v, al, tone):
        s = sl(v, al, tone)
        if s == 1: return (c1 or ('#' + _hex(v) if v != 'currentColor' and _hex(v) else '#15151A')), al
        if s == 2:
            if c2: return c2, 1.0
            return (c1 if v == 'currentColor' else '#' + _hex(v)) or '#15151A', al
        return ('#' + _hex(v)) if _hex(v) else '#000000', al
    for it in items:
        if it['fill']:
            f, fa = col(it['fill'], it['fa'], it['tone'])
            for g in fill_groups(it['sub'], it['rule']):
                out.append(dict(paths=[it['sub'][i] for i in g], fill=f, fa=fa, stroke=None))
        if it['stroke']:
            s, sa = col(it['stroke'], it['sa'], it['tone'])
            out.append(dict(paths=it['sub'], fill=None, stroke=s, sa=sa, sw=it['sw'], cap=it['cap'], join=it['join'], dash=it['dash']))
    return vb, _merge(out)

def _merge(out):
    """ชิ้นติดกันที่สี/เส้นเหมือนกัน รวมเป็นรูปทรงเดียว (หลาย a:path) ไฟล์เล็กลง เลือกเปลี่ยนสีใน PowerPoint ได้ทีเดียว"""
    res = []
    key = lambda o: (o['fill'], o.get('fa'), o['stroke'], o.get('sa'), round(o.get('sw', 0), 3), o.get('cap'), o.get('join'), o.get('dash'))
    for o in out:
        if res and key(res[-1]) == key(o):
            if o['fill']: res[-1]['groups'].append(o['paths'])
            else: res[-1]['groups'][0] = res[-1]['groups'][0] + o['paths']
        else: res.append({**o, 'groups': [o['paths']]})
    return res

def map_shapes(pc=None, base='#DCDDE4', line='#FFFFFF'):
    """แผนที่ไทย: จังหวัดละรูปทรง (ชื่อไทย) สีตาม pc[iso] ไม่มี = เทาอ่อน  ทะเลสาบสงขลา = ขาว"""
    root = ET.parse(MAPF).getroot(); vb = [_f(x) for x in root.get('viewBox').split()]; out = []
    for e in root.iter():
        if e.tag.split('}')[-1] != 'path': continue
        iso = e.get('data-iso') or ''; sub = parse_d(e.get('d'))
        f = (pc or {}).get(iso) or ('#FFFFFF' if not iso else base)
        out.append(dict(groups=[sub], fill=f, fa=1, stroke=line, sa=1, sw=1.0, cap='round', join='round', dash=False, name=e.get('data-th') or e.get('id'), iso=iso))
    return vb, out

# ── ไฟล์ PowerPoint ──────────────────────────────────────────────────────────
A_NS = 'http://schemas.openxmlformats.org/drawingml/2006/main'; P_NS = 'http://schemas.openxmlformats.org/presentationml/2006/main'
R_NS = 'http://schemas.openxmlformats.org/officeDocument/2006/relationships'
def _clr(c, al, colx):
    kind, val = colx(c); a = '' if al >= 0.999 else '<a:alpha val="%d"/>' % int(round(max(0, min(1, al)) * 100000))
    return '<a:%s val="%s">%s</a:%s>' % (kind, val, a, kind)

def _pathxml(sub, vb, S, fill, stroke):
    vx, vy, vw, vh = vb; P = lambda x, y: '<a:pt x="%d" y="%d"/>' % (round((x - vx) * S), round((y - vy) * S)); o = []
    for sp in sub:
        for s in sp:
            if s[0] == 'M': o.append('<a:moveTo>%s</a:moveTo>' % P(s[1], s[2]))
            elif s[0] == 'C': o.append('<a:cubicBezTo>%s%s%s</a:cubicBezTo>' % (P(s[1], s[2]), P(s[3], s[4]), P(s[5], s[6])))
            else: o.append('<a:close/>')
    return '<a:path w="%d" h="%d"%s%s>%s</a:path>' % (round(vw * S), round(vh * S), '' if fill else ' fill="none"', '' if stroke else ' stroke="0"', ''.join(o))

CAP = {'round': 'rnd', 'square': 'sq', 'butt': 'flat'}
def _spxml(sid, name, o, vb, box, colx):
    x, y, w, h = box; S = 100000 / max(vb[2], vb[3]); fill, stroke = o['fill'], o['stroke']
    paths = ''.join(_pathxml(g, vb, S, fill, stroke) for g in o['groups'])
    fx = '<a:solidFill>%s</a:solidFill>' % _clr(fill, o.get('fa', 1), colx) if fill else '<a:noFill/>'
    if stroke:
        lw = int(round(o['sw'] * w / vb[2]))            # ความหนาเส้นตามขนาดที่วาง (PowerPoint ไม่ย่อเส้นตามรูปทรง)
        j = {'round': '<a:round/>', 'bevel': '<a:bevel/>'}.get(o.get('join'), '<a:miter lim="800000"/>')
        ln = '<a:ln w="%d" cap="%s"><a:solidFill>%s</a:solidFill>%s%s</a:ln>' % (max(lw, 3175), CAP.get(o.get('cap'), 'flat'), _clr(stroke, o.get('sa', 1), colx), '<a:prstDash val="dash"/>' if o.get('dash') else '', j)
    else: ln = '<a:ln><a:noFill/></a:ln>'
    return ('<p:sp><p:nvSpPr><p:cNvPr id="%d" name="%s"/><p:cNvSpPr/><p:nvPr/></p:nvSpPr><p:spPr><a:xfrm><a:off x="%d" y="%d"/><a:ext cx="%d" cy="%d"/></a:xfrm>'
            '<a:custGeom><a:avLst/><a:gdLst/><a:ahLst/><a:cxnLst/><a:rect l="0" t="0" r="r" b="b"/><a:pathLst>%s</a:pathLst></a:custGeom>%s%s</p:spPr></p:sp>') % (sid, _esc(name), x, y, w, h, paths, fx, ln)

def _esc(t): return str(t).replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;').replace('"', '&quot;')

def add_group(slide, name, vb, shs, box, colx):
    """กลุ่มรูปทรง custGeom ชื่อ name ที่กรอบ box (EMU) ต่อท้าย spTree (= บนสุด) คืน element"""
    from pptx.oxml import parse_xml
    sid = slide.shapes._next_shape_id; x, y, w, h = box
    kids = ''.join(_spxml(sid + 1 + i, o.get('name') or ('%s %d' % (name, i + 1)), o, vb, box, colx) for i, o in enumerate(shs))
    xml = ('<p:grpSp xmlns:p="%s" xmlns:a="%s"><p:nvGrpSpPr><p:cNvPr id="%d" name="%s"/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr><p:grpSpPr><a:xfrm>'
           '<a:off x="%d" y="%d"/><a:ext cx="%d" cy="%d"/><a:chOff x="%d" y="%d"/><a:chExt cx="%d" cy="%d"/></a:xfrm></p:grpSpPr>%s</p:grpSp>') % (P_NS, A_NS, sid, _esc(name), x, y, w, h, x, y, w, h, kids)
    el = parse_xml(xml); slide.shapes._spTree.insert_element_before(el, 'p:extLst'); return el

# ── ภาพบนจอ (SVG จากรูปทรงชุดเดียวกับไฟล์) ───────────────────────────────────
def _d(sub):
    o = []
    for sp in sub:
        for s in sp:
            o.append('M%.2f %.2f' % s[1:3] if s[0] == 'M' else 'C%.2f %.2f %.2f %.2f %.2f %.2f' % s[1:] if s[0] == 'C' else 'Z')
    return ''.join(o)

def svg_of(vb, shs, hexof, ids=False):
    """รูปทรงเดียวกับในไฟล์ → SVG (พื้น = evenodd ทีละ a:path เหมือน PowerPoint / เส้น = ความหนาตาม viewBox)"""
    o = []
    for sh in shs:
        ext = ' data-iso="%s"' % sh['iso'] if ids and sh.get('iso') else ''
        if sh['fill']:
            f = ' fill="#%s"%s' % (hexof(sh['fill']), '' if sh.get('fa', 1) >= 0.999 else ' fill-opacity="%.3f"' % sh['fa'])
            st = ' stroke="#%s" stroke-width="%.3f" stroke-linejoin="round"' % (hexof(sh['stroke']), sh['sw']) if sh.get('stroke') else ''
            o.extend('<path fill-rule="evenodd"%s%s%s d="%s"/>' % (f, st, ext, _d(g)) for g in sh['groups'])
        else:
            o.append('<path fill="none" stroke="#%s"%s stroke-width="%.3f" stroke-linecap="%s" stroke-linejoin="%s"%s d="%s"/>' % (
                hexof(sh['stroke']), '' if sh.get('sa', 1) >= 0.999 else ' stroke-opacity="%.3f"' % sh['sa'], sh['sw'], sh.get('cap') or 'butt',
                sh.get('join') or 'miter', ' stroke-dasharray="%.2f %.2f"' % (sh['sw'] * 2, sh['sw'] * 2) if sh.get('dash') else '', _d(sh['groups'][0])))
    return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="%g %g %g %g" preserveAspectRatio="none" style="display:block;width:100%%;height:100%%;overflow:visible">%s</svg>' % (*vb, ''.join(o))

def check(svg):
    """เว็บถามก่อนวาง: 'vec' = เป็นรูปทรงได้ (+ จำนวนช่องสี) / 'pic:<เหตุ>' = ลงเป็นรูป SVG + PNG"""
    try: vb, items = parse(svg); return 'vec%d' % multi(items)
    except Unsupported as e: return 'pic:' + str(e)
    except Exception as e: return 'pic:err'

def credits(d):
    """บรรทัดเครดิตของชุด CC BY ที่อยู่บนหน้านี้ (ตามลำดับ ไม่ซ้ำ)"""
    out = []
    for o in d.get('add') or []:
        el = (o or {}).get('el') or {}; k = CCSET.get(el.get('set') or '')
        if k and CCBY[k] not in out: out.append(CCBY[k])
    return out

if __name__ == '__main__':                            # python3 d2s_el.py = ตรวจตัวเองเร็ว ๆ
    assert len(parse_d('M0 0h10v10h-10z')[0]) == 5
    assert fill_groups(parse_d('M0 0h10v10H0zM2 2v6h6V2z'), 'nonzero') == [[0, 1]]       # รูกลับทิศ = รู
    assert fill_groups(parse_d('M0 0h10v10H0zM2 2h6v6H2z'), 'nonzero') == [[0]]          # ทิศเดียวกัน nonzero = ทึบ (ไม่วาดเส้นใน)
    assert fill_groups(parse_d('M0 0h10v10H0zM2 2h6v6H2z'), 'evenodd') == [[0, 1]]
    vb, sh = shapes('<svg viewBox="0 0 24 24"><path fill="currentColor" d="M2 2h20v20H2z" opacity=".2"/><path fill="currentColor" d="M4 4h4v4H4z"/></svg>', ('T:primary', '#FF0000'))
    assert [s['fill'] for s in sh] == ['#FF0000', 'T:primary'], sh
    assert check('<svg viewBox="0 0 2 2"><defs><linearGradient id="a"/></defs><path fill="url(#a)" d="M0 0h2v2z"/></svg>').startswith('pic')
    print('ok')
