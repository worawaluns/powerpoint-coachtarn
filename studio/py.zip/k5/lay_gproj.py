"""20 เลย์เอาต์ชุด Project Summary — ลอกโครงจากเทมเพลตเขียวเข้ม + ส้ม

พื้นขาว บล็อกเขียวเข้มกับส้มสดตัดมุมฉาก ของตกแต่งเป็นรูปทรงเรขาคณิตแบน:
วงกลมผ่าครึ่ง/ผ่าสี่ สี่เหลี่ยมด้านขนานเรียงเป็นตาหมากรุก ดอกจัน และข้าวหลามตัดสี่เม็ด
แถบหัวกระดาษเป็นข้อความเล็กคั่นจุดสี ปีอยู่มุมขวา
ตัวหนังสือบนส้มใช้สีเข้มเสมอ (ขาวบนส้มวัดได้ 3.35 ไม่ผ่าน)
"""
from eng import *
import eng
from lay import L, reg

txt = txt_big        # ขนาดขั้นต่ำตามชุด 366 ดู eng.roomy()
chart = chart_big
from pptx.enum.chart import XL_LABEL_POSITION

M = 0.62
NAV = ['บริษัทของคุณ', 'โครงการ', 'สรุปผล', 'นำเสนอ']


def G(): return P['acc']
def O(): return P['acc2']
def PALE(): return 'DDEFE5'          # เนื้อความบนเขียว


def _duo():
    return f"duo:{mix(P['ink'], P['acc'], 0.55)}:{mix('FFFFFF', P['acc'], 0.10)}"


def _top(s, d, light=False, yr=True):
    c = 'FFFFFF' if light else P['mute']
    x = M
    for i, t in enumerate(NAV):
        shp(s, 'oval', x, 0.43, 0.08, 0.08, O() if i % 2 == 0 else (PALE() if light else G()))
        txt(s, x + 0.16, 0.33, 2.0, 0.28, t, 9, c, 'md' if i == 0 else 'rg')
        x += 0.16 + len(t) * 0.068 + 0.22
    if yr:
        txt(s, W - M - 1.2, 0.33, 0.95, 0.28, d.get('yr', '2570'), 9, c, 'md', 'r')
        shp(s, 'oval', W - M - 0.10, 0.43, 0.08, 0.08, PALE() if light else G())


def _h(s, x, y, t, sz=40, w=7.0, c=None, al='l'):
    txt(s, x, y, w, 2.4, t, sz, c or P['ink'], 'md', al, sp=1.06)


def _p(s, x, y, w, t, sz=11, c=None, al='l'):
    if t: txt(s, x, y, w, 2.0, t, sz, c or mix('FFFFFF', P['ink'], 0.80), 'rg', al, sp=1.38)


def _k(s, x, y, t, c=None):
    if t: txt(s, x, y, 5.0, 0.28, t, 10.5, c or O(), 'md', track=1.0)


def _photo(s, n, x, y, w, h, d=None, focus=(0.5, 0.45), topic=None):
    pic(s, ph(topic or (d or {}).get('topic', 'office'), n), x, y, w, h, focus=focus, mode=_duo())


def _tag(s, x, y, t, orange=True, sz=11.5, w=None):
    w = w or len(t) * 0.105 + 0.44
    shp(s, 'rect', x, y, w, 0.40, O() if orange else G())
    txt(s, x, y, w, 0.40, t, sz, P['ink'] if orange else 'FFFFFF', 'md', 'c', 'm')
    return w


# ── รูปทรงตกแต่ง ────────────────────────────────────────────────────────────
QUAD = {'br': (0, 90), 'bl': (90, 180), 'tl': (180, 270), 'tr': (270, 0)}
HALF = {'b': (0, 180), 'l': (90, 270), 't': (180, 0), 'r': (270, 90)}


def _pie(s, cx, cy, r, ang, fill):
    a, b = ang
    shp(s, 'pie', cx - r, cy - r, r * 2, r * 2, fill, adj=[a * 0.6, b * 0.6])


def _quad(s, cx, cy, r, q, fill=None): _pie(s, cx, cy, r, QUAD[q], fill or O())


def _half(s, cx, cy, r, side, fill=None): _pie(s, cx, cy, r, HALF[side], fill or O())


def _aster(s, cx, cy, sz, c=None):
    c = c or G()
    for rot in (0, 60, 120):
        shp(s, 'round', cx - sz * 0.11, cy - sz / 2, sz * 0.22, sz, c, adj=0.5, rot=rot)


def _dia4(s, cx, cy, d, c=None):
    c = c or O()
    for dx, dy in ((0, -1), (-1, 0), (1, 0), (0, 1)):
        shp(s, 'diamond', cx + dx * d * 0.52 - d / 2, cy + dy * d * 0.52 - d / 2, d, d, c)


def _checker(s, x, y, n, w, h, c=None, rows=2):
    c = c or O()
    for r in range(rows):
        for i in range(n):
            if (i + r) % 2: continue
            shp(s, 'para', x + i * w * 0.86, y + r * h, w, h, c, adj=0.30)


def _flower(s, cx, cy, r=0.16, c='FFFFFF'):
    for dx, dy in ((-1, -1), (1, -1), (-1, 1), (1, 1)):
        shp(s, 'oval', cx + dx * r - r, cy + dy * r - r, r * 2, r * 2, c)


def _monitor(s, x, y, w, n, d):
    h = w * 0.60
    shp(s, 'round', x, y, w, h, '161616', adj=0.03, shadow=('000000', 0.30, 18, 8))
    _photo(s, n, x + 0.10, y + 0.10, w - 0.20, h - 0.36, d)
    shp(s, 'round', x, y + h - 0.30, w, 0.40, 'D7DAD6', adj=0.20)
    shp(s, 'oval', x + w / 2 - 0.05, y + h - 0.15, 0.10, 0.10, '9AA09B')
    shp(s, 'rect', x + w / 2 - 0.42, y + h + 0.10, 0.84, 0.62, grad=('C9CDC8', 'EEF0EC', 0))
    shp(s, 'round', x + w / 2 - 0.80, y + h + 0.68, 1.60, 0.14, 'C9CDC8', adj=0.5)


# ══ เลย์เอาต์ตามรูปอ้างอิง ═════════════════════════════════════════════════

@reg
def gp_cover(prs, d):
    s = page(prs)
    shp(s, 'rect', 0, 0, 4.70, H, G())
    _quad(s, 0, 1.30, 1.30, 'br')
    _half(s, 2.30, H, 1.70, 't')
    shp(s, 'rect', 3.20, 4.70, 1.50, 1.10, O())
    _quad(s, 3.20, 4.70, 1.10, 'tr', G())
    _top(s, d, True, yr=False)
    txt(s, W - M - 1.2, 0.33, 0.95, 0.28, d.get('yr', '2570'), 9, P['mute'], 'md', 'r')
    shp(s, 'oval', W - M - 0.10, 0.43, 0.08, 0.08, G())
    _monitor(s, 0.80, 1.35, 4.80, d.get('pi', 4), d)
    _aster(s, 5.75, 1.45, 0.62)
    _h(s, 6.30, 1.25, d['t'], 44, 6.6)
    shp(s, 'rect', 6.20, 3.00, d.get('hlw', 4.4), 1.02, O())
    txt(s, 6.36, 3.00, d.get('hlw', 4.4) - 0.3, 1.02, d['hl'], 44, P['ink'], 'md', an='m')
    shp(s, 'rect', 6.30, 4.24, 5.70, 0.52, G())
    txt(s, 6.30, 4.24, 5.70, 0.52, d['s'], 13, 'FFFFFF', 'md', 'c', 'm')
    _dia4(s, 12.20, 4.30, 0.42)
    _p(s, 6.30, 5.30, 5.6, d.get('by', ''), 11, P['mute'])


@reg
def gp_agenda(prs, d):
    s = page(prs)
    shp(s, 'rect', 4.90, 0, W - 4.90, 1.62, G())
    _checker(s, 5.20, 0.22, 9, 0.95, 0.58)
    _photo(s, d.get('pi', 0), 0, 0.95, 4.50, 3.10, d)
    _top(s, d, yr=False)
    _h(s, M, 4.35, d['t'], 40, 4.2)
    _aster(s, 3.95, 6.40, 0.70)
    for i, (tag, body) in enumerate(d['items'][:4]):
        x = 5.55 + (i % 2) * 3.75
        y = 2.25 + (i // 2) * 2.25
        _tag(s, x, y, tag, i in (0, 3))
        _p(s, x, y + 0.58, 3.30, body, 11)


@reg
def gp_goals_photo(prs, d):
    s = page(prs)
    _top(s, d)
    _h(s, M, 0.95, d['t'], 40, 6.4)
    ln(s, 7.10, 1.40, 7.90, 1.40, G(), 1.5)
    _p(s, 8.20, 1.00, 4.50, d.get('note', ''), 11)
    shp(s, 'rect', 0, 4.20, W, H - 4.20, G())
    _half(s, 0, 5.55, 1.15, 'r')
    _half(s, W, 5.55, 1.15, 'l')
    _checker(s, 1.30, 3.10, 3, 0.55, 0.30, rows=1)
    _photo(s, d.get('pi', 9), 1.45, 3.55, W - 2.90, 3.35, d, focus=(0.5, 0.40))


@reg
def gp_three_photos(prs, d):
    s = page(prs)
    shp(s, 'rect', 10.20, 0, W - 10.20, 1.95, G())
    _quad(s, 10.20, 1.95, 1.30, 'tr')
    _quad(s, W, 0, 1.30, 'bl')
    _top(s, d, yr=False)
    _h(s, M, 0.95, d['t'], 38, 9.3)
    cw = (W - M * 2 - 0.50) / 3
    for i, (n, goal, res) in enumerate(d['items'][:3]):
        x = M + i * (cw + 0.25)
        _photo(s, n, x, 2.30, cw, 2.55, d)
        shp(s, 'rect', x, 4.95, cw, 0.66, G())
        txt(s, x + 0.20, 4.95, cw - 0.40, 0.66, goal, 12.5, 'FFFFFF', 'md', an='m')
        shp(s, 'rect', x, 5.68, cw, 0.66, O())
        txt(s, x + 0.20, 5.68, cw - 0.40, 0.66, res, 12.5, P['ink'], 'md', an='m')
    _p(s, M, 6.60, 11.5, d.get('note', ''), 10.5, P['mute'])


@reg
def gp_progress(prs, d):
    s = page(prs)
    _top(s, d)
    _photo(s, d.get('pi', 13), M, 0.95, 4.20, 3.70, d)
    for i, (v, lab, body) in enumerate(d['items'][:2]):
        x = 5.05 + i * 3.92
        f = G() if i == 0 else O()
        hc = 'FFFFFF' if i == 0 else P['ink']
        bc = PALE() if i == 0 else P['ink']
        shp(s, 'rect', x, 0.95, 3.66, 3.70, f)
        txt(s, x, 1.20, 3.66, 0.90, v, 44, hc, 'md', 'c')
        ln(s, x + 1.83, 2.20, x + 1.83, 2.80, hc, 1.2)
        txt(s, x + 0.30, 2.95, 3.06, 0.34, lab, 13, hc, 'md', 'c')
        _p(s, x + 0.35, 3.36, 2.96, body, 10.5, bc, 'c')
    _checker(s, -0.30, 5.05, 5, 0.95, 0.80, rows=3)
    _h(s, 4.40, 5.25, d['t'], 42, 8.5)


@reg
def gp_value(prs, d):
    s = page(prs)
    _photo(s, d.get('pi', 2), 0, 0, 4.90, H, d)
    _quad(s, 0, H, 1.55, 'tr')
    _half(s, 3.50, H, 0.80, 't', G())
    shp(s, 'rect', W - 2.40, 0, 2.40, 1.20, O())
    _quad(s, W - 2.40, 0, 1.20, 'br', G())
    _quad(s, W - 1.20, 1.20, 1.20, 'tr', O())
    _top_x = 5.50
    txt(s, _top_x, 0.33, 4.0, 0.28, 'บริษัทของคุณ · สรุปผลโครงการ', 9, P['mute'], 'md')
    _dia4(s, 5.85, 1.70, 0.36, G())
    _k(s, 5.50, 2.45, d.get('k', ''))
    _h(s, 5.50, 2.80, d['t'], 40, 7.2)
    _p(s, 5.50, 4.55, 6.6, d.get('note', ''), 11.5)


@reg
def gp_org_value(prs, d):
    s = page(prs)
    shp(s, 'rect', 0, 0, W, 3.70, G())
    for i in range(4):
        _half(s, 1.6 + i * 3.4, 0, 1.15, 'b', 'FFFFFF')   # แถบหัวกระดาษขาวจะจมหายในครึ่งวงกลม หน้านี้จึงไม่มี
    spec = [(1.35, 2.20, 3.30, 2.70), (5.02, 1.20, 3.30, 2.70), (8.69, 2.45, 3.30, 2.70)]
    for (h_, body), (x, y, w, hh) in zip(d['items'][:3], spec):
        shp(s, 'rect', x, y, w, hh, O(), shadow=('000000', 0.14, 14, 5))
        _flower(s, x + w / 2, y + 0.62, 0.17)
        txt(s, x + 0.25, y + 1.12, w - 0.50, 0.36, h_, 14, P['ink'], 'md', 'c')
        _p(s, x + 0.30, y + 1.52, w - 0.60, body, 10.5, P['ink'], 'c')
    _aster(s, 1.20, 6.35, 0.72, O())
    _h(s, 1.85, 5.82, d['t'], 40, 10.5)


# ══ อีก 13 เลย์เอาต์ในระบบเดียวกัน ════════════════════════════════════════

@reg
def gp_timeline(prs, d):
    s = page(prs)
    _top(s, d)
    _h(s, M, 0.95, d['t'], 38, 8.0)
    _p(s, M, 1.85, 8.0, d.get('note', ''), 11)
    n = len(d['items'][:4]); cw = (W - M * 2) / n
    for i, (per, h_, body) in enumerate(d['items'][:4]):
        x = M + i * cw
        org = i % 2 == 1
        shp(s, 'pent', x, 2.95, cw + 0.05, 0.86, O() if org else G(), adj=0.30)
        txt(s, x + 0.30, 2.95, cw - 0.6, 0.86, per, 13, P['ink'] if org else 'FFFFFF', 'md', an='m')
        txt(s, x + 0.05, 4.10, cw - 0.35, 0.40, h_, 16, P['ink'], 'md')
        _p(s, x + 0.05, 4.58, cw - 0.40, body, 10.5)
    _checker(s, W - 3.30, 6.55, 4, 0.70, 0.40, rows=2)


@reg
def gp_div_green(prs, d):
    s = page(prs, G())
    for (cx, cy, q) in ((9.20, 3.75, 'tl'), (9.20, 3.75, 'br')):
        _quad(s, cx, cy, 2.30, q)
    _quad(s, 9.20, 3.75, 2.30, 'tr', 'FFFFFF')
    _quad(s, 9.20, 3.75, 2.30, 'bl', P['g1'])
    _top(s, d, True)
    _k(s, M, 2.40, d.get('k', ''), 'FFD3BF')
    _h(s, M, 2.80, d['t'], 46, 6.6, 'FFFFFF')
    _p(s, M, 5.00, 5.8, d.get('note', ''), 12, PALE())
    _aster(s, 12.30, 6.55, 0.62, O())


@reg
def gp_div_orange(prs, d):
    s = page(prs)
    _half(s, W, 3.75, 3.30, 'l')
    _half(s, W, 3.75, 1.70, 'l', G())
    _checker(s, 7.50, 6.55, 3, 0.70, 0.40, rows=2, c=G())
    _top(s, d, yr=False)
    _k(s, M, 2.30, d.get('k', ''), G())
    _h(s, M, 2.70, d['t'], 46, 7.6)
    _p(s, M, 4.90, 6.0, d.get('note', ''), 12)
    _dia4(s, 1.05, 6.55, 0.40, O())


@reg
def gp_kpi(prs, d):
    s = page(prs)
    _top(s, d)
    _h(s, M, 0.95, d['t'], 38, 8.6)
    _dia4(s, 12.25, 1.30, 0.40)
    cw = (W - M * 2 - 0.60) / 4
    for i, (v, frm, lab) in enumerate(d['items'][:4]):
        x = M + i * (cw + 0.20)
        f = G() if i % 2 == 0 else O()
        shp(s, 'rect', x, 2.40, cw, 0.16, f)
        shp(s, 'rect', x, 2.56, cw, 3.50, P['panel'])
        txt(s, x + 0.28, 2.90, cw - 0.56, 0.90, v, 36, G() if i % 2 == 0 else P['ink'], 'md')
        _tag(s, x + 0.28, 3.95, frm, i % 2 == 1, 10.5)
        _p(s, x + 0.28, 4.62, cw - 0.56, lab, 11)
    _p(s, M, 6.35, 11.5, d.get('note', ''), 10.5, P['mute'])


@reg
def gp_chart_dept(prs, d):
    s = page(prs)
    _top(s, d)
    _h(s, M, 0.95, d['t'], 36, 4.4)
    _p(s, M, 2.60, 4.0, d.get('note', ''), 11)
    for i, (v, lab) in enumerate(d['items'][:2]):
        y = 4.30 + i * 1.15
        shp(s, 'rect', M, y, 0.12, 0.92, O() if i else G())
        txt(s, M + 0.30, y - 0.04, 3.6, 0.56, v, 26, P['ink'], 'md')
        _p(s, M + 0.30, y + 0.52, 3.6, lab, 10.5, P['mute'])
    shp(s, 'rect', 5.15, 0.95, W - M - 5.15, 5.95, P['panel'])
    chart(s, 'bar', 5.35, 1.10, W - M - 5.55, 5.65, d['cats'], d['series'], [O(), G()], labels=True,
          fmt='#,##0', legend=True, gap=45, overlap=-10, sz=11, c=P['mute'])


@reg
def gp_chart_line(prs, d):
    s = page(prs)
    shp(s, 'rect', 9.30, 0, W - 9.30, H, G())
    _quad(s, W, H, 1.40, 'tl')
    _top(s, d, yr=False)
    _h(s, M, 0.95, d['t'], 36, 8.4)
    chart(s, 'line', M - 0.10, 2.05, 8.50, 4.85, d['cats'], [(d['sname'], d['vals'])], [G()], labels=True,
          fmt='0"%"', sz=10.5, c=P['mute'], lw=3, maxv=100, minv=0, lblpos=XL_LABEL_POSITION.ABOVE)
    _k(s, 9.75, 0.95, d.get('k', ''), 'FFD3BF')
    for i, (v, lab) in enumerate(d['items'][:3]):
        y = 1.45 + i * 1.62
        txt(s, 9.75, y, 3.0, 0.62, v, 30, 'FFFFFF', 'md')
        _p(s, 9.75, y + 0.66, 3.05, lab, 10.5, PALE())


@reg
def gp_table(prs, d):
    s = page(prs)
    _top(s, d)
    _h(s, M, 0.95, d['t'], 36, 9.0)
    cols = d['colw']; tw = W - M * 2; y0 = 2.30; rh = 0.70
    xs = [M]
    for f in cols[:-1]: xs.append(xs[-1] + tw * f)
    shp(s, 'rect', M, y0, tw, rh, G())
    for j, hd in enumerate(d['head']):
        txt(s, xs[j] + 0.22, y0, tw * cols[j] - 0.44, rh, hd, 12, 'FFFFFF', 'md', 'l' if j == 0 else 'c', 'm')
    for i, row in enumerate(d['rows']):
        y = y0 + rh * (i + 1)
        if i % 2: shp(s, 'rect', M, y, tw, rh, P['panel'])
        for j, cell in enumerate(row):
            last = j == len(row) - 1
            if last:
                good = d['good'][i]
                _tag(s, xs[j] + (tw * cols[j] - 1.9) / 2, y + 0.15, cell, good, 10.5, 1.9)
            else:
                txt(s, xs[j] + 0.22, y, tw * cols[j] - 0.44, rh, cell, 12, P['ink'],
                    'md' if j == 0 else 'rg', 'l' if j == 0 else 'c', 'm')
    _p(s, M, y0 + rh * (len(d['rows']) + 1) + 0.18, 11.5, d.get('note', ''), 10.5, P['mute'])


@reg
def gp_budget(prs, d):
    s = page(prs)
    _top(s, d)
    _h(s, M, 0.95, d['t'], 36, 7.0)
    cols = [G(), O(), P['g1'], mix('FFFFFF', G(), 0.45), mix('FFFFFF', O(), 0.50)]
    it = d['items'][:5]
    chart(s, 'donut', 0.55, 2.10, 4.70, 4.70, [x[0] for x in it], [('ล้านบาท', [x[1] for x in it])],
          cols, labels=False, hole=60)
    txt(s, 0.55, 4.05, 4.70, 0.60, d['big'], 28, P['ink'], 'md', 'c')
    txt(s, 0.55, 4.66, 4.70, 0.30, d['biglab'], 10.5, P['mute'], 'rg', 'c')
    for i, (lab, v, body) in enumerate(it):
        y = 2.20 + i * 0.86
        shp(s, 'rect', 5.75, y + 0.06, 0.30, 0.30, cols[i])
        txt(s, 6.25, y, 3.2, 0.36, lab, 13, P['ink'], 'md')
        _p(s, 6.25, y + 0.38, 3.6, body, 10, P['mute'])
        txt(s, 9.40, y, 1.0, 0.36, f'{v:g} ล.', 13, G(), 'md', 'r')
    shp(s, 'rect', 10.75, 2.20, W - M - 10.75, 4.20, O())
    txt(s, 10.95, 2.50, 1.60, 0.80, d['save'], 32, P['ink'], 'md')
    _p(s, 10.95, 3.40, 1.60, d['savelab'], 10.5, P['ink'])
    _dia4(s, 11.95, 5.75, 0.32, G())


@reg
def gp_quote(prs, d):
    s = page(prs)
    shp(s, 'rect', 0, 0, 4.90, H, G())
    _photo(s, d.get('pi', 10), 0.62, 1.30, 3.66, 4.20, d, focus=(d.get('fx', 0.5), 0.35))
    _quad(s, 4.90, H, 1.40, 'tl')
    _top(s, d, True, yr=False)
    icon(s, 'quote', 6.05, 1.75, 0.80, O())
    txt(s, 5.65, 2.40, 7.0, 3.0, d['t'], 23, P['ink'], 'md', sp=1.32)
    shp(s, 'rect', 5.65, 5.30, 0.70, 0.08, O())
    txt(s, 5.65, 5.52, 6.0, 0.36, d['who'], 14, P['ink'], 'md')
    _p(s, 5.65, 5.92, 6.5, d['role'], 11, P['mute'])


@reg
def gp_lessons(prs, d):
    s = page(prs)
    shp(s, 'rect', 0, 0, 4.60, H, P['panel'])
    _top(s, d, yr=False)
    _k(s, M, 1.30, d.get('k', ''), G())
    _h(s, M, 1.70, d['t'], 38, 3.8)
    _checker(s, -0.20, 6.25, 4, 0.80, 0.45, rows=2, c=G())
    for i, (ic, h_, body) in enumerate(d['items'][:3]):
        y = 1.15 + i * 1.95
        f = O() if i % 2 == 0 else G()
        shp(s, 'rect', 5.20, y, 0.96, 0.96, f)
        icon(s, ic, 5.68, y + 0.48, 0.46, P['ink'] if i % 2 == 0 else 'FFFFFF')
        txt(s, 6.50, y - 0.02, 6.2, 0.40, h_, 16, P['ink'], 'md')
        _p(s, 6.50, y + 0.46, 6.2, body, 11)


@reg
def gp_team(prs, d):
    s = page(prs)
    _top(s, d)
    _h(s, M, 0.95, d['t'], 38, 8.0)
    _aster(s, 12.30, 1.35, 0.62, O())
    cw = (W - M * 2 - 0.75) / 4
    for i, (name, role, duty, pi, fx) in enumerate(d['items'][:4]):
        x = M + i * (cw + 0.25)
        _photo(s, pi, x, 2.15, cw, 2.70, d, focus=(fx, 0.25))
        org = i % 2 == 1
        shp(s, 'rect', x, 4.85, cw, 0.62, O() if org else G())
        txt(s, x + 0.22, 4.85, cw - 0.44, 0.62, name, 13.5, P['ink'] if org else 'FFFFFF', 'md', an='m')
        txt(s, x, 5.62, cw, 0.32, role, 11.5, G(), 'md')
        _p(s, x, 5.96, cw - 0.10, duty, 10.5)


@reg
def gp_next(prs, d):
    s = page(prs)
    _k(s, M, 1.00, d.get('k', ''), G())
    _h(s, M, 1.36, d['t'], 38, 8.0)
    _half(s, W, 1.30, 1.10, 'l')
    _top(s, d, yr=False)
    cw = (W - M * 2 - 0.50) / 3
    for i, (h_, body, when) in enumerate(d['items'][:3]):
        x = M + i * (cw + 0.25)
        f = G() if i == 0 else P['panel']
        shp(s, 'rect', x, 2.75, cw, 3.30, f)
        hc = 'FFFFFF' if i == 0 else P['ink']
        txt(s, x + 0.32, 3.05, cw - 0.64, 0.80, h_, 16, hc, 'md', sp=1.15)
        _p(s, x + 0.32, 3.95, cw - 0.64, body, 11, PALE() if i == 0 else None)
        _tag(s, x + 0.32, 5.38, when, True, 10.5)
    _checker(s, M, 6.55, 6, 0.62, 0.36, rows=2, c=G())


@reg
def gp_close(prs, d):
    s = page(prs)
    shp(s, 'rect', 7.60, 0, W - 7.60, H, G())
    _quad(s, 7.60, 0, 2.20, 'br')
    _quad(s, W, H, 2.60, 'tl')
    _quad(s, W, H, 1.30, 'tl', P['g1'])
    _flower(s, 10.95, 2.90, 0.30)
    _top(s, d, yr=False)
    _h(s, M, 1.60, d['t'], 46, 6.8)
    shp(s, 'rect', M, 3.60, d.get('hlw', 3.9), 0.92, O())
    txt(s, M + 0.18, 3.60, d.get('hlw', 3.9) - 0.3, 0.92, d['hl'], 40, P['ink'], 'md', an='m')
    _p(s, M, 4.85, 6.4, d.get('note', ''), 12)
    for i, (lab, v) in enumerate(d['items'][:3]):
        x = M + i * 2.30
        txt(s, x, 6.10, 2.2, 0.28, lab, 10, P['mute'], 'rg')
        txt(s, x, 6.40, 2.2, 0.34, v, 12, P['ink'], 'md')
