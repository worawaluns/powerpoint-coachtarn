"""k5 engine: gradient-first slide kit. Layout registry L[...] — each deck picks its own sequence,
palette and font pairing so no two files share a skeleton (Ice's rule)."""
import os, sys, math, random
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, '..', 'k3'))
from base import *            # noqa: primitives (txt, shp, pic, icon, chart, table, ln, ring, mixt, new, deck, save...)
import base

W, H = 13.333, 7.5
K5 = os.path.dirname(os.path.abspath(__file__))   # base.py redefines HERE on star-import
IMG = os.path.join(K5, 'img')

# ── palettes: (bg, ink, mute, acc, acc2, grad_from, grad_to, dark?) ────────────
PAL = {
 'ink_violet':  dict(bg='0B0B14', ink='FFFFFF', mute='9A9AB5', acc='8B5CF6', acc2='C4B5FD', g1='6D28D9', g2='C084FC', dark=1, panel='15152A'),
 'ink_lime':    dict(bg='0C1110', ink='FFFFFF', mute='93A3A0', acc='B6F04A', acc2='6EE7B7', g1='3F6212', g2='BEF264', dark=1, panel='15201C'),
 'ink_teal':    dict(bg='061417', ink='FFFFFF', mute='8FA6AB', acc='2DD4BF', acc2='5EEAD4', g1='0F766E', g2='5EEAD4', dark=1, panel='0E2126'),
 'ink_amber':   dict(bg='12100B', ink='FFFFFF', mute='A9A192', acc='F59E0B', acc2='FCD34D', g1='B45309', g2='FDE68A', dark=1, panel='1E1A12'),
 'ink_blue':    dict(bg='080F20', ink='FFFFFF', mute='94A3C4', acc='3B82F6', acc2='93C5FD', g1='1D4ED8', g2='60A5FA', dark=1, panel='101A33'),
 'ink_rose':    dict(bg='150A10', ink='FFFFFF', mute='B295A4', acc='F43F5E', acc2='FDA4AF', g1='9F1239', g2='FB7185', dark=1, panel='23111A'),
 'paper_red':   dict(bg='FFFFFF', ink='140F0C', mute='7A7167', acc='E2431F', acc2='F98A38', g1='E2431F', g2='F9A03F', dark=0, panel='FBF3EE'),
 'paper_blue':  dict(bg='FFFFFF', ink='0B1220', mute='6B7A90', acc='2563EB', acc2='60A5FA', g1='1E40AF', g2='7DD3FC', dark=0, panel='F1F5FD'),
 'paper_green': dict(bg='FCFDFB', ink='0F1A14', mute='6B7A70', acc='15803D', acc2='86EFAC', g1='166534', g2='A7F3D0', dark=0, panel='EEF7F0'),
 'paper_plum':  dict(bg='FFFFFF', ink='191024', mute='7C7288', acc='7C3AED', acc2='C4B5FD', g1='5B21B6', g2='DDD6FE', dark=0, panel='F5F1FE'),
 'sand_brown':  dict(bg='FAF6F0', ink='1C1410', mute='7E7268', acc='B45309', acc2='F0B429', g1='92400E', g2='FBBF24', dark=0, panel='F2E9DC'),
 'mist_cyan':   dict(bg='F7FBFC', ink='08191F', mute='5F7885', acc='0891B2', acc2='67E8F9', g1='155E75', g2='A5F3FC', dark=0, panel='E8F5F8'),
 'slate_coral': dict(bg='0F1417', ink='FFFFFF', mute='9AA6AD', acc='FB7185', acc2='FDBA74', g1='BE123C', g2='FDBA74', dark=1, panel='192024'),
 'paper_indigo':dict(bg='FFFFFF', ink='10132B', mute='6E7391', acc='4338CA', acc2='A5B4FC', g1='312E81', g2='818CF8', dark=0, panel='F0F1FA'),
 'ink_gold':    dict(bg='0E0D0A', ink='FFFFFF', mute='A59B86', acc='D4AF37', acc2='F5E6A8', g1='8A6D1F', g2='F5D67B', dark=1, panel='1A1712'),
 'paper_teal':  dict(bg='FBFEFD', ink='062120', mute='5C7B78', acc='0D9488', acc2='99F6E4', g1='115E59', g2='5EEAD4', dark=0, panel='E9F7F5'),
 'paper_amber': dict(bg='FFFDF8', ink='1A1408', mute='7B7060', acc='D97706', acc2='FCD34D', g1='B45309', g2='FDE68A', dark=0, panel='FDF4E3'),
 'ink_cyan':    dict(bg='061018', ink='FFFFFF', mute='8DA4B5', acc='22D3EE', acc2='A5F3FC', g1='0E7490', g2='67E8F9', dark=1, panel='0D1C28'),
 'paper_rose':  dict(bg='FFFBFC', ink='230F17', mute='86707A', acc='BE123C', acc2='FDA4AF', g1='9F1239', g2='FECDD3', dark=0, panel='FDF0F3'),
 'ink_forest':  dict(bg='07120C', ink='FFFFFF', mute='8FA79A', acc='34D399', acc2='A7F3D0', g1='065F46', g2='6EE7B7', dark=1, panel='0E2018'),
 'paper_slate': dict(bg='FBFCFD', ink='0D1520', mute='64748B', acc='0F172A', acc2='38BDF8', g1='1E293B', g2='7DD3FC', dark=0, panel='EEF2F6'),
 'ink_magenta': dict(bg='120A14', ink='FFFFFF', mute='A891AC', acc='E879F9', acc2='F5D0FE', g1='86198F', g2='F0ABFC', dark=1, panel='1E1022'),
 'ink_navyorange': dict(bg='0A1222', ink='FFFFFF', mute='93A2BC', acc='FB923C', acc2='FDBA74', g1='C2410C', g2='FDBA74', dark=1, panel='121D33'),
 'paper_lilac':   dict(bg='FDFCFF', ink='1A1330', mute='766E8C', acc='6D28D9', acc2='C4B5FD', g1='4C1D95', g2='DDD6FE', dark=0, panel='F4F1FE'),
 'ink_sand':      dict(bg='14110C', ink='FFFFFF', mute='A89C87', acc='E7C27D', acc2='F6E3B8', g1='9A7B34', g2='F3DFAE', dark=1, panel='1F1A12'),
 'paper_mint':    dict(bg='FAFFFD', ink='07231A', mute='5E7C71', acc='059669', acc2='6EE7B7', g1='047857', g2='A7F3D0', dark=0, panel='E9F8F1'),
 'ink_brick':     dict(bg='170D0B', ink='FFFFFF', mute='B19089', acc='F97316', acc2='FDBA74', g1='9A3412', g2='FB923C', dark=1, panel='24120F'),
 'paper_denim':   dict(bg='FBFCFE', ink='0A1A2F', mute='5F7288', acc='1D4ED8', acc2='93C5FD', g1='1E3A8A', g2='BFDBFE', dark=0, panel='EDF2FB'),
 # ── พาเลตสด (23 ก.ย. 2026) ส้ม/เขียวมะนาว/ฟ้า ตามที่ไอซ์เลือก ห้ามโทน 700 หม่น ๆ อีก
 'sun_orange':  dict(bg='FFFDFA', ink='14100C', mute='7A7167', acc='F5751F', acc2='F9A968', g1='E05E10', g2='FDEADA', dark=0, panel='FDF1E6'),
 'lime_fresh':  dict(bg='FCFEF8', ink='121A0C', mute='6F7A66', acc='8CC63E', acc2='B6DC7E', g1='6FA62E', g2='ECF6DE', dark=0, panel='F1F8E4'),
 'sky_vivid':   dict(bg='F9FDFF', ink='06181F', mute='627985', acc='3BC4E8', acc2='87DAF0', g1='1FA8CC', g2='E2F5FC', dark=0, panel='E6F6FC'),
 'night_orange':dict(bg='141A24', ink='FFFFFF', mute='9AA3B2', acc='F5751F', acc2='F9A968', g1='E05E10', g2='F9A968', dark=1, panel='1E2530'),
 'night_lime':  dict(bg='141A24', ink='FFFFFF', mute='9AA3B2', acc='8CC63E', acc2='B6DC7E', g1='6FA62E', g2='B6DC7E', dark=1, panel='1E2530'),
 # ── คู่สีเทรนด์ 2026-2027 (ค้นมา 2 ต.ค. 2569) เน้นสนามสีเต็มใบ สด ทันสมัย
 #    ที่มา: prodesignschool Top 20 Modern Color Combinations 2026 + Envato color trends 2026
 'lime_punch':   dict(bg='9ADD00', ink='16210A', mute='3F5214', acc='16210A', acc2='C6FF5E', g1='9ADD00', g2='C6FF5E', dark=0, panel='F4FFF1'),
 'cyber_pink':   dict(bg='FF1F8A', ink='15000A', mute='7A0A3F', acc='0C0C0C', acc2='FF6EB4', g1='FF1F8A', g2='FF6EB4', dark=0, panel='FFE9F3'),
 'solar_fusion': dict(bg='FF823A', ink='241008', mute='7A3A18', acc='8030A0', acc2='FFD1E4', g1='FF823A', g2='FF6D8B', dark=0, panel='FFF1E8'),
 'ocean_deep':   dict(bg='006F87', ink='FFFFFF', mute='B6E6F2', acc='8AD9F2', acc2='E6FBFF', g1='006F87', g2='009EC2', dark=1, panel='064352'),
 'royal_prestige':dict(bg='143A75', ink='FFFFFF', mute='AFC6EC', acc='6AA2FF', acc2='BFD8FF', g1='0A1A3C', g2='6AA2FF', dark=1, panel='112648'),
 'galaxy_purple':dict(bg='7A3DE2', ink='FFFFFF', mute='D6C6FF', acc='A885FF', acc2='E8DEFF', g1='3B1C63', g2='A885FF', dark=1, panel='492784'),
 'burnt_citrus': dict(bg='E86F1B', ink='2A1406', mute='8A4512', acc='2A1406', acc2='FFC845', g1='E86F1B', g2='FFC845', dark=0, panel='FFEBCF'),
 'retro_pop':    dict(bg='128276', ink='FFFFFF', mute='B7E3DD', acc='FFCF36', acc2='FFF5C5', g1='0D5B53', g2='FFCF36', dark=1, panel='10524D'),
 'tech_violet':  dict(bg='3B1F6E', ink='FFFFFF', mute='C3B6E0', acc='B8A9D9', acc2='F8F6FF', g1='3B1F6E', g2='8A6FD4', dark=1, panel='261745'),
 'neon_dark':    dict(bg='1A1A1D', ink='FFFFFF', mute='9A9AA2', acc='B4FF39', acc2='00D4FF', g1='1A1A1D', g2='3B3B3D', dark=1, panel='26262B'),
 'rosewood':     dict(bg='8F2F42', ink='FFFFFF', mute='E7C2C8', acc='F7E5E1', acc2='FFB3A7', g1='60202A', g2='B2545B', dark=1, panel='54202C'),
 'amber_glow':   dict(bg='FFBF5E', ink='2B1B06', mute='8F6522', acc='2B1B06', acc2='FFEFD2', g1='FFBF5E', g2='FFDA9A', dark=0, panel='FFF6E6'),
 'mint_calm':    dict(bg='6AA495', ink='0B2A21', mute='2F6353', acc='CFFFEA', acc2='EFFFF8', g1='6AA495', g2='9ADBC6', dark=0, panel='EFFFF8'),
 'eggplant_hot': dict(bg='3D1E3F', ink='FFFFFF', mute='C7A8CA', acc='FF6D8B', acc2='FFD1E4', g1='3D1E3F', g2='7A3B7E', dark=1, panel='27162B'),

    # ── ชุดองค์กร: พื้นเป็นกลาง สีแบรนด์เป็นบล็อก (ลูกค้าเป็นบริษัทกับราชการ ไม่เอาฉูดฉาด) ──
    'corp_cobalt':     dict(bg='F7F8FB', ink='14161A', mute='6A6C70', acc='2C4BD8', acc2='C9D3F7', g1='223AA8', g2='2C4BD8', dark=0, panel='EBECEF'),
    'corp_navy':       dict(bg='FBFAF7', ink='14161A', mute='6C6D6E', acc='16274B', acc2='B9C4D8', g1='111E3A', g2='16274B', dark=0, panel='EEEDEB'),
    'corp_forest':     dict(bg='F6F7F3', ink='14161A', mute='6A6C6C', acc='1F4D3A', acc2='BFD4C7', g1='183C2D', g2='1F4D3A', dark=0, panel='EAEBE7'),
    'corp_olive':      dict(bg='F4F2EC', ink='14161A', mute='696A6A', acc='5A6238', acc2='D3D6BE', g1='464C2C', g2='5A6238', dark=0, panel='E8E6E0'),
    'corp_teal':       dict(bg='F4F8F8', ink='14161A', mute='696C6E', acc='14605E', acc2='B7D8D6', g1='104B49', g2='14605E', dark=0, panel='E8ECEC'),
    'corp_slate':      dict(bg='F5F6F8', ink='14161A', mute='6A6B6E', acc='3B4654', acc2='C8CDD6', g1='2E3742', g2='3B4654', dark=0, panel='E9EAEC'),
    'corp_burgundy':   dict(bg='FAF6F4', ink='14161A', mute='6B6B6D', acc='6D2435', acc2='E0C3C7', g1='551C29', g2='6D2435', dark=0, panel='EDEAE8'),
    'corp_terracotta': dict(bg='FAF6F1', ink='14161A', mute='6B6B6C', acc='AE5435', acc2='EBC9B6', g1='884229', g2='AE5435', dark=0, panel='EDEAE5'),
    'corp_mustard':    dict(bg='FAF8F2', ink='14161A', mute='6B6C6C', acc='A8761E', acc2='EBD7A6', g1='835C17', g2='A8761E', dark=0, panel='EDECE6'),
    'corp_plum':       dict(bg='F7F5FA', ink='14161A', mute='6A6B6F', acc='43305E', acc2='D2C8E2', g1='342549', g2='43305E', dark=0, panel='EBE9EE'),
    'corp_steel':      dict(bg='F5F7FA', ink='14161A', mute='6A6C6F', acc='456A92', acc2='CBD9E8', g1='365372', g2='456A92', dark=0, panel='E9EBEE'),
    'corp_moss':       dict(bg='F5F7F2', ink='14161A', mute='6A6C6C', acc='3E5E43', acc2='C7D7C7', g1='304934', g2='3E5E43', dark=0, panel='E9EBE6'),
    'corp_clay':       dict(bg='FAF7F3', ink='14161A', mute='6B6C6C', acc='A8674A', acc2='E8CFBE', g1='83503A', g2='A8674A', dark=0, panel='EDEBE7'),
    'corp_indigo':     dict(bg='F6F7FB', ink='14161A', mute='6A6C70', acc='2A3570', acc2='C6CBE4', g1='212957', g2='2A3570', dark=0, panel='EAEBEF'),
    'corp_bronze':     dict(bg='F9F7F2', ink='14161A', mute='6B6C6C', acc='8A6436', acc2='DFCFB4', g1='6C4E2A', g2='8A6436', dark=0, panel='ECEBE6'),
    'corp_pine':       dict(bg='F3F7F5', ink='14161A', mute='696C6D', acc='1C3F38', acc2='BCD2CB', g1='16312C', g2='1C3F38', dark=0, panel='E7EBE9'),
    'corp_rust':       dict(bg='FAF6F3', ink='14161A', mute='6B6B6C', acc='A4482B', acc2='E7C5B5', g1='803822', g2='A4482B', dark=0, panel='EDEAE7'),
    'corp_royal':      dict(bg='F6F8FC', ink='14161A', mute='6A6C70', acc='1E3A8A', acc2='C3CFE9', g1='172D6C', g2='1E3A8A', dark=0, panel='EAECF0'),
    'corp_ink_blue':   dict(bg='14161B', ink='FFFFFF', mute='A6A6A8', acc='5B86E5', acc2='9DB8F0', g1='4769B3', g2='5B86E5', dark=1, panel='14151A'),
    'corp_ink_green':  dict(bg='12151A', ink='FFFFFF', mute='A5A6A8', acc='4E9A6B', acc2='A8D4BA', g1='3D7853', g2='4E9A6B', dark=1, panel='121419'),
    'corp_ink_amber':  dict(bg='17161A', ink='FFFFFF', mute='A7A6A8', acc='C79A4A', acc2='E6D0A4', g1='9B783A', g2='C79A4A', dark=1, panel='161519'),
    'corp_ink_slate':  dict(bg='16181D', ink='FFFFFF', mute='A6A7A9', acc='7E93AD', acc2='BCC9D8', g1='627387', g2='7E93AD', dark=1, panel='15171C'),

    # ── ชุดสีสด ถอดสีจากพินจริงในบอร์ดของไอซ์ (V สูง S กลาง-สูง) ──
        'viv_bluelime':    dict(bg='F7F8FB', ink='14161A', mute='6A6C70', acc='2F6BFF', acc2='D4E85C', g1='2656CC', g2='2F6BFF', dark=0, panel='ECEDF0'),
    'viv_limeink':     dict(bg='FAFAF7', ink='14161A', mute='6B6D6E', acc='9FD117', acc2='2B3A12', g1='7FA712', g2='9FD117', dark=0, panel='EEEFEC'),
    'viv_cobalt':      dict(bg='F6F8FF', ink='14161A', mute='6A6C71', acc='1463FF', acc2='AFC9FF', g1='084ACC', g2='0A5CFF', dark=0, panel='EBEDF4'),
    'viv_mint':        dict(bg='F5FBF9', ink='14161A', mute='6A6D6F', acc='13C7A2', acc2='A6EEDD', g1='0E987C', g2='12BE9B', dark=0, panel='EAF0EE'),
    'viv_coral':       dict(bg='FFF8F5', ink='14161A', mute='6D6C6D', acc='F2603C', acc2='FFC6B2', g1='C24D30', g2='F2603C', dark=0, panel='F3EDEA'),
    'viv_violet':      dict(bg='F8F6FF', ink='14161A', mute='6B6B71', acc='6B4EF5', acc2='CFC4FF', g1='563EC4', g2='6B4EF5', dark=0, panel='EDEBF4'),
    'viv_teal':        dict(bg='F4FAFC', ink='14161A', mute='696D70', acc='0FA7C9', acc2='A9E3F0', g1='0C86A1', g2='0FA7C9', dark=0, panel='E9EFF1'),
    'viv_grass':       dict(bg='F6FAF4', ink='14161A', mute='6A6D6D', acc='3DC757', acc2='B5E6BC', g1='2A873B', g2='34A94A', dark=0, panel='EBEFE9'),
    'sustain_green':   dict(bg='2B564A', ink='FFFFFF', mute='A6C0B4', acc='4E8F74', acc2='D4E8DC', g1='4E8F74', g2='2B564A', dark=1, panel='FFFFFF'),
    'mkt_violet':      dict(bg='F4F3EF', ink='14143C', mute='7B7B9E', acc='4553EE', acc2='B84BE8', g1='4553EE', g2='C04AE0', dark=0, panel='E8E9FB'),
    'propo_rust':      dict(bg='E9E4DA', ink='131110', mute='8C8377', acc='BC3109', acc2='D6CEC0', g1='C8360A', g2='9E2605', dark=0, panel='DFD8CB'),
    'edtech_mint':     dict(bg='0A0A0A', ink='FFFFFF', mute='8E8E8E', acc='B8F5A8', acc2='7BD96A', g1='CDFABF', g2='8FE57C', dark=1, panel='1C1C1C'),
    'agency_cream':    dict(bg='EFE9DD', ink='1A1512', mute='8A8074', acc='C23207', acc2='D9CFBC', g1='CF3708', g2='A52705', dark=0, panel='E5DDCD'),
    'proc_ember':      dict(bg='0E0C0B', ink='FFFFFF', mute='968E88', acc='F2761E', acc2='C21A12', g1='FFA552', g2='EC5A1E', dark=1, panel='1A1614'),
    'cs_red':          dict(bg='F8F3E9', ink='2A1410', mute='6A3B2E', acc='C8290A', acc2='F9C4B9', g1='C8290A', g2='2A1410', dark=0, panel='F9C4B9'),
    'scrap_brown':     dict(bg='F6EED8', ink='4A1D16', mute='6B4A3C', acc='4A1D16', acc2='C9A646', g1='4A1D16', g2='C9A646', dark=0, panel='E2D7A6'),
    'ugc_blue':        dict(bg='DCE5F5', ink='2B3F7A', mute='5A6585', acc='4A66B8', acc2='FBF7EE', g1='2B3F7A', g2='4A66B8', dark=0, panel='FBF7EE'),
    'am_pink':         dict(bg='FBE1E7', ink='7A1E35', mute='6E4A55', acc='7A1E35', acc2='F4B9C7', g1='7A1E35', g2='F4B9C7', dark=0, panel='FFF7EC'),
    'gloss_blue':      dict(bg='F6F0E6', ink='1F2B45', mute='5E6577', acc='2F5FA8', acc2='5E8FD6', g1='14254A', g2='2F5FA8', dark=0, panel='FBF8F2'),
    'cl_yellow':       dict(bg='1C1C1C', ink='FFFFFF', mute='BDBDB8', acc='EDE321', acc2='EFEDE6', g1='1C1C1C', g2='EDE321', dark=1, panel='2A2A2A'),
    'br_red':          dict(bg='111111', ink='FFFFFF', mute='BEBEBE', acc='D0201E', acc2='F0453C', g1='111111', g2='D0201E', dark=1, panel='1E1E1E'),
    'bk_lime':         dict(bg='8C8C8A', ink='161616', mute='555553', acc='C8F03C', acc2='161616', g1='161616', g2='C8F03C', dark=0, panel='E9E9E7'),
    'bp_yellow':       dict(bg='F7F7F5', ink='1A1A1A', mute='5E5E5E', acc='F2EC0C', acc2='1E1E1E', g1='1E1E1E', g2='F2EC0C', dark=0, panel='E6E6E3'),
    'eng_blue':        dict(bg='FFFFFF', ink='121722', mute='4A5163', acc='1652E8', acc2='4A8BFF', g1='0B2E8C', g2='1652E8', dark=0, panel='F2F3F5'),
    'tb_red':          dict(bg='FFFFFF', ink='0E0B0D', mute='5B5658', acc='E0193A', acc2='D9D9D9', g1='0E0B0D', g2='4A0F1C', dark=0, panel='F2F2F2'),
    'op_orange':       dict(bg='FFFFFF', ink='2A1206', mute='6B5547', acc='FF5A0A', acc2='FFA21A', g1='FF4A00', g2='FF8A2E', dark=0, panel='F3F3F3'),
    'zw_green':        dict(bg='F2F1EC', ink='0E3B2C', mute='4A5A52', acc='0D7553', acc2='DCDD2A', g1='0A5E43', g2='0D7553', dark=0, panel='FFFFFF'),
    'proj_green':      dict(bg='FFFFFF', ink='15211B', mute='5C6B63', acc='0F6E46', acc2='EE5E24', g1='0B5A39', g2='0F6E46', dark=0, panel='F2F4F1'),
    'startup_navy':    dict(bg='EDF0F7', ink='17204A', mute='4F587A', acc='1F3FA3', acc2='4766C2', g1='1C1A52', g2='2D3A93', dark=0, panel='E1E6F2'),
    'evol_lime':       dict(bg='0A0A0A', ink='FFFFFF', mute='8E8E8E', acc='C6F94E', acc2='35D07F', g1='D8FF5E', g2='2FBF72', dark=1, panel='1A1A1A'),
    'perf_night':      dict(bg='050509', ink='FFFFFF', mute='8A8AA2', acc='2222EE', acc2='5B5BFF', g1='1414C8', g2='6A6AFF', dark=1, panel='0F0F18'),
    'tech_night':      dict(bg='07071A', ink='FFFFFF', mute='8E94BC', acc='2B4BFF', acc2='7B3FE4', g1='2B4BFF', g2='7B3FE4', dark=1, panel='101028'),
    'strat_blue':      dict(bg='FFFFFF', ink='101828', mute='79839A', acc='1A3BE8', acc2='E8EEFF', g1='1A3BE8', g2='9FB6FF', dark=0, panel='F2F5FC'),
    'town_blue':       dict(bg='FFFFFF', ink='14203A', mute='7C8798', acc='1B49F0', acc2='6FF7B0', g1='1B49F0', g2='3C6BFF', dark=0, panel='EFF5F6'),
    'pitch_lime':      dict(bg='FFFFFF', ink='101010', mute='8E8E8E', acc='DFF84B', acc2='101010', g1='DFF84B', g2='F0FCA8', dark=0, panel='F4F4F4'),
    'proc_yellow':     dict(bg='FFFFFF', ink='1A1A1A', mute='8C8C8C', acc='FFD60A', acc2='1A1A1A', g1='FFD60A', g2='FFEF9E', dark=0, panel='F5F5F5'),
    'viv_amber':       dict(bg='FFFAF2', ink='14161A', mute='6D6D6C', acc='E09112', acc2='FFD894', g1='B36E00', g2='E08A00', dark=0, panel='F3EFE7'),
    'viv_pink':        dict(bg='FFF7FA', ink='14161A', mute='6D6C6F', acc='E8417E', acc2='FFC2D6', g1='BA3465', g2='E8417E', dark=0, panel='F3ECEF'),
    'viv_indigo':      dict(bg='F7F7FD', ink='14161A', mute='6A6C70', acc='4B46D6', acc2='C4C2F3', g1='3C38AB', g2='4B46D6', dark=0, panel='ECECF2'),
    'viv_seafoam':     dict(bg='F4FBF8', ink='14161A', mute='696D6E', acc='18C77B', acc2='A9E8C9', g1='128F59', g2='16B36F', dark=0, panel='E9F0ED'),
    'viv_sky':         dict(bg='F5FAFF', ink='14161A', mute='6A6D71', acc='1E86E8', acc2='B4DBFA', g1='186BBA', g2='1E86E8', dark=0, panel='EAEFF4'),
    'viv_plumbright':  dict(bg='FBF6FD', ink='14161A', mute='6C6B70', acc='9333C9', acc2='E2C2F2', g1='7629A1', g2='9333C9', dark=0, panel='EFEBF2'),
    'viv_ink_lime':    dict(bg='15181A', ink='FFFFFF', mute='A6A7A8', acc='C3F53F', acc2='8AB32A', g1='9CC432', g2='C3F53F', dark=1, panel='141719'),
    'viv_ink_blue':    dict(bg='12151D', ink='FFFFFF', mute='A5A6A9', acc='4A84FF', acc2='A9C5FF', g1='3B6ACC', g2='4A84FF', dark=1, panel='12141C'),
    'viv_ink_mint':    dict(bg='10171A', ink='FFFFFF', mute='A4A7A8', acc='28D6AE', acc2='A4F0DD', g1='20AB8B', g2='28D6AE', dark=1, panel='101619'),
    'viv_ink_coral':   dict(bg='1A1413', ink='FFFFFF', mute='A8A6A5', acc='FF7A54', acc2='FFBBA5', g1='CC6243', g2='FF7A54', dark=1, panel='191313'),
    'viv_blue_full':   dict(bg='2250E8', ink='FFFFFF', mute='ABBCF6', acc='D9E86B', acc2='BDD0FF', g1='AEBA56', g2='D9E86B', dark=1, panel='204BD7'),
    'viv_orange_full': dict(bg='E2602E', ink='14161A', mute='5A2F21', acc='FFE0A3', acc2='7A2A0C', g1='CCB382', g2='FFE0A3', dark=0, panel='D85C2D'),
    'viv_green_full':  dict(bg='157A4E', ink='FFFFFF', mute='A6CCBC', acc='C3F53F', acc2='A6E6C4', g1='9CC432', g2='C3F53F', dark=1, panel='147149'),
    'viv_navy_full': dict(bg='1E4FD8', ink='FFFFFF', mute='AABCF0', acc='FFC93C', acc2='BBD0FF', g1='CCA130', g2='FFC93C', dark=1, panel='16317F'),
 'night_sky':   dict(bg='121A22', ink='FFFFFF', mute='94A5B2', acc='3BC4E8', acc2='87DAF0', g1='1FA8CC', g2='87DAF0', dark=1, panel='1C2733'),

    # ── คู่สีชุดใหม่ 2569: กลุ่มสดใสขายกว้าง + กลุ่มดูแพง ──
    'cobalt_butter':   dict(bg='1B48D8', ink='FFFFFF', mute='A8B9F0', acc='FFD64A', acc2='FFF0B8', g1='1436A2', g2='FFD64A', dark=1, panel='152D7F'),
    'coral_teal':      dict(bg='FF5A4E', ink='101010', mute='6B2C28', acc='0E6E6B', acc2='FFD9CE', g1='BF443A', g2='0E6E6B', dark=0, panel='FFEBEA'),
    'grape_lemon':     dict(bg='5B2BC9', ink='FFFFFF', mute='C1AEEA', acc='E8FF4D', acc2='DCCBFF', g1='442097', g2='E8FF4D', dark=1, panel='381E77'),
    'sunset_peach':    dict(bg='F2612C', ink='101010', mute='662F1B', acc='FFC9A3', acc2='2A1206', g1='B64921', g2='FFC9A3', dark=0, panel='FDECE6'),
    'aqua_navy':       dict(bg='19C2C9', ink='101010', mute='135456', acc='0B2A4A', acc2='CFF7F8', g1='139297', g2='0B2A4A', dark=0, panel='E3F8F9'),
    'blush_plum':      dict(bg='FFB7C5', ink='101010', mute='6B4F55', acc='5A1138', acc2='7A1F4F', g1='BF8994', g2='5A1138', dark=0, panel='FFF6F8'),
    'kiwi_ink':        dict(bg='B9E62E', ink='101010', mute='50611B', acc='14170F', acc2='2E3A14', g1='8BAC22', g2='14170F', dark=0, panel='F7FCE6'),
    'sky_mandarin':    dict(bg='2E9BF0', ink='101010', mute='1B4565', acc='FF7A1A', acc2='D6ECFF', g1='2274B4', g2='FF7A1A', dark=0, panel='E6F3FD'),
    'noir_gold':       dict(bg='15161A', ink='FFFFFF', mute='A6A6A8', acc='D8B45C', acc2='F0DFB4', g1='101014', g2='D8B45C', dark=1, panel='111216'),
    'emerald_ivory':   dict(bg='0A5C44', ink='FFFFFF', mute='A2C1B8', acc='E8E2D2', acc2='C8A96A', g1='084533', g2='E8E2D2', dark=1, panel='0B382E'),
    'wine_sand':       dict(bg='6E1B2E', ink='FFFFFF', mute='C8A8B0', acc='E5C9A3', acc2='C98B5E', g1='521422', g2='E5C9A3', dark=1, panel='421521'),
    'ink_pearl':       dict(bg='12182B', ink='FFFFFF', mute='A5A7AE', acc='C9D4E8', acc2='8FA6C9', g1='0E1220', g2='C9D4E8', dark=1, panel='101320'),
}
P = {}            # active palette, set by deck()

def legible_fill(c, need=4.6):
    """ดันสีแบรนด์ให้ตัวขาวหรือตัวดำอ่านออกบนบล็อกสีเต็ม โดยไม่เปลี่ยนเฉดและความอิ่มสี

    มีโซนตายกลาง ๆ ที่ทั้งตัวขาวและตัวดำวัดได้ 4.2-4.5 คือไม่ผ่านสักทาง
    เจอใน viv_bluelime (2F6BFF) และใน 28 จาก 195 พาเลตต์ที่ oldcovers สร้างจากสีเด็คเอง
    ปัญหาอยู่ที่สีพื้น ไม่ใช่สีตัวหนังสือ _fg() จึงช่วยไม่ได้ ต้องขยับ V ของสีพื้นเอง
    ขยับทีละ 1% ทั้งสองทาง เอาทางที่ขยับน้อยที่สุดและยัง V อยู่ในกรอบ 0.75-1.00 ของไอซ์
    """
    import colorsys
    if max(cratio('FFFFFF', c), cratio('101010', c)) >= need: return c
    h, s, v = colorsys.rgb_to_hsv(*[int(c[i:i + 2], 16) / 255 for i in (0, 2, 4)])
    hx = lambda vv: '%02X%02X%02X' % tuple(round(x * 255) for x in colorsys.hsv_to_rgb(h, s, vv))
    back = None
    for i in range(1, 80):
        for vv in (v - 0.01 * i, v + 0.01 * i):
            if not 0.02 < vv <= 1.0: continue
            o = hx(vv)
            if max(cratio('FFFFFF', o), cratio('101010', o)) < need: continue
            if 0.755 <= vv <= 1.0: return o         # อยู่ในกรอบ เอาเลย (เผื่อปัดเศษ hex)
            back = back or o                        # หลุดกรอบ เก็บไว้เผื่อไม่มีทางอื่น
    return back or c


def setpal(name, font='plex', head=None):
    P.clear(); P.update(PAL[name])
    P['acc'] = legible_fill(P['acc'])
    if P.get('g2') == PAL[name]['acc']: P['g2'] = P['acc']
    T.update(font=font, head=head, ink=P['ink'], mute=P['mute'], bg=P['bg'], acc=P['acc'])

def ph(topic, n):
    """photo path: pool topic + index (wraps)"""
    d = os.path.join(IMG, topic); fs = sorted(os.listdir(d))
    return os.path.join(d, fs[n % len(fs)])

# ── backgrounds / decoration ─────────────────────────────────────────────────
def page(prs, bg=None):
    return new(prs, bg or P['bg'])

def glow(s, cx, cy, r, c=None, a=0.55):
    """soft radial glow: many low-alpha ovals so no visible banding (light palettes show rings otherwise)"""
    c = c or P['acc']
    for i in range(9):
        k = 1.0 - i * 0.1
        shp(s, 'oval', cx - r * k, cy - r * k * 0.66, r * 2 * k, r * 1.32 * k, c, a=a * 0.055)

def gradband(s, x, y, w, h, ang=0, a1=1, a2=1, c1=None, c2=None, kind='rect', adj=None):
    return shp(s, kind, x, y, w, h, grad=(c1 or P['g1'], c2 or P['g2'], ang, a1, a2), adj=adj)

def grid(s, step=0.62, c=None, a=0.5, x0=0, y0=0, x1=W, y1=H, lw=0.5):
    c = c or (P['ink'] if not P['dark'] else P['acc2'])
    n = int((x1 - x0) / step)
    for i in range(n + 1):
        ln(s, x0 + i * step, y0, x0 + i * step, y1, mix(P['bg'], c, 0.12 * a), lw)
    m = int((y1 - y0) / step)
    for j in range(m + 1):
        ln(s, x0, y0 + j * step, x1, y0 + j * step, mix(P['bg'], c, 0.12 * a), lw)

def dots(s, x, y, cols, rows, step=0.22, d=0.06, c=None, a=0.9):
    c = c or P['acc']
    for r in range(rows):
        for q in range(cols):
            shp(s, 'oval', x + q * step, y + r * step, d, d, c, a=a)

def photo_wash(s, topic, n, x=0, y=0, w=W, h=H, a=0.22, tint=None, geom=None, adj=None, focus=(0.5, 0.4)):
    """photo laid under a tint panel so text stays readable (Ice: ภาพจางๆ เป็นพื้นหลัง)"""
    pic(s, ph(topic, n), x, y, w, h, geom=geom, adj=adj, focus=focus)
    shp(s, 'round' if geom == 'roundRect' else 'rect', x, y, w, h, tint or P['bg'], a=1 - a, adj=adj)

def footer(s, left, right='', c=None, y=None):
    c = c or P['mute']
    y = H - 0.52 if y is None else y
    ln(s, 0.62, y - 0.12, W - 0.62, y - 0.12, mix(P['bg'], c, 0.35), 0.5)
    txt(s, 0.62, y, 8, 0.3, left, 9.5, c, 'rg', track=0.6)
    if right: txt(s, W - 6.62, y, 6, 0.3, right, 9.5, c, 'rg', 'r', track=0.6)

def eyebrow(s, x, y, t, c=None, sz=10.5):
    c = c or P['acc']
    shp(s, 'rect', x, y + 0.12, 0.26, 0.06, c)
    txt(s, x + 0.42, y, 6, 0.3, t, sz, c, 'md', track=1.2, caps=False)

def pill(s, x, y, w, h, t, fill=None, c=None, sz=10.5, grad=None):
    if not str(t).strip(): return          # ไม่มีข้อความก็ไม่ต้องวาดแคปซูลเปล่า
    if grad: gradband(s, x, y, w, h, 0, kind='round', adj=0.5)
    else: shp(s, 'round', x, y, w, h, fill or mix(P['bg'], P['acc'], 0.16), adj=0.5)
    txt(s, x, y, w, h, t, sz, c or P['ink'], 'md', 'c', 'm')

def bignum(s, x, y, w, v, label='', sz=72, c=None, lc=None, sub=''):
    txt(s, x, y, w, sz / 60, v, sz, c or P['acc'], 'bd', sp=0.95)
    if label: txt(s, x, y + sz / 72 + 0.12, w, 0.34, label, 12, lc or P['mute'], 'md')
    if sub: txt(s, x, y + sz / 72 + 0.5, w, 0.34, sub, 10.5, P['mute'])

# ── chart helpers beyond base.chart ──────────────────────────────────────────
def waffle(s, x, y, pct, cols=10, rows=10, step=0.3, d=0.24, on=None, off=None, shape='round'):
    n = round(pct / 100 * cols * rows)
    for i in range(cols * rows):
        r, q = divmod(i, cols)
        shp(s, shape, x + q * step, y + r * step, d, d, None if False else (on or P['acc']) if i < n else (off or mix(P['bg'], P['mute'], 0.3)), adj=0.35)

def gradbars(s, x, y, w, h, vals, labels, top=None, c1=None, c2=None, gap=0.26, fmt='{}', lab_c=None, val_c=None, kind='rect', adj=None):
    n = len(vals); bw = (w - gap * (n - 1)) / n; mx = max(vals) or 1
    for i, v in enumerate(vals):
        bh = h * (v / mx); bx = x + i * (bw + gap)
        gradband(s, bx, y + h - bh, bw, bh, 90, c1=c1, c2=c2, kind=kind, adj=adj)
        txt(s, bx, y + h - bh - 0.42, bw, 0.36, fmt.format(v), 15, val_c or P['ink'], 'bd', 'c')
        txt(s, bx, y + h + 0.14, bw, 0.34, labels[i], 10.5, lab_c or P['mute'], 'rg', 'c')


def _lm(c):
    """ความสว่างสัมพัทธ์ตามสูตร WCAG"""
    f = lambda v: v / 12.92 if v <= 0.03928 else ((v + 0.055) / 1.055) ** 2.4
    r, g, b = [int(c[i:i + 2], 16) / 255 for i in (0, 2, 4)]
    return 0.2126 * f(r) + 0.7152 * f(g) + 0.0722 * f(b)

def cratio(a, b):
    l1, l2 = sorted((_lm(a), _lm(b)), reverse=True)
    return (l1 + 0.05) / (l2 + 0.05)

def tone(surf, k=0.62, need=4.9):
    """สีตัวหนังสือรองที่จางได้ แต่ห้ามจางจนอ่านไม่ออกบนพื้น surf

    เคยเขียน mix(P['bg'], P['ink'], 0.55) ตรง ๆ กระจายทั่วไฟล์ ผลคือหัวกระดาษ 8.5pt
    ตกคอนทราสต์ 16 จาก 18 ใบ และบางใบตัวหนังสือหายไปจากหน้าเลย (วัดได้ 1.03)
    ตัวนี้ไล่ k ขึ้นทีละขั้นจนผ่าน need แล้วหยุด จะได้จางที่สุดเท่าที่ยังอ่านออก
    need ตั้ง 4.9 ไม่ใช่ 4.5 เพราะมันหยุดทันทีที่ผ่าน ถ้าตั้ง 4.5 จะได้ค่าเฉียด 4.50 พอดี
    แล้วขอบตัวอักษรที่ถูก antialias ครึ่งหนึ่งวัดได้ต่ำกว่า 4.5 (ป้าย 8.5pt ใน cv_top_slab)
    """
    ink = '101010' if _lm(surf) > 0.19 else 'FFFFFF'
    while k < 0.999:
        c = mix(surf, ink, k)
        if cratio(c, surf) >= need: return c
        k += 0.05
    return ink

def surf_for(c, base, need=4.5):
    """ดันสีพื้นออกห่างจากสีตัวหนังสือ c จนอ่านออก — คู่กับ ink_on() ที่ขยับตัวหนังสือแทน

    เคสจริง: การ์ดใน cx_glass_card / cx_bento4 / cx_ticket ผสม P['bg'] เข้าหา P['ink']
    เพื่อยกการ์ดให้ลอยขึ้นจากพื้น พอเจอพาเลตต์พื้นสีเต็ม (viv_orange_full) การผสม
    เข้าหา ink ยิ่งทำให้การ์ดเข้ม หัวข้อ P['ink'] บนการ์ดวัดได้ 4.41
    ที่ต้องขยับคือพื้น ไม่ใช่ตัวหนังสือ เพราะ P['ink'] เป็นสีหลักของชุด เปลี่ยนไม่ได้
    """
    t = 'FFFFFF' if _lm(c) < 0.19 else '101010'
    k, o = 0.0, base
    while k < 0.999:
        if cratio(c, o) >= need: return o
        k += 0.06
        o = mix(base, t, k)
    return t


def ink_on(c, surf, need=4.9):
    """สีเน้นที่คงโทนเดิมไว้ แต่ดันให้อ่านออกบนพื้น surf

    เคสจริง: kicker สีม่วง acc บนพื้นส้ม bg ของ solar_fusion วัดได้ 2.30
    ดันทีละขั้นไปทาง 101010 หรือ FFFFFF ตามพื้น จนผ่าน need
    """
    if cratio(c, surf) >= need: return c
    t = '101010' if _lm(surf) > 0.19 else 'FFFFFF'
    k = 0.0
    while k < 0.999:
        k += 0.08
        o = mix(c, t, k)
        if cratio(o, surf) >= need: return o
    return t


# ── ระบบ variant: โครงเดียวกันแต่ให้หน้าตาไม่ซ้ำ ────────────────────────────
VAR = 0

def setvar(n):
    """ตั้งเลข variant ของสไลด์นี้ ตัวช่วยด้านล่างจะอ่านค่านี้เอง"""
    global VAR
    VAR = int(n)

def vch(ch, n):
    """เลขตัวเลือกของ knob ช่องที่ ch

    ต้องแยกช่องกัน ไม่งั้น knob ทุกตัวผูกกับ VAR%4 เดียวกัน พลิกซ้ายขวากับเปลี่ยน
    พื้นผิวก็จะเกิดพร้อมกันเสมอ เหลือแค่ 4 แบบต่อโครงแทนที่จะเป็น 32
    """
    return (VAR // (7 ** ch)) % n

def vpick(*opts, ch=1):
    return opts[vch(ch, len(opts))]

def mirror(s, pw=None):
    """พลิกองค์ประกอบซ้าย-ขวาทั้งสไลด์ หลังเลย์เอาต์วาดเสร็จ

    ถูกกว่าการเขียนเลย์เอาต์คู่แฝดทุกตัวมาก และได้โครงเพิ่มเท่าตัวทันที
    รูปไม่ถูกกลับด้าน เพราะย้ายแค่กล่อง ไม่ได้พลิกเนื้อภาพ
    """
    from pptx.util import Emu
    from pptx.enum.text import PP_ALIGN
    SW = Emu(int((pw or W) * 914400))
    for sh in s.shapes:
        if sh.name.startswith('add.'): continue          # doc2slide ใบ 030: กล่องที่ลูกค้าเพิ่มวางตามจอแล้ว ไม่พลิก (ตำแหน่ง/ชิดซ้ายขวา)
        try: sh.left = Emu(int(SW) - int(sh.left) - int(sh.width))
        except Exception: continue
        if sh.rotation: sh.rotation = (360 - sh.rotation) % 360
        if sh.has_text_frame:
            for p in sh.text_frame.paragraphs:
                if p.alignment == PP_ALIGN.LEFT: p.alignment = PP_ALIGN.RIGHT
                elif p.alignment == PP_ALIGN.RIGHT: p.alignment = PP_ALIGN.LEFT

_FF = {}
def _facefile(fam, wt):
    """ไฟล์ฟอนต์จริงของ family ที่ txt() จะใช้ — ไว้วัดความกว้างก่อนตัดสินว่าต้องย่อไหม"""
    key = (fam, wt)
    if key not in _FF:
        import subprocess
        from base import FONTS, T
        face, bold = FONTS[fam or T['font']][wt]
        q = face + (':bold' if bold or wt in ('bd', 'md') else '')
        try: _FF[key] = subprocess.run(['fc-match', '-f', '%{file}', q], capture_output=True, text=True, timeout=5).stdout or None
        except Exception: _FF[key] = None
    return _FF[key]

def fit_w(t, w_in, base, lo=20, wt='bd', fam=None, dpi=200):
    """เหมือน fit_sz แต่วัดจาก metric ของฟอนต์จริง — ย่อเฉพาะตอนที่ล้นกล่องจริง ๆ

    fit_sz เดาความกว้างที่ 0.58em ซึ่งย่อข้อความที่ยังพอดีอยู่ด้วย พอเอาไปใส่การ์ดตัวเลข
    ทั้งคลังเลยเล็กลงทั้งที่ไม่ได้พัง ตัวนี้คืน base เป๊ะ ๆ ถ้าไม่ล้น
    """
    t = str(t).split('\n')[0]
    f = _facefile(fam, wt)
    if not f: return fit_sz(t, w_in, base, lo)          # ไม่มีฟอนต์ให้วัด ถอยไปใช้ค่าประมาณ
    try:
        from PIL import ImageFont
        px = ImageFont.truetype(f, int(base / 72 * dpi)).getlength(t) / dpi
    except Exception:
        return fit_sz(t, w_in, base, lo)
    if px <= w_in: return base
    return max(lo, int(base * w_in * 0.97 / px))   # กันเผื่อ 3% ไม่งั้นพอดีเป๊ะแล้วตัวสุดท้ายตกบรรทัด

def fit_sz(t, w_in, base, lo=28):
    """ย่อขนาดตัวเลขใหญ่ให้พอดีกล่อง — กันเคส '4,180 ล้าน' ตกบรรทัดไปทับย่อหน้าข้างล่าง

    ความกว้างตัวอักษรไทย/ตัวเลขที่ฟอนต์นี้ ≈ 0.58em จึงได้ sz ≤ 72*w / (0.58*len)
    """
    t = str(t).split('\n')[0]
    return max(lo, min(base, int(72 * w_in / (0.58 * max(1, len(t))))))

def hbars(s, x, y, w, rows, c1=None, c2=None, rh=0.42, gap=0.28, lw=3.1, fmt='{}'):
    for i, (lab, v, mx) in enumerate(rows):
        yy = y + i * (rh + gap)
        txt(s, x, yy, lw, rh, lab, 12, P['ink'], 'md', an='m')
        track = w - lw - 1.0
        shp(s, 'round', x + lw, yy + 0.06, track, rh - 0.12, mix(P['bg'], P['mute'], 0.22), adj=0.5)
        gradband(s, x + lw, yy + 0.06, max(track * v / mx, 0.2), rh - 0.12, 0, c1=c1, c2=c2, kind='round', adj=0.5)
        txt(s, x + w - 0.95, yy, 0.95, rh, fmt.format(v), 12, P['acc'], 'bd', 'r', 'm')

def donut_ring(s, cx, cy, d, pct, label='', sub='', c=None, th=0.13, track=None):
    ring(s, cx, cy, d, pct, c or P['acc'], track or mix(P['bg'], P['mute'], 0.25), th)
    txt(s, cx - d / 2, cy - 0.34, d, 0.5, label or f'{pct}%', 26, P['ink'], 'bd', 'c', 'm')
    if sub: txt(s, cx - d / 2, cy + 0.18, d, 0.3, sub, 10, P['mute'], 'rg', 'c')

def sparkline(s, x, y, w, h, vals, c=None, dotlast=True, fill=False):
    c = c or P['acc']; mx, mn = max(vals), min(vals); rng = (mx - mn) or 1
    pts = [(x + i * w / (len(vals) - 1), y + h - (v - mn) / rng * h) for i, v in enumerate(vals)]
    for a_, b_ in zip(pts, pts[1:]): ln(s, a_[0], a_[1], b_[0], b_[1], c, 2.2)
    if dotlast: shp(s, 'oval', pts[-1][0] - 0.07, pts[-1][1] - 0.07, 0.14, 0.14, c)
    return pts

def steps_arrow(s, x, y, w, items, h=0.86, c1=None, c2=None, tc=None):
    n = len(items); sw = w / n
    for i, t in enumerate(items):
        gradband(s, x + i * sw, y, sw - 0.12, h, 0, kind='chev', adj=0.35,
                 c1=mix(c1 or P['g1'], c2 or P['g2'], i / max(n - 1, 1)), c2=mix(c1 or P['g1'], c2 or P['g2'], min((i + 1) / max(n - 1, 1), 1)))
        txt(s, x + i * sw + 0.22, y, sw - 0.5, h, t, 12, tc or 'FFFFFF', 'md', 'c', 'm')

def card(s, x, y, w, h, fill=None, line=None, adj=0.06, shadow=False):
    return shp(s, 'round', x, y, w, h, fill if fill is not None else P['panel'],
               line=line, lw=0.75, adj=adj, shadow=('000000', 0.18, 22, 8) if shadow else None)


# ── ตัวหนังสือขั้นต่ำ (7 ต.ค. 2569) ─────────────────────────────────────────
# ไอซ์ให้ชุด 366 ได้ 8/10 เรื่องขนาดตัวหนังสือ แล้วให้ปรับชุด 358-365 ตาม
# ชุดเก่าวัดได้ว่าข้อความ 26-55% ต่ำกว่า 11pt (ชุด 366 อยู่ที่ 27%)
# โมดูลที่ใช้: txt = txt_big; chart = chart_big  ต่ำกว่า 12pt ขยาย 1pt และไม่ต่ำกว่า 10.5pt
def roomy(sz):
    return max(sz + 1, 10.5) if sz < 12 else sz


def txt_big(s, x, y, w, h, t, sz=14, *a, **k):
    return txt(s, x, y, w, h, t, roomy(sz), *a, **k)


def chart_big(*a, **k):
    k['sz'] = roomy(k.get('sz', 11))
    return chart(*a, **k)
