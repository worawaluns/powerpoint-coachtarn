"""20 เลย์เอาต์ชุดครีเอทีฟสตูดิโอ แดงส้ม+ครีม+ชมพูอ่อน — ลอกโครงจากเทมเพลต Creative Studio Pitch Deck (Studio Shodwe)

หัวเรื่องหนามากตัวโตเต็มหน้า สีแดงบนครีม / ครีมบนแดง แถบป้ายเล็กบนสุดซ้าย-ขวาทุกหน้า
ป้ายในวงเล็บเหลี่ยม [ขั้นตอน] แทนเลขลำดับ ปุ่มครีมมีตัวแดง แถบแดงเต็มกว้างล่างหน้า
แดงต้นฉบับ E22F0C ได้แค่ 4.09 กับครีม จึงเข้มขึ้นเป็น C8290A (5.03) · หมึกเข้มบนชมพู 11.7
"""
from eng import *
import eng
from lay import L, reg

txt = txt_big        # ขนาดขั้นต่ำตามชุด 366 ดู eng.roomy()
chart = chart_big

M = 0.62
RED = 'C8290A'
CR = 'F8F3E9'
BL = 'F9C4B9'        # ชมพูอ่อนรอบการ์ดในรูปอ้างอิง
INK = '2A1410'
MUTE = '6A3B2E'
CARD = 'FFFBF4'


def _photo(s, n, x, y, w, h, focus=(0.5, 0.4)):
    return pic(s, ph('studio', n), x, y, w, h, focus=focus, mode="duo:5E1405:F8F3E9")


def _bar(s, d, dark=False, x0=M, x1=None, y=0.30):
    """ป้ายเล็กบนสุด ซ้าย/ขวา แบบ CREATE WITH PURPOSE · STUDIO SHODWE"""
    c = CR if dark else RED
    x1 = x1 or W - M
    txt(s, x0, y, 5.0, 0.36, d.get('_l', 'ข้อเสนอบริการ ปี 2570'), 11, c, 'bd')
    txt(s, x1 - 5.0, y, 5.0, 0.36, d.get('_r', 'ลายเส้นสตูดิโอ'), 11, c, 'bd', 'r')


def _h(s, x, y, t, sz=60, w=9.0, dark=False, al='l'):
    txt(s, x, y, w, 2.8, t, sz, CR if dark else RED, 'bd', al, sp=0.92)


def _p(s, x, y, w, t, sz=12, dark=False, c=None, al='l'):
    if t: txt(s, x, y, w, 2.0, t, sz, c or (CR if dark else INK), 'rg', al, sp=1.40)


def _tag(s, x, y, t, dark=False, w=2.2):
    txt(s, x, y, w, 0.40, f'[{t}]', 12, CR if dark else RED, 'bd')


def _pill(s, x, y, w, t, dark=True):
    shp(s, 'round', x, y, w, 0.46, CR if dark else RED, adj=0.18)
    txt(s, x + 0.18, y, w - 0.36, 0.46, t, 12, RED if dark else CR, 'bd', an='m')


def _red(prs):
    return page(prs, RED)


# ══ เลย์เอาต์ตามรูปอ้างอิง ═════════════════════════════════════════════════

@reg
def cs_cover(prs, d):
    s = page(prs, BL)
    shp(s, 'round', 0.35, 0.35, W - 0.70, H - 0.70, CR, adj=0.03)
    _bar(s, d, x0=0.85, x1=W - 0.85, y=0.58)
    _photo(s, d.get('pi', 0), 7.85, 1.00, 4.65, 5.75, (0.5, 0.35))
    _h(s, 0.85, 1.35, d['t'], 72, 8.2)
    txt(s, 0.85, 5.20, 2.6, 0.80, d['big'], 40, RED, 'bd')
    txt(s, 0.85, 5.95, 2.6, 0.40, d['biglab'], 12, RED, 'bd')
    txt(s, 3.55, 5.20, 4.0, 0.40, d['k'], 15, RED, 'bd')
    _p(s, 3.55, 5.65, 4.0, d['s'], 12, c=INK)


@reg
def cs_summary(prs, d):
    s = page(prs, CR)
    _bar(s, d)
    _h(s, M, 0.75, d['t'], 60, W - 2 * M)
    txt(s, M, 2.35, 1.6, 0.40, d.get('k', 'ใจความ'), 13, RED, 'bd')
    # เฟส D: แถวสูงตามข้อความจริง รับได้ถึง 7 ข้อ / ข้อที่มีแต่ประโยค (รายการจากเอกสาร ไม่มีป้าย) วางเป็นย่อหน้าเต็มกว้าง ไม่ยัดในป้าย [ ]
    its = d['items'][:7]; z = d.get('_big') or 0; bw = W - M - 6.10; fw = W - M - 2.40
    hs = []
    for lab, body in its:
        if body: hs.append(max(0.40, box_h(tlines(f'[{lab}]', 3.2, max(12, z), 'bd'), max(12, z)), box_h(tlines(body, bw, max(13, z)), max(13, z), 1.40)))
        else: hs.append(box_h(tlines(lab, fw, max(15, z)), max(15, z), 1.30))
    ys, rh, over = flow_ys([h + 0.34 for h in hs], 2.30, 1.62 if len(its) <= 3 else 4.65 / len(its), 7.0)
    for i, ((lab, body), y) in enumerate(zip(its, ys)):
        if body:
            txt(s, 2.40, y, eng._fitw(3.2, y + hs[i], 7.0), max(0.40, hs[i]), f'[{lab}]', 12, RED, 'bd')
            txt(s, 6.10, y, eng._fitw(bw, y + hs[i], 7.0), max(hs[i], 0.4), body, 13, INK, 'rg', sp=1.40)
        else:
            shp(s, 'rect', 2.00, y + 0.12, 0.16, 0.16, RED)
            txt(s, 2.40, y, eng._fitw(fw, y + hs[i], 7.0), hs[i], lab, 15, INK, 'rg', sp=1.30)
        if i < len(its) - 1 or not over: ln(s, 2.40, y + rh[i] - 0.32, W - M, y + rh[i] - 0.32, mix(RED, CR, 0.55), 0.8)


@reg
def cs_about(prs, d):
    s = _red(prs)
    _bar(s, d, True, x1=6.6)
    _photo(s, d.get('pi', 3), 7.10, 0, W - 7.10, 3.00, (0.5, 0.5))
    for i, (v, lab) in enumerate(d['stats'][:2]):
        x = M + i * 3.10
        txt(s, x, 0.95, 3.0, 0.95, v, 46, CR, 'bd')
        txt(s, x, 1.95, 3.0, 0.40, lab, 12, CR, 'bd')
    ln(s, 0, 3.00, W, 3.00, CR, 1.0)
    _h(s, M, 3.35, d['t'], 58, 6.2, True)
    txt(s, M, 5.55, 5.6, 0.40, d.get('k', ''), 13, CR, 'bd')
    _p(s, M, 5.95, 5.6, d.get('note', ''), 12, True)
    _pill(s, 7.40, 3.40, 2.0, d.get('pill', 'จุดเด่น'))
    for i, (lab, body) in enumerate(d['items'][:3]):
        y = 4.15 + i * 1.02
        txt(s, 7.40, y, 2.2, 0.80, lab, 14, CR, 'bd', an='m')
        _p(s, 9.70, y + 0.10, W - M - 9.70, body, 11.5, True)
        ln(s, 7.40, y + 0.92, W - M, y + 0.92, mix(CR, RED, 0.45), 0.7)


@reg
def cs_process(prs, d):
    s = page(prs, CR)
    _bar(s, d, x1=7.0)
    _photo(s, d.get('pi', 21), 7.30, 0, W - 7.30, 4.70, (0.5, 0.45))
    _h(s, M, 0.80, d['t'], 46, 6.5)
    for i, (lab, body) in enumerate(d['items'][:2]):
        y = 2.75 + i * 0.90
        _tag(s, M, y, lab, w=1.9)
        _p(s, M + 1.95, y, 4.55, body, 12)
    ln(s, 0, 4.70, W, 4.70, mix(RED, CR, 0.55), 1.0)
    _tag(s, M, 5.05, d.get('k', 'เส้นทาง'), w=2.6)
    for i, (when, body) in enumerate(d['journey'][:3]):
        x = 3.40 + i * 3.25
        txt(s, x, 4.95, 3.0, 0.60, when, 22, RED, 'bd')
        _p(s, x, 5.65, 2.9, body, 11.5)


@reg
def cs_vision(prs, d):
    s = _red(prs)
    _bar(s, d, True)
    _h(s, 1.60, 0.80, d['t'], 62, 10.0, True)
    _photo(s, d.get('pi', 19), 9.30, 2.55, 3.40, 4.30, (0.5, 0.3))
    _tag(s, 1.60, 2.75, d.get('vk', 'วิสัยทัศน์'), True)
    _p(s, 4.20, 2.75, 4.70, d['vision'], 13, True)
    _tag(s, 1.60, 4.55, d.get('mk', 'พันธกิจ'), True)
    for i, t in enumerate(d['mission'][:3]):
        _pill(s, 4.20, 4.50 + i * 0.66, 4.30, t)


@reg
def cs_brand(prs, d):
    s = _red(prs)
    _bar(s, d, True)
    _h(s, M, 0.80, d['t'], 64, 6.0, True)
    txt(s, 6.90, 1.05, 5.5, 0.40, d.get('k', ''), 13, CR, 'bd')
    _p(s, 6.90, 1.50, 5.6, d.get('note', ''), 12.5, True)
    _photo(s, d.get('pi', 29), M, 3.75, W - 2 * M, H - 3.75, (0.5, 0.4))


@reg
def cs_strategy(prs, d):
    s = page(prs, CR)
    _bar(s, d)
    _h(s, M, 1.05, d['t'], 62, W - 2 * M, al='c')
    _p(s, 2.2, 2.45, W - 4.4, d.get('note', ''), 13, al='c')
    shp(s, 'rect', 0, 4.10, W, H - 4.10, RED)
    for i, (k, lab, body) in enumerate(d['items'][:3]):
        x = M + i * 4.10
        txt(s, x, 4.45, 3.9, 0.85, f'[{k}]', 36, CR, 'bd')
        txt(s, x, 5.35, 3.8, 0.45, lab, 15, CR, 'bd')
        _p(s, x, 5.85, 3.7, body, 11.5, True)


# ══ เติมในระบบเดียวกันให้ครบ 20 ═══════════════════════════════════════════

@reg
def cs_toc(prs, d):
    s = page(prs, CR)
    shp(s, 'rect', 0, 0, 5.30, H, RED)
    _bar(s, d, True, x1=4.9)
    _h(s, M, 1.00, d['t'], 60, 4.6, True)
    _photo(s, d.get('pi', 24), M, 4.10, 4.06, 2.80, (0.5, 0.5))
    # เฟส D: แถวสูงตามข้อความจริง (ข้อยาวหลายบรรทัด) และรับได้ถึง 7 ข้อ (รายการ "ได้แก่" 7 เรื่อง) ข้อความพอดีระยะเดิม = หน้าตาเดิม
    its = d['items'][:7]; z = d.get('_big') or 0
    hz = [20 if tlines(t, 6.2, max(20, z), 'bd') <= 2 else 16 for t, _ in its]
    hh = [max(0.56, box_h(tlines(t, 6.2, max(a, z), 'bd'), max(a, z))) for (t, _), a in zip(its, hz)]
    bh = [box_h(tlines(b, 6.2, max(12.5, z)), max(12.5, z), 1.40) for _, b in its]
    ys, rh, over = flow_ys([a + b + 0.22 for a, b in zip(hh, bh)], 0.75, 1.28 if len(its) <= 5 else 6.25 / len(its), 7.05)
    for i, ((t, body), y) in enumerate(zip(its, ys)):
        shp(s, 'rect', 6.00, y + 0.18, 0.22, 0.22, RED)
        txt(s, 6.45, y, eng._fitw(6.2, y + hh[i], 7.05), hh[i], t, hz[i], RED, 'bd')
        if body: txt(s, 6.45, y + hh[i], eng._fitw(6.2, y + hh[i] + bh[i], 7.05), max(bh[i], 0.3), body, 11.5, INK, 'rg', sp=1.40)
        if i < len(its) - 1 or not over: ln(s, 6.00, y + rh[i] - 0.16, W - M, y + rh[i] - 0.16, mix(RED, CR, 0.6), 0.7)


@reg
def cs_problem(prs, d):
    s = page(prs, BL)
    _bar(s, d, x1=W - M)
    txt(s, M, 0.80, 9.0, 1.8, d['t'], 54, INK, 'bd', sp=0.92)
    _p(s, M, 2.30, 7.5, d.get('note', ''), 13, c=INK)
    cw = (W - 2 * M - 0.50) / 3
    for i, (v, lab, body) in enumerate(d['items'][:3]):
        x = M + i * (cw + 0.25)
        shp(s, 'rect', x, 3.35, cw, 3.55, CARD)
        txt(s, x + 0.30, 3.55, cw - 0.6, 1.10, v, 50, RED, 'bd')
        txt(s, x + 0.30, 4.75, cw - 0.6, 0.45, lab, 15, INK, 'bd')
        _p(s, x + 0.30, 5.25, cw - 0.6, body, 11.5)


@reg
def cs_div(prs, d):
    s = _red(prs)
    _bar(s, d, True)
    txt(s, M, 1.55, 5.0, 0.40, d.get('k', ''), 14, CR, 'bd')
    _h(s, M, 2.00, d['t'], 72, 7.5, True)
    _p(s, M, 4.75, 5.4, d.get('note', ''), 13, True)
    for i, n in enumerate(d['pis'][:3]):
        _photo(s, n, 7.70 + i * 1.90, 1.20 + (i % 2) * 0.70, 1.75, 4.60, (0.5, 0.4))


@reg
def cs_packages(prs, d):
    s = page(prs, CR)
    _bar(s, d)
    _h(s, M, 0.70, d['t'], 50, W - 2 * M)
    cw = (W - 2 * M - 0.50) / 3
    for i, (name, price, unit, inc) in enumerate(d['items'][:3]):
        x = M + i * (cw + 0.25); hot = i == d.get('hot', 1)
        bg, fg = (RED, CR) if hot else (CARD, RED)
        body = CR if hot else INK
        shp(s, 'rect', x, 2.00, cw, 4.95, bg, line=None if hot else mix(RED, CR, 0.5), lw=1)
        if hot: _pill(s, x + cw - 2.05, 2.20, 1.80, d.get('hotlab', 'แนะนำ'))
        txt(s, x + 0.30, 2.20, cw - 2.3, 0.50, name, 16, fg, 'bd')
        txt(s, x + 0.30, 2.80, cw - 0.6, 0.90, price, 38, fg, 'bd')
        txt(s, x + 0.30, 3.65, cw - 0.6, 0.40, unit, 11.5, body, 'rg')
        ln(s, x + 0.30, 4.20, x + cw - 0.30, 4.20, mix(fg, bg, 0.5), 0.8)
        for k, t in enumerate(inc[:4]):
            shp(s, 'rect', x + 0.32, 4.50 + k * 0.58, 0.14, 0.14, fg)
            txt(s, x + 0.60, 4.33 + k * 0.58, cw - 0.9, 0.48, t, 12.5, body, 'rg', an='m')


@reg
def cs_chart_budget(prs, d):
    s = page(prs, BL)
    _bar(s, d)
    txt(s, M, 0.80, 8.0, 1.0, d['t'], 46, INK, 'bd')
    it = d['items'][:4]
    cols = [RED, INK, 'E7765A', CARD]
    shp(s, 'rect', M, 2.05, 5.20, 4.85, CARD)
    chart(s, 'donut', M + 0.25, 2.20, 4.70, 4.55, [x[0] for x in it], [('สัดส่วน', [x[1] for x in it])], cols,
          labels=False, hole=58)
    txt(s, M + 0.25, 4.10, 4.70, 0.60, d['big'], 26, RED, 'bd', 'c')
    txt(s, M + 0.25, 4.70, 4.70, 0.35, d['biglab'], 11, INK, 'rg', 'c')
    for i, (lab, v, amt, body) in enumerate(it):
        y = 2.05 + i * 1.23
        shp(s, 'rect', 6.20, y + 0.20, 0.30, 0.30, cols[i], line=INK if i == 3 else None, lw=0.8)
        txt(s, 6.70, y + 0.05, 3.6, 0.45, lab, 15, INK, 'bd')
        _p(s, 6.70, y + 0.52, 3.8, body, 11.5, c=INK)
        txt(s, 10.40, y + 0.02, W - M - 10.40, 0.55, f'{v}%', 24, RED, 'bd', 'r')
        txt(s, 10.40, y + 0.58, W - M - 10.40, 0.40, amt, 12, INK, 'bd', 'r')
        ln(s, 6.20, y + 1.12, W - M, y + 1.12, mix(INK, BL, 0.75), 0.7)


@reg
def cs_chart_case(prs, d):
    s = _red(prs)
    _bar(s, d, True)
    shp(s, 'rect', M, 0.95, 7.40, 5.95, CR)
    chart(s, 'col', M + 0.20, 1.15, 7.00, 5.55, d['cats'], [(d['sname'], d['vals'])],
          ['E7A08F'] * (len(d['vals']) - 1) + [RED], labels=True, fmt='#,##0', gap=55, sz=12, c=INK, vary=True)
    _h(s, 8.45, 0.95, d['t'], 40, W - M - 8.45, True)
    _p(s, 8.45, 2.75, W - M - 8.45, d.get('note', ''), 12, True)
    for i, (v, lab) in enumerate(d['items'][:2]):
        y = 4.05 + i * 1.45
        shp(s, 'rect', 8.45, y, W - M - 8.45, 1.28, CR)
        txt(s, 8.70, y + 0.10, 2.2, 1.08, v, 30, RED, 'bd', an='m')
        _p(s, 10.85, y + 0.25, W - M - 11.0, lab, 11.5)


@reg
def cs_chart_pkg(prs, d):
    s = page(prs, CR)
    _bar(s, d)
    _h(s, M, 0.75, d['t'], 46, 8.0)
    chart(s, 'col', M, 2.00, 7.90, 4.95, d['cats'], d['series'], [RED, INK], labels=True, fmt='0', gap=70,
          overlap=-10, sz=12, c=INK, legend=True)
    shp(s, 'rect', 8.95, 0, W - 8.95, H, RED)
    _bar(s, dict(_l='', _r=d.get('_r', 'ลายเส้นสตูดิโอ')), True)
    for i, (v, lab) in enumerate(d['items'][:3]):
        y = 1.10 + i * 2.00
        txt(s, 9.35, y, W - M - 9.35, 0.95, v, 40, CR, 'bd')
        _p(s, 9.35, y + 0.95, W - M - 9.35, lab, 12, True)


@reg
def cs_timeline(prs, d):
    s = page(prs, CR)
    _bar(s, d)
    _h(s, M, 0.75, d['t'], 46, 10.0)
    x0, x1 = 4.10, W - M; mw = (x1 - x0) / 12
    for m in range(12):
        txt(s, x0 + m * mw, 2.00, mw, 0.40, f'{m + 1}', 12, RED, 'bd', 'c')
        if m: ln(s, x0 + m * mw, 2.45, x0 + m * mw, 6.85, mix(RED, CR, 0.75), 0.5)
    txt(s, M, 2.00, 3.3, 0.40, d.get('k', 'เดือนที่'), 12, RED, 'bd')
    for i, (lab, spans) in enumerate(d['rows'][:5]):
        y = 2.55 + i * 0.86
        txt(s, M, y, 3.35, 0.66, lab, 13.5, INK, 'bd', an='m')
        for a, b in spans:
            shp(s, 'rect', x0 + (a - 1) * mw + 0.04, y + 0.12, (b - a + 1) * mw - 0.08, 0.42, RED if i % 2 == 0 else INK)
        ln(s, M, y + 0.78, x1, y + 0.78, mix(RED, CR, 0.6), 0.6)


@reg
def cs_team(prs, d):
    s = _red(prs)
    _bar(s, d, True)
    _h(s, M, 0.75, d['t'], 50, 7.5, True)
    _p(s, 8.30, 0.95, W - M - 8.30, d.get('note', ''), 12, True)
    cw = (W - 2 * M - 0.75) / 4
    for i, (n, name, role) in enumerate(d['items'][:4]):
        x = M + i * (cw + 0.25)
        _photo(s, n, x, 2.25, cw, 3.45, (0.5, 0.3))
        txt(s, x, 5.85, cw, 0.48, name, 16, CR, 'bd')
        _p(s, x, 6.33, cw, role, 11.5, True)


@reg
def cs_deliver(prs, d):
    s = page(prs, BL)
    _bar(s, d)
    txt(s, M, 0.80, 9.0, 1.0, d['t'], 50, INK, 'bd')
    _p(s, M, 1.95, 8.0, d.get('note', ''), 13, c=INK)
    cw = (W - 2 * M - 0.75) / 4
    for i, (v, lab, body) in enumerate(d['items'][:4]):
        x = M + i * (cw + 0.25)
        shp(s, 'rect', x, 3.05, cw, 3.85, CARD if i % 2 == 0 else RED)
        fg = RED if i % 2 == 0 else CR
        txt(s, x + 0.25, 3.25, cw - 0.5, 1.40, v, 66, fg, 'bd')
        txt(s, x + 0.25, 4.85, cw - 0.5, 0.48, lab, 15, fg, 'bd')
        _p(s, x + 0.25, 5.35, cw - 0.5, body, 11.5, c=INK if i % 2 == 0 else CR)


@reg
def cs_quote(prs, d):
    s = page(prs, CR)
    _bar(s, d, x1=W - M)
    _photo(s, d.get('pi', 35), M, 1.00, 4.60, 5.90, d.get('focus', (0.5, 0.35)))
    txt(s, 5.80, 0.70, 2.0, 1.60, '“', 120, RED, 'bd')
    txt(s, 5.80, 2.20, W - M - 5.80, 2.80, d['q'], 26, RED, 'bd', sp=1.25)
    ln(s, 5.80, 5.35, 8.30, 5.35, RED, 1.5)
    txt(s, 5.80, 5.55, 6.5, 0.45, d['who'], 15, INK, 'bd')
    _p(s, 5.80, 6.00, 6.5, d.get('role', ''), 12)


@reg
def cs_invest(prs, d):
    s = page(prs, CR)
    shp(s, 'rect', 0, 0, 5.40, H, RED)
    _bar(s, d, True, x1=5.0)
    txt(s, M, 1.10, 4.6, 0.50, d['k'], 15, CR, 'bd')
    txt(s, M, 1.65, 4.7, 1.20, d['big'], 54, CR, 'bd')
    txt(s, M, 2.85, 4.6, 0.45, d['biglab'], 14, CR, 'bd')
    _p(s, M, 3.60, 4.3, d.get('note', ''), 12, True)
    _photo(s, d.get('pi', 20), M, 4.55, 5.40 - 2 * M, 2.35, (0.5, 0.5))
    _h(s, 6.00, 0.80, d['t'], 44, W - M - 6.00)
    for i, (lab, v) in enumerate(d['rows']):
        y = 2.20 + i * 0.82
        last = i == len(d['rows']) - 1
        if last: shp(s, 'rect', 6.00, y, W - M - 6.00, 0.74, RED)
        c = CR if last else INK
        txt(s, 6.25, y, 4.0, 0.74, lab, 14, c, 'bd' if last else 'rg', an='m')
        txt(s, 9.60, y, W - M - 9.85, 0.74, v, 16, CR if last else RED, 'bd', 'r', 'm')
        if not last: ln(s, 6.00, y + 0.74, W - M, y + 0.74, mix(RED, CR, 0.6), 0.7)


@reg
def cs_close(prs, d):
    s = page(prs, BL)
    shp(s, 'round', 0.35, 0.35, W - 0.70, H - 0.70, RED, adj=0.03)
    _bar(s, d, True, x0=0.85, x1=W - 0.85, y=0.58)
    _h(s, 0.85, 1.20, d['t'], 72, 7.0, True)
    for i, (lab, v) in enumerate(d['items'][:4]):
        y = 4.15 + i * 0.62
        txt(s, 0.85, y, 1.8, 0.50, lab, 12, CR, 'bd', an='m')
        txt(s, 2.70, y, 4.6, 0.50, v, 14, CR, 'rg', an='m')
    _photo(s, d.get('pi', 16), 7.85, 1.00, 4.65, 5.50, (0.5, 0.4))
