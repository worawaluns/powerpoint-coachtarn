"""20 เลย์เอาต์ชุดโปรไฟล์บริษัทวิศวกรรม — ลอกโครงจากเทมเพลต Engineering Solutions (ต้นฉบับแดง) ทำเป็นน้ำเงินตามที่ไอซ์สั่ง

รูปคนย้อมน้ำเงินเต็มแผง แถบหัวกระดาษมนยาวเต็มหน้ามีป้ายเล็ก หัวเรื่องตัวหนามาก
ป้ายตัวเลขสี่เหลี่ยมน้ำเงิน การ์ดมีปุ่มวงกลมลูกศร หน่วยของตัวเลขเป็นน้ำเงินสว่าง
สลับหน้าเทาอ่อน กรมท่าเกือบดำ และน้ำเงินเต็มหน้า
ตัวหนังสือบนน้ำเงินใช้ขาว (6.2) ตัวเลขน้ำเงินสว่างบนพื้นเข้ม (5.5)
"""
from eng import *
import eng
from lay import L, reg

txt = txt_big        # ขนาดขั้นต่ำตามชุด 366 ดู eng.roomy()
chart = chart_big

M = 0.62
DK = '121722'          # กรมท่าเกือบดำ
DK2 = '1C2333'         # การ์ดบนพื้นเข้ม
LG = 'F2F3F5'
CG = 'E3E6EB'          # การ์ดเทาบนพื้นอ่อน
SOFT = 'B8C2D6'        # เนื้อความบนพื้นเข้ม


def B(): return P['acc']
def LB(): return P['acc2']


def _duo(dark=True):
    if dark:
        return f"duo:{mix(DK, B(), 0.30)}:{mix('FFFFFF', LB(), 0.45)}"
    return f"duo:{mix(DK, B(), 0.20)}:{mix('FFFFFF', LB(), 0.10)}"


def _photo(s, n, x, y, w, h, focus=(0.5, 0.35), adj=None, dark=True, topic='eng'):
    return pic(s, ph(topic, n), x, y, w, h, geom='roundRect' if adj else None, adj=adj, focus=focus, mode=_duo(dark))


def _bar(s, label, dark=False, fill=None, n=None):
    """แถบหัวกระดาษมนยาวเต็มหน้า มีป้ายเล็กด้านซ้าย"""
    f = fill or (mix(DK, 'FFFFFF', 0.10) if dark else mix(LG, DK, 0.08))
    shp(s, 'round', M, 0.30, W - M * 2, 0.40, f, adj=0.5)
    c = 'FFFFFF' if dark or fill else '4A5163'
    txt(s, M + 0.30, 0.30, 5.0, 0.40, label, 9, c, 'md', an='m')
    if n:
        txt(s, W - M - 1.3, 0.30, 1.0, 0.40, str(int(n)), 9, c, 'md', 'r', 'm')


def _h(s, x, y, t, sz=40, w=7.0, c=None, al='l'):
    txt(s, x, y, w, 2.6, t, sz, c or B(), 'bd', al, sp=0.98)


def _p(s, x, y, w, t, sz=11, c=None, al='l'):
    if t: txt(s, x, y, w, 2.0, t, sz, c or '3E4556', 'rg', al, sp=1.36)


def _arrow(s, cx, cy, r=0.20, fill=None, c='FFFFFF'):
    shp(s, 'oval', cx - r, cy - r, r * 2, r * 2, fill or B())
    icon(s, 'arrow-right', cx, cy, r * 1.1, c)


def _badge(s, x, y, n, sz=0.46):
    shp(s, 'rect', x, y, sz, sz, B())
    txt(s, x, y, sz, sz, str(n), 16, 'FFFFFF', 'bd', 'c', 'm')


def _num(s, x, y, w, v, unit, sz=36, c='FFFFFF', uc=None):
    txt(s, x, y, w, sz / 55, '', sz, c, 'md', runs=[[(v, {}), (unit, {'c': uc or LB(), 'sz': sz * 0.55})]])


def _mark(s, x, y, sz=0.9, c=None):
    """เครื่องหมายบั้งคู่ แทนโลโก้ X ของต้นฉบับ"""
    c = c or B()
    shp(s, 'chev', x, y, sz * 0.55, sz, c)
    shp(s, 'chev', x + sz * 0.38, y, sz * 0.55, sz, c, rot=180)


# ══ เลย์เอาต์ตามรูปอ้างอิง ═════════════════════════════════════════════════

@reg
def eg_cover(prs, d):
    s = page(prs, DK)
    _photo(s, d.get('pi', 4), 0, 0, W, H, (0.30, 0.35))
    shp(s, 'rect', 0, 0, W, H, mix(DK, B(), 0.35), a=0.35)
    gradband(s, 6.0, 0, W - 6.0, H, 0, c1=DK, c2=DK, a1=0.0, a2=0.85)
    _bar(s, d.get('k', 'โปรไฟล์บริษัท'), fill=B())
    _mark(s, M + 0.15, 0.95, 0.70, 'FFFFFF')
    txt(s, M + 1.10, 1.02, 3.0, 0.50, d.get('brand', 'บริษัทของคุณ'), 16, 'FFFFFF', 'bd')
    _h(s, 7.10, 2.10, d['t'], 50, 5.7, 'FFFFFF')
    ln(s, 7.15, 5.25, 7.95, 5.25, LB(), 2)
    _p(s, 8.15, 5.05, 4.5, d.get('s', ''), 12, 'E3EAFA')


@reg
def eg_exec(prs, d):
    s = page(prs, DK)
    _photo(s, d.get('pi', 5), 8.30, 0, W - 8.30, H, (0.6, 0.25))
    gradband(s, 8.30, 0, 2.2, H, 0, c1=DK, c2=DK, a2=0.0)
    _bar(s, 'ภาพรวม', dark=True, n=d.get('n'))
    _h(s, M, 1.20, d['t'], 44, 6.4, 'FFFFFF')
    _p(s, M, 2.85, 5.6, d.get('note', ''), 12, SOFT)
    for i, (v, unit, lab) in enumerate(d['items'][:4]):
        x = M + i * 1.95                      # ทั้งสี่ตัวต้องจบก่อนรูปเริ่ม ไม่งั้นหน่วยสีน้ำเงินจมในรูป
        _num(s, x, 4.95, 1.9, v, unit, 32, 'FFFFFF')
        _p(s, x, 5.75, 1.8, lab, 11, SOFT)


@reg
def eg_toc(prs, d):
    s = page(prs, LG)
    _photo(s, d.get('pi', 14), 8.80, 0.95, W - 8.80, H - 0.95, (0.5, 0.4), dark=False, topic='construction')
    gradband(s, 8.80, 0.95, 2.4, H - 0.95, 0, c1=LG, c2=LG, a2=0.0)
    _bar(s, 'สารบัญ', n=d.get('n'))
    _h(s, M, 1.20, d['t'], 46, 7.0)
    cw = 2.05
    for i, (no, h_, body, pages) in enumerate(d['items'][:4]):
        x = M + i * (cw + 0.20)
        shp(s, 'round', x, 3.20, cw, 3.50, CG, adj=0.08)
        _badge(s, x + 0.25, 3.45, no)
        txt(s, x + 0.25, 4.15, cw - 0.45, 0.80, h_, 13, DK, 'bd', sp=1.05)
        ln(s, x + 0.25, 5.00, x + cw - 0.25, 5.00, B(), 1.4)
        _p(s, x + 0.25, 5.15, cw - 0.45, body, 10.5)
        txt(s, x + 0.25, 6.20, cw - 0.45, 0.30, pages, 10.5, '4A5163', 'md')


@reg
def eg_value(prs, d):
    s = page(prs, LG)
    _photo(s, d.get('pi', 6), 0, 0, 7.30, H, (0.5, 0.35), dark=False)
    shp(s, 'rtri', 5.30, 0, 2.05, H, LG, rot=180)
    gradband(s, 0, 4.40, 6.4, H - 4.40, 90, c1=LG, c2=LG, a1=0.0, a2=0.92)
    _bar(s, 'สิ่งที่เรามอบให้', n=d.get('n'))
    _h(s, M, 5.40, d['t'], 42, 6.5)
    # เฟส D: แถวสูงตามข้อความจริง รับได้ถึง 5 ข้อ / ข้อที่มีแต่ประโยค (รายการจากเอกสาร) เป็นย่อหน้า 14pt ไม่ใช่หัวตัวหนา 16pt สองบรรทัด
    its = d['items'][:5]; z = d.get('_big') or 0
    para = all(not b for _, b in its) and any(len(h) > 40 for h, _ in its)   # ทั้งหน้าใช้แบบเดียวกัน
    rows = []
    for h_, body in its:
        if not para:
            a = max(0.80, box_h(tlines(h_, 4.2, max(16, z), 'bd'), max(16, z), 1.05)); b = box_h(tlines(body, 4.2, max(12, z)), max(12, z), 1.36)
        else: a, b = box_h(tlines(h_, 4.2, max(14, z)), max(14, z), 1.3), 0
        rows.append((a, b))
    ys, rh, over = flow_ys([max(0.56, a + b) + 0.30 for a, b in rows], 1.30, 1.95 if len(its) <= 3 else 5.70 / len(its), 7.05)
    for i, ((h_, body), y, (a, b)) in enumerate(zip(its, ys, rows)):
        _badge(s, 7.90, y, i + 1)
        if not para:
            txt(s, 8.55, y - 0.02, eng._fitw(4.2, y + a, 7.05), a, h_, 16, DK, 'bd', sp=1.05)
            if body: txt(s, 8.55, y + a, eng._fitw(4.2, y + a + b, 7.05), max(b, 0.3), body, 11, '3E4556', 'rg', sp=1.36)
        else: txt(s, 8.55, y + 0.02, eng._fitw(4.2, y + a, 7.05), a, h_, 14, DK, 'rg', sp=1.3)


@reg
def eg_vision(prs, d):
    s = page(prs, B())
    _bar(s, 'วิสัยทัศน์และพันธกิจ', fill=mix(B(), 'FFFFFF', 0.15), n=d.get('n'))
    _photo(s, d.get('pi', 1), M, 1.00, 5.80, 5.90, (0.4, 0.3), adj=0.04)
    shp(s, 'round', M, 1.00, 5.80, 5.90, DK, a=0.35, adj=0.04)
    txt(s, M + 0.40, 1.30, 3.0, 0.30, 'วิสัยทัศน์', 11, 'FFFFFF', 'md')
    _h(s, M + 0.40, 3.70, d['vision'], 26, 5.0, 'FFFFFF')
    shp(s, 'round', 6.70, 1.00, W - M - 6.70, 5.90, DK, adj=0.04)
    _mark(s, W - M - 0.95, 1.30, 0.55, LB())
    txt(s, 7.10, 1.30, 3.0, 0.30, 'พันธกิจ', 11, SOFT, 'md')
    _h(s, 7.10, 1.85, d['mission'], 22, 5.0, 'FFFFFF')
    for i, t in enumerate(d['items'][:3]):
        y = 4.30 + i * 0.62
        shp(s, 'oval', 7.12, y + 0.12, 0.12, 0.12, LB())
        _p(s, 7.40, y, 4.8, t, 11.5, SOFT)


@reg
def eg_who(prs, d):
    s = page(prs, DK)
    _bar(s, 'เราคือใคร', dark=True, n=d.get('n'))
    _h(s, M, 1.30, d['t'], 50, 6.2, 'FFFFFF')
    _p(s, M, 3.10, 5.6, d.get('note', ''), 12, SOFT)
    x = M
    for t in d.get('tags', []):
        w = len(t) * 0.10 + 0.50
        shp(s, 'round', x, 5.95, w, 0.42, None, line=SOFT, lw=1, adj=0.5)
        txt(s, x, 5.95, w, 0.42, t, 10.5, 'FFFFFF', 'md', 'c', 'm')
        x += w + 0.15
    spec = [(7.40, 1.10, mix(DK, B(), 0.28)), (10.10, 1.10, '070A10'), (7.40, 4.05, mix(DK, B(), 0.28)), (10.10, 4.05, DK2)]
    for (lab, v, big_blue), (x, y, f) in zip(d['items'][:4], spec):
        shp(s, 'round', x, y, 2.60, 2.80, f, adj=0.05)
        _arrow(s, x + 2.22, y + 0.38, 0.17)
        txt(s, x + 0.30, y + 1.30, 2.0, 0.30, lab, 10.5, SOFT, 'md')
        txt(s, x + 0.30, y + 1.70, 2.2, 0.90, v, 40, LB() if big_blue else 'FFFFFF', 'md')


@reg
def eg_org(prs, d):
    s = page(prs)
    _photo(s, d.get('pi', 17), 7.00, 0.90, W - 7.00, 3.70, (0.5, 0.3), dark=False)
    gradband(s, 7.00, 0.90, 2.4, 3.70, 0, c1='FFFFFF', c2='FFFFFF', a2=0.0)
    txt(s, M, 0.55, 3.0, 0.28, 'โครงสร้างองค์กร', 9, '4A5163', 'md')
    _h(s, M, 0.95, d['t'], 42, 6.0)
    ln(s, M, 2.55, M + 0.70, 2.55, B(), 2)
    _p(s, M, 2.75, 5.6, d.get('note', ''), 11.5)
    shp(s, 'round', M, 4.10, 3.10, 0.62, DK, adj=0.3)
    txt(s, M, 4.10, 3.10, 0.62, d['top'], 12, 'FFFFFF', 'bd', 'c', 'm')
    ln(s, M + 1.55, 4.72, M + 1.55, 5.05, DK, 1.2)
    n = len(d['items'][:5]); cw = (W - M * 2 - 0.15 * (n - 1)) / n
    ln(s, M + cw / 2, 5.05, W - M - cw / 2, 5.05, DK, 1.2)
    for i, (h_, body) in enumerate(d['items'][:5]):
        x = M + i * (cw + 0.15)
        ln(s, x + cw / 2, 5.05, x + cw / 2, 5.25, DK, 1.2)
        shp(s, 'round', x, 5.25, cw, 1.75, CG, adj=0.08)
        txt(s, x + 0.20, 5.40, cw - 0.75, 0.40, h_, 12, DK, 'bd')
        _arrow(s, x + cw - 0.35, 5.58, 0.16)
        _p(s, x + 0.20, 5.90, cw - 0.40, body, 10.5)


@reg
def eg_div(prs, d):
    s = page(prs, DK)
    _photo(s, d.get('pi', 3), 4.0, 0, W - 4.0, H, (0.5, 0.25))
    gradband(s, 4.0, 0, 4.0, H, 0, c1=DK, c2=DK, a2=0.0)
    shp(s, 'rect', 0, 0, 4.0, H, DK)
    _mark(s, -0.30, -0.10, 2.30, B())
    _h(s, M, 3.10, d['t'], 64, 11.5, LB())
    txt(s, M, 5.55, 4.0, 0.30, d.get('k', ''), 11, 'FFFFFF', 'md')
    _p(s, M, 5.95, 5.5, d.get('note', ''), 11.5, SOFT)


@reg
def eg_capability(prs, d):
    s = page(prs, B())
    _bar(s, d.get('k', 'ความสามารถ'), fill=mix(B(), 'FFFFFF', 0.15), n=d.get('n'))
    _photo(s, d.get('pi', 2), M, 1.00, 4.70, 5.90, (0.5, 0.25), adj=0.04)
    shp(s, 'round', M, 1.00, 4.70, 5.90, DK, a=0.30, adj=0.04)
    _h(s, M + 0.35, 4.10, d['t'], 32, 4.1, 'FFFFFF')
    _p(s, M + 0.35, 5.65, 4.0, d.get('note', ''), 11, 'E3EAFA')
    cw, ch = 3.50, 2.85
    fills = [mix(B(), DK, 0.30), DK, mix(B(), DK, 0.30), DK]
    for i, (h_, body) in enumerate(d['items'][:4]):
        x = 5.60 + (i % 2) * (cw + 0.20)
        y = 1.00 + (i // 2) * (ch + 0.20)
        shp(s, 'round', x, y, cw, ch, fills[i], adj=0.05)
        _arrow(s, x + cw - 0.40, y + 0.40, 0.17, 'FFFFFF', B())
        txt(s, x + 0.30, y + 0.30, cw - 1.0, 0.80, h_, 14, 'FFFFFF', 'bd', sp=1.05)
        _p(s, x + 0.30, y + 1.15, cw - 0.6, body, 10.5, 'DCE3F2')


@reg
def eg_numbered(prs, d):
    s = page(prs, LG)
    _bar(s, d.get('k', 'ความสามารถ'), n=d.get('n'))
    for i, (h_, body) in enumerate(d['items'][:4]):
        y = 1.05 + i * 1.47
        hot = i == 1
        shp(s, 'round', M, y, 6.10, 1.30, DK if hot else 'FFFFFF', adj=0.10)
        _badge(s, M + 0.25, y + 0.42, i + 1)
        txt(s, M + 0.95, y + 0.20, 4.9, 0.40, h_, 14, 'FFFFFF' if hot else DK, 'bd')
        _p(s, M + 0.95, y + 0.62, 4.9, body, 10.5, SOFT if hot else None)
    _photo(s, d.get('pi', 13), 7.05, 1.05, W - M - 7.05, 5.85, (0.5, 0.45), adj=0.04)
    shp(s, 'round', 7.05, 1.05, W - M - 7.05, 5.85, DK, a=0.35, adj=0.04)
    _mark(s, W - M - 1.10, 1.35, 0.70, 'FFFFFF')
    _h(s, 7.45, 3.80, d['t'], 32, 5.0, 'FFFFFF')
    ln(s, 7.50, 5.35, 8.20, 5.35, LB(), 2)
    _p(s, 7.50, 5.55, 4.7, d.get('note', ''), 11, 'E3EAFA')


@reg
def eg_project(prs, d):
    s = page(prs, DK)
    _photo(s, d.get('pi', 26), 0, 0, W, H, (0.5, 0.5), topic='construction')
    shp(s, 'rect', 0, 0, W, H, DK, a=0.82)          # รูปเป็นแค่พื้นผิว ตัวหนังสือต้องอ่านออก
    _bar(s, d.get('k', 'โครงการที่ 01'), dark=True, n=d.get('n'))
    _h(s, M, 1.20, d['t'], 40, 5.8, 'FFFFFF')
    _p(s, M, 2.90, 5.4, d.get('note', ''), 11.5, SOFT)
    _num(s, M, 5.15, 6.0, d['big'], d['bigunit'], 60)
    txt(s, M, 6.45, 5.5, 0.30, d['biglab'], 10.5, SOFT, 'md')
    cards = [(7.00, 1.00, W - M - 7.00, 2.70, 'เป้าหมาย'), (7.00, 3.90, 2.75, 3.00, 'วิธีทำ'),
             (9.95, 3.90, W - M - 9.95, 3.00, 'ผลลัพธ์')]
    for (x, y, w, h, lab), body in zip(cards, d['items'][:3]):
        shp(s, 'round', x, y, w, h, '070A10' if lab != 'ผลลัพธ์' else DK2, adj=0.05)
        txt(s, x + 0.30, y + 0.28, 2.0, 0.30, lab, 10.5, SOFT, 'md')
        _arrow(s, x + w - 0.40, y + 0.42, 0.17)
        txt(s, x + 0.30, y + 0.85, w - 0.6, h - 1.0, body, 15 if lab == 'เป้าหมาย' else 13, 'FFFFFF', 'bd', sp=1.15)


@reg
def eg_highlights(prs, d):
    s = page(prs, DK)
    _photo(s, d.get('pi', 21), 0, 0, W, H, (0.5, 0.5), topic='construction')
    shp(s, 'rect', 0, 0, W, H, DK, a=0.85)
    _bar(s, d.get('k', 'โครงการที่ 01'), dark=True, n=d.get('n'))
    shp(s, 'oval', M, 1.08, 0.30, 0.30, B())
    icon(s, 'check', M + 0.15, 1.23, 0.20, 'FFFFFF')
    txt(s, M + 0.45, 1.05, 6.0, 0.36, d['t'], 14, 'FFFFFF', 'bd')
    cw = (W - M * 2 - 0.50) / 2
    for i, (h_, body) in enumerate(d['items'][:4]):
        x = M + (i % 2) * (cw + 0.50)
        y = 1.70 + (i // 2) * 1.55
        txt(s, x, y, cw, 0.36, h_, 13, LB(), 'bd')
        _p(s, x, y + 0.42, cw, body, 11, SOFT)
    shp(s, 'round', M, 5.10, W - M * 2, 1.80, '070A10', adj=0.12)
    txt(s, M + 0.40, 5.40, 5.6, 0.90, d['statement'], 14, 'FFFFFF', 'bd', sp=1.15)
    _p(s, M + 0.40, 6.30, 5.6, d.get('note', ''), 10.5, SOFT)
    _num(s, 7.20, 5.30, 4.6, d['big'], d['bigunit'], 54)
    txt(s, 7.25, 6.35, 4.6, 0.30, d['biglab'], 10.5, SOFT, 'md')
    _arrow(s, W - M - 0.45, 5.50, 0.20)


# ══ อีก 8 เลย์เอาต์ในระบบเดียวกัน ═════════════════════════════════════════

@reg
def eg_chart_rev(prs, d):
    s = page(prs, LG)
    _bar(s, 'ผลประกอบการ', n=d.get('n'))
    _h(s, M, 1.10, d['t'], 40, 4.6)
    for i, (v, unit, lab) in enumerate(d['items'][:2]):
        y = 3.40 + i * 1.65
        shp(s, 'rect', M, y, 0.10, 1.25, B() if i == 0 else DK)
        _num(s, M + 0.30, y - 0.05, 4.2, v, unit, 36, DK, B())
        _p(s, M + 0.30, y + 0.78, 3.9, lab, 11)
    shp(s, 'round', 5.30, 1.05, W - M - 5.30, 5.85, 'FFFFFF', adj=0.04)
    chart(s, 'col', 5.50, 1.25, W - M - 5.70, 5.45, d['cats'], [(d['sname'], d['vals'])],
          ['9AA3B5'] * (len(d['vals']) - 1) + [B()], labels=True, fmt='#,##0', gap=45, sz=12, c=DK, vary=True)


@reg
def eg_donut(prs, d):
    s = page(prs)
    _bar(s, 'รายได้แยกตามกลุ่มธุรกิจ', n=d.get('n'))
    _h(s, M, 1.10, d['t'], 38, 6.0)
    cols = [B(), DK, LB(), '9AA3B5', 'C9D4F2']
    it = d['items'][:5]
    chart(s, 'donut', 0.60, 2.40, 4.60, 4.60, [x[0] for x in it], [('ล้านบาท', [x[1] for x in it])],
          cols, labels=False, hole=60)
    txt(s, 0.60, 4.30, 4.60, 0.60, d['big'], 28, DK, 'bd', 'c')
    txt(s, 0.60, 4.90, 4.60, 0.30, d['biglab'], 10.5, '4A5163', 'rg', 'c')
    for i, (lab, v, pct, body) in enumerate(it):
        y = 2.10 + i * 0.98
        shp(s, 'round', 5.70, y, W - M - 5.70, 0.86, LG, adj=0.15)
        shp(s, 'rect', 5.95, y + 0.29, 0.28, 0.28, cols[i])
        txt(s, 6.45, y + 0.08, 3.4, 0.36, lab, 13, DK, 'bd')
        _p(s, 6.45, y + 0.44, 3.8, body, 10.5)
        txt(s, 10.10, y + 0.12, 1.30, 0.60, f'{v:,}', 17, DK, 'bd', 'r', 'm')
        txt(s, 11.45, y + 0.12, 0.85, 0.60, f'{pct}%', 14, B(), 'bd', 'r', 'm')


@reg
def eg_safety(prs, d):
    s = page(prs, DK)
    _bar(s, 'ความปลอดภัย', dark=True, n=d.get('n'))
    _h(s, M, 1.10, d['t'], 38, 7.2, 'FFFFFF')
    _p(s, M, 2.40, 7.0, d.get('note', ''), 11.5, SOFT)
    shp(s, 'round', M, 3.20, 8.10, 3.70, DK2, adj=0.05)
    chart(s, 'line', M + 0.15, 3.35, 7.80, 3.45, d['cats'], [(d['sname'], d['vals'])], [LB()], labels=True,
          fmt='0.00', sz=11, c=SOFT, lw=3.5, minv=0)
    for i, (v, unit, lab) in enumerate(d['items'][:3]):
        y = 1.10 + i * 1.95
        shp(s, 'round', 9.10, y, W - M - 9.10, 1.75, B() if i == 0 else DK2, adj=0.08)
        _num(s, 9.40, y + 0.20, 3.2, v, unit, 32, 'FFFFFF', 'DCE6FF' if i == 0 else LB())
        _p(s, 9.40, y + 0.98, 3.1, lab, 10.5, 'E3EAFA' if i == 0 else SOFT)


@reg
def eg_table(prs, d):
    s = page(prs, LG)
    _bar(s, 'โครงการสำคัญ', n=d.get('n'))
    _h(s, M, 1.10, d['t'], 38, 9.0)
    cols = d['colw']; tw = W - M * 2; y0 = 2.30; rh = 0.78
    xs = [M]
    for f in cols[:-1]: xs.append(xs[-1] + tw * f)
    shp(s, 'round', M, y0, tw, 0.60, DK, adj=0.2)
    for j, hd in enumerate(d['head']):
        txt(s, xs[j] + 0.25, y0, tw * cols[j] - 0.45, 0.60, hd, 11.5, 'FFFFFF', 'md', 'l' if j == 0 else 'c', 'm')
    for i, row in enumerate(d['rows']):
        y = y0 + 0.70 + i * rh
        shp(s, 'round', M, y, tw, rh - 0.10, 'FFFFFF', adj=0.15)
        for j, cell in enumerate(row):
            last = j == len(row) - 1
            if last:
                done = cell.startswith('ส่งมอบ')
                w = 1.70
                shp(s, 'round', xs[j] + (tw * cols[j] - w) / 2, y + 0.17, w, 0.36, B() if done else CG, adj=0.5)
                txt(s, xs[j] + (tw * cols[j] - w) / 2, y + 0.17, w, 0.36, cell, 10.5, 'FFFFFF' if done else DK, 'md', 'c', 'm')
            else:
                txt(s, xs[j] + 0.25, y, tw * cols[j] - 0.45, rh - 0.10, cell, 12 if j == 0 else 11.5, DK,
                    'bd' if j == 0 else 'rg', 'l' if j == 0 else 'c', 'm')


@reg
def eg_timeline(prs, d):
    s = page(prs, DK)
    _photo(s, d.get('pi', 19), 0, 0, W, 3.30, (0.5, 0.5))
    gradband(s, 0, 1.30, W, 2.00, 90, c1=DK, c2=DK, a1=0.0, a2=1.0)
    _bar(s, 'เส้นทางของเรา', dark=True, n=d.get('n'))
    _h(s, M, 1.30, d['t'], 40, 9.0, 'FFFFFF')
    n = len(d['items'][:5]); cw = (W - M * 2) / n
    ln(s, M, 4.05, W - M, 4.05, mix(DK, 'FFFFFF', 0.25), 1.5)
    for i, (yr, h_, body) in enumerate(d['items'][:5]):
        x = M + i * cw
        last = i == n - 1
        shp(s, 'oval', x, 3.92, 0.26, 0.26, B() if last else 'FFFFFF')
        txt(s, x, 4.35, cw - 0.3, 0.60, yr, 26, LB() if last else 'FFFFFF', 'md')
        txt(s, x, 5.05, cw - 0.3, 0.40, h_, 13, 'FFFFFF', 'bd')
        _p(s, x, 5.50, cw - 0.35, body, 10.5, SOFT)


@reg
def eg_team(prs, d):
    s = page(prs, LG)
    _bar(s, 'ทีมผู้บริหาร', n=d.get('n'))
    _h(s, M, 1.10, d['t'], 38, 7.0)
    cw = (W - M * 2 - 0.60) / 4
    for i, (name, role, body, pi, fx) in enumerate(d['items'][:4]):
        x = M + i * (cw + 0.20)
        shp(s, 'round', x, 2.25, cw, 4.65, 'FFFFFF', adj=0.05)
        _photo(s, pi, x + 0.15, 2.40, cw - 0.30, 2.60, (fx, 0.25), adj=0.06, dark=False)
        txt(s, x + 0.25, 5.15, cw - 0.5, 0.40, name, 14, DK, 'bd')
        txt(s, x + 0.25, 5.55, cw - 0.5, 0.30, role, 11, B(), 'md')
        _p(s, x + 0.25, 5.95, cw - 0.5, body, 10.5)


@reg
def eg_quote(prs, d):
    s = page(prs, B())
    _photo(s, d.get('pi', 0), 7.80, 0, W - 7.80, H, (0.5, 0.25))
    gradband(s, 7.80, 0, 2.0, H, 0, c1=B(), c2=B(), a2=0.0)
    _bar(s, 'เสียงจากลูกค้า', fill=mix(B(), 'FFFFFF', 0.15), n=d.get('n'))
    icon(s, 'quote', M + 0.40, 1.60, 0.80, 'FFFFFF')
    txt(s, M, 2.30, 7.4, 3.0, d['t'], 22, 'FFFFFF', 'md', sp=1.3)
    ln(s, M, 5.55, M + 0.80, 5.55, 'FFFFFF', 2)
    txt(s, M, 5.75, 6.5, 0.40, d['who'], 15, 'FFFFFF', 'bd')
    _p(s, M, 6.15, 6.5, d['role'], 11.5, 'E3EAFA')


@reg
def eg_close(prs, d):
    s = page(prs, DK)
    _photo(s, d.get('pi', 9), 6.50, 0, W - 6.50, H, (0.5, 0.3))
    gradband(s, 6.50, 0, 3.0, H, 0, c1=DK, c2=DK, a2=0.0)
    _bar(s, 'ติดต่อเรา', dark=True, n=d.get('n'))
    _mark(s, M, 1.20, 0.80, B())
    _h(s, M, 2.20, d['t'], 54, 7.0, 'FFFFFF')
    _p(s, M, 4.15, 5.6, d.get('note', ''), 12.5, SOFT)
    for i, (lab, v) in enumerate(d['items'][:3]):
        y = 5.15 + i * 0.55
        txt(s, M, y, 1.6, 0.36, lab, 11, SOFT, 'rg')
        txt(s, M + 1.70, y, 4.5, 0.36, v, 13, 'FFFFFF', 'bd')
    shp(s, 'round', W - M - 3.30, H - 1.40, 3.30, 0.80, B(), adj=0.5)
    txt(s, W - M - 3.10, H - 1.40, 2.4, 0.80, d.get('cta', ''), 13, 'FFFFFF', 'bd', an='m')
    _arrow(s, W - M - 0.45, H - 1.00, 0.22, 'FFFFFF', B())
