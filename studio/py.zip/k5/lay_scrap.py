"""20 เลย์เอาต์ชุดสมุดภาพ น้ำตาลเข้ม+ครีม+กากี — ลอกโครงจากเทมเพลต Creative Portfolio (Hannah Morales)

พื้นน้ำตาลช็อกโกแลตมีเส้นตารางจาง กับพื้นครีม/กากีมีตาราง บัตรครีมมีคลิปหนีบสีเงิน
ดาวทอง กระดาษฉีกมีเส้นบรรทัด เทปกาว แฟ้มลายจุดมีป้ายชื่อ ตารางโปรไฟล์ แถบบาร์โค้ด
หัวเรื่องเป็นตัวพิมพ์หนาสีน้ำตาลบนครีม/ครีมบนน้ำตาล (ฟอนต์ใช้ได้แค่สามตัว แทน serif ของต้นฉบับ)
ครีมบนน้ำตาล 11.5 น้ำตาลบนครีม 12.3 บนกากี 9.8
"""
from eng import *
import eng
from lay import L, reg

txt = txt_big        # ขนาดขั้นต่ำตามชุด 366 ดู eng.roomy()
chart = chart_big

M = 0.62
BR = '4A1D16'
CR = 'F6EED8'
KH = 'E2D7A6'
GOLD = 'C9A646'
MUTE = '6B4A3C'
SOFT = 'E9DCC0'        # เนื้อความบนน้ำตาล
DOTS = ['F2E9C9', 'D9E2F0', 'F4D6DA', 'DDE9CF']


def _duo(): return "duo:3A1712:F6EED8"


def _photo(s, n, x, y, w, h, focus=(0.5, 0.4)):
    return pic(s, ph('kidclass', n), x, y, w, h, focus=focus, mode=_duo())


def _grid(s, x, y, w, h, c, step=0.42):
    i = 1
    while i * step < w:
        ln(s, x + i * step, y, x + i * step, y + h, c, 0.5); i += 1
    j = 1
    while j * step < h:
        ln(s, x, y + j * step, x + w, y + j * step, c, 0.5); j += 1


def _bg(s, dark):
    shp(s, 'rect', 0, 0, W, H, BR if dark else CR)
    _grid(s, 0, 0, W, H, mix(BR, 'FFFFFF', 0.10) if dark else mix(CR, BR, 0.08))


def _star(s, cx, cy, sz, c=None):
    shp(s, 'star', cx - sz / 2, cy - sz / 2, sz, sz, c or GOLD, rot=12)


def _clip(s, cx, y, w=0.70):
    shp(s, 'round', cx - w / 2, y, w, 0.42, '9B9690', adj=0.2, shadow=('000000', 0.25, 6, 2))
    shp(s, 'round', cx - w / 2 + 0.08, y + 0.08, w - 0.16, 0.26, 'C9C4BC', adj=0.2)
    shp(s, 'arc', cx - w * 0.35, y - 0.45, w * 0.7, 0.70, '9B9690', adj=[180 * 0.6, 0, 0.12])


def _tape(s, x, y, w=1.10, rot=-8):
    shp(s, 'rect', x, y, w, 0.34, KH, a=0.85, rot=rot)


def _note(s, x, y, w, h, rot=0, lines=True):
    shp(s, 'rect', x, y, w, h, 'FBF7EC', rot=rot, shadow=('000000', 0.18, 8, 3))
    if lines and not rot:
        for k in range(1, int(h / 0.32)):
            ln(s, x + 0.12, y + k * 0.32, x + w - 0.12, y + k * 0.32, 'D7CBB0', 0.5)


def _polaroid(s, n, x, y, w, h, rot=0):
    shp(s, 'rect', x, y, w, h, 'FBF7EC', rot=rot, shadow=('000000', 0.22, 10, 3))
    p = _photo(s, n, x + 0.12, y + 0.12, w - 0.24, h - 0.50)
    p.rotation = rot


def _h(s, x, y, t, sz=44, w=7.0, dark=False, al='l'):
    txt(s, x, y, w, 2.8, t, sz, CR if dark else BR, 'bd', al, sp=0.98)


def _p(s, x, y, w, t, sz=11.5, dark=False, c=None, al='l'):
    if t: txt(s, x, y, w, 2.0, t, sz, c or (SOFT if dark else MUTE), 'rg', al, sp=1.42)


def _folder(s, x, y, w, h, i, label):
    f = DOTS[i % 4]
    shp(s, 'round2', x, y, w * 0.42, 0.30, BR, adj=0.3)
    shp(s, 'rect', x, y + 0.24, w, h - 0.24, f, line=BR, lw=1)
    for a in range(int(w / 0.22)):
        for b in range(int((h - 0.3) / 0.22)):
            if (a + b) % 2 == 0:
                shp(s, 'oval', x + 0.08 + a * 0.22, y + 0.34 + b * 0.22, 0.06, 0.06, BR)
    _tape(s, x + 0.18, y + h * 0.42, w - 0.36, -6)
    txt(s, x + 0.18, y + h * 0.42 - 0.06, w - 0.36, 0.46, label, 12, BR, 'bd', 'c', 'm')


# ══ เลย์เอาต์ตามรูปอ้างอิง ═════════════════════════════════════════════════

@reg
def sc_cover(prs, d):
    s = page(prs)
    _bg(s, True)
    shp(s, 'round', 1.20, 1.10, W - 2.40, H - 2.00, KH, adj=0.05)
    shp(s, 'round', 1.40, 1.30, W - 2.80, H - 2.40, None, line=BR, lw=1.2, adj=0.05)
    _clip(s, W / 2, 0.70, 1.00)
    _h(s, 1.90, 1.85, d['t'], 54, 6.5)
    txt(s, 1.90, 4.40, 5.4, 0.60, d['name'], 26, BR, 'md')
    _p(s, 1.90, 5.05, 5.0, d.get('s', ''), 12, c=BR)
    _photo(s, d.get('pi', 0), 7.60, 1.75, 3.70, 3.40, (0.5, 0.3))
    for k in range(26):
        shp(s, 'rect', 7.60 + k * 0.142, 5.40, 0.07 if k % 3 else 0.11, 0.60, BR)
    _star(s, 7.30, 1.70, 0.60)
    _star(s, 11.50, 5.70, 0.50)


@reg
def sc_hello(prs, d):
    s = page(prs)
    _bg(s, True)
    shp(s, 'rect', 6.40, 0, W - 6.40, H, KH)
    _grid(s, 6.40, 0, W - 6.40, H, mix(KH, BR, 0.10))
    _star(s, 0.95, 0.85, 0.42)
    _h(s, M, 1.20, d['t'], 50, 5.4, True)
    _p(s, M, 3.10, 3.0, d['note'], 13, True)
    _p(s, M, 5.20, 3.0, d.get('note2', ''), 12, True)
    _polaroid(s, d.get('pi', 0), 3.75, 2.90, 2.50, 3.10, -4)
    _clip(s, 4.95, 2.60)
    _note(s, 7.40, 0.90, W - M - 7.40, 5.80)
    txt(s, 7.70, 1.10, 4.0, 0.50, 'ข้อมูลครู', 18, BR, 'bd')
    for i, (lab, v) in enumerate(d['items'][:7]):
        y = 1.75 + i * 0.66
        txt(s, 7.70, y, 1.70, 0.60, lab, 11, BR, 'bd', an='m')
        txt(s, 9.40, y, 2.90, 0.60, v, 11, MUTE, 'rg', an='m')
        ln(s, 7.70, y + 0.62, W - M - 0.30, y + 0.62, 'D7CBB0', 0.6)


@reg
def sc_folders(prs, d):
    s = page(prs)
    _bg(s, True)
    shp(s, 'rect', 5.20, 0, W - 5.20, H, CR)
    _h(s, M, 0.70, d['t'], 48, 4.6, True)
    _polaroid(s, d.get('pi', 3), 1.00, 2.95, 3.30, 2.60, 3)
    _clip(s, 2.70, 2.65)
    _note(s, 0.70, 5.55, 2.40, 1.50, -6, False)
    txt(s, 0.85, 5.70, 2.0, 1.20, d.get('k', ''), 12, BR, 'md', sp=1.2)
    _star(s, 4.60, 6.50, 0.55)
    for i, (label, items) in enumerate(d['items'][:4]):
        y = 0.55 + i * 1.68
        _folder(s, 5.70, y, 2.30, 1.40, i, label)
        for k, t in enumerate(items[:3]):
            shp(s, 'oval', 8.40, y + 0.35 + k * 0.40, 0.09, 0.09, BR)
            txt(s, 8.60, y + 0.20 + k * 0.40, 4.0, 0.40, t, 12, BR, 'rg')


@reg
def sc_why(prs, d):
    s = page(prs)
    _bg(s, False)
    _h(s, M, 0.60, d['t'], 50, 7.5)
    for i, (h_, body) in enumerate(d['items'][:3]):
        x = M + 0.20 + i * 4.10
        rot = (-3, 2, -2)[i]
        _note(s, x, 2.70, 3.60, 3.60, 0, True)
        _tape(s, x + 1.20, 2.55, 1.20, rot * 2)
        txt(s, x + 0.30, 3.05, 3.0, 0.50, h_, 18, BR, 'bd')
        _p(s, x + 0.30, 3.70, 3.0, body, 12, c=BR)
    _star(s, 12.30, 1.00, 0.6)


@reg
def sc_feature(prs, d):
    s = page(prs)
    _bg(s, False)
    shp(s, 'rect', 0, 0, W, H, KH, a=0.6)
    _h(s, M, 0.60, d['t'], 46, 6.6)
    for i, (lab, v) in enumerate(d['items'][:4]):
        y = 2.30 + i * 1.10
        txt(s, M, y, 4.0, 0.40, lab, 15, BR, 'bd')
        _p(s, M, y + 0.42, 6.0, v, 12, c=MUTE)
    _polaroid(s, d.get('pi', 6), 7.40, 1.10, 2.70, 3.40, 4)
    _polaroid(s, d.get('pi2', 7), 9.80, 3.00, 2.70, 3.40, -3)
    _star(s, 7.30, 5.80, 0.5)


# ══ อีก 15 เลย์เอาต์ในระบบเดียวกัน ════════════════════════════════════════

@reg
def sc_toc(prs, d):
    s = page(prs)
    _bg(s, False)
    _h(s, M, 0.70, d['t'], 50, 5.0)
    _polaroid(s, d.get('pi', 1), M + 0.20, 3.10, 3.40, 3.60, -3)
    _clip(s, M + 1.90, 2.82)
    for i, t in enumerate(d['items'][:6]):
        y = 0.90 + i * 1.00
        _star(s, 6.00, y + 0.32, 0.38)
        txt(s, 6.45, y, 6.2, 0.64, t, 18, BR, 'md', an='m')
        ln(s, 6.45, y + 0.80, W - M, y + 0.80, 'D7CBB0', 0.8)


@reg
def sc_div_dark(prs, d):
    s = page(prs)
    _bg(s, True)
    _polaroid(s, d.get('pi', 2), 7.60, 1.00, 4.60, 5.20, 4)
    _clip(s, 9.90, 0.70, 0.9)
    txt(s, M, 2.30, 5.0, 0.40, d.get('k', ''), 14, GOLD, 'md')
    _h(s, M, 2.80, d['t'], 54, 6.6, True)
    _p(s, M, 5.00, 6.0, d.get('note', ''), 13, True)
    _star(s, 6.70, 6.40, 0.6)


@reg
def sc_div_khaki(prs, d):
    s = page(prs, KH)
    _grid(s, 0, 0, W, H, mix(KH, BR, 0.10))
    shp(s, 'round', 1.20, 1.30, W - 2.40, H - 2.60, CR, adj=0.05)
    _clip(s, W / 2, 0.90, 1.00)
    txt(s, 0, 2.40, W, 0.40, d.get('k', ''), 14, MUTE, 'md', 'c')
    _h(s, 1.20, 2.90, d['t'], 56, W - 2.40, al='c')
    _p(s, 2.50, 4.80, W - 5.0, d.get('note', ''), 13, c=MUTE, al='c')
    _star(s, 1.60, 1.70, 0.6)
    _star(s, W - 1.60, H - 1.70, 0.6)


@reg
def sc_schedule(prs, d):
    s = page(prs)
    _bg(s, False)
    _h(s, M, 0.60, d['t'], 44, 9.0)
    cols = d['colw']; tw = W - M * 2; y0 = 1.95; rh = 0.78
    xs = [M]
    for f in cols[:-1]: xs.append(xs[-1] + tw * f)
    shp(s, 'rect', M, y0, tw, 0.60, BR)
    for j, hd in enumerate(d['head']):
        txt(s, xs[j] + 0.22, y0, tw * cols[j] - 0.44, 0.60, hd, 12, CR, 'bd', 'l' if j == 0 else 'c', 'm')
    for i, row in enumerate(d['rows']):
        y = y0 + 0.60 + i * rh
        shp(s, 'rect', M, y, tw, rh, 'FBF7EC' if i % 2 == 0 else KH)
        for j, cell in enumerate(row):
            txt(s, xs[j] + 0.22, y, tw * cols[j] - 0.44, rh, cell, 12.5 if j == 0 else 12, BR,
                'bd' if j == 0 else 'rg', 'l' if j == 0 else 'c', 'm')


@reg
def sc_chart_reading(prs, d):
    s = page(prs)
    _bg(s, True)
    _h(s, M, 0.60, d['t'], 42, 5.0, True)
    _p(s, M, 2.40, 4.4, d.get('note', ''), 12, True)
    for i, (v, lab) in enumerate(d['items'][:2]):
        y = 4.20 + i * 1.40
        _note(s, M, y, 4.40, 1.20, 0, False)
        txt(s, M + 0.30, y, 1.9, 1.20, v, 30, BR, 'bd', an='m')
        _p(s, M + 2.20, y + 0.30, 2.1, lab, 10.5, c=BR)
    _note(s, 5.50, 0.60, W - M - 5.50, 6.30, 0, False)
    _tape(s, 8.60, 0.45, 1.40, -4)
    chart(s, 'col', 5.70, 0.85, W - M - 5.90, 5.85, d['cats'], [(d['sname'], d['vals'])],
          [KH] * (len(d['vals']) - 1) + [BR], labels=True, fmt='0', gap=50, sz=12, c=BR, vary=True)


@reg
def sc_chart_attend(prs, d):
    s = page(prs)
    _bg(s, False)
    _h(s, M, 0.60, d['t'], 42, 8.0)
    _note(s, M, 2.00, 8.20, 4.90, 0, False)
    chart(s, 'line', M + 0.20, 2.20, 7.80, 4.50, d['cats'], [(d['sname'], d['vals'])], [BR], labels=True,
          fmt='0"%"', sz=11, c=BR, lw=3, minv=80, maxv=100)
    for i, (v, lab) in enumerate(d['items'][:3]):
        y = 2.00 + i * 1.66
        shp(s, 'rect', 9.10, y, W - M - 9.10, 1.48, BR)
        txt(s, 9.35, y + 0.12, 3.2, 0.60, v, 26, CR, 'bd')
        _p(s, 9.35, y + 0.78, 3.2, lab, 10.5, True)


@reg
def sc_time(prs, d):
    s = page(prs, KH)
    _grid(s, 0, 0, W, H, mix(KH, BR, 0.10))
    _h(s, M, 0.60, d['t'], 42, 7.0)
    cols = [BR, GOLD, 'A9886F', CR]
    it = d['items'][:4]
    chart(s, 'donut', 0.60, 2.10, 4.70, 4.70, [x[0] for x in it], [('ร้อยละ', [x[1] for x in it])], cols, labels=False, hole=58)
    txt(s, 0.60, 4.05, 4.70, 0.60, d['big'], 28, BR, 'bd', 'c')
    txt(s, 0.60, 4.65, 4.70, 0.30, d['biglab'], 10.5, MUTE, 'rg', 'c')
    for i, (lab, v, body) in enumerate(it):
        y = 2.15 + i * 1.20
        _note(s, 5.85, y, W - M - 5.85, 1.04, 0, False)
        shp(s, 'rect', 6.10, y + 0.38, 0.28, 0.28, cols[i], line=BR if i == 3 else None, lw=0.8)
        txt(s, 6.60, y + 0.12, 4.0, 0.40, lab, 14, BR, 'bd')
        _p(s, 6.60, y + 0.55, 4.4, body, 10.5)
        txt(s, 10.80, y + 0.12, 1.70, 0.80, f'{v}%', 20, BR, 'bd', 'r', 'm')


@reg
def sc_rules(prs, d):
    s = page(prs)
    _bg(s, True)
    _h(s, M, 0.60, d['t'], 46, 9.0, True)
    for i, t in enumerate(d['items'][:6]):
        x = M + (i % 3) * 4.10
        y = 2.10 + (i // 3) * 2.45
        rot = (-2, 1.5, -1, 2, -1.5, 1)[i]
        _note(s, x, y, 3.70, 2.15, rot, False)
        _star(s, x + 0.45, y + 0.45, 0.42)
        txt(s, x + 0.30, y + 0.85, 3.10, 1.20, t, 14, BR, 'md', sp=1.2)


@reg
def sc_gallery(prs, d):
    s = page(prs)
    _bg(s, False)
    _h(s, 0, 0.50, d['t'], 44, W, al='c')
    spec = [(0.80, 1.90, 2.80, -4), (3.75, 2.25, 2.80, 3), (6.70, 1.90, 2.80, -2), (9.65, 2.25, 2.80, 4)]
    for (x, y, w, r), (n, cap) in zip(spec, d['items'][:4]):
        _polaroid(s, n, x, y, w, 3.40, r)
        _tape(s, x + 0.80, y - 0.18, 1.10, r * 2)
        txt(s, x, y + 3.55, w, 0.40, cap, 13, BR, 'md', 'c')


@reg
def sc_home(prs, d):
    s = page(prs)
    _bg(s, False)
    shp(s, 'rect', 0, 0, 5.30, H, BR)
    _grid(s, 0, 0, 5.30, H, mix(BR, 'FFFFFF', 0.10))
    _h(s, M, 0.80, d['t'], 46, 4.4, True)
    _p(s, M, 3.00, 4.2, d.get('note', ''), 12.5, True)
    _star(s, 4.60, 6.50, 0.6)
    for i, (h_, body) in enumerate(d['items'][:4]):
        y = 0.75 + i * 1.62
        _note(s, 5.90, y, W - M - 5.90, 1.40, 0, False)
        txt(s, 6.20, y + 0.15, 0.6, 0.60, f'{i + 1}', 26, GOLD, 'bd')
        txt(s, 6.90, y + 0.18, 5.4, 0.40, h_, 15, BR, 'bd')
        _p(s, 6.90, y + 0.62, 5.4, body, 11.5)


@reg
def sc_contact(prs, d):
    s = page(prs, KH)
    _grid(s, 0, 0, W, H, mix(KH, BR, 0.10))
    _h(s, M, 0.70, d['t'], 46, 6.0)
    for i, (lab, v) in enumerate(d['items'][:4]):
        y = 2.40 + i * 1.00
        shp(s, 'rect', M, y, 1.90, 0.62, BR)
        txt(s, M, y, 1.90, 0.62, lab, 12, CR, 'bd', 'c', 'm')
        txt(s, M + 2.15, y, 5.0, 0.62, v, 15, BR, 'md', an='m')
    _polaroid(s, d.get('pi', 0), 8.40, 1.10, 3.80, 4.80, 3)
    _clip(s, 10.30, 0.80, 0.9)


@reg
def sc_quote(prs, d):
    s = page(prs)
    _bg(s, True)
    _note(s, 1.40, 1.30, W - 2.80, 4.70, -1, False)
    _tape(s, 5.70, 1.05, 1.80, -3)
    _star(s, 2.20, 2.10, 0.6)
    txt(s, 2.10, 2.50, W - 4.20, 2.40, d['t'], 26, BR, 'bd', 'c', sp=1.3)
    txt(s, 2.10, 5.05, W - 4.20, 0.40, d['who'], 13, MUTE, 'md', 'c')


@reg
def sc_thanks(prs, d):
    s = page(prs)
    _bg(s, True)
    _polaroid(s, d.get('pi', 4), 1.00, 1.30, 3.60, 4.40, -4)
    _polaroid(s, d.get('pi2', 10), 3.80, 2.20, 3.30, 4.10, 5)
    _clip(s, 2.70, 1.00)
    _h(s, 7.70, 1.60, d['t'], 56, 5.0, True)
    _p(s, 7.70, 4.00, 4.8, d.get('note', ''), 13, True)
    _star(s, 8.10, 5.70, 0.6)
    _star(s, 9.00, 6.10, 0.42)


@reg
def sc_class_stats(prs, d):
    s = page(prs)
    _bg(s, True)
    _h(s, M, 0.60, d['t'], 46, 9.0, True)
    cw = (W - M * 2 - 0.60) / 4
    for i, (v, lab) in enumerate(d['items'][:4]):
        x = M + i * (cw + 0.20)
        _note(s, x, 2.30, cw, 3.40, 0, False)
        _clip(s, x + cw / 2, 2.00, 0.60)
        txt(s, x, 2.90, cw, 1.10, v, 44, BR, 'bd', 'c')
        _p(s, x + 0.25, 4.25, cw - 0.5, lab, 12, c=BR, al='c')
    _star(s, 12.30, 6.60, 0.55)


@reg
def sc_goals(prs, d):
    s = page(prs, KH)
    _grid(s, 0, 0, W, H, mix(KH, BR, 0.10))
    _h(s, M, 0.60, d['t'], 46, 9.0)
    cw = (W - M * 2 - 0.50) / 3
    for i, (when, h_, body) in enumerate(d['items'][:3]):
        x = M + i * (cw + 0.25)
        shp(s, 'rect', x, 2.20, cw, 4.60, BR if i == 1 else 'FBF7EC', shadow=('000000', 0.18, 8, 3))
        _tape(s, x + cw / 2 - 0.55, 2.05, 1.10, (-6, 4, -3)[i])
        dark = i == 1
        txt(s, x + 0.35, 2.65, cw - 0.7, 0.40, when, 13, GOLD if dark else MUTE, 'bd')
        txt(s, x + 0.35, 3.15, cw - 0.7, 0.90, h_, 20, CR if dark else BR, 'bd', sp=1.05)
        _p(s, x + 0.35, 4.20, cw - 0.7, body, 12, dark)
