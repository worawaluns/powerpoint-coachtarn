"""20 เลย์เอาต์ชุดแอปการเงิน (OpenPay) — ลอกโครงจากเทมเพลตส้มไล่เฉด + น้ำตาลเข้ม + ขาว

การ์ดมุมขวาบนบากลาดลง (วาดเป็น freeform แก้รูปทรงต่อใน PowerPoint ได้) ตัวเลขยักษ์ตัวหนา
หัวกระดาษ: ชื่อบริษัทซ้าย เลขหน้าขวา ปีมุมล่างซ้าย
สีตัวหนังสือ: บนน้ำตาลใช้ขาว บนส้ม/เหลืองอำพันใช้น้ำตาลเข้ม (ขาวบนอำพัน 2.01 บนส้ม 3.13 ไม่ผ่าน)
ยกเว้นตัวเลขยักษ์ 54pt ขึ้นไปบนส้ม ใช้ขาวได้ (ผ่านเกณฑ์ตัวใหญ่ 3:1)
"""
import math
from lxml import etree
from pptx.util import Inches, Pt
from pptx.oxml.ns import qn
import base
from eng import *
import eng
from lay import L, reg

txt = txt_big        # ขนาดขั้นต่ำตามชุด 366 ดู eng.roomy()
chart = chart_big

M = 0.62
BR = '5E1F04'          # น้ำตาลเข้ม
LG = 'F3F3F3'          # เทาอ่อน


def O(): return P['acc']
def A(): return P['acc2']
def INK(): return P['ink']


def _duo():
    return f"duo:{mix(BR, O(), 0.25)}:{mix('FFFFFF', A(), 0.22)}"


def _fill(sh, fill=None, grad=None, shadow=True):
    spPr = sh._element.spPr
    if grad:
        c1, c2, ang = grad
        g = etree.SubElement(spPr, qn('a:gradFill')); g.set('rotWithShape', '1')
        gl = etree.SubElement(g, qn('a:gsLst'))
        for pos, c in ((0, c1), (100000, c2)):
            gs = etree.SubElement(gl, qn('a:gs')); gs.set('pos', str(pos))
            etree.SubElement(gs, qn('a:srgbClr')).set('val', c)
        etree.SubElement(g, qn('a:lin')).set('ang', str(int(ang * 60000)))
        base._order(spPr)
    else:
        sh.fill.solid(); sh.fill.fore_color.rgb = base.rgb(fill)
    sh.line.fill.background()
    if shadow: base._shadow(spPr, '3A1200', 0.20, 22, 8)
    return sh


def _notch(s, x, y, w, h, fill=None, grad=None, r=0.26, nw=None, nd=None, shadow=True):
    """การ์ดมุมมนสี่มุม มุมขวาบนบากลาดลงเป็นเส้นโค้งตัว S แบบในต้นฉบับ"""
    nw = nw if nw is not None else min(0.95, w * 0.28)
    nd = nd if nd is not None else min(0.48, h * 0.22)
    pts = []

    def arc(cx, cy, a0, a1, rr=r, n=7):
        for i in range(n + 1):
            a = math.radians(a0 + (a1 - a0) * i / n)
            pts.append((cx + rr * math.cos(a), cy + rr * math.sin(a)))
    arc(x + r, y + r, 180, 270)                                  # มุมซ้ายบน
    sx, ex = x + w - nw - r * 0.6, x + w - r * 0.8
    for i in range(1, 13):                                       # ทางลาดตัว S
        t = i / 12
        pts.append((sx + (ex - sx) * t, y + nd * (1 - math.cos(math.pi * t)) / 2))
    arc(x + w - r * 0.8, y + nd + r * 0.8, 270, 360, r * 0.8)    # มุมขวาบนหลังบาก
    arc(x + w - r, y + h - r, 0, 90)
    arc(x + r, y + h - r, 90, 180)
    E = lambda v: int(Inches(v))
    fb = s.shapes.build_freeform(E(pts[0][0]), E(pts[0][1]), scale=1.0)
    fb.add_line_segments([(E(px), E(py)) for px, py in pts[1:]], close=True)
    sh = fb.convert_to_shape()
    base._nostyle(sh)
    return _fill(sh, fill, None if fill else (grad or (P['g1'], P['g2'], 315)), shadow)


def _og(): return (P['g1'], P['g2'], 315)          # ส้มไล่เฉด
def _ag(): return ('FF9500', 'FFB443', 315)        # อำพันไล่เฉด


def _chrome(s, d, light=False, yr=True):
    c = 'FFFFFF' if light else INK()
    txt(s, M, 0.36, 3.0, 0.26, d.get('brand', 'บริษัทของคุณ'), 9, c, 'md')
    if d.get('n'):
        txt(s, W - M - 1.4, 0.36, 1.4, 0.26, f"หน้า {int(d['n'])}", 9, c, 'md', 'r')
    if yr:
        txt(s, M, H - 0.56, 1.5, 0.26, d.get('yr', '2570'), 9, c, 'md')


def _h(s, x, y, t, sz=36, w=6.5, c=None, al='l', wt='md'):
    txt(s, x, y, w, 2.4, t, sz, c or INK(), wt, al, sp=1.05)


def _p(s, x, y, w, t, sz=11.5, c=None, al='l'):
    if t: txt(s, x, y, w, 2.0, t, sz, c or mix('FFFFFF', INK(), 0.82), 'rg', al, sp=1.38)


def _pill(s, x, y, t, fill=None, c=None, sz=11):
    w = len(t) * 0.11 + 0.36
    shp(s, 'round', x, y, w, 0.40, fill or A(), adj=0.22)
    txt(s, x, y, w, 0.40, t, sz, c or INK(), 'bd', 'c', 'm')
    return w


def _ring_icon(s, cx, cy, ic, d=0.70, fill=None, c='FFFFFF', line=None):
    shp(s, 'oval', cx - d / 2, cy - d / 2, d, d, fill, line=line, lw=1.4)
    icon(s, ic, cx, cy, d * 0.48, c)


def _photo(s, n, x, y, w, h, adj=0.10, focus=(0.5, 0.35), topic=None):
    pic(s, ph(topic or 'office', n), x, y, w, h, geom='roundRect', adj=adj, focus=focus, mode=_duo())


# ══ เลย์เอาต์ตามรูปอ้างอิง ═════════════════════════════════════════════════

@reg
def op_cover(prs, d):
    s = page(prs)
    gradband(s, 0, 0, W, H, 315, c1=P['g1'], c2=P['g2'])
    _chrome(s, {**d, 'n': ''}, yr=False)
    txt(s, W - M - 1.4, 0.36, 1.4, 0.26, d.get('yr', '2570'), 9, INK(), 'md', 'r')
    _h(s, M, 0.95, d['t'], 60, 12.0, 'FFFFFF', wt='bd')
    _p(s, M, 3.05, 9.5, d.get('s', ''), 15, INK())
    cw = (W - M * 2 - 0.50) / 3
    for i, (ic, h_, body) in enumerate(d['items'][:3]):
        x = M + i * (cw + 0.25)
        _notch(s, x, 4.30, cw, 2.60, 'FFFFFF')
        _ring_icon(s, x + 0.70, 4.30, ic, 0.86, A(), INK())
        txt(s, x + 0.36, 4.95, cw - 0.7, 0.50, h_, 20, INK(), 'bd')
        _p(s, x + 0.36, 5.55, cw - 0.72, body, 11.5)


@reg
def op_tiers(prs, d):
    s = page(prs, BR)
    _chrome(s, d, True)
    _h(s, M, 0.85, d['t'], 36, 6.0, 'FFFFFF')
    _p(s, 7.30, 0.90, 5.4, d.get('note', ''), 11.5, 'F3D9C8')
    spec = [(1.70, 3.15, 'FFFFFF', None), (4.55, 2.55, None, _ag()), (7.40, 1.95, None, _og())]
    for i, ((v, lab, body), (x, y, f, g)) in enumerate(zip(d['items'][:3], spec)):
        w, h = 2.70, 2.95
        _notch(s, x, y, w, h, f, g)
        txt(s, x + 0.30, y + 0.30, w - 0.6, 1.30, v, 66, 'FFFFFF' if i == 2 else INK(), 'bd', 'c')
        txt(s, x + 0.30, y + 1.70, w - 0.6, 0.34, lab, 13, INK(), 'bd')
        _p(s, x + 0.30, y + 2.06, w - 0.6, body, 10.5, INK())
    _p(s, 10.40, 5.25, 2.4, d.get('note2', ''), 11, 'F3D9C8')


@reg
def op_growth(prs, d):
    s = page(prs)
    gradband(s, 0, 0, W, H, 315, c1=P['g1'], c2=P['g2'])
    _chrome(s, d)
    _h(s, M, 0.85, d['t'], 40, 5.5)
    _p(s, M, 1.75, 4.6, d.get('note', ''), 12.5, INK())
    (y1, v1), (y2, v2) = d['items'][:2]
    _pill(s, 6.70, 1.30, y1)
    txt(s, 5.60, 1.60, 7.0, 2.0, v1, 110, 'FFFFFF', 'bd', 'r')
    sh = s.shapes[-1]
    rPr = sh.text_frame.paragraphs[0].runs[0]._r.get_or_add_rPr()
    sf = rPr.find(qn('a:solidFill'))
    etree.SubElement(sf.find(qn('a:srgbClr')), qn('a:alpha')).set('val', '45000')   # ตัวเลขปีก่อนจางลง
    _pill(s, 4.90, 3.90, y2)
    txt(s, 3.90, 4.20, 8.8, 2.2, v2, 140, 'FFFFFF', 'bd')


@reg
def op_market(prs, d):
    s = page(prs, LG)
    shp(s, 'rect', 0, 0, 5.20, H, 'FFFFFF')
    _chrome(s, d)
    _h(s, M, 1.10, d['t'], 36, 4.4)
    _p(s, M, 2.55, 4.0, d.get('note', ''), 11.5)
    _photo(s, d.get('pi', 6), 7.40, 0.75, 5.30, 3.05, 0.10, (0.5, 0.3))
    _photo(s, d.get('pi2', 10), 9.25, 4.05, 3.45, 2.85, 0.10, (0.3, 0.3))
    _notch(s, 5.55, 4.30, 3.45, 2.05)
    txt(s, 5.85, 4.45, 3.0, 1.10, d['big'], 54, 'FFFFFF', 'bd')
    txt(s, 5.88, 5.55, 3.0, 0.40, d['biglab'], 13, INK(), 'bd')
    _p(s, M, 4.70, 4.0, d.get('note2', ''), 11)


@reg
def op_columns(prs, d):
    s = page(prs)
    _chrome(s, d)
    _h(s, M, 1.10, d['t'], 36, 5.0)
    _p(s, M, 2.55, 4.5, d.get('note', ''), 11.5)
    n = len(d['items'][:3]); cw = 1.75; x0 = 6.35; top, bot = 0.85, 6.85
    mx = max(v for _, v, _ in d['items'][:3]) or 1
    for i, (yr, v, lab) in enumerate(d['items'][:3]):
        x = x0 + i * (cw + 0.30)
        _notch(s, x, top, cw, bot - top, 'E4E4E4', shadow=False, nw=0.55, nd=0.32)
        hh = (bot - top - 0.5) * v / mx
        _notch(s, x, bot - hh, cw, hh, None, _og() if i == n - 1 else _ag(), nw=0.55, nd=0.32)
        txt(s, x, bot - hh + 0.42, cw, 0.50, yr, 22, INK(), 'bd', 'c')
        txt(s, x, bot - hh + 0.95, cw, 0.30, lab, 10.5, INK(), 'md', 'c')
    for i, (v, lab) in enumerate(d.get('stats', [])[:2]):
        y = 4.30 + i * 1.20
        txt(s, M, y, 4.5, 0.60, v, 30, O(), 'bd')
        _p(s, M, y + 0.62, 4.5, lab, 11)


@reg
def op_revenue(prs, d):
    s = page(prs)
    _chrome(s, d)
    _h(s, M, 0.85, d['t'], 34, 9.0)
    cw = (W - M * 2 - 0.40) / 2
    for i, (ic, body, v) in enumerate(d['items'][:2]):
        x = M + i * (cw + 0.40)
        _notch(s, x, 2.10, cw, 4.30, None, _ag() if i == 0 else _og())
        _p(s, x + 0.45, 2.45, cw - 1.60, body, 12, INK())
        txt(s, x + 0.40, 3.55, cw - 0.8, 1.70, v, 88, 'FFFFFF' if i else INK(), 'bd', 'r')
        _ring_icon(s, x + 0.85, 5.55, ic, 0.80, None, INK(), INK())
    _p(s, M, 6.52, 11.5, d.get('note', ''), 10.5, P['mute'])


@reg
def op_div_brown(prs, d):
    s = page(prs, BR)
    _chrome(s, d, True)
    _p(s, M, 1.30, 5.0, d.get('k', ''), 13, 'F3D9C8')
    _h(s, M, 2.40, d['t'], 72, 12.0, 'FFFFFF', wt='bd')
    _h(s, M, 3.75, d['t2'], 96, 12.0, mix(O(), 'FFFFFF', 0.10), wt='bd')
    _notch(s, 10.20, 0.95, 2.50, 1.70, None, _og(), nw=0.6, nd=0.32)
    icon(s, d.get('ic', 'rocket'), 11.45, 1.80, 0.80, INK())


# ══ อีก 13 เลย์เอาต์ในระบบเดียวกัน ════════════════════════════════════════

@reg
def op_toc(prs, d):
    s = page(prs, LG)
    _chrome(s, d)
    _h(s, M, 1.10, d['t'], 40, 4.4)
    _p(s, M, 2.55, 4.0, d.get('note', ''), 11.5)
    for i, (no, lab) in enumerate(d['items'][:6]):
        col, row = i // 3, i % 3
        x = 5.40 + col * 3.75; y = 1.10 + row * 1.95
        hot = i == 0
        _notch(s, x, y, 3.55, 1.70, None if hot else 'FFFFFF', _og() if hot else None, nw=0.6, nd=0.3)
        txt(s, x + 0.35, y + 0.28, 1.2, 0.40, f'หน้า {no}', 11, INK(), 'md')
        txt(s, x + 0.35, y + 0.75, 2.9, 0.80, lab, 17, INK(), 'bd', sp=1.05)


@reg
def op_problem(prs, d):
    s = page(prs, BR)
    _chrome(s, d, True)
    _h(s, M, 0.85, d['t'], 36, 6.0, 'FFFFFF')
    txt(s, M, 2.50, 5.6, 1.70, d['big'], 110, A(), 'bd')
    _p(s, M, 4.40, 5.0, d['biglab'], 13, 'F3D9C8')
    for i, (ic, h_, body) in enumerate(d['items'][:3]):
        y = 1.25 + i * 1.85
        _notch(s, 6.90, y, 5.80, 1.62, 'FFFFFF', nw=0.6, nd=0.3)
        _ring_icon(s, 7.55, y + 0.81, ic, 0.80, A(), INK())
        txt(s, 8.20, y + 0.24, 4.2, 0.40, h_, 15, INK(), 'bd')
        _p(s, 8.20, y + 0.70, 4.2, body, 11, INK())


@reg
def op_chart_users(prs, d):
    s = page(prs)
    _chrome(s, d)
    _h(s, M, 0.85, d['t'], 34, 5.0)
    _p(s, M, 2.40, 4.4, d.get('note', ''), 11.5)
    for i, (v, lab) in enumerate(d['items'][:2]):
        y = 3.60 + i * 1.55
        _notch(s, M, y, 4.20, 1.35, None, _og() if i == 0 else _ag(), nw=0.55, nd=0.28)
        txt(s, M + 0.30, y + 0.16, 3.6, 0.62, v, 30, INK(), 'bd')
        _p(s, M + 0.30, y + 0.80, 3.6, lab, 10.5, INK())
    shp(s, 'round', 5.40, 0.85, W - M - 5.40, 6.05, LG, adj=0.06)
    chart(s, 'col', 5.65, 1.10, W - M - 5.90, 5.60, d['cats'], [(d['sname'], d['vals'])],
          [A()] * (len(d['vals']) - 1) + [O()], labels=True, fmt='0.0', gap=55, sz=11, c=INK(), vary=True)


@reg
def op_donut(prs, d):
    s = page(prs, LG)
    _chrome(s, d)
    _h(s, M, 0.85, d['t'], 34, 6.0)
    cols = [O(), A(), BR]
    it = d['items'][:3]
    chart(s, 'donut', 0.80, 2.00, 4.80, 4.80, [x[0] for x in it], [('ล้านบาท', [x[1] for x in it])],
          cols, labels=False, hole=62)
    txt(s, 0.80, 3.95, 4.80, 0.62, d['big'], 30, INK(), 'bd', 'c')
    txt(s, 0.80, 4.58, 4.80, 0.32, d['biglab'], 11, P['mute'], 'rg', 'c')
    for i, (lab, v, pct, body) in enumerate(it):
        y = 2.00 + i * 1.62
        _notch(s, 6.20, y, 6.50, 1.42, 'FFFFFF', nw=0.55, nd=0.28)
        shp(s, 'oval', 6.55, y + 0.52, 0.38, 0.38, cols[i])
        txt(s, 7.15, y + 0.22, 3.2, 0.40, lab, 15, INK(), 'bd')
        _p(s, 7.15, y + 0.66, 3.4, body, 10.5, INK())
        txt(s, 10.30, y + 0.20, 2.10, 0.50, f'{v:g} ล.', 22, O() if i != 1 else INK(), 'bd', 'r')
        txt(s, 10.30, y + 0.78, 2.10, 0.30, f'{pct}%', 11, P['mute'], 'md', 'r')


@reg
def op_line(prs, d):
    s = page(prs, BR)
    _chrome(s, d, True)
    _h(s, M, 0.85, d['t'], 34, 7.0, 'FFFFFF')
    _p(s, M, 1.85, 6.5, d.get('note', ''), 11.5, 'F3D9C8')
    chart(s, 'line', M - 0.1, 2.55, 8.60, 4.40, d['cats'], [(d['sname'], d['vals'])], [A()], labels=True,
          fmt='#,##0', sz=11, c='F3D9C8', lw=3.5, minv=0)
    for i, (v, lab) in enumerate(d['items'][:2]):
        y = 2.70 + i * 2.15
        _notch(s, 9.35, y, 3.35, 1.90, None, _og() if i == 0 else _ag(), nw=0.55, nd=0.3)
        txt(s, 9.65, y + 0.25, 2.9, 0.70, v, 34, INK(), 'bd')
        _p(s, 9.65, y + 1.00, 2.9, lab, 10.5, INK())


@reg
def op_table(prs, d):
    s = page(prs)
    _chrome(s, d)
    _h(s, M, 0.85, d['t'], 34, 9.0)
    cols = d['colw']; tw = W - M * 2; y0 = 2.05; rh = 0.66
    xs = [M]
    for f in cols[:-1]: xs.append(xs[-1] + tw * f)
    heads = [None, ('FFFFFF', None), (None, _ag()), (None, _og())]
    for j, hd in enumerate(d['head']):
        if j == 0: continue
        f, g = heads[j]
        _notch(s, xs[j] + 0.08, y0, tw * cols[j] - 0.16, 1.10, f, g, nw=0.45, nd=0.24)
        txt(s, xs[j] + 0.08, y0 + 0.14, tw * cols[j] - 0.16, 0.50, hd[0], 22, INK(), 'bd', 'c')
        txt(s, xs[j] + 0.08, y0 + 0.64, tw * cols[j] - 0.16, 0.30, hd[1], 10.5, INK(), 'md', 'c')
    for i, row in enumerate(d['rows']):
        y = y0 + 1.25 + i * rh
        if i % 2 == 0: shp(s, 'round', M, y, tw, rh - 0.06, LG, adj=0.25)
        for j, cell in enumerate(row):
            txt(s, xs[j] + 0.25, y, tw * cols[j] - 0.5, rh - 0.06, cell, 11.5, INK(),
                'bd' if j == 0 else 'rg', 'l' if j == 0 else 'c', 'm')


@reg
def op_steps(prs, d):
    s = page(prs, LG)
    _chrome(s, d)
    _h(s, M, 0.85, d['t'], 34, 9.0)
    _p(s, M, 1.85, 9.0, d.get('note', ''), 11.5)
    n = len(d['items'][:4]); cw = (W - M * 2 - 0.45) / n
    for i, (ic, h_, body) in enumerate(d['items'][:4]):
        x = M + i * (cw + 0.15)
        y = 3.05 + (n - 1 - i) * 0.30
        hot = i == n - 1
        _notch(s, x, y, cw, 6.90 - y, None if hot else 'FFFFFF', _og() if hot else None, nw=0.5, nd=0.28)
        _ring_icon(s, x + 0.62, y + 0.65, ic, 0.72, A() if not hot else None, INK(), None if not hot else INK())
        txt(s, x + 0.30, y + 1.25, cw - 0.6, 0.70, h_, 15, INK(), 'bd', sp=1.08)
        _p(s, x + 0.30, y + 2.00, cw - 0.6, body, 10.5, INK())


@reg
def op_quote(prs, d):
    s = page(prs)
    _chrome(s, d)
    _photo(s, d.get('pi', 13), M, 0.85, 4.70, 6.05, 0.08, (d.get('fx', 0.5), 0.3))
    _notch(s, 5.75, 0.85, W - M - 5.75, 6.05, None, _og(), nw=1.1, nd=0.55)
    icon(s, 'quote', 6.55, 1.75, 0.80, INK())
    txt(s, 6.25, 2.35, 6.10, 2.90, d['t'], 22, INK(), 'md', sp=1.32)
    txt(s, 6.25, 5.45, 5.6, 0.40, d['who'], 15, INK(), 'bd')
    _p(s, 6.25, 5.86, 5.8, d['role'], 11.5, INK())


@reg
def op_team(prs, d):
    s = page(prs, LG)
    _chrome(s, d)
    _h(s, M, 0.85, d['t'], 34, 8.0)
    cw = (W - M * 2 - 0.75) / 4
    for i, (name, role, duty, pi, fx) in enumerate(d['items'][:4]):
        x = M + i * (cw + 0.25)
        _notch(s, x, 2.00, cw, 4.90, 'FFFFFF', nw=0.6, nd=0.3)
        _photo(s, pi, x + 0.20, 2.45, cw - 0.40, 2.40, 0.10, (fx, 0.25))
        txt(s, x + 0.25, 5.00, cw - 0.5, 0.40, name, 15, INK(), 'bd')
        _pill(s, x + 0.25, 5.45, role, A() if i % 2 == 0 else O(), INK(), 10)
        _p(s, x + 0.25, 6.00, cw - 0.5, duty, 10.5)


@reg
def op_div_orange(prs, d):
    s = page(prs)
    gradband(s, 0, 0, W, H, 315, c1=P['g1'], c2=P['g2'])
    _chrome(s, d)
    txt(s, 4.6, 0.90, 8.4, 3.0, d['ghost'], 170, 'FFFFFF', 'bd', 'r')
    sh = s.shapes[-1]
    rPr = sh.text_frame.paragraphs[0].runs[0]._r.get_or_add_rPr()
    etree.SubElement(rPr.find(qn('a:solidFill')).find(qn('a:srgbClr')), qn('a:alpha')).set('val', '35000')
    _p(s, M, 3.85, 5.0, d.get('k', ''), 14, INK())
    _h(s, M, 4.30, d['t'], 60, 11.0, 'FFFFFF', wt='bd')
    _p(s, M, 5.95, 7.0, d.get('note', ''), 13, INK())


@reg
def op_roadmap(prs, d):
    s = page(prs)
    _chrome(s, d)
    _h(s, M, 0.85, d['t'], 34, 5.4)
    _p(s, M, 2.40, 5.0, d.get('note', ''), 11.5)
    n = len(d['items'][:4]); cw = (W - M * 2 - 0.30) / n
    for i, (when, h_, body) in enumerate(d['items'][:4]):
        x = M + i * (cw + 0.10)
        y = 4.65 - i * 0.82
        f, g = [('E4E4E4', None), (None, _ag()), (BR, None), (None, _og())][i]
        _notch(s, x, y, cw, 6.90 - y, f, g, nw=0.5, nd=0.28, shadow=False)
        tc = 'FFFFFF' if f == BR else INK()
        txt(s, x + 0.30, y + 0.28, cw - 0.6, 0.60, when, 26, tc, 'bd')
        txt(s, x + 0.30, y + 0.95, cw - 0.6, 0.40, h_, 13.5, tc, 'bd')
        _p(s, x + 0.30, y + 1.38, cw - 0.6, body, 10.5, 'F3D9C8' if f == BR else INK())


@reg
def op_kpi(prs, d):
    s = page(prs, LG)
    _chrome(s, d)
    _h(s, M, 0.85, d['t'], 34, 9.0)
    cw = (W - M * 2 - 0.60) / 4
    for i, (v, lab, body) in enumerate(d['items'][:4]):
        x = M + i * (cw + 0.20)
        hot = i == 1
        _notch(s, x, 2.10, cw, 4.70, None if hot else 'FFFFFF', _og() if hot else None, nw=0.55, nd=0.3)
        txt(s, x + 0.30, 2.55, cw - 0.6, 0.90, v, 40, 'FFFFFF' if hot else O(), 'bd')
        txt(s, x + 0.30, 3.65, cw - 0.6, 0.40, lab, 14, INK(), 'bd')
        _p(s, x + 0.30, 4.15, cw - 0.6, body, 11, INK())


@reg
def op_close(prs, d):
    s = page(prs, BR)
    _chrome(s, d, True)
    _h(s, M, 1.60, d['t'], 60, 7.6, 'FFFFFF', wt='bd')
    _p(s, M, 3.85, 6.4, d.get('note', ''), 13, 'F3D9C8')
    for i, (lab, v) in enumerate(d['items'][:3]):
        y = 4.85 + i * 0.62
        txt(s, M, y, 1.6, 0.40, lab, 11, 'F3D9C8', 'rg')
        txt(s, M + 1.70, y, 4.6, 0.40, v, 13, 'FFFFFF', 'bd')
    _notch(s, 8.10, 1.20, 4.60, 5.20, None, _og(), nw=1.0, nd=0.5)
    txt(s, 8.45, 1.70, 4.0, 1.40, d['big'], 66, 'FFFFFF', 'bd')
    _p(s, 8.50, 3.25, 3.9, d['biglab'], 13, INK())
    _ring_icon(s, 9.05, 5.55, 'arrow-up-right', 0.90, None, INK(), INK())
