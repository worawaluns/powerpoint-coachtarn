"""20 เลย์เอาต์ชุด Zero-Waste (Trash Talk) — ลอกโครงจากเทมเพลตเขียว+เหลืองมะนาวแบบภาพตัดแปะ

พื้นกระดาษยับ ผ้าตาหมากรุกเขียว ขอบกระดาษฉีก กระดาษสมุดตาราง รูปโพลารอยด์ติดหมุด
สายฟ้า ระเบิดดาว ดอกจันเหลืองแบบวาดมือ หัวเรื่องตัวหนาเขียวมีแผ่นรองเหลือง
พื้นผิวทั้งหมดวาดเองด้วย tex.py (ไม่ใช่รูปของใคร)
ตัวหนังสือบนเหลืองใช้เขียวเข้มเกือบดำ เขียวบนเหลือง (3.91) ใช้กับหัวเรื่องตัวใหญ่เท่านั้น
"""
import math
import os
from pptx.enum.shapes import MSO_SHAPE
import base
from eng import *
import eng
from lay import L, reg

txt = txt_big        # ขนาดขั้นต่ำตามชุด 366 ดู eng.roomy()
chart = chart_big

base.KIND.update(bolt=MSO_SHAPE.LIGHTNING_BOLT, burst=MSO_SHAPE.EXPLOSION2, burst1=MSO_SHAPE.EXPLOSION1,
                 cloud=MSO_SHAPE.CLOUD)

M = 0.62
TEX = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'tex')


def G(): return P['acc']
def Y(): return P['acc2']
def INK(): return P['ink']


def _t(name): return os.path.join(TEX, name)


def _duo():
    return f"duo:{mix(INK(), G(), 0.35)}:{mix('FFFFFF', Y(), 0.18)}"


def _paper(s):
    pic(s, _t('paper.jpg'), 0, 0, W, H)


def _gingham(s, x=0, y=0, w=W, h=H, lime=False):
    pic(s, _t('gingham_lime.jpg' if lime else 'gingham_green.jpg'), x, y, w, h)


def _torn(s, name, x, y, w, h, keep='top'):
    pic(s, _t(name), x, y, w, h, focus=(0.5, 0.0 if keep == 'top' else 1.0))


def _photo(s, n, x, y, w, h, rot=0, geom=None, adj=None, focus=(0.5, 0.45), shadow=None):
    p = pic(s, ph('waste', n), x, y, w, h, geom=geom, adj=adj, focus=focus, mode=_duo(), shadow=shadow)
    if rot: p.rotation = rot
    return p


def _polaroid(s, n, x, y, w, h, rot=0, pin=True):
    shp(s, 'rect', x, y, w, h, 'FFFFFF', rot=rot, shadow=('000000', 0.22, 10, 4))
    _photo(s, n, x + 0.10, y + 0.10, w - 0.20, h - 0.42, rot)
    if pin:
        shp(s, 'oval', x + w / 2 - 0.17, y - 0.12, 0.34, 0.34, 'B7A73A', shadow=('000000', 0.30, 6, 3))
        shp(s, 'oval', x + w / 2 - 0.09, y - 0.05, 0.12, 0.12, 'E2D77A')


def _h(s, x, y, t, sz=44, w=7.0, c=None, al='l'):
    txt(s, x, y, w, 2.6, t, sz, c or G(), 'bd', al, sp=1.0)


def _p(s, x, y, w, t, sz=11.5, c=None, al='l'):
    if t: txt(s, x, y, w, 2.2, t, sz, c or INK(), 'rg', al, sp=1.36)


def _pm(s, x, y, w, t, sz=12, c=None, al='l'):
    if t: txt(s, x, y, w, 2.2, t, sz, c or INK(), 'md', al, sp=1.3)


def _blob(s, x, y, w, h, c=None, rot=-1.5):
    shp(s, 'round', x, y, w, h, c or Y(), adj=0.5, rot=rot)


def _tag(s, x, y, t, w=None, fill='FFFFFF', c=None, sz=11, rot=0):
    w = w or len(t) * 0.098 + 0.40
    shp(s, 'rect', x, y, w, 0.40, fill, rot=rot, shadow=('000000', 0.18, 6, 2))
    txt(s, x, y, w, 0.40, t, sz, c or G(), 'md', 'c', 'm')
    return w


def _aster(s, cx, cy, sz, c=None, rot=8):
    c = c or Y()
    for a in (0, 45, 90, 135):
        shp(s, 'round', cx - sz * 0.10, cy - sz / 2, sz * 0.20, sz, c, adj=0.5, rot=a + rot)


def _bolt(s, x, y, w, h, c=None, rot=0):
    shp(s, 'bolt', x, y, w, h, c or Y(), rot=rot)


def _stick(s, x, y, w, h, c=None, rot=0):
    """เทปกาวแปะมุม"""
    shp(s, 'rect', x, y, w, h, c or mix(Y(), 'FFFFFF', 0.35), a=0.85, rot=rot)


def _bullets(s, x, y, w, items, sz=12, gap=0.62, c=None, star=None):
    for i, t in enumerate(items):
        yy = y + i * gap
        _aster(s, x + 0.12, yy + 0.16, 0.22, star or G(), 0)
        _p(s, x + 0.40, yy, w - 0.40, t, sz, c)


# ══ เลย์เอาต์ตามรูปอ้างอิง ═════════════════════════════════════════════════

@reg
def zw_cover(prs, d):
    s = page(prs)
    _gingham(s)
    pic(s, _t('paper.jpg'), 1.70, 1.10, 9.90, 5.20, geom='cloud')
    shp(s, 'burst', 0.20, 2.10, 3.70, 3.30, Y(), rot=-8)
    shp(s, 'oval', 0.55, 4.60, 1.50, 1.50, INK(), shadow=('000000', 0.30, 10, 4))
    icon(s, 'megaphone', 1.30, 5.35, 0.85, Y())
    _bolt(s, 3.05, 2.55, 0.90, 1.30, G(), 12)
    _aster(s, 1.00, 0.95, 0.80)
    _aster(s, 11.95, 6.55, 0.80)
    _aster(s, 12.60, 4.80, 0.45)
    _photo(s, d.get('pi', 18), 10.30, 0.55, 2.30, 2.30, geom='ellipse', shadow=('000000', 0.28, 10, 4))
    _photo(s, d.get('pi2', 1), 9.10, 1.75, 1.40, 1.40, geom='ellipse', shadow=('000000', 0.28, 10, 4))
    _pm(s, 3.90, 2.00, 5.6, d.get('k', ''), 13, G(), 'c')
    _blob(s, 3.55, 2.62, 6.30, 1.18)
    _blob(s, 3.30, 3.62, 6.80, 1.18, rot=1)
    _h(s, 3.20, 2.52, d['t'], 50, 7.0, al='c')
    shp(s, 'rect', 3.75, 4.98, 5.90, 0.56, G())
    txt(s, 3.75, 4.98, 5.90, 0.56, d['s'], 13.5, 'FFFFFF', 'md', 'c', 'm')


@reg
def zw_what(prs, d):
    s = page(prs, Y())
    pic(s, _t('paper.jpg'), 0, 0, W, H, a=0.13)
    _torn(s, 'torn_top.png', 8.40, -0.20, 5.20, 0.95, 'bottom')
    _photo(s, d.get('pi', 0), 8.55, 0.55, 4.78, 2.15)
    _photo(s, d.get('pi2', 3), 8.55, 2.70, 4.78, 2.15)
    _photo(s, d.get('pi3', 1), 8.55, 4.85, 4.78, 2.65)
    for y in (2.48, 4.62):
        _torn(s, 'torn_top.png', 8.40, y, 5.10, 0.42)
    for (t, y) in zip(d.get('tags', []), (1.70, 3.85, 6.00)):
        _tag(s, 10.10, y, t)
    p = pic(s, _t('grid_note.png'), 0.75, 0.85, 7.70, 5.90)
    p.rotation = -2
    _h(s, 1.35, 1.55, d['t'], 46, 6.6)
    _p(s, 1.45, 4.05, 6.3, d.get('note', ''), 12)
    _bolt(s, 7.70, 0.40, 0.80, 1.10, G(), 20)


@reg
def zw_laptop_chart(prs, d):
    s = page(prs)
    _paper(s)
    _torn(s, 'torn_green_top.png', -0.10, 4.15, W + 0.2, 3.45)
    _h(s, M, 0.70, d['t'], 44, 6.0)
    _p(s, 6.90, 0.85, 5.80, d.get('note', ''), 12, al='r')
    _bolt(s, 0.70, 4.50, 2.40, 1.30, Y(), 70)
    _bolt(s, 10.40, 4.40, 2.40, 1.30, Y(), -70)
    x, y, w, h = 3.30, 3.05, 6.70, 3.70
    shp(s, 'round', x, y, w, h, '141414', adj=0.04, shadow=('000000', 0.35, 16, 6))
    shp(s, 'rect', x + 0.18, y + 0.18, w - 0.36, h - 0.30, 'FFFFFF')
    chart(s, 'col', x + 0.30, y + 0.24, w - 0.60, h - 0.42, d['cats'], d['series'], [G(), Y()], labels=True,
          fmt='0.0', legend=True, gap=60, overlap=-8, sz=10.5, c=INK())
    shp(s, 'rect', x - 0.55, y + h - 0.02, w + 1.10, 0.26, 'C9CBC6')
    shp(s, 'rect', x - 0.55, y + h + 0.24, w + 1.10, 0.10, '8E918B')


@reg
def zw_6r(prs, d):
    s = page(prs)
    _paper(s)
    _h(s, M, 0.75, d['t'], 44, 7.4)
    for i, (h_, body) in enumerate(d['items'][:6]):
        x = M + (i // 3) * 3.75
        y = 2.55 + (i % 3) * 1.40
        _aster(s, x + 0.15, y + 0.18, 0.28, G(), 0)
        txt(s, x + 0.45, y, 3.1, 0.36, h_, 14, G(), 'bd')
        _p(s, x + 0.45, y + 0.42, 3.1, body, 11)
    # ต้นกระบองเพชรกับดวงอาทิตย์ ตามต้นฉบับ วาดด้วยรูปทรงล้วน
    cx = 10.40
    sun_x, sun_y, r = 9.40, 2.10, 0.85
    for k in range(12):
        a = math.radians(k * 30)
        rx, ry = sun_x + math.cos(a) * (r + 0.32), sun_y + math.sin(a) * (r + 0.32)
        shp(s, 'round', rx - 0.06, ry - 0.20, 0.12, 0.40, Y(), adj=0.5, rot=k * 30 + 90)
    shp(s, 'oval', sun_x - r, sun_y - r, r * 2, r * 2, Y())
    shp(s, 'round', cx, 1.10, 1.30, 6.60, G(), adj=0.5)
    shp(s, 'round', cx - 1.05, 3.30, 0.80, 2.10, G(), adj=0.5)
    shp(s, 'round', cx - 1.05, 4.75, 1.40, 0.70, G(), adj=0.5)
    shp(s, 'round', cx + 1.55, 2.40, 0.80, 2.20, G(), adj=0.5)
    shp(s, 'round', cx + 0.95, 3.90, 1.40, 0.70, G(), adj=0.5)
    for k in range(5):
        ln(s, cx + 0.40 + (k % 2) * 0.5, 1.6 + k * 1.05, cx + 0.40 + (k % 2) * 0.5, 1.9 + k * 1.05, mix(G(), 'FFFFFF', 0.4), 1.2)


@reg
def zw_home(prs, d):
    s = page(prs)
    _paper(s)
    shp(s, 'rect', 0, 0, W, 2.30, Y())
    _torn(s, 'torn_lime_bottom.png', -0.10, 2.10, W + 0.2, 0.62, 'bottom')
    _h(s, M, 0.55, d['t'], 44, 6.8)
    _p(s, 7.60, 0.75, 5.10, d.get('note', ''), 12, al='r')
    _aster(s, 12.55, 0.45, 0.42, G())
    cw = (W - 0.20) / 3
    for i, (n, cap) in enumerate(d['items'][:3]):
        x = 0.10 + i * cw
        _photo(s, n, x, 2.90, cw - 0.06, 4.50)
        _torn(s, 'torn_top.png', x - 0.05, 2.78, cw + 0.05, 0.36)
        _tag(s, x + 0.25, 6.55 - (i % 2) * 0.45, cap, rot=-1.5 if i % 2 else 1.5, sz=11)


@reg
def zw_go(prs, d):
    s = page(prs)
    _paper(s)
    _photo(s, d.get('pi', 7), 0, 0, 4.40, 4.30)
    _torn(s, 'torn_top.png', -0.10, 4.05, 4.60, 0.42)
    _photo(s, d.get('pi2', 3), 0, 4.40, 4.40, 3.10)
    shp(s, 'burst', 8.40, 0.55, 2.60, 2.20, Y(), rot=10)
    _h(s, 5.10, 0.90, d['t'], 46, 7.6)
    _pm(s, 5.15, 2.95, 7.4, d.get('k', ''), 13)
    _bullets(s, 5.15, 3.65, 7.3, d['items'][:4], 12, 0.78)


@reg
def zw_food(prs, d):
    s = page(prs, G())
    _gingham(s, 8.80, 0, W - 8.80, H, True)
    _aster(s, 0.55, 0.50, 0.80)
    _h(s, M + 0.55, 0.55, d['t'], 48, 7.2, Y())
    _p(s, M, 2.35, 5.9, d.get('note', ''), 13, 'FFFFFF')
    for i, n in enumerate(d.get('pis', [12, 2, 11])[:3]):
        _polaroid(s, n, M + 0.05 + i * 2.05, 4.30, 1.85, 2.30, (-4, 3, -2)[i])
    shp(s, 'rect', 6.95, 1.55, 5.60, 5.10, '1D2B24', rot=-4)
    p = pic(s, _t('note_plain.jpg'), 7.25, 1.05, 5.30, 5.20)
    p.rotation = 2
    shp(s, 'round', 11.30, 0.75, 0.30, 1.00, None, line='8E8E8E', lw=2.5, adj=0.5)
    _bullets(s, 7.70, 1.65, 4.60, d['items'][:4], 12, 1.05, star=G())
    _aster(s, 12.55, 6.75, 0.70)


# ══ อีก 13 เลย์เอาต์ในระบบเดียวกัน ════════════════════════════════════════

@reg
def zw_agenda(prs, d):
    s = page(prs)
    _paper(s)
    _h(s, M, 0.70, d['t'], 44, 8.0)
    _bolt(s, 11.60, 0.40, 1.00, 1.40, Y(), 15)
    n = len(d['items'][:4]); cw = (W - M * 2 - 0.60) / 4
    for i, (h_, body) in enumerate(d['items'][:4]):
        x = M + i * (cw + 0.20)
        rot = (-3, 2, -2, 3)[i]
        y = 2.30 + (i % 2) * 0.45
        f = Y() if i % 2 == 0 else 'FFFFFF'
        shp(s, 'rect', x, y, cw, 3.80, f, rot=rot, shadow=('000000', 0.20, 10, 4))
        _stick(s, x + cw / 2 - 0.55, y - 0.18, 1.10, 0.34, rot=rot - 4)
        txt(s, x + 0.30, y + 0.40, cw - 0.60, 0.80, h_, 17, G(), 'bd', sp=1.05)
        _p(s, x + 0.30, y + 1.40, cw - 0.60, body, 11.5)


@reg
def zw_div_gingham(prs, d):
    s = page(prs)
    _gingham(s)
    _torn(s, 'torn_top.png', -0.10, 2.10, W + 0.2, 0.60)
    pic(s, _t('paper.jpg'), 0, 2.62, W, 2.40)
    _torn(s, 'torn_bottom.png', -0.10, 4.95, W + 0.2, 0.60, 'bottom')
    _h(s, 0, 2.70, d['t'], 54, W, al='c')
    _pm(s, 0, 4.30, W, d.get('note', ''), 13, INK(), 'c')
    _aster(s, 1.30, 1.20, 1.00)
    _aster(s, 12.00, 6.40, 0.90)


@reg
def zw_div_green(prs, d):
    s = page(prs, G())
    pic(s, _t('paper.jpg'), 0, 0, W, H, a=0.06)
    _polaroid(s, d.get('pi', 9), 8.20, 1.10, 4.20, 4.40, 4)
    _bolt(s, 7.00, 4.50, 1.40, 2.20, Y(), -10)
    _pm(s, M, 2.10, 6.0, d.get('k', ''), 13, 'FFFFFF')
    _h(s, M, 2.55, d['t'], 54, 7.2, Y())
    _p(s, M, 4.75, 6.0, d.get('note', ''), 13, 'FFFFFF')


@reg
def zw_kpi(prs, d):
    s = page(prs)
    _paper(s)
    _h(s, M, 0.70, d['t'], 44, 9.0)
    spec = [('burst', Y()), ('oval', 'FFFFFF'), ('oval', G()), ('burst', 'FFFFFF')]
    cw = (W - M * 2) / 4
    for i, (v, lab) in enumerate(d['items'][:4]):
        cx = M + cw * (i + 0.5)
        kind, f = spec[i]
        sz = 2.90 if kind == 'burst' else 2.50
        shp(s, kind, cx - sz / 2, 3.95 - sz / 2, sz, sz, f, rot=(-6, 0, 0, 8)[i], shadow=('000000', 0.18, 10, 4))
        tc = 'FFFFFF' if f == G() else (G() if f == 'FFFFFF' else INK())
        txt(s, cx - 1.30, 3.55, 2.60, 0.70, v, 30, tc, 'bd', 'c')
        _p(s, M + cw * i + 0.15, 5.55, cw - 0.30, lab, 11.5, al='c')
    _aster(s, 12.50, 0.80, 0.55)


@reg
def zw_trend(prs, d):
    s = page(prs, Y())
    pic(s, _t('paper.jpg'), 0, 0, W, H, a=0.13)
    _h(s, M, 0.60, d['t'], 42, 4.4)
    _p(s, M, 3.25, 3.9, d.get('note', ''), 12)
    for i, (v, lab) in enumerate(d['items'][:2]):
        y = 4.55 + i * 1.20
        txt(s, M, y, 3.8, 0.60, v, 28, G(), 'bd')
        _p(s, M, y + 0.60, 3.8, lab, 11)
    p = pic(s, _t('grid_note.png'), 4.70, 0.55, 8.30, 6.50)
    p.rotation = 1.5
    chart(s, 'line', 5.20, 1.25, 7.40, 5.20, d['cats'], [(d['sname'], d['vals'])], [G()], labels=True,
          fmt='0.0', sz=10.5, c=INK(), lw=3, minv=0, maxv=20)


@reg
def zw_donut(prs, d):
    s = page(prs)
    _paper(s)
    _h(s, M, 0.70, d['t'], 42, 6.2)
    _p(s, M, 2.45, 5.6, d.get('note', ''), 12)
    cols = [G(), Y(), mix(G(), 'FFFFFF', 0.45), INK(), 'B9BBB2']
    it = d['items'][:5]
    chart(s, 'donut', 6.60, 0.80, 5.90, 5.90, [x[0] for x in it], [('ร้อยละ', [x[1] for x in it])],
          cols, labels=False, hole=55)
    txt(s, 6.60, 3.30, 5.90, 0.70, d['big'], 32, G(), 'bd', 'c')
    txt(s, 6.60, 4.00, 5.90, 0.32, d['biglab'], 11, INK(), 'rg', 'c')
    for i, (lab, v, t) in enumerate(it):
        y = 3.70 + i * 0.64
        shp(s, 'rect', M, y + 0.06, 0.30, 0.30, cols[i])
        txt(s, M + 0.45, y, 2.6, 0.40, lab, 12.5, INK(), 'md')
        txt(s, M + 2.95, y, 0.9, 0.40, f'{v}%', 12.5, G(), 'bd', 'r')
        txt(s, M + 4.00, y, 1.8, 0.40, t, 11.5, P['mute'], 'rg')
    _aster(s, 12.55, 6.70, 0.55)


@reg
def zw_bank(prs, d):
    s = page(prs)
    _paper(s)
    _h(s, M, 0.70, d['t'], 44, 8.6)
    _p(s, M, 1.95, 8.0, d.get('note', ''), 12)
    n = len(d['steps'][:4]); cw = (W - M * 2) / n
    for i, (ic, h_, body) in enumerate(d['steps'][:4]):
        cx = M + cw * (i + 0.5)
        f = (G(), Y(), G(), Y())[i]
        shp(s, 'oval', cx - 0.62, 3.05, 1.24, 1.24, f, shadow=('000000', 0.20, 8, 3))
        icon(s, ic, cx, 3.67, 0.60, 'FFFFFF' if f == G() else INK())
        if i < n - 1:
            ln(s, cx + 0.80, 3.67, cx + cw - 0.80, 3.67, G(), 2, dash=True)
        txt(s, cx - cw / 2 + 0.10, 4.45, cw - 0.20, 0.40, h_, 14, G(), 'bd', 'c')
        _p(s, cx - cw / 2 + 0.20, 4.90, cw - 0.40, body, 11, al='c')
    for i, (v, lab) in enumerate(d['items'][:3]):
        x = M + i * 4.10
        shp(s, 'rect', x, 6.05, 3.85, 0.95, G() if i != 1 else Y(), rot=(-1, 1, -1)[i])
        txt(s, x + 0.20, 6.05, 1.75, 0.95, v, 20, 'FFFFFF' if i != 1 else INK(), 'bd', an='m')
        _p(s, x + 1.95, 6.17, 1.85, lab, 10.5, 'FFFFFF' if i != 1 else INK())


@reg
def zw_money(prs, d):
    s = page(prs, G())
    pic(s, _t('paper.jpg'), 0, 0, W, H, a=0.06)
    _h(s, M, 0.60, d['t'], 42, 4.6, Y())
    _p(s, M, 2.55, 4.2, d.get('note', ''), 12, 'FFFFFF')
    shp(s, 'burst', 0.55, 4.15, 3.30, 2.90, Y(), rot=-6)
    txt(s, 0.55, 5.05, 3.30, 0.60, d['big'], 26, INK(), 'bd', 'c')
    txt(s, 0.95, 5.65, 2.50, 0.40, d['biglab'], 10.5, INK(), 'md', 'c')
    p = pic(s, _t('note_plain.jpg'), 5.20, 0.70, 7.60, 6.20)
    p.rotation = -1.5
    _stick(s, 8.30, 0.50, 1.40, 0.40, rot=-6)
    cols = d['colw']; tw = 6.80; x0 = 5.60; y0 = 1.30; rh = 0.78
    xs = [x0]
    for f in cols[:-1]: xs.append(xs[-1] + tw * f)
    for j, hd in enumerate(d['head']):
        txt(s, xs[j] + 0.10, y0, tw * cols[j] - 0.20, rh, hd, 12, G(), 'bd', 'l' if j == 0 else 'r', 'm')
    for i, row in enumerate(d['rows']):
        y = y0 + rh * (i + 1)
        last = i == len(d['rows']) - 1
        ln(s, x0, y, x0 + tw, y, mix(P['bg'], G(), 0.35), 1 if not last else 2)
        if last: shp(s, 'rect', x0, y + 0.08, tw, rh - 0.16, Y())
        for j, cell in enumerate(row):
            txt(s, xs[j] + 0.10, y, tw * cols[j] - 0.20, rh, cell, 12, INK(),
                'bd' if (last or j == 0) else 'rg', 'l' if j == 0 else 'r', 'm')


@reg
def zw_compare(prs, d):
    s = page(prs)
    _paper(s)
    shp(s, 'rect', W / 2, 0, W / 2, H, Y())
    _h(s, 0, 0.55, d['t'], 40, W, INK(), 'c')
    for i, (lab, n, v, vl, items) in enumerate(d['sides'][:2]):
        x = 0.85 + i * (W / 2)
        _tag(s, x, 1.70, lab, 1.60, G() if i else INK(), 'FFFFFF', 12)
        _polaroid(s, n, x, 2.40, 2.70, 3.10, (-3, 3)[i], pin=False)
        txt(s, x + 3.05, 2.40, 2.6, 0.80, v, 34, G() if i else INK(), 'bd')
        _p(s, x + 3.05, 3.20, 2.5, vl, 11)
        for k, t in enumerate(items[:3]):
            _p(s, x + 3.05, 4.10 + k * 0.55, 2.6, '· ' + t, 11)
    _bolt(s, W / 2 - 0.55, 5.70, 1.10, 1.50, G(), 5)


@reg
def zw_quote(prs, d):
    s = page(prs)
    _paper(s)
    _gingham(s, 0, 0, 4.80, H)
    _polaroid(s, d.get('pi', 17), 0.70, 1.20, 3.70, 4.20, -4)
    p = pic(s, _t('note_plain.jpg'), 5.30, 1.00, 7.40, 5.40)
    p.rotation = 1
    _stick(s, 8.35, 0.80, 1.40, 0.40, rot=4)
    icon(s, 'quote', 6.20, 1.95, 0.80, G())
    txt(s, 5.95, 2.55, 6.30, 2.50, d['t'], 21, INK(), 'md', sp=1.32)
    txt(s, 5.95, 5.20, 6.0, 0.36, d['who'], 14, G(), 'bd')
    _p(s, 5.95, 5.58, 6.2, d['role'], 11, P['mute'])
    _aster(s, 12.60, 6.80, 0.70)


@reg
def zw_team(prs, d):
    s = page(prs)
    _paper(s)
    shp(s, 'rect', 0, 0, W, 2.40, G())
    _torn(s, 'torn_green_top.png', -0.10, 2.20, W + 0.2, 0.60, 'bottom')
    _h(s, M, 0.60, d['t'], 44, 9.0, Y())
    _aster(s, 12.40, 1.05, 0.70)
    cw = (W - M * 2 - 0.60) / 4
    for i, (ic, h_, body) in enumerate(d['items'][:4]):
        x = M + i * (cw + 0.20)
        shp(s, 'rect', x, 3.15, cw, 3.70, 'FFFFFF', rot=(-1.5, 1, -1, 1.5)[i], shadow=('000000', 0.16, 10, 4))
        shp(s, 'oval', x + 0.30, 3.45, 0.92, 0.92, Y() if i % 2 == 0 else G())
        icon(s, ic, x + 0.76, 3.91, 0.48, INK() if i % 2 == 0 else 'FFFFFF')
        txt(s, x + 0.30, 4.55, cw - 0.60, 0.42, h_, 15, G(), 'bd')
        _p(s, x + 0.30, 5.05, cw - 0.60, body, 11)


@reg
def zw_next(prs, d):
    s = page(prs, Y())
    pic(s, _t('paper.jpg'), 0, 0, W, H, a=0.13)
    _h(s, M, 0.60, d['t'], 44, 8.0)
    shp(s, 'burst', 10.10, 0.30, 2.90, 2.50, G(), rot=8)
    txt(s, 10.10, 1.05, 2.90, 0.60, d['big'], 24, 'FFFFFF', 'bd', 'c')
    txt(s, 10.40, 1.62, 2.30, 0.40, d['biglab'], 10.5, 'FFFFFF', 'md', 'c')
    cw = (W - M * 2 - 0.50) / 3
    for i, (h_, body, when) in enumerate(d['items'][:3]):
        x = M + i * (cw + 0.25)
        _torn(s, 'torn_top.png', x, 2.85, cw, 0.40)
        pic(s, _t('note_plain.jpg'), x, 3.20, cw, 3.55)
        _tag(s, x + 0.30, 3.35, when, None, G(), 'FFFFFF', 11)
        txt(s, x + 0.30, 3.95, cw - 0.60, 0.80, h_, 16, G(), 'bd', sp=1.08)
        _p(s, x + 0.30, 4.85, cw - 0.60, body, 11.5)


@reg
def zw_close(prs, d):
    s = page(prs)
    _gingham(s)
    pic(s, _t('paper.jpg'), 1.50, 0.90, 10.30, 5.70, geom='cloud')
    _aster(s, 1.10, 1.00, 0.90)
    _aster(s, 12.30, 6.40, 0.90)
    _bolt(s, 10.60, 0.70, 1.10, 1.60, Y(), 15)
    _blob(s, 3.20, 2.20, 6.90, 1.18)
    _h(s, 2.70, 2.12, d['t'], 50, 7.9, al='c')
    _p(s, 3.10, 3.60, 7.10, d.get('note', ''), 13, al='c')
    for i, (lab, v) in enumerate(d['items'][:3]):
        x = 3.25 + i * 2.35
        txt(s, x, 4.70, 2.25, 0.30, lab, 10.5, P['mute'], 'rg', 'c')
        txt(s, x, 5.00, 2.25, 0.36, v, 12.5, G(), 'bd', 'c')
