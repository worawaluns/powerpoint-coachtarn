"""20 เลย์เอาต์ชุด Strategic Planning — ลอกโครงจากเทมเพลตน้ำเงินไล่เฉดที่ไอซ์ส่งมา

หน้าเป็นขาว/ฟ้าอ่อน มีบล็อกน้ำเงินทึบและไทล์ไล่เฉดวางทับ หัวเรื่องเป็นน้ำเงินน้ำหนักบาง
เลขหน้ามุมขวาล่าง ตามต้นฉบับ
"""
from eng import *
import eng
from lay import L, reg


def _duo():
    """ย้อมรูปให้อยู่ในโทนเดียวกับพาเลตต์ของเด็ค ไม่ให้สีรูปตีกับสีธีม"""
    if P.get('dark'):
        return f"duo:{mix(P['bg'], P['acc'], 0.34)}:{mix(P['acc'], 'FFFFFF', 0.54)}"
    return f"duo:{mix(P['ink'], P['acc'], 0.42)}:{mix(P['bg'], P['acc'], 0.13)}"

M = 0.70
PALE = None   # ตั้งใน _pale()


def _pale():
    return mix(P['bg'], P['acc'], 0.09)


def _n(s, d, light=False):
    if d.get('n'):
        txt(s, W - M - 0.9, H - 0.52, 0.9, 0.26, str(int(d['n'])), 8, 'FFFFFF' if light else P['mute'], 'rg', 'r')


def _h(s, x, y, t, sz=40, w=6.0, light=False, wt='md'):
    txt(s, x, y, w, 1.6, t, sz, 'FFFFFF' if light else P['acc'], wt, sp=1.16)


def _lab(s, x, y, t, light=False, sz=13):
    if t: txt(s, x, y, 4.6, 0.26, t, sz, 'C6D2FF' if light else P['mute'], 'md')


def _p(s, x, y, w, t, sz=13.5, light=False):
    txt(s, x, y, w, 1.5, t, sz, 'DCE4FF' if light else mix(P['bg'], P['ink'], 0.60), 'rg', sp=1.42)


def _tile(s, x, y, w, h, grad=True, adj=0.10):
    if grad: return gradband(s, x, y, w, h, 300, c1=P['acc'], c2=mix(P['acc'], 'FFFFFF', 0.45), kind='round', adj=adj)
    return shp(s, 'round', x, y, w, h, P['acc'], adj=adj)


def _arrow(s, x, y, w=1.15):
    shp(s, 'round', x, y, w, 0.42, P['acc'], adj=0.5)
    ln(s, x + w * 0.30, y + 0.21, x + w * 0.68, y + 0.21, 'FFFFFF', 1.5)
    ln(s, x + w * 0.58, y + 0.12, x + w * 0.70, y + 0.21, 'FFFFFF', 1.5)
    ln(s, x + w * 0.58, y + 0.30, x + w * 0.70, y + 0.21, 'FFFFFF', 1.5)


# ══ เลย์เอาต์ตามรูปอ้างอิง ═════════════════════════════════════════════════

@reg
def st_cover(prs, d):
    s = page(prs, P['acc'])
    pic(s, ph(d['topic'], d.get('pi', 0)), 0.34, 0.34, W - 0.68, H - 0.68, focus=(0.5, 0.45), mode=_duo())
    shp(s, 'rect', 0.34, 0.34, W - 0.68, H - 0.68, mix(P['ink'], P['acc'], 0.30), a=0.42)
    shp(s, 'rect', 0.34, 2.22, W - 2.20, 3.52, 'FFFFFF')
    txt(s, 1.00, 2.72, 7.2, 0.86, d['t1'], 54, P['acc'], 'bd')   # กว้างถึงขอบเลขไตรมาส (เดิม 6.4): ชื่อยาวสองบรรทัดยังได้ 40pt ขึ้นไป (slide-judge 30 ต.ค.)
    txt(s, 1.00, 3.62, 7.2, 0.86, d['t2'], 54, mix(P['acc'], 'FFFFFF', 0.30), 'md')
    _p(s, 1.00, 4.66, 5.4, d['s'], 13.5)
    txt(s, 8.30, 2.56, 2.6, 0.92, d.get('q', 'Q3'), 40, mix(P['bg'], P['ink'], 0.42), 'md', 'r')
    txt(s, 8.30, 3.52, 2.6, 0.30, d.get('yr', '2570'), 10, P['mute'], 'rg', 'r')
    ln(s, 9.52, 4.52, 10.40, 5.26, P['ink'], 2.6)
    ln(s, 10.40, 5.26, 10.40, 4.72, P['ink'], 2.6); ln(s, 10.40, 5.26, 9.90, 5.26, P['ink'], 2.6)
    _n(s, d)


@reg
def st_drivers(prs, d):
    s = page(prs, P['bg'])
    _h(s, M, 0.90, d['t'], 41, 4.3)
    ln(s, M, 4.20, M + 0.50, 4.46, P['acc'], 2.0); ln(s, M + 0.50, 4.46, M + 1.02, 3.96, P['acc'], 2.0)
    shp(s, 'tri', M + 0.96, 3.84, 0.20, 0.20, P['acc'], rot=45)
    _p(s, M, 4.76, 3.9, d['note'], 13.5)
    bx = 5.40
    pic(s, ph(d['topic'], d.get('pi', 1)), bx, 0.46, (W - M - bx) / 2 - 0.06, 2.24, focus=(0.5, 0.42), mode=_duo())
    pic(s, ph(d['topic'], d.get('pi2', 5)), bx + (W - M - bx) / 2 + 0.06, 0.46, (W - M - bx) / 2 - 0.06, 2.24, focus=(0.5, 0.42), mode=_duo())
    shp(s, 'rect', bx, 2.70, W - M - bx, H - 0.46 - 2.70, P['acc'])
    for i, (h_, body) in enumerate(d['items'][:2]):
        y = 3.08 + i * 1.42
        txt(s, bx + 0.34, y, 0.9, 0.46, f'{i + 1:02d}', 27, 'FFFFFF', 'md')
        txt(s, bx + 1.30, y + 0.04, 5.4, 0.30, h_, 15, 'FFFFFF', 'md')
        _p(s, bx + 1.30, y + 0.38, 5.3, body, 13, True)
    _n(s, d, True)


@reg
def st_journey(prs, d):
    s = page(prs, P['bg'])
    shp(s, 'rect', M, 0.56, W - M * 2, 3.10, P['acc'])
    pic(s, ph(d['topic'], d.get('pi', 2)), 8.05, 0.56, W - M - 8.05, 3.10, focus=(0.5, 0.42), mode=_duo())
    _h(s, M + 0.44, 0.96, d['t'], 37, 6.6, True, 'md')
    _p(s, M + 0.44, 2.46, 6.6, d['note'], 13.5, True)
    shp(s, 'rect', M, 3.80, W - M * 2, 2.58, _pale())
    pic(s, ph(d['topic'], d.get('pi2', 6)), 8.05, 3.80, W - M - 8.05, 2.58, focus=(0.5, 0.45), mode=_duo())
    txt(s, M + 0.44, 4.30, 6.0, 0.90, d['big'], 51, P['acc'], 'md')
    _p(s, M + 0.44, 5.30, 6.3, d['biglab'], 13.5)
    _n(s, d)


@reg
def st_bars(prs, d):
    s = page(prs, P['bg'])
    _lab(s, M, 0.86, d.get('k', ''))
    _p(s, M, 1.18, 4.6, d['note'], 13.5)
    shp(s, 'oval', M, 2.62, 0.20, 0.20, P['acc'])
    txt(s, M + 0.32, 2.56, 3.0, 0.30, d.get('src', ''), 8.5, P['mute'], 'rg')
    n = len(d['bars'][:6]); gx = 4.40; gw = W - M - gx
    bw = gw / n * 0.60
    base, top = 6.26, 1.42
    mx = max(v for _, v in d['bars'][:6]) or 1
    pts = []
    for i, (lab, v) in enumerate(d['bars'][:6]):
        cx = gx + gw / n * (i + 0.5)
        h = (base - top) * (v / mx) * 0.92
        gradband(s, cx - bw / 2, base - h, bw, h, 270, c1=mix(P['acc'], 'FFFFFF', 0.62), c2=P['acc'], kind='round', adj=0.10)
        txt(s, cx - bw / 2 - 0.3, base - h - 0.40, bw + 0.6, 0.32, lab, 15, P['ink'], 'rg', 'c')
        pts.append((cx, base - h))
    for a_, b_ in zip(pts, pts[1:]):
        ln(s, a_[0], a_[1] + 0.26, b_[0], b_[1] + 0.26, mix(P['bg'], P['acc'], 0.30), 0.9)
    shp(s, 'oval', pts[-1][0] - 0.09, pts[-1][1] + 0.17, 0.18, 0.18, 'FFFFFF', line=P['acc'], lw=1.4)
    _n(s, d)


@reg
def st_split_table(prs, d):
    s = page(prs, P['bg'])
    for i, part in enumerate(d['t'].split('\n')[:4]):
        txt(s, M, 0.90 + i * 0.58, 3.4, 0.56, part, 37,
            P['acc'] if i % 2 == 0 else mix(P['acc'], 'FFFFFF', 0.40), 'md')
    _arrow(s, M, 3.66)
    txt(s, 4.35, 0.84, 2.3, 0.80, d['big'], 51, P['acc'], 'md')
    _p(s, 6.50, 0.90, 2.4, d['biglab'], 13)
    tw = W - M - 4.35; y0 = 2.06
    cols = d['colw']
    shp(s, 'rect', 4.35, y0, tw, 0.42, P['acc'])
    cx = 4.35
    for hd, fr in zip(d['head'], cols):
        txt(s, cx + 0.14, y0, tw * fr - 0.28, 0.42, hd, 13, 'FFFFFF', 'md', an='m'); cx += tw * fr
    for i, row in enumerate(d['rows'][:5]):
        y = y0 + 0.42 + i * 0.46
        if i % 2 == 0: shp(s, 'rect', 4.35, y, tw, 0.46, _pale())
        cx = 4.35
        for j, (cell, fr) in enumerate(zip(row, cols)):
            txt(s, cx + 0.14, y, tw * fr - 0.28, 0.46, cell, 13, P['ink'] if j else P['acc'], 'rg', an='m'); cx += tw * fr
    _n(s, d)


@reg
def st_team(prs, d):
    s = page(prs, P['bg'])
    _h(s, M, 0.90, d['t'], 40, 4.2)
    _lab(s, M, 2.72, d.get('k', ''))
    _p(s, M, 3.04, 4.0, d['note'], 13.5)
    x0 = 5.30
    for i, (name, role) in enumerate(d['items'][:3]):
        x = x0 + i * 2.60
        y = 0.70 + (i % 2) * 0.46
        pic(s, ph(d.get('ptopic', 'office'), d.get('pi', 3) + i), x, y, 2.38, 4.42, focus=(0.5, 0.34), mode=_duo())
        shp(s, 'rect', x, y + 4.42, 2.38, 0.86, P['acc'])
        txt(s, x + 0.18, y + 4.52, 2.0, 0.28, name, 14.5, 'FFFFFF', 'md')
        _p(s, x + 0.18, y + 4.82, 2.0, role, 13, True)
    _n(s, d)


@reg
def st_reality(prs, d):
    s = page(prs, P['bg'])
    pic(s, ph(d['topic'], d.get('pi', 7)), M, 0.56, 5.05, 3.00, focus=(0.5, 0.42), mode=_duo())
    for i, (v, lab, body) in enumerate(d['items'][:2]):
        x = M + i * 2.62
        _tile(s, x, 3.74, 2.42, 2.08)
        txt(s, x + 0.24, 3.98, 2.0, 0.58, v, 34, 'FFFFFF', 'md')
        txt(s, x + 0.24, 4.60, 2.0, 0.28, lab, 13.5, 'FFFFFF', 'md')
        _p(s, x + 0.24, 4.94, 1.95, body, 13, True)
    shp(s, 'rect', 6.30, 0.56, W - M - 6.30, H - 1.12, P['acc'])
    _h(s, 6.74, 1.00, d['t'], 37, 5.4, True, 'md')
    _p(s, 6.74, 2.56, 5.3, d['note'], 13.5, True)
    _p(s, 6.74, 4.30, 5.3, d.get('note2', ''), 13.5, True)
    _n(s, d, True)


@reg
def st_photo_tiles(prs, d):
    s = page(prs, P['bg'])
    _lab(s, M, 0.82, d.get('k', ''))
    pic(s, ph(d['topic'], d.get('pi', 8)), M, 1.60, 2.56, 2.70, focus=(0.5, 0.42), mode=_duo())
    for i, (v, lab) in enumerate(d['items'][:3]):
        x = 3.52 + i * 1.86          # เดิมไทล์กว้างเกิน ชนการ์ดหมายเหตุที่มุมขวาบน
        _tile(s, x, 1.60, 1.70, 2.70)
        txt(s, x + 0.22, 1.86, 1.4, 0.62, v, 28, 'FFFFFF', 'md')
        _p(s, x + 0.22, 2.56, 1.30, lab, 13, True)
    card(s, 9.10, 1.26, 3.52, 1.56, _pale(), adj=0.08)
    _p(s, 9.34, 1.50, 3.05, d['note'], 13)
    ln(s, M, 4.80, 11.70, 4.80, mix(P['bg'], P['acc'], 0.25), 0.8)
    ln(s, 11.70, 4.80, 11.70, 4.40, mix(P['bg'], P['acc'], 0.25), 0.8)
    _p(s, M, 5.02, 5.6, d.get('note2', ''), 13)
    _n(s, d)


@reg
def st_heatgrid(prs, d):
    s = page(prs, P['bg'])
    for i, (v, lab) in enumerate(d['items'][:2]):
        x = M + i * 2.46
        _lab(s, x, 0.86, lab)
        txt(s, x, 1.18, 2.3, 0.78, v, 45, P['ink'], 'md')
    shp(s, 'oval', M, 2.46, 0.20, 0.20, P['acc'])
    txt(s, M + 0.32, 2.40, 3.0, 0.30, d.get('src', ''), 8.5, P['mute'], 'rg')
    _lab(s, M, 4.30, d.get('k', ''))
    _p(s, M, 4.62, 4.5, d['note'], 13)
    gx, gy = 6.10, 1.70
    cw, ch, gap = 1.62, 0.58, 0.16
    for r, row in enumerate(d['grid'][:5]):
        for c, lv in enumerate(row[:3]):
            shp(s, 'round', gx + c * (cw + gap), gy + r * (ch + gap), cw, ch,
                mix(mix(P['bg'], P['acc'], 0.12), P['acc'], lv), adj=0.22)
    _n(s, d)


@reg
def st_bench(prs, d):
    s = page(prs, P['bg'])
    _lab(s, M, 0.86, d.get('k', ''))
    _h(s, M, 1.18, d['t'], 38, 7.2)
    for i, (v, lab) in enumerate(d['items'][:2]):
        x = M + i * 1.92
        _tile(s, x, 3.10, 1.76, 1.76)
        txt(s, x + 0.20, 3.22, 1.4, 0.28, lab, 13, 'FFFFFF', 'md')
        txt(s, x + 0.20, 3.86, 1.4, 0.72, v, 37, 'FFFFFF', 'md')
    txt(s, 5.00, 3.10, 3.0, 0.30, d.get('h2', ''), 9.5, P['ink'], 'md')
    _p(s, 5.00, 3.48, 7.3, d['note'], 13)
    _p(s, 5.00, 4.86, 7.3, d.get('note2', ''), 13)
    _n(s, d)


@reg
def st_photo_panel(prs, d):
    s = page(prs, P['bg'])
    pic(s, ph(d['topic'], d.get('pi', 9)), 0, 0, 6.05, H, focus=(0.5, 0.42), mode=_duo())
    shp(s, 'rect', 5.10, 0.78, W - M - 5.10, H - 1.56, P['acc'])
    _h(s, 5.54, 1.28, d['t'], 36, 4.6, True, 'md')
    for i, (h_, body) in enumerate(d['items'][:2]):
        y = 3.46 + i * 1.46
        txt(s, 5.54, y, 4.6, 0.30, h_, 14.5, 'FFFFFF', 'md')
        _p(s, 5.54, y + 0.34, 5.6, body, 13, True)
    _n(s, d, True)


@reg
def st_vision(prs, d):
    s = page(prs, P['bg'])
    _h(s, M, 0.86, d['t'], 38, 9.0)
    cw = (W - M * 2 - 0.50) / 2
    for i, (h_, items) in enumerate(d['items'][:2]):
        x = M + i * (cw + 0.50)
        txt(s, x, 2.30, cw, 0.30, h_, 14.5, P['acc'], 'md')
        ln(s, x, 2.62, x + cw, 2.62, mix(P['bg'], P['acc'], 0.25), 0.7)
        for j, it in enumerate(items[:3]):
            y = 2.78 + j * 0.54
            shp(s, 'oval', x + 0.04, y + 0.12, 0.10, 0.10, P['acc'])
            txt(s, x + 0.30, y, cw - 0.34, 0.44, it, 13.5, P['ink'], 'rg', an='m')
    shp(s, 'rect', M, 4.90, W - M * 2, 1.46, P['acc'])
    _p(s, M + 0.40, 5.14, W - M * 2 - 0.80, d['note'], 13.5, True)
    _n(s, d, True)


@reg
def st_thanks(prs, d):
    s = page(prs, P['bg'])
    pic(s, ph(d.get('ptopic', 'office'), d.get('pi', 10)), 5.30, 0.42, W - M - 5.30, H - 0.84, focus=(0.5, 0.42), mode=_duo())
    shp(s, 'rect', M, 0.42, 5.10, H - 0.84, P['acc'])
    txt(s, M + 0.46, 1.40, 4.2, 1.9, d['t'], 51, 'FFFFFF', 'md', sp=1.12)
    for i, (ic, v) in enumerate(d['items'][:3]):
        y = 4.14 + i * 0.52
        shp(s, 'oval', M + 0.46, y + 0.06, 0.22, 0.22, mix(P['acc'], 'FFFFFF', 0.35))
        txt(s, M + 0.86, y, 3.9, 0.34, v, 13.5, 'FFFFFF', 'rg', an='m')
    _n(s, d, True)


# ══ อีก 7 เลย์เอาต์ ════════════════════════════════════════════════════════

@reg
def st_agenda(prs, d):
    s = page(prs, P['bg'])
    _h(s, M, 0.90, d['t'], 40, 4.0)
    _p(s, M, 3.10, 3.9, d.get('note', ''), 13.5)
    x = 5.20
    for i, (h_, body) in enumerate(d['items'][:5]):
        y = 0.80 + i * 1.08
        txt(s, x, y, 0.8, 0.40, f'{i + 1:02d}', 17, mix(P['bg'], P['acc'], 0.42), 'md')
        txt(s, x + 0.92, y + 0.04, 6.4, 0.30, h_, 15.5, P['acc'], 'md')
        _p(s, x + 0.92, y + 0.38, 6.3, body, 13)
        ln(s, x, y + 0.92, W - M, y + 0.92, mix(P['bg'], P['acc'], 0.22), 0.6)
    _n(s, d)


@reg
def st_divider(prs, d):
    s = page(prs, P['acc'])
    pic(s, ph(d['topic'], d.get('pi', 11)), 6.60, 0, W - 6.60, H, focus=(0.5, 0.42), mode=_duo())
    txt(s, M, 2.26, 2.6, 1.3, d['num'], 54, mix(P['acc'], 'FFFFFF', 0.42), 'md')
    txt(s, M, 3.66, 5.3, 1.2, d['t'], 43, 'FFFFFF', 'md', sp=1.14)
    if d.get('s'): _p(s, M, 4.92, 5.1, d['s'], 14, True)
    _n(s, d, True)


@reg
def st_kpi4(prs, d):
    s = page(prs, P['bg'])
    _lab(s, M, 0.86, d.get('k', ''))
    _h(s, M, 1.18, d['t'], 38, 8.0)
    cw = (W - M * 2 - 0.54) / 4
    for i, (v, lab, body) in enumerate(d['items'][:4]):
        x = M + i * (cw + 0.18)
        hot = i == 1
        if hot: _tile(s, x, 3.00, cw, 2.46)
        else: card(s, x, 3.00, cw, 2.46, _pale(), adj=0.09)
        txt(s, x + 0.26, 3.24, cw - 0.52, 0.66, v, 36, 'FFFFFF' if hot else P['acc'], 'md')
        txt(s, x + 0.26, 3.96, cw - 0.52, 0.30, lab, 14, 'FFFFFF' if hot else P['ink'], 'md')
        _p(s, x + 0.26, 4.32, cw - 0.52, body, 13, hot)
    _n(s, d)


@reg
def st_steps(prs, d):
    s = page(prs, P['bg'])
    _lab(s, M, 0.86, d.get('k', ''))
    _h(s, M, 1.18, d['t'], 38, 5.0)
    x = 5.90
    n = len(d['items'][:4])
    ln(s, x + 0.19, 1.00, x + 0.19, 1.00 + (n - 1) * 1.34 + 0.38, mix(P['bg'], P['acc'], 0.26), 0.8)
    for i, (h_, body) in enumerate(d['items'][:4]):
        y = 1.00 + i * 1.34
        shp(s, 'oval', x, y, 0.38, 0.38, P['acc'])
        txt(s, x, y, 0.38, 0.38, f'{i + 1}', 15, 'FFFFFF', 'md', 'c', 'm')
        txt(s, x + 0.66, y - 0.02, 6.0, 0.32, h_, 16, P['acc'], 'md')
        _p(s, x + 0.66, y + 0.36, 5.9, body, 13)
    _n(s, d)


@reg
def st_compare(prs, d):
    s = page(prs, P['bg'])
    _lab(s, M, 0.86, d.get('k', ''))
    _h(s, M, 1.18, d['t'], 38, 8.2)
    cw = (W - M * 2 - 0.44) / 2
    for c, (ttl, rows) in enumerate(zip(d['heads'], [d['before'], d['after']])):
        x = M + c * (cw + 0.44)
        hot = c == 1
        if hot: shp(s, 'rect', x, 2.90, cw, 3.10, P['acc'])
        else: shp(s, 'rect', x, 2.90, cw, 3.10, _pale())
        txt(s, x + 0.30, 3.12, cw - 0.60, 0.34, ttl, 15, 'FFFFFF' if hot else P['acc'], 'md')
        for i, (lab, v) in enumerate(rows[:4]):
            y = 3.66 + i * 0.56
            txt(s, x + 0.30, y, cw - 1.70, 0.40, lab, 13.5, 'FFFFFF' if hot else P['ink'], 'rg', an='m')
            txt(s, x + cw - 1.50, y, 1.20, 0.40, v, 15.5, 'FFFFFF' if hot else P['acc'], 'md', 'r', 'm')
            ln(s, x + 0.30, y + 0.46, x + cw - 0.30, y + 0.46,
               mix(P['acc'], 'FFFFFF', 0.28) if hot else mix(P['bg'], P['acc'], 0.18), 0.6)
    _n(s, d)


@reg
def st_quote(prs, d):
    s = page(prs, _pale())
    pic(s, ph(d.get('ptopic', 'office'), d.get('pi', 12)), W - 4.60, 0, 4.60, H, focus=(0.5, 0.4), mode=_duo())
    txt(s, M, 1.46, 1.2, 0.9, '"', 54, mix(P['bg'], P['acc'], 0.35), 'bd')
    txt(s, M, 2.34, 7.3, 2.2, d['t'], 30, P['acc'], 'md', sp=1.3)
    ln(s, M, 4.88, M + 2.8, 4.88, mix(P['bg'], P['acc'], 0.30), 0.8)
    txt(s, M, 5.04, 5.2, 0.30, d['who'], 15, P['ink'], 'md')
    _p(s, M, 5.38, 5.2, d['role'], 13)
    _n(s, d)


@reg
def st_next(prs, d):
    s = page(prs, P['bg'])
    _lab(s, M, 0.86, d.get('k', ''))
    _h(s, M, 1.18, d['t'], 38, 8.2)
    cw = (W - M * 2 - 0.44) / 3
    for i, (h_, body, when) in enumerate(d['items'][:3]):
        x = M + i * (cw + 0.22)
        hot = i == 0
        if hot: _tile(s, x, 2.96, cw, 2.72, adj=0.07)
        else: card(s, x, 2.96, cw, 2.72, _pale(), adj=0.07)
        txt(s, x + 0.30, 3.18, 0.8, 0.34, f'{i + 1:02d}', 16.5, 'FFFFFF' if hot else mix(P['bg'], P['acc'], 0.45), 'md')
        txt(s, x + 0.30, 3.64, cw - 0.60, 0.60, h_, 16, 'FFFFFF' if hot else P['acc'], 'md', sp=1.25)
        _p(s, x + 0.30, 4.36, cw - 0.60, body, 13, hot)
        ln(s, x + 0.30, 5.10, x + cw - 0.30, 5.10,
           mix(P['acc'], 'FFFFFF', 0.3) if hot else mix(P['bg'], P['acc'], 0.2), 0.6)
        txt(s, x + 0.30, 5.22, cw - 0.60, 0.28, when, 13, 'FFFFFF' if hot else P['ink'], 'md')
    _n(s, d)
