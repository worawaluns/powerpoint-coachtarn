# python3 doc2slide.py <ไฟล์ docx/pdf/xlsx> <เลขชุดในคลัง> [--render]
# ไฟล์เดียวกันนี้รันในเบราว์เซอร์ด้วย (Pyodide) ที่ coachtarnslide.com/doc2slide — sync ด้วย d2s_web.py
# ต้นแบบ "แปลงเอกสารเป็นสไลด์" — ไม่ใช้ AI ทุกคำบนสไลด์มาจากไฟล์ลูกค้า
#   อ่าน docx → ตัดเป็นหัวข้อ → ดูรูปทรงเนื้อหา
#   → เลือกจาก layout ของ "ชุดที่ลูกค้าเลือก" เท่านั้น (ดีไซน์ สี ฟอนต์ ภาพ ของชุดนั้นทั้งหมด)
#   → วาด layout จริงลงไฟล์ทดลองแล้ววัดกรอบ ล้นก็เปลี่ยนตัว
#   → เขียนเด็คลง d2s/<ชื่อ>.py (META ของชุดนั้น + SEQ ใหม่) แล้วส่งให้ mk.py สร้าง .pptx
#
# layout ของชุดรับเนื้อหารูปทรงไหน อ่านจากตัวอย่างใน SEQ ของชุดนั้นเอง (decks/*.py)
# ponytail: ได้เฉพาะ 161 ชุดที่มีไฟล์ใน decks/ ชุดเก่าที่มีแต่ .pptx ต้องเขียนตัวเติมอีกแบบ
import sys, os, re, io, ast, glob, json, inspect, importlib, importlib.util, unicodedata, subprocess, pprint
K = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, K); os.chdir(K)
import eng, lay, base
for f in sorted(glob.glob(f'{K}/lay_*.py')):           # ลงทะเบียนเลย์เอาต์เฉพาะชุดทั้งหมดเข้า lay.L เหมือน mk.py
    importlib.import_module(os.path.basename(f)[:-3])
HUB = os.path.expanduser('~/doublecraft-hub/projects/apps/powerpoint-coachtarn')
WEB = os.path.exists(f'{K}/fonts.json')                  # บนเว็บไม่มี fc-match ใช้แผนที่ฟอนต์ที่ d2s_web.py เขียนไว้
ICONS = {f.rsplit('.', 1)[0] for f in os.listdir(f'{K}/../kit/icons')}
# ชื่อหมวดรูป เช่น d.get('ptopic', 'office') ห้ามล้าง  บนเว็บโหลดรูปแค่บางหมวด เลยอ่านรายชื่อจากไฟล์
TOPICS = set(json.load(open(f'{K}/topics.json'))) if os.path.exists(f'{K}/topics.json') else set(os.listdir(eng.IMG))
SRC = {n: inspect.getsource(f) for n, f in lay.L.items()}
REQ = {n: set(re.findall(r"d\['(\w+)'\]", s)) - set(re.findall(r"d\.get\('(\w+)'", s)) for n, s in SRC.items()}
# ข้อความตั้งต้นที่ซ่อนอยู่ใน layout เช่น d.get('_l', 'ข้อเสนอบริการ ปี 2570') ของชุด 377
# ไม่ล้างทิ้ง ชื่อบริษัทสมมติของชุดจะไปโผล่บนสไลด์ลูกค้า
_MOD = {}
def _modsrc(n):
    m = sys.modules[lay.L[n].__module__]
    if m not in _MOD: _MOD[m] = inspect.getsource(m)
    return _MOD[m]
TXTDEF = {n: {k for k, v in re.findall(r"d\.get\('(\w+)',\s*'([^']*)'\)", s + _modsrc(n))
              if re.search(r'[A-Za-z\u0E00-\u0E7F]', v) and '{' not in v and v not in ICONS and v not in TOPICS} - {'topic', 'foot', 'n'}
          for n, s in SRC.items()}
ALLOW = {'สารบัญ'}                                         # คำเดียวที่ระบบเติมเอง
CAP = {n: int(m.group(1)) for n, s in SRC.items() for m in [re.search(r"d\['items'\]\[:(\d+)\]", s)] if m}
ROWCAP = {n: int(m.group(1)) for n, s in SRC.items() for m in [re.search(r"d\['rows'\]\[:(\d+)\]", s)] if m}   # ตารางที่วาดได้ไม่ครบทุกแถว

# ══ 1. อ่านไฟล์ → blocks ═══════════════════════════════════════════════════
# block = ('h', ระดับ, ข้อความ) | ('li', ข้อความ, มีเลขข้อ) | ('p', ข้อความ) | ('table', [[ช่อง...]])

def clean(t):
    """ตัดสัญลักษณ์นำหน้า (• - ✨) กับอีโมจิทิ้ง ฟอนต์ไทยในคลังไม่มีอีโมจิ ขึ้นเป็นกล่องเปล่า
    คำทุกคำยังอยู่ครบ ตัดแค่สัญลักษณ์ตกแต่ง"""
    t = ''.join(c for c in t if unicodedata.category(c) != 'So')
    return re.sub(r'^[\s•\-–*·]+', '', t).strip()

def read_docx(path):
    import docx
    from docx.table import Table
    from docx.text.paragraph import Paragraph
    d = docx.Document(path); out = []
    for el in d.element.body.iterchildren():           # เดินตามลำดับจริง ตารางแทรกกลางย่อหน้าได้
        tag = el.tag.rsplit('}', 1)[-1]
        if tag == 'tbl':
            rows = [[clean(c.text) for c in r.cells] for r in Table(el, d).rows]
            if rows: out.append(('table', rows))
            continue
        if tag != 'p': continue
        p = Paragraph(el, d); st = p.style.name.lower(); raw = p.text
        if not raw.strip(): continue
        m = re.match(r'(heading|หัวเรื่อง)\s*(\d)', st)
        if m or st == 'title':
            out.append(('h', int(m.group(2)) if m else 0, clean(raw))); continue
        numbered = 'number' in st or (p._p.pPr is not None and p._p.pPr.numPr is not None and 'bullet' not in st)
        if 'list' in st or numbered:
            out.append(('li', clean(raw), numbered)); continue
        for x in [x for x in raw.split('\n') if x.strip()]:   # ย่อหน้าที่พิมพ์ • หรือ 1. เองทีละบรรทัด
            if re.match(r'\s*[•\-–*·]\s', x): out.append(('li', clean(x), False))
            elif re.match(r'\s*\d{1,2}[.)]\s', x): out.append(('li', re.sub(r'^\s*\d{1,2}[.)]\s*', '', x).strip(), True))
            else: out.append(('p', clean(x)))
    return out

def read_pdf(path):
    """PDF ไม่มี style บอกหัวข้อ ดูจากขนาดตัวอักษร: ใหญ่กว่าเนื้อความชัด ๆ = หัวข้อ ใหญ่สุด = ชื่อเรื่อง
    ponytail: ไม่แกะตารางใน PDF ตารางจะออกมาเป็นบรรทัดข้อความ"""
    from pypdf import PdfReader
    lines_ = []                                           # (ขนาดฟอนต์, ข้อความ)
    for pg in PdfReader(path).pages:
        cur = {'sz': 0, 't': '', 'y': None}
        def vis(text, cm, tm, fd, fs):
            # ตำแหน่ง/ขนาดจริง = tm x cm  บรรทัดใหม่เมื่อ y เปลี่ยน (PDF จาก Chrome/Word ไม่ใส่ \n ให้)
            a_, b_ = tm[0] * cm[0] + tm[1] * cm[2], tm[0] * cm[1] + tm[1] * cm[3]
            y = tm[4] * cm[1] + tm[5] * cm[3] + cm[5]
            sz = round(abs(fs) * ((a_ * a_ + b_ * b_) ** 0.5 or 1), 1)
            if cur['y'] is not None and abs(y - cur['y']) > max(sz, 4) * 0.5 and cur['t'].strip():
                lines_.append((cur['sz'], cur['t'])); cur['t'] = ''; cur['sz'] = 0
            for i, part in enumerate(text.split('\n')):
                if i and cur['t'].strip(): lines_.append((cur['sz'], cur['t'])); cur['t'] = ''; cur['sz'] = 0
                if part.strip(): cur['t'] += part; cur['sz'] = max(cur['sz'], sz); cur['y'] = y
        pg.extract_text(visitor_text=vis)
        lines_.append((cur['sz'], cur['t']))
    # pypdf เติมช่องว่างหน้าสระ/วรรณยุกต์/จุดของคำย่อไทย ("ป .1" "พ . ค .") คืนให้ติดกันเหมือนต้นฉบับ
    lines_ = [(z, re.sub(r'(?<=[\u0E00-\u0E7F])\s+(?=[.\u0E31\u0E33-\u0E3A\u0E47-\u0E4E])', '', t)) for z, t in lines_]
    lines_ = [(z, re.sub(r'(?<=[\u0E01-\u0E2E]\.)\s+(?=[\u0E01-\u0E2E]\.)', '', t)) for z, t in lines_]
    lines_ = [(z, t.replace('\u0e4d\u0e32', '\u0e33').strip()) for z, t in lines_ if t.strip()]   # ํา → ำ
    if not lines_: return []
    # PDF ไทยหลายไฟล์ฝังฟอนต์แบบไม่มีตารางแปลงกลับเป็นตัวอักษร สระบน/วรรณยุกต์หายเป็นช่องว่างหรือ \x00
    # เอาขึ้นสไลด์แล้วดูพังทันที บอกลูกค้าตรง ๆ ดีกว่า
    allt = ' '.join(t for _, t in lines_)
    thai = len(re.findall(r'[\u0E01-\u0E2E]', allt))
    broken = allt.count('\x00') + len(re.findall(r'[\u0E01-\u0E2E] (?=[\u0E01-\u0E2E]{1,2}(?: |$))', allt))
    if thai and broken / thai > 0.02:
        raise ValueError('PDF นี้เก็บตัวอักษรไทยไว้ไม่ครบ (สระหรือวรรณยุกต์หาย) ใช้ไฟล์ Word (.docx) ต้นฉบับแทนจะได้ข้อความถูกต้อง')
    body = sorted(z for z, _ in lines_)[len(lines_) // 2]
    # ตัวเลขล้วน (เลขขั้นตอนตัวโต เลขหน้า) ไม่ใช่หัวข้อ ทิ้งไปเลย
    lines_ = [(z, t) for z, t in lines_ if re.search(r'[A-Za-z\u0E01-\u0E2E]', t)]
    if not lines_: return []
    big = sorted({z for z, t in lines_ if z >= body * 1.18 and len(t) <= 90}, reverse=True)
    lvl = {z: min(i + 1, 3) for i, z in enumerate(big)}
    out = []
    full = sorted(len(t) for _, t in lines_)[int(len(lines_) * 0.9)]   # ความยาวบรรทัดเต็มแถวโดยประมาณ
    prev_full = False
    for z, t in lines_:
        if z in lvl: out.append(('h', lvl[z], clean(t)))
        elif re.match(r'\s*[•\-–*·▪●○]\s*', t): out.append(('li', clean(t), False))
        elif re.match(r'\s*\d{1,2}[.)]\s', t): out.append(('li', re.sub(r'^\s*\d{1,2}[.)]\s*', '', t).strip(), True))
        elif out and out[-1][0] == 'p' and prev_full and not re.search(r'[.!?:]$', out[-1][1]):
            out[-1] = ('p', out[-1][1] + ' ' + clean(t))  # บรรทัดที่ PDF ตัดกลางย่อหน้า ต่อกลับเป็นย่อหน้าเดียว
        else: out.append(('p', clean(t)))
        prev_full = len(t) >= full * 0.85                  # บรรทัดยาวเต็มแถว = ย่อหน้ายังไม่จบ
    return out

def read_xlsx(path):
    """แต่ละชีต = หนึ่งหัวข้อ เป็นตารางหนึ่งตาราง ชื่อชีตเป็นหัวข้อ"""
    import openpyxl
    wb = openpyxl.load_workbook(path, data_only=True, read_only=True); out = []
    for ws in wb.worksheets:
        rows = []
        for r in ws.iter_rows(values_only=True, max_col=8):    # ponytail: 8 คอลัมน์ 9 แถวแรก (หัว+8) ไฟล์ 5,000 แถวไม่ต้องอ่านทั้งหมด
            if len(rows) >= 9: break
            cells = ['' if v is None else (f'{v:,.0f}' if isinstance(v, (int, float)) and not isinstance(v, bool) and float(v).is_integer()
                                           else f'{v:,.2f}' if isinstance(v, float) else str(v)).strip() for v in r]
            while cells and not cells[-1]: cells.pop()
            if any(cells): rows.append(cells)
        if not rows: continue
        w = max(len(r) for r in rows)
        out += [('h', 2, ws.title), ('table', [r + [''] * (w - len(r)) for r in rows])]
        if (ws.max_row or 0) > 9 or (ws.max_column or 0) > 8: NOTES.append(f'ชีต "{ws.title}" ใช้ 8 แถวและ 8 คอลัมน์แรก')
    return out

NOTES = []                                                 # สิ่งที่ระบบตัดทิ้ง ต้องบอกลูกค้าตรง ๆ
MAXSLIDES = 30                                             # มือถือรับไม่ไหวถ้าเกินนี้ (คำนวณ + พรีวิว)

def read_any(path):
    NOTES.clear()
    ext = path.lower().rsplit('.', 1)[-1]
    return {'docx': read_docx, 'pdf': read_pdf, 'xlsx': read_xlsx}[ext](path)

def source_text(path):
    """ข้อความทั้งหมดในไฟล์ลูกค้า ไว้ตรวจว่าทุกคำบนสไลด์มาจากไฟล์นี้"""
    return re.sub(r'\s+', '', ' '.join(b[2] if b[0] == 'h' else (' '.join(' '.join(r) for r in b[1]) if b[0] == 'table' else b[1])
                                     for b in read_any(path)))

# ══ 2. ตัดเป็นหัวข้อ ═══════════════════════════════════════════════════════

def sections(blocks):
    """หัวเรื่องระดับบนสุดที่มีอันเดียว = ชื่อเด็ค, ระดับถัดมา = หนึ่งหัวข้อ, ลึกกว่านั้น = กลุ่มย่อย"""
    lv = sorted({b[1] for b in blocks if b[0] == 'h'})
    title, top = None, lv[0] if lv else 9
    if len(lv) > 1 and sum(1 for b in blocks if b[0] == 'h' and b[1] == lv[0]) == 1:
        top = lv[1]
    secs = []
    for b in blocks:
        if b[0] == 'h' and b[1] < top: title = title or b[2]; continue
        if b[0] == 'h' and b[1] == top:
            num = re.match(r'^(\d{1,2})[.)]\s*', b[2])
            secs.append(dict(t=b[2][num.end():] if num else b[2], num=num.group(1) if num else '', body=[]))
            continue
        if not secs: secs.append(dict(t='', num='', body=[]))
        secs[-1]['body'].append(b)
    return title, [s for s in secs if s['t'] or s['body']]

# ══ 3. ดูรูปทรงเนื้อหา (ยังไม่เกี่ยวกับ layout) ═══════════════════════════════
# หนึ่งแผ่น = dict(kind, t, items/...)  kind: divider statement list pairs qa stat timeline table chart compare

NUM = r'[\d][\d,\.]*\s*(?:%|฿|บาท|คน|ราย|ครั้ง|วัน|เดือน|ปี|ชั่วโมง|หน้า|ล้าน|แห่ง|โรงเรียน|ชิ้น|\+)'
DATE = (r'(พ\.ศ\.|ค\.ศ\.|\b25[5-9]\d\b|\b20[2-4]\d\b|(?:ม\.ค|ก\.พ|มี\.ค|เม\.ย|พ\.ค|มิ\.ย|ก\.ค|ส\.ค|ก\.ย|ต\.ค|พ\.ย|ธ\.ค)\.'
        r'|มกราคม|กุมภาพันธ์|มีนาคม|เมษายน|พฤษภาคม|มิถุนายน|กรกฎาคม|สิงหาคม|กันยายน|ตุลาคม|พฤศจิกายน|ธันวาคม|ไตรมาส)')

def pair(t):
    """'หัว: เนื้อ' หรือ 'Q: ...\\nA: ...' → (ชนิด, หัว, เนื้อ)  ไม่ใช่คู่ → None"""
    qa = re.match(r'\s*Q\s*[:.]\s*(.+?)\s*\n\s*A\s*[:.]\s*(.+)', t, re.S)
    if qa: return ('qa', qa.group(1).strip(), qa.group(2).strip())
    m = re.match(r'([^:：\n]{1,40}?)\s*[:：]\s+(.+)', t, re.S)
    if m and not re.match(r'https?$', m.group(1)): return ('kv', m.group(1).strip(), m.group(2).strip())
    return None

def isnum(c): return bool(re.fullmatch(r'-?[\d,]+(\.\d+)?%?', c.replace(' ', '')))
def tonum(c):
    v = float(c.replace(',', '').replace('%', '').replace(' ', ''))
    return int(v) if v.is_integer() else v               # 220 ไม่ใช่ 220.0 บนกราฟ

def chunk(xs, n=5):
    """เกิน n ข้อตัดเป็นหลายแผ่น แบ่งให้เท่ากัน (8 → 4+4 ไม่ใช่ 5+3)"""
    if len(xs) <= n: return [xs]
    k = -(-len(xs) // n); m = -(-len(xs) // k)
    return [xs[i:i + m] for i in range(0, len(xs), m)]

def shapes(sec):
    t, body = sec['t'], sec['body']
    lis = [b for b in body if b[0] == 'li']; ps = [b[1] for b in body if b[0] == 'p']
    tables = [b[1] for b in body if b[0] == 'table']; subs = [b for b in body if b[0] == 'h']
    note = ' '.join(ps)

    if tables:
        head, data = tables[0][0], tables[0][1:]
        numcols = [j for j in range(1, len(head)) if data and all(len(r) > j and isnum(r[j]) for r in data)]
        if len(numcols) == 1 and 2 <= len(data) <= 8:
            j = numcols[0]
            return [dict(kind='chart', t=t, s=head[j], note=note, head=head, rows=data,
                         cats=[r[0] for r in data], vals=[tonum(r[j]) for r in data])]
        return [dict(kind='table', t=t, note=note, head=head, rows=data)]

    if len(subs) == 2:                                   # สองกลุ่มย่อย = เทียบกัน
        groups, cur = [], None
        for b in body:
            if b[0] == 'h': cur = [b[2], []]; groups.append(cur)
            elif cur and b[0] in ('li', 'p'): cur[1].append(b[1])
        return [dict(kind='compare', t=t, items=[(g[0], g[1]) for g in groups])]

    texts = [b[1] for b in lis] if lis else (ps if len(ps) > 1 else [])
    if not lis: note = ''                                  # ย่อหน้ากลายเป็นข้อไปแล้ว อย่าซ้ำเป็นหมายเหตุ
    if not texts:
        if ps: return [dict(kind='statement', t=ps[0], s=t)]
        return [dict(kind='divider', t=t, num=sec['num'])]

    prs = [pair(x) for x in texts]
    if all(p and p[0] == 'qa' for p in prs):
        return [dict(kind='qa', t=t, items=part) for part in chunk([(p[1], p[2]) for p in prs], 4)]

    nums = [re.search(NUM, x) for x in texts]
    if 2 <= len(texts) <= 4 and all(nums):              # ทุกข้อมีตัวเลขพร้อมหน่วย → การ์ดตัวเลข
        return [dict(kind='stat', t=t, note=note, raw=texts,
                     items=[(m.group(0).strip(), (x[:m.start()] + x[m.end():]).strip(' :,-')) for x, m in zip(texts, nums)])]

    if 3 <= len(texts) <= 5 and all(re.search(DATE, x) for x in texts):
        return [dict(kind='timeline', t=t, items=[(p[1], p[2]) if p else (re.search(DATE, x).group(0), x)
                                                  for x, p in zip(texts, prs)])]

    ordered = bool(lis) and all(b[2] for b in lis)
    kv = all(p and p[0] == 'kv' for p in prs)
    out = []
    for part in chunk(list(zip(texts, prs))):
        if kv: out.append(dict(kind='pairs', t=t, ordered=ordered, note=note, items=[(p[1], p[2]) for _, p in part]))
        else: out.append(dict(kind='list', t=t, ordered=ordered, note=note, items=[(x,) for x, _ in part]))
    return out

# ══ 4. layout ของชุดนี้รับรูปทรงไหน — อ่านจากตัวอย่างใน SEQ ═══════════════════

def isval(x):
    """'5 เดือน' '-35%' '140+' = ค่าตัวเลข  ใช้แยกการ์ดสถิติออกจากการ์ดหัว+เนื้อ"""
    x = str(x).strip()
    return bool(x) and len(x) <= 14 and x[0] in '-+0123456789฿' and any(c.isdigit() for c in x)

DATA = ('series', 'points', 'kpis', 'before', 'stats', 'big', 'pct', 'on', 'side')

def kind_of(name, ex, idx, total):
    """คืน (kind, จำนวนข้อในตัวอย่าง, โครงของแต่ละข้อ)  ใช้ไม่ได้ → kind=None"""
    if idx == 0: return 'cover', 0, None
    if 'close' in name or idx == total - 1: return None, 0, None   # หน้าปิดท้ายไม่มีเนื้อหาจากเอกสาร
    if any(k in ex for k in DATA): return None, 0, None   # ต้องมีตัวเลขเฉพาะทาง (โดนัท การ์ดใหญ่) ที่เอกสารไม่ได้ให้
    if 'cats' in ex and 'vals' in ex and 'series' not in ex: return 'chart', len(ex['cats']), None
    if 'head' in ex and 'rows' in ex: return 'table', len(ex['rows']), None
    it = ex.get('items')
    if isinstance(it, list) and it:
        f = it[0]
        if isinstance(f, str): return ('agenda' if 'agenda' in name or 'toc' in name or idx == 1 else 'list'), len(it), (str,)
        if not isinstance(f, (list, tuple)) or any(isinstance(x, dict) for x in f): return None, 0, None
        slots = tuple(type(x) for x in f)
        if any(isinstance(x, (int, float)) and x not in (0, 1) for r in it for x in r):
            return None, 0, None                           # ช่องตัวเลขในข้อ = ข้อมูลกราฟ ห้ามยืมเลขตัวอย่าง
        if isinstance(f[0], str) and f[0] in ICONS: return None, 0, None   # ช่องแรกเป็นไอคอน เดาไอคอนให้เนื้อลูกค้าไม่ได้
        if list in slots: return ('compare' if len(it) == 2 else None), len(it), slots
        if isval(f[0]): return 'stat', len(it), slots
        if 'timeline' in name or 'gantt' in name: return 'timeline', len(it), slots
        if 'toc' in name or 'agenda' in name or idx == 1: return 'agenda', len(it), slots
        return ('faq' if 'faq' in name else 'pairs'), len(it), slots
    if 'num' in ex or name.startswith('div') or '_div' in name or 'section' in name: return 'divider', 0, None
    return 'statement', 0, None

# เนื้อหาชนิดนี้ ลงตัวอย่างชนิดไหนได้บ้าง พร้อมโทษ (น้อย = เหมาะกว่า)
FIT = {'list': {'list': 0, 'agenda': 3, 'pairs': 4}, 'agenda': {'agenda': 0, 'list': 1, 'pairs': 4},
       'pairs': {'pairs': 0, 'faq': 2, 'agenda': 3}, 'qa': {'faq': 0, 'pairs': 1, 'agenda': 3},
       'stat': {'stat': 0}, 'timeline': {'timeline': 0, 'pairs': 3}, 'compare': {'compare': 0},
       'table': {'table': 0}, 'chart': {'chart': 0, 'table': 2},
       'statement': {'statement': 0, 'divider': 2}, 'divider': {'divider': 0, 'statement': 2}, 'cover': {'cover': 0}}
KEEP = ('pi', 'tsz', 'hi', 'nomirror')                    # คีย์ดีไซน์ที่ไม่ใช่ข้อความ เก็บตามตัวอย่าง

def fill(name, ex, slots, c):
    """เอาเนื้อลูกค้าใส่ตามโครงของตัวอย่าง ห้ามมีคำจากตัวอย่างหลุดมา  ใส่ไม่ได้ → None"""
    d = {k: ex[k] for k in KEEP if k in ex}
    d['t'] = c['t']
    if c['kind'] == 'cover' and 't' not in ex and 't1' in ex:   # ปกบางชุดแยกชื่อเรื่องเป็นสองบรรทัด t1/t2
        d['t1'] = c['t']; d.pop('t')
    if c.get('s'): d['s'] = c['s']
    if c.get('note') and 'note' in ex: d['note'] = c['note']
    if 'num' in ex: d['num'] = c.get('num', '')
    if c['kind'] in ('table', 'chart') and 'head' in ex:
        d['head'] = c['head']; d['rows'] = [list(r) for r in c['rows']]
        if 'colw' in ex:                                   # หน่วยเดียวกับตัวอย่าง (นิ้ว หรือ สัดส่วน) แบ่งเท่ากัน
            d['colw'] = [round(sum(ex['colw']) / len(c['head']), 3)] * len(c['head'])
        if 'al' in ex: d['al'] = ['l'] + ['r' if all(isnum(r[j]) for r in c['rows']) else 'l' for j in range(1, len(c['head']))]
    elif 'cats' in ex:
        d['cats'] = c['cats']; d['vals'] = c['vals']
    elif 'items' in ex and c.get('items'):                 # ปกบางชุดมี items ในตัวอย่าง ถ้าบังคับ REQ ด้านล่างจะตัดทิ้งเอง
        rows = []
        for it in c['items']:
            if slots == (str,):
                if len(it) > 1: return None                # หัว+เนื้อ ยัดลงช่องเดียวไม่ได้
                rows.append(it[0]); continue
            strs = [i for i, t in enumerate(slots) if t is str]
            lsts = [i for i, t in enumerate(slots) if t is list]
            vals = list(it)
            if c['kind'] == 'compare':                     # (หัว, [ข้อ...]) → ช่องสตริงแรก + ช่องลิสต์
                if not lsts: return None
                r = [''] * len(slots); r[strs[0]] = vals[0]; r[lsts[0]] = vals[1]
            else:
                if len(vals) > len(strs): return None
                r = [ex['items'][0][i] if t in (int, float, bool) else '' for i, t in enumerate(slots)]
                for i, v in zip(strs, vals): r[i] = v
            rows.append(tuple(r))
        d['items'] = rows
    for k in TXTDEF.get(name, ()):
        d.setdefault(k, '')
    for k in REQ.get(name, set()) - set(d) - {'topic', 'foot', 'n'}:   # คีย์บังคับที่เอกสารไม่มี
        if isinstance(ex.get(k), str): d[k] = ''
        elif c['kind'] == 'cover' and isinstance(ex.get(k), (list, tuple)): d[k] = []   # การ์ดตัวเลขบนปก mk เติมจากเนื้อเด็คเอง
        else: return None
    return d

# ══ 5. วัดกรอบจากการวาดจริง ════════════════════════════════════════════════

_FACE, _FONT = {}, {}
def facefile(name, bold):
    k = (name, bold)
    if k not in _FACE:
        q = (name or 'IBM Plex Sans Thai') + (':bold' if bold else '')
        if WEB:
            fm = json.load(open(f'{K}/fonts.json'))
            _FACE[k] = f"{K}/fonts/{fm.get(q) or fm.get(name or '') or fm['IBM Plex Sans Thai']}"
        else:
            _FACE[k] = subprocess.run(['fc-match', '-f', '%{file}', q], capture_output=True, text=True).stdout
    return _FACE[k]

def lines(t, w_in, pt, f, dpi=144):
    """ข้อความนี้ที่ขนาดนี้กินกี่บรรทัด ใช้ตัวตัดคำเพื่อวัดอย่างเดียว ไม่แทรก ZWSP ลงไฟล์
    ปล่อยให้ PowerPoint ขึ้นบรรทัดเอง"""
    from PIL import ImageFont
    if (f, pt) not in _FONT: _FONT[(f, pt)] = ImageFont.truetype(f, int(pt / 72 * dpi))
    font, lim, n = _FONT[(f, pt)], w_in * dpi, 0
    for para in str(t).split('\n'):
        n += 1; cur = 0.0
        for tok in words(para):
            wd = font.getlength(tok)
            if cur and cur + wd > lim and not tok.isspace(): n += 1; cur = 0.0
            cur += wd
    return n

def words(t):
    """ตัดคำไทยเพื่อวัด  ในเครื่องใช้ PyThaiNLP บนเว็บใช้ Intl.Segmenter ของเบราว์เซอร์ (พจนานุกรมเหมือนกัน ไม่ใช่ AI)"""
    try:
        from pythainlp.tokenize import word_tokenize
        return word_tokenize(t, keep_whitespace=True)
    except ImportError:
        import js
        return list(js.d2sSeg(t))

def strings(v):
    if isinstance(v, str): yield v
    elif isinstance(v, (int, float)) and not isinstance(v, bool): yield str(v)   # ค่ากราฟของลูกค้า
    elif isinstance(v, (list, tuple)):
        for x in v: yield from strings(x)
    elif isinstance(v, dict):
        for k, x in v.items():
            if k not in KEEP and k != 'al': yield from strings(x)

import base64
_DOT = base64.b64decode('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==')

def overflow(name, d, M):
    """วาด layout นี้ด้วยเนื้อลูกค้า แล้วดูทุกกล่องที่มีข้อความลูกค้าว่าล้นความสูงกรอบไหม"""
    eng.setpal(M['pal'], M.get('font', 'plex'), M.get('head')); eng.setvar(0)
    prs = base.deck()
    real = base._prep
    base._prep = lambda path, mode=None: (_DOT, (4, 3))   # วัดแค่ข้อความ ไม่ต้องย่อ/ย้อมสีรูปจริง เร็วขึ้นหลายเท่า
    try: lay.L[name](prs, {'topic': M.get('topic', 'office'), 'foot': '', 'n': '01', **d})
    except Exception as ex: return [f'วาดไม่ได้ {type(ex).__name__}']
    finally: base._prep = real
    mine = {x.strip() for x in strings(d) if len(x.strip()) > 1}
    bad = []
    for sh in prs.slides[-1].shapes:
        if not sh.has_text_frame or sh.text_frame.text.strip() not in mine: continue
        p = sh.text_frame.paragraphs[0]
        if not p.runs or not p.runs[0].font.size: continue
        r = p.runs[0].font; pt = r.size.pt
        w, h = sh.width / 914400, sh.height / 914400
        sp = p.line_spacing if isinstance(p.line_spacing, float) else 1.0
        lh = pt * max(sp, 1.0) * 1.25 / 72                 # ความสูงหนึ่งบรรทัดของฟอนต์ไทย (สระบน-ล่าง)
        allow = max(1, int(h / lh + 0.35))
        need = lines(sh.text_frame.text, w, pt, facefile(r.name, bool(r.bold)))
        if need > allow: bad.append(f'"{sh.text_frame.text[:22]}" {need}/{allow} บรรทัด')
    return bad

_norm = lambda x: re.sub(r'[^\w\u0E00-\u0E7F]', '', x)   # เทียบเฉพาะตัวอักษร ลาย [ ] · ของดีไซน์ไม่นับ

def scrub(slide, mine):
    """ลบข้อความตัวอย่างที่ดีไซน์ฝังไว้ (ป้ายหัวกระดาษ "ข้อเสนอโครงการ 8 ต.ค. 2570", ชื่อบริษัทสมมติ)
    ลายดีไซน์ยังอยู่ครบ หายแค่คำที่ไม่ใช่ของลูกค้า  คืนรายการที่ลบ"""
    src = _norm(''.join(mine)); gone = []
    for sh in slide.shapes:
        if not sh.has_text_frame: continue
        for p in sh.text_frame.paragraphs:
            k = _norm(''.join(r.text for r in p.runs))
            if not k or k in ALLOW or k in src: continue
            if re.search(r'[A-Za-z\u0E01-\u0E2E]{2}', k) or re.search(r'\d[\d,\.]{2,}', k):
                gone.append(''.join(r.text for r in p.runs).strip())
                for r in p.runs: r.text = ''
    return gone

# ══ 6. เลือก layout ในชุด → สร้างไฟล์ ═══════════════════════════════════════

_DECKS = {}
def deck_of(slug):
    """ไฟล์ต้นฉบับของชุด (META + SEQ) จาก decks/*.py"""
    if not _DECKS:
        for p in sorted(glob.glob(f'{K}/decks/*.py')):
            ns = {}
            try: exec(open(p, encoding='utf-8').read(), ns)
            except Exception: continue
            if 'META' in ns and 'SEQ' in ns: _DECKS[ns['META']['slug']] = ns
    return _DECKS.get(slug)

def slug_of(no):
    e = next(x for x in json.load(open(f'{HUB}/library/data.json')) if str(x['no']) == str(no))
    return e['slug'], e

def analyze(path, name=None):
    """ไฟล์ลูกค้า → ชื่อเรื่อง + รายการแผ่น (ยังไม่เลือก layout)"""
    title, secs = sections(read_any(path))
    ttl = title or os.path.splitext(name or os.path.basename(path))[0]
    want = [dict(kind='cover', t=ttl)]
    if len(secs) >= 3: want.append(dict(kind='agenda', t='สารบัญ', items=[(s['t'],) for s in secs if s['t']][:6]))
    for s in secs: want += shapes(s)
    if len(want) > MAXSLIDES:
        NOTES.append(f'เอกสารยาว ใช้ {MAXSLIDES} หน้าแรกจาก {len(want)} หน้า'); want = want[:MAXSLIDES]
    return ttl, want

def pool_of(slug):
    m = deck_of(slug)
    return dict(m['META']), [(nm, ex, *kind_of(nm, ex, i, len(m['SEQ']))) for i, (nm, ex) in enumerate(m['SEQ'])]

def candidates(c, pool, used):
    cand = []
    for nm, ex, kd, n_ex, slots in pool:
        pen = FIT.get(c['kind'], {}).get(kd)
        if pen is None: continue
        n_c = len(c.get('items') or c.get('rows') or [])
        if len(c.get('items') or []) > CAP.get(nm, 99) or len(c.get('rows') or []) > ROWCAP.get(nm, 99): continue
        cand.append((pen * 10 + abs(n_c - n_ex) * 2 + used.get(nm, 0) * 12, nm, ex, slots))
    return sorted(cand, key=lambda x: x[0])

def try_one(nm, ex, slots, c, M):
    """คืน (dict, ปัญหา)  dict=None ถ้าใส่ไม่ได้"""
    d = fill(nm, ex, slots, c)
    if d is None: return None, 'โครงไม่ตรง'
    if c['kind'] == 'cover':                               # ปกย่อขนาดหัวเรื่องได้ ลองไล่ลงก่อนเปลี่ยน layout
        for z in (None, 40, 36, 32, 28):
            if z: d['tsz'] = z
            if not overflow(nm, d, M): break
    bad = overflow(nm, d, M)
    return (None, bad[0]) if bad else (d, '')

def one(c, xs):
    """ข้อที่แบ่งออกมา  เหลือข้อเดียว → ไปลง layout ประโยคเดี่ยวที่ตัวใหญ่และกว้างกว่า"""
    if len(xs) > 1 or c['kind'] not in ('list', 'pairs', 'qa', 'timeline'): return dict(c, items=xs)
    x = xs[0]
    if c['kind'] == 'qa': return dict(kind='statement', t=x[1], s=x[0])
    return dict(kind='statement', t=': '.join(x), s=c['t'])   # คืนเครื่องหมาย : ให้ตรงต้นฉบับ

def plan(want, slug, on_step=None):
    """เลือก layout ทีละแผ่น  คืน (META, [dict(c, layout, d)], log)"""
    it = plan_iter(want, slug)
    try:
        while True:
            st = next(it)
            if on_step: on_step(*st)
    except StopIteration as e:
        return e.value

def plan_iter(want, slug):
    """เหมือน plan แต่ yield (เสร็จ, ทั้งหมด, ชื่อ layout ล่าสุด) ทุกแผ่น ให้เว็บวาดความคืบหน้าระหว่างคิด
    (Pyodide รันบนเธรดหน้าเว็บ ถ้าไม่หยุดเป็นช่วง ๆ จอจะค้างจนเสร็จ)"""
    M, pool = pool_of(slug)
    want = list(want); out, log, used = [], [], {}
    while want:
        yield (len(out), len(out) + len(want), out[-1]['layout'] if out else '')
        c = want.pop(0)
        cand = candidates(c, pool, used)
        why, got = [], None
        for sc, nm, ex, slots in cand:
            d, bad = try_one(nm, ex, slots, c, M)
            if d is None: why.append(f'{nm} ไม่ผ่าน: {bad}'); continue
            got = (nm, d); break
        if not got and c['kind'] == 'cover' and cand:      # ปกต้องมีเสมอ ล้นก็ใส่แล้วฟ้องให้คนแก้ชื่อ
            d = fill(cand[0][1], cand[0][2], cand[0][3], c)
            if d is not None: got = (cand[0][1], d); why.append('ใส่ปกทั้งที่ไม่ผ่าน')
        if not got and c['kind'] == 'stat' and c.get('raw'):  # ชุดนี้ไม่มีการ์ดตัวเลขที่รับได้ → ลงเป็นรายการ ข้อความเดิม
            want.insert(0, dict(kind='list', t=c['t'], note=c.get('note', ''), items=[(x,) for x in c['raw']]))
            log.append((c, None, why[-3:], 'ลงเป็นรายการแทน')); continue
        n_rw = len(c.get('rows') or [])
        if not got and n_rw > 2 and c['kind'] in ('table', 'chart') and any(p[2] in ('table', 'chart') for p in pool):   # ตารางยาวเกินที่ชุดนี้วาดได้ → แบ่งครึ่ง หัวตารางซ้ำ
            h = -(-n_rw // 2)
            cut = lambda a, b: dict(c, rows=c['rows'][a:b], **({'cats': c['cats'][a:b], 'vals': c['vals'][a:b]} if 'cats' in c else {}))
            want[:0] = [cut(0, h), cut(h, n_rw)]
            log.append((c, None, why[-3:], f'แบ่งตารางเป็น {h}+{n_rw - h} แถว')); continue
        if not got and c['kind'] in ('chart', 'table') and len(c['head']) >= 2:   # ไม่มีตาราง/กราฟ → คู่ ช่องแรก: ที่เหลือ
            rows = [(r[0], ' '.join(x for x in r[1:] if x)) for r in c['rows']]
            want[:0] = [dict(kind='pairs', t=c['t'], note=c.get('note', ''), items=part) for part in chunk(rows)]
            log.append((c, None, why[-3:], 'ลงเป็นคู่หัว-ค่าแทน')); continue
        n_it = len(c.get('items') or [])
        if not got and n_it > 1 and c['kind'] != 'agenda':  # ห้ามทิ้งเนื้อลูกค้า แบ่งครึ่งแล้วลองใหม่
            h = -(-n_it // 2)
            want[:0] = [one(c, c['items'][:h]), one(c, c['items'][h:])]
            log.append((c, None, why[-3:], f'แบ่งเป็น {h}+{n_it - h} ข้อ')); continue
        if not got and c['kind'] == 'statement' and not c.get('_fb'):   # ประโยคยาวเกินหน้าคำคม → ลองเป็นรายการข้อเดียว
            want.insert(0, dict(kind='list', t=c.get('s', ''), items=[(c['t'],)], _fb=1))
            log.append((c, None, why[-3:], 'ลองเป็นรายการ')); continue
        if not got:
            log.append((c, None, why, 'ไม่มี layout ในชุดนี้รับได้ ข้ามแผ่นนี้')); continue
        used[got[0]] = used.get(got[0], 0) + 1
        out.append(dict(c=c, layout=got[0], d=got[1])); log.append((c, got[0], why, ''))
    return M, out, log

KIND_TH = {'cover': 'ปก', 'agenda': 'สารบัญ', 'list': 'รายการ', 'pairs': 'หัวข้อพร้อมคำอธิบาย', 'qa': 'ถาม-ตอบ',
           'stat': 'ตัวเลขสำคัญ', 'timeline': 'ไทม์ไลน์', 'table': 'ตาราง', 'chart': 'กราฟ', 'statement': 'ข้อความเด่น',
           'divider': 'หน้าคั่น', 'compare': 'เปรียบเทียบ'}

def findings(want):
    """สิ่งที่อ่านเจอในไฟล์ ไว้โชว์ลูกค้าก่อนสร้าง (ของจริงทั้งหมด ไม่ได้เดา)"""
    secs = [c for c in want if c['kind'] not in ('cover', 'agenda')]
    nums = [x[0] for c in want if c['kind'] == 'stat' for x in c['items']]
    return dict(
        sections=len({c['t'] for c in secs}),
        tables=sum(1 for c in want if c['kind'] in ('table', 'chart')),
        rows=sum(len(c.get('rows') or []) for c in want if c['kind'] in ('table', 'chart')),
        nums=nums[:6], dates=sum(len(c['items']) for c in want if c['kind'] == 'timeline'),
        qa=sum(len(c['items']) for c in want if c['kind'] == 'qa'), notes=list(NOTES),
        outline=[dict(t=c['t'] if c['kind'] != 'statement' else (c.get('s') or c['t']), kind=c['kind'],
                      th=KIND_TH.get(c['kind'], ''), n=len(c.get('items') or c.get('rows') or [])) for c in want])

def alternatives(c, slug):
    """layout อื่นในชุดเดียวกันที่รับแผ่นนี้ได้โดยไม่ล้น — ให้ลูกค้ากดเปลี่ยนแบบ"""
    M, pool = pool_of(slug)
    res = []
    for sc, nm, ex, slots in candidates(c, pool, {}):
        d, bad = try_one(nm, ex, slots, c, M)
        if d is not None: res.append((nm, d))
    return res

_covfill = None
def render(items, M, ttl):
    """[(layout, dict)] → ไบต์ .pptx  ลำดับขั้นเดียวกับ mk.py (เติมปก, สลับรายละเอียดตาม slug, พลิกปก, ฟอนต์ธีม)"""
    global _covfill
    if _covfill is None:                                   # ยืม _covfill จาก mk.py ตรง ๆ ไม่ก๊อปโค้ด (mk.py รันทันทีที่ import)
        tree = ast.parse(open(f'{K}/mk.py', encoding='utf-8').read())
        fn = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == '_covfill')
        ns = {'re': re}; exec(compile(ast.Module(body=[fn], type_ignores=[]), 'mk.py', 'exec'), ns)
        _covfill = ns['_covfill']
    M = dict(M, cat='', foot=ttl, th=ttl)
    eng.setpal(M['pal'], M.get('font', 'plex'), M.get('head'))
    prs = base.deck()
    seq = list(items)
    for i, (name, d) in enumerate(seq, 1):
        dd = dict(topic=M.get('topic', 'office'), foot=ttl, n=f'{i:02d}')
        dd.update(d)
        if i == 1 and name in [n for n, _ in deck_of(M['slug'])['SEQ'][:1]]:
            _covfill(dd, seq, M)
            eng.setvar(sum(ord(c) * (k + 3) for k, c in enumerate(M['slug'])))
        else:
            eng.setvar(0)
        lay.L[name](prs, dd)
        scrub(prs.slides[-1], list(strings(dd)) + [ttl])
        if i == 1 and eng.vch(0, 2) and not M.get('nomirror'): eng.mirror(prs.slides[-1])
    base.theme_font(prs, M.get('font', 'plex'))
    b = io.BytesIO(); prs.save(b)
    return b.getvalue()

FONT_HOWTO = """วิธีติดตั้งฟอนต์ (ทำครั้งเดียวต่อเครื่อง)

Windows: เลือกไฟล์ .ttf ทั้งหมด คลิกขวา แล้วเลือก "ติดตั้งสำหรับผู้ใช้ทั้งหมด" (Install for all users)
Mac: ดับเบิลคลิกไฟล์ .ttf แล้วกด "ติดตั้งฟอนต์" ทีละไฟล์
เสร็จแล้วปิด PowerPoint แล้วเปิดไฟล์สไลด์ใหม่อีกครั้ง

ถ้าเปิดในเครื่องที่ไม่ได้ติดตั้งฟอนต์ ข้อความยังอยู่ครบและแก้ได้ แต่ตัวอักษรจะเปลี่ยนเป็นฟอนต์อื่น
ฟอนต์ทั้งหมดใช้สัญญาอนุญาต SIL Open Font License (ดูไฟล์ OFL.txt) ใช้งานและแจกต่อได้ฟรี
"""

def fonts_zip(files):
    """ฟอนต์ของชุด + สัญญาอนุญาต + วิธีติดตั้ง เป็นไฟล์ zip ให้ลูกค้าโหลดคู่กับ .pptx"""
    import zipfile
    b = io.BytesIO()
    with zipfile.ZipFile(b, 'w', zipfile.ZIP_DEFLATED) as z:
        for f in files: z.write(f'{K}/fonts/{f}', f'ฟอนต์/{f}')
        if os.path.exists(f'{K}/fonts/OFL.txt'): z.write(f'{K}/fonts/OFL.txt', 'ฟอนต์/OFL.txt')
        z.writestr('วิธีติดตั้งฟอนต์.txt', FONT_HOWTO)
    return b.getvalue()

def words_missing(items, src):
    """ข้อความบนสไลด์ที่ไม่มีในไฟล์ต้นฉบับ  คำเดียวที่ระบบเติมเองคือ 'สารบัญ'"""
    return [v for _, d in items for v in strings({k: x for k, x in d.items() if k != 'num'})
            if v.strip() and v != 'สารบัญ' and not re.fullmatch(r'[\d.]+', v) and re.sub(r'\s+', '', v) not in src]

if __name__ == '__main__':
    a = [x for x in sys.argv[1:] if not x.startswith('--')]
    path = os.path.abspath(a[0]); slug, e = slug_of(a[1])
    if not deck_of(slug): sys.exit(f'ชุด {a[1]} {e["th"]} ยังไม่มีไฟล์ต้นฉบับใน decks/ (มีแต่ .pptx)')
    ttl, want = analyze(path)
    M, out, log = plan(want, slug)
    print(f'ชุด {e["no"]} {e["th"]} ({e["theme"]})')
    for i, (c, nm, why, err) in enumerate(log, 1):
        n = len(c.get('items') or c.get('rows') or [])
        print(f'{i:2d}. {c["t"][:26]:<26} | {c["kind"]:<9} {n or "":>2} → {nm or "-"}  {err}')
        for w in why[:4]: print(f'        ข้าม {w}')
    items = [(x['layout'], x['d']) for x in out]
    print('ข้อความที่ไม่มีในต้นฉบับ:', [w for w in words_missing(items, source_text(path)) if w != ttl] or 'ไม่มี (ชื่อเรื่องจากชื่อไฟล์ไม่นับ)')
    os.makedirs(f'{K}/out', exist_ok=True)
    stem = re.sub(r'[^a-z0-9]+', '', os.path.splitext(os.path.basename(path))[0].lower())[:10] or 'doc'
    dst = f'{K}/out/d2s{a[1]}_{stem}.pptx'
    open(dst, 'wb').write(render(items, M, ttl)); print('→', dst)
    if '--render' in sys.argv:
        subprocess.run([f'{K}/../kit/render.sh', dst, dst[:-5] + '.pdf'], check=True)
