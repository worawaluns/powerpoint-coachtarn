# python3 doc2slide.py <ไฟล์ docx/pdf/xlsx> <เลขชุดในคลัง> [--render]
# ไฟล์เดียวกันนี้รันในเบราว์เซอร์ด้วย (Pyodide) ที่ coachtarnslide.com/doc2slide — sync ด้วย d2s_web.py
# ต้นแบบ "แปลงเอกสารเป็นสไลด์" — ไม่ใช้ AI ทุกคำบนสไลด์มาจากไฟล์ลูกค้า
#   อ่าน docx → ตัดเป็นหัวข้อ → ดูรูปทรงเนื้อหา
#   → เลือกจาก layout ของ "ชุดที่ลูกค้าเลือก" เท่านั้น (ดีไซน์ สี ฟอนต์ ภาพ ของชุดนั้นทั้งหมด)
#   → วาด layout จริงลงไฟล์ทดลองแล้ววัดกรอบ ล้นก็เปลี่ยนตัว
#   → เขียนเด็คลง d2s/<ชื่อ>.py (META ของชุดนั้น + SEQ ใหม่) แล้วส่งให้ mk.py สร้าง .pptx
#
# layout ของชุดรับเนื้อหารูปทรงไหน อ่านจากตัวอย่างใน SEQ ของชุดนั้นเอง (decks/*.py)
# ponytail: ได้เฉพาะ 161 ชุดที่มีไฟล์ใน decks/ ชุดเก่าที่มีแต่ .pptx ต้องเขียนตัวเติมอีกแบบ
import sys, os, re, io, ast, glob, json, inspect, importlib, importlib.util, unicodedata, subprocess, pprint
K = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, K); os.chdir(K)
import eng, lay, base
for f in sorted(glob.glob(f'{K}/lay_*.py')):           # ลงทะเบียนเลย์เอาต์เฉพาะชุดทั้งหมดเข้า lay.L เหมือน mk.py
    importlib.import_module(os.path.basename(f)[:-3])
HUB = os.path.expanduser('~/doublecraft-hub/projects/apps/powerpoint-coachtarn')
WEB = os.path.exists(f'{K}/fonts.json')                  # บนเว็บไม่มี fc-match ใช้แผนที่ฟอนต์ที่ d2s_web.py เขียนไว้
ICONS = {f.rsplit('.', 1)[0] for f in os.listdir(f'{K}/../kit/icons')}
# ชื่อหมวดรูป เช่น d.get('ptopic', 'office') ห้ามล้าง  บนเว็บโหลดรูปแค่บางหมวด เลยอ่านรายชื่อจากไฟล์
TOPICS = set(json.load(open(f'{K}/topics.json'))) if os.path.exists(f'{K}/topics.json') else set(os.listdir(eng.IMG))
SRC = {n: inspect.getsource(f) for n, f in lay.L.items()}
REQ = {n: set(re.findall(r"d\['(\w+)'\]", s)) - set(re.findall(r"d\.get\('(\w+)'", s)) for n, s in SRC.items()}
# ข้อความตั้งต้นที่ซ่อนอยู่ใน layout เช่น d.get('_l', 'ข้อเสนอบริการ ปี 2570') ของชุด 377
# ไม่ล้างทิ้ง ชื่อบริษัทสมมติของชุดจะไปโผล่บนสไลด์ลูกค้า
_MOD = {}
def _modsrc(n):
    m = sys.modules[lay.L[n].__module__]
    if m not in _MOD: _MOD[m] = inspect.getsource(m)
    return _MOD[m]
TXTDEF = {n: {k for k, v in re.findall(r"d\.get\('(\w+)',\s*'([^']*)'\)", s + _modsrc(n))
              if re.search(r'[A-Za-z\u0E00-\u0E7F]', v) and '{' not in v and v not in ICONS and v not in TOPICS} - {'topic', 'foot', 'n'}
          for n, s in SRC.items()}
ALLOW = {'สารบัญ'}                                         # คำเดียวที่ระบบเติมเอง
CAP = {n: int(m.group(1)) for n, s in SRC.items() for m in [re.search(r"d\['items'\]\[:(\d+)\]", s)] if m}
ROWCAP = {n: int(m.group(1)) for n, s in SRC.items() for m in [re.search(r"d\['rows'\]\[:(\d+)\]", s)] if m}   # ตารางที่วาดได้ไม่ครบทุกแถว

# ══ 1. อ่านไฟล์ → blocks ═══════════════════════════════════════════════════
# block = ('h', ระดับ, ข้อความ) | ('li', ข้อความ, มีเลขข้อ) | ('p', ข้อความ) | ('table', [[ช่อง...]])

def clean(t):
    """ตัดสัญลักษณ์นำหน้า (• - ✨) กับอีโมจิทิ้ง ฟอนต์ไทยในคลังไม่มีอีโมจิ ขึ้นเป็นกล่องเปล่า
    คำทุกคำยังอยู่ครบ ตัดแค่สัญลักษณ์ตกแต่ง"""
    t = ''.join(c for c in t if unicodedata.category(c) != 'So')
    return re.sub(r'^[\s•\-–*·]+', '', t).strip()

def read_docx(path):
    import docx
    from docx.table import Table
    from docx.text.paragraph import Paragraph
    d = docx.Document(path); out = []
    for el in d.element.body.iterchildren():           # เดินตามลำดับจริง ตารางแทรกกลางย่อหน้าได้
        tag = el.tag.rsplit('}', 1)[-1]
        if tag == 'tbl':
            rows = [[clean(c.text) for c in r.cells] for r in Table(el, d).rows]
            if rows: out.append(('table', rows))
            continue
        if tag != 'p': continue
        p = Paragraph(el, d); st = p.style.name.lower(); raw = p.text
        if not raw.strip(): continue
        m = re.match(r'(heading|หัวเรื่อง)\s*(\d)', st)
        if m or st == 'title':
            out.append(('h', int(m.group(2)) if m else 0, clean(raw))); continue
        numbered = 'number' in st or (p._p.pPr is not None and p._p.pPr.numPr is not None and 'bullet' not in st)
        if 'list' in st or numbered:
            out.append(('li', clean(raw), numbered)); continue
        for x in [x for x in raw.split('\n') if x.strip()]:   # ย่อหน้าที่พิมพ์ • หรือ 1. เองทีละบรรทัด
            if re.match(r'\s*[•\-–*·]\s', x): out.append(('li', clean(x), False))
            elif re.match(r'\s*\d{1,2}[.)]\s', x): out.append(('li', re.sub(r'^\s*\d{1,2}[.)]\s*', '', x).strip(), True))
            else: out.append(('p', clean(x)))
    return out

def read_pdf(path):
    """PDF ไม่มี style บอกหัวข้อ ดูจากขนาดตัวอักษร: ใหญ่กว่าเนื้อความชัด ๆ = หัวข้อ ใหญ่สุด = ชื่อเรื่อง
    ponytail: ไม่แกะตารางใน PDF ตารางจะออกมาเป็นบรรทัดข้อความ"""
    from pypdf import PdfReader
    lines_ = []                                           # (ขนาดฟอนต์, ข้อความ)
    for pg in PdfReader(path).pages:
        cur = {'sz': 0, 't': '', 'y': None}
        def vis(text, cm, tm, fd, fs):
            # ตำแหน่ง/ขนาดจริง = tm x cm  บรรทัดใหม่เมื่อ y เปลี่ยน (PDF จาก Chrome/Word ไม่ใส่ \n ให้)
            a_, b_ = tm[0] * cm[0] + tm[1] * cm[2], tm[0] * cm[1] + tm[1] * cm[3]
            y = tm[4] * cm[1] + tm[5] * cm[3] + cm[5]
            sz = round(abs(fs) * ((a_ * a_ + b_ * b_) ** 0.5 or 1), 1)
            if cur['y'] is not None and abs(y - cur['y']) > max(sz, 4) * 0.5 and cur['t'].strip():
                lines_.append((cur['sz'], cur['t'])); cur['t'] = ''; cur['sz'] = 0
            for i, part in enumerate(text.split('\n')):
                if i and cur['t'].strip(): lines_.append((cur['sz'], cur['t'])); cur['t'] = ''; cur['sz'] = 0
                if part.strip(): cur['t'] += part; cur['sz'] = max(cur['sz'], sz); cur['y'] = y
        pg.extract_text(visitor_text=vis)
        lines_.append((cur['sz'], cur['t']))
    # pypdf เติมช่องว่างหน้าสระ/วรรณยุกต์/จุดของคำย่อไทย ("ป .1" "พ . ค .") คืนให้ติดกันเหมือนต้นฉบับ
    lines_ = [(z, re.sub(r'(?<=[\u0E00-\u0E7F])\s+(?=[.\u0E31\u0E33-\u0E3A\u0E47-\u0E4E])', '', t)) for z, t in lines_]
    lines_ = [(z, re.sub(r'(?<=[\u0E01-\u0E2E]\.)\s+(?=[\u0E01-\u0E2E]\.)', '', t)) for z, t in lines_]
    lines_ = [(z, t.replace('\u0e4d\u0e32', '\u0e33').strip()) for z, t in lines_ if t.strip()]   # ํา → ำ
    if not lines_: return []
    # PDF ไทยหลายไฟล์ฝังฟอนต์แบบไม่มีตารางแปลงกลับเป็นตัวอักษร สระบน/วรรณยุกต์หายเป็นช่องว่างหรือ \x00
    # เอาขึ้นสไลด์แล้วดูพังทันที บอกลูกค้าตรง ๆ ดีกว่า
    allt = ' '.join(t for _, t in lines_)
    thai = len(re.findall(r'[\u0E01-\u0E2E]', allt))
    broken = allt.count('\x00') + len(re.findall(r'[\u0E01-\u0E2E] (?=[\u0E01-\u0E2E]{1,2}(?: |$))', allt))
    if thai and broken / thai > 0.02:
        raise ValueError('PDF นี้เก็บตัวอักษรไทยไว้ไม่ครบ (สระหรือวรรณยุกต์หาย) ใช้ไฟล์ Word (.docx) ต้นฉบับแทนจะได้ข้อความถูกต้อง')
    body = sorted(z for z, _ in lines_)[len(lines_) // 2]
    # ตัวเลขล้วน (เลขขั้นตอนตัวโต เลขหน้า) ไม่ใช่หัวข้อ ทิ้งไปเลย
    lines_ = [(z, t) for z, t in lines_ if re.search(r'[A-Za-z\u0E01-\u0E2E]', t)]
    if not lines_: return []
    big = sorted({z for z, t in lines_ if z >= body * 1.18 and len(t) <= 90}, reverse=True)
    lvl = {z: min(i + 1, 3) for i, z in enumerate(big)}
    out = []
    full = sorted(len(t) for _, t in lines_)[int(len(lines_) * 0.9)]   # ความยาวบรรทัดเต็มแถวโดยประมาณ
    prev_full = False
    for z, t in lines_:
        if z in lvl: out.append(('h', lvl[z], clean(t)))
        elif re.match(r'\s*[•\-–*·▪●○]\s*', t): out.append(('li', clean(t), False))
        elif re.match(r'\s*\d{1,2}[.)]\s', t): out.append(('li', re.sub(r'^\s*\d{1,2}[.)]\s*', '', t).strip(), True))
        elif out and out[-1][0] == 'p' and prev_full and not re.search(r'[.!?:]$', out[-1][1]):
            out[-1] = ('p', out[-1][1] + ' ' + clean(t))  # บรรทัดที่ PDF ตัดกลางย่อหน้า ต่อกลับเป็นย่อหน้าเดียว
        else: out.append(('p', clean(t)))
        prev_full = len(t) >= full * 0.85                  # บรรทัดยาวเต็มแถว = ย่อหน้ายังไม่จบ
    return out

def xl_text(v, fmt):
    """ตัวเลขตามที่เซลล์แสดง: ทศนิยมตามรูปแบบเซลล์ เปอร์เซ็นต์ยังเป็นเปอร์เซ็นต์ ไม่ปัดเองถ้าเซลล์ไม่ได้ปัด
    ponytail: อ่านแค่จำนวนทศนิยม/%/ตัวคั่นหลักพันจากรูปแบบ สัญลักษณ์เงินในรูปแบบเซลล์ไม่ใส่ให้"""
    if v is None: return ''
    if isinstance(v, bool) or not isinstance(v, (int, float)): return str(v).strip()
    f = re.sub(r'"[^"]*"|\[[^\]]*\]|\\.', '', (fmt or 'General').split(';')[0])
    m = re.search(r'\.(0+)', f); d = len(m.group(1)) if m else 0
    if '%' in f: return f'{v * 100:,.{d}f}%'
    if m or re.search(r'[0#]', f): return f'{v:,.{d}f}'
    return f'{v:.0f}' if float(v).is_integer() else format(v, '.10g')      # General: เหมือนเซลล์ ไม่มีตัวคั่นหลักพัน ทศนิยมเท่าที่พิมพ์

def read_xlsx(path):
    """แต่ละชีต = หนึ่งหัวข้อ เป็นตารางหนึ่งตาราง ชื่อชีตเป็นหัวข้อ"""
    import openpyxl
    wb = openpyxl.load_workbook(path, data_only=True, read_only=True); out = []
    for ws in wb.worksheets:
        rows = []
        for r in ws.iter_rows(max_col=8):                      # ponytail: 8 คอลัมน์ 9 แถวแรก (หัว+8) ไฟล์ 5,000 แถวไม่ต้องอ่านทั้งหมด
            if len(rows) >= 9: break
            cells = [xl_text(c.value, getattr(c, 'number_format', 'General')) for c in r]
            while cells and not cells[-1]: cells.pop()
            if any(cells): rows.append(cells)
        if not rows: continue
        w = max(len(r) for r in rows)
        out += [('h', 2, ws.title), ('table', [r + [''] * (w - len(r)) for r in rows])]
        if (ws.max_row or 0) > 9 or (ws.max_column or 0) > 8: NOTES.append(f'ชีต "{ws.title}" ใช้หัวตารางกับ 8 แถวแรก และ 8 คอลัมน์แรก')
    return out

NOTES = []                                                 # สิ่งที่ระบบตัดทิ้ง ต้องบอกลูกค้าตรง ๆ
MAXSLIDES = 30                                             # มือถือรับไม่ไหวถ้าเกินนี้ (คำนวณ + พรีวิว)

SECHEAD = r'\s*(วาระ(ที่)?|หัวข้อ(ที่)?|ส่วน(ที่)?|บท(ที่)?|ตอน(ที่)?|ภาค(ที่)?|เรื่อง(ที่)?)\s*\d{1,2}(\.\d+)?\b'

def read_txt(path):
    """ข้อความที่ลูกค้าพิมพ์/วางในช่องแชท  บรรทัดแรก = ชื่อเรื่อง, บรรทัดสั้นที่ตามด้วยรายการ = หัวข้อ
    รองรับ # หัวข้อ, - • * รายการ, 1. รายการมีเลข, ตาราง (คั่นด้วย tab หรือ |)"""
    raw = [l.rstrip() for l in open(path, encoding='utf-8').read().replace('\r', '').split('\n')]
    L = [l for l in raw]
    bullet = lambda l: re.match(r'\s*([•\-–*·▪●○]|\d{1,2}[.)])\s+\S', l)
    out, i, first = [], 0, True
    while i < len(L):
        l = L[i].strip()
        if not l: i += 1; continue
        cells = [c.strip() for c in re.split(r'\t|\s*\|\s*', l.strip('|'))] if ('\t' in l or l.count('|') >= 2) else None
        if cells and len(cells) >= 2:                 # ตาราง: เก็บแถวติดกันที่จำนวนช่องเท่ากัน
            rows = []
            while i < len(L) and L[i].strip() and ('\t' in L[i] or L[i].count('|') >= 2):
                r = [c.strip() for c in re.split(r'\t|\s*\|\s*', L[i].strip().strip('|'))]
                if not all(re.fullmatch(r':?-{2,}:?', c) for c in r if c): rows.append(r)   # ข้ามเส้นคั่นของ markdown
                i += 1
            w = max(len(r) for r in rows); out.append(('table', [r + [''] * (w - len(r)) for r in rows])); continue
        nxt = next((x.strip() for x in L[i + 1:] if x.strip()), '')
        if l.startswith('#'):
            lv = min(len(l) - len(l.lstrip('#')), 3); out.append(('h', lv, clean(l.lstrip('#')))); first = False
        elif first and not bullet(l) and len(l) <= 90 and nxt:
            out.append(('h', 1, clean(l))); first = False     # บรรทัดแรก = ชื่อเรื่อง
        elif bullet(l):
            num = bool(re.match(r'\s*\d{1,2}[.)]', l)); txt = re.sub(r'^\s*([•\-–*·▪●○]|\d{1,2}[.)])\s+', '', l)
            if num and nxt and bullet(nxt) and not re.match(r'\s*\d', nxt):   # "1. หัวข้อ" ตามด้วยรายการ = หัวข้อ
                out.append(('h', 2, clean(txt)))
            else: out.append(('li', clean(txt), num))
        elif len(l) <= 60 and not re.search(r'[.!?]$', l) and nxt and (bullet(nxt) or ('\t' in nxt or nxt.count('|') >= 2)):
            out.append(('h', 2, clean(l.rstrip(':：'))))   # บรรทัดสั้นที่ตามด้วยรายการหรือตาราง = หัวข้อ
        elif len(l) <= 70 and re.match(SECHEAD, l) and nxt and not re.match(SECHEAD, nxt):
            out.append(('h', 2, clean(l.rstrip(':：'))))   # "วาระที่ 1 ..." "ส่วนที่ 2" "บทที่ 3" ตามด้วยรายละเอียด = หัวข้อ
        elif re.fullmatch(r'.{1,60}[:：]', l):
            out.append(('h', 2, clean(l.rstrip(':：'))))
        else: out.append(('p', clean(l)))
        i += 1
    return out

def read_any(path):
    NOTES.clear()
    ext = path.lower().rsplit('.', 1)[-1]
    return {'docx': read_docx, 'pdf': read_pdf, 'xlsx': read_xlsx, 'txt': read_txt}[ext](path)

def source_text(path):
    """ข้อความทั้งหมดในไฟล์ลูกค้า ไว้ตรวจว่าทุกคำบนสไลด์มาจากไฟล์นี้"""
    return re.sub(r'\s+', '', ' '.join(b[2] if b[0] == 'h' else (' '.join(' '.join(r) for r in b[1]) if b[0] == 'table' else b[1])
                                     for b in read_any(path)))

# ══ 2. ตัดเป็นหัวข้อ ═══════════════════════════════════════════════════════

def sections(blocks):
    """หัวเรื่องระดับบนสุดที่มีอันเดียว = ชื่อเด็ค, ระดับถัดมา = หนึ่งหัวข้อ, ลึกกว่านั้น = กลุ่มย่อย"""
    lv = sorted({b[1] for b in blocks if b[0] == 'h'})
    title, top = None, lv[0] if lv else 9
    if len(lv) > 1 and sum(1 for b in blocks if b[0] == 'h' and b[1] == lv[0]) == 1:
        top = lv[1]
    elif len(lv) == 1 and blocks and blocks[0][0] == 'h' and sum(1 for b in blocks if b[0] == 'h') == 1:
        top = lv[0] + 1                                    # หัวเรื่องเดียวบรรทัดแรก = ชื่อเรื่อง (ไม่ใช่หัวข้อเดียวของทั้งเอกสาร)
    secs = []
    for b in blocks:
        if b[0] == 'h' and b[1] < top: title = title or b[2]; continue
        if b[0] == 'h' and b[1] == top:
            num = re.match(r'^(\d{1,2})[.)]\s*', b[2])
            secs.append(dict(t=b[2][num.end():] if num else b[2], num=num.group(1) if num else '', body=[]))
            continue
        if not secs: secs.append(dict(t='', num='', body=[]))
        secs[-1]['body'].append(b)
    return title, [s for s in secs if s['t'] or s['body']]

# ══ 3. ดูรูปทรงเนื้อหา (ยังไม่เกี่ยวกับ layout) ═══════════════════════════════
# หนึ่งแผ่น = dict(kind, t, items/...)  kind: divider statement list pairs qa stat timeline table chart compare

NUM = r'[\d][\d,\.]*\s*(?:%|฿|บาท|คน|ราย|ครั้ง|วัน|เดือน|ปี|ชั่วโมง|หน้า|ล้าน|แห่ง|โรงเรียน|ชิ้น|\+)'
DATE = (r'(พ\.ศ\.|ค\.ศ\.|\b25[5-9]\d\b|\b20[2-4]\d\b|(?:ม\.ค|ก\.พ|มี\.ค|เม\.ย|พ\.ค|มิ\.ย|ก\.ค|ส\.ค|ก\.ย|ต\.ค|พ\.ย|ธ\.ค)\.'
        r'|มกราคม|กุมภาพันธ์|มีนาคม|เมษายน|พฤษภาคม|มิถุนายน|กรกฎาคม|สิงหาคม|กันยายน|ตุลาคม|พฤศจิกายน|ธันวาคม|ไตรมาส)')

def pair(t):
    """'หัว: เนื้อ' หรือ 'Q: ...\\nA: ...' → (ชนิด, หัว, เนื้อ)  ไม่ใช่คู่ → None"""
    qa = re.match(r'\s*Q\s*[:.]\s*(.+?)\s*\n\s*A\s*[:.]\s*(.+)', t, re.S)
    if qa: return ('qa', qa.group(1).strip(), qa.group(2).strip())
    m = re.match(r'([^:：\n]{1,40}?)\s*[:：]\s+(.+)', t, re.S)
    if m and not re.match(r'https?$', m.group(1)): return ('kv', m.group(1).strip(), m.group(2).strip())
    return None

def isnum(c): return bool(re.fullmatch(r'-?[\d,]+(\.\d+)?%?', c.replace(' ', '')))
def tonum(c):
    v = float(c.replace(',', '').replace('%', '').replace(' ', ''))
    return int(v) if v.is_integer() else v               # 220 ไม่ใช่ 220.0 บนกราฟ

def chunk(xs, n=5):
    """เกิน n ข้อตัดเป็นหลายแผ่น แบ่งให้เท่ากัน (8 → 4+4 ไม่ใช่ 5+3)"""
    if len(xs) <= n: return [xs]
    k = -(-len(xs) // n); m = -(-len(xs) // k)
    return [xs[i:i + m] for i in range(0, len(xs), m)]

def shapes(sec):
    t, body = sec['t'], sec['body']
    lis = [b for b in body if b[0] == 'li']; ps = [b[1] for b in body if b[0] == 'p']
    tables = [b[1] for b in body if b[0] == 'table']; subs = [b for b in body if b[0] == 'h']
    note = ' '.join(ps)

    if tables:
        head, data = tables[0][0], tables[0][1:]
        numcols = [j for j in range(1, len(head)) if data and all(len(r) > j and isnum(r[j]) for r in data)]
        if len(numcols) == 1 and 2 <= len(data) <= 8:
            j = numcols[0]
            return [dict(kind='chart', t=t, s=head[j], note=note, head=head, rows=data,
                         cats=[r[0] for r in data], vals=[tonum(r[j]) for r in data])]
        return [dict(kind='table', t=t, note=note, head=head, rows=data)]

    if len(subs) == 2:                                   # สองกลุ่มย่อย = เทียบกัน
        groups, cur = [], None
        for b in body:
            if b[0] == 'h': cur = [b[2], []]; groups.append(cur)
            elif cur and b[0] in ('li', 'p'): cur[1].append(b[1])
        return [dict(kind='compare', t=t, items=[(g[0], g[1]) for g in groups])]

    texts = [b[1] for b in lis] if lis else (ps if len(ps) > 1 else [])
    if not lis: note = ''                                  # ย่อหน้ากลายเป็นข้อไปแล้ว อย่าซ้ำเป็นหมายเหตุ
    if not texts:
        if ps: return [dict(kind='statement', t=ps[0], s=t)]
        return [dict(kind='divider', t=t, num=sec['num'])]

    prs = [pair(x) for x in texts]
    if all(p and p[0] == 'qa' for p in prs):
        return [dict(kind='qa', t=t, items=part) for part in chunk([(p[1], p[2]) for p in prs], 4)]

    # ตัวเลขพร้อมหน่วย หรือเลขที่มีหลักพัน/ทศนิยม (1,240 / 68.5) ไม่นับเลขปี 4 หลักเปล่า ๆ
    nums = [re.search(NUM, x) or re.search(r'(?<![\d.])\d{1,3}(?:,\d{3})+(?:\.\d+)?|(?<![\d.])\d+\.\d+', x) for x in texts]
    if len(texts) >= 2 and all(nums) and not all(re.search(DATE, x) for x in texts):   # ทุกข้อมีตัวเลข → การ์ดตัวเลข ทีละไม่เกิน 4 ใบ
        st = [(x, m) for x, m in zip(texts, nums)]
        return [dict(kind='stat', t=t, note=note, raw=[x for x, _ in part],
                     items=[(m.group(0).strip(), re.sub(r'\s{2,}', ' ', x[:m.start()] + x[m.end():]).strip(' :,-')) for x, m in part])
                for part in chunk(st, 4)]

    if 3 <= len(texts) <= 5 and all(re.search(DATE, x) for x in texts):
        return [dict(kind='timeline', t=t, items=[(p[1], p[2]) if p else (re.search(DATE, x).group(0), x)
                                                  for x, p in zip(texts, prs)])]

    ordered = bool(lis) and all(b[2] for b in lis)
    kv = all(p and p[0] == 'kv' for p in prs)
    out = []
    for part in chunk(list(zip(texts, prs))):
        if kv: out.append(dict(kind='pairs', t=t, ordered=ordered, note=note, items=[(p[1], p[2]) for _, p in part]))
        else: out.append(dict(kind='list', t=t, ordered=ordered, note=note, items=[(x,) for x, _ in part]))
    return out

# ══ 4. layout ของชุดนี้รับรูปทรงไหน — อ่านจากตัวอย่างใน SEQ ═══════════════════

def isval(x):
    """'5 เดือน' '-35%' '140+' = ค่าตัวเลข  ใช้แยกการ์ดสถิติออกจากการ์ดหัว+เนื้อ"""
    x = str(x).strip()
    return bool(x) and len(x) <= 14 and x[0] in '-+0123456789฿' and any(c.isdigit() for c in x)

DATA = ('series', 'points', 'kpis', 'before', 'stats', 'big', 'pct', 'on', 'side')

def kind_of(name, ex, idx, total):
    """คืน (kind, จำนวนข้อในตัวอย่าง, โครงของแต่ละข้อ)  ใช้ไม่ได้ → kind=None"""
    if idx == 0: return 'cover', 0, None
    if 'close' in name or idx == total - 1: return None, 0, None   # หน้าปิดท้ายไม่มีเนื้อหาจากเอกสาร
    if any(k in ex for k in DATA): return None, 0, None   # ต้องมีตัวเลขเฉพาะทาง (โดนัท การ์ดใหญ่) ที่เอกสารไม่ได้ให้
    if 'cats' in ex and 'vals' in ex and 'series' not in ex: return 'chart', len(ex['cats']), None
    if 'head' in ex and 'rows' in ex: return 'table', len(ex['rows']), None
    it = ex.get('items')
    if isinstance(it, list) and it:
        f = it[0]
        if isinstance(f, str): return ('agenda' if 'agenda' in name or 'toc' in name or idx == 1 else 'list'), len(it), (str,)
        if not isinstance(f, (list, tuple)) or any(isinstance(x, dict) for x in f): return None, 0, None
        slots = tuple(type(x) for x in f)
        if any(isinstance(x, (int, float)) and x not in (0, 1) for r in it for x in r):
            return None, 0, None                           # ช่องตัวเลขในข้อ = ข้อมูลกราฟ ห้ามยืมเลขตัวอย่าง
        if isinstance(f[0], str) and f[0] in ICONS: return None, 0, None   # ช่องแรกเป็นไอคอน เดาไอคอนให้เนื้อลูกค้าไม่ได้
        if list in slots: return ('compare' if len(it) == 2 else None), len(it), slots
        if 'timeline' in name or 'gantt' in name: return 'timeline', len(it), slots   # ก่อน isval: ไทม์ไลน์ขึ้นต้นด้วยปี
        if isval(f[0]): return 'stat', len(it), slots
        if 'toc' in name or 'agenda' in name or idx == 1: return 'agenda', len(it), slots
        return ('faq' if 'faq' in name else 'pairs'), len(it), slots
    if 'num' in ex or name.startswith('div') or '_div' in name or 'section' in name: return 'divider', 0, None
    return 'statement', 0, None

# เนื้อหาชนิดนี้ ลงตัวอย่างชนิดไหนได้บ้าง พร้อมโทษ (น้อย = เหมาะกว่า)
FIT = {'list': {'list': 0, 'agenda': 3, 'pairs': 4}, 'agenda': {'agenda': 0, 'list': 1, 'pairs': 4},
       'pairs': {'pairs': 0, 'faq': 2, 'agenda': 3}, 'qa': {'faq': 0, 'pairs': 1, 'agenda': 3},
       'stat': {'stat': 0}, 'timeline': {'timeline': 0, 'pairs': 3}, 'compare': {'compare': 0},
       'table': {'table': 0}, 'chart': {'chart': 0, 'table': 2},
       'statement': {'statement': 0, 'divider': 2}, 'divider': {'divider': 0, 'statement': 2}, 'cover': {'cover': 0}}
KEEP = ('pi', 'tsz', 'hi', 'nomirror')                    # คีย์ดีไซน์ที่ไม่ใช่ข้อความ เก็บตามตัวอย่าง

LABEL = ('k', 'kicker', 'lab', 'label', 'tag', 'who', 'sub', 'cat', 'eyebrow')   # ช่องป้ายสั้น ๆ ที่ใส่หัวรองแทนได้

def fill(name, ex, slots, c):
    """เอาเนื้อลูกค้าใส่ตามโครงของตัวอย่าง ห้ามมีคำจากตัวอย่างหลุดมา  ใส่ไม่ได้ → None"""
    d = {k: ex[k] for k in KEEP if k in ex}
    d['t'] = c['t']
    if c['kind'] == 'cover' and 't' not in ex and 't1' in ex:   # ปกบางชุดแยกชื่อเรื่องเป็นสองบรรทัด t1/t2
        d['t1'] = c['t']; d.pop('t')
    if c.get('s'): d['s'] = c['s']
    if c.get('note') and 'note' in ex: d['note'] = c['note']
    if 'num' in ex: d['num'] = c.get('num', '')
    if c['kind'] in ('table', 'chart') and 'head' in ex:
        d['head'] = c['head']; d['rows'] = [list(r) for r in c['rows']]
        tp = next((h for h in ex['head'] if isinstance(h, (list, tuple))), None)
        if tp:                                             # หัวคอลัมน์แบบ (หัว, หัวรอง) เช่น op_table ใส่หัวรองว่าง
            d['head'] = [(h,) + ('',) * (len(tp) - 1) for h in c['head']]
        if 'colw' in ex:                                   # หน่วยเดียวกับตัวอย่าง (นิ้ว หรือ สัดส่วน) แบ่งเท่ากัน
            d['colw'] = [round(sum(ex['colw']) / len(c['head']), 3)] * len(c['head'])
        if 'al' in ex: d['al'] = ['l'] + ['r' if all(isnum(r[j]) for r in c['rows']) else 'l' for j in range(1, len(c['head']))]
    elif 'cats' in ex:
        d['cats'] = c['cats']; d['vals'] = c['vals']
    elif 'items' in ex and c.get('items'):                 # ปกบางชุดมี items ในตัวอย่าง ถ้าบังคับ REQ ด้านล่างจะตัดทิ้งเอง
        rows = []
        for it in c['items']:
            if slots == (str,):
                if len(it) > 1: return None                # หัว+เนื้อ ยัดลงช่องเดียวไม่ได้
                rows.append(it[0]); continue
            strs = [i for i, t in enumerate(slots) if t is str]
            lsts = [i for i, t in enumerate(slots) if t is list]
            vals = list(it)
            if c['kind'] == 'compare':                     # (หัว, [ข้อ...]) → ช่องสตริงแรก + ช่องลิสต์
                if not lsts: return None
                r = [''] * len(slots); r[strs[0]] = vals[0]; r[lsts[0]] = vals[1]
            else:
                if len(vals) > len(strs): return None
                r = [ex['items'][0][i] if t in (int, float, bool) else '' for i, t in enumerate(slots)]
                off = min(c.get('_slot', 0), len(strs) - len(vals))   # ลองใส่ช่องถัดไปได้ (ช่องแรกบาง layout เป็นเลขหน้า)
                for i, v in zip(strs[off:], vals): r[i] = v
            rows.append(tuple(r))
        d['items'] = rows
    for k in TXTDEF.get(name, ()):
        d.setdefault(k, '')
    if d.get('s') and "d['s']" not in SRC[name] and "d.get('s'" not in SRC[name]:   # layout ไม่วาดหัวรอง: ย้ายไปช่องป้ายที่ layout วาด
        lab = next((k for k in LABEL if k in SRC[name] and not d.get(k) and isinstance(ex.get(k, ''), str)), None)
        if lab: d[lab] = d.pop('s')
    for k in REQ.get(name, set()) - set(d) - {'topic', 'foot', 'n'}:   # คีย์บังคับที่เอกสารไม่มี
        if isinstance(ex.get(k), str): d[k] = ''
        elif c['kind'] == 'cover' and isinstance(ex.get(k), (list, tuple)): d[k] = []   # การ์ดตัวเลขบนปก mk เติมจากเนื้อเด็คเอง
        else: return None
    return d

# ══ 5. วัดกรอบจากการวาดจริง ════════════════════════════════════════════════

_FACE, _FONT = {}, {}
def facefile(name, bold):
    k = (name, bold)
    if k not in _FACE:
        q = (name or 'IBM Plex Sans Thai') + (':bold' if bold else '')
        if WEB:
            fm = json.load(open(f'{K}/fonts.json'))
            _FACE[k] = f"{K}/fonts/{fm.get(q) or fm.get(name or '') or fm['IBM Plex Sans Thai']}"
        else:
            _FACE[k] = subprocess.run(['fc-match', '-f', '%{file}', q], capture_output=True, text=True).stdout
    return _FACE[k]

def lines(t, w_in, pt, f, dpi=144):
    """ข้อความนี้ที่ขนาดนี้กินกี่บรรทัด ใช้ตัวตัดคำเพื่อวัดอย่างเดียว ไม่แทรก ZWSP ลงไฟล์
    ปล่อยให้ PowerPoint ขึ้นบรรทัดเอง"""
    from PIL import ImageFont
    if (f, pt) not in _FONT: _FONT[(f, pt)] = ImageFont.truetype(f, int(pt / 72 * dpi))
    font, lim, n = _FONT[(f, pt)], w_in * dpi, 0
    for para in str(t).split('\n'):
        n += 1; cur = 0.0
        for tok in words(para):
            wd = font.getlength(tok)
            if cur and cur + wd > lim and not tok.isspace(): n += 1; cur = 0.0
            cur += wd
    return n

def wordsx(t):
    """words() แต่ไม่หั่นคำอังกฤษ/ตัวเลข/ขีด เช่น O-NET 5/2568 ไว้เป็นชิ้นเดียว ใช้ตอนหาที่ตัดบรรทัด/หน้า"""
    out = []
    for w_ in words(t):
        if out and re.fullmatch(r'[A-Za-z0-9\-./%,]+', w_) and re.search(r'[A-Za-z0-9\-./]$', out[-1]): out[-1] += w_
        else: out.append(w_)
    return out

def words(t):
    """ตัดคำไทยเพื่อวัด  ในเครื่องใช้ PyThaiNLP บนเว็บใช้ Intl.Segmenter ของเบราว์เซอร์ (พจนานุกรมเหมือนกัน ไม่ใช่ AI)"""
    try:
        from pythainlp.tokenize import word_tokenize
        return word_tokenize(t, keep_whitespace=True)
    except ImportError:
        import js
        return list(js.d2sSeg(t))

def strings(v):
    if isinstance(v, str): yield v
    elif isinstance(v, (int, float)) and not isinstance(v, bool): yield str(v)   # ค่ากราฟของลูกค้า
    elif isinstance(v, (list, tuple)):
        for x in v: yield from strings(x)
    elif isinstance(v, dict):
        for k, x in v.items():
            if k not in KEEP and k != 'al': yield from strings(x)

import base64
_DOT = base64.b64decode('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==')

def overflow(name, d, M):
    """วาด layout นี้ด้วยเนื้อลูกค้า แล้วดูทุกกล่องที่มีข้อความลูกค้าว่าล้นความสูงกรอบไหม"""
    eng.setpal(M['pal'], M.get('font', 'plex'), M.get('head')); eng.setvar(0)
    prs = base.deck()
    real = base._prep
    base._prep = lambda path, mode=None: (_DOT, (4, 3))   # วัดแค่ข้อความ ไม่ต้องย่อ/ย้อมสีรูปจริง เร็วขึ้นหลายเท่า
    try: lay.L[name](prs, {'topic': M.get('topic', 'office'), 'foot': '', 'n': '01', **d})
    except Exception as ex: return [f'วาดไม่ได้ {type(ex).__name__}']
    finally: base._prep = real
    mine = {x.strip() for x in strings(d) if len(x.strip()) > 1}
    scrub(prs.slides[-1], list(strings(d)))              # เหมือนตอนวาดจริง: คำที่ layout เติมเอง ("หน้า 450,000 บาท") ถูกลบทั้งกล่อง
    bad = [f'ไม่ได้วาด "{x[:22]}"' for x in lost(prs.slides[-1], d)]   # layout ที่ไม่วาดบางช่อง = ทิ้งเนื้อลูกค้า ใช้ไม่ได้
    def solid(x):
        try: return x.fill.type == 1                       # MSO_FILL.SOLID
        except Exception: return False
    shs = [x for x in prs.slides[-1].shapes if solid(x) and not (x.has_text_frame and x.text_frame.text.strip())]
    for sh in prs.slides[-1].shapes:
        if not sh.has_text_frame or sh.text_frame.text.strip() not in mine: continue
        p = sh.text_frame.paragraphs[0]
        if not p.runs or not p.runs[0].font.size: continue
        r = p.runs[0].font; pt = r.size.pt
        w, h = sh.width / 914400, sh.height / 914400
        sp = p.line_spacing if isinstance(p.line_spacing, float) else 1.0
        lh = pt * max(sp, 1.0) * 1.25 / 72                 # ความสูงหนึ่งบรรทัดของฟอนต์ไทย (สระบน-ล่าง)
        allow = max(1, int(h / lh + 0.35))
        need = lines(sh.text_frame.text, w, pt, facefile(r.name, bool(r.bold)))
        if need > allow: bad.append(f'"{sh.text_frame.text[:22]}" {need}/{allow} บรรทัด')
        elif need >= 3 and h < 1.0 and need * lh * 1.2 > h + 0.05: bad.append(f'"{sh.text_frame.text[:22]}" {need} บรรทัดแน่นเกินกล่อง')   # ไทยหลายบรรทัดสูงกว่าที่ประมาณ (ข้อความล้นลูกศร)
        SW = prs.slide_width / 914400; x0 = sh.left / 914400; y0 = sh.top / 914400
        # กล่องข้อความวางบนแผงสี (เช่นกล่องขาวบนปก) ที่เตี้ยกว่ากล่องข้อความ: ข้อความต้องจบในแผง
        for pn in shs:
            if pn is sh: continue
            px, py, pw, ph_ = pn.left / 914400, pn.top / 914400, pn.width / 914400, pn.height / 914400
            if px <= x0 + 0.05 and py <= y0 + 0.05 < py + ph_ - 0.1 and px + pw >= x0 + min(w, 1) and py + ph_ < y0 + h - 0.15 and pw * ph_ < SW * 7.5 * 0.6:   # แผงต้องรองรับต้นข้อความจริง
                if y0 + need * lh + 0.1 > py + ph_: bad.append(f'"{sh.text_frame.text[:22]}" ล้นแผงพื้น'); break
        if x0 + w > SW + 0.05:                             # กล่องกว้างเลยขอบสไลด์ (กว้างตามข้อความ) ข้อความต้องจบในขอบสไลด์บรรทัดเดียว
            if lines(sh.text_frame.text, max(SW - x0 - 0.3, 0.5), pt, facefile(r.name, bool(r.bold))) > 1:
                bad.append(f'"{sh.text_frame.text[:22]}" ล้นขอบสไลด์')
    return bad

def slide_text(slide):
    """ข้อความทั้งหมดที่วาดจริงบนสไลด์ (กล่อง ตาราง กราฟ) ตัดช่องว่าง ตัวเล็ก ไว้เทียบว่าคำลูกค้าอยู่ครบไหม"""
    out = []
    for sh in slide.shapes:
        if getattr(sh, 'has_table', False) and sh.has_table: out += [c.text for r in sh.table.rows for c in r.cells]
        elif getattr(sh, 'has_chart', False) and sh.has_chart: out += list(sh.chart._chartSpace.itertext())
        elif sh.has_text_frame: out.append(sh.text_frame.text)
    return ''.join(''.join(out).split()).lower()

def cust(d):
    """ข้อความลูกค้าใน d (ไม่รวมคีย์ดีไซน์ ความกว้างคอลัมน์ และตัวเลขใน items ที่ fill ยกมาจากตัวอย่าง เช่นธง 0/1)"""
    strs = lambda v: [x for x in v if isinstance(x, str)] if isinstance(v, (list, tuple)) else v
    d2 = {k: ([strs(r) for r in v] if k == 'items' and isinstance(v, list) else v) for k, v in d.items() if k != 'colw'}
    return [x for x in strings(d2) if x.strip()]

def lost(slide, d):
    """คำลูกค้าที่อยู่ใน d แต่ layout ไม่ได้วาดลงสไลด์ (กฎห้ามทิ้งเนื้อหา)"""
    t = slide_text(slide)
    return [x for x in cust(d) if ''.join(x.split()).lower() not in t]

def drop_empty(slide, sw=13.333, sh_=7.5):
    """ป้าย/ปุ่มที่ไม่มีข้อความ (ช่องที่เอกสารไม่มี หรือข้อความตัวอย่างที่ scrub ลบ) เหลือแคปซูลสีว่าง ๆ บนสไลด์
    ลบเฉพาะคู่ "กล่องข้อความว่างที่ไม่มีพื้น" + "พื้นสีเล็ก ๆ ตำแหน่งเดียวกันพอดี" (ปุ่ม ป้าย)
    พื้นหลัง/แผงใหญ่ (สูงเกิน 1 นิ้ว หรือกว้างเกินครึ่งสไลด์) และกล่องที่มีพื้นเอง ไม่แตะ"""
    E = 914400; sh = list(slide.shapes); tol = E * 0.03
    same = lambda a, b: all(abs(int(getattr(a, k)) - int(getattr(b, k))) <= tol for k in ('left', 'top', 'width', 'height'))
    def nofill(x):
        try: return x.fill.type is None or x.fill.type == 5    # ไม่มีพื้น / พื้นโปร่ง (MSO_FILL.BACKGROUND)
        except Exception: return True
    small = lambda x: x.height <= E * 1.0 and x.width <= E * sw * 0.5
    for e in [x for x in sh if x.has_text_frame and not x.text_frame.text.strip() and nofill(x) and small(x)]:
        bg = [x for x in sh if x is not e and same(x, e) and small(x) and not (x.has_text_frame and x.text_frame.text.strip())
              and not getattr(x, 'image', None) and x.shape_type != 13]
        if len(bg) == 1:
            for x in bg + [e]:
                if x._element.getparent() is not None: x._element.getparent().remove(x._element)
    # แถบเมนู/แท็บของดีไซน์ (แถบเตี้ยที่ข้างในมีแต่กล่องข้อความว่างหลายกล่องกับเส้นคั่น) หลังลบคำตัวอย่างเหลือกรอบเปล่า: เอาออกทั้งแถบ
    sh = [x for x in slide.shapes]
    inside = lambda x, b: x.left >= b.left - 1e4 and x.top >= b.top - 1e4 and x.left + x.width <= b.left + b.width + 1e4 and x.top + x.height <= b.top + b.height + 1e4
    for b in [x for x in sh if x.height <= E * 0.8 and x.width >= E * 2 and x.shape_type == 1 and not (x.has_text_frame and x.text_frame.text.strip())]:
        kids = [x for x in sh if x is not b and inside(x, b)]
        empt = [x for x in kids if x.has_text_frame and not x.text_frame.text.strip() and x.shape_type == 17]
        if len(empt) >= 2 and all(x in empt or x.shape_type == 9 for x in kids):
            for x in [b] + kids:
                if x._element.getparent() is not None: x._element.getparent().remove(x._element)

_norm = lambda x: re.sub(r'[^\w\u0E00-\u0E7F]', '', x)   # เทียบเฉพาะตัวอักษร ลาย [ ] · ของดีไซน์ไม่นับ

def scrub(slide, mine):
    """ลบข้อความตัวอย่างที่ดีไซน์ฝังไว้ (ป้ายหัวกระดาษ "ข้อเสนอโครงการ 8 ต.ค. 2570", ชื่อบริษัทสมมติ)
    ลายดีไซน์ยังอยู่ครบ หายแค่คำที่ไม่ใช่ของลูกค้า  คืนรายการที่ลบ"""
    src = _norm(''.join(mine)); gone = []
    for sh in slide.shapes:
        if not sh.has_text_frame: continue
        for p in sh.text_frame.paragraphs:
            k = _norm(''.join(r.text for r in p.runs))
            if not k or k in ALLOW or k in src: continue
            if re.search(r'[A-Za-z\u0E01-\u0E2E]{2}', k) or re.search(r'\d[\d,\.]{2,}', k):
                gone.append(''.join(r.text for r in p.runs).strip())
                for r in p.runs: r.text = ''
    return gone

# ══ 6. เลือก layout ในชุด → สร้างไฟล์ ═══════════════════════════════════════

_DECKS = {}
def deck_of(slug):
    """ไฟล์ต้นฉบับของชุด (META + SEQ) จาก decks/*.py"""
    if not _DECKS:
        for p in sorted(glob.glob(f'{K}/decks/*.py')):
            ns = {}
            try: exec(open(p, encoding='utf-8').read(), ns)
            except Exception: continue
            if 'META' in ns and 'SEQ' in ns: _DECKS[ns['META']['slug']] = ns
    return _DECKS.get(slug)

def slug_of(no):
    e = next(x for x in json.load(open(f'{HUB}/library/data.json')) if str(x['no']) == str(no))
    return e['slug'], e

CONT = {'ซึ่ง', 'และ', 'หรือ', 'โดย', 'เพื่อ', 'จึง', 'แต่', 'ที่', 'ของ', 'ใน', 'กับ', 'คือ', 'เป็น', 'ให้', 'จาก', 'ถึง', 'ได้',
        'แล้ว', 'ด้วย', 'อีก', 'ทั้ง', 'ตาม', 'เมื่อ', 'จน', 'หรือไม่', 'ก็', 'จะ', 'ไป', 'มา', 'คิดเป็น', 'รวม', 'เท่ากับ',
        'ลดลง', 'เพิ่มขึ้น', 'สูงขึ้น', 'เหลือ', 'มาจาก', 'เริ่ม', 'ยัง', 'ไม่', 'ต้อง', 'อยู่', 'กว่า', 'มากกว่า', 'น้อยกว่า',
        'สูงกว่า', 'ต่ำกว่า', 'ภายใน', 'สำหรับ', 'เพราะ', 'เนื่องจาก', 'ทำให้', 'แม้', 'หาก', 'ถ้า', 'เช่น', 'ตั้งแต่',
        'เฉลี่ย', 'เพิ่ม', 'ลด', 'โดยเฉลี่ย', 'จำนวน', 'ประมาณ'}   # คำต่อความ ห้ามตัดหน้าคำเหล่านี้
TAIL = {'ถึง', 'จาก', 'และ', 'หรือ', 'ของ', 'ใน', 'กับ', 'ที่', 'ซึ่ง', 'โดย', 'เพื่อ', 'แต่', 'คือ', 'เป็น', 'ตาม', 'ตั้งแต่',
        'สำหรับ', 'ภายใน', 'เช่น', 'ทั้ง', 'จน', 'เมื่อ', 'ว่า'}                                 # ห้ามจบข้อด้วยคำเหล่านี้
UNIT = (r'(?:%|฿|บาท|คน|ราย|ครั้ง|วัน|เดือน|ปี|ชั่วโมง|หน้า|ล้าน|แห่ง|โรงเรียน|ชิ้น|เล่ม|คะแนน|นาที|พ\.ศ|ค\.ศ'
        r'|มกราคม|กุมภาพันธ์|มีนาคม|เมษายน|พฤษภาคม|มิถุนายน|กรกฎาคม|สิงหาคม|กันยายน|ตุลาคม|พฤศจิกายน|ธันวาคม'
        r'|ม\.ค|ก\.พ|มี\.ค|เม\.ย|พ\.ค|มิ\.ย|ก\.ค|ส\.ค|ก\.ย|ต\.ค|พ\.ย|ธ\.ค)')   # ตัวเลขกับหน่วย/เดือนอยู่ด้วยกันเสมอ

def clauses(t):
    """ตัดเฉพาะท้ายประโยค (. ! ?) หรือเว้นวรรคที่คำถัดไปขึ้นความใหม่ ไม่ตัดหน้าคำเชื่อม (ซึ่ง และ โดย ...) ไม่แยกตัวเลขกับหน่วย"""
    cl, cur = [], ''
    for w in t.split():
        first = (words(w) or [w])[0]
        tail = (words(cur.split()[-1]) or [''])[-1] if cur else ''
        brk = cur and (re.search(r'[.!?]$', cur) or (first not in CONT and tail not in TAIL and not (re.search(r'\d$', cur) and re.match(UNIT, w))
                                                       and not re.search(r'\d', w) and not re.match(r'[(A-Za-z]', w) and not re.search(r'[(:]$', cur)))
        if brk: cl.append(cur); cur = w
        else: cur = f'{cur} {w}' if cur else w
    return cl + [cur] if cur else cl

def pieces(cl, lo=55, hi=130):
    """รวมความสั้นเข้ากับความก่อนหน้า (ความสั้นที่ตามมามักเป็นส่วนต่อ) ให้แต่ละข้อยาวพอ ๆ กัน ไม่แต่งคำ ไม่ทิ้งคำ"""
    out = []
    for c in cl:
        if out and len(c) < 30 and len(out[-1]) + len(c) + 1 <= hi * 1.4: out[-1] += ' ' + c      # เศษสั้น ๆ ต่อท้ายข้อก่อน
        elif out and len(out[-1]) < lo and len(out[-1]) + len(c) + 1 <= hi: out[-1] += ' ' + c
        else: out.append(c)
    if len(out) > 1 and len(out[-1]) < lo and len(out[-2]) + len(out[-1]) + 1 <= hi * 1.3: last = out.pop(); out[-1] += ' ' + last
    return out

def analyze(path, name=None):
    """ไฟล์ลูกค้า → ชื่อเรื่อง + รายการแผ่น (ยังไม่เลือก layout)"""
    blocks = read_any(path)
    body = [b for b in blocks if b[0] != 'h']
    if len(body) == 1 and body[0][0] == 'p' and len(body[0][1]) >= 120:   # วางมาเป็นย่อหน้ายาวย่อหน้าเดียว
        cl = clauses(body[0][1]); hs = [b for b in blocks if b[0] == 'h']
        ttl = hs[0][2] if hs else cl.pop(0)                    # ไม่มีหัวเรื่อง = ความแรกเป็นชื่อเรื่อง
        sub = ''
        if not hs and len(ttl) > 60:                           # ความแรกยาวเกินปก: ชื่อเรื่องถึงเว้นวรรคแรกหลัง ~20 ตัว ที่เหลือเป็นหัวรองบนปก
            cut = next((m.start() for m in re.finditer(' ', ttl) if 20 <= m.start() <= 60
                        and (wordsx(ttl[m.start() + 1:]) or [''])[0] not in CONT and not re.match(UNIT, ttl[m.start() + 1:])
                        and not re.search(r'\d', ttl[m.start() + 1:].split(' ')[0])), None)
            if cut: ttl, sub = ttl[:cut], ttl[cut + 1:]
        ps = pieces(cl)
        if len(ps) >= 2:
            want = [dict(kind='cover', t=ttl, _sec=None, **({'s': sub} if sub else {}))] + [dict(kind='list', t='', ordered=False, note='', items=[(x,) for x in part], _sec=0) for part in chunk(ps)]   # เป็นรายการ ไม่ทำการ์ดตัวเลข (ป้ายจะเป็นประโยคเว้าแหว่ง)
            return ttl, want
    title, secs = sections(blocks)
    ttl = title or os.path.splitext(name or os.path.basename(path))[0]
    # _sec = หัวข้อที่หน้านี้มาจาก (เลขลำดับในเอกสาร) สารบัญผูกกับหน้าด้วยเลขนี้ ไม่ใช่ชื่อ (หน้าที่ใช้ประโยคเป็นชื่อก็ไม่หลุด)
    want = [dict(kind='cover', t=ttl, _sec=None)]
    if len(secs) >= 3:
        ix = [i for i, s in enumerate(secs) if s['t']][:6]
        want.append(dict(kind='agenda', t='สารบัญ', items=[(secs[i]['t'],) for i in ix], _secs=ix, _sec=None))
    for i, s in enumerate(secs): want += [dict(x, _sec=i) for x in shapes(s)]
    if len(want) > MAXSLIDES:
        NOTES.append(f'เอกสารยาว ใช้ {MAXSLIDES} หน้าแรกจาก {len(want)} หน้า'); want = want[:MAXSLIDES]
    return ttl, want

def pool_of(slug):
    m = deck_of(slug)
    return dict(m['META']), [(nm, ex, *kind_of(nm, ex, i, len(m['SEQ']))) for i, (nm, ex) in enumerate(m['SEQ'])]

def candidates(c, pool, used):
    cand = []
    for nm, ex, kd, n_ex, slots in pool:
        pen = FIT.get(c['kind'], {}).get(kd)
        if pen is None: continue
        n_c = len(c.get('items') or c.get('rows') or [])
        if len(c.get('items') or []) > CAP.get(nm, 99) or len(c.get('rows') or []) > ROWCAP.get(nm, 99): continue
        cand.append((pen * 10 + abs(n_c - n_ex) * 2 + used.get(nm, 0) * 20, nm, ex, slots))   # ใช้ซ้ำโดนโทษแรงขึ้น ให้หน้าตาหลากหลาย
    return sorted(cand, key=lambda x: x[0])

def try_one(nm, ex, slots, c, M):
    """คืน (dict, ปัญหา)  dict=None ถ้าใส่ไม่ได้"""
    d = fill(nm, ex, slots, c)
    if d is None: return None, 'โครงไม่ตรง'
    if c['kind'] == 'agenda' and slots and slots != (str,) and c.get('items') and all(len(x) == 1 for x in c['items']) and sum(t is str for t in slots) > 1 \
            and not c.get('_slot') and overflow(nm, d, M):    # ข้อเดียวต่อแถวลงช่องแรกไม่ได้ ลองช่องที่สอง
        d2, bad2 = try_one(nm, ex, slots, dict(c, _slot=1), M)
        if d2 is not None: return d2, ''
    if c['kind'] == 'cover' and 't1' in d and 't2' in d and not d.get('t2') and overflow(nm, d, M):
        # ปกที่แยกชื่อเรื่องเป็นบรรทัด t1/t2 (ตัวใหญ่ บรรทัดละกล่อง): แบ่งชื่อที่รอยต่อคำ ถ้ายังยาว ส่วนท้ายลงหัวรอง
        ws = wordsx(d['t1']); slots_ = ['t1', 't2'] + ([] if d.get('s') else ['s'])
        blank = {k: '' for k in slots_}; got = {}; i = 0
        for k in slots_:                                   # ใส่คำให้เต็มบรรทัดทีละช่อง (วัดจริงทุกครั้ง) ช่องสุดท้ายรับที่เหลือ
            if k == slots_[-1]: got[k] = ''.join(ws[i:]).strip(); break
            j = i + 1
            while j < len(ws) and not overflow(nm, {**d, **blank, **got, k: ''.join(ws[i:j + 1]).strip()}, M): j += 1
            got[k] = ''.join(ws[i:j]).strip(); i = j
        d2 = {**d, **blank, **got}
        if i >= len(ws) or got.get(slots_[-1]):
            if not overflow(nm, d2, M): d = d2
    if c['kind'] == 'cover':                               # ปกย่อขนาดหัวเรื่องได้ ลองไล่ลงก่อนเปลี่ยน layout
        for z in (None, 40, 36, 32, 28):
            if z: d['tsz'] = z
            if not overflow(nm, d, M): break
    bad = overflow(nm, d, M)
    return (None, bad[0]) if bad else (d, '')

def one(c, xs):
    """ข้อที่แบ่งออกมา  เหลือข้อเดียว → ไปลง layout ประโยคเดี่ยวที่ตัวใหญ่และกว้างกว่า"""
    if len(xs) > 1 or c['kind'] not in ('list', 'pairs', 'qa', 'timeline'): return dict(c, items=xs)
    x = xs[0]
    if c['kind'] == 'qa': return dict(kind='statement', t=x[1], s=x[0])
    return dict(kind='statement', t=': '.join(x), s=c['t'])   # คืนเครื่องหมาย : ให้ตรงต้นฉบับ

def plan(want, slug, on_step=None):
    """เลือก layout ทีละแผ่น  คืน (META, [dict(c, layout, d)], log)"""
    it = plan_iter(want, slug)
    try:
        while True:
            st = next(it)
            if on_step: on_step(*st)
    except StopIteration as e:
        return e.value

def plan_iter(want, slug):
    """เหมือน plan แต่ yield (เสร็จ, ทั้งหมด, ชื่อ layout ล่าสุด) ทุกแผ่น ให้เว็บวาดความคืบหน้าระหว่างคิด
    (Pyodide รันบนเธรดหน้าเว็บ ถ้าไม่หยุดเป็นช่วง ๆ จอจะค้างจนเสร็จ)"""
    M, pool = pool_of(slug)
    want = list(want); out, log, used = [], [], {}
    last = None
    while want:
        yield (len(out), len(out) + len(want), out[-1]['layout'] if out else '')
        c = want.pop(0)
        if '_sec' not in c and last is not None: c = dict(c, _sec=last)   # หน้าที่แบ่ง/เปลี่ยนชนิดออกมา อยู่หัวข้อเดิม
        last = c.get('_sec', last)
        cand = candidates(c, pool, used)
        why, got = [], None
        for sc, nm, ex, slots in cand:
            d, bad = try_one(nm, ex, slots, c, M)
            if d is None: why.append(f'{nm} ไม่ผ่าน: {bad}'); continue
            got = (nm, d); break
        if not got and c['kind'] == 'cover' and cand:      # ปกต้องมีเสมอ ล้นก็ใส่แล้วฟ้องให้คนแก้ชื่อ
            d = fill(cand[0][1], cand[0][2], cand[0][3], c)
            if d is not None: got = (cand[0][1], d); why.append('ใส่ปกทั้งที่ไม่ผ่าน')
        if not got and c['kind'] == 'stat' and c.get('raw'):  # ชุดนี้ไม่มีการ์ดตัวเลขที่รับได้ → ลงเป็นรายการ ข้อความเดิม
            want.insert(0, dict(kind='list', t=c['t'], note=c.get('note', ''), items=[(x,) for x in c['raw']]))
            log.append((c, None, why[-3:], 'ลงเป็นรายการแทน')); continue
        n_rw = len(c.get('rows') or [])
        if not got and n_rw > 2 and c['kind'] in ('table', 'chart') and any(p[2] in ('table', 'chart') for p in pool):   # ตารางยาวเกินที่ชุดนี้วาดได้ → แบ่งครึ่ง หัวตารางซ้ำ
            h = -(-n_rw // 2)
            cut = lambda a, b: dict(c, rows=c['rows'][a:b], **({'cats': c['cats'][a:b], 'vals': c['vals'][a:b]} if 'cats' in c else {}))
            want[:0] = [cut(0, h), cut(h, n_rw)]
            log.append((c, None, why[-3:], f'แบ่งตารางเป็น {h}+{n_rw - h} แถว')); continue
        if not got and c['kind'] in ('chart', 'table') and len(c['head']) >= 2:   # ไม่มีตาราง/กราฟ → คู่ ช่องแรก: ที่เหลือ
            hd = c['head']                                 # หลายคอลัมน์: ใส่ชื่อคอลัมน์ของลูกค้าหน้าค่า ไม่ให้ตัวเลขติดกันอ่านไม่ออก
            head_pair = [(hd[0], ' '.join(hd[1:]))] if len(hd) <= 2 and any(hd) else []   # สองคอลัมน์: หัวตารางเป็นคู่แรก ไม่ทิ้งชื่อคอลัมน์
            rows = [(r[0], (' '.join(x for x in r[1:] if x) if len(hd) <= 2 else
                            ' '.join(f'{h} {x}' for h, x in zip(hd[1:], r[1:]) if x))) for r in c['rows']]   # เว้นวรรคอย่างเดียว ไม่เติมเครื่องหมาย
            rows = head_pair + rows
            want[:0] = [dict(kind='pairs', t=c['t'], note=c.get('note', ''), items=part) for part in chunk(rows)]
            log.append((c, None, why[-3:], 'ลงเป็นคู่หัว-ค่าแทน')); continue
        n_it = len(c.get('items') or [])
        if not got and c['kind'] == 'list' and not c.get('t') and not c.get('_cl') and any(len(x[0]) > 40 for x in c['items']):
            # ย่อหน้ายาวที่ไม่มีหัวข้อ ในชุดที่กล่องรายการเล็ก: รวมหลายข้อติดกันลงช่องข้อความยาวของหน้าข้อความเด่น
            # (ข้อความเต็มประโยค ไม่ตัดกลางความ หน้าละหลายข้อ ไม่ใช่หน้าละท่อนสั้น ๆ)
            its, i, packs = [x[0] for x in c['items']], 0, []
            while i < len(its):
                k = next((k for k in range(len(its) - i, 0, -1) if len(' '.join(its[i:i + k])) <= 170   # หน้าละไม่เกิน ~170 ตัว อ่านได้
                          and any(try_one(nm, ex, sl, dict(kind='statement', t='', s=' '.join(its[i:i + k])), M)[0] is not None
                                  for _, nm, ex, sl in candidates(dict(kind='statement', t='', s=''), pool, used))), 0)
                if not k:                                  # ข้อนี้ยาวเกินทุกช่อง: แตกที่รอยต่อความแล้วลองต่อ
                    sub = pieces(clauses(its[i]), lo=25, hi=60)
                    if len(sub) < 2: break
                    its[i:i + 1] = sub; continue
                packs.append(dict(kind='statement', t='', s=' '.join(its[i:i + k]), _sec=c.get('_sec'))); i += k
            if i == len(its):
                want[:0] = packs; log.append((c, None, why[-3:], f'รวม {len(its)} ข้อเป็น {len(packs)} หน้าข้อความ')); continue
        if not got and c['kind'] == 'list' and not c.get('_cl') and any(len(x[0]) > 60 for x in c['items']):
            # ข้อยาวเกินกล่องของชุดนี้: แตกเป็นความสั้นที่รอยต่อความ (ยังเป็นรายการเดียวกัน) ก่อนจะแบ่งเป็นหลายหน้า
            its = [(p_,) for x in c['items'] for p_ in pieces(clauses(x[0]), lo=25, hi=60)]
            want[:0] = [dict(c, items=part, _cl=1) for part in chunk(its)]
            log.append((c, None, why[-3:], f'แตกข้อยาวเป็น {len(its)} ข้อสั้น')); continue
        if not got and n_it > 1 and c['kind'] != 'agenda':  # ห้ามทิ้งเนื้อลูกค้า แบ่งครึ่งแล้วลองใหม่
            h = -(-n_it // 2)
            want[:0] = [one(c, c['items'][:h]), one(c, c['items'][h:])]
            log.append((c, None, why[-3:], f'แบ่งเป็น {h}+{n_it - h} ข้อ')); continue
        if not got and c['kind'] == 'compare':                  # ชุดนี้ไม่มีหน้าเปรียบเทียบ → รายการกลุ่มละหน้า
            want[:0] = [dict(kind='list', t=g[0], items=[(x,) for x in g[1]]) for g in c['items'] if g[1]]
            log.append((c, None, why[-3:], 'แยกเป็นรายการกลุ่มละหน้า')); continue
        if not got and c['kind'] == 'list' and c.get('_fb') and len(c['items']) == 1:   # ย่อหน้ายาวเกินทุกกรอบ
            txt = c['items'][0][0]
            cl = clauses(txt); acc = 0; sp = []                # ตัดที่รอยต่อความก่อน (ไม่ตัดกลางความ เช่นหน้า "ซึ่ง")
            for x in cl[:-1]: acc += len(x) + 1; sp.append(acc - 1)
            if not sp:                                     # ไม่มีรอยต่อความ: เว้นวรรคที่ไม่แยกตัวเลขกับป้าย/หน่วย ไม่จบด้วยคำเชื่อม
                ok = lambda i: not re.search(r'\d', txt[i + 1:].split(' ')[0]) and not (re.search(r'\d$', txt[:i]) and re.match(UNIT, txt[i + 1:])) \
                    and (words(txt[i + 1:].split(' ')[0]) or [''])[0] not in CONT \
                    and (words(txt[:i].split(' ')[-1]) or [''])[-1] not in TAIL
                allsp = [m.start() for m in re.finditer(' ', txt)]
                sp = [i for i in allsp if ok(i)] or allsp
            if not sp and len(txt) > 40:                # ประโยคไทยไม่มีเว้นวรรค: ตัดที่รอยต่อคำ (ตัวตัดคำ ไม่ใช่ AI)
                acc = 0; sp = []
                for w_ in wordsx(txt)[:-1]: acc += len(w_); sp.append(acc)
            if sp and len(txt) > 40:                    # ตัดที่ช่องว่างใกล้กึ่งกลาง เป็นสองหน้าต่อกัน คำครบเหมือนเดิม
                cut = min(sp, key=lambda i: abs(i - len(txt) / 2))
                want[:0] = [dict(kind='statement', t=txt[:cut].strip(), s=c['t']), dict(kind='statement', t=txt[cut:].strip(), s=c['t'])]
                log.append((c, None, why[-3:], 'แบ่งย่อหน้ายาวเป็นสองหน้า')); continue
        if not got and c['kind'] == 'statement' and not c.get('_fb'):   # ประโยคยาวเกินหน้าคำคม → ลองเป็นรายการข้อเดียว
            want.insert(0, dict(kind='list', t=c.get('s', ''), items=[(c['t'],)], _fb=1))
            log.append((c, None, why[-3:], 'ลองเป็นรายการ')); continue
        if not got:
            log.append((c, None, why, 'ไม่มี layout ในชุดนี้รับได้ ข้ามแผ่นนี้')); continue
        used[got[0]] = used.get(got[0], 0) + 1
        out.append(dict(c=c, layout=got[0], d=got[1])); log.append((c, got[0], why, ''))
    return M, out, log

KIND_TH = {'cover': 'ปก', 'agenda': 'สารบัญ', 'list': 'รายการ', 'pairs': 'หัวข้อพร้อมคำอธิบาย', 'qa': 'ถาม-ตอบ',
           'stat': 'ตัวเลขสำคัญ', 'timeline': 'ไทม์ไลน์', 'table': 'ตาราง', 'chart': 'กราฟ', 'statement': 'ข้อความเด่น',
           'divider': 'หน้าคั่น', 'compare': 'เปรียบเทียบ'}

def findings(want):
    """สิ่งที่อ่านเจอในไฟล์ ไว้โชว์ลูกค้าก่อนสร้าง (ของจริงทั้งหมด ไม่ได้เดา)"""
    secs = [c for c in want if c['kind'] not in ('cover', 'agenda')]
    nums = [x[0] for c in want if c['kind'] == 'stat' for x in c['items']]
    return dict(
        sections=len({c['t'] for c in secs}),
        tables=sum(1 for c in want if c['kind'] in ('table', 'chart')),
        rows=sum(len(c.get('rows') or []) for c in want if c['kind'] in ('table', 'chart')),
        nums=nums[:6], dates=sum(len(c['items']) for c in want if c['kind'] == 'timeline'),
        qa=sum(len(c['items']) for c in want if c['kind'] == 'qa'), notes=list(NOTES),
        outline=[dict(t=c['t'] if c['kind'] != 'statement' else (c.get('s') or c['t']), kind=c['kind'],
                      th=KIND_TH.get(c['kind'], ''), n=len(c.get('items') or c.get('rows') or [])) for c in want])

def _ptitle(c):
    t = (c.get('s') or c.get('t')) if c['kind'] == 'statement' else c.get('t')
    if t: return t
    x = (c.get('items') or c.get('rows') or [''])[0]
    x = x if isinstance(x, str) else (x[0] if x else '')
    return x[:40] + ('…' if len(x) > 40 else '')

def plan_summary(out):
    """สิ่งที่ทำจริงหลังลงหน้าตา ไว้ให้ผู้ช่วยเล่า (ไม่ใช่สิ่งที่เจอในเนื้อหา ซึ่งบางอย่างหน้าตานั้นทำไม่ได้)"""
    cs = [x['c'] for x in out]
    n = lambda k: sum(1 for c in cs if c['kind'] == k)
    return dict(pages=len(out), kinds={k: n(k) for k in KIND_TH if n(k)},
                stats=[dict(t=c.get('t', ''), vals=[v for v, _ in c['items']][:4]) for c in cs if c['kind'] == 'stat'][:3],
                charts=[c.get('t', '') for c in cs if c['kind'] == 'chart'], tables=[c.get('t', '') for c in cs if c['kind'] == 'table'],
                timelines=sum(len(c['items']) for c in cs if c['kind'] == 'timeline'),
                sections=len({c.get('_sec') for c in cs if isinstance(c.get('_sec'), int)}),
                # โครงหน้าจริงหลังจัด (ชื่อหน้า: หัวเรื่อง หรือหัวรอง หรือข้อความแรกของหน้า) ให้รายการในแชทตรงกับสไลด์
                outline=[dict(t=_ptitle(c), kind=c['kind'], th=KIND_TH.get(c['kind'], ''),
                              n=len(c.get('items') or c.get('rows') or [])) for c in cs])

def alternatives(c, slug):
    """layout อื่นในชุดเดียวกันที่รับแผ่นนี้ได้โดยไม่ล้น — ให้ลูกค้ากดเปลี่ยนแบบ"""
    M, pool = pool_of(slug)
    res = []
    for sc, nm, ex, slots in candidates(c, pool, {}):
        d, bad = try_one(nm, ex, slots, c, M)
        if d is not None: res.append((nm, d))
    return res

def reagenda(c, secs, slug, layout):
    """สารบัญหลังย้าย/ลบหน้า: หัวข้อเดิมที่ยังมีหน้าอยู่ เรียงตามลำดับหน้าปัจจุบัน (secs = หัวข้อของหน้าที่เหลือตามลำดับ)
    คืน (สารบัญใหม่, (layout, d) หรือ None)  None = ไม่เหลือหัวข้อหรือหน้าตานี้ใส่ไม่ได้ เว็บเอาหน้าสารบัญออก
    ponytail: ไม่เติมหัวข้อที่เกิน 6 ข้อแรกเข้ามาแทนข้อที่ลบ สารบัญจึงสั้นลงได้แต่ไม่มีข้อที่ไม่จริง"""
    base = c.get('_items0') or c['items']
    pos = {}
    for i, t in enumerate(secs): pos.setdefault(t, i)
    ids = c.get('_secs0') or c.get('_secs')
    if ids is not None and all(isinstance(t, int) for t in secs):   # ผูกด้วยเลขหัวข้อ
        pairs = sorted([(x, n) for x, n in zip(base, ids) if n in pos], key=lambda p: pos[p[1]])
        keep = [x for x, _ in pairs]
        c2 = dict(c, items=keep, _items0=base, _secs=[n for _, n in pairs], _secs0=ids)
    else:
        keep = sorted([x for x in base if x[0] in pos], key=lambda x: pos[x[0]])
        c2 = dict(c, items=keep, _items0=base)
    if not keep: return c2, None
    alts = alternatives(c2, slug)
    return c2, next((a for a in alts if a[0] == layout), alts[0] if alts else None)

# ══ 7. ตัวแก้บนเว็บ: กล่องไหนมาจากช่องไหน / แก้คำหนึ่งกล่อง ═══════════════════════
BOXES = []                                                 # render() เติม: ต่อหน้าที่วาด รายการกล่องที่แก้ได้

def _leaves(v, path=()):
    """ทุกข้อความของลูกค้าใน d พร้อมที่อยู่ เช่น ('items', 2, 0)  ไม่รวมคีย์ดีไซน์ ตัวเลขกราฟ เลขหน้าคั่น"""
    if isinstance(v, str): yield path, v
    elif isinstance(v, (list, tuple)):
        for i, x in enumerate(v): yield from _leaves(x, path + (i,))
    elif isinstance(v, dict):
        for k, x in v.items():
            if k not in KEEP and k not in ('al', 'colw', 'vals', 'num'): yield from _leaves(x, path + (k,))

def boxmap(slide, d, sw, sh_):
    """กล่องข้อความบนสไลด์ที่วาดแล้ว → ช่องใน d ที่มันมา (หน่วย 960×540)
    จับคู่ด้วยข้อความตรงตัว: ทุกคำบนสไลด์มาจาก d อยู่แล้ว (scrub ลบที่เหลือ) ไม่ต้องรู้โครงของแต่ละ layout
    ponytail: ข้อความที่ layout แยกเป็นหลายกล่อง (เลข + หน่วย) หรืออยู่ในกราฟ ไม่มีกล่อง แก้บนจอไม่ได้"""
    want = {}
    for p, t in _leaves(d):
        if t.strip(): want.setdefault(t.strip(), []).append(list(p))
    used = {}
    fx, fy = 960 / sw, 540 / sh_
    def box(t, x, y, w, h, tf):
        ps = want.get(t)
        if not ps: return None
        k = used.get(t, 0); used[t] = k + 1
        r = next((r for p in tf.paragraphs for r in p.runs if r.font.size), None)
        pt = r.font.size.pt if r else 18
        lh = pt * 1.25 / 72 * 914400
        return dict(p=ps[min(k, len(ps) - 1)], x=round(x * fx, 1), y=round(y * fy, 1), w=round(w * fx, 1), h=round(h * fy, 1),
                    pt=round(pt, 1), multi=ps[0][0] not in ('t', 't1') and (h / lh >= 1.65 or '\n' in t))
    out = []
    for s in slide.shapes:
        if getattr(s, 'has_table', False) and s.has_table:
            tb, y = s.table, s.top
            for row in tb.rows:
                x = s.left
                for j, cell in enumerate(row.cells):
                    b = box(cell.text_frame.text.strip(), x, y, tb.columns[j].width, row.height, cell.text_frame)
                    if b: out.append(b)
                    x += tb.columns[j].width
                y += row.height
        elif s.has_text_frame:
            b = box(s.text_frame.text.strip(), s.left, s.top, s.width, s.height, s.text_frame)
            if b: out.append(b)
    return out

def _get(v, path):
    for k in path: v = v[k]
    return v

def _put(v, path, new):
    """คืนสำเนาที่เปลี่ยนแค่ช่องเดียว (tuple ยังเป็น tuple)"""
    if not path: return new
    k, rest = path[0], path[1:]
    if isinstance(v, dict): return {**v, k: _put(v[k], rest, new)}
    xs = list(v); xs[k] = _put(xs[k], rest, new)
    return tuple(xs) if isinstance(v, tuple) else xs

def _sub(v, old, new, hit):
    """เปลี่ยนทุกข้อความที่ตรงกับคำเดิม  hit[0] นับจำนวนที่เปลี่ยน
    raw (ข้อความเต็มของการ์ดตัวเลข ใช้ตอนลงเป็นรายการแทน) แทนเฉพาะส่วนที่ตรง"""
    if isinstance(v, str):
        if v == old: hit[0] += 1; return new
        return v
    if isinstance(v, (list, tuple)):
        xs = [_sub(x, old, new, hit) for x in v]
        return tuple(xs) if isinstance(v, tuple) else xs
    if isinstance(v, dict):
        out = {}
        for k, x in v.items():
            if k in KEEP: out[k] = x
            elif k == 'raw' and len(old) > 1: out[k] = [r.replace(old, new) if old in r else r for r in x]
            else: out[k] = _sub(x, old, new, hit)
        return out
    return v

def edit_text(items, cs, want, idx, path, new, M, dry=False):
    """ลูกค้าแก้คำในกล่องหนึ่งของหน้า idx  คืน (สถานะ, ตามไปหน้าตาใหม่ได้ไหม)
    สถานะ ok / shrink (ปกย่อตัวลงให้พอดี) / over (ล้นกล่อง ไม่เปลี่ยนอะไร ให้ลูกค้าตัดเอง ห้ามตัดคำเงียบ)
    ไม่ dry: แก้ items[idx] ช่องนั้น + ทุกข้อความเดิมใน cs (สารบัญกับหัวข้อยังตรงกัน) + want (เปลี่ยนหน้าตาแล้วคำใหม่ตามไป)
    ponytail: คำเดิมที่ซ้ำกันหลายที่ใน want/cs เปลี่ยนทั้งหมด หน้าอื่นยังโชว์คำเดิมจนกว่าจะจัดหน้านั้นใหม่"""
    name, d = items[idx]
    path = [p for p in path]
    old = _get(d, path)
    d2 = _sub(_put(d, path, new), old, new, [0]) if old.strip() else _put(d, path, new)   # คำเดียวกันในหน้าเดียวกันเปลี่ยนด้วย (เช่นหัวตารางที่ซ้ำหัวเรื่อง)
    if path[0] == 'cats' and isinstance(d2.get('rows'), list) and len(d2['rows']) > path[1] and d2['rows'][path[1]][0] == old:
        d2 = _put(d2, ['rows', path[1], 0], new)            # ป้ายกราฟกับแถวตารางเป็นคำเดียวกัน
    st = 'ok'
    if overflow(name, d2, M):
        st = 'over'
        if idx == 0 or 'tsz' in d2:                        # ปกย่อหัวเรื่องได้ ไล่ลงแบบเดียวกับตอนจัดครั้งแรก
            for z in (40, 36, 32, 28):
                if z >= d2.get('tsz', 99): continue
                if not overflow(name, {**d2, 'tsz': z}, M): d2 = {**d2, 'tsz': z}; st = 'shrink'; break
    # หัวข้อกับข้อในสารบัญเป็นคำเดียวกัน แก้ฝั่งไหนอีกฝั่งต้องตาม (ไม่งั้นไฟล์มีสองคำไม่ตรงกัน)
    links, ag = [], cs[idx].get('kind') == 'agenda'
    if (ag and path[0] == 'items') or (not ag and path[0] in ('t', 't1', 's')):
        for j, (nm, dj) in enumerate(items):
            if j == idx: continue
            if not ag and cs[j].get('kind') == 'agenda' and 'items' in dj:
                h = [0]; it2 = _sub(dj['items'], old, new, h)
                if h[0]: links.append((j, (nm, {**dj, 'items': it2})))
            elif ag and cs[j].get('kind') not in ('cover', 'agenda'):
                k = next((k for k in ('t', 's') if dj.get(k) == old), None)
                if k: links.append((j, (nm, {**dj, k: new})))
    if st != 'over' and any(overflow(nm, dj, M) for _, (nm, dj) in links): st = 'over'
    if dry or st == 'over': return st, True
    items[idx] = (name, d2)
    for j, it in links: items[j] = it
    hit = [0]
    for j in range(len(cs)): cs[j] = _sub(cs[j], old, new, [0])
    for j in range(len(want)): want[j] = _sub(want[j], old, new, hit)
    return st, hit[0] > 0

def keys(items, order, ttl, slug):
    """ลายนิ้วมือของแต่ละหน้า (ตามลำดับบนจอ) เว็บใช้ภาพเดิมซ้ำถ้าไม่เปลี่ยน ไม่ต้องวาดใหม่ทั้งไฟล์ตอนเลิกทำ"""
    import hashlib
    return [hashlib.md5(repr((items[i], ttl, slug, k == 0)).encode()).hexdigest()[:16] for k, i in enumerate(order)]

def sync_agenda(items, cs, order, slug):
    """หลังย้าย/ลบ/ทำสำเนาหน้า: จัดสารบัญใหม่จากหน้าที่เหลือตามลำดับปัจจุบัน แก้ items/cs ในที่ คืนลำดับหน้าใหม่
    (ไม่เหลือหัวข้อ หรือหน้าตานี้ใส่ไม่ได้ = เอาหน้าสารบัญออก)"""
    k = next((p for p, i in enumerate(order) if cs[i]['kind'] == 'agenda'), -1)
    if k < 0: return list(order)
    i = order[k]; rest = [j for j in order if cs[j]['kind'] not in ('cover', 'agenda')]
    if cs[i].get('_secs') is not None or cs[i].get('_secs0') is not None:
        secs = [cs[j]['_sec'] for j in rest if isinstance(cs[j].get('_sec'), int)]
    else:                                                  # งานเก่าที่เก็บไว้ก่อนมีเลขหัวข้อ
        secs = [t for t in ((cs[j].get('s') if cs[j]['kind'] == 'statement' else cs[j].get('t')) or '' for j in rest) if t]
    c2, pk = reagenda(cs[i], secs, slug, items[i][0])
    cs[i] = c2
    if pk: items[i] = tuple(pk); return list(order)
    return [j for p, j in enumerate(order) if p != k]

_covfill = None
def render(items, M, ttl, only=None):
    """[(layout, dict)] → ไบต์ .pptx  ลำดับขั้นเดียวกับ mk.py (เติมปก, สลับรายละเอียดตาม slug, พลิกปก, ฟอนต์ธีม)
    only = ตำแหน่งหน้าที่จะวาด (ปก/เลขหน้ายังคิดจากทั้งเด็ค) ใช้วาดใหม่เฉพาะหน้าที่แก้"""
    global _covfill
    if _covfill is None:                                   # ยืม _covfill จาก mk.py ตรง ๆ ไม่ก๊อปโค้ด (mk.py รันทันทีที่ import)
        tree = ast.parse(open(f'{K}/mk.py', encoding='utf-8').read())
        fn = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == '_covfill')
        ns = {'re': re}; exec(compile(ast.Module(body=[fn], type_ignores=[]), 'mk.py', 'exec'), ns)
        _covfill = ns['_covfill']
    M = dict(M, cat='', foot=ttl, th=ttl)
    eng.setpal(M['pal'], M.get('font', 'plex'), M.get('head'))
    prs = base.deck()
    seq = list(items)
    BOXES.clear()
    for i, (name, d) in enumerate(seq, 1):
        if only is not None and i - 1 not in only: continue
        dd = dict(topic=M.get('topic', 'office'), foot=ttl, n=f'{i:02d}')
        dd.update(d)
        if i == 1 and name in [n for n, _ in deck_of(M['slug'])['SEQ'][:1]]:
            _covfill(dd, seq, M)
            eng.setvar(sum(ord(c) * (k + 3) for k, c in enumerate(M['slug'])))
        else:
            eng.setvar(0)
        lay.L[name](prs, dd)
        scrub(prs.slides[-1], list(strings(dd)) + [ttl]); drop_empty(prs.slides[-1])
        if i == 1 and eng.vch(0, 2) and not M.get('nomirror'): eng.mirror(prs.slides[-1])
        BOXES.append(boxmap(prs.slides[-1], d, prs.slide_width, prs.slide_height))
    base.theme_font(prs, M.get('font', 'plex'))
    b = io.BytesIO(); prs.save(b)
    return b.getvalue()

FONT_HOWTO = """วิธีติดตั้งฟอนต์ (ทำครั้งเดียวต่อเครื่อง)

Windows: เลือกไฟล์ .ttf ทั้งหมด คลิกขวา แล้วเลือก "ติดตั้งสำหรับผู้ใช้ทั้งหมด" (Install for all users)
Mac: ดับเบิลคลิกไฟล์ .ttf แล้วกด "ติดตั้งฟอนต์" ทีละไฟล์
เสร็จแล้วปิด PowerPoint แล้วเปิดไฟล์สไลด์ใหม่อีกครั้ง

ถ้าเปิดในเครื่องที่ไม่ได้ติดตั้งฟอนต์ ข้อความยังอยู่ครบและแก้ได้ แต่ตัวอักษรจะเปลี่ยนเป็นฟอนต์อื่น
ฟอนต์ทั้งหมดใช้สัญญาอนุญาต SIL Open Font License (ดูไฟล์ OFL.txt) ใช้งานและแจกต่อได้ฟรี
"""

def fonts_zip(files):
    """ฟอนต์ของชุด + สัญญาอนุญาต + วิธีติดตั้ง เป็นไฟล์ zip ให้ลูกค้าโหลดคู่กับ .pptx"""
    import zipfile
    b = io.BytesIO()
    with zipfile.ZipFile(b, 'w', zipfile.ZIP_DEFLATED) as z:
        for f in files: z.write(f'{K}/fonts/{f}', f'ฟอนต์/{f}')
        if os.path.exists(f'{K}/fonts/OFL.txt'): z.write(f'{K}/fonts/OFL.txt', 'ฟอนต์/OFL.txt')
        z.writestr('วิธีติดตั้งฟอนต์.txt', FONT_HOWTO)
    return b.getvalue()

def words_missing(items, src):
    """ข้อความบนสไลด์ที่ไม่มีในไฟล์ต้นฉบับ  คำเดียวที่ระบบเติมเองคือ 'สารบัญ'"""
    return [v for _, d in items for v in strings({k: x for k, x in d.items() if k != 'num'})
            if v.strip() and v != 'สารบัญ' and not re.fullmatch(r'[\d.]+', v) and re.sub(r'\s+', '', v) not in src
            and not all(w in src for w in v.split())]   # ป้ายการ์ดตัวเลขตัดตัวเลขออก วลีเลยไม่ติดกัน แต่ทุกคำยังมาจากต้นฉบับ

if __name__ == '__main__':
    a = [x for x in sys.argv[1:] if not x.startswith('--')]
    path = os.path.abspath(a[0]); slug, e = slug_of(a[1])
    if not deck_of(slug): sys.exit(f'ชุด {a[1]} {e["th"]} ยังไม่มีไฟล์ต้นฉบับใน decks/ (มีแต่ .pptx)')
    ttl, want = analyze(path)
    M, out, log = plan(want, slug)
    print(f'ชุด {e["no"]} {e["th"]} ({e["theme"]})')
    for i, (c, nm, why, err) in enumerate(log, 1):
        n = len(c.get('items') or c.get('rows') or [])
        print(f'{i:2d}. {c["t"][:26]:<26} | {c["kind"]:<9} {n or "":>2} → {nm or "-"}  {err}')
        for w in why[:4]: print(f'        ข้าม {w}')
    items = [(x['layout'], x['d']) for x in out]
    print('ข้อความที่ไม่มีในต้นฉบับ:', [w for w in words_missing(items, source_text(path)) if w != ttl] or 'ไม่มี (ชื่อเรื่องจากชื่อไฟล์ไม่นับ)')
    os.makedirs(f'{K}/out', exist_ok=True)
    stem = re.sub(r'[^a-z0-9]+', '', os.path.splitext(os.path.basename(path))[0].lower())[:10] or 'doc'
    dst = f'{K}/out/d2s{a[1]}_{stem}.pptx'
    open(dst, 'wb').write(render(items, M, ttl)); print('→', dst)
    if '--render' in sys.argv:
        subprocess.run([f'{K}/../kit/render.sh', dst, dst[:-5] + '.pdf'], check=True)
